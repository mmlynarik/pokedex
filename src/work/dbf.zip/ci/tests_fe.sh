#!/bin/bash

CONFIG_FILE=pyproject.toml

source activate dbf

echo "Running django unittest"
cd dbfapp
python manage.py version
python manage.py test
