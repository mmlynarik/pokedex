#!/bin/bash

CONFIG_FILE=pyproject.toml

source activate dbf

echo "Running unittests"
python --version
python -m unittest discover -s tests . || exit $?
