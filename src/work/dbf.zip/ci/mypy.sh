#!/bin/bash

CONFIG_FILE=pyproject.toml

source activate dbf

echo "Running Mypy static-typing check"
mypy --version
mypy --config-file ${CONFIG_FILE} . || exit $?
