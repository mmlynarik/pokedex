CONFIG_FILE=pyproject.toml

source activate dbf

echo "Running Black formatting check"
black --version
black --config ${CONFIG_FILE} --diff .
black --config ${CONFIG_FILE} --check . || exit $?

echo "Running Isort imports sorting check"
isort --version
isort --settings ${CONFIG_FILE} --check . || exit $?

echo "Running Ruff linting check"
ruff --version
ruff check --config ${CONFIG_FILE} . || exit $?
echo "Linting check completed. No issues found."
