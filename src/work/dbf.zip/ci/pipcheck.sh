#!/bin/bash

source activate dbf

echo 'Installing pipik'
pip install usskpipik==1.0.1
echo 'Running pipik'
usskpipik \
    --send $DEVOPS_PIPIK_ENDPOINT \
    --project $DEVOPS_PROJECT \
    --build $DEVOPS_SOURCE_BRANCH:$DEVOPS_SOURCE_VERSION:$DEVOPS_BUILD_ID \
    --user $DEVOPS_PIPIK_USER \
    --password $DEVOPS_PIPIK_PASSWORD

echo "Run sonarqube scan"
sonar-scanner || echo "Sonarqube unavailable."
