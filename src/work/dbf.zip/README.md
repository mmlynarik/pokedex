# Introduction
DBF (Digital Blast Furnace) is a project combining models for blast furnace control from below. The main goal of the project is to reduce the amount of fuel used to operate the blast furnace. For now, the temperature of the pig iron and the content of silicon are the most important features that are monitored and predicted.


# Table of contents
- [Introduction](#introduction)
- [Table of contents](#table-of-contents)
- [Environments](#environments)
    - [Environment setup](#environment-setup)
    - [How to add a new package or update versions](#how-to-add-a-new-package-or-update-versions)
        - [How to generate fixed environment](#how-to-generate-fixed-environment)
- [Datasets and model training](#datasets-and-model-training)
- [Blast furnace GUI](#blast-furnace-gui)
- [Experimental features and scripts](#experimental-features-and-scripts)
- [Kubernetes (K8S) notes](#kubernetes-k8s-notes)


# Environments
In the root directory of this project, you can find 3 similar environments that have been designed for slightly different purposes:
1. `environment.yml` - elemental development environment
2. `environment_gpu.yml` - specifically designed for training models in docker
3. `environment_fixed.yml` - production ready environment

*NOTE: All environments are based on the development `environment.yml`.*

### Environment setup
To configure a local development evironment, use the following commands.

```bash
conda env create -f environment.yml
conda activate dbf
pip install -e dbfcore
```

*NOTE: `dbfcore` is the main package where all the logic takes place. It needs to be installed for the proper functioning of the project.*


### How to add a new package or update versions
Environments need to be updated together, i.e. if you need to update a package in one environment, the same package must be updated in other environments as well!

1. Update the development `environment.yml`
2. Update the `environment_gpu.yml` with the same packages as the development one
3. Generate `environment_fixed.yml` from the updated development environment
4. Push the newly generated environments and make a PR

##### How to generate fixed environment
1. Uncomment the line `COPY ./environment.yml /tmp/environment.yml` and comment the line `COPY ./environment_fixed.yml /tmp/environment.yml` in `./docker/dbfadmin/Dockerfile`
2. Build an image with a newly updated development environment:
   `docker build -t dbftestimage -f .\docker\dbfadmin\Dockerfile .`
3. Log in to the running container:
   `docker run -it dbftestimage /bin/bash`
4. Activate the development environment:
   `conda activate dbf`
5. Create fixed environment:
   `conda env export >> environment_fixed.yml`
6. Copy file from docker container:
   `docker cp [containername]:[internal/path/to/environment_fixed.yml] .`
7. Modify copied file - remove local packages, channels and prefixes


# Datasets and model training
The main package that includes all information about datasets, model training and model evaluation, as well as other key features leading to the final blast furnace model is `dbfcore`

For more information about datasets and model training see the [dbfcore docs](./dbfcore/README.md).


# Blast furnace GUI
At the time, the blast furnace GUI serves mainly to monitor the performance of the prediction model in real time. It is a simple django application consisting of a few plotly charts.

For more information about how to manage and run blast furnace GUI see the [dbfapp docs](./dbfapp/README.md).


#  Experimental features and scripts
All experimental features (e.g. notebooks, scripts, small csv files etc.) are stored in the `experimental` folder.

*NOTE: Scripts and notebooks stored within the `experimental` folder shall not be used in production, hence they are usually not thoroughly reviewed.*


# Kubernetes (K8S) notes
Below are a few notes for the work with K8S.

1. To start local k8s
   `minikube start`
2. To run local dashboard run
   `minikube dashboard --url`
3. In folder `k8s` you can run the following command to upgrade charts in your k8s
   `helm upgrade -i dbf .\dbf\ -f .\dbf\values-test.yaml`
4. To save local image to `.tar`
   `docker save -o imagename.tar [imagetag]`
5. To load local image to minikube
   `minikube image load imagename.tar`
6. To publish service
   `minikube service [service name]`