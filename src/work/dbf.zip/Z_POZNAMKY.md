# DBFCORE
## Struktura
1. vytiahnut `piclient` ako samostatny package do DCP
2. vsetko co je v `./dataset/raw_dataset` a `./dataset/preprocessed_dataset` presunut do nejakeho *LEGACY* foldra (spolu so skriptami, ktore sa pouzivaju na generovanie tychto datasetov)
3. folder `dataset/signals` by sa mohol rozdelit na 2 subfoldre: `loading` a `preprocessing`. Vo foldri `loading` budu obsiahnute vsetky loadre (training aj live). Vo foldri `preprocessing` budu vsetky moduly, ktore preprocesuju data (zachovat `make_transformations` pri preprocessingu?)
4. obsah `.dataset/utils.py` presunut do *LEGACY* foldra
5. folder `./dataset/liveprediction` zanikne, pretoze nacitanie dat a preprocessing bude v ramci foldra `./dataset/signals` (live aj training)
6. vytiahnut modul `preprocessing` z `./model/datamodule/` do `.dataset/signals`
7. premenovat `./model/datamodule/pisignal.py`
8. moduly, ktore su volne v `./model` zabalit do nejakeho subfoldru (napr. `nnmodules` alebo nejak tak)
9. co s `./model/normalizerparams.py`? - je tam todo na refaktoring
10. 

## Refactoring
1. refaktorovat `utils.py`
2. na viacerych miestach mame rozne mapingy na *user_friendly_name* (napr. v `./model/datamodule/common.py` mame mapovanie na *pi_point_names*, v `./dbfapp/modelbackend/management/commands/utils.py` mame mapovanie na cislo vysokej pece) - mozno by nebolo odveci to zjednotit a vytvorit jednotny framework/protocol, kde *user_friendly_name* by bol ako kluc a hodnoty by boli kolekcie (napr. namedtuple) hodnot ako *pi_point_name*, cislo pece atd.
3. precistit (rozdelit na viacero modulov) `./model/datamodule/pisignal.py`? (a premenovat na `signal.py`)
4. v `./model/datamodule/pisignal.py` odstranit 2 z `Signal2`, `SignalsDataModule2`
5. `./model/datamodule/preprocessing/py` vytiahnut na uroven datasetu
6. v `./model/utils.py` su nejake nn.moduly. To asi nebude OK a zasluzili by si vlastne `.py` moduly
7. Vytiahnut logiku zo skriptov v `./model/scripts`


# DBFAPP
## Struktura
1. vsetko OK

## Refactoring
1. Refaktorovat vsetky skripty v `./modelbackend/commands`
2. Mozno preniest niektore URL z modelfrontend do modelbackend - napr.:
    * calculatemodel
    * backfillembeddings
    * backfillpredictions
    * decodepredictions


# ROZNE
- integrovat vsetko co je v `docs` do hlavneho `README.md` (pripadne prislusnych subpackagov) - myslene, pridat do hlavneho readme odkazy na prislusne `.md` fily