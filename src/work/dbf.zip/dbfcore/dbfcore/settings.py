import os
from datetime import datetime, timedelta

import pandas as pd
from pytz import timezone

from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

LOCAL = "Europe/Bratislava"
TZ_UTC = timezone("UTC")
TZ_LOCAL = timezone(LOCAL)

# When changing MAX_PRED_FREQ value, update value attributes of options elements in select element in
# base_eval_chart.html to be multiples of new MAX_PRED_FREQ value in order for the selection and display of
# stored results on model evaluation page was correct
MAX_PRED_FREQ = "1min"

EVAL_MODE_FORECAST_HORIZONS_MINS = [0, 30, 60, 90, 120, 150, 180, 210, 240]
# Frequency with which we want model evaluation data to be saved in DB
EVAL_MODE_FORECAST_FREQUENCY = pd.Timedelta(minutes=15)

FURNACE_IDS = (1, 2, 3)
NUM_CHARGE_LAYERS = 30
NANOSECONDS_IN_SECOND = 1_000_000_000

EXPECTED_DELIVERY_WEIGHT_T = 350

DBF_ROOT_DATA_PATH = os.getenv("DBF_ROOT_DATA_PATH", "./data")
RAW_DATASET_PATH = DBF_ROOT_DATA_PATH + "/raw_dataset"
PREPROCESSED_DATASETS_PATH = DBF_ROOT_DATA_PATH + "/preprocessed_datasets"
PI_CACHE_FOLDER = DBF_ROOT_DATA_PATH + "/piapi"
DATAMODULE_CACHE = DBF_ROOT_DATA_PATH + "/datamodule"
DEFAULT_DATASET_SEPARATOR = ","
DEFAULT_DATASET_INDEX_COLUMN = "date"

DEFAULT_RAW_DATASET_START_DATE = datetime(2018, 1, 1, 0, 0, tzinfo=TZ_UTC)
DEFAULT_RAW_DATASET_END_DATE = datetime(2024, 1, 1, 0, 0, tzinfo=TZ_UTC)
INVALID_TIMESTAMPS = {
    2018: (datetime(2018, 3, 25, 2, 0, 0), datetime(2018, 3, 25, 2, 59, 59)),
    2019: (datetime(2019, 3, 31, 2, 0, 0), datetime(2019, 3, 31, 2, 59, 59)),
    2020: (datetime(2020, 3, 29, 2, 0, 0), datetime(2020, 3, 29, 2, 59, 59)),
    2021: (datetime(2021, 3, 28, 2, 0, 0), datetime(2021, 3, 28, 2, 59, 59)),
    2022: (datetime(2022, 3, 27, 2, 0, 0), datetime(2022, 3, 27, 2, 59, 59)),
    2023: (datetime(2023, 3, 26, 2, 0, 0), datetime(2023, 3, 26, 2, 59, 59)),
    2024: (datetime(2024, 3, 31, 2, 0, 0), datetime(2024, 3, 31, 2, 59, 59)),
}

# Processing time of the analysis of the sample taken during tapping
ANALYSIS_PROCESSING_DURATION = timedelta(minutes=30)

AVG_TAPPING_DURATION = timedelta(hours=1.5)
MAX_TAPPING_DURATION = timedelta(hours=3)
MIN_VALID_TAPPING_TEMPERATURE = 1100
MAX_VALID_TAPPING_TEMPERATURE = 1600

MAX_DELIVERIES_PER_TAPPING = 3
MAX_HEATS_PER_DELIVERY = 7
STEELSHOP_ANALYSIS_CHEMS = ["c", "mn", "p", "s", "si", "ti"]
ELIGIBLE_CHEM_PRECISIONS = {"s": 0.01, "p": 0.005, "c": 0.15, "ti": 0.005, "mn": 0.01, "si": 0.01}

NUMBER_OF_RAW_MATERIAL_COLUMNS = 20
NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS = 6
NUMBER_OF_PIG_IRON_ANALYSIS_COLUMNS = 3
NUMBER_OF_SLAG_POT_COLUMNS = 10

COKES = [34, 37, 40]
COKE_1_OR_3 = [34, 40]
CARBONATES = [32, 39, 204, 187, 351, 350]

PIG_IRON_ELEMENTS = ["as", "c", "fe", "mn", "p", "pb", "s", "si", "ti", "zn"]
SLAG_MINERALS = ["al2o3", "c", "cao", "fe", "k2o", "mgo", "mn", "na2o", "s", "sio2", "tio2"]
RAW_MATERIAL_MINERALS = [
    "al2o3",
    "ars",
    "c",
    "cao",
    "caco3",
    "cu",
    "fe2o3",
    "feo",
    "h2o",
    "hg",
    "k",
    "k2o",
    "mgo",
    "mgco3",
    "mn",
    "na",
    "na2o",
    "p",
    "pb",
    "s",
    "sio2",
    "ti",
    "tio2",
    "zn",
]

AUTOENCODER_CHARGE_MINERALS = RAW_MATERIAL_MINERALS + ["coke"]

SUPPORTED_AUTOENCODER_SIGNALS: dict[str, list[str] | list[tuple[str, ...]]] = {
    "PI": list(PI_POINT_NAME_TO_SIGNAL_NAMES_MAP.values()),
    "CHARGE": [
        f"{prefix}charge{mineral}_flow_kgh"
        for prefix in [f"bf{i}_" for i in range(1, 4)]
        for mineral in AUTOENCODER_CHARGE_MINERALS
    ],
    "PIGIRON": [
        f"{prefix}hotmetal{element}_chem_pct"
        for prefix in [f"bf{i}_" for i in range(1, 4)]
        for element in PIG_IRON_ELEMENTS
    ],
    "TEMP": [
        f"{prefix}hotmetal{suffix}_temp_C"
        for prefix in [f"bf{i}_" for i in range(1, 4)]
        for suffix in ["corrected", "afterslag"]
    ],
}


GRANULOMETRY_AZVP_COLUMN_NAMES = [
    "granulometry_date",
    "number_at_granulometry",
    "r0_5",
    "r5_10",
    "above_10",
    "under_25",
    "r25_40",
    "r40_60",
    "r60_80",
    "above_80",
    "kind",
]

GRANULOMETRY_FRACTIONS_MAP = {
    "sinter": ["r0_5", "r5_10", "above_10"],
    "pellets": ["r0_5", "r5_10", "above_10"],
    "coke": [
        "under_25",
        "r25_40",
        "r40_60",
        "r60_80",
        "above_80",
    ],
}

# Currently we do not weight slag, only measurement of slag weight is through number of slag pots
# Operators are marking slag pot fill by quarters. On average full pot should have 30 tons.
SLAG_POT_WEIGHT = 30

SENSORS_DATA_COLUMN_NAMES = [
    "QZPC",
    "QPUA",
    "QPUB",
    "QV",
    "QW",
    "QO2",
    "POS",
    "TV",
    "QCVP",
    "PS",
    "CO",
    "CO2",
    "H2",
    "POKHV",
    "POKVLH",
    "POKEXA",
    "POKEXB",
    "POKEXC",
    "POKEXD",
    "QVSK",
    "O2V",
    "WV",
    "QPU",
    "S_KO",
    "TKP",
]

PIG_IRON_WEIGHT_COLUMN_NAME = "pig_iron_weight"
PIG_IRON_ANALYSIS_COLUMN_NAMES = [f"pig_iron_{chem}_pct" for chem in PIG_IRON_ELEMENTS]
SLAG_POT_COLUMN_NAME = "slag_pot_fill_value"

SENSORS_DATA_TIME_PERIOD = 5
CARBON_RATIO_IN_QPU = 0.8
DUST_WEIGHT_IN_KG_PER_TON_OF_PIG_IRON = 20
CARBON_RATIO_IN_DUST = 0.2
CELSIUS_TO_KELVIN_CONVERTER_UNIT = 273.15  # [K]
GAS_CONSTANT = 8.31446261815324  # [m3⋅Pa/K⋅mol]

BFILL_TIME_BOUNDARY_FOR_SOURCE = pd.Timedelta(weeks=1)

STOVE_NUMBERS = [11, 12, 13, 14]

STOVE_COG_CHEMS = ["ch4", "h2", "o2", "n2", "co2", "c2h4", "c2h6", "c2h2", "co"]
STOVE_BFG_CHEMS = ["co", "co2", "h2", "n2", "h2o"]
STOVE_AIR_CHEMS = ["o2", "n2", "h2o"]

SPP_NATURAL_GAS_CHEM_COMPOSITION = {
    "ch4": 93.6643,
    "c2h6": 3.6512,
    "c3h8": 1.6064,  # included: c4h10 (0.3028), c5h12 (0.0525), c6h14 (0.0243)
    "co2": 0.5691,
    "n2": 0.7081,
    "h2": 0.0007,
    "o2": 0.0003,
}
