import torch
import torch.nn as nn

mb_output = dict[str, tuple[torch.Tensor, torch.Tensor]]


class MBParams(nn.Module):
    def __init__(self):
        super().__init__()
        self.qpu_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.charge_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.pig_iron_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.slag_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.bf_gas_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)
        self.dust_weight_correction = nn.Parameter(torch.tensor(1.0), requires_grad=True)


class SimpleChemMaterialBalance(nn.Module):
    def __init__(self, mbparams: MBParams, element: str):
        super().__init__()
        self.mbparams = mbparams
        self.qpu_weight = f"qpu_{element}_weight"
        self.rm_weight = f"raw_material_{element}_weight"
        self.pi_weight = f"pig_iron_{element}_weight"
        self.s_weight = f"slag_{element}_weight"

    def forward(self, data: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        qpu = data[self.qpu_weight] * self.mbparams.qpu_weight_correction
        raw_material = data[self.rm_weight] * self.mbparams.charge_weight_correction
        pig_iron = data[self.pi_weight] * self.mbparams.pig_iron_weight_correction
        slag = data[self.s_weight] * self.mbparams.slag_weight_correction

        return qpu + raw_material, pig_iron + slag


class ComplexChemMaterialBalance(nn.Module):
    def __init__(self, mbparams: MBParams, element: str):
        super().__init__()
        self.mbparams = mbparams
        self.qpu_weight = f"qpu_{element}_weight"
        self.rm_weight = f"raw_material_{element}_weight"
        self.pi_weight = f"pig_iron_{element}_weight"
        self.s_weight = f"slag_{element}_weight"
        self.bfg_weight = f"bf_gas_{element}_weight"
        self.dust_weight = f"dust_{element}_weight"

    def forward(self, data: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor]:
        qpu = data[self.qpu_weight] * self.mbparams.qpu_weight_correction
        raw_material = data[self.rm_weight] * self.mbparams.charge_weight_correction
        pig_iron = data[self.pi_weight] * self.mbparams.pig_iron_weight_correction
        slag = data[self.s_weight] * self.mbparams.slag_weight_correction
        bf_gas = data[self.bfg_weight] * self.mbparams.bf_gas_weight_correction
        dust = data[self.dust_weight] * self.mbparams.dust_weight_correction

        return qpu + raw_material, pig_iron + slag + bf_gas + dust


# toto sa do buducna nahradi premennou PIG_IRON_ELEMENTS zo settingov, pretoze tam budu vsetky elementy, ktore su obsiahnute v surovom zeleze
MATERIAL_BALANCE_ELEMENTS = ["al", "as", "c", "ca", "fe", "k", "mg", "mn", "na", "p", "pb", "si", "ti", "zn"]


class MaterialBalance(nn.Module):
    def __init__(self, mbparams: MBParams, chems: list[str] = MATERIAL_BALANCE_ELEMENTS):
        super().__init__()
        self.mbparams = mbparams
        for chem in chems:
            if chem != "c":
                setattr(self, f"{chem}_material_balance", SimpleChemMaterialBalance(self.mbparams, chem))
            else:
                setattr(self, f"{chem}_material_balance", ComplexChemMaterialBalance(self.mbparams, chem))

    def forward(self, data: dict[str, torch.Tensor]) -> mb_output:
        al_mat_bal = self.al_material_balance(data)
        as_mat_bal = self.as_material_balance(data)
        c_mat_bal = self.c_material_balance(data)
        ca_mat_bal = self.ca_material_balance(data)
        fe_mat_bal = self.fe_material_balance(data)
        k_mat_bal = self.k_material_balance(data)
        mg_mat_bal = self.mg_material_balance(data)
        mn_mat_bal = self.mn_material_balance(data)
        na_mat_bal = self.na_material_balance(data)
        p_mat_bal = self.p_material_balance(data)
        pb_mat_bal = self.pb_material_balance(data)
        si_mat_bal = self.si_material_balance(data)
        ti_mat_bal = self.ti_material_balance(data)
        zn_mat_bal = self.zn_material_balance(data)

        return {
            "al": al_mat_bal,
            "as": as_mat_bal,
            "c": c_mat_bal,
            "ca": ca_mat_bal,
            "fe": fe_mat_bal,
            "k": k_mat_bal,
            "mg": mg_mat_bal,
            "mn": mn_mat_bal,
            "na": na_mat_bal,
            "p": p_mat_bal,
            "pb": pb_mat_bal,
            "si": si_mat_bal,
            "ti": ti_mat_bal,
            "zn": zn_mat_bal,
        }
