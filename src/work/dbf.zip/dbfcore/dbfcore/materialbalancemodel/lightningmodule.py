from typing import Sequence

import lightning as L
import torch
from torch.nn.functional import mse_loss

from dbfcore.dataset.preprocessed_dataset.material_balance_coefs_preprocessing import (
    MATERIAL_BALANCE_COEFS_FEATURES,
)
from dbfcore.materialbalancemodel.datamodule import PandasToDictBatchDataset
from dbfcore.materialbalancemodel.model import MATERIAL_BALANCE_ELEMENTS, MaterialBalance, MBParams, mb_output

INDEXES = list(MATERIAL_BALANCE_COEFS_FEATURES)[1:]


def tensor_batch_to_dict_batch(
    tensor_batch: PandasToDictBatchDataset, keys: Sequence[str]
) -> dict[str, torch.Tensor]:
    return {cn: tensor_batch[:, idx] for idx, cn in enumerate(keys)}


class PLMaterialBalance(L.LightningModule):
    def __init__(self, mb_factors: dict[str, float], regularization_factors: dict[str, float]):
        super().__init__()
        self.mbparams = MBParams()
        self.model = MaterialBalance(self.mbparams)
        self.register_buffer("one", torch.tensor(1.0))
        self.one: torch.Tensor
        self.mb_factors = {
            "al": 1.0,
            "as": 1.0,
            "c": 1.0,
            "ca": 1.0,
            "fe": 1.0,
            "k": 1.0,
            "mg": 1.0,
            "mn": 1.0,
            "na": 1.0,
            "p": 1.0,
            "pb": 1.0,
            "si": 1.0,
            "ti": 1.0,
            "zn": 1.0,
            **mb_factors,
        }
        self.regularization_factors = {
            "qpu": 1.0,
            "charge": 1.0,
            "pig_iron": 1.0,
            "slag": 1.0,
            "bf_gas": 1.0,
            "dust": 1.0,
            **regularization_factors,
        }
        self.save_hyperparameters()

    def forward(self, data: dict[str, torch.Tensor]) -> mb_output:
        return self.model(data)

    def _common_step(self, batch: PandasToDictBatchDataset, stage: str):
        dict_batch = tensor_batch_to_dict_batch(batch, INDEXES)
        balances = self.forward(dict_batch)

        self.log_output_input_ratio(balances, stage)

        losses = [
            mse_loss(balances[element][0], balances[element][1]) * self.mb_factors[element]
            for element in MATERIAL_BALANCE_ELEMENTS
        ]

        for loss, element in zip(losses, MATERIAL_BALANCE_ELEMENTS):
            self.log(f"{stage}/loss/{element}_loss", loss)

        return sum(losses)

    def get_regularization_loss(self):
        qpu_regularization = (
            mse_loss(self.mbparams.qpu_weight_correction, self.one) * self.regularization_factors["qpu"]
        )
        self.log("regularization/qpu_regularization", qpu_regularization)
        charge_regularization = (
            mse_loss(self.mbparams.charge_weight_correction, self.one) * self.regularization_factors["charge"]
        )
        self.log("regularization/charge_regularization", charge_regularization)
        pi_regularization = (
            mse_loss(self.mbparams.pig_iron_weight_correction, self.one)
            * self.regularization_factors["pig_iron"]
        )
        self.log("regularization/pi_regularization", pi_regularization)
        slag_regularization = (
            mse_loss(self.mbparams.slag_weight_correction, self.one) * self.regularization_factors["slag"]
        )
        self.log("regularization/slag_regularization", slag_regularization)
        bfg_regularization = (
            mse_loss(self.mbparams.bf_gas_weight_correction, self.one) * self.regularization_factors["bf_gas"]
        )
        self.log("regularization/bf_gas_regularization", bfg_regularization)
        dust_regularization = (
            mse_loss(self.mbparams.dust_weight_correction, self.one) * self.regularization_factors["dust"]
        )
        self.log("regularization/dust_regularization", dust_regularization)

        regularizations = [
            qpu_regularization,
            charge_regularization,
            pi_regularization,
            slag_regularization,
            bfg_regularization,
            dust_regularization,
        ]

        return sum(regularizations)

    def training_step(self, batch: PandasToDictBatchDataset, batch_idx: int) -> torch.Tensor:
        sum_losses = self._common_step(batch, "train")
        sum_regularizations = self.get_regularization_loss()

        self.log("train/sum_losses", sum_losses)
        self.log("train/sum_regularizations", sum_regularizations)

        total_loss = sum_losses + sum_regularizations
        self.log("train/total_loss", total_loss)
        self.log_params()

        return total_loss  # type: ignore

    def validation_step(self, batch: PandasToDictBatchDataset, batch_idx: int):
        sum_losses = self._common_step(batch, "val")
        self.log("val/sum_losses", sum_losses)

    def configure_optimizers(self) -> torch.optim.SGD:
        return torch.optim.SGD(self.model.parameters(), lr=0.001)

    def log_params(self):
        self.log("param/qpu_weight", self.mbparams.qpu_weight_correction)
        self.log("param/charge_weight", self.mbparams.charge_weight_correction)
        self.log("param/pig_iron", self.mbparams.pig_iron_weight_correction)
        self.log("param/slag", self.mbparams.slag_weight_correction)
        self.log("param/bf_gas", self.mbparams.bf_gas_weight_correction)
        self.log("param/dust", self.mbparams.dust_weight_correction)

    def log_output_input_ratio(self, balances: mb_output, stage: str):
        # ked do modelu doplnim vsetky prvky tak sa vyuzije premenna `PIG_IRON_ELEMENTS` namiesto tuple prvkov
        for element in MATERIAL_BALANCE_ELEMENTS:
            ratio = balances[element][1] / balances[element][0]
            self.logger.experiment.add_histogram(f"{stage}/histogram/{element}_histogram", ratio)  # type: ignore
            self.log(f"{stage}/ratio/{element}_ratio_mean", ratio.mean())
