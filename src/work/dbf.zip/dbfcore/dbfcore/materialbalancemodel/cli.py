# main.py
from lightning.pytorch.cli import LightningCLI

from dbfcore.materialbalancemodel.datamodule import MBDataModule
from dbfcore.materialbalancemodel.lightningmodule import PLMaterialBalance


def main():
    LightningCLI(model_class=PLMaterialBalance, datamodule_class=MBDataModule)


if __name__ == "__main__":
    main()
