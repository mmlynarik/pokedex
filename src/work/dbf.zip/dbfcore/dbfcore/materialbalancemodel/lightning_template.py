import lightning as L
import torch
import torch.nn as nn


class MaterialBalanceInput:
    def __init__(self, data: torch.Tensor):
        self.data = data

    @property
    def burden_fe_content(self) -> torch.Tensor:
        return self.data[:, 0]

    @property
    def burden_weight(self) -> torch.Tensor:
        return self.data[:, 1]

    @property
    def pulv_coal_weight(self) -> torch.Tensor:
        return self.data[:, 2]


class MaterialBalanceParams(nn.Module):
    def __init__(self):
        self.burden_weight_correction = nn.Parameter(torch.Tensor(1.0), requires_grad=True)
        self.chem_correction = nn.Parameter(torch.Tensor(1.0), requires_grad=True)


class MaterialBalance(nn.Module):
    def __init__(self, mbparams: MaterialBalanceParams):
        self.mbparams = mbparams
        self.balanced_chems = (
            ("Fe", input_fe, output_fe),
            ("Si", input_si, output_si),
            ("Mn", input_si, output_si),
        )

    def forward(self, data: torch.Tensor):
        mbinput = MaterialBalanceInput(data)
        for chem, input_fn, output_fn in self.balanced_chems:
            input_weight = input_fn(mbinput, self.mbparams)
            output_weight = output_fn(mbinput, self.mbparams)

        return ((input_weight, output_weight), (input_weight, output_weight))


class PLMaterialBalance(L.LightningModule):
    def __init__(self):
        super().__init__()
        self.mbparams = MaterialBalanceParams()
        self.model = MaterialBalance(self.mbparams)

    def forward(self, data):
        return self.model(data)

    def training_step(self, batch, batch_idx):
        inputs, outputs = self.forward(batch)

        losses = []
        for input, output in zip(inputs, outputs):
            loss = torch.nn.functional.mse_loss(input, output)
            losses.append(loss)

        regularization_1 = (self.mbparams.burden_weight_correction - 1).clamp_min(0.0)

        return sum(losses) + regularization_1

    def configure_optimizers(self):
        return torch.optim.SGD(self.model.parameters(), lr=0.1)


def input_fe(data: MaterialBalanceInput, context: MaterialBalanceParams):
    burden_input = data.burden_fe_content * data.burden_weight * context.burden_weight_correction
    pulv_coal_input = data.pulv_coal_weight * context

    return burden_input, pulv_coal_input


def output_fe(data: MaterialBalanceInput, context: MaterialBalanceParams):
    pass


def input_si(data: MaterialBalanceInput, context: MaterialBalanceParams):
    pass


def output_si(data: MaterialBalanceInput, context: MaterialBalanceParams):
    pass


def input_mn(data: MaterialBalanceInput, context: MaterialBalanceParams):
    pass


def output_mn(data: MaterialBalanceInput, context: MaterialBalanceParams):
    pass
