import lightning as L
import pandas as pd
import torch
from torch.utils.data import DataLoader

from dbfcore.dataset.dataset_reader import load_dataset_as_dataframe
from dbfcore.settings import PREPROCESSED_DATASETS_PATH


class PandasToDictBatchDataset(torch.utils.data.Dataset):
    def __init__(self, df_data: pd.DataFrame):
        self.data = torch.tensor(df_data.values)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx, :]


class MBDataModule(L.LightningDataModule):
    def __init__(
        self,
        dataset_path: str = f"{PREPROCESSED_DATASETS_PATH}/material-balance-coefficients",
        window_size: str = "30D",
        train_size: float = 0.75,
        batch_size: int = 32,
    ):
        super().__init__()
        self.dataset_path = dataset_path
        self.window_size = pd.Timedelta(window_size)
        self.train_size = train_size
        self.batch_size = batch_size
        self.train_dataset: PandasToDictBatchDataset
        self.val_dataset: PandasToDictBatchDataset

    def setup(self, stage: str):
        data = load_dataset_as_dataframe(path=self.dataset_path)

        train_start = data.index.min()
        val_end = data.index.max()

        train_end = train_start + ((val_end - train_start) * self.train_size)
        val_start = train_end + self.window_size

        self.train_dataset = PandasToDictBatchDataset(data[train_start:train_end])
        self.val_dataset = PandasToDictBatchDataset(data[val_start:val_end])

        print("Train dataset length: ", len(self.train_dataset))
        print("Val dataset length: ", len(self.val_dataset))

    def train_dataloader(self) -> DataLoader:
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True)

    def val_dataloader(self) -> DataLoader:
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=False)
