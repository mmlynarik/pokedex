import pandas as pd

from dbfcore.predictionmodel.metrics.hitconfusionmatrix import TargetHitConfusionMatrixMetric
from dbfcore.predictionmodel.metrics.metricprotocol import Metric
from dbfcore.predictionmodel.metrics.predictiontrendmetric import PredictionTrendMetric
from dbfcore.predictionmodel.metrics.simpleorabsoluteerror import SimpleOrAbsoluteErrorMetric
from dbfcore.predictionmodel.metrics.zeroforecasttrendmetric import ZeroForecastTrendMetric


def load_metrics_from_dict(metric_definitions: dict) -> list[Metric]:
    metrics: list[Metric] = []

    for metric_definition in metric_definitions:
        metric_name = metric_definition["name"]

        if metric_name == "SimpleOrAbsoluteErrorMetric":
            metrics.append(
                SimpleOrAbsoluteErrorMetric(
                    signal_name=metric_definition["signal_name"],
                    forecast_window=pd.Timedelta(metric_definition["forecast_window"]),
                    tolerance=pd.Timedelta(metric_definition["tolerance"]),
                    metric_type=metric_definition["metric_type"],
                )
            )
        elif metric_name == "TargetHitConfusionMatrixMetric":
            metrics.append(
                TargetHitConfusionMatrixMetric(
                    signal_name=metric_definition["signal_name"],
                    forecast_window=pd.Timedelta(metric_definition["forecast_window"]),
                    tolerance=pd.Timedelta(metric_definition["tolerance"]),
                    furnace_id=metric_definition["furnace_id"],
                    metric_type=metric_definition["metric_type"],
                    category_tolerance=metric_definition["category_tolerance"],
                )
            )
        elif metric_name == "ZeroForecastTrendMetric":
            metrics.append(
                ZeroForecastTrendMetric(
                    signal_name=metric_definition["signal_name"],
                    forecast_window=pd.Timedelta(metric_definition["forecast_window"]),
                    tolerance=pd.Timedelta(metric_definition["tolerance"]),
                    metric_type=metric_definition["metric_type"],
                    category_boundary_1=metric_definition["category_boundary_1"],
                    category_boundary_2=metric_definition["category_boundary_2"],
                )
            )
        elif metric_name == "PredictionTrendMetric":
            metrics.append(
                PredictionTrendMetric(
                    signal_name=metric_definition["signal_name"],
                    tolerance=pd.Timedelta(metric_definition["tolerance"]),
                    metric_type=metric_definition["metric_type"],
                    category_boundary_1=metric_definition["category_boundary_1"],
                    category_boundary_2=metric_definition["category_boundary_2"],
                )
            )
    return metrics
