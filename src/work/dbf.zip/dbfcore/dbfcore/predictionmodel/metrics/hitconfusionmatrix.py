from functools import reduce
from itertools import product
from typing import Literal, Sequence

import numpy as np
import pandas as pd

from dbfcore.dataset.signals import SIGNAL_TO_SIGNAL_GROUP_MAP
from dbfcore.predictionmodel.metrics.common import (
    filter_out_targets_for_furnace,
    get_nearest_real_value_for_prediction,
    get_targets_for_calc_times,
)
from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult, DataDefinition, SignalGroupData


def make_hit_confusion_matrix_categorization(
    eval_array: np.ndarray, target_array: np.ndarray, tolerance: float
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    under = eval_array < target_array - tolerance
    over = eval_array > target_array + tolerance
    middle = ~(over | under)

    return over, middle, under


def generate_categories(
    category_labels: Sequence[Sequence[str]], category_evaluations: Sequence[Sequence[np.ndarray]]
) -> np.ndarray:
    labels_combs = product(*category_labels)
    eval_combs = product(*category_evaluations)
    labels = [first_label + "_" + second_label for first_label, second_label, in labels_combs]
    evals = [(first_eval & second_eval) for first_eval, second_eval, in eval_combs]
    categories = [np.where(eval, label, "") for eval, label in zip(evals, labels)]

    return reduce(lambda x, y: np.char.add(x, y), categories)


def get_hit_confusion_matrix_categories(
    calc_times: np.ndarray,
    forecasts: np.ndarray,
    real_values: np.ndarray,
    targets: np.ndarray,
    tolerance: float,
) -> pd.Series:
    f_over, f_target, f_under = make_hit_confusion_matrix_categorization(forecasts, targets, tolerance)
    r_over, r_target, r_under = make_hit_confusion_matrix_categorization(real_values, targets, tolerance)

    forecast_labels = ["forecast_over", "forecast_target", "forecast_under"]
    real_labels = ["real_over", "real_target", "real_under"]
    forecast_evals = [f_over, f_target, f_under]
    real_evals = [r_over, r_target, r_under]

    categories = generate_categories([forecast_labels, real_labels], [forecast_evals, real_evals])

    return pd.Series(index=calc_times, data=categories)


class TargetHitConfusionMatrixMetric:
    def __init__(
        self,
        signal_name: str,
        forecast_window: pd.Timedelta,
        tolerance: pd.Timedelta,
        furnace_id: int,
        metric_type: Literal["silicon", "temperature"],
        category_tolerance: float,
    ):
        self.signal_name = signal_name
        self.forecast_window = forecast_window
        self.tolerance = tolerance
        self.furnace_id = furnace_id
        self.metric_type = metric_type
        self.category_tolerance = category_tolerance
        self.metric_name = "ConfMtrx"
        self.signal_group = SIGNAL_TO_SIGNAL_GROUP_MAP[self.signal_name]

    def get_data_definition(self, calc_times: Sequence[pd.Timestamp]) -> DataDefinition:
        buffer = 2 * self.forecast_window
        return {self.signal_group: (min(calc_times), max(calc_times) + buffer)}

    def calculate_metric(
        self,
        calc_times: Sequence[pd.Timestamp],
        results: Sequence[BlastFurnaceModelResult],
        real_data: SignalGroupData,
        targets: Sequence[list[dict[str, pd.Timestamp | float]]],
    ) -> pd.DataFrame:
        signal_df = real_data[self.signal_group][[self.signal_name]]
        real_values = get_nearest_real_value_for_prediction(
            calc_times, signal_df, self.forecast_window, self.tolerance
        )
        col_name = f"{self.signal_name}_{self.metric_name}_{int(self.forecast_window.total_seconds() / 60)}"
        if real_values.empty or real_values.isnull().all().item():
            return pd.DataFrame(columns=[col_name])

        furnace_targets = filter_out_targets_for_furnace(targets, self.furnace_id)
        targets_arr = get_targets_for_calc_times(furnace_targets, calc_times, self.metric_type)
        forecasts_arr = np.array([r.get_expected_value(self.forecast_window) for r in results])
        real_values_arr = real_values[self.signal_name].values
        calc_times_arr = np.array(calc_times)

        categories = get_hit_confusion_matrix_categories(
            calc_times_arr[~np.isnan(real_values_arr)],
            forecasts_arr[~np.isnan(real_values_arr)],
            real_values_arr[~np.isnan(real_values_arr)],
            targets_arr[~np.isnan(real_values_arr)],
            self.category_tolerance,
        )

        return pd.DataFrame(index=calc_times, data=categories, columns=[col_name])
