from typing import Protocol, Sequence

import pandas as pd

from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult, DataDefinition, SignalGroupData


class Metric(Protocol):
    signal_name: str
    forecast_window: pd.Timedelta
    tolerance: pd.Timedelta

    def get_data_definition(self, calc_times: Sequence[pd.Timestamp]) -> DataDefinition: ...

    def calculate_metric(
        self,
        calc_times: Sequence[pd.Timestamp],
        results: Sequence[BlastFurnaceModelResult],
        real_data: SignalGroupData,
        targets: Sequence[list[dict[str, pd.Timestamp | float]]],
    ) -> pd.DataFrame:
        """
        Format of the output DataFrame should be as following:
            * `calc_times` serve as indices
            * values represent metric results
            * the number of columns varies depending on the metric
            * column names are defined by the metric

            * example:
            | Calc_time (index)         | Error_name |
            |:--------------------------|-----------:|
            | 2024-11-11 01:00:00+00:00 | 0.5        |
            | 2024-11-11 01:01:00+00:00 | 0.25       |
        """
        ...
