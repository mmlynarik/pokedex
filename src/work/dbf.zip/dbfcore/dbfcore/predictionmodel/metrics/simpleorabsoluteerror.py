from typing import Literal, Sequence

import pandas as pd
import torch

from dbfcore.dataset.signals import SIGNAL_TO_SIGNAL_GROUP_MAP
from dbfcore.predictionmodel.metrics.common import get_nearest_real_value_for_prediction
from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult, DataDefinition, SignalGroupData


class SimpleOrAbsoluteErrorMetric:
    def __init__(
        self,
        signal_name: str,
        forecast_window: pd.Timedelta,
        tolerance: pd.Timedelta,
        metric_type: Literal["simple", "absolute"],
        verbose: bool = False,
    ):
        self.signal_name = signal_name
        self.forecast_window = forecast_window
        self.tolerance = tolerance
        self.metric_type = metric_type
        self.metric_name = "AbsErr" if metric_type == "absolute" else "Err"
        self.verbose = verbose
        self.signal_group = SIGNAL_TO_SIGNAL_GROUP_MAP[self.signal_name]

    def get_data_definition(self, calc_times: Sequence[pd.Timestamp]) -> DataDefinition:
        buffer = 2 * self.forecast_window
        return {self.signal_group: (min(calc_times), max(calc_times) + buffer)}

    def calculate_metric_from_excel_predictions(
        self,
        calc_times: Sequence[pd.Timestamp],
        forecasts: list[float],
        target_data: SignalGroupData,
    ) -> pd.DataFrame:
        signal_df = target_data[self.signal_group][[self.signal_name]]
        real_values = get_nearest_real_value_for_prediction(
            calc_times, signal_df, self.forecast_window, self.tolerance
        )
        col_name = f"{self.signal_name}_{self.metric_name}_{int(self.forecast_window.total_seconds() / 60)}"
        if real_values.empty or real_values.isnull().all().item():
            return pd.DataFrame(columns=[col_name])

        real_values_tensor = torch.Tensor(real_values[self.signal_name].to_list())
        forecasts_tensor = torch.Tensor(forecasts)
        errors = real_values_tensor - forecasts_tensor
        if self.metric_type == "absolute":
            errors = errors.abs()
        data = (
            {"real": real_values_tensor, "forecast": forecasts_tensor, "error": errors}
            if self.verbose
            else {col_name: errors}
        )
        return pd.DataFrame(index=calc_times, data=data)

    def calculate_metric(
        self,
        calc_times: Sequence[pd.Timestamp],
        results: Sequence[BlastFurnaceModelResult],
        real_data: SignalGroupData,
        targets: Sequence[list[dict[str, pd.Timestamp | float]]],
    ) -> pd.DataFrame:
        signal_df = real_data[self.signal_group][[self.signal_name]]
        real_values = get_nearest_real_value_for_prediction(
            calc_times, signal_df, self.forecast_window, self.tolerance
        )
        col_name = f"{self.signal_name}_{self.metric_name}_{int(self.forecast_window.total_seconds() / 60)}"
        if real_values.empty or real_values.isnull().all().item():
            return pd.DataFrame(columns=[col_name])

        forecasts_tensor = torch.Tensor([r.get_expected_value(self.forecast_window) for r in results])
        real_values_tensor = torch.Tensor(real_values[self.signal_name].to_list())

        errors = real_values_tensor - forecasts_tensor
        if self.metric_type == "absolute":
            errors = errors.abs()
        data = (
            {"real": real_values_tensor, "forecast": forecasts_tensor, "error": errors}
            if self.verbose
            else {col_name: errors}
        )
        return pd.DataFrame(index=calc_times, data=data)
