from typing import Sequence

import numpy as np
import pandas as pd


def df_with_calc_times_as_index_plus_forecast_window(
    calc_times: Sequence[pd.Timestamp], forecast_window: pd.Timedelta
) -> pd.DataFrame:
    return (
        pd.DataFrame(pd.Series(calc_times) + forecast_window, columns=["calc_time"])
        .set_index("calc_time")
        .sort_index()
    )


def get_accurate_real_value_for_prediction(
    calc_times: Sequence[pd.Timestamp],
    signal_df: pd.DataFrame,
    forecast_window: pd.Timedelta,
    tolerance: pd.Timedelta,
) -> pd.DataFrame:
    forecast_times_df = df_with_calc_times_as_index_plus_forecast_window(calc_times, forecast_window)
    signal_df.index = signal_df.index.ceil(tolerance)

    return pd.concat([forecast_times_df, signal_df], axis=1)


def get_nearest_real_value_for_prediction(
    calc_times: Sequence[pd.Timestamp],
    signal_df: pd.DataFrame,
    forecast_window: pd.Timedelta,
    tolerance: pd.Timedelta,
) -> pd.DataFrame:
    forecast_times_df = df_with_calc_times_as_index_plus_forecast_window(calc_times, forecast_window)

    return pd.merge_asof(
        forecast_times_df,
        signal_df,
        right_index=True,
        left_index=True,
        tolerance=tolerance,
        direction="nearest",
    )


def filter_out_targets_for_furnace(
    all_furnaces_targets: Sequence[list[dict[str, float | pd.Timestamp]]], furnace_id: int
) -> list:
    targets = []
    for furnace_targets in all_furnaces_targets:
        if furnace_targets[0]["furnace_id"] == furnace_id:
            targets += furnace_targets

    return targets


def get_targets_for_calc_times(
    targets: Sequence[dict[str, pd.Timedelta | float]],
    calc_times: Sequence[pd.Timestamp],
    target_name: str,
) -> np.ndarray:
    return pd.merge_asof(pd.Series(calc_times, name="valid_asof"), pd.DataFrame(targets))[target_name].values


def filter_array_by_mask(array: np.ndarray, mask: np.ndarray) -> np.ndarray:
    return array[mask]


def categorize_sequence_according_to_limits(
    sequence: Sequence | np.ndarray, limits: Sequence | np.ndarray, categories: Sequence | np.ndarray
) -> list:
    digitized_sequence = np.digitize(sequence, limits)

    return [categories[val] for val in digitized_sequence]
