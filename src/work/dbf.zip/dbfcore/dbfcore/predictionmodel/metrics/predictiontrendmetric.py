from typing import Literal, Sequence

import numpy as np
import pandas as pd

from dbfcore.dataset.signals import SIGNAL_TO_SIGNAL_GROUP_MAP
from dbfcore.predictionmodel.metrics.common import (
    categorize_sequence_according_to_limits,
    filter_array_by_mask,
    get_accurate_real_value_for_prediction,
)
from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult, DataDefinition, SignalGroupData


class PredictionTrendMetric:
    def __init__(
        self,
        signal_name: str,
        tolerance: pd.Timedelta,
        metric_type: Literal["trend_hist", "conf_matrix"],
        category_boundary_1: float,
        category_boundary_2: float,
    ):
        self.signal_name = signal_name
        self.forecast_window = pd.Timedelta(0)
        self.max_forecast_window = pd.Timedelta("4h")
        self.tolerance = tolerance
        self.metric_type = metric_type
        self.category_boundary_1 = category_boundary_1
        self.category_boundary_2 = category_boundary_2
        self.metric_name = "PredTrendHist" if metric_type == "trend_hist" else "PredTrendMatrix"
        self.signal_group = SIGNAL_TO_SIGNAL_GROUP_MAP[self.signal_name]

    def get_data_definition(self, calc_times: Sequence[pd.Timestamp]) -> DataDefinition:
        buffer = 2 * self.forecast_window
        return {self.signal_group: (min(calc_times), max(calc_times) + buffer)}

    def calculate_metric(
        self,
        calc_times: Sequence[pd.Timestamp],
        results: Sequence[BlastFurnaceModelResult],
        real_data: SignalGroupData,
        targets: Sequence[list[dict[str, pd.Timestamp | float]]],
    ) -> pd.DataFrame:
        signal_df = real_data[self.signal_group][[self.signal_name]]
        real_values = get_accurate_real_value_for_prediction(
            calc_times, signal_df, self.forecast_window, self.tolerance
        )
        col_name = f"{self.signal_name}_{self.metric_name}"
        if real_values.empty or real_values.isnull().all().item():
            return pd.DataFrame(columns=[col_name])

        notna_mask = real_values[self.signal_name].notna().values

        calc_times_arr = filter_array_by_mask(np.array(calc_times), notna_mask)
        results_arr = filter_array_by_mask(np.array(results), notna_mask)
        real_vals_arr = filter_array_by_mask(real_values[self.signal_name].values, notna_mask)

        forecast_windows = np.diff(calc_times_arr)
        fw_clipped = forecast_windows.clip(self.forecast_window, self.max_forecast_window)
        forecasts_0 = np.array([r.get_expected_value(self.forecast_window) for r in results_arr[:-1]])
        forecasts_fw = np.array([r.get_expected_value(fw) for r, fw in zip(results_arr[:-1], fw_clipped)])

        forecasts_diff = forecasts_fw - forecasts_0
        real_vals_diff = np.diff(real_vals_arr)

        validity_mask = forecast_windows <= self.max_forecast_window
        valid_index = filter_array_by_mask(calc_times_arr[:-1], validity_mask)

        if self.metric_type == "trend_hist":
            trends = forecasts_diff - real_vals_diff
            fw_hours = forecast_windows / pd.Timedelta(hours=1)  # forecast windows as part of hour
            trends_by_fw = trends / fw_hours

            valid_data = filter_array_by_mask(trends_by_fw, validity_mask)

        elif self.metric_type == "conf_matrix":
            limits = [
                -self.category_boundary_2,
                -self.category_boundary_1,
                self.category_boundary_1,
                self.category_boundary_2,
            ]
            categories = [-2, -1, 0, 1, 2]

            forecasts_categorized = categorize_sequence_according_to_limits(
                forecasts_diff, limits, categories
            )
            rv_categorized = categorize_sequence_according_to_limits(real_vals_diff, limits, categories)
            fcast_rv_conf_categories = [f"{f}_{r}" for f, r in zip(forecasts_categorized, rv_categorized)]

            valid_data = filter_array_by_mask(np.array(fcast_rv_conf_categories), validity_mask)

        return pd.DataFrame(index=valid_index, data=valid_data, columns=[col_name])
