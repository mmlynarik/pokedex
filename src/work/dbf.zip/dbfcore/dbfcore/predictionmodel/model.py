import traceback
from functools import partial
from typing import Optional

import lightning as L
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from torch.utils.tensorboard.writer import SummaryWriter

from dbfcore.model.lipschitz import LipMLP

# TODO move to common
from dbfcore.model.vicregtraining import ThreeLayerPerceptron


class FourLayerPerceptron(nn.Module):
    """
    A simple Four-Layer Perceptron (MLP) module in PyTorch.

    Args:
    in_features (int): Number of input features.
    hidden_features_1 (int, optional): First hidden layer size.
    hidden_features_2 (int, optional): Second hidden layer size.
    hidden_features_3 (int, optional): Third hidden layer size.
    out_features (int, optional): Output size.
    """

    def __init__(
        self,
        in_features: int,
        hidden_features_1: int,
        hidden_features_2: int,
        hidden_features_3: int,
        out_features: int,
    ):
        super().__init__()

        self.model = nn.Sequential(
            nn.Linear(in_features, hidden_features_1),
            nn.LayerNorm(hidden_features_1, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features_1, hidden_features_2),
            nn.LayerNorm(hidden_features_2, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features_2, hidden_features_3),
            nn.LayerNorm(hidden_features_3, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features_3, out_features),
        )

    def forward(self, x):
        return self.model(x)


class MioNet4BF(nn.Module):
    def __init__(
        self,
        bf_state_rep_size: int,
        bf_actions_rep_size: int,
        hidden_sizes: tuple[int, int, int],
        rep_size: int,
        use_last_value: bool = False,
    ):
        super().__init__()
        self.use_last_value = use_last_value

        self.bf_state_net = LipMLP((bf_state_rep_size, *hidden_sizes, rep_size))
        self.bf_actions_net = LipMLP((bf_actions_rep_size, *hidden_sizes, rep_size))
        self.time_net = LipMLP((1, *hidden_sizes, rep_size))
        self.cdf_net = LipMLP((1, *hidden_sizes, rep_size))
        if self.use_last_value:
            self.last_value_net = LipMLP((2, *hidden_sizes, rep_size))

        self.bias = nn.Parameter(torch.zeros((1), requires_grad=True))

    def get_last_values_rep(
        self, template_rep: torch.Tensor, last_values: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        if self.use_last_value and (last_values is not None):
            return self.last_value_net(last_values)
        else:
            return torch.ones_like(template_rep)

    # Inputs are with shape B x D
    def forward(
        self,
        bf_states: torch.Tensor,
        bf_actions: torch.Tensor,
        times: torch.Tensor,
        cdfs: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        state_rep = self.bf_state_net(bf_states)
        actions_rep = self.bf_actions_net(bf_actions)
        time_rep = self.time_net(times)
        cdfs_rep = self.cdf_net(cdfs)
        last_value_rep = self.get_last_values_rep(state_rep, last_values)

        dotproduct = state_rep * actions_rep * time_rep * cdfs_rep * last_value_rep
        return torch.nn.functional.sigmoid(dotproduct.sum(dim=1) + self.bias)

    # Inputs are with shape B x D
    def calculate_result_representation(
        self, bf_states: torch.Tensor, bf_actions: torch.Tensor, last_values: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        state_rep = self.bf_state_net(bf_states)
        actions_rep = self.bf_actions_net(bf_actions)
        last_value_rep = self.get_last_values_rep(state_rep, last_values)

        return state_rep * actions_rep * last_value_rep

    # Inputs are with shape B x D
    def calculate_one_time_different_action_representation(
        self,
        bf_states: torch.Tensor,
        times: torch.Tensor,
        bf_actions_1: torch.Tensor,
        bf_actions_2: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        state_rep = self.bf_state_net(bf_states)
        time_rep = self.time_net(times)

        actions_rep_1 = self.bf_actions_net(bf_actions_1)
        actions_rep_2 = self.bf_actions_net(bf_actions_2)
        last_value_rep = self.get_last_values_rep(state_rep, last_values)

        halfrep = state_rep * time_rep * last_value_rep
        return halfrep * actions_rep_1, halfrep * actions_rep_2

    def calculate_from_result_representation(
        self, result_representation: torch.Tensor, times: torch.Tensor, cdfs: torch.Tensor
    ) -> torch.Tensor:
        time_rep = self.time_net(times)
        cdfs_rep = self.cdf_net(cdfs)
        dotproduct = result_representation * time_rep * cdfs_rep
        return torch.nn.functional.sigmoid(dotproduct.sum(dim=1) + self.bias)

    def get_lipschitz_loss(self):
        constant_parts_loss = (
            self.bf_state_net.get_lipschitz_loss()
            + self.bf_actions_net.get_lipschitz_loss()
            + self.time_net.get_lipschitz_loss()
            + self.cdf_net.get_lipschitz_loss()
        )
        if self.use_last_value:
            return constant_parts_loss + self.last_value_net.get_lipschitz_loss()
        return constant_parts_loss


class TwoOutputDeepONet(nn.Module):
    def __init__(self, latent_rep_size: int, hidden_sizes: tuple[int, int], rep_size: int):
        super().__init__()
        self.branch_net = ThreeLayerPerceptron(latent_rep_size, hidden_sizes[0], hidden_sizes[1], rep_size)

        self.trunk_net_1 = ThreeLayerPerceptron(1, hidden_sizes[0], hidden_sizes[1], rep_size)
        self.bias_1 = nn.Parameter(torch.zeros((1), requires_grad=True))

        self.trunk_net_2 = ThreeLayerPerceptron(1, hidden_sizes[0], hidden_sizes[1], rep_size)
        self.bias_2 = nn.Parameter(torch.zeros((1), requires_grad=True))

        self.latent_rep_size = latent_rep_size

    # latent rep is Batch x Latent rep size
    # eval points is Batch x Points
    # return tensor is Batch x Points
    def forward(self, latent_rep, eval_points):
        branch = self.branch_net(latent_rep)

        trunk_1 = self.trunk_net_1(eval_points.unsqueeze(2))
        trunk_2 = self.trunk_net_2(eval_points.unsqueeze(2))

        branch_unsqueezed = branch.unsqueeze(1)

        dotproduct_1 = branch_unsqueezed * trunk_1
        dotproduct_2 = branch_unsqueezed * trunk_2

        result_1 = dotproduct_1.sum(dim=2) + self.bias_1
        result_2 = dotproduct_2.sum(dim=2) + self.bias_2

        return result_1, result_2

    @property
    def latent_dim(self):
        return self.latent_rep_size


def learning_rate_lambda(warmup_steps, step):
    if step < warmup_steps:
        return float(step) / float(max(1, warmup_steps))
    else:
        return 1.0


def linear_warmup_decay(warmup_steps):
    return partial(learning_rate_lambda, warmup_steps)


class SimpleNormalizer(nn.Module):
    def __init__(self, mean: float, std: float):
        super().__init__()

        if std == 0:
            raise ValueError("Standard deviation value must not be 0.")

        self.register_buffer("mean", torch.tensor(mean))
        self.register_buffer("std", torch.tensor(std))

    def forward(self, x):
        return (x - self.mean) / self.std

    def denormalize(self, x):
        return (x * self.std) + self.mean


def get_value_denormalizer(min_val: float, max_val: float):
    val_range = max_val - min_val

    def value_denormalizer(x):
        return (x * val_range) + min_val

    return value_denormalizer


# def get_percentiles_generator(alpha, beta, loc, scale):
#     beta_dist = torch.distributions.beta.Beta(alpha, beta)

#     def generate(count, device):
#         half_count = count // 2
#         remaining_count = count - half_count
#         torch_uniform_samples = torch.rand((remaining_count, 1))
#         torch_samples = (beta_dist.sample((half_count, 1)) * scale) + loc
#         return torch.cat([torch_samples, torch_uniform_samples], dim=0).clamp(0.0, 1.0).to(device)

#     return generate


def get_real_histogram(all_values, value_resolution):
    bucket_idxs = torch.bucketize(
        all_values, torch.linspace(0, 1, value_resolution, device=all_values.device)
    )
    repeated_idxs = bucket_idxs.unsqueeze(0).repeat(value_resolution - 1, 1, 1)
    tested_idxs = torch.arange(1, value_resolution, device=all_values.device).unsqueeze(1).unsqueeze(2)
    return (repeated_idxs == tested_idxs).sum(dim=1).float()


def get_calculated_histogram(model, masked_state, masked_action, value_resolution, time_resolution):
    representation = model.calculate_representation(masked_state, masked_action)
    results = model.get_result_grid(representation, value_resolution, time_resolution)
    calc_hist = results[2][:, 1:, :] - results[2][:, 0:-1, :]
    return calc_hist.transpose(1, 2)


def smooth_out_histogram(hist, smoothing_factor):
    kernel = torch.ones((1, 1, smoothing_factor), device=hist.device)
    padding = smoothing_factor // 2
    return torch.nn.functional.conv1d(hist.unsqueeze(0), kernel, padding=padding)


def normalize_histogram(hist):
    return hist / hist.sum()


def kldiv(data_hist, model_hist):
    data_zero_addition = (data_hist == 0.0).float()
    epsilon = 0.000001
    normalized_non_zero_model_hist = normalize_histogram(model_hist + epsilon)

    return (
        data_hist * (torch.log(data_hist + data_zero_addition) - torch.log(normalized_non_zero_model_hist))
    ).sum()


# cdfs shape   ITEM COUNT X CDF RESOLUTION
# #####
# output shape ITEM COUNT X CDF RESOLUTION - 1
def cdf_to_pdf(cdfs):
    return cdfs[:, 1:] - cdfs[:, 0:-1]


# value_grid shape CDF RESOLUTION
#  #####
# return shape     CDF RESOLUTION - 1
def get_pdf_values(value_grid):
    return (value_grid[1:] + value_grid[0:-1]) / 2


# pdfs shape       ITEM COUNT x PDF RESOLUTION
# pdf_values shape PDF RESOLUTION
# #######
# return shape     PDF RESOLUTION
def pdf_to_expected_value(pdfs, pdf_values):
    return (pdfs * pdf_values.unsqueeze(0)).sum(dim=1)


# pdfs shape            ITEM COUNT x PDF RESOLUTION
# pdf_values shape      PDF RESOLUTION
# expected_values shape PDF RESOLUTION
# #######
# return shape          PDF RESOLUTION
def pdf_to_variance(pdfs, pdf_values, expected_values):
    pdf_resolution = pdf_values.size(0)
    return (
        (pdf_values.unsqueeze(0) - expected_values.unsqueeze(1).repeat(1, pdf_resolution)).pow(2.0) * pdfs
    ).sum(dim=1)


# representations shape BATCH SIZE X INTERNAL REP SIZE
# values shape          BATCH SIZE X VAL COUNT
# times shape           BATCH SIZE X VAL COUNT
# bool_mask shape       BATCH SIZE X VAL COUNT
# ######
# return shapes         ITEM COUNT x INTERNAL REP SIZE, ITEM COUNT, ITEM COUNT
def get_measured_values_data(representations, values, times, bool_mask):
    batch_size = representations.size(0)
    batch_indices = torch.arange(0, batch_size, device=representations.device).reshape(-1, 1)

    flatmask = bool_mask.reshape(-1)

    rep_selector = (bool_mask * batch_indices).reshape(-1)[flatmask]

    selected_representation = representations[rep_selector]
    selected_values = values.reshape(-1)[flatmask]
    selected_times = times.reshape(-1)[flatmask]

    return selected_representation, selected_times, selected_values


class PredictionModel(L.LightningModule):
    def __init__(
        self,
        bf_state_size: int,
        bf_action_size: int,
        hidden_size: tuple[int, int, int],
        output_rep_size: int,
        max_time_sec: int,
        cdf_loss_weight: float,
        possibility_loss_weight: float,
        calibration_loss_weight: float,
        mse_loss_weight: float,
        focal_loss_weight: float,
        lip_loss_weight: float,
        # full_length_epochs: int,
        log_images_every_n_steps: int,
        warmup_steps: int,
        # percentiles_count: int,
        value_resolution: int,
        val_range: tuple[float, float] = (0.0, 2.0),
        gamma: float = 5.0,
        use_last_value: bool = False,
    ):
        super().__init__()

        self.predictor = MioNet4BF(
            bf_state_size, bf_action_size, hidden_size, output_rep_size, use_last_value
        )
        self.max_time_sec = max_time_sec
        self.time_normalizer = SimpleNormalizer(
            max_time_sec / 2.0,
            torch.linspace(0, max_time_sec, (max_time_sec // 60) - 1).std().item(),
        )
        self.cdf_normalizer = SimpleNormalizer(0.5, 0.2887)
        self.cdf_loss_weight = cdf_loss_weight
        self.possibility_loss_weight = possibility_loss_weight
        self.focal_loss_weight = focal_loss_weight
        self.gamma = gamma
        self.mse_loss_weight = mse_loss_weight
        self.calibration_loss_weight = calibration_loss_weight
        self.lip_loss_weight = lip_loss_weight
        self.log_images_every_n_steps = log_images_every_n_steps
        # self.full_length_epochs = full_length_epochs
        self.warmup_steps = warmup_steps
        # self.percentiles_count = percentiles_count
        self.value_resolution = value_resolution
        self.register_buffer("cdf_grid", torch.linspace(0, 1, self.value_resolution))
        self.cdf_grid: torch.Tensor

        self.register_buffer("pdf_values", get_pdf_values(self.cdf_grid))
        self.pdf_values: torch.Tensor

        self.value_denormalizer = get_value_denormalizer(*val_range)
        # models fitted to train dataset TODO this should not be here should be generated in dataset
        # self.percentiles_generator = get_percentiles_generator(
        #     6.480292851639513, 33.64794610631512, -0.017716648172476486, 2.0012212817139656
        # )
        # self.gamma = gamma

        percentile_values = [0.05, 0.15, 0.25, 0.35, 0.45, 0.5, 0.55, 0.65, 0.75, 0.85, 0.95]
        self.register_buffer("tested_percentiles", torch.Tensor(percentile_values).reshape(-1, 1))
        self.tested_percentiles: torch.Tensor
        self.percentiles_count = len(percentile_values)
        # self.approx_metric_names = [f"approx_percentile_{x:.2}" for x in self.tested_percentiles]
        self.real_metric_names = [f"real_percentile_{x:.2}" for x in percentile_values]

        self.save_hyperparameters()

    def forward(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        eval_times: torch.Tensor,
        eval_cdfs: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        eval_times_count = eval_times.size(1)

        results = self.predictor(
            masked_state.repeat_interleave(eval_times_count, 0),
            masked_action.repeat_interleave(eval_times_count, 0),
            self.time_normalizer(eval_times).reshape(-1, 1),
            self.cdf_normalizer(eval_cdfs).reshape(-1, 1),
            None if last_values is None else last_values.repeat_interleave(eval_times_count, 0),
        )

        return results.reshape(-1, eval_times_count)

    # Input shapes:
    # representation ITEM COUNT X INTERNAL REP SIZE
    # eval_times     ITEM COUNT X 1
    # eval_cdfs      ITEM COUNT X 1
    # #####
    # Return shape   ITEM COUNT
    def forward_from_representation(
        self,
        representation: torch.Tensor,
        eval_times: torch.Tensor,
        eval_cdfs: torch.Tensor,
    ) -> torch.Tensor:
        return self.predictor.calculate_from_result_representation(
            representation,
            self.time_normalizer(eval_times),
            self.cdf_normalizer(eval_cdfs),
        )

    def calculate_representation(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return self.predictor.calculate_result_representation(masked_state, masked_action, last_values)

    # Input shapes:
    # result_representation  ITEM COUNT X INTERNAL REP SIZE
    # #####
    # Return shape           ITEM COUNT
    def get_expected_values(
        self,
        result_representation: torch.Tensor,
        offset_sec: float,
        value_resolution: int = 51,  # experimentally set up
    ):
        representations = result_representation.repeat_interleave(value_resolution, 0)
        eval_times = (
            torch.Tensor([offset_sec], device=representations.device)
            .repeat(representations.size(0))
            .reshape(-1, 1)
        )
        grid = torch.linspace(0, 1, value_resolution, device=representations.device)
        eval_values = grid.reshape(-1, 1).repeat(result_representation.size(0), 1)

        cdfs = self.forward_from_representation(representations, eval_times, eval_values)
        return self.value_denormalizer(
            pdf_to_expected_value(
                cdf_to_pdf(cdfs.reshape(result_representation.size(0), value_resolution)),
                get_pdf_values(grid),
            )
        )

    def get_result_grid(
        self,
        result_representation: torch.Tensor,
        values_resolution: int,
        time_resolution: int,
        eval_point: torch.Tensor | None = None,
    ):
        batch_size = result_representation.size(0)

        eval_points_c = (
            eval_point
            if eval_point is not None and time_resolution == 1
            else torch.linspace(0.0, 1.0, time_resolution, device=result_representation.device).reshape(-1, 1)
            * self.max_time_sec
        )

        tested_cdfs_c = torch.linspace(
            0.0, 1.0, values_resolution, device=result_representation.device
        ).reshape(-1, 1)

        repeated_eval_points = eval_points_c.repeat(values_resolution, 1)
        repeated_percentiles = tested_cdfs_c.repeat_interleave(time_resolution, 0)

        res = self.predictor.calculate_from_result_representation(
            result_representation.repeat_interleave(values_resolution * time_resolution, 0),
            self.time_normalizer(repeated_eval_points.repeat(batch_size, 1)),
            self.cdf_normalizer(repeated_percentiles.repeat(batch_size, 1)),
        )
        grid_vals = res.reshape(batch_size, values_resolution, time_resolution)
        return eval_points_c.reshape(-1), self.value_denormalizer(tested_cdfs_c.reshape(-1)), grid_vals

    def get_quantile(self, vals: torch.Tensor, result_grid: torch.Tensor, quantile: float):
        indices = (abs(result_grid - quantile)).argmin(1)
        return vals.take(indices)[0]

    def get_random_representation(self, count, representation_template):
        return torch.normal(
            representation_template.mean(dim=0).repeat(count, 1),
            representation_template.std(dim=0).repeat(count, 1),
        )

    def get_random_times(self, count, device):
        return torch.rand((count, 1), device=device) * self.max_time_sec

    def get_boundary_and_gradient_losses(self, representations: torch.Tensor, eval_times: torch.Tensor):
        zeros = torch.zeros_like(eval_times)
        ones = torch.ones_like(eval_times)

        zero_boundary_res = self.forward_from_representation(representations, eval_times, zeros)
        ones_boundary_res = self.forward_from_representation(representations, eval_times, ones)

        if self.training:
            rand_values = torch.rand_like(eval_times, requires_grad=True)
            random_cdfs_res = self.forward_from_representation(representations, eval_times, rand_values)
            result_grad = torch.autograd.grad(random_cdfs_res.sum(), rand_values, create_graph=True)[0]
            negative_grads_loss = torch.nn.functional.relu(result_grad * -1).mean()
        else:
            negative_grads_loss = torch.tensor(0.0)

        if self.training:
            eval_times_grad_clone = eval_times.clone()
            eval_times_grad_clone.requires_grad = True
            real_cdfs = self.calculate_cdfs(representations, eval_times_grad_clone)
            real_pdfs = cdf_to_pdf(real_cdfs)
            expected_values = pdf_to_expected_value(real_pdfs, self.pdf_values)
            variances = pdf_to_variance(real_pdfs, self.pdf_values, expected_values)

            variance_grad = torch.autograd.grad(variances.sum(), eval_times_grad_clone, create_graph=True)[0]
            variance_grad_loss = torch.nn.functional.relu(variance_grad * -1).mean()
        else:
            variance_grad_loss = torch.tensor(0.0)

        return {
            "zero_boundary_loss": zero_boundary_res.pow(2.0).mean(),
            "ones_boundary_loss": (1.0 - ones_boundary_res).pow(2.0).mean(),
            "negative_grad_loss": negative_grads_loss,
            "variance_grad_loss": variance_grad_loss,
        }

    def get_one_focal_loss(self, predicted, target):
        alpha = target.mean()
        bce_loss = torch.nn.functional.binary_cross_entropy(predicted, target, reduction="none")
        p_t = (predicted * target) + ((1 - predicted) * (1 - target))
        gamma_weights = (1 - p_t) ** self.gamma
        alpha_weights = alpha * target + (1 - alpha) * (1 - target)
        return (alpha_weights * gamma_weights * bce_loss).mean()

    def get_possibility_loss(
        self,
        representation: torch.Tensor,
        eval_times: torch.Tensor,
        min_vals: torch.Tensor,
        max_vals: torch.Tensor,
    ):
        min_vals_result = self.forward_from_representation(representation, eval_times, min_vals)
        max_vals_result = self.forward_from_representation(representation, eval_times, max_vals)
        weights = 1.0 / (max_vals - min_vals)

        focal_loss_lower = self.get_one_focal_loss(min_vals_result, torch.zeros_like(min_vals_result))
        focal_loss_upper = self.get_one_focal_loss(max_vals_result, torch.ones_like(min_vals_result))

        return {
            "possibility_loss": ((1.0 - (max_vals_result - min_vals_result)) * weights).mean(),
            "focal_loss": focal_loss_upper + focal_loss_lower,
        }

    # def get_focal_loss(
    #     self,
    #     masked_state: torch.Tensor,
    #     masked_action: torch.Tensor,
    #     eval_times: torch.Tensor,
    #     min_vals: torch.Tensor,
    #     max_vals: torch.Tensor,
    # ):
    #     percentiles = self.percentiles_generator(eval_times.numel(), eval_times.device).reshape_as(eval_times)

    #     max_val_targets = (max_vals < percentiles).float()
    #     min_val_targets = (min_vals < percentiles).float()

    #     predicted = self.forward(masked_state, masked_action, eval_times, percentiles)

    #     total_loss = self.get_one_focal_loss(predicted, max_val_targets) + self.get_one_focal_loss(
    #         predicted, min_val_targets
    #     )

    #     return {"focal_loss": total_loss}

    # def get_one_calibration_loss(
    #     self,
    #     masked_state: torch.Tensor,
    #     masked_action: torch.Tensor,
    #     eval_times: torch.Tensor,
    #     values: torch.Tensor,
    #     values_mask: torch.Tensor,
    # ):
    #     flat_values_mask = values_mask.reshape(-1).bool()

    #     masked_eval_points = eval_times.reshape(-1, 1)[flat_values_mask, :]
    #     masked_values = values.reshape(-1, 1)[flat_values_mask, :]
    #     states = masked_state.repeat_interleave(eval_times.size(1), 0)[flat_values_mask, :]
    #     actions = masked_action.repeat_interleave(eval_times.size(1), 0)[flat_values_mask, :]

    #     masked_values_count = masked_values.numel()

    #     if masked_values_count < 10:
    #         total_loss = torch.tensor(0.0, requires_grad=self.training, device=masked_state.device)
    #     else:
    #         repeated_eval_points = masked_eval_points.repeat(self.percentiles_count, 1)
    #         percentiles = self.percentiles_generator(self.percentiles_count, masked_state.device)
    #         repeated_percentiles = percentiles.repeat_interleave(masked_values_count, 0)

    #         cdfs = torch.ones_like(repeated_eval_points) * repeated_percentiles

    #         model_estimate = self.predictor.forward(
    #             states.repeat(self.percentiles_count, 1),
    #             actions.repeat(self.percentiles_count, 1),
    #             self.time_normalizer(repeated_eval_points),
    #             self.cdf_normalizer(cdfs),
    #         )
    #         percentile_estimates = model_estimate.reshape(self.percentiles_count, -1).mean(dim=1)

    #         repeated_values = masked_values.repeat(self.percentiles_count, 1)

    #         data_estimate = (repeated_values <= repeated_percentiles).reshape(self.percentiles_count, -1).sum(
    #             dim=1
    #         ) / masked_values_count

    #         all_losses = torch.nn.functional.mse_loss(percentile_estimates, data_estimate, reduction="none")
    #         total_loss = all_losses.mean()
    #         # metrics = dict(zip(self.calibration_metric_names, all_losses))

    #     return total_loss

    # def get_calibration_loss(
    #     self,
    #     masked_state: torch.Tensor,
    #     masked_action: torch.Tensor,
    #     eval_times: torch.Tensor,
    #     values: torch.Tensor,
    #     values_mask: torch.Tensor,
    # ):
    #     device = masked_state.device
    #     value_ranges = torch.cat(
    #         [
    #             torch.zeros(1, device=device),
    #             self.percentiles_generator(4, device).reshape(-1).sort()[0],
    #             torch.ones(1, device=device),
    #         ]
    #     )
    #     time_ranges = (
    #         torch.cat(
    #             [
    #                 torch.zeros(0, device=device),
    #                 torch.rand(4, device=device).sort()[0],
    #                 torch.ones(1, device=device),
    #             ]
    #         )
    #         * self.max_time_sec
    #     )

    #     calib_estimate_threshold = 10
    #     all_sums = []
    #     all_losses = []
    #     for i in range(len(value_ranges) - 1):
    #         for j in range(len(time_ranges) - 1):
    #             min_val = value_ranges[i]
    #             max_val = value_ranges[i + 1]
    #             min_time = time_ranges[j]
    #             max_time = time_ranges[j + 1]
    #             val_mask = ((values >= min_val) & (values < max_val)).float()
    #             time_mask = ((eval_times >= min_time) & (eval_times < max_time)).float()
    #             full_mask = val_mask * time_mask * values_mask
    #             values_count = full_mask.sum()
    #             all_sums.append(values_count)
    #             if values_count > calib_estimate_threshold:
    #                 all_losses.append(
    #                     self.get_one_calibration_loss(
    #                         masked_state, masked_action, eval_times, values, full_mask
    #                     )
    #                 )

    #     if len(all_losses) > 0:
    #         total_loss = torch.stack(all_losses).mean()
    #     else:
    #         total_loss = torch.tensor(0.0, requires_grad=self.training, device=masked_state.device)

    #     all_sums_tensor = torch.stack(all_sums)
    #     return {"calibration_loss": total_loss}, {
    #         "calibration_mean_values": all_sums_tensor.mean(),
    #         "calibration_over_threshold": (all_sums_tensor > calib_estimate_threshold).float().mean(),
    #     }

    # def get_calibration_loss(
    #     self, masked_state, masked_action, all_times, all_values, all_masks, values_resolution
    # ):
    #     if self.training:
    #         return {"calibration_loss": torch.tensor(0.0, device=masked_state.device, requires_grad=True)}, {}

    #     batch_size, time_resolution = all_times.size()

    #     result_representation = self.calculate_representation(masked_state, masked_action)
    #     repeated_times = all_times.reshape(-1, 1).repeat(values_resolution, 1)
    #     grid_values = torch.linspace(
    #         0.0, 1.0, values_resolution, device=result_representation.device
    #     ).reshape(-1, 1)
    #     repeated_values = grid_values.repeat_interleave(time_resolution, 0).repeat(batch_size, 1)
    #     res = self.predictor.calculate_from_result_representation(
    #         result_representation.repeat_interleave(values_resolution * time_resolution, 0),
    #         self.time_normalizer(repeated_times),
    #         self.cdf_normalizer(repeated_values),
    #     )
    #     probas = res.reshape(batch_size, values_resolution, time_resolution)

    #     unsqueezed_probas = probas.unsqueeze(0).repeat(self.percentiles_count, 1, 1, 1)
    #     distances = unsqueezed_probas - self.tested_percentiles.unsqueeze(1).unsqueeze(2).unsqueeze(3)

    #     selected_values = all_values[all_masks.bool()].unsqueeze(0).repeat(self.percentiles_count, 1)

    #     # differentiable calc
    #     squared_distances = distances**2.0
    #     weights = squared_distances - torch.nn.functional.hardshrink(squared_distances, lambd=0.01)

    #     grid_values_2 = grid_values.repeat(1, time_resolution)
    #     quantiles = torch.nn.functional.hardtanh(
    #         (weights * grid_values_2).sum(dim=2) / (weights.sum(dim=2) + 0.000001)
    #     )

    #     selected_quantiles = quantiles[:, all_masks.bool()]

    #     percentages = torch.nn.functional.sigmoid((selected_quantiles - selected_values) * 100.0).mean(dim=1)

    #     # nondifferentiable calc
    #     nd_indices = abs(distances).argmin(dim=2)
    #     nd_quantiles = grid_values.reshape(-1).take_along_dim(nd_indices).reshape_as(nd_indices)

    #     nd_selected_quantiles = nd_quantiles[:, all_masks.bool()]
    #     nd_percentages = (selected_values <= nd_selected_quantiles).float().mean(dim=1)

    #     diff = percentages - self.tested_percentiles
    #     return {"calibration_loss": (diff * diff).mean()}, {
    #         **{name: val for name, val in zip(self.approx_metric_names, percentages)},
    #         **{name: val for name, val in zip(self.real_metric_names, nd_percentages)},
    #     }

    def get_calibration_loss(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        all_values: torch.Tensor,
        all_masks: torch.Tensor,
        value_resolution: int,
        time_resolution: int,
    ):
        device = masked_state.device
        time_indices = torch.randint(1, 240, (self.percentiles_count,), device=device).sort()[0]
        time_indices[0] = 0
        time_indices[-1] = 241

        real_hist = get_real_histogram(all_values, value_resolution)
        calc_hist = get_calculated_histogram(
            self, masked_state, masked_action, value_resolution, time_resolution
        )

        all_sums = []
        all_losses = []
        for i in range(len(time_indices) - 1):
            min_index = time_indices[i]
            max_index = time_indices[i + 1]

            time_filter = torch.zeros_like(all_masks)
            time_filter[:, min_index:max_index] = 1.0
            full_mask = all_masks * time_filter

            values_count = full_mask.sum()
            all_sums.append(values_count)
            if values_count < 1:
                all_losses.append(torch.tensor(0.0, requires_grad=self.training, device=masked_state.device))
            else:
                full_flat_mask = full_mask.reshape(-1).bool()
                calc_hist_selected = calc_hist.reshape(-1, value_resolution - 1)[full_flat_mask, :]

                calculated_time_selection = normalize_histogram(calc_hist_selected.sum(dim=0))

                # Smoothing factor 3 is valid for value resolution 101 for Si
                real_time_selection = normalize_histogram(
                    smooth_out_histogram(real_hist[:, min_index:max_index].sum(dim=1), 3)
                )

                # we need to remove negative values from calculated histogram as occasionally when
                # cdf loss is not optimized yet we can have them
                loss = kldiv(real_time_selection, torch.nn.functional.relu(calculated_time_selection))
                all_losses.append(loss)

        total_loss = torch.stack(all_losses).mean()
        all_sums_tensor = torch.stack(all_sums)
        return {"calibration_loss": total_loss}, {"calibration_mean_values": all_sums_tensor.mean()}

    # representations shape ITEM COUNT X INTERNAL REP SIZE
    # times shape           ITEM COUNT X 1
    # value_grid shape      CDF RESOLUTION
    # #####
    # return shape          ITEM COUNT X CDF RESOLUTION
    def calculate_cdfs(self, representations, times):
        item_count = representations.size(0)
        tested_values = self.cdf_grid.reshape(-1, 1).repeat(item_count, 1)

        result = self.forward_from_representation(
            representations.repeat_interleave(self.value_resolution, 0),
            times.repeat_interleave(self.value_resolution, 0),
            tested_values,
        )
        return result.reshape(-1, self.value_resolution)

    def get_real_percentiles(self, cdfs, real_values):
        repeated_percentiles = self.tested_percentiles.repeat(cdfs.size(0), 1)

        repeated_cdfs = cdfs.repeat_interleave(self.percentiles_count, 0)

        distances = abs(repeated_cdfs - repeated_percentiles)
        quantiles = self.cdf_grid.take(distances.argmin(dim=1))

        repeated_values = real_values.repeat_interleave(self.percentiles_count, 0)

        real_percentiles = (
            (repeated_values <= quantiles).reshape(-1, self.percentiles_count).float().mean(dim=0)
        )

        diffs = abs(real_percentiles - self.tested_percentiles.reshape(-1))

        mean_difference = diffs.mean()
        max_difference = diffs.max()

        return {
            "mean_calibration_diff": mean_difference,
            "max_calibration_diff": max_difference,
            **{name: val for name, val in zip(self.real_metric_names, real_percentiles)},
        }

    def get_zero_time_action_independence_loss(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ):
        batch_size = masked_state.size(0)
        device = masked_state.device

        random_states = self.get_random_representation(batch_size, masked_state)
        random_actions_1 = self.get_random_representation(batch_size, masked_action)
        random_actions_2 = self.get_random_representation(batch_size, masked_action)

        normalized_zero_time = self.time_normalizer(torch.zeros(batch_size, device=device).reshape(-1, 1))

        rep1a, rep2a = self.predictor.calculate_one_time_different_action_representation(
            masked_state, normalized_zero_time, masked_action, random_actions_1, last_values
        )

        rep1b, rep2b = self.predictor.calculate_one_time_different_action_representation(
            random_states, normalized_zero_time, random_actions_1, random_actions_2, last_values
        )

        return torch.nn.functional.mse_loss(rep1a, rep2a) + torch.nn.functional.mse_loss(rep1b, rep2b)

    def get_results_metrics_and_losses(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        eval_times: torch.Tensor,
        values: torch.Tensor,
        values_mask: torch.Tensor,
        min_vals: torch.Tensor,
        max_vals: torch.Tensor,
        last_values: Optional[torch.Tensor] = None,
    ) -> tuple[dict[str, torch.Tensor], dict[str, torch.Tensor], dict[str, torch.Tensor]]:
        batch_size = masked_state.size(0)
        device = masked_state.device

        internal_rep = self.calculate_representation(masked_state, masked_action, last_values)

        random_internal_rep = self.get_random_representation(batch_size, internal_rep)
        random_times = self.get_random_times(batch_size, device)

        boundary_losses_1 = self.get_boundary_and_gradient_losses(internal_rep, random_times)
        boundary_losses_2 = self.get_boundary_and_gradient_losses(random_internal_rep, random_times)
        boundary_losses = {key: boundary_losses_1[key] + boundary_losses_2[key] for key in boundary_losses_1}

        all_internal_reps = internal_rep.repeat_interleave(eval_times.size(1), 0)
        all_eval_times = eval_times.reshape(-1, 1)

        possiblity_loss = self.get_possibility_loss(
            all_internal_reps, all_eval_times, min_vals.reshape(-1, 1), max_vals.reshape(-1, 1)
        )

        selected_representation, selected_times, selected_values = get_measured_values_data(
            internal_rep, values, eval_times, values_mask.bool()
        )

        selected_values_count = selected_values.size(0)

        if selected_values_count > 0:
            cdfs = self.calculate_cdfs(selected_representation, selected_times.reshape(-1, 1))
            pdfs = cdf_to_pdf(cdfs)
            expected_values = pdf_to_expected_value(pdfs, self.pdf_values)

            mse_loss = torch.nn.functional.mse_loss(expected_values, selected_values)
            mae_loss = torch.nn.functional.l1_loss(
                self.value_denormalizer(expected_values), self.value_denormalizer(selected_values)
            )

            real_percentiles = self.get_real_percentiles(cdfs, selected_values)

            # calibration_loss, metrics = self.get_calibration_loss(
            #     masked_state, masked_action, all_values, all_masks, self.calibration_resolution, 241
            # )
        else:
            mse_loss = torch.zeros(1, device=device, requires_grad=True)
            mae_loss = torch.zeros(1, device=device, requires_grad=True)
            real_percentiles = {}

        zero_time_action_independence_loss = self.get_zero_time_action_independence_loss(
            masked_state, masked_action, last_values
        )

        lip_loss = self.predictor.get_lipschitz_loss()

        losses = {
            **boundary_losses,
            **possiblity_loss,
            "mse_loss": mse_loss,
            "lipschitz_loss": lip_loss,
            "zero_time_action_indp_loss": zero_time_action_independence_loss,
        }
        metrics = {**real_percentiles, "mae_loss": mae_loss, "selected_values_count": selected_values_count}

        return {}, metrics, losses

    def get_total_loss(self, losses):
        return (
            (losses["zero_boundary_loss"] * self.cdf_loss_weight)
            + (losses["ones_boundary_loss"] * self.cdf_loss_weight)
            + (losses["negative_grad_loss"] * self.cdf_loss_weight)
            + (losses["variance_grad_loss"] * self.cdf_loss_weight)
            + (losses["zero_time_action_indp_loss"] * self.cdf_loss_weight)
            + (losses["possibility_loss"] * self.possibility_loss_weight)
            + (losses["focal_loss"] * self.focal_loss_weight)
            + (losses["mse_loss"] * self.mse_loss_weight)
            + (losses["lipschitz_loss"] * self.lip_loss_weight)
            # + (losses["calibration_loss"] * self.calibration_loss_weight)
        )

    def calculate_cdf_grid(
        self,
        one_masked_state: torch.Tensor,
        one_masked_action: torch.Tensor,
        time_resolution: int,
        percentiles_resolution: int,
        one_last_value: Optional[torch.Tensor] = None,
    ):
        if (
            (one_masked_state.size(0) != 1)
            or (one_masked_action.size(0) != 1)
            or (one_last_value is not None and one_last_value.size(0) != 1)
        ):
            raise Exception(
                "calculate_cdf_grid expect one specific state and action embedding. Shape should be 1 x EMBSIZE"
            )

        eval_points_c = (
            torch.linspace(0.0, 1.0, time_resolution, device=one_masked_state.device).reshape(-1, 1)
            * self.max_time_sec
        )
        tested_cdfs_c = torch.linspace(
            0.0, 1.0, percentiles_resolution, device=one_masked_state.device
        ).reshape(-1, 1)

        repeated_eval_points = eval_points_c.repeat(percentiles_resolution, 1)
        repeated_percentiles = tested_cdfs_c.repeat_interleave(time_resolution, 0)
        total_size = time_resolution * percentiles_resolution

        res = self.forward(
            one_masked_state.repeat(total_size, 1),
            one_masked_action.repeat(total_size, 1),
            repeated_eval_points,
            repeated_percentiles,
            None if one_last_value is None else one_last_value.repeat(total_size, 1),
        )
        grid_vals = res.reshape(percentiles_resolution, time_resolution)
        return eval_points_c, tested_cdfs_c, grid_vals

    def get_figure(
        self,
        grid_eval_points,
        grid_cdf_points,
        grid_vals,
        eval_points,
        min_vals,
        max_vals,
        vals,
        min_cdf_index,
        max_cdf_index,
        min_cdf_value,
        max_cdf_value,
    ):
        fig, (ax2, ax) = plt.subplots(1, 2, figsize=(14, 6), width_ratios=[0.02, 0.98])
        image = ax.imshow(
            grid_vals[min_cdf_index:max_cdf_index, :],
            cmap="RdYlGn",
            vmin=0.0,
            vmax=1.0,
            extent=(0, self.max_time_sec / 60, max_cdf_index, min_cdf_index),
            aspect="auto",
        )
        ax.set_ylim(ax.get_ylim()[::-1])
        ax.get_yaxis().set_visible(False)
        ax1 = ax.twinx()

        ax1.plot(eval_points, min_vals, ":", c="lightyellow", label="min_vlas")
        ax1.plot(eval_points, max_vals, ":", c="lightyellow", label="max_vals")
        ax1.plot(eval_points, vals, "*", c="black", label="values")

        X, Y = np.meshgrid(grid_eval_points.reshape(-1), grid_cdf_points.reshape(-1))
        CS = ax1.contour(X, Y, grid_vals, levels=[0.05, 0.25, 0.5, 0.75, 0.95], cmap="Grays")
        ax1.clabel(CS, inline=True, fontsize=15)
        ax1.set_ylim(min_cdf_value, max_cdf_value)

        plt.colorbar(image, cax=ax2)

        ax1.set_ylabel("Si (%)")
        ax.set(xlabel="Time (min)")
        ax2.set_ylabel("Probability (<= value)")
        ax2.yaxis.set_label_position("left")
        ax2.yaxis.tick_left()
        plt.tight_layout()

        return fig

    def get_zoom_values(self, grid_cdf_values, min_vals, max_vals, vals):
        cdfs = grid_cdf_values.reshape(-1)
        all_values = np.concatenate([min_vals, max_vals, vals])
        all_values = all_values[~np.isnan(all_values)]
        min_index = ((all_values.min() - cdfs).clip(0).argmin() - 1).clip(0)
        max_index = ((cdfs - all_values.max()).clip(0) > 0).argmax()
        return min_index.item(), max_index.item(), cdfs[min_index].item(), cdfs[max_index].item()

    # TODO move to callback
    def log_prediction_chart(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        eval_points: torch.Tensor,
        values: torch.Tensor,
        values_mask: torch.Tensor,
        min_vals: torch.Tensor,
        max_vals: torch.Tensor,
        prefix: str,
        last_value: Optional[torch.Tensor] = None,
    ):
        logger = self.get_tensorboard_logger()
        if logger is None:
            return

        time_resolution = 241
        cdf_resolution = 201

        grid_eval_points, grid_cdf_values, grid_vals = self.calculate_cdf_grid(
            masked_state.unsqueeze(0),
            masked_action.unsqueeze(0),
            time_resolution,
            cdf_resolution,
            None if last_value is None else last_value.unsqueeze(0),
        )

        # TODO move to callback and make it settable
        def value_to_real_value(x):
            return x * 2.0

        def seconds_to_minutes(x):
            return x / 60.0

        detached_eval_points = seconds_to_minutes(eval_points.detach().cpu().numpy())
        detached_min_vals = value_to_real_value(min_vals.detach().cpu().numpy())
        detached_max_vals = value_to_real_value(max_vals.detach().cpu().numpy())
        detached_values = value_to_real_value(values.detach().cpu().numpy())
        detached_mask = values_mask.detach().cpu().numpy()

        detached_values[detached_mask == 0] = np.nan

        detached_grid_eval_points = seconds_to_minutes(grid_eval_points.detach().cpu().numpy())
        detached_grid_cdf_values = value_to_real_value(grid_cdf_values.detach().cpu().numpy())
        detached_grid = grid_vals.detach().cpu().numpy()

        full_fig = self.get_figure(
            detached_grid_eval_points,
            detached_grid_cdf_values,
            detached_grid,
            detached_eval_points,
            detached_min_vals,
            detached_max_vals,
            detached_values,
            0,
            cdf_resolution - 1,
            value_to_real_value(0.0),
            value_to_real_value(1.0),
        )

        logger.add_figure(f"{prefix}/ppf_fixedy", full_fig, global_step=self.global_step)

        zoomed_fig = self.get_figure(
            detached_grid_eval_points,
            detached_grid_cdf_values,
            detached_grid,
            detached_eval_points,
            detached_min_vals,
            detached_max_vals,
            detached_values,
            *self.get_zoom_values(
                detached_grid_cdf_values, detached_min_vals, detached_max_vals, detached_values
            ),
        )

        logger.add_figure(f"{prefix}/ppf", zoomed_fig, global_step=self.global_step)

    def calculate_envelope_width_order(self, min_vals: torch.Tensor, max_vals: torch.Tensor) -> torch.Tensor:
        min_max_vals = max_vals - min_vals
        return min_max_vals.mean(dim=1).argsort()

    def log_prediction_chart_by_envelope_width_order(
        self,
        masked_state: torch.Tensor,
        masked_action: torch.Tensor,
        eval_points: torch.Tensor,
        values: torch.Tensor,
        values_mask: torch.Tensor,
        min_vals: torch.Tensor,
        max_vals: torch.Tensor,
        prefix: str,
        last_values: Optional[torch.Tensor] = None,
    ):
        try:
            envelope_width_order = self.calculate_envelope_width_order(min_vals, max_vals)
            envelope_width_order_map = (
                (envelope_width_order[0], "narrow"),
                (envelope_width_order[envelope_width_order[len(envelope_width_order) // 2]], "middle"),
                (envelope_width_order[int(len(envelope_width_order) * 0.9)], "wide"),
            )

            for order, name in envelope_width_order_map:
                self.log_prediction_chart(
                    masked_state[order],
                    masked_action[order],
                    eval_points[order],
                    values[order],
                    values_mask[order],
                    min_vals[order],
                    max_vals[order],
                    f"{prefix}/{name}",
                    None if last_values is None else last_values[order],
                )
        except Exception:
            print(traceback.format_exc())

    def training_step(self, batch, batch_idx):
        (masked_state, masked_action, eval_points, values, values_mask, min_vals, max_vals, last_values) = (
            batch
        )

        # current_percentage = max(0.1, min(1.0, (self.current_epoch / self.full_length_epochs)))
        # max_index = int(eval_points.size(1) * current_percentage)

        results, metrics, losses = self.get_results_metrics_and_losses(
            masked_state, masked_action, eval_points, values, values_mask, min_vals, max_vals, last_values
        )

        # self.log("train/max_index", max_index)

        for name in losses:
            prog_bar_log = name in [
                "zero_boundary_loss",
                "ones_boundary_loss",
                "possibility_loss",
                "negative_grad_loss",
            ]
            self.log(f"train/{name}", losses[name], prog_bar=prog_bar_log)

        for name in metrics:
            self.log(f"train/{name}", metrics[name], prog_bar=False)

        total_loss = self.get_total_loss(losses)
        self.log("train/total_loss", total_loss, prog_bar=True)

        if (batch_idx % self.log_images_every_n_steps) == 0:
            # Logging only first item of batch now
            self.log_prediction_chart_by_envelope_width_order(
                masked_state,
                masked_action,
                eval_points,
                values,
                values_mask,
                min_vals,
                max_vals,
                "train",
                last_values,
            )

        return total_loss

    def validation_step(self, batch, batch_idx):
        (masked_state, masked_action, eval_points, values, values_mask, min_vals, max_vals, last_values) = (
            batch
        )

        results, metrics, losses = self.get_results_metrics_and_losses(
            masked_state, masked_action, eval_points, values, values_mask, min_vals, max_vals, last_values
        )

        for name in losses:
            self.log(f"val/{name}", losses[name], prog_bar=True)

        for name in metrics:
            self.log(f"val/{name}", metrics[name], prog_bar=False)

        total_loss = self.get_total_loss(losses)
        self.log("val/total_loss", total_loss)

        if (batch_idx % self.log_images_every_n_steps) == 0:
            # Logging only first item of batch now
            self.log_prediction_chart_by_envelope_width_order(
                masked_state,
                masked_action,
                eval_points,
                values,
                values_mask,
                min_vals,
                max_vals,
                "val",
                last_values,
            )

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=0.001)

        scheduler = {
            "scheduler": torch.optim.lr_scheduler.LambdaLR(
                optimizer,
                linear_warmup_decay(self.warmup_steps),
            ),
            "interval": "step",
            "frequency": 1,
        }

        return [optimizer], [scheduler]

    def get_tensorboard_logger(self) -> Optional[SummaryWriter]:
        try:
            tb_logger = None
            for logger in self.trainer.loggers:
                if isinstance(logger, L.pytorch.loggers.TensorBoardLogger):
                    tb_logger = logger.experiment
                    break
            return tb_logger
        except Exception:
            return None
