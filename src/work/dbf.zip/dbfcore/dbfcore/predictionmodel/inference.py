import base64
import json
from functools import partial
from pathlib import Path
from typing import Any, Callable, Self

import attrs
import pandas as pd
import torch

from dbfcore.dataset.signals import (
    SIGNAL_TO_SIGNAL_GROUP_MAP,
    SIGNALVAESIMPLE_SIGNAL_MAIN_GROUPS,
    get_signal_main_group,
)
from dbfcore.dataset.signals.protocol import SignalGroupDataFrame
from dbfcore.model.datamodule.pisignal import (
    is_empty_sequence_batched,
    normalize_start_and_convert_to_torch,
    resample_to_len,
    transform_timestamps,
)
from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from dbfcore.model.vicregtraining import RealVicReg
from dbfcore.predictionmodel.datamodule import (
    create_zero_one_normalizer_with_clamping,
    get_last_value_with_offset_before,
)
from dbfcore.predictionmodel.model import PredictionModel
from dbfcore.predictionmodel.protocols import DataDefinition, SignalGroupData
from dbfcore.utils import (
    EMBEDDING_MODEL,
    flat_tensor_to_float32_bytes,
    float32_bytes_to_flat_tensor,
    load_lightning_model_from_path_cached,
    load_yaml_into_dict,
)

LOCAL_TIMEZONE = "Europe/Bratislava"


def get_minmax_data_definition(data_definitions: list[DataDefinition]) -> DataDefinition:
    minmax_data_definition = {}
    signal_groups = set(signal_group for dd in data_definitions for signal_group in dd)
    for signal_group in signal_groups:
        min_start = min(dd[signal_group][0] for dd in data_definitions if signal_group in dd)
        max_end = max(dd[signal_group][1] for dd in data_definitions if signal_group in dd)
        minmax_data_definition[signal_group] = (min_start, max_end)
    return minmax_data_definition


def select_embedding_model_raw_inputs_history(
    signal_data: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    return signal_data[start:end].dropna()


def select_embedding_model_raw_inputs_future(
    signal_data: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    signal_data = signal_data.dropna()
    return generate_synthetic_future_data(signal_data, start, end)


def generate_synthetic_future_data(
    data: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    if len(data) < 2:
        return pd.DataFrame()

    frequency = data.index.diff().mean()
    index_name = data.index.name
    timestamps = pd.date_range(start, end, freq=frequency, name=index_name, inclusive="right")

    smoothing_factor = "15min"  # experimentally defined
    value_to_project = data.rolling(smoothing_factor).median().loc[:start].iloc[-1, 0]

    return pd.DataFrame(index=timestamps, data=value_to_project, columns=[data.columns[0]])


def process_selected_data_into_tensor(
    selected_data: pd.DataFrame, seq_len: int, start: pd.Timestamp
) -> torch.Tensor:
    transformed_data = transform_timestamps(selected_data)
    resampled = resample_to_len(transformed_data.values, seq_len, "live")
    return normalize_start_and_convert_to_torch(resampled, start.timestamp())


def get_embedding_model_inputs_for_history_only_signal(
    data: pd.DataFrame, seq_len: int, start: pd.Timestamp, _: pd.Timestamp, end: pd.Timestamp
) -> torch.Tensor:
    selected_data = select_embedding_model_raw_inputs_history(data, start, end)
    return process_selected_data_into_tensor(selected_data, seq_len, start)


def get_embedding_model_inputs_for_signal_with_future(
    data: pd.DataFrame, seq_len: int, start: pd.Timestamp, calc_time: pd.Timestamp, end: pd.Timestamp
) -> torch.Tensor:
    past_selected_data = select_embedding_model_raw_inputs_history(data, start, calc_time)
    future_selected_data = select_embedding_model_raw_inputs_future(data, calc_time, end)
    if future_selected_data.empty:
        selected_data = future_selected_data
    else:
        selected_data = pd.concat([past_selected_data, future_selected_data])
    return process_selected_data_into_tensor(selected_data, seq_len, start)


def get_prediction_model_inputs_for_signal_wo_data(
    batch_size: int, encoder: EMBEDDING_MODEL, signal_name: str, seq_len: int
) -> tuple[torch.Tensor, torch.Tensor]:
    inputs = torch.zeros(batch_size, seq_len, 2)
    indices = torch.tensor([encoder.get_idx_for_signal_name(signal_name)]).repeat(batch_size).long()
    embedding = encoder.encode_and_project(inputs, indices)
    mask = torch.logical_not(is_empty_sequence_batched(inputs))
    return embedding, mask


def signal_requires_future(window_size: pd.Timedelta, offset: pd.Timedelta, eval_mode: bool) -> bool:
    return False if eval_mode else window_size.total_seconds() + offset.total_seconds() > 0


def get_embedding_model_inputs_func(requires_future: bool, signal_data: pd.DataFrame, seq_len: int):
    func = (
        get_embedding_model_inputs_for_signal_with_future
        if requires_future
        else get_embedding_model_inputs_for_history_only_signal
    )
    return partial(func, signal_data, seq_len), func


def get_embedding_model_inputs_iterable(
    calc_times: list[pd.Timestamp], window_size: pd.Timedelta, offset: pd.Timedelta
) -> list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]:
    return [(ct + offset, ct, ct + offset + window_size) for ct in calc_times]


def get_embedding_model_inputs_from_func_iterable(
    func: Callable, argslist: list[tuple[pd.Timestamp, pd.Timestamp, pd.Timestamp]]
) -> torch.Tensor:
    return torch.stack([func(*args) for args in argslist])


def get_prediction_model_inputs_for_signal(
    signal: dict[str, Any],
    data: SignalGroupDataFrame,
    calc_times: list[pd.Timestamp],
    encoder: EMBEDDING_MODEL,
    eval_mode: bool,
) -> tuple[torch.Tensor, torch.Tensor]:
    signal_name = signal["name"]
    seq_len = encoder.max_seq_len if isinstance(encoder, SignalVAESimple2) else encoder.seq_len
    window_size = pd.Timedelta(encoder.window_size)
    offset = pd.Timedelta(signal["start_time_offset_sec"], "sec")

    if signal_name not in data:
        return get_prediction_model_inputs_for_signal_wo_data(len(calc_times), encoder, signal_name, seq_len)

    requires_future = signal_requires_future(window_size, offset, eval_mode)
    func, _ = get_embedding_model_inputs_func(requires_future, data[[signal_name]], seq_len)
    iterable = get_embedding_model_inputs_iterable(calc_times, window_size, offset)

    inputs = get_embedding_model_inputs_from_func_iterable(func, iterable)
    indices = torch.tensor([encoder.get_idx_for_signal_name(signal_name)]).repeat(len(calc_times)).long()
    embedding = encoder.encode_and_project(inputs, indices)
    mask = torch.logical_not(is_empty_sequence_batched(inputs))

    return embedding, mask


@attrs.define(slots=False)
class DummyBlastFurnaceModelResult:
    result: dict
    calc_time: pd.Timestamp
    target_signal_name: str

    def to_bytes(self) -> bytes:
        return json.dumps(self.result).encode("utf-8")

    @classmethod
    def from_bytes(cls, data: bytes, calc_time: pd.Timestamp, *args, **kwargs) -> Self:
        return cls(json.loads(data.decode("utf-8")), calc_time, kwargs["target_signal_name"])

    def get_predicted_quantiles(
        self, quantiles: list[float], forecast_horizon: pd.Timedelta | None = None
    ) -> pd.DataFrame:
        return pd.DataFrame()

    def get_data_availability(self) -> pd.DataFrame:
        return pd.DataFrame()

    def get_expected_value(self, forecast_horizon: pd.Timedelta) -> float:
        return float("nan")

    def get_expected_values(self) -> pd.DataFrame:
        return pd.DataFrame()


class DummyBlastFurnaceModel:
    def __init__(self, target_signal: str):
        self.target_signal = target_signal

    def get_data_definition(self, calc_time: pd.Timestamp) -> DataDefinition:
        return {
            "bf1_chargeflow": (calc_time - pd.Timedelta("4h"), calc_time),
            "bf1_hotmetal_chem": (calc_time - pd.Timedelta("8h"), calc_time),
        }

    def calculate_batch(
        self, data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> list[DummyBlastFurnaceModelResult]:
        results = [{calc_time.timestamp(): (idx + 1) * 10} for idx, calc_time in enumerate(calc_times)]
        return [
            DummyBlastFurnaceModelResult(result, calc_time, self.target_signal)
            for result, calc_time in zip(results, calc_times)
        ]


@attrs.define(slots=False)
class NeuralBlastFurnaceModelResult:
    calc_time: pd.Timestamp
    representation: torch.Tensor
    time_resolution: int
    value_resolution: int
    input_sequence_masks: torch.Tensor
    prediction_model: PredictionModel
    input_signals: list[dict]
    target_signal_name: str

    def to_bytes(self) -> bytes:
        return json.dumps(
            {
                "rep": base64.b64encode(flat_tensor_to_float32_bytes(self.representation)).decode(),
                "mask": base64.b64encode(flat_tensor_to_float32_bytes(self.input_sequence_masks)).decode(),
            }
        ).encode("utf-8")

    @classmethod
    def from_bytes(cls, data: bytes, calc_time: pd.Timestamp, *args, **kwargs) -> Self:
        decoded_json = json.loads(data.decode())
        representation = float32_bytes_to_flat_tensor(base64.b64decode(decoded_json["rep"]))
        input_sequence_masks = float32_bytes_to_flat_tensor(base64.b64decode(decoded_json["mask"]))
        return cls(
            calc_time,
            representation,
            kwargs["time_resolution"],
            kwargs["value_resolution"],
            input_sequence_masks,
            kwargs["prediction_model"],
            kwargs["input_signals"],
            kwargs["target_signal_name"],
        )

    def get_forecast_times_for_predicted_quantiles(
        self, forecast_horizon: pd.Timedelta | None
    ) -> list[pd.Timestamp]:
        if forecast_horizon:
            return [self.calc_time + forecast_horizon]
        eval_points = torch.linspace(0.0, 1.0, self.time_resolution) * self.prediction_model.max_time_sec
        return [self.calc_time + pd.Timedelta(x.item(), "sec") for x in eval_points]

    def get_predicted_quantiles(
        self, quantiles: list[float], forecast_horizon: pd.Timedelta | None = None
    ) -> pd.DataFrame:
        with torch.no_grad():
            time_resolution = 1 if forecast_horizon is not None else self.time_resolution
            eval_point = (
                torch.tensor(forecast_horizon.total_seconds()) if forecast_horizon is not None else None
            )
            _, values, result_grid = self.prediction_model.get_result_grid(
                self.representation.unsqueeze(0), self.value_resolution, time_resolution, eval_point
            )
            forecast_times = self.get_forecast_times_for_predicted_quantiles(forecast_horizon)
            data = {str(q): self.prediction_model.get_quantile(values, result_grid, q) for q in quantiles}
            df = pd.DataFrame(data, index=forecast_times, columns=list(map(str, quantiles)))
            return df if forecast_horizon is None else df.loc[self.calc_time + forecast_horizon].to_frame().T

    def get_expected_value(self, forecast_horizon: pd.Timedelta) -> float:
        forecast_horizon = forecast_horizon.total_seconds()
        if forecast_horizon > self.prediction_model.max_time_sec:
            raise ValueError("Requested forecast window cannot be beyond model max_time_sec")

        with torch.no_grad():
            return self.prediction_model.get_expected_values(
                self.representation.unsqueeze(0), forecast_horizon
            ).item()

    def get_expected_values(self) -> pd.DataFrame:
        with torch.no_grad():
            eval_points = (
                torch.linspace(0.0, 1.0, self.time_resolution).numpy() * self.prediction_model.max_time_sec
            )
            data = [self.get_expected_value(pd.Timedelta(seconds=eval_point)) for eval_point in eval_points]
            forecast_times = [self.calc_time + pd.Timedelta(x.item(), "sec") for x in eval_points]
            return pd.DataFrame(data, index=forecast_times, columns=["expected_value"])

    def get_data_availability(self) -> pd.DataFrame:
        columns = ["signal_id", "signal_name", "input_sequence_masks", "start", "now"]

        if not self.input_sequence_masks.numel():
            return pd.DataFrame(columns=columns)
        now = self.calc_time.tz_convert(LOCAL_TIMEZONE)
        data = [
            (
                idx,
                signal["name"],
                empty.item(),
                pd.Timedelta(signal["start_time_offset_sec"], "sec") + now,
                now,
            )
            for idx, (signal, empty) in enumerate(zip(self.input_signals, self.input_sequence_masks))
        ]
        df = pd.DataFrame(data, columns=columns)
        df["input_sequence_masks"] = df["input_sequence_masks"].map({0: "Data N/A", 1: "Data OK"})
        return df


class NeuralBlastFurnaceModel:
    def __init__(
        self,
        value_resolution: int,
        time_resolution: int,
        config_path: Path,
        prediction_model_path: Path,
        embedding_model_paths: dict[str, Path],
        eval_mode: bool = False,
    ):
        self.config = load_yaml_into_dict(config_path)
        self.prediction_model_path = prediction_model_path
        self.embedding_model_paths = embedding_model_paths
        self.value_resolution = value_resolution
        self.time_resolution = time_resolution
        self.embedding_models: dict[str, EMBEDDING_MODEL] = {
            main_group: load_lightning_model_from_path_cached(
                SignalVAESimple2 if main_group in SIGNALVAESIMPLE_SIGNAL_MAIN_GROUPS else RealVicReg,
                self.embedding_model_paths[main_group],
            )
            .to("cpu")
            .eval()
            for main_group in self.input_signal_main_groups | self.future_signals_main_groups
        }
        self.prediction_model: PredictionModel = (
            load_lightning_model_from_path_cached(PredictionModel, self.prediction_model_path)
            .to("cpu")
            .eval()
        )
        self.target_value_normalizer = create_zero_one_normalizer_with_clamping(
            self.target_signal["value_minimum"], self.target_signal["value_maximum"]
        )

        self.eval_mode = eval_mode

    @property
    def input_signals(self) -> list[dict]:
        return self.config["data"]["input_signals"]

    @property
    def input_signal_main_groups(self) -> set[str]:
        return set(get_signal_main_group(signal["name"]) for signal in self.input_signals)

    @property
    def future_signals(self) -> list[dict]:
        return self.config["data"]["future_signals"]

    @property
    def future_signals_main_groups(self) -> set[str]:
        return set(get_signal_main_group(signal["name"]) for signal in self.future_signals)

    @property
    def target_signal(self) -> dict:
        return self.config["data"]["target_signal"]

    @property
    def target_signal_name(self) -> str:
        return self.target_signal["name"]

    @property
    def target_signal_group(self) -> str:
        return SIGNAL_TO_SIGNAL_GROUP_MAP[self.target_signal_name]

    @property
    def forecast_horizon(self) -> pd.Timedelta:
        return pd.Timedelta(self.config["data"]["forecast_horizon"])

    def get_data_definition(self, calc_time: pd.Timestamp) -> DataDefinition:
        data_definitions = []
        signals = self.input_signals + self.future_signals
        for signal in signals:
            group = SIGNAL_TO_SIGNAL_GROUP_MAP[signal["name"]]
            offset = pd.Timedelta(signal["start_time_offset_sec"], "sec")

            if self.eval_mode:
                encoder = self.get_encoder_for_signal(signal)
                window_size = pd.Timedelta(encoder.window_size)
                data_definitions.append({group: (calc_time + offset, calc_time + offset + window_size)})
            else:
                data_definitions.append({group: (calc_time + offset, calc_time)})

        return get_minmax_data_definition(data_definitions)

    def get_encoder_for_signal(self, signal: dict[str, Any]) -> EMBEDDING_MODEL:
        signal_main_group = get_signal_main_group(signal["name"])
        return self.embedding_models[signal_main_group]

    def get_embeddings_and_masks(
        self, signals: list[dict], data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> tuple[list, list, list]:
        embeddings, masks, scalar_masks = [], [], []
        for signal in signals:
            encoder = self.get_encoder_for_signal(signal)
            signal_group_data = data[SIGNAL_TO_SIGNAL_GROUP_MAP[signal["name"]]]
            emb, mask = get_prediction_model_inputs_for_signal(
                signal, signal_group_data, calc_times, encoder, self.eval_mode
            )
            embeddings.append(emb)
            masks.append(torch.ones_like(emb) * mask.unsqueeze(1))
            scalar_masks.append(mask)
        return embeddings, masks, scalar_masks

    def get_prediction_model_input_states(
        self, data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        embeddings, masks, scalar_masks = self.get_embeddings_and_masks(self.input_signals, data, calc_times)
        return torch.cat(embeddings, dim=1), torch.cat(masks, dim=1), torch.stack(scalar_masks, dim=1)

    def get_prediction_model_input_actions(
        self, data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        embeddings, masks, _ = self.get_embeddings_and_masks(self.future_signals, data, calc_times)
        return torch.cat(embeddings, dim=1), torch.cat(masks, dim=1)

    def get_last_values_tensor(self, data: SignalGroupData, calc_times: list[pd.Timestamp]) -> torch.Tensor:
        selected_data = data[self.target_signal_group]
        return torch.stack(
            [
                get_last_value_with_offset_before(
                    selected_data, self.target_signal_name, calc_time, self.target_value_normalizer
                )
                for calc_time in calc_times
            ]
        )

    def calculate_batch(
        self, data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> list[NeuralBlastFurnaceModelResult]:
        with torch.no_grad():
            states_embeddings, states_masks, masks = self.get_prediction_model_input_states(data, calc_times)
            actions_embeddings, actions_masks = self.get_prediction_model_input_actions(data, calc_times)
            masked_states = states_embeddings * states_masks
            masked_actions = actions_embeddings * actions_masks
            last_values = self.get_last_values_tensor(data, calc_times)
            representations = self.prediction_model.calculate_representation(
                masked_states, masked_actions, last_values.to(masked_states.dtype)
            )

        return [
            NeuralBlastFurnaceModelResult(
                ct,
                r,
                self.time_resolution,
                self.value_resolution,
                m,
                self.prediction_model,
                self.input_signals,
                self.target_signal["name"],
            )
            for ct, r, m in zip(calc_times, representations, masks)
        ]
