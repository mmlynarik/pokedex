from typing import Protocol, Self

import pandas as pd

from dbfcore.dataset.signals.protocol import SignalGroupDataFrame

# TODO finalization - move to django

# DataDefinition represents a mapping of signal group strings (SIGNAL_GROUP_REGISTRY keys) to start/end
# timestamps specifying range of data required for given calc_time.
DataDefinition = dict[str, tuple[pd.Timestamp, pd.Timestamp]]

# SignalGroupData represents a mapping of signal group strings (SIGNAL_GROUP_REGISTRY keys) to dataframes
# conforming to rules defined in module dbfcore.dataset.signals.protocol.py
SignalGroupData = dict[str, SignalGroupDataFrame]


class BlastFurnaceModelResult(Protocol):
    """Single prediction from BlastFurnaceModel providing forecast within the forecast horizon"""

    calc_time: pd.Timestamp
    target_signal_name: str

    def to_bytes(self) -> bytes: ...

    @classmethod
    def from_bytes(self, data: bytes, calc_time: pd.Timestamp, *args, **kwargs) -> Self: ...

    def get_predicted_quantiles(
        self, quantiles: list[float], forecast_horizon: pd.Timedelta | None = None
    ) -> pd.DataFrame: ...

    """
    Returned DataFrame should have following structure:
        * index: forecast_time
        * columns: quantile string (e.g. "0.5")
        * data: calculated quantiles for each forecast time

        * example:
        |  (index)                  | 0.05 | 0.5 | 0.95 |
        |:--------------------------|------|-----|------|
        | 2024-11-11 01:00:00+00:00 | 0.5  | 0.6 | 0.7  |
        | 2024-11-11 01:01:00+00:00 | 0.56 | 0.65| 0.73 |
    """

    def get_expected_value(self, forecast_horizon: pd.Timedelta) -> float: ...

    def get_expected_values(self) -> pd.DataFrame: ...

    """
    Returned DataFrame should have following structure:
        * index: forecast_time
        * columns: expected_value
        * data: calculated expected value for each forecast time

        * example:
        |  (index)                  | expected_value |
        |:--------------------------|----------------|
        | 2024-11-11 01:00:00+00:00 |      0.5       |
        | 2024-11-11 01:01:00+00:00 |     0.54       |
    """

    def get_data_availability(self) -> pd.DataFrame: ...

    """
    Returned DataFrame should have following structure:
        * index: integer range
        * columns: ["signal_id", "signal_name", "input_seq_masks", "start", "end"]
        * data:

        * example:
        |  signal_id | signal_name           | input_sequence_masks | start                    | end |
        |:-----------|-----------------------|----------------------|--------------------------|-----|
        | 0          | bf3_topgasco_chem_pct |  Data OK             |2024-11-27 05:55:00+01:00 | ... |
        | 1          | bf3_topgash2_chem_pct |  Data OK             |2024-11-27 05:55:00+01:00 | ... |
        | 2          | bf3_topgasco2_chem_pct|  Data OK             |2024-11-27 05:55:00+01:00 | ... |
    """


class BlastFurnaceModel(Protocol):
    """Prediction model providing batch prediction of given blast furnace signal for given calc times"""

    def get_data_definition(self, calc_time: pd.Timestamp) -> DataDefinition: ...

    def calculate_batch(
        self, data: SignalGroupData, calc_times: list[pd.Timestamp]
    ) -> list[BlastFurnaceModelResult]: ...
