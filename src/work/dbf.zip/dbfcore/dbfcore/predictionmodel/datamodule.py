import logging
import sqlite3
import warnings
from pathlib import Path
from typing import Callable, Optional

import lightning as L
import numpy as np
import pandas as pd
import torch
from attr import define
from torch.utils.data import DataLoader, Dataset

from dbfcore.model.datamodule.pisignal import CalculatedStartTimesDataset, TrainValIntervals


def get_limit_vals(
    time_multiplier: float,
    gradient_multiplier: float,
    calc_times: pd.DatetimeIndex,
    indices: np.ndarray,
    data: pd.DataFrame,
    max_abs_gradient: float,
    val_uncertainity_perc: float,
    time_uncertainity_sec: float,
):
    selected = data.iloc[indices, :].copy()
    selected = selected.set_index(calc_times)
    selected["adj_value"] = selected["value"] * (1 + ((val_uncertainity_perc / 100) * gradient_multiplier))
    selected["limit_position"] = selected["seconds"] + (time_uncertainity_sec * time_multiplier)
    selected["index_seconds"] = selected.index.to_series().apply(lambda dt: dt.timestamp())
    selected["distance"] = abs(selected["index_seconds"] - selected["limit_position"])
    selected["limit_val"] = (selected["distance"] * max_abs_gradient * gradient_multiplier) + selected[
        "adj_value"
    ]
    return selected.limit_val.values


def get_min_estimate_vectorized(
    indices: np.ndarray,
    calc_times: pd.DatetimeIndex,
    calc_df: pd.DataFrame,
    total_minimum: float,
    max_abs_gradient: float,
    val_uncertainity_perc: float,
    time_uncertainity_sec: float,
):
    all_minimums = []

    # Limit should not be affected by data more than 5 measurements away
    for i in range(5):
        clipped_indices = (indices + i).clip(0, len(calc_df) - 1)
        limit_vals = get_limit_vals(
            1.0,
            -1.0,
            calc_times,
            clipped_indices,
            calc_df,
            max_abs_gradient,
            val_uncertainity_perc,
            time_uncertainity_sec,
        )
        if (limit_vals <= total_minimum).all():
            break
        all_minimums.append(limit_vals)

    # Limit should not be affected by data more than 5 measurements away
    for i in range(1, 6):
        clipped_indices = (indices - i).clip(0, len(calc_df) - 1)
        limit_vals = get_limit_vals(
            -1.0,
            -1.0,
            calc_times,
            clipped_indices,
            calc_df,
            max_abs_gradient,
            val_uncertainity_perc,
            time_uncertainity_sec,
        )
        if (limit_vals <= total_minimum).all():
            break
        all_minimums.append(limit_vals)

    if not all_minimums:
        return np.ones(len(indices)) * total_minimum
    return np.column_stack(all_minimums).max(axis=1)


def get_max_estimate_vectorized(
    indices: np.ndarray,
    calc_times: pd.DatetimeIndex,
    calc_df: pd.DataFrame,
    total_maximum: float,
    max_abs_gradient: float,
    val_uncertainity_perc: float,
    time_uncertainity_sec: float,
):
    all_maximums = []

    # Limit should not be affected by data more than 5 measurements away
    for i in range(5):
        clipped_indices = (indices + i).clip(0, len(calc_df) - 1)
        limit_vals = get_limit_vals(
            1.0,
            1.0,
            calc_times,
            clipped_indices,
            calc_df,
            max_abs_gradient,
            val_uncertainity_perc,
            time_uncertainity_sec,
        )
        if (limit_vals >= total_maximum).all():
            break
        all_maximums.append(limit_vals)

    # Limit should not be affected by data more than 5 measurements away
    for i in range(1, 6):
        clipped_indices = (indices - i).clip(0, len(calc_df) - 1)
        limit_vals = get_limit_vals(
            -1.0,
            1.0,
            calc_times,
            clipped_indices,
            calc_df,
            max_abs_gradient,
            val_uncertainity_perc,
            time_uncertainity_sec,
        )
        if (limit_vals >= total_maximum).all():
            break
        all_maximums.append(limit_vals)

    if not all_maximums:
        return np.ones(len(indices)) * total_maximum
    return np.column_stack(all_maximums).min(axis=1)


def load_target_and_calculate_extremes(
    orig_data_path: Path,
    start: pd.Timestamp,
    end: pd.Timestamp,
    step: pd.Timedelta,
    value_minimum: float,
    value_maximum: float,
    total_minimum: float,
    total_maximum: float,
    max_abs_gradient: float,
    val_uncertainity_perc: float,
    time_uncertainity_sec: float,
):
    chem_data = pd.read_parquet(orig_data_path).set_axis(["value"], axis=1)
    # TODO move this to preprocessing
    chem_data = chem_data.clip(value_minimum, value_maximum)

    chem_data["seconds"] = chem_data.index.to_series().apply(lambda dt: dt.timestamp())
    chem_data = chem_data.dropna()

    times = pd.date_range(start, end, freq=step, inclusive="left")
    indices = chem_data.index.searchsorted(times)

    maximums = get_max_estimate_vectorized(
        indices,
        times,
        chem_data,
        total_maximum,
        max_abs_gradient,
        val_uncertainity_perc,
        time_uncertainity_sec,
    )
    minimums = get_min_estimate_vectorized(
        indices,
        times,
        chem_data,
        total_minimum,
        max_abs_gradient,
        val_uncertainity_perc,
        time_uncertainity_sec,
    )

    step_index = chem_data.set_index(chem_data.index.floor(step))
    step_index = step_index[~step_index.index.duplicated(keep=False)]

    merged = pd.merge(pd.DataFrame(index=times), step_index, left_index=True, right_index=True, how="left")

    merged["minimum"] = minimums
    merged["maximum"] = maximums

    merged = merged.drop("seconds", axis=1).set_index(
        merged.index.to_series(name="Timestamp").apply(lambda dt: dt.timestamp())
    )

    #######
    # This is to cover everything outside "possible" gradient range - i.e. extremely large volatility
    merged2 = pd.merge(pd.DataFrame(index=times), step_index, left_index=True, right_index=True, how="left")
    merged2["minimum"] = merged2["value"] * (1 - ((val_uncertainity_perc / 100)))
    merged2["maximum"] = merged2["value"] * (1 + ((val_uncertainity_perc / 100)))
    merged2 = merged2.interpolate("linear")
    merged2 = merged2.bfill()
    merged2 = merged2.drop("seconds", axis=1).set_index(
        merged2.index.to_series(name="Timestamp").apply(lambda dt: dt.timestamp())
    )

    #######

    merged3 = merged.copy()
    merged3["minimum"] = np.column_stack([merged["minimum"].values, merged2["minimum"].values]).min(axis=1)
    merged3["maximum"] = np.column_stack([merged["maximum"].values, merged2["maximum"].values]).max(axis=1)

    return merged3


@define(slots=False, frozen=True)
class InputSignalDefinition:
    path_to_embeddings: str
    name: str
    # Difference embeddings start_time - prediction now
    start_time_offset_sec: int


@define(slots=False, frozen=True)
class TargetSignal:
    name: str
    data_path: str
    value_minimum: float
    value_maximum: float
    total_minimum: float
    total_maximum: float
    max_abs_gradient: float
    val_uncertainity_perc: float
    time_uncertainity_sec: float


class InputEmbeddingsDataset(Dataset):
    def __init__(
        self,
        sqlite_path: Path,
        prediction_times: CalculatedStartTimesDataset,
        input_data: tuple[InputSignalDefinition, ...],
    ):
        self.database_path = sqlite_path
        self.db_connection: Optional[sqlite3.Connection] = None
        self.input_definiton = input_data
        self.prediction_times = prediction_times
        self.query_template = "SELECT * FROM {} WHERE start_times = {};"
        self.embedding_columns_query_template = "pragma table_info({});"

    def get_connection(self) -> sqlite3.Connection:
        if self.db_connection is None:
            # Open connection in readonly mode
            self.db_connection = sqlite3.connect(f"file:{self.database_path}?mode=ro", uri=True)
        return self.db_connection

    def get_input_embedding(self, signal_name, now_timestamp):
        query = self.query_template.format(signal_name, now_timestamp)
        cur = self.get_connection().cursor()
        cur.execute(query)
        row = cur.fetchone()
        if row:
            # Indexes in database are as following:
            # First column is start time
            # Last column [-1] is mask
            # All others in the middle [1:-1] are parts of embedding
            x = torch.tensor(row[1:-1])
            mask = torch.ones_like(x, dtype=torch.bool) * bool(row[-1])
            return x, mask
        else:
            cur = self.get_connection().cursor()
            cur.execute(self.embedding_columns_query_template.format(signal_name))
            all_rows = cur.fetchall()
            embedding_size = len(all_rows) - 2

            return torch.zeros(embedding_size), torch.zeros(embedding_size, dtype=torch.bool)

    def __len__(self):
        return len(self.prediction_times)

    def __getitem__(self, idx: int) -> tuple[float, torch.Tensor, torch.Tensor]:
        now = self.prediction_times[idx]
        embs = [
            self.get_input_embedding(signal.name, now + signal.start_time_offset_sec)
            for signal in self.input_definiton
        ]
        return now, torch.cat([e[0] for e in embs]), torch.cat([e[1] for e in embs])


class TargetWithExtremesSQLiteDatasource:
    def __init__(self, database_path: Path, table_name: str):
        if not database_path.exists():
            raise ValueError(f"SQLite database on path {database_path} does not exist.")
        self.db_connection: Optional[sqlite3.Connection] = None
        self.database_path = database_path
        self.query_template = f"SELECT * FROM {table_name} WHERE Timestamp >= {{}} AND Timestamp <= {{}} ORDER BY Timestamp ASC;"

    def get_connection(self) -> sqlite3.Connection:
        if self.db_connection is None:
            # Open connection in readonly mode
            self.db_connection = sqlite3.connect(f"file:{self.database_path}?mode=ro", uri=True)
        return self.db_connection

    def get_data_in_interval(self, start: float, end: float) -> pd.DataFrame:
        query = self.query_template.format(start, end)
        return pd.read_sql(
            query,
            self.get_connection(),
            index_col="Timestamp",
            dtype={"value": "float64", "minimum": "float64", "maximum": "float64"},
        )


# We will never consider values older than 24h as an input to the model
# Currently it will affect Si and Temp measurements both of which are irelevant after the 24h
MAX_LAST_MEASURED_VALUE_OFFSET_SEC = float(24 * 60 * 60)


def create_zero_one_normalizer_with_clamping(min_value: float, max_value: float):
    value_range = max_value - min_value

    def normalizer(values: torch.Tensor) -> torch.Tensor:
        return ((values - min_value) / value_range).clamp(0.0, 1.0)

    return normalizer


def get_last_value_with_offset_before(
    data: pd.DataFrame,
    value_column: str,
    timestamp: pd.Timestamp | float,
    value_normalizer: Callable[[torch.Tensor], torch.Tensor],
):
    """Get last value before timestamp specified together with its offset from timestamp specified"""
    last_measurement = data.loc[:timestamp].dropna().tail(1)  # type: ignore
    if not last_measurement.empty:
        last_value = last_measurement.iloc[0][value_column]
        last_timestamp = last_measurement.iloc[0].name
        offset = timestamp - last_timestamp
        if isinstance(timestamp, pd.Timestamp):
            offset = offset.total_seconds()
    else:
        last_value = 0.0
        offset = MAX_LAST_MEASURED_VALUE_OFFSET_SEC

    normalized_last_value = value_normalizer(torch.tensor(last_value))
    # maximal considered offset is 24h - everything earlier is considered irrelevant
    # code below ensures this condition with maximum normalized value 6.0 - see examples below
    # - offset is MAX_LAST_MEASURED_VALUE_OFFSET_SEC / 2 - normalized offset will be 3.0
    # - offset is MAX_LAST_MEASURED_VALUE_OFFSET_SEC - normalized offset will be 6.0
    # - offset is MAX_LAST_MEASURED_VALUE_OFFSET_SEC * 2 - normalized offset will be 6.0
    # so normalization below push offset to range 0.0 - 6.0 capped by MAX_LAST_MEASURED_VALUE_OFFSET_SEC
    normalized_offset = torch.nn.functional.relu6(
        torch.tensor((offset * 6.0) / (MAX_LAST_MEASURED_VALUE_OFFSET_SEC))
    )

    return torch.stack((normalized_last_value, normalized_offset))


class PredictionModelDataset(Dataset):
    def __init__(
        self,
        input_data: InputEmbeddingsDataset,
        future_data: InputEmbeddingsDataset,
        target_data: TargetWithExtremesSQLiteDatasource,
        forecast_horizon: pd.Timedelta,
        min_value: float,
        max_value: float,
        items_count: int,
    ):
        self.input_data = input_data
        self.future_data = future_data
        self.target_data = target_data
        self.forecast_horizon_sec = forecast_horizon.total_seconds()
        self.normalize = create_zero_one_normalizer_with_clamping(min_value, max_value)
        self.max_time_value = self.forecast_horizon_sec
        self.items_count = items_count

        if self.items_count < 2:
            raise ValueError(
                "Items count need to be at least 2 - one for measurement in zero time, second for real data"
            )

    def __len__(self) -> int:
        return len(self.input_data)

    def __getitem__(self, idx: int) -> tuple[
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
        torch.Tensor,
    ]:
        now_timestamp, input_tensor, input_mask = self.input_data[idx]
        now_timestamp2, future_tensor, future_mask = self.future_data[idx]

        if now_timestamp != now_timestamp2:
            raise Exception("Inconsistent timestamps")

        start_timestamp = now_timestamp - MAX_LAST_MEASURED_VALUE_OFFSET_SEC
        end_timestamp = now_timestamp + self.forecast_horizon_sec

        all_data = self.target_data.get_data_in_interval(start_timestamp, end_timestamp)
        data = all_data.loc[now_timestamp:]  # type: ignore

        data_with_values = data.dropna()

        remaining_count = self.items_count
        all_to_concat = []

        if remaining_count > 0:
            # First
            all_to_concat.append(data.iloc[0:1])
            remaining_count -= 1

        if len(data_with_values) > remaining_count:
            data_with_values = data_with_values.sample(remaining_count, replace=False)

        remaining_count = remaining_count - len(data_with_values)
        all_to_concat.append(data_with_values)

        if remaining_count > 0:
            # Last
            all_to_concat.append(data.iloc[-1:])
            remaining_count -= 1
        # remaining random
        if remaining_count > 0:
            offsets = np.random.rand(remaining_count) * self.forecast_horizon_sec
            tested_times = offsets + now_timestamp
            nans = np.zeros_like(tested_times) * np.nan
            nans_df = pd.DataFrame(
                {"Timestamp": tested_times, "value": nans, "minimum": nans, "maximum": nans}
            ).set_index("Timestamp")
            sorted_with_nans = pd.concat([nans_df, data]).sort_index()
            sorted_without_nans = sorted_with_nans.interpolate("linear")
            selected_random_times_data = sorted_without_nans.loc[tested_times]
            selected_random_times_data["value"] = np.nan

            all_to_concat.append(selected_random_times_data)

        data_with_values = pd.concat(all_to_concat)
        data_with_values = data_with_values.sort_index()

        measured_values = torch.Tensor(data_with_values["value"].fillna(0.0).values).reshape(-1)
        measured_mask = torch.Tensor(data_with_values["value"].notnull().values).reshape(-1)

        min_values = torch.Tensor(data_with_values["minimum"].fillna(0.0).values)
        max_values = torch.Tensor(data_with_values["maximum"].fillna(1.0).values)

        if ((min_values - max_values) >= 0).any():
            raise Exception(f"Min should be smaller than max {idx}")

        eval_points = torch.Tensor(data_with_values.index.values - now_timestamp)

        return (
            input_tensor * input_mask,
            future_tensor * future_mask,
            eval_points[: self.items_count],
            self.normalize(measured_values)[: self.items_count],
            measured_mask[: self.items_count],
            self.normalize(min_values)[: self.items_count],
            self.normalize(max_values)[: self.items_count],
            get_last_value_with_offset_before(all_data, "value", now_timestamp, self.normalize).to(
                input_tensor.dtype
            ),
        )


def get_row_count(connection: sqlite3.Connection, table_name: str) -> int:
    try:
        return connection.cursor().execute(f"SELECT COUNT(*) FROM {table_name};").fetchone()[0]
    except sqlite3.OperationalError as e:
        if str(e).startswith("no such table"):
            return 0
        raise


def get_embeddings_dataframe(embeddings_path: str, signal_name: str) -> pd.DataFrame:
    full_embeddings = torch.load(embeddings_path)
    signal_idx = [y["signal_name"] for y in full_embeddings["signal_normalizers_params"]].index(signal_name)
    selection_mask = full_embeddings["indices"] == signal_idx
    df = pd.DataFrame(full_embeddings["embeddings"][selection_mask])
    df["masks"] = full_embeddings["masks"][selection_mask]
    df["start_times"] = full_embeddings["start_times"][selection_mask]
    return df.set_index("start_times")


class PredictionModelDataModule(L.LightningDataModule):
    def __init__(
        self,
        input_signals: tuple[InputSignalDefinition, ...],
        future_signals: tuple[InputSignalDefinition, ...],
        target_signal: TargetSignal,
        forecast_horizon: str,
        train_val_split: TrainValIntervals,
        sqlite_database_path: str,
        batch_size: int = 32,
        items_count: int = 32,
        num_workers: int = 0,
        shuffle_train: bool = True,
        shuffle_val: bool = False,
        prefetch_factor: Optional[int] = None,
        pin_memory: bool = False,
    ):
        super().__init__()
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.input_signals = input_signals
        self.future_signals = future_signals
        self.target_signal = target_signal
        self.forecast_horizon = pd.Timedelta(forecast_horizon)
        self.train_val_split = train_val_split
        self.items_count = items_count
        self.shuffle_train = shuffle_train
        self.shuffle_val = shuffle_val
        self.prefetch_factor = prefetch_factor
        self.pin_memory = pin_memory

        self.all_signals = [*input_signals, *future_signals]
        logging.info(
            f"PredictionModelDataModule for input signals {[signal.name for signal in self.all_signals]}"
        )
        logging.info(f"PredictionModelDataModule for target signal {target_signal.name}")
        logging.info(f"PredictionModelDataModule forecast horizon: {self.forecast_horizon}")
        logging.info(f"PredictionModelDataModule batch_size: {self.batch_size}")
        logging.info(f"PredictionModelDataModule num workers: {self.num_workers}")

        self.sqlite_path = Path(sqlite_database_path)
        logging.info(f"SQLite data source will be used with db on path: {self.sqlite_path}")
        if self.sqlite_path.exists():
            logging.info(
                "SQLite data source already exists. "
                + "Signals with same name will not be reimported to database."
                + "If you changed underlying data you need to delete database file manually"
            )

        if not self.shuffle_train:
            warnings.warn(
                "PredictionModelDataModule training shuffle is turned off.\n"
                + "It is recommended to have it on if you are not doing something special."
            )
        if self.shuffle_val:
            warnings.warn(
                "PredictionModelDataModule validation shuffle is turned on.\n"
                + "It is recommended to have it off if you are not doing something special."
            )

        for signal in self.all_signals:
            path_to_emb = Path(signal.path_to_embeddings)
            if not path_to_emb.exists():
                raise FileNotFoundError(
                    f"{signal.name} signal cached file not found on path {path_to_emb}.\n"
                    + "Please use `get_embeddings` script to generate it first."
                )
        target_signal_path = Path(target_signal.data_path)
        if not target_signal_path.exists():
            raise FileNotFoundError(
                f"{target_signal.name} target signal cached file not found on path {target_signal_path}.\n"
                + "Please use `generate_signal_dataframe` script to generate it first."
            )

    def import_input_signals_data_to_database(self, data: pd.DataFrame, signal_name: str):
        logging.info(f"Importing data to sqlite database for input signal {signal_name}")
        db_connection = sqlite3.connect(f"file:{self.sqlite_path}", uri=True)
        current_row_count = get_row_count(db_connection, signal_name)
        logging.info(f"Current row count for {signal_name} is {current_row_count}.")
        logging.info(f"Row count of data to be imported: {len(data)}")
        if current_row_count != len(data):
            logging.info("Importing data - old data in database (if any) will be replaced")
            data.to_sql(signal_name, db_connection, chunksize=1000, if_exists="replace")
        else:
            logging.info("Data in database have same length as new data - new data will NOT be imported")
            logging.info("If it is coincidence and data changed please delete database file manually")

    def import_target_signal_data_to_database(self):
        eval_step_str = "1min"
        target_table_name = (
            f"{self.target_signal.name}_{eval_step_str}_"
            + f"{int(self.train_val_split.train_start_ts.timestamp())}_"
            + f"{int(self.train_val_split.val_end_ts.timestamp())}"
        )

        logging.info(f"Checking database for table {target_table_name}")
        db_connection = sqlite3.connect(f"file:{self.sqlite_path}", uri=True)
        current_row_count = get_row_count(db_connection, target_table_name)
        logging.info(f"Current row count for {target_table_name} is {current_row_count}.")

        if current_row_count > 0:
            logging.info(
                "Assuming extremes for target are calculated.\n"
                + f" If you want to recalculate please delete table {target_table_name}"
            )
        else:
            logging.info("Calculating extremes")
            target_data = load_target_and_calculate_extremes(
                Path(self.target_signal.data_path),
                self.train_val_split.train_start_ts,
                self.train_val_split.val_end_ts,
                pd.Timedelta(eval_step_str),
                self.target_signal.value_minimum,
                self.target_signal.value_maximum,
                self.target_signal.total_minimum,
                self.target_signal.total_maximum,
                self.target_signal.max_abs_gradient,
                self.target_signal.val_uncertainity_perc,
                self.target_signal.time_uncertainity_sec,
            )

            logging.info(f"Row count of data to be imported: {len(target_data)}")
            logging.info("Importing data - old data in database (if any) will be replaced")

            target_data.to_sql(target_table_name, db_connection, chunksize=1000, if_exists="replace")
        return target_table_name

    def setup(self, stage: str):
        for input_signal in self.all_signals:
            data = get_embeddings_dataframe(input_signal.path_to_embeddings, input_signal.name)
            self.import_input_signals_data_to_database(data, input_signal.name)

        target_table_name = self.import_target_signal_data_to_database()

        train_start_times = CalculatedStartTimesDataset(
            self.train_val_split.train_start_ts,
            self.train_val_split.train_end_ts,
            self.train_val_split.step_timedelta,
            self.forecast_horizon,
            self.train_val_split.train_size_limit,
        )

        val_start_times = CalculatedStartTimesDataset(
            self.train_val_split.val_start_ts,
            self.train_val_split.val_end_ts,
            self.train_val_split.step_timedelta,
            self.forecast_horizon,
            self.train_val_split.val_size_limit,
        )

        target_with_extremes = TargetWithExtremesSQLiteDatasource(self.sqlite_path, target_table_name)

        self.train_emb_dataset = InputEmbeddingsDataset(
            self.sqlite_path, train_start_times, self.input_signals
        )
        self.val_emb_dataset = InputEmbeddingsDataset(self.sqlite_path, val_start_times, self.input_signals)

        self.train_future_emb_dataset = InputEmbeddingsDataset(
            self.sqlite_path, train_start_times, self.future_signals
        )
        self.val_future_emb_dataset = InputEmbeddingsDataset(
            self.sqlite_path, val_start_times, self.future_signals
        )

        self.train_dataset = PredictionModelDataset(
            self.train_emb_dataset,
            self.train_future_emb_dataset,
            target_with_extremes,
            self.forecast_horizon,
            self.target_signal.total_minimum,
            self.target_signal.total_maximum,
            self.items_count,
        )

        self.val_dataset = PredictionModelDataset(
            self.val_emb_dataset,
            self.val_future_emb_dataset,
            target_with_extremes,
            self.forecast_horizon,
            self.target_signal.total_minimum,
            self.target_signal.total_maximum,
            self.items_count,
        )

        logging.info(f"Train dataset length: {len(self.train_dataset)}")
        logging.info(f"Val dataset length: {len(self.val_dataset)}")

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle_train,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
            prefetch_factor=self.prefetch_factor,
            pin_memory=self.pin_memory,
            drop_last=True,
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle_val,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
            prefetch_factor=self.prefetch_factor,
            pin_memory=self.pin_memory,
            drop_last=True,
        )
