import numpy as np
import pandas as pd


def clean_burden_drop_data(data: pd.DataFrame, timedelta_threshold: pd.Timedelta) -> pd.DataFrame:
    data = data.iloc[1:-1]  # remove first and last row of signal data
    time = data.index
    end_of_segment = time.to_series().diff() > timedelta_threshold

    # rows to remove are the ones where end_of_segment is True (first row of segment)
    # and the row before that (last row of segment before)
    # the derivation at these points does not make sense or can improperly affect the correctness of the data
    rows_to_remove = end_of_segment | end_of_segment.shift(-1)
    return data[~rows_to_remove]


def preprocess_burden_drop_data(
    data: pd.DataFrame,
    timedelta_threshold: pd.Timedelta = pd.Timedelta(seconds=100),
    lower_gradient_threshold: int = 0,
    upper_gradient_threshold: int = 1,
) -> pd.DataFrame:
    # The default value of timedelta_threshold parameter was set on the basis of stockrod data
    # where the time differences between two segments were from 100 or more seconds
    # The default value gradient_threshold parameter is 0, which is set to ensure
    # that the gradient is non-negative and thus the function is non-decreasing.
    cleaned_data = clean_burden_drop_data(data, timedelta_threshold)
    return cleaned_data[
        (cleaned_data["gradient"] >= lower_gradient_threshold)
        & (cleaned_data["gradient"] < upper_gradient_threshold)
    ]


def count_gradient(data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
    time = data.index.to_series().apply(lambda dt: dt.timestamp())
    return pd.DataFrame(
        index=data.index,
        data=np.gradient(data[signal_name], time),
        columns=["gradient"],
    )
