import attrs
import pandas as pd

from dbfcore.dataset.hooks.azvp_hook import AZVPHook
from dbfcore.dataset.hooks.hook_config import (
    get_azvp_config_from_env,
    get_oko_config_from_env,
    get_pi_config_from_env,
    get_pvis_config_from_env,
    get_pzvp_config_from_env,
    get_scada_config_from_env,
)
from dbfcore.dataset.hooks.oko_hook import OkoHook
from dbfcore.dataset.hooks.pi_hook import PIHook
from dbfcore.dataset.hooks.piclient import PiClient, get_pi_client
from dbfcore.dataset.hooks.pvis_hook import PvisHook
from dbfcore.dataset.hooks.pzvp_hook import PZVPHook
from dbfcore.dataset.hooks.scada_hook import ScadaHook
from dbfcore.settings import BFILL_TIME_BOUNDARY_FOR_SOURCE

VPHook = AZVPHook | PZVPHook


def get_azvp_hook() -> AZVPHook:
    return AZVPHook(get_azvp_config_from_env())


def get_pzvp_hook() -> PZVPHook:
    return PZVPHook(get_pzvp_config_from_env())


def get_scada_hook() -> ScadaHook:
    return ScadaHook(get_scada_config_from_env())


def get_oko_hook() -> OkoHook:
    return OkoHook(get_oko_config_from_env())


def get_pi_hook() -> PIHook:
    return PIHook(get_pi_config_from_env())


def get_pvis_hook() -> PvisHook:
    return PvisHook(get_pvis_config_from_env())


# TODO make datasources lazy
@attrs.define(slots=False, frozen=True)
class DataSources:
    azvp: AZVPHook
    pzvp: PZVPHook
    pi: PiClient
    scada: ScadaHook
    oko: OkoHook
    pvis: PvisHook

    def get_vp_hook(self, calc_time: pd.Timestamp, now: pd.Timestamp) -> VPHook:
        calc_time_diff = now - calc_time
        return self.pzvp if calc_time_diff < BFILL_TIME_BOUNDARY_FOR_SOURCE else self.azvp


def get_datasources_configured_with_env() -> DataSources:
    return DataSources(
        get_azvp_hook(), get_pzvp_hook(), get_pi_client(), get_scada_hook(), get_oko_hook(), get_pvis_hook()
    )
