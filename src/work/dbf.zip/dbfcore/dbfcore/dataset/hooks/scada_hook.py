from datetime import datetime
from typing import Protocol

import pandas as pd

from dbfcore.dataset.hooks.base_hook import OracleHook
from dbfcore.dataset.raw_dataset.utils import split_into_chunks, utc_to_local


def get_bind_names_for_tapping_ids(length: int) -> str:
    return ", ".join(":tid" + str(i + 1) for i in range(length))


def get_bind_names_for_delivery_ids(length: int) -> str:
    return ", ".join(":did" + str(i + 1) for i in range(length))


class ScadaDbDataSelector(Protocol):
    def get_outgoing_deliveries_from_blast_furnace(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_incoming_deliveries_for_steelshop(self, start: datetime, end: datetime) -> pd.DataFrame: ...


class ScadaHook(OracleHook):
    def get_outgoing_deliveries_from_blast_furnace(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                CIS_DOD as delivery_id,
                CIS_MIESACA as mixer_id,
                CIS_ODP1_ROK as tapping_id_1,
                CIS_ODP2_ROK as tapping_id_2,
                CAS_VYPR_MIES,
                ZAC_PLN_MIES,
                KON_PLN_MIES,
                CIS_ODP1 as tapping_number_1,
                HMOTN_ODP1,
                KVALITA1,
                ZAC_ODP1,
                KON_ODP1,
                CIS_ODP2 as tapping_number_2,
                HMOTN_ODP2,
                KVALITA2,
                ZAC_ODP2,
                KON_ODP2,
                TEPLOTA_SZ,
                ANA_C_WA,
                ANA_MN_WA,
                ANA_SI_WA,
                ANA_P_WA,
                ANA_S_WA,
                ANA_AS_WA,
                ANA_PB_WA,
                ANA_ZN_WA,
                ANA_TI_WA,
                MIESAC_POC_NAL,
                MIESAC_PREVEZENE_FE,
                ZAC_VYL1,
                KON_VYL1,
                ZAC_VYL2,
                KON_VYL2,
                ZAC_VYL3,
                KON_VYL3,
                ZAC_VYL4,
                KON_VYL4,
                MIES_VYPRAZDNENY_OC
            FROM
                DBOC.V_ODS_DODAVKY_VP
            WHERE
                CAS_VYPR_MIES between :start_date AND :end_date
            ORDER BY
                CAS_VYPR_MIES
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
                dtype={"tapping_id_1": int},
            )

    def get_outgoing_deliveries_from_blast_furnace_by_tapping_id_1(
        self, tapping_ids: list[int]
    ) -> pd.DataFrame:
        output = []
        for chunk in split_into_chunks(tapping_ids):
            query = """
                SELECT
                    CIS_DOD as delivery_id,
                    CIS_MIESACA as mixer_id,
                    CIS_ODP1_ROK as tapping_id,
                    ZAC_PLN_MIES as mixer_fill_start_date,
                    KON_PLN_MIES as mixer_fill_end_date,
                    HMOTN_ODP1 as estimated_weight_from_tapping
                FROM
                    DBOC.V_ODS_DODAVKY_VP
                WHERE
                    CIS_ODP1_ROK in (%s)
                ORDER BY
                    CAS_VYPR_MIES
            """ % (
                get_bind_names_for_tapping_ids(len(chunk))
            )
            with self.engine.begin() as conn:
                df = pd.read_sql(
                    query,
                    conn,
                    params={**{f"tid{idx+1}": tid for idx, tid in enumerate(chunk)}},
                    dtype={"tapping_id": int},
                )
            output.append(df)
        return pd.concat(output)

    def get_outgoing_deliveries_from_blast_furnace_by_tapping_id_2(
        self, tapping_ids: list[int]
    ) -> pd.DataFrame:
        output = []
        for chunk in split_into_chunks(tapping_ids):
            query = """
                SELECT
                    CIS_DOD as delivery_id,
                    CIS_MIESACA as mixer_id,
                    CIS_ODP2_ROK as tapping_id,
                    ZAC_PLN_MIES as mixer_fill_start_date,
                    KON_PLN_MIES as mixer_fill_end_date,
                    HMOTN_ODP2 as estimated_weight_from_tapping
                FROM
                    DBOC.V_ODS_DODAVKY_VP
                WHERE
                    CIS_ODP2_ROK in (%s)
                ORDER BY
                    CAS_VYPR_MIES
            """ % (
                get_bind_names_for_tapping_ids(len(chunk))
            )
            with self.engine.begin() as conn:
                df = pd.read_sql(
                    query,
                    conn,
                    params={**{f"tid{idx+1}": tid for idx, tid in enumerate(chunk)}},
                    dtype={"tapping_id": int},
                )
            output.append(df)
        return pd.concat(output)

    def get_incoming_deliveries_for_steelshop(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                DATUM as "date",
                OCELIAREN as steelshop,
                CISTAVBY as heat_number,
                CISPANVY as ladle,
                AKOST as grade_id,
                CIS_DOD1 as delivery_id_1,
                CIS_DOD2 as delivery_id_2,
                CIS_MIES1 as mixer_id_1,
                CIS_MIES2 as mixer_id_2,
                HMOTN_MIES1 as mixer_weight_1,
                HMOTN_MIES2 as mixer_weight_2,
                HMOTN_SUZE as pig_iron_weight
            FROM
                DBOC.v_ods_data
            WHERE
                DATUM between :start_date AND :end_date
            ORDER BY
                DATUM
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
                parse_dates=["date"],
                dtype={"heat_number": int},
            ).assign(heat_id=lambda df: df["heat_number"] * 10000 + df["date"].dt.year)

    def get_incoming_deliveries_for_steelshop_by_delivery_id_1(self, delivery_ids: list[int]) -> pd.DataFrame:
        output = []
        for chunk in split_into_chunks(delivery_ids):
            query = """
                SELECT
                    DATUM as heat_start_date,
                    OCELIAREN as steelshop,
                    CISTAVBY * 10000 + extract(year from DATUM) as heat_id,
                    CIS_DOD1 as delivery_id,
                    HMOTN_MIES1 as weight_from_mixer,
                    HMOTN_SUZE as pig_iron_weight,
                    ZAC_VYL_MIES_1 as mixer_offload_start_date,
                    KON_VYL_MIES_1 as mixer_offload_end_date
                FROM
                    DBOC.v_ods_data
                WHERE
                    CIS_DOD1 in (%s)
                ORDER BY
                    DATUM
            """ % (
                get_bind_names_for_delivery_ids(len(chunk))
            )
            with self.engine.begin() as conn:
                df = pd.read_sql(
                    query,
                    conn,
                    params={**{f"did{idx+1}": did for idx, did in enumerate(chunk)}},
                    parse_dates=["mixer_offload_start_date", "mixer_offload_end_date"],
                    dtype={"heat_id": int},
                )
            output.append(df)
        return pd.concat(output)

    def get_incoming_deliveries_for_steelshop_by_delivery_id_2(self, delivery_ids: list[int]) -> pd.DataFrame:
        output = []
        for chunk in split_into_chunks(delivery_ids):
            query = """
                SELECT
                    DATUM as heat_start_date,
                    OCELIAREN as steelshop,
                    CISTAVBY * 10000 + extract(year from DATUM) as heat_id,
                    CIS_DOD2 as delivery_id,
                    HMOTN_MIES2 as weight_from_mixer,
                    HMOTN_SUZE as pig_iron_weight,
                    ZAC_VYL_MIES_2 as mixer_offload_start_date,
                    KON_VYL_MIES_2 as mixer_offload_end_date
                FROM
                    DBOC.v_ods_data
                WHERE
                    CIS_DOD2 in (%s)
                ORDER BY
                    DATUM
            """ % (
                get_bind_names_for_delivery_ids(len(chunk))
            )
            with self.engine.begin() as conn:
                df = pd.read_sql(
                    query,
                    conn,
                    params={**{f"did{idx+1}": did for idx, did in enumerate(chunk)}},
                    parse_dates=["mixer_offload_start_date", "mixer_offload_end_date"],
                    dtype={"heat_id": int},
                )
            output.append(df)
        return pd.concat(output)

    def get_two_mixers_one_delivery_error_heats(self) -> pd.DataFrame:
        query = """
            SELECT
                DATUM as heat_start_date,
                OCELIAREN as steelshop,
                CISTAVBY * 10000 + extract(year from DATUM) as heat_id
            FROM
                DBOC.v_ods_data
            WHERE
                (CIS_DOD1 = 0 or CIS_DOD2 = 0) and (CIS_MIES1 > 0 and CIS_MIES2 > 0)
        """
        with self.engine.begin() as conn:
            return pd.read_sql(query, conn, parse_dates=["heat_start_date"], dtype={"heat_id": int})

    def get_misaligned_mixer_weights_error_heats(self) -> pd.DataFrame:
        query = """
            SELECT
                DATUM as heat_start_date,
                OCELIAREN as steelshop,
                CISTAVBY * 10000 + extract(year from DATUM) as heat_id
            FROM
                DBOC.v_ods_data
            WHERE
                HMOTN_MIES1 + HMOTN_MIES2 != HMOTN_SUZE
        """
        with self.engine.begin() as conn:
            return pd.read_sql(query, conn, parse_dates=["heat_start_date"], dtype={"heat_id": int})

    def get_data_for_scrap_weight_forecast(self, start_date: datetime):
        query = """
        SELECT
            tha.STEELSHOP,
            tha.PLANT,
            tha.HEATSTEP,
            tha.HEATNO,
            tha.RELEASE_TIME,
            tha.HEAT_TIME,
            tha.AKOST,
            tha.SROT_VAHA,
            tha.T_SUZE,
            tha.HMOTN_SUZE,
            COALESCE(tha.PELETY_MOD, 0) AS pelety_mod,
            COALESCE(tha.PELETY_SET, 0) AS pelety_set,
            COALESCE(tha.PELETY_SKUT, 0) AS pelety_skut,
            COALESCE(tha.BRIKETY_MOD , 0) AS brikety_mod,
            COALESCE(tha.BRIKETY_SET , 0) AS brikety_set,
            COALESCE(tha.BRIKETY_SKUT , 0) AS brikety_skut,
            COALESCE(tha.VAPENEC_MOD , 0) AS vapenec_mod,
            COALESCE(tha.VAPENEC_SET , 0) AS vapenec_set,
            COALESCE(tha.VAPENEC_SKUT , 0) AS vapenec_skut,
            COALESCE(tha.O2_DOFUK_SKUT, 0) AS o2_dofuk_skut,
            COALESCE(tha.O2_DOFUK_KOD, 0) AS o2_dofuk_kod,
            COALESCE(tha.O2_DOFUK_PRIC,0) AS o2_dofuk_pricina,
            tha.T_SET_1VKK,
            tha.T_SKUT_1VKK, thaa.SMER
        FROM
            dboc.T_HEAT_APX tha
        INNER JOIN
            dboc.T_HEAT_APX_ANALYSES thaa
        ON
            tha.HEATSTEP = thaa.HEATSTEP
        WHERE
            tha.HEAT_TIME > :start_date
        ORDER
            BY tha.HEAT_TIME ASC
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start_date)},
                parse_dates=["release_time", "heat_time"],
                dtype={"heatno": int},
            ).assign(heat_id=lambda df: df["heatno"] * 10000 + df["heat_time"].dt.year)
