from datetime import datetime, timedelta
from typing import Optional, Protocol

import pandas as pd

from dbfcore.dataset.hooks.base_hook import OracleHook
from dbfcore.dataset.hooks.queries import (
    get_min_most_recent_analysis_date_query,
    get_pig_iron_analysis_query,
    get_raw_material_analysis_query,
    get_raw_material_charge_extended_end_date_query,
    get_raw_material_charge_extended_start_date_query,
    get_raw_material_charge_query,
    get_raw_material_charge_summary_query,
    get_sinter_analysis_query,
)
from dbfcore.dataset.raw_dataset.utils import local_naive_to_utc, utc_to_local


class AZVPDbDataSelector(Protocol):
    def get_sensors_for_bf1_5min_section_21(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_sensors_for_bf1_5min_section_11(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_sensors_for_bf1_5min_section_31(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_qpu_analysis(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_sinter_analysis(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_raw_material_analysis(
        self, start: datetime, end: datetime, raw_material_numbers: set[int]
    ) -> pd.DataFrame: ...

    def get_raw_material_charge(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_raw_material_charge_summary(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame: ...

    def get_tapping_start_end_datetimes(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame: ...

    def get_tapping_ids_from_all_furnaces(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_pig_iron_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_slag_weights(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_slag_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_granulometry(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...


class AZVPHook(OracleHook):
    def get_sensors_for_bf1_5min_section_21(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                DATUM AS "sensors_date",
                ID56 AS "pokhv",
                ID57 AS "pokvlh",
                ID61 AS "pokexa",
                ID62 AS "pokexb",
                ID63 AS "pokexc",
                ID64 AS "pokexd",
                ID136 AS "qvsk",
                ID180 AS "o2v",
                ID187 AS "wv",
                ID190 AS "qpu",
                ID191 AS "s_ko",
                ID188 AS "tth"
            FROM
                EKONOM.VP1_5MIN_ARCH f
            WHERE
                POR = 21
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
            )

    def get_sensors_for_bf1_5min_section_11(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                DATUM AS "sensors_date",
                ID69 AS "qzpc",
                ID88 AS "qpua",
                ID89 AS "qpub",
                ID101 AS "qv",
                ID125 AS "qw",
                ID138 AS "qo2",
                ID158 AS "pos",
                ID198 AS "tv",
                ID207 AS "qcvp",
                ID62 AS "ps",
                ID135 AS "co",
                ID136 AS "co2",
                ID137 AS "h2"
            FROM
                EKONOM.VP1_5MIN_ARCH
            WHERE
                POR = 11
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
            )

    def get_sensors_for_bf1_5min_section_31(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                DATUM AS "sensors_date",
                ID100 AS "tkp"
            FROM
                EKONOM.VP1_5MIN_ARCH
            WHERE
                POR = 31
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
            )

    def get_qpu_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        qpu_analysis_number = 38
        query = """
            SELECT
                DATUM AS "qpu_analysis_date",
                AL2O3 AS "qpu_al2o3_pct",
                ARS AS "qpu_ars_pct",
                C AS "qpu_c_pct",
                CAO AS "qpu_cao_pct",
                CU AS "qpu_cu_pct",
                FE2O3 AS "qpu_fe2o3_pct",
                FEO AS "qpu_feo_pct",
                H2O AS "qpu_h2o_pct",
                HG AS "qpu_hg_pct",
                K as "qpu_k_pct",
                K2O AS "qpu_k2o_pct",
                MGO AS "qpu_mgo_pct",
                MN AS "qpu_mn_pct",
                NA AS "qpu_na_pct",
                NA2O AS "qpu_na2o_pct",
                P AS "qpu_p_pct",
                PB AS "qpu_pb_pct",
                S AS "qpu_s_pct",
                SIO2 AS "qpu_sio2_pct",
                TI AS "qpu_ti_pct",
                TIO2 AS "qpu_tio2_pct",
                ZN AS "qpu_zn_pct"
            FROM
                EKONOM.ANAL_SUR_VSA
            WHERE
                DATUM BETWEEN :start_date AND :end_date
            AND
                CISLO_SUROVINY = :qpu_analysis_number
            ORDER BY
                DATUM
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "qpu_analysis_number": qpu_analysis_number,
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                },
            )

    def get_sinter_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_sinter_analysis_query("AZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                },
            )

    def get_min_most_recent_analysis_date(
        self, start: datetime, raw_material_numbers: set[int]
    ) -> pd.Timestamp:
        with self.engine.begin() as conn:
            df = pd.read_sql(
                get_min_most_recent_analysis_date_query(len(raw_material_numbers), "AZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    **{f"rmn{idx+1}": rmn for idx, rmn in enumerate(raw_material_numbers)},
                },
            )
        return df["actual_start_date"].loc[0]

    def get_raw_material_analysis(
        self, start: datetime, end: datetime, raw_material_numbers: set[int]
    ) -> pd.DataFrame:
        actual_start_date = self.get_min_most_recent_analysis_date(start, raw_material_numbers)
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_analysis_query(len(raw_material_numbers), "AZVP"),
                conn,
                params={
                    "actual_start_date": actual_start_date,
                    "end_date": utc_to_local(end),
                    **{f"rmn{idx+1}": rmn for idx, rmn in enumerate(raw_material_numbers)},
                },
            )

    def get_raw_material_charge(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_charge_query("AZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_raw_material_charge_summary(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_charge_summary_query("AZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_raw_material_charge_extended_start_date(self, start: datetime, furnace_id: int) -> datetime:
        query = get_raw_material_charge_extended_start_date_query("AZVP")
        with self.engine.begin() as conn:
            df = pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "furnace_id": furnace_id,
                },
            )
            return local_naive_to_utc(df["extended_start_date"].loc[0])

    def get_raw_material_charge_extended_end_date(self, end: datetime, furnace_id: int) -> Optional[datetime]:
        query = get_raw_material_charge_extended_end_date_query("AZVP")
        with self.engine.begin() as conn:
            df = pd.read_sql(
                query,
                conn,
                params={
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )
            extended_end = df["extended_end_date"].loc[0]
            return local_naive_to_utc(extended_end) if extended_end is not None else None

    def get_tapping_start_end_datetimes(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame:
        query = """
            SELECT
                CISLO_ODPICHU AS "tapping_number",
                ZACIATOK AS "tapping_start_date",
                KONIEC AS "tapping_end_date",
                ZACIATOK_TR AS "tapping_slag_start",
                OTVOR AS "tapping_hole"
            FROM
                EKONOM.ODPICHY
            WHERE
                trunc(CISLO_ODPICHU / 10000, 0) = :furnace_id
            AND
                ZACIATOK BETWEEN :start_date AND :end_date
            ORDER BY
                ZACIATOK
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_tapping_ids_from_all_furnaces(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                CISLO_ODPICHU AS "tapping_number",
                ZACIATOK AS "tapping_start_date",
                KONIEC AS "tapping_end_date",
                trunc(CISLO_ODPICHU / 10000, 0) as furnace_id
            FROM
                EKONOM.ODPICHY
            WHERE
                ZACIATOK BETWEEN :start_date AND :end_date
            ORDER BY
                ZACIATOK
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
            ).assign(tapping_id=lambda x: x["tapping_number"] * 10000 + x["tapping_start_date"].dt.year)

    def get_pig_iron_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_pig_iron_analysis_query("AZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_slag_weights(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        query = """
            SELECT
                CISLO_ODPICHU AS "tapping_number",
                ZACIATOK AS "slag_start_date",
                PORADIE AS "slag_pot_order",
                MNOZSTVO AS "slag_pot_fill_value"
            FROM
                EKONOM.KOLIBY
            WHERE
                TRUNC(CISLO_ODPICHU / 10000, 0) = :furnace_id
            AND
                ZACIATOK BETWEEN :start_date AND :end_date
            ORDER BY
                ZACIATOK,
                PORADIE
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_slag_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        query = """
            SELECT
                DATUM_ANALYZY AS "slag_analysis_date",
                CISLO_ODPICHU AS "tapping_number",
                PER_AL2O3 AS "al2o3_pct",
                PER_C AS "c_pct",
                PER_CAO AS "cao_pct",
                PER_FE AS "fe_pct",
                PER_K2O AS "k2o_pct",
                PER_MGO AS "mgo_pct",
                PER_MN AS "mn_pct",
                PER_NA2O AS "na2o_pct",
                PER_S AS "s_pct",
                PER_SIO2 AS "sio2_pct",
                PER_TIO2 AS "tio2_pct"
            FROM
                EKONOM.ANALYZY_TROSKY
            WHERE
                TRUNC(CISLO_ODPICHU / 10000, 0) = :furnace_id
            AND
                DATUM_ANALYZY BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM_ANALYZY
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_granulometry(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        start -= timedelta(days=365)  # in order to map granulometry for earliest charges in date range
        query = """
            SELECT
                DATUM as granulometry_date,
                CISLO_SUROVINY as number_at_granulometry,
                VP as furnace_id,
                R0_5 as R0_5,
                R5_10 as R5_10,
                NAD_10 as ABOVE_10,
                null as UNDER_25,
                null as R25_40,
                null as R40_60,
                null as R60_80,
                null as ABOVE_80,
                'pellets' as kind
            FROM
                EKONOM.ROZ_PEL
            WHERE
                CISLO_SUROVINY is not null
            AND
                VP = :furnace_id
            AND
                DATUM BETWEEN :start_date AND :end_date
            UNION
            SELECT
                DATUM,
                1,
                VP,
                R0_5,
                R5_10,
                NAD_10,
                null,
                null,
                null,
                null,
                null,
                'sinter' as kind
            FROM
                EKONOM.ROZ_AGLO
            WHERE
                VP = :furnace_id
            AND
                DATUM BETWEEN :start_date AND :end_date
            UNION
            SELECT
                DATUM,
                 case when KB = 3 then 34 when KB = 1 then 40 else 37 end,
                 null,
                 null,
                 null,
                 null,
                 POD25,
                 R25_40,
                 R40_60,
                 R60_80,
                 NAD_80,
                 'coke'
            FROM
                EKONOM.ROZ_KOKS_VP
            WHERE
                POD25 is not null
            AND
                DATUM BETWEEN :start_date AND :end_date
            UNION
            SELECT
                to_date('2000-01-01', 'YYYY-MM-DD'),
                37,
                null,
                null,
                null,
                null,
                0,
                100,
                0,
                0,
                0,
                'coke'
            FROM
                dual
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )
