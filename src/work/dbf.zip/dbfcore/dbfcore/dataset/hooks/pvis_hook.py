from datetime import datetime
from typing import Protocol

import pandas as pd

from dbfcore.dataset.hooks.base_hook import OracleHook
from dbfcore.dataset.raw_dataset.utils import utc_to_local


class PvisDbDataSelector(Protocol):
    def get_cog_chem_composition(self, start: datetime, end: datetime) -> pd.DataFrame: ...


class PvisHook(OracleHook):
    def get_cog_chem_composition(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            WITH kp_chem AS (
            SELECT
                KP_CH4 AS ch4_pct,
                KP_H2 AS h2_pct,
                KP_O2 AS o2_pct,
                KP_N2 AS n2_pct,
                KP_CO2 AS co2_pct,
                KP_C2H4 AS c2h4_pct,
                KP_C2H6 AS c2h6_pct,
                KP_C2H2 AS c2h2_pct,
                KP_CO AS co_pct,
                COALESCE(DATCAS_UPD, DATCAS_INS) AS last_update
            FROM
                VIS.KP_LA
            )
            SELECT
                *
            FROM
                kp_chem
            WHERE
                last_update BETWEEN :start_date AND :end_date
            ORDER BY
                last_update
        """

        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start_date": utc_to_local(start), "end_date": utc_to_local(end)},
                parse_dates=["last_update"],
            )
