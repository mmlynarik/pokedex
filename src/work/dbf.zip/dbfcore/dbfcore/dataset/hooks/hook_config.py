import os
from typing import TypedDict


class DBHookConfig(TypedDict):
    host: str
    port: int
    database: str
    username: str
    password: str


class PIHookConfig(TypedDict):
    host: str
    database: str
    user: str
    password: str


def get_azvp_config_from_env() -> DBHookConfig:
    try:
        return {
            "host": os.environ["AZVP_DB_HOST"],
            "port": int(os.environ["AZVP_DB_PORT"]),
            "database": os.environ["AZVP_DB_DATABASE"],
            "username": os.environ["AZVP_DB_USER"],
            "password": os.environ["AZVP_DB_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid AZVP database setting in environment variables, please setup following variables:
            AZVP_DB_HOST, AZVP_DB_PORT, AZVP_DB_DATABASE, AZVP_DB_USER, AZVP_DB_PASSWORD"""
        ) from e


def get_pzvp_config_from_env() -> DBHookConfig:
    try:
        return {
            "host": os.environ["PZVP_DB_HOST"],
            "port": int(os.environ["PZVP_DB_PORT"]),
            "database": os.environ["PZVP_DB_DATABASE"],
            "username": os.environ["PZVP_DB_USER"],
            "password": os.environ["PZVP_DB_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid PZVP database setting in environment variables, please setup following variables:
            PZVP_DB_HOST, PZVP_DB_PORT, PZVP_DB_DATABASE, PZVP_DB_USER, PZVP_DB_PASSWORD"""
        ) from e


def get_scada_config_from_env() -> DBHookConfig:
    try:
        return {
            "host": os.environ["SCADA_DB_HOST"],
            "port": int(os.environ["SCADA_DB_PORT"]),
            "database": os.environ["SCADA_DB_SID"],
            "username": os.environ["SCADA_DB_USER"],
            "password": os.environ["SCADA_DB_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid SCADA database setting in environment variables, please setup following variables:
            SCADA_DB_HOST, SCADA_DB_PORT, SCADA_DB_SID, SCADA_DB_USER, SCADA_DB_PASSWORD"""
        ) from e


def get_oko_config_from_env() -> DBHookConfig:
    try:
        return {
            "host": os.environ["OKO_DB_HOST"],
            "port": int(os.environ["OKO_DB_PORT"]),
            "database": os.environ["OKO_DB_SID"],
            "username": os.environ["OKO_DB_USER"],
            "password": os.environ["OKO_DB_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid SCADA database setting in environment variables, please setup following variables:
            OKO_DB_HOST, OKO_DB_PORT, OKO_DB_SID, OKO_DB_USER, OKO_DB_PASSWORD"""
        ) from e


def get_pi_config_from_env() -> PIHookConfig:
    try:
        return {
            "host": os.environ["PI_API_ENDPOINT"],
            "database": os.environ["PI_DB_NAME"],
            "user": os.environ["PI_CLIENT_USER"],
            "password": os.environ["PI_CLIENT_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid PI API setting in environment variables, please setup following variables:
            PI_API_ENDPOINT, PI_DB_NAME, PI_CLIENT_USER, PI_CLIENT_PASSWORD"""
        ) from e


def get_pvis_config_from_env() -> DBHookConfig:
    try:
        return {
            "host": os.environ["PVIS_DB_HOST"],
            "port": int(os.environ["PVIS_DB_PORT"]),
            "database": os.environ["PVIS_DB_SID"],
            "username": os.environ["PVIS_DB_USER"],
            "password": os.environ["PVIS_DB_PASSWORD"],
        }
    except KeyError as e:
        raise Exception(
            """Invalid PVIS database setting in environment variables, please setup following variables:
            PVIS_DB_HOST, PVIS_DB_PORT, PVIS_DB_SID, PVIS_DB_USER, PVIS_DB_PASSWORD"""
        ) from e
