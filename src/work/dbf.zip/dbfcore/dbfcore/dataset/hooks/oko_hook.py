from datetime import datetime
from typing import Protocol

import pandas as pd

from dbfcore.dataset.hooks.base_hook import MssqlHook
from dbfcore.dataset.raw_dataset.utils import split_into_chunks, utc_to_local


def get_bind_names_for_heat_ids(heat_ids: list[int]) -> str:
    return ",".join(str(heat) for heat in heat_ids)


class OkoDbDataSelector(Protocol):
    def get_steelshop_chems_for_heats(self, start: datetime, end: datetime) -> pd.DataFrame: ...


class OkoHook(MssqlHook):
    def get_steelshop_chems_for_heats(self, start: datetime, end: datetime) -> pd.DataFrame:
        query = """
            SELECT
                datum as date,
                o.cis_tavby as heat_number,
                o.cis_tavby * 10000 + year(datum) as heat_id,
                teplota_1_odsirenie as first_temp,
                teplota_2_odsirenie as second_temp,
                cas_1_teploty_odsirenie as first_temp_date,
                hmotnost_suze_po as pig_iron,
                planovana_akost as grade,
                total_scrap_weight,
                miesac_c as c_pct,
                miesac_mn as mn_pct,
                miesac_p as p_pct,
                miesac_s as s_pct,
                miesac_si as si_pct,
                miesac_ti as ti_pct
            FROM
                dbo.iars_odsirenie o
            LEFT JOIN
                (
                    SELECT
                        rok, cis_tavby, cis_tavby * 10000 + rok as heat_id, sum(hmotnost) / 100 as total_scrap_weight
                    FROM
                        oko.dbo.iars_konv_srot
                    WHERE
                        rok >= year(%(start)s) and rok <= year(%(end)s)
                    GROUP BY
                        rok, cis_tavby
                ) s
            ON o.cis_tavby * 10000 + year(o.datum) = s.cis_tavby * 10000 + s.rok

            WHERE
                cas_1_teploty_odsirenie >= %(start)s
            AND
                cas_1_teploty_odsirenie <= %(end)s
            AND
                miesac_si is not null
            AND
                miesac_si > 0
            AND
                year(datum) < 9999;
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={"start": utc_to_local(start), "end": utc_to_local(end)},
                dtype={"grade": int},
            )

    def get_steelshop_chems_for_heats_by_heat_ids(self, heat_ids: list[int]) -> pd.DataFrame:
        output = []
        for chunk in split_into_chunks(heat_ids):
            query = """
                DECLARE @MyValues NVARCHAR(MAX) = '%s';
                SELECT
                    datum as date,
                    cis_tavby as heat_number,
                    cis_tavby * 10000 + year(datum) as heat_id,
                    cas_1_teploty_odsirenie as first_temp_date,
                    miesac_c as c_pct,
                    miesac_mn as mn_pct,
                    miesac_p as p_pct,
                    miesac_s as s_pct,
                    miesac_si as si_pct,
                    miesac_ti as ti_pct
                FROM
                    dbo.iars_odsirenie
                WHERE
                    cis_tavby * 10000 + year(datum) IN (SELECT value FROM STRING_SPLIT(@MyValues, ','))
            """ % get_bind_names_for_heat_ids(
                chunk
            )
            with self.engine.begin() as conn:
                df = pd.read_sql(
                    query,
                    conn,
                    parse_dates=["date", "first_temp_date"],
                    dtype={"heat_id": int},
                )
            output.append(df)
        return pd.concat(output)
