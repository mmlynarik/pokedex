from datetime import datetime

import pandas as pd

from dbfcore.dataset.hooks.hook_config import PIHookConfig
from dbfcore.dataset.hooks.piclient import PiClient, get_pi_point_by_name


class PIHook:
    def __init__(self, conf: PIHookConfig):
        self._client = PiClient(conf["host"], conf["database"], conf["user"], conf["password"])

    def get_tapping_temperature_from_pi_db(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame:
        pipoint = get_pi_point_by_name(self._client, f"SK{furnace_id}.HotMetal.Temp.MeasDevice.C")
        data = pipoint.history(start, end)
        df = pd.DataFrame(data)
        df["date"] = pd.to_datetime(df["Timestamp"], format="ISO8601").dt.floor("Min")
        df["tapping_temperature"] = df["Value"]
        return df[["date", "tapping_temperature"]]
