from typing import Literal

AZVP_PZVP = Literal["AZVP", "PZVP"]


def get_bind_names_for_raw_material_numbers(length: int) -> str:
    return ", ".join(":rmn" + str(i + 1) for i in range(length))


def get_raw_material_charge_extended_start_date_query(source: AZVP_PZVP) -> str:
    if source == "AZVP":
        return """
            SELECT
                MAX(v.DATUM) as extended_start_date
            FROM
                EKONOM.VSA_HMOTNOSTI h
            JOIN
                EKONOM.VSADZKY v
            ON
                h.CISLO_VSADZKY = v.CISLO_VSADZKY
            AND
                trunc(h.CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                v.DATUM < :start_date
        """
    else:
        return """
            SELECT
                MAX(v.DATUM) as extended_start_date
            FROM
                DISP.VSA_HMOTNOSTI h
            JOIN
                DISP.VSADZKY v
            ON
                h.CISLO_VSADZKY = v.CISLO_VSADZKY
            AND
                trunc(h.CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                v.DATUM < :start_date
        """


def get_raw_material_charge_extended_end_date_query(source: AZVP_PZVP) -> str:
    if source == "AZVP":
        return """
            SELECT
                MIN(v.DATUM) as extended_end_date
            FROM
                EKONOM.VSA_HMOTNOSTI h
            JOIN
                EKONOM.VSADZKY v
            ON
                h.CISLO_VSADZKY = v.CISLO_VSADZKY
            AND
                trunc(h.CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                v.DATUM > :end_date
        """
    else:
        return """
            SELECT
                MIN(v.DATUM) as extended_end_date
            FROM
                DISP.VSA_HMOTNOSTI h
            JOIN
                DISP.VSADZKY v
            ON
                h.CISLO_VSADZKY = v.CISLO_VSADZKY
            AND
                trunc(h.CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                v.DATUM > :end_date
        """


def get_raw_material_charge_query(source: AZVP_PZVP) -> str:
    if source == "AZVP":
        return """
            SELECT
                DATUM AS charge_date,
                CISLO_VSADZKY AS charge_number,
                CISLO_SUROVINY AS raw_material_number,
                HMOTNOST AS raw_material_weight
            FROM
                EKONOM.VSA_HMOTNOSTI
            WHERE
                trunc(CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """
    else:
        return """
            SELECT
                v.DATUM as charge_date,
                h.CISLO_VSADZKY as charge_number,
                h.CISLO_SUROVINY as raw_material_number,
                h.HMOTNOST as raw_material_weight
            FROM
                DISP.VSA_HMOTNOSTI h
            JOIN
                DISP.VSADZKY v
            ON
                h.CISLO_VSADZKY = v.CISLO_VSADZKY
            AND
                trunc(h.CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                v.DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                v.DATUM
        """


def get_raw_material_charge_summary_query(source: AZVP_PZVP) -> str:
    if source == "AZVP":
        return """
            SELECT
                DATUM AS charge_date,
                VLHKOST AS moisture_pct
            FROM
                EKONOM.VSADZKY
            WHERE
                trunc(CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """
    else:
        return """
            SELECT
                DATUM as charge_date,
                VLHKOST as moisture_pct
            FROM
                DISP.VSADZKY
            AND
                trunc(CISLO_VSADZKY / 10000, 0) = :furnace_id
            AND
                DATUM BETWEEN :start_date AND :end_date
            ORDER BY
                DATUM
        """


def get_min_most_recent_analysis_date_query(num_raw_material_numbers: int, source: AZVP_PZVP) -> str:
    table = "EKONOM.ANAL_SUR_VSA" if source == "AZVP" else "DISP.ANAL_SUR_VSA"
    return """
        SELECT
            MIN(most_recent_analysis_date) as actual_start_date
        FROM (
                SELECT
                    CISLO_SUROVINY, MAX(DATUM) as most_recent_analysis_date
                FROM
                    %s
                WHERE
                    DATUM <= :start_date
                AND
                    CISLO_SUROVINY in (%s)
                GROUP BY
                    CISLO_SUROVINY
            )
    """ % (
        table,
        get_bind_names_for_raw_material_numbers(num_raw_material_numbers),
    )


def get_raw_material_analysis_query(num_raw_material_numbers: int, source: AZVP_PZVP) -> str:
    table = "EKONOM.ANAL_SUR_VSA" if source == "AZVP" else "DISP.ANAL_SUR_VSA"
    return """
        SELECT
            DATUM AS raw_material_analysis_date,
            CISLO_SUROVINY AS raw_material_number,
            AL2O3 AS al2o3_pct,
            ARS AS ars_pct,
            C AS c_pct,
            CAO AS cao_pct,
            0 AS caco3_pct,
            CU AS cu_pct,
            FE2O3 AS fe2o3_pct,
            FEO AS feo_pct,
            H2O AS h2o_pct,
            HG AS hg_pct,
            K as k_pct,
            K2O AS k2o_pct,
            MGO AS mgo_pct,
            0 AS mgco3_pct,
            MN AS mn_pct,
            NA as na_pct,
            NA2O AS na2o_pct,
            P AS p_pct,
            PB AS pb_pct,
            S AS s_pct,
            SIO2 AS sio2_pct,
            TI AS ti_pct,
            TIO2 AS tio2_pct,
            ZN AS zn_pct
        FROM
            %s
        WHERE
            DATUM BETWEEN :actual_start_date AND :end_date
        AND
            CISLO_SUROVINY in (%s)
        ORDER BY
            DATUM
    """ % (
        table,
        get_bind_names_for_raw_material_numbers(num_raw_material_numbers),
    )


def get_sinter_analysis_query(source: AZVP_PZVP) -> str:
    table = "EKONOM.ANALYZY_AGLO" if source == "AZVP" else "DISP.ANALYZY_AGLO"
    return """
        WITH
            most_recent_analysis_date as (
                SELECT
                    MAX(DATUM_ANALYZY) as most_recent_analysis_date
                FROM
                    %s
                WHERE
                    DATUM_ANALYZY <= :start_date
            )
        SELECT
            DATUM_ANALYZY AS sinter_analysis_date,
            PER_AL2O3 AS al2o3_pct,
            0 AS ars_pct,
            PER_C AS c_pct,
            PER_CAO AS cao_pct,
            0 AS caco3_pct,
            0 AS cu_pct,
            PER_FEO AS feo_pct,
            PER_FE2O3 AS fe2o3_pct,
            0 AS h2o_pct,
            0 as hg_pct,
            0 as k_pct,
            PER_K2O AS k2o_pct,
            PER_MGO AS mgo_pct,
            0 AS mgco3_pct,
            PER_MN AS mn_pct,
            0 as na_pct,
            PER_NA2O AS na2o_pct,
            PER_P AS p_pct,
            0 as pb_pct,
            PER_S AS s_pct,
            PER_SIO2 AS sio2_pct,
            0 as ti_pct,
            PER_TIO2 AS tio2_pct,
            PER_ZN AS zn_pct
        FROM
            %s
        WHERE
            DATUM_ANALYZY BETWEEN (select most_recent_analysis_date from most_recent_analysis_date) AND :end_date
        ORDER BY
            DATUM_ANALYZY,
            CISLO_ANALYZY
    """ % (
        table,
        table,
    )


def get_pig_iron_analysis_query(source: AZVP_PZVP):
    table = "EKONOM.ANALYZY_VZORIEK" if source == "AZVP" else "DISP.ANALYZY_VZORIEK"

    return """
        SELECT
            DATUM_ANALYZY AS "pig_iron_analysis_date",
            CISLO_ODPICHU AS "tapping_number",
            CISLO_VZORKY AS "pig_iron_sample_number",
            PER_AS AS "as_pct",
            PER_C AS "c_pct",
            PER_MN AS "mn_pct",
            PER_P AS "p_pct",
            PER_PB AS "pb_pct",
            PER_S AS "s_pct",
            PER_SI AS "si_pct",
            PER_TI AS "ti_pct",
            PER_ZN AS "zn_pct"
        FROM
            %s
        WHERE
            trunc(CISLO_ODPICHU / 10000, 0) = :furnace_id
        AND
            DATUM_ANALYZY BETWEEN :start_date AND :end_date
        ORDER BY
            DATUM_ANALYZY
    """ % (
        table
    )


def get_pulverized_coal_analysis_query():
    return """
        SELECT
            DATUM AS "pc_analysis_date",
            OBSAH_H2O AS "h2o_pct",
            OBSAH_H2O_AN AS "h2o_an_pct",
            OBSAH_POPOL AS "ash_pct",
            OBSAH_PRCHAVE_LATKY AS "volatile_matter_pct",
            OBSAH_S AS "s_pct",
            VYHREVNOST AS "heat_value_MJkg"
        FROM
            SYS_AGLO.LAB_K_UHLIE_PRASKOVE
        WHERE
            DATUM BETWEEN :start_date AND :end_date
        ORDER BY
            DATUM
    """


def get_pulverized_coal_ash_monthly_analysis_query():
    return """
        SELECT
            DATUM AS "pc_ash_monthly_analysis_date",
            FE2O3 AS "fe2o3_ash_pct",
            SIO2 AS "sio2_ash_pct",
            CAO AS "cao_ash_pct",
            MGO AS "mgo_ash_pct",
            AL2O3 AS "al2o3_ash_pct",
            MN AS "mn_ash_pct",
            P AS "p_ash_pct",
            NA2O AS "nao_ash_pct",
            K2O AS "k2o_ash_pct",
            TIO2 AS "tio2_ash_pct",
            PB AS "pb_ash_pct",
            ZN AS "zn_ash_pct",
            CU AS "cu_ash_pct"
        FROM
            SYS_AGLO.V_MES_ANAL
        WHERE DATUM BETWEEN TRUNC(:start_date) AND TRUNC(:end_date)
        AND KOD = 'Popol PU'
        AND SKUP = 120
        ORDER BY
            DATUM
    """
