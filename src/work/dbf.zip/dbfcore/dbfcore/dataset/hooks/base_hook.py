import oracledb
from sqlalchemy.engine import URL, create_engine

from dbfcore.dataset.hooks.hook_config import DBHookConfig


class BaseDBHook:
    def __init__(self, drivername: str, conf: DBHookConfig):
        self.engine = create_engine(URL.create(drivername, **conf), pool_pre_ping=True)

    @property
    def host(self):
        return self.engine.url.host

    @property
    def port(self):
        return self.engine.url.port


class OracleHook(BaseDBHook):
    def __init__(self, conf: DBHookConfig):
        super().__init__("oracle+oracledb", conf)
        oracledb.init_oracle_client()


class MssqlHook(BaseDBHook):
    def __init__(self, conf: DBHookConfig):
        super().__init__("mssql+pymssql", conf)
