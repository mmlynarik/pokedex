from datetime import datetime
from typing import Optional, Protocol

import pandas as pd

from dbfcore.dataset.hooks.base_hook import OracleHook
from dbfcore.dataset.hooks.queries import (
    get_min_most_recent_analysis_date_query,
    get_pig_iron_analysis_query,
    get_pulverized_coal_analysis_query,
    get_pulverized_coal_ash_monthly_analysis_query,
    get_raw_material_analysis_query,
    get_raw_material_charge_extended_end_date_query,
    get_raw_material_charge_extended_start_date_query,
    get_raw_material_charge_query,
    get_raw_material_charge_summary_query,
    get_sinter_analysis_query,
)
from dbfcore.dataset.raw_dataset.utils import local_naive_to_utc, utc_to_local


class PZVPDbDataSelector(Protocol):
    def get_pig_iron_weights(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_sinter_analysis(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_raw_material_analysis(
        self, start: datetime, end: datetime, raw_material_numbers: set[int]
    ) -> pd.DataFrame: ...

    def get_raw_material_charge(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame: ...

    def get_raw_material_charge_summary(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame: ...

    def get_pulverized_coal_analysis(self, start: datetime, end: datetime) -> pd.DataFrame: ...

    def get_pulverized_coal_ash_monthly_analysis(self, start: datetime, end: datetime) -> pd.DataFrame: ...


class PZVPHook(OracleHook):
    def get_tapping_start_end_datetimes(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame:
        query = """
            SELECT
                CISLO_ODPICHU AS "tapping_number",
                ZACIATOK AS "tapping_start_date",
                KONIEC AS "tapping_end_date",
                ZACIATOK_TR AS "tapping_slag_start",
                OTVOR AS "tapping_hole"
            FROM
                EKONOM.ODPICHY
            WHERE
                trunc(CISLO_ODPICHU / 10000, 0) = :furnace_id
            AND
                ZACIATOK BETWEEN :start_date AND :end_date
            ORDER BY
                ZACIATOK
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_pig_iron_weights(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        query = """
          SELECT
            DATUM_PRIRADENIA AS "pig_iron_date",
            CISLO_DODAVKY AS "delivery_id",
            CISLO_ODPICHU AS "tapping_number",
            HMOTNOST_SKUTOCNA_T AS "pig_iron_weight"
        FROM
            DISP.PRIRADENIE
        WHERE
            DATUM_PRIRADENIA BETWEEN :start_date AND :end_date
        AND
            TRUNC(CISLO_ODPICHU / 10000, 0) = :furnace_id
        ORDER BY
            DATUM_PRIRADENIA
        """
        with self.engine.begin() as conn:
            return pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_pig_iron_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_pig_iron_analysis_query("PZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_sinter_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_sinter_analysis_query("PZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                },
            )

    def get_raw_material_charge_extended_start_date(self, start: datetime, furnace_id: int) -> datetime:
        query = get_raw_material_charge_extended_start_date_query("PZVP")
        with self.engine.begin() as conn:
            df = pd.read_sql(
                query,
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "furnace_id": furnace_id,
                },
            )
            return local_naive_to_utc(df["extended_start_date"].loc[0])

    def get_raw_material_charge_extended_end_date(self, end: datetime, furnace_id: int) -> Optional[datetime]:
        query = get_raw_material_charge_extended_end_date_query("PZVP")
        with self.engine.begin() as conn:
            df = pd.read_sql(
                query,
                conn,
                params={
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )
            extended_end = df["extended_end_date"].loc[0]
            return local_naive_to_utc(extended_end) if extended_end is not None else None

    def get_raw_material_charge(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_charge_query("PZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_raw_material_charge_summary(
        self, start: datetime, end: datetime, furnace_id: int
    ) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_charge_summary_query("PZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                    "furnace_id": furnace_id,
                },
            )

    def get_min_most_recent_analysis_date(
        self, start: datetime, raw_material_numbers: set[int]
    ) -> pd.Timestamp:
        with self.engine.begin() as conn:
            df = pd.read_sql(
                get_min_most_recent_analysis_date_query(len(raw_material_numbers), "PZVP"),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    **{f"rmn{idx+1}": rmn for idx, rmn in enumerate(raw_material_numbers)},
                },
            )
        return df["actual_start_date"].loc[0]

    def get_raw_material_analysis(
        self, start: datetime, end: datetime, raw_material_numbers: set[int]
    ) -> pd.DataFrame:
        actual_start_date = self.get_min_most_recent_analysis_date(start, raw_material_numbers)
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_raw_material_analysis_query(len(raw_material_numbers), "PZVP"),
                conn,
                params={
                    "actual_start_date": actual_start_date,
                    "end_date": utc_to_local(end),
                    **{f"rmn{idx+1}": rmn for idx, rmn in enumerate(raw_material_numbers)},
                },
            )

    def get_pulverized_coal_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_pulverized_coal_analysis_query(),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                },
            )

    def get_pulverized_coal_ash_monthly_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        with self.engine.begin() as conn:
            return pd.read_sql(
                get_pulverized_coal_ash_monthly_analysis_query(),
                conn,
                params={
                    "start_date": utc_to_local(start),
                    "end_date": utc_to_local(end),
                },
            )
