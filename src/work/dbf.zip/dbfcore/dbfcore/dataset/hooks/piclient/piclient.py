import logging
import os
import warnings
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
import requests
from requests import JSONDecodeError
from requests.auth import HTTPBasicAuth
from urllib3.exceptions import InsecureRequestWarning

from dbfcore.utils import is_utc


class PiClient:
    def __init__(self, api_endpoint: str, db_name: str, user: str, password: str):
        self._api_endpoint = api_endpoint
        self._db_name = db_name
        self._auth = HTTPBasicAuth(user, password)

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=InsecureRequestWarning)
            return requests.get(
                f"{self._api_endpoint}/{url}", auth=self._auth, verify=False, params=params
            ).json()

    def post_request(self, url: str, body: dict) -> Optional[dict]:
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=InsecureRequestWarning)
            response = requests.post(f"{self._api_endpoint}/{url}", auth=self._auth, verify=False, json=body)
            response.raise_for_status()
            try:
                return response.json()
            except JSONDecodeError:
                return None

    def webid_by_path(self, name: str) -> str:
        response = self.get_request(f"points?path=\\{self._db_name}\{name}")
        if "WebId" not in response:
            raise Exception(
                f"PI webid for signal name: {name} not found. \n"
                + " Probably you used invalid name. \n"
                + "If you are sure the name is correct check connection to PI."
            )
        return response["WebId"]


class PiPoint:
    def __init__(self, piclient: PiClient, webid: str):
        self._webid: str = webid
        self._piclient: PiClient = piclient

    def value(self):
        return self._piclient.get_request(f"streams/{self._webid}/value")

    # PI API allows also batch updates but we do not support it yet - will be implemented with first use case
    def add_or_update_value(
        self,
        value: float,
        timestamp: datetime,
        good: bool = True,
        questionable: bool = False,
        units_abbreviation: str = "",
    ) -> None:
        if not is_utc(timestamp):
            raise ValueError("Timestamp must be specified in UTC")

        request_data = {
            "Timestamp": timestamp.isoformat(),
            "UnitsAbbreviation": units_abbreviation,
            "Good": good,
            "Questionable": questionable,
            "Value": value,
        }

        self._piclient.post_request(f"streams/{self._webid}/value", request_data)

    # Use larger batch_sizes than 2000 with caution
    def history(self, start: datetime, end: datetime, batch_size: int = 2000, log_enabled: bool = False):
        if (not is_utc(start)) or (not is_utc(end)):
            raise ValueError("All datetimes used must be specified in UTC")

        all_items = []
        current_start = start

        while True:
            if log_enabled:
                logging.info(f"Loading history for {self._webid} current start {current_start.isoformat()}")
            response = self._piclient.get_request(
                f"streams/{self._webid}/recorded",
                params={
                    "startTime": current_start.isoformat(),
                    "endTime": end.isoformat(),
                    "selectedFields": "Items.Timestamp;Items.Value;Items.Good",
                    "maxCount": batch_size,
                },
            )
            items = response["Items"]
            all_items.extend(items)
            items_count = len(items)
            if (items_count < batch_size) or (items_count < 1):
                break
            # PI web API always returns all data including start and end time
            # adding one microsecond so we do not have duplicates when batching
            current_start = datetime.fromisoformat(items[-1]["Timestamp"]) + timedelta(microseconds=1)
        return all_items


def get_pi_client() -> PiClient:
    username = os.environ.get("PI_CLIENT_USER")  # username in format "tka7447"
    password = os.environ.get("PI_CLIENT_PASSWORD")  # passowrd in format "strongpass"
    pi_hostname = os.environ.get("PI_API_ENDPOINT")
    pi_db_name = os.environ.get("PI_DB_NAME")
    if (username is None) or (password is None) or (pi_hostname is None) or (pi_db_name is None):
        raise Exception(
            """
            PI information need to be setup in env variables:
            PI_CLIENT_USER, PI_CLIENT_PASSWORD, PI_API_ENDPOINT and PI_DB_NAME
            """
        )

    return PiClient(pi_hostname, pi_db_name, username, password)


def get_pi_point_by_name(piclient: PiClient, name: str) -> PiPoint:
    webid = piclient.webid_by_path(name)
    return PiPoint(piclient, webid)


def load_pi_data(
    pi_client: PiClient,
    pi_point_name: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    log_enabled: bool = False,
) -> list:
    pi_point = get_pi_point_by_name(pi_client, pi_point_name)
    return pi_point.history(start, end, log_enabled=log_enabled)
