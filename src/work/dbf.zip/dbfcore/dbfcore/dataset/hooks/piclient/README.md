## PiClient

Package `piclient` serves as a connector to PI datbase API. This package creates a simple framework to acquire data from PI database by providing three basic inputs: `pi_point_name`, `start_date`, and `end_date`. As an output `piclient` provides a list of three values: timestamp, actual pi_point value, and identificator if the value is valid or not.

*NOTE: All datetimes used in PI database are in UTC timezone.*

## Table of contents

- [PiClient](#piclient)
- [Table of contents](#table-of-contents)
- [Installation](#installation)
- [Example usage](#example-usage)
- [Unit tests](#unit-tests)
- [Versions](#versions)
- [Todo](#todo)

## Installation

Not yet implemented.

<!-- Install `usskpiclient` package with `pip` as follows:

Configure pip to use https://vnexus.sk.uss.com/repository/pypi-group/pypi repository

```shell
pip install usskpiclient
``` -->

## Example usage

First, set the environment with `piclient` credentials:
PI_API_ENDPOINT = https://vpiaf/piwebapi
PI_DB_NAME = VPIPRIMSK
PI_CLIENT_USER = DIGITAL_DBF
PI_CLIENT_PASSWORD = ******

OR

use `PiClient` class to setup connection

```python
import datetime
import pytz
from dbfcore.dataset.hooks.piclient import get_pi_point_by_name, get_pi_client, PiClient

# Client setup
client = PiClient("https://vpiaf/piwebapi", "VPIPRIMSK", "DIGITAL_DBF", "<password>")
# OR after the environment setup
client = get_pi_client()

pi_point_name = "SK1.Top.StockRod1.Distance.m"
pipoint = get_pi_point_by_name(client, pi_point_name)

# Get current value
current_value_of_sensor = pipoint.value()

# Get last 120 seconds for the sensor (any historical times can be used)
end = datetime.datetime.now().astimezone(pytz.timezone("utc"))
start = end - datetime.timedelta(seconds=120)

historical_values = pipoint.history(start, end)
```

## Unit tests

To run tests, go to the `usskpiclient` directory (where `setup.py` is) and run

```shell
python -m unittest discover -s .\tests -t .
```

## Versions

| Version | Date       | Change Description |
| ------- | ---------- | ------------------ |
| 0.0.1   | YYYY-MM-DD | Initial version    |

## Todo

- [ ] *PLACEHOLDER*

