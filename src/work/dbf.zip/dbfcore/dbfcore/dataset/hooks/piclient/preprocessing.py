from datetime import datetime
from pathlib import Path

import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient, PiPoint, load_pi_data


# TODO name should be somehow embedded in PiPoint class but it is not clear how
def pi_to_df(pi_data: list, name: str) -> pd.DataFrame:
    if not pi_data:
        return pd.DataFrame()
    df = pd.DataFrame(pi_data)
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], format="ISO8601")
    df = df.set_index("Timestamp")
    df.loc[~df.Good, ["Value"]] = float("nan")
    df.Value = pd.to_numeric(df.Value)
    return df.rename(columns={"Value": name}).drop(columns=["Good"])


def get_cache_filename(pi_point: PiPoint, start: datetime, end: datetime) -> str:
    return f"{pi_point._webid}_{int(start.timestamp())}_{int(end.timestamp())}.parquet"


# TODO name should be somehow embedded in PiPoint class but it is not clear how
def get_pi_cached_data(
    pi_point: PiPoint, name: str, start: datetime, end: datetime, cache_folder: str
) -> pd.DataFrame:
    if not Path(cache_folder).exists():
        raise FileNotFoundError(
            f"PI API cache folder {cache_folder} does not exist. Please create it before fetching PI API data."
        )
    cache_filename = Path(cache_folder) / get_cache_filename(pi_point, start, end)
    if cache_filename.exists():
        return pd.read_parquet(cache_filename)
    history = pi_point.history(start, end, batch_size=30000, log_enabled=True)
    history_df = pi_to_df(history, name)
    history_df.to_parquet(cache_filename)

    return history_df


def get_pi_data_as_dataframe(
    pi_client: PiClient,
    pi_point_name: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    name: str,
    log_enabled: bool = False,
) -> pd.DataFrame:
    pi_data = load_pi_data(pi_client, pi_point_name, start, end, log_enabled)
    return pi_to_df(pi_data, name)
