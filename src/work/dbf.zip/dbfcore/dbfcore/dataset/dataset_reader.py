from typing import Iterable, Optional

import pandas as pd
from datasets import Dataset, load_from_disk


def load_dataset(path: str, columns: Optional[Iterable[str]] = None) -> Dataset:
    """
    Loads dataset from disk.
    `Path` (required) specifies the location of the dataset in disk.
    `Columns` (optional) can be used to specify column names to be present in loaded dataset.
    """

    dataset = load_from_disk(path)

    return dataset.select_columns(list(columns)) if columns else dataset


def load_dataset_as_dataframe(
    path: str, columns: Optional[Iterable[str]] = None, index: str = "date"
) -> pd.DataFrame:
    """
    Loads dataset from disk as a pandas dataframe.
    `Path` (required) specifies the location of the dataset in disk.
    `Columns` (optional) can be used to specify column names to be present in loaded dataset.
    """

    columns_with_index = list(columns) + [index] if columns else None

    return load_dataset(path, columns_with_index).to_pandas().set_index(index)
