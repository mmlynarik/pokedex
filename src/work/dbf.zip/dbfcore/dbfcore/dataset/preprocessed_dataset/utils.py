from typing import Callable, Iterable, Union

import pandas as pd
import periodictable
from tqdm import tqdm

TransformationsCallables = list[Callable[..., pd.DataFrame]]


def drop_columns(df: pd.DataFrame, columns: Union[str, list[str]]) -> pd.DataFrame:
    """Drops specified column or list of columns."""

    return df.drop(columns=columns)


def select_columns(df: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    """Selects specified columns."""

    return df.filter(items=list(columns), axis=1)


def reindex_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    """Reorders dataframe columns as specified."""

    return df.reindex(columns=columns)


def sum_columns(df: pd.DataFrame, columns: list[str], output_column: str) -> pd.DataFrame:
    """Performs column-wise sum of defined columns and results as an `output_column`."""

    df[output_column] = df[columns].sum(axis=1)

    return df


def convert_mass_units(df: pd.DataFrame, direction: str, input_col: str, output_col: str) -> pd.DataFrame:
    """
    Converts specified mass column from `kg` to `t` or vice versa.

    Args:
        df: dataframe which columns are being used
        direction:
            kg -> t: converts kilograms to tons
            t -> kg: converts tons to kilograms
        input_col: column with masses to be converted
        output_col: the name of the column after conversion

    Example:
        >>> convert_mass_units(df, "kg -> t", "input_mass", "output_mass")
    """

    if direction == "kg -> t":
        df[output_col] = df[input_col].div(1000)
    elif direction == "t -> kg":
        df[output_col] = df[input_col].mul(1000)
    else:
        raise Exception("Direction not implemented!")

    return df


def _element_mass_fraction(formula: str, element: str) -> float:
    """Calculates the mass fraction of the defined element in the defined compound"""

    mass_fractions_dict = periodictable.formula(formula).mass_fraction

    return mass_fractions_dict[getattr(periodictable, element)]


def calculate_element_mass_of_chemical_compound(
    df: pd.DataFrame, chemical_compound: str, element: str, input_col: str, output_col: str
) -> pd.DataFrame:
    """
    Calculates the mass of the specified element in the specified chemical compound.
    The element mass is calculated as follows:
        mass_column [kg] * element_pct [%] -> [kg]
        mass_column [t] * element_pct [%] -> [t]

    Args:
        df: specified dataframe which columns to be used
        chemical_compound: chemical compound from wich mass fraction is calculated
        element: chemical element of which the element mass is calculated
        input_col: the name of column with the mass of specified chem. compound to be used for element mass calculation
        output_col: the name of the column with the resulting mass of the specified element

    Example:
        >>> calculate_element_mass_of_chemical_compound(
                df=df,
                chemical_compound="SiO2",
                element="Si",
                input_col="sio2_weight",
                output_col="raw_material_si_weight"
            )
    """

    element_pct = _element_mass_fraction(chemical_compound, element)
    df[output_col] = df[input_col] * element_pct

    return df


def calculate_output_input_weight_ratio_per_standard_time_period(
    df: pd.DataFrame, time_period: str
) -> pd.DataFrame:
    """
    Summarizes original dataframe per standard periods ("M" - month, "W" - week, "D" - day etc.)
    and calculates output vs. input weight difference and ratio
    """

    if "input_weight" not in df.columns and "output_weight" not in df.columns:
        raise Exception(
            "The functions `input_weight`  and `output_weight` must precede the function `calculate_output_input_weight_ratio_per_standard_time_period`!"
        )

    return (
        df.loc[:, ["input_weight", "output_weight"]]
        .resample(time_period)
        .sum()
        .assign(
            output_input_diff=lambda df: df.output_weight.sub(df.input_weight),
            output_input_ratio=lambda df: df.output_weight.div(df.input_weight),
        )
    )


def make_transformations(
    df: pd.DataFrame, transformations: TransformationsCallables, progbar: bool = True
) -> pd.DataFrame:
    """
    Applies all tranformation functions defined as a list of transformation function names (Callables).
    If transformation is parametrized, use `partial` from `functools` to predefine arguments.
    For more informations see https://docs.python.org/3/library/functools.html#functools.partial.

    Example:
        >>> make_transformations(
                dataset,
                [
                    transformation_function_1,
                    partial(transformation_function_2, arg1=arg1, arg2=arg2),
                ]
            )
    """
    for transformation in tqdm(transformations, desc="Applying transformations", disable=not progbar):
        df = df.pipe(transformation)

    return df
