from functools import partial

from dbfcore.dataset.preprocessed_dataset.transformations.charge_flows import (
    get_charge_flows_time_series_for_multiple_columns,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import ChainMap, Value, ValueDict
from dbfcore.dataset.utils import get_float32_with_label, get_timestamp_with_label
from dbfcore.settings import NUMBER_OF_RAW_MATERIAL_COLUMNS, PREPROCESSED_DATASETS_PATH

SAMPLING_FREQ_SECS = 15
CHARGE_FLOWS_15_KEY = f"charge-flows-{SAMPLING_FREQ_SECS}"
CHARGE_FLOWS_15_PREPROCESSED_DATASET_PATH = PREPROCESSED_DATASETS_PATH + "/" + CHARGE_FLOWS_15_KEY


def get_single_raw_material_weight(idx: int) -> ValueDict:
    return {
        f"raw_material_weight_{idx}": Value(
            dtype="float32",
            id='{"label": "Hmotnosť suroviny", "unit": "kg", "type": "extensive"}',
        )
    }


def get_raw_material_weights(max_idx: int) -> ValueDict:
    return dict(ChainMap(*[get_single_raw_material_weight(idx) for idx in range(max_idx, 0, -1)]))


CHARGE_FLOWS_15_INPUT_FEATURES = {
    "charge_date": get_timestamp_with_label("Časová značka vsádzky"),
    **get_raw_material_weights(NUMBER_OF_RAW_MATERIAL_COLUMNS),
}
CHARGE_FLOWS_15_OUTPUT_FEATURES = {
    "flow_start_time": get_timestamp_with_label("Zaciatok prietokoveho intervalu"),
    "flow_end_time": get_timestamp_with_label("Koniec prietokoveho intervalu"),
    "first_charge_start_time": get_timestamp_with_label("Časová značka zaciatku vsádzky"),
    "last_charge_end_time": get_timestamp_with_label("Časová značka konca vsádzky"),
    **{
        f"raw_material_{i}_flow_kg_h": get_float32_with_label(f"Prietok suroviny c.{i} pocas vsadzky")
        for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
    },
}
CHARGE_FLOWS_15_TRANSFORMATIONS: TransformationsCallables = [
    partial(select_columns, columns=CHARGE_FLOWS_15_INPUT_FEATURES),
    partial(
        get_charge_flows_time_series_for_multiple_columns,
        charge_end_col="charge_date",
        cols=get_raw_material_weights(NUMBER_OF_RAW_MATERIAL_COLUMNS),
        sampling_freq_secs=SAMPLING_FREQ_SECS,
    ),
    partial(select_columns, columns=CHARGE_FLOWS_15_OUTPUT_FEATURES),
]
