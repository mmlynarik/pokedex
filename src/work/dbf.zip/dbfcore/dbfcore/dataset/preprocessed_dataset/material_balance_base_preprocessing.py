from functools import partial
from typing import Iterable

from datasets import Value

from dbfcore.dataset.preprocessed_dataset.transformations.pig_iron import (
    average_pig_iron_analysis,
    calculate_pig_iron_element_weights,
    calculate_pig_iron_fe_pct_avg,
    sum_pig_iron_weights,
)
from dbfcore.dataset.preprocessed_dataset.transformations.pulverized_coal import (
    calculate_qpu_mineral_weight,
    calculate_qpu_weight,
)
from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_control_weight_and_percentage,
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_charge_weight,
    calculate_total_mineral_weight,
)
from dbfcore.dataset.preprocessed_dataset.transformations.slag import (
    calculate_slag_mineral_weights,
    calculate_slag_weights_from_pots,
    sum_slag_weights,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, drop_columns, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    STEELSHOP_DATA_COLUMNS,
    get_pig_iron_weight_columns,
    get_raw_material_columns,
)
from dbfcore.dataset.utils import (
    ValueDict,
    get_float32_with_label,
    get_int32_with_label,
    get_timestamp_with_label,
)
from dbfcore.settings import (
    NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS,
    NUMBER_OF_RAW_MATERIAL_COLUMNS,
    PIG_IRON_ELEMENTS,
    RAW_MATERIAL_MINERALS,
    SENSORS_DATA_TIME_PERIOD,
    SLAG_MINERALS,
)


def get_qpu_mineral_weight_columns(minerals: Iterable[str]) -> ValueDict:
    return {
        f"qpu_{mineral}_weight": Value(
            dtype="float32",
            id=f'{{"label": "Hmotnosť {mineral} v práškovom uhlí", "unit": "kg", "type": "extensive"}}',
        )
        for mineral in minerals
    }


def get_raw_material_mineral_weight_columns(minerals: Iterable[str]) -> ValueDict:
    return {
        f"{mineral}_weight": Value(
            dtype="float32",
            id=f'{{"label": "Celková hmotnosť {mineral} v surovinách", "unit": "kg", "type": "extensive"}}',
        )
        for mineral in minerals
    }


def get_pig_iron_element_weight_columns(elements: Iterable[str]) -> ValueDict:
    return {
        f"pig_iron_{element}_weight": Value(
            dtype="float32",
            id=f'{{"label": "Hmotnosť {element} v surovom železe", "unit": "t", "type": "extensive"}}',
        )
        for element in elements
    }


def get_slag_element_weight_columns(elements: Iterable[str]) -> ValueDict:
    return {
        f"slag_{element}_weight": Value(
            dtype="float32",
            id=f'{{"label": "Hmotnosť {element} v troske", "unit": "t", "type": "extensive"}}',
        )
        for element in elements
    }


# To improve performance of preprocessed dataset generation, we drop raw dataset columns we don't need
columns_to_drop = STEELSHOP_DATA_COLUMNS.keys()


# Selecting the columns to be in the preprocessed dataset
BASE_MATERIAL_BALANCE_FEATURES: ValueDict = {
    "date": get_timestamp_with_label("Dataset index"),
    "QZPC": Value(
        dtype="float32",
        id='{"label": "Množstvo zemného plynu pre VP1", "unit": "m^3/h", "type": "extensive"}',
    ),
    "QCVP": Value(
        dtype="float32",
        id='{"label": "Množstvo vysokopecného plynu", "unit": "m^3/h",  "type": "intensive"}',
    ),
    "PS": Value(
        dtype="float32",
        id='{"label": "Tlak vysokopecného plynu", "unit": "kPa", "type": "intensive"}',
    ),
    "CO": Value(
        dtype="float32",
        id='{"label": "Podiel CO vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
    ),
    "CO2": Value(
        dtype="float32",
        id='{"label": "Podiel CO2 vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
    ),
    "H2": Value(
        dtype="float32",
        id='{"label": "Podiel H2 vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
    ),
    "TKP": Value(
        dtype="float32",
        id='{"label": "Teplota plynu na sadzobni (priemerná)", "unit": "°C", "type": "intensive"}',
    ),
    "QPU_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť práškového uhlia", "unit": "kg", "type": "extensive"}',
    ),
    **get_qpu_mineral_weight_columns(RAW_MATERIAL_MINERALS),
    "charge_date": get_timestamp_with_label("Časová značka vsádzky"),
    "charge_number": get_int32_with_label("Číslo vsádzky"),
    "charge_weight": Value(
        dtype="float32",
        id='{"label": "Celková hmotnosť vsádzky", "unit": "kg", "type": "extensive"}',
    ),
    **get_raw_material_mineral_weight_columns(RAW_MATERIAL_MINERALS),
    "weight_sum": Value(
        dtype="float32",
        id='{"label": "Hmotnosť vsádzky (kontrolný súčet hmotností všetkých minerálov)", "unit": "kg", "type": "extensive"}',
    ),
    "weight_pct": get_float32_with_label("Pomer celkovej hmotnosti vsádzky a kontrolnej hmotnosti vsádzky"),
    "tapping_number": get_int32_with_label("Číslo odpichu"),
    "tapping_start_date": get_timestamp_with_label("Časová značka začiatku odpichu"),
    "tapping_end_date": get_timestamp_with_label("Časová značka konca odpichu"),
    "tapping_slag_start": get_timestamp_with_label("Časová značka začiatku trosky"),
    "tapping_id": get_int32_with_label("ID odpichu"),
    "pig_iron_weight_sum": Value(
        dtype="float32",
        id='{"label": "Celková hmotnosť surového železa", "unit": "t", "type": "extensive"}',
    ),
    **get_pig_iron_element_weight_columns(PIG_IRON_ELEMENTS),
    "slag_weight_sum": Value(
        dtype="float32",
        id='{"label": "Celková hmotnosť trosky", "unit": "t", "type": "extensive"}',
    ),
    **get_slag_element_weight_columns(SLAG_MINERALS),
}


BASE_MATERIAL_BALANCE_KEY = "material-balance-base"
BASE_MATERIAL_BALANCE_TRANSFORMATIONS: TransformationsCallables = [
    partial(drop_columns, columns=columns_to_drop),
    # QPU transformations
    partial(calculate_qpu_weight, col="QPU", time_period=SENSORS_DATA_TIME_PERIOD),
    partial(calculate_qpu_mineral_weight, minerals=RAW_MATERIAL_MINERALS),
    # raw material transformation functions
    partial(calculate_mineral_weight_of_all_raw_materials, minerals=RAW_MATERIAL_MINERALS),
    calculate_total_charge_weight,
    partial(calculate_total_mineral_weight, minerals=RAW_MATERIAL_MINERALS),
    partial(calculate_control_weight_and_percentage, minerals=RAW_MATERIAL_MINERALS),
    partial(drop_columns, columns=get_raw_material_columns(NUMBER_OF_RAW_MATERIAL_COLUMNS)),
    # pig iron transformation functions
    sum_pig_iron_weights,
    partial(average_pig_iron_analysis, elements=PIG_IRON_ELEMENTS),
    calculate_pig_iron_fe_pct_avg,
    partial(calculate_pig_iron_element_weights, elements=PIG_IRON_ELEMENTS),
    partial(drop_columns, columns=get_pig_iron_weight_columns(NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS)),
    # slag transformation functions
    calculate_slag_weights_from_pots,
    sum_slag_weights,
    partial(calculate_slag_mineral_weights, minerals=SLAG_MINERALS),
    # select columns for preprocessed dataset
    lambda df: df.reset_index(),
    partial(select_columns, columns=BASE_MATERIAL_BALANCE_FEATURES.keys()),
]
