from datetime import datetime
from typing import Optional

import pandas as pd


def select_charges_only(df: pd.DataFrame) -> pd.DataFrame:
    """Select only rows that contain charges"""
    return df[~df["charge_date"].isna()]


def get_flow_periods(freq: pd.Timedelta, first_start: pd.Timestamp, last_start: pd.Timestamp) -> pd.DataFrame:
    """Generate flow periods dataframe"""
    flow_start_time = pd.date_range(first_start, last_start - freq, freq=freq, tz="UTC")
    flow_end_time = pd.date_range(first_start + freq, last_start, freq=freq, tz="UTC")
    return pd.DataFrame({"flow_start_time": flow_start_time, "flow_end_time": flow_end_time})


def prepare_charge_periods(df: pd.DataFrame, charge_end_col: str) -> pd.DataFrame:
    """Return modified dataframe with prepared charge periods columns"""
    df = df.rename(columns={charge_end_col: "charge_end_time"})
    df["charge_start_time"] = df["charge_end_time"].shift(1)
    df["charge_period_hrs"] = (df["charge_end_time"] - df["charge_start_time"]).dt.total_seconds() / 3600
    df = df[(df["charge_period_hrs"] > 0) | (df["charge_period_hrs"].isna())]
    head = ["charge_start_time", "charge_end_time", "charge_period_hrs"]
    df = df.reindex(columns=head + list(df.columns.drop(head)))
    return df


def calculate_charges_dict_for_flow_period(
    row,
    charge_periods_start: pd.DataFrame,
    charge_periods_end: pd.DataFrame,
    charge_periods: pd.DataFrame,
    cols: list[str],
) -> dict:
    """Calculate dictionary of relevant charge periods for given flow period"""
    start_idx = charge_periods_start.index.searchsorted(row["first_charge_start_time"])
    end_idx = charge_periods_end.index.searchsorted(row["last_charge_end_time"])
    relevant_charge_periods = charge_periods.iloc[start_idx : end_idx + 1]
    charges_dict = {}
    for _, row in relevant_charge_periods.iterrows():
        charges_dict[(row["charge_start_time"], row["charge_end_time"])] = [
            row[f"charge{col.replace('_weight', '')}_flow_kgh"] for col in cols
        ]
    return charges_dict


def calculate_charge_flow(row, col_idx: int, sampling_freq: pd.Timedelta) -> float:
    """Calculate charge flow for given flow period and given column index, using relevant charges"""
    flow = 0
    num_charges = len(row["charges_dict"])
    for idx, ((charge_start_time, charge_end_time), flows) in enumerate(row["charges_dict"].items()):
        if num_charges == 1:
            flow += flows[col_idx] * (row["flow_end_time"] - row["flow_start_time"]).total_seconds()
        elif idx == 0:
            flow += flows[col_idx] * (charge_end_time - row["flow_start_time"]).total_seconds()
        elif idx == num_charges - 1:
            flow += flows[col_idx] * (row["flow_end_time"] - charge_start_time).total_seconds()
        else:
            flow += flows[col_idx] * (charge_end_time - charge_start_time).total_seconds()
    return flow / sampling_freq.total_seconds()


def calculate_per_charge_flow_variables(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """Calculate per-charge charge flow variables from weight and charge period data"""
    for col in cols:
        df[f"charge{col.replace('_weight', '')}_flow_kgh"] = df[col] / df["charge_period_hrs"]
    # exclude first row with NaN values to allow pd.merge_asof to work
    return df[1:].reset_index(drop=True)


def filter_out_of_range_rows(df: pd.DataFrame) -> pd.DataFrame:
    """Filter flow periods for which no charge exists"""
    df = df[(~df["first_charge_start_time"].isna()) & (df["flow_start_time"] <= df["last_charge_end_time"])]
    df = df.reset_index(drop=True)
    return df


def join_boundary_charges_to_flow_periods(
    charge_periods: pd.DataFrame, flow_periods: pd.DataFrame
) -> pd.DataFrame:
    """Identify start of first and end of last relevant charge influencing given flow period"""
    first_charges = pd.merge_asof(
        flow_periods,
        charge_periods,
        left_on="flow_start_time",
        right_on="charge_start_time",
        allow_exact_matches=True,
        direction="backward",
    )[["flow_start_time", "flow_end_time", "charge_start_time"]]

    last_charges = pd.merge_asof(
        flow_periods,
        charge_periods,
        left_on="flow_end_time",
        right_on="charge_end_time",
        allow_exact_matches=True,
        direction="forward",
    )[["flow_start_time", "flow_end_time", "charge_end_time"]]

    flows = pd.merge(first_charges, last_charges, how="inner", on=["flow_start_time", "flow_end_time"])
    flows = flows.rename(
        columns={"charge_start_time": "first_charge_start_time", "charge_end_time": "last_charge_end_time"}
    )
    flows = filter_out_of_range_rows(flows)
    return flows


def get_charge_flows_time_series_for_multiple_columns(
    df: pd.DataFrame,
    weight_cols: list[str],
    charge_end_col: str,
    sampling_freq: pd.Timedelta,
    start: Optional[datetime] = None,
    end: Optional[datetime] = None,
    remove_dict: bool = True,
) -> pd.DataFrame:
    """
    Process raw dataset and return charge flows time series based on selected flow range and frequency.
    Flow range is either [`start`, `end`] (live prediction) or df's [first charge, last charge] (training).
    Remove dict is set to True because datasets library cannot accept dict column type as feature.
    """
    charges = select_charges_only(df)
    charge_periods = prepare_charge_periods(charges, charge_end_col)
    min_charge_start_time = charge_periods["charge_start_time"].min().floor("min")
    max_charge_end_time = charge_periods["charge_end_time"].max().floor("min")
    charge_periods = calculate_per_charge_flow_variables(charge_periods, weight_cols)
    flow_periods = get_flow_periods(sampling_freq, start or min_charge_start_time, end or max_charge_end_time)
    flow_periods = join_boundary_charges_to_flow_periods(charge_periods, flow_periods)
    # Prepare charge_periods indexed with start and end time for better performance within apply function
    charge_periods_start = charge_periods.set_index("charge_start_time")
    charge_periods_end = charge_periods.set_index("charge_end_time")
    flow_periods["charges_dict"] = flow_periods.apply(
        lambda row: calculate_charges_dict_for_flow_period(
            row, charge_periods_start, charge_periods_end, charge_periods, weight_cols
        ),
        axis=1,
    )
    for idx, col in enumerate(weight_cols):
        flow_periods[f"charge{col.replace('_weight', '')}_flow_kgh"] = flow_periods.apply(
            lambda row: calculate_charge_flow(row, idx, sampling_freq), axis=1
        )
    flow_periods["date"] = flow_periods["flow_end_time"]
    if remove_dict:
        flow_periods = flow_periods.drop(columns=["charges_dict"])

    return flow_periods
