from itertools import product

import pandas as pd

from dbfcore.settings import COKES, NUMBER_OF_RAW_MATERIAL_COLUMNS, RAW_MATERIAL_MINERALS


def calculate_mineral_weight_of_all_raw_materials(
    df: pd.DataFrame,
    minerals: list[str] = RAW_MATERIAL_MINERALS,
    num_raw_materials: int = NUMBER_OF_RAW_MATERIAL_COLUMNS,
) -> pd.DataFrame:
    """
    Calculates the weights of selected minerals for all raw materials:
        raw_material_weight [kg] * raw_material_analysis [%] -> [kg]
    """

    dfs = [df]
    raw_material_column_numbers = range(1, num_raw_materials + 1)

    for col_number, mineral in product(raw_material_column_numbers, minerals):
        raw_material_weight_df = pd.DataFrame()

        raw_material_weight_df[f"raw_material_{mineral}_weight_{col_number}"] = (
            df[f"raw_material_weight_{col_number}"] * df[f"raw_material_{mineral}_pct_{col_number}"] * 0.01
        )

        dfs.append(raw_material_weight_df)

    return pd.concat(dfs, axis=1)


def calculate_total_charge_weight(
    df: pd.DataFrame, num_raw_materials: int = NUMBER_OF_RAW_MATERIAL_COLUMNS
) -> pd.DataFrame:
    """Calculates the total charge weight of all raw material weight columns."""

    raw_material_column_numbers = range(1, num_raw_materials + 1)
    columns = [
        col
        for col_number in raw_material_column_numbers
        for col in df.columns
        if col == f"raw_material_weight_{col_number}"
    ]

    return df.assign(charge_weight=lambda df: df[columns].sum(axis=1))


def calculate_total_mineral_weight(
    df: pd.DataFrame, minerals: list[str], num_raw_materials: int = NUMBER_OF_RAW_MATERIAL_COLUMNS
) -> pd.DataFrame:
    """
    Calculate the total weight of specified minerals contained in raw material (sum of all mineral weights).
    """

    raw_material_column_numbers = range(1, num_raw_materials + 1)

    if f"raw_material_{minerals[0]}_weight_{raw_material_column_numbers[0]}" not in df.columns:
        raise Exception(
            "The function `calculate_mineral_weight_of_all_raw_materials` must precede the function `calculate_total_mineral_weight`!"
        )

    columns = [
        col
        for col_number in raw_material_column_numbers
        for mineral in minerals
        for col in df.columns
        if col == f"raw_material_{mineral}_weight_{col_number}"
    ]

    df_weights = df[columns]

    dfs = [df]
    for mineral in minerals:
        cols = [col for col in df_weights.columns if f"raw_material_{mineral}_weight" in col]
        mineral_weight = df_weights[cols].sum(axis=1).rename(f"{mineral}_weight")
        dfs.append(mineral_weight)

    return pd.concat(dfs, axis=1)


def calculate_control_weight_and_percentage(df: pd.DataFrame, minerals: list[str]) -> pd.DataFrame:
    """Assigns control sum of mineral weights and its percentage ratio from original charge weight."""

    if f"{minerals[0]}_weight" not in df.columns:
        raise Exception(
            "The function `calculate_total_mineral_weight` must precede the function `calculate_control_weight_and_percentage`!"
        )

    columns = [col for mineral in minerals for col in df.columns if col == f"{mineral}_weight"]

    return df.assign(
        weight_sum=lambda df: df[columns].sum(axis=1),
        weight_pct=lambda df: df.weight_sum / df.charge_weight * 100,
    )


def get_coke_weight(df: pd.DataFrame) -> pd.DataFrame:
    def get_coke_charge_weight_for_one_row(row, coke_material_numbers: list[int] = COKES) -> float:
        weight = 0
        for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1):
            if row[f"raw_material_number_{i}"] in coke_material_numbers:
                weight += row[f"raw_material_weight_{i}"]
        return weight

    # Filter unused rows to improve performance of this transformation
    df_charge = df[~df["raw_material_number_1"].isna()][
        [
            f"raw_material_{item}_{i}"
            for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
            for item in ["weight", "number"]
        ]
    ]
    df_charge["coke_weight"] = df_charge.apply(lambda row: get_coke_charge_weight_for_one_row(row), axis=1)
    return df.merge(df_charge["coke_weight"], how="left", left_index=True, right_index=True)
