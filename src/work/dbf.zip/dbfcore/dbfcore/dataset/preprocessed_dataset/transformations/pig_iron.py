import numpy as np
import pandas as pd

from dbfcore.dataset.raw_dataset.utils import generate_column_names_with_trailing_integer
from dbfcore.settings import NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS, PIG_IRON_WEIGHT_COLUMN_NAME

# TEMPORARILY COMMENTED OUT BECAUSE WE DON'T USE THEM
# THESE FUNCTIONS MAY BE REMOVED IN THE FUTURE

# def distribute_tapping_id_in_time(df: pd.DataFrame) -> pd.DataFrame:
#     df_to_melt = df[["tapping_id", "tapping_start_date", "tapping_end_date"]].dropna()

#     df_to_merge = (
#         df_to_melt.melt(
#             id_vars=["tapping_id"],
#             value_vars=["tapping_start_date", "tapping_end_date"],
#             var_name="process",
#             value_name="date",
#         )
#         .sort_values("date")
#         .set_index("date")
#         .drop(columns="process")
#         .astype("int64")
#     )

#     df_to_merge.index = pd.to_datetime(df_to_merge.index)
#     df_resampled = pd.concat(
#         [
#             df_to_merge.loc[df_to_merge.tapping_id == tap_id].resample("1min").bfill().astype("int64")
#             for tap_id in df_to_merge.tapping_id.unique()
#         ]
#     )

#     return df.merge(df_resampled, on="date", how="left").rename(
#         columns={"tapping_id_x": "tapping_id", "tapping_id_y": "tapping_id_distributed"}
#     )


# def distribute_pig_iron_weight(df: pd.DataFrame) -> pd.DataFrame:
#     pig_iron_weight_cols = [column for column in df.columns if "pig_iron_weight" in column]
#     pig_iron_weight_df = pd.DataFrame(
#         data={"tapping_id": df.tapping_id, "total_weight": df[pig_iron_weight_cols].sum(axis=1)}
#     )
#     pig_iron_weight_df = pig_iron_weight_df[pig_iron_weight_df["tapping_id"].notna()]
#     pig_iron_weight_df.index = pig_iron_weight_df.tapping_id.astype(float)

#     row_count_per_tapping_id = (
#         df.groupby("tapping_id_distributed")
#         .size()
#         .reset_index(name="count")
#         .set_index("tapping_id_distributed")
#     )
#     row_count_per_tapping_id.index = row_count_per_tapping_id.index.astype(float)

#     df["pig_iron_weight_distributed"] = df["tapping_id_distributed"].map(
#         pig_iron_weight_df["total_weight"] / row_count_per_tapping_id["count"]
#     )

#     return df


def calculate_pig_iron_fe_pct(df: pd.DataFrame, analysis_num: int) -> pd.DataFrame:
    """
    Calculates the pig iron pct of Fe as a difference between 100 (percent)
    and a sum of all measured percentages of elements in pig iron.
    The calculation is specific for the defined pig iron analysis number.
    """

    cols = [
        col for col in df.columns if ("pig_iron" in col) & (f"pct_{analysis_num}" in col) & ("fe" not in col)
    ]

    df = df.copy()
    df[f"pig_iron_fe_pct_{analysis_num}"] = 100 - df[cols].sum(axis=1, skipna=False)

    return df


def sum_pig_iron_weights(df: pd.DataFrame) -> pd.DataFrame:
    """Sums pig iron weights (1-6) and assigns the sum to column `pig_iron_weight_sum`. The unit is [t]."""

    columns = np.concatenate(
        [
            generate_column_names_with_trailing_integer([PIG_IRON_WEIGHT_COLUMN_NAME], num)
            for num in range(1, NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS + 1)
        ]
    )

    return df.assign(pig_iron_weight_sum=lambda df: df[columns].sum(axis=1))


def average_pig_iron_analysis(df: pd.DataFrame, elements: list[str]) -> pd.DataFrame:
    """Creates an average of the three pig iron analyzes for specified elements present in the pig iron."""

    dfs = [df]

    for element in elements:
        cols = [col for col in df.columns if f"pig_iron_{element}_pct" in col]
        d = df[cols].mean(axis=1).rename(f"pig_iron_{element}_pct_avg")
        dfs.append(d)

    return pd.concat(dfs, axis=1)


def calculate_pig_iron_fe_pct_avg(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates the average pig iron pct of Fe as a difference between 100 (percent)
    and a sum of all measured percentages of elements in pig iron.
    """

    cols = [col for col in df.columns if ("pig_iron" in col) & ("pct_avg" in col) & ("fe" not in col)]

    if not cols:
        raise Exception(
            "The function `average_pig_iron_analysis` must precede the function `calculate_pig_iron_fe_pct_avg`!"
        )

    return df.assign(pig_iron_fe_pct_avg=lambda df: 100 - df[cols].sum(axis=1, skipna=False))


def calculate_pig_iron_element_weights(df: pd.DataFrame, elements: list[str]) -> pd.DataFrame:
    """
    Calculates the weight of each pig iron element:
        pig_iron_weight_sum [t] * pig_iron_element_analysis [%] -> [t]
    """

    if "pig_iron_weight_sum" not in df.columns:
        raise Exception(
            "The function `sum_pig_iron_weights` must precede the function `calculate_pig_iron_element_weights`!"
        )
    if f"pig_iron_{elements[0]}_pct_avg" not in df.columns:
        raise Exception(
            "The function `average_pig_iron_analysis` must precede the function `calculate_pig_iron_element_weights`!"
        )

    for element in elements:
        df[f"pig_iron_{element}_weight"] = (
            df["pig_iron_weight_sum"] * df[f"pig_iron_{element}_pct_avg"] * 0.01
        )

    return df
