import pandas as pd


def calculate_qpu_weight(df: pd.DataFrame, col: str, time_period: int) -> pd.DataFrame:
    """
    Calculates the QPU weight for specified time period in minutes. QPU is measured using sensors.
    The unit of QPU is [kg/h]. Thus, the amount (in kg) of QPU per time period in minutes:
        QPU / 60 [minutes] * time_period [minutes] -> [kg]
    """

    return df.assign(QPU_weight=lambda df: df[col] / 60 * time_period)


def calculate_qpu_mineral_weight(df: pd.DataFrame, minerals: list[str]) -> pd.DataFrame:
    """
    Calculates the weight of each mineral contained in QPU
        QPU_weight [kg] * QPU_element_analysis [%] -> [kg]
    """

    if "QPU_weight" not in df.columns:
        raise Exception(
            "The function `calculate_qpu_weight` must precede the function `calculate_qpu_mineral_weight`!"
        )

    for mineral in minerals:
        df[f"qpu_{mineral}_weight"] = df["QPU_weight"] * df[f"qpu_{mineral}_pct"] * 0.01

    return df


def calculate_carbon_weight_in_qpu(df: pd.DataFrame, carbon_ratio_in_qpu: float) -> pd.DataFrame:
    """
    Calculates the carbon weight in QPU using the defined carbon ratio in QPU.
    Carbon weight in QPU is calculated in kg:
        QPU_weight [kg] * carbon_ratio_in_qpu [%] -> [kg]
    """

    if "QPU_weight" not in df.columns:
        raise Exception(
            "The function `calculate_qpu_weight` must precede the function `calculate_carbon_weight_in_qpu`!"
        )

    return df.assign(QPU_c_weight=lambda df: df.QPU_weight * carbon_ratio_in_qpu)
