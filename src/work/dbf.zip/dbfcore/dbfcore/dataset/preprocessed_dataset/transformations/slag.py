import pandas as pd

from dbfcore.settings import NUMBER_OF_SLAG_POT_COLUMNS, SLAG_POT_WEIGHT


def calculate_slag_weights_from_pots(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates slag weight of each slag pot. Slag pot fill value is defined in quarters.
    Slag weights are calculated as follows:
        slag_pot_fill_value / 4 * SLAG_POT_WEIGHT [t] -> [t]
    """

    for i in range(1, NUMBER_OF_SLAG_POT_COLUMNS + 1):
        df[f"slag_weight_{i}"] = df[f"slag_pot_fill_value_{i}"] / 4 * SLAG_POT_WEIGHT

    return df


def sum_slag_weights(df: pd.DataFrame) -> pd.DataFrame:
    """Sums slag weights (1-10) and assigns the sum to column `slag_weight_sum` -> [t]."""

    if "slag_weight_1" not in df.columns:
        raise Exception(
            "The function `calculate_slag_weights_from_pots` must precede the function `sum_slag_weights`!"
        )

    columns = [col for col in df.columns if "slag_weight" in col]

    return df.assign(slag_weight_sum=lambda df: df[columns].sum(axis=1))


def calculate_slag_mineral_weights(df: pd.DataFrame, minerals: list[str]) -> pd.DataFrame:
    """Calculates slag weight for all minerals defined in argument."""

    if "slag_weight_sum" not in df.columns:
        raise Exception(
            "The function `sum_slag_weights` must precede the function `calculate_slag_mineral_weights`!"
        )

    for mineral in minerals:
        df[f"slag_{mineral}_weight"] = df["slag_weight_sum"] * df[f"slag_{mineral}_pct"] * 0.01

    return df
