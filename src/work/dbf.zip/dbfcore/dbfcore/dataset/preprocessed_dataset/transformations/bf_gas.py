import pandas as pd
import periodictable

from dbfcore.settings import CELSIUS_TO_KELVIN_CONVERTER_UNIT, GAS_CONSTANT


def calculate_qcvp_volume(df: pd.DataFrame, time_period: int) -> pd.DataFrame:
    """
    Calculates the QCVP volume for specified time period in minutes. QCVP is measured using sensors.
    The unit of QCVP is [m3/h]. Thus, the volume (in m3) of QCVP per time period in minutes:
        QCVP [m3/h] / 60 [minutes] * time_period [minutes] -> [m3]
    """

    return df.assign(QCVP_volume=lambda df: df.QCVP / 60 * time_period)


def calculate_fraction_of_n2_in_bf_gas(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates the percentage fraction of N2 in blast furnace gas.
    The fraction of N2 is defined as a difference between 100 (%) and the sum of the
    fractions of CO, CO2, and H2 present in the blast furnace gas:
        100 [%] - sum(CO, CO2, H2) [%] -> [%]
    """

    return df.assign(N2=lambda df: 100 - df[["CO", "CO2", "H2"]].sum(axis=1, skipna=False))


def calculate_partial_pressure(df: pd.DataFrame, chemical_compound: str) -> pd.DataFrame:
    """
    Calculates partial pressure of the defined chemical compound present in the blast furnace gas.
    The partial pessure of the chemical compound in BF gas is calculated as follows:
        bf_gas_pressure [Pa] * chemical_compound_ratio [%] -> [Pa]
    """

    # We check only for N2 because the other compounds are present in raw dataset
    if chemical_compound == "N2" and "N2" not in df.columns:
        raise Exception(
            "The function `calculate_fraction_of_n2_in_bf_gas` must precede the function `calculate_partial_pressure`!"
        )

    df[f"{chemical_compound}_pressure"] = df["PS"] * df[f"{chemical_compound}"] * 0.01

    return df


def convert_bf_gas_temperature_from_C_to_K(df: pd.DataFrame) -> pd.DataFrame:
    """Converts the BF gas temperature from °C to K."""

    return df.assign(TKP_K=lambda df: df.TKP + CELSIUS_TO_KELVIN_CONVERTER_UNIT)


def _define_molar_mass(chemical_compound: str) -> float:
    """Defines molar mass of a chemical compound. The unit is [g/mol]"""

    return periodictable.formula(chemical_compound).mass


def calculate_bf_gas_weight(df: pd.DataFrame, chemical_compound: str) -> pd.DataFrame:
    """
    Calculates the weight of a specified fraction (chemical compound) of blast furnace gas.
    For the calculation of blast furnace gas we use the ideal gas law equation:
        pressure [kPa] * volume [m3] * molar_mass [g/mol] /
        ideal_gas_constant [Pa⋅m3/K⋅mol] * thermodynamic_temperature [K]
        -> [kg]
    """

    if f"{chemical_compound}_pressure" not in df.columns:
        raise Exception(
            "The function `calculate_partial_pressure` must precede the function `calculate_bf_gas_weight`!"
        )
    if "QCVP_volume" not in df.columns:
        raise Exception(
            "The function `calculate_qcvp_volume` must precede the function `calculate_bf_gas_weight`!"
        )
    if "TKP_K" not in df.columns:
        raise Exception(
            "The function `convert_bf_gas_temperature_from_C_to_K` must precede the function `calculate_bf_gas_weight`!"
        )

    molar_mass = _define_molar_mass(chemical_compound)
    df[f"bf_gas_{chemical_compound}_weight"] = (
        df[f"{chemical_compound}_pressure"] * df.QCVP_volume * molar_mass
    ) / (GAS_CONSTANT * df.TKP_K)

    return df


def calculate_combined_bf_gas_weight(df: pd.DataFrame, bf_gas_weight_cols: list[str]) -> pd.DataFrame:
    """Calculates the combined mass of specified gases (columns) of blast furnace gas -> [kg]."""

    return df.assign(bf_gas_weight=df[bf_gas_weight_cols].sum(axis=1, skipna=False))
