import pandas as pd


def calculate_dust_weight(df: pd.DataFrame, dust_unit_of_measure: int) -> pd.DataFrame:
    """
    Calculates the dust weight that is expressed by `dust_unit_of_measure` per 1 ton of pig iron.
    Dust weight is calculated using following formula:
        pig_iron_weight_sum [t] * dust_unit_of_measure [kg] -> [kg]
    """

    if "pig_iron_weight_sum" not in df.columns:
        raise Exception(
            "The function `sum_pig_iron_weights` must precede the function `calculate_dust_weight`!"
        )

    return df.assign(dust_weight=lambda df: df.pig_iron_weight_sum * dust_unit_of_measure)


def calculate_carbon_weight_in_dust(df: pd.DataFrame, carbon_ratio_in_dust: float) -> pd.DataFrame:
    """
    Calculates the carbon weight in dust out of the overall dust weight and the carbon ratio in dust.
    Carbon weight in dust is calculated using following formula:
        dust_weight [kg] * carbon_ratio_in_dust [%] -> [kg]
    """

    if "dust_weight" not in df.columns:
        raise Exception(
            "The function `calculate_dust_weight` must precede the function `calculate_carbon_weight_in_dust`!"
        )

    return df.assign(dust_c_weight=lambda df: df.dust_weight * carbon_ratio_in_dust)
