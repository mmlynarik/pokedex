from functools import partial
from pathlib import Path

import pandas as pd

from dbfcore.dataset.preprocessed_dataset.transformations.charge_flows import (
    get_charge_flows_time_series_for_multiple_columns,
    select_charges_only,
)
from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_mineral_weight,
    get_coke_weight,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    ChainMap,
    Value,
    ValueDict,
    get_granulometry_columns,
)
from dbfcore.dataset.utils import get_float32_with_label, get_timestamp_with_label
from dbfcore.settings import (
    GRANULOMETRY_FRACTIONS_MAP,
    NUMBER_OF_RAW_MATERIAL_COLUMNS,
    PREPROCESSED_DATASETS_PATH,
    RAW_MATERIAL_MINERALS,
)

# TODO: Get rid of SAMPLING_FREQ_SECS, keep only FLOWS_SAMPLING_FREQ
FLOWS_SAMPLING_FREQ = pd.Timedelta("2min")

AUTOENCODER_FLOWS_KEY = "autoencoder-flows"
AUTOENCODER_FLOWS_PREPROCESSED_DATASET_PATHS = PREPROCESSED_DATASETS_PATH + "/" + AUTOENCODER_FLOWS_KEY

GRANULOMETRY_FRACTIONS = [
    f"{category}_{fraction}"
    for category, fractions in GRANULOMETRY_FRACTIONS_MAP.items()
    for fraction in fractions
]

OTHER_DERIVED_FEATURES = ["coke"]


def get_autoencoder_flows_preprocessed_dataset_path(furnace_id: int) -> Path:
    return Path(AUTOENCODER_FLOWS_PREPROCESSED_DATASET_PATHS, f"vp{furnace_id}")


def get_single_raw_material_info(idx: int) -> ValueDict:
    return {
        f"raw_material_number_{idx}": Value(
            dtype="int32",
            id='{"label": "Kódové označenie (ID) suroviny")}',
        ),
        f"raw_material_weight_{idx}": Value(
            dtype="int32",
            id='{"label": "Hmotnosť suroviny", "unit": "kg", "type": "extensive"}',
        ),
        **{
            f"raw_material_{mineral}_pct_{idx}": Value(
                dtype="float32",
                id=f'{{"label": "Podiel {mineral} v surovine", "unit": "%", "type": "intensive"}}',
            )
            for mineral in RAW_MATERIAL_MINERALS
        },
    }


def get_raw_material_info(max_idx: int) -> ValueDict:
    return dict(ChainMap(*[get_single_raw_material_info(idx) for idx in range(max_idx, 0, -1)]))


def get_mineral_weight_columns(minerals: list[str] = RAW_MATERIAL_MINERALS) -> list[str]:
    return [f"{mineral}_weight" for mineral in minerals]


def get_granulometry_weight_columns(fractions: list[str] = GRANULOMETRY_FRACTIONS) -> list[str]:
    return [f"{fraction}_weight" for fraction in fractions]


def get_derived_weight_columns() -> list[str]:
    return ["coke_weight"]


def get_autoencoder_weight_columns(
    minerals: list[str] = RAW_MATERIAL_MINERALS, fractions: list[str] = GRANULOMETRY_FRACTIONS
) -> list[str]:
    return (
        get_mineral_weight_columns(minerals)
        + get_granulometry_weight_columns(fractions)
        + get_derived_weight_columns()
    )


def calculate_granulometry_fractions_weights(
    df: pd.DataFrame, granulometry_fractions: dict[str, list[str]] = GRANULOMETRY_FRACTIONS_MAP
) -> pd.DataFrame:
    df = df.copy()
    for category, fractions in granulometry_fractions.items():
        for fraction in fractions:
            df[f"{category}_{fraction}_weight"] = df.apply(
                lambda row: sum(
                    row[f"raw_material_{fraction}_{i}"] * row[f"raw_material_weight_{i}"] / 100
                    for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
                    if row[f"raw_material_kind_{i}"] == category
                ),
                axis=1,
            )

    return df


def calculate_derived_features_weights(df: pd.DataFrame) -> pd.DataFrame:
    df = get_coke_weight(df)
    return df


AUTOENCODER_FLOWS_INPUT_FEATURES = {
    "charge_date": get_timestamp_with_label("Časová značka vsádzky"),
    **get_raw_material_info(NUMBER_OF_RAW_MATERIAL_COLUMNS),
    **get_granulometry_columns(NUMBER_OF_RAW_MATERIAL_COLUMNS),
}
AUTOENCODER_FLOWS_OUTPUT_FEATURES = {
    "date": get_timestamp_with_label("Dataset index"),
    "flow_start_time": get_timestamp_with_label("Zaciatok prietokoveho intervalu"),
    "flow_end_time": get_timestamp_with_label("Koniec prietokoveho intervalu"),
    "first_charge_start_time": get_timestamp_with_label("Časová značka zaciatku vsádzky"),
    "last_charge_end_time": get_timestamp_with_label("Časová značka konca vsádzky"),
    **{
        f"charge{mineral}_flow_kgh": get_float32_with_label(f"Prietok mineralu {mineral} pocas vsadzky")
        for mineral in RAW_MATERIAL_MINERALS
    },
    **{
        f"charge{fraction}_flow_kgh": get_float32_with_label(f"Prietok frakcie {fraction} pocas vsadzky")
        for fraction in GRANULOMETRY_FRACTIONS
    },
    **{
        f"charge{feature}_flow_kgh": get_float32_with_label(
            f"Prietok odvodenej premennej {feature} pocas vsadzky"
        )
        for feature in OTHER_DERIVED_FEATURES
    },
}
AUTOENCODER_FLOWS_TRANSFORMATIONS: TransformationsCallables = [
    partial(select_columns, columns=AUTOENCODER_FLOWS_INPUT_FEATURES),
    partial(select_charges_only),
    partial(calculate_mineral_weight_of_all_raw_materials, minerals=RAW_MATERIAL_MINERALS),
    partial(calculate_total_mineral_weight, minerals=RAW_MATERIAL_MINERALS),
    calculate_derived_features_weights,
    calculate_granulometry_fractions_weights,
    partial(
        get_charge_flows_time_series_for_multiple_columns,
        charge_end_col="charge_date",
        weight_cols=get_autoencoder_weight_columns(),
        sampling_freq=FLOWS_SAMPLING_FREQ,
    ),
    partial(select_columns, columns=AUTOENCODER_FLOWS_OUTPUT_FEATURES),
]
