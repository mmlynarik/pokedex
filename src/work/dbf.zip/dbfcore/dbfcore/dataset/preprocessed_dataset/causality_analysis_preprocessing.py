from functools import partial

import pandas as pd

from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_charge_weight,
    calculate_total_mineral_weight,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, drop_columns, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    get_delivery_heat_chem_columns,
    get_delivery_heat_columns,
    get_delivery_heat_mixers_columns,
)
from dbfcore.dataset.utils import (
    Value,
    ValueDict,
    get_float32_with_label,
    get_int32_with_label,
    get_timestamp_with_label,
)
from dbfcore.settings import NUMBER_OF_RAW_MATERIAL_COLUMNS

MINERALS = ["sio2"]
TARGET = "eligible_chem_si_wavg"
TARGET_KIND = "intensive"
DYNAMIC_PREDICTOR = TARGET + "_interp"
PREDICTORS = {
    "TV": Value(dtype="float32", id='{"label": "Teplota horúceho vetra", "unit": "°C", "type": "intensive"}'),
    "QV": Value(dtype="float32", id='{"label": "Množstvo studeného vetra", "type": "extensive"}'),
    "QPU": Value(
        dtype="float32",
        id='{"label": "Množstvo práškového uhlia (priemerné)", "unit": "kg/h", "type": "extensive"}',
    ),
    "TTH": Value(
        dtype="float32",
        id='{"label": "Teoretická teplota horenia", "unit": "°C", "type": "intensive"}',
    ),
    "coke_charge_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnost vsadzky koksu", "type": "extensive"}',
    ),
    "charge_weight": Value(dtype="float32", id='{"label": "Hmotnost vsadzky", "type": "extensive"}'),
    "sio2_weight": Value(dtype="float32", id='{"label": "Hmotnost sio2", "type": "extensive"}'),
}


def get_coke_charge_weight(df: pd.DataFrame) -> pd.DataFrame:
    def get_coke_charge_weight_for_one_row(row, coke_material_numbers: list[int] = [34, 37, 40]) -> float:
        weight = 0
        for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1):
            if row[f"raw_material_number_{i}"] in coke_material_numbers:
                weight += row[f"raw_material_weight_{i}"]
        return weight

    # Filter unused rows to improve performance of this transformation
    df_charge = df[~df["raw_material_number_1"].isna()][
        [
            f"raw_material_{item}_{i}"
            for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
            for item in ["weight", "number"]
        ]
    ]
    df_charge["coke_charge_weight"] = df_charge.apply(
        lambda row: get_coke_charge_weight_for_one_row(row), axis=1
    )
    return df.merge(df_charge["coke_charge_weight"], how="left", left_index=True, right_index=True)


# To improve performance of preprocessed dataset generation, we drop raw dataset columns we don't need
cauality_analysis_columns_to_drop = {
    **get_delivery_heat_columns(),
    **get_delivery_heat_mixers_columns(),
    **get_delivery_heat_chem_columns(),
}


# Selecting the columns to be in the preprocessed dataset
CAUSALITY_ANALYSIS_FEATURES: ValueDict = dict(
    {
        **PREDICTORS,
        "tapping_id": get_int32_with_label("ID odpichu"),
        TARGET: get_float32_with_label("Vážený priemer kremíka z eligible tavieb"),
        "date": get_timestamp_with_label("Dataset index"),
    }
)


CAUSALITY_ANALYSIS_KEY = "causality-analysis"
CAUSALITY_ANALYSIS_TRANSFORMATIONS: TransformationsCallables = [
    calculate_total_charge_weight,
    partial(calculate_mineral_weight_of_all_raw_materials, minerals=MINERALS),
    partial(calculate_total_mineral_weight, minerals=MINERALS),
    partial(drop_columns, columns=cauality_analysis_columns_to_drop),
    get_coke_charge_weight,
    partial(select_columns, columns=CAUSALITY_ANALYSIS_FEATURES.keys()),
]
