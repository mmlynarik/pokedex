from functools import partial
from pathlib import Path
from typing import Iterable

import pandas as pd
from datasets import Value

from dbfcore.dataset.preprocessed_dataset.transformations.pig_iron import calculate_pig_iron_fe_pct
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import get_pig_iron_chem_analysis_columns
from dbfcore.dataset.utils import ValueDict, get_timestamp_with_label
from dbfcore.settings import PIG_IRON_ELEMENTS, PREPROCESSED_DATASETS_PATH

PIG_IRON_CHEMS_PREPROCESSED_DATASET_PATHS = PREPROCESSED_DATASETS_PATH + "/pig-iron-chems"


def get_pig_iron_chems_preprocessed_dataset_path(furnace_id: int) -> Path:
    return Path(PIG_IRON_CHEMS_PREPROCESSED_DATASET_PATHS, f"vp{furnace_id}")


def get_columns_to_keep() -> list[str]:
    return ["tapping_start_date", "tapping_end_date"] + list(get_pig_iron_chem_analysis_columns(2))


def assign_tapping_durations(df: pd.DataFrame) -> pd.DataFrame:
    return df.assign(
        durations=lambda df: df["tapping_end_date"] - df["tapping_start_date"],
        durations_half=lambda df: (df["durations"] / 2).apply(lambda x: x.round("s")),
    )


# TODO: Needs refactoring
#! The first sample for the chem analysis is probably taken later than at the beginning of tapping (estim)
#! The second sample for the chem analysis is probably taken sometime before the end of tapping (estimation)
#! We need to find out how sampling of pig iron for chem analysis work.
def distribute_pig_iron_analyses(df: pd.DataFrame) -> pd.DataFrame:
    tapping_start_col = ["tapping_start_date"]

    cols1 = [col for col in df.columns if col.endswith("1")]
    pi_chems1 = (
        df.filter(tapping_start_col + cols1)
        .rename(
            columns={
                "tapping_start_date": "date",
                **{
                    f"pig_iron_{element}_pct_1": f"hotmetal{element}_chem_pct"
                    for element in PIG_IRON_ELEMENTS
                },
            }
        )
        .set_index("date")
    )

    cols2 = [col for col in df.columns if col.endswith("2")]
    pi_chems2 = (
        df.filter(tapping_start_col + ["durations_half"] + cols2)
        .assign(new_start=lambda df: df["tapping_start_date"] + df["durations_half"])
        .rename(
            columns={
                "new_start": "date",
                **{
                    f"pig_iron_{element}_pct_2": f"hotmetal{element}_chem_pct"
                    for element in PIG_IRON_ELEMENTS
                },
            }
        )
        .set_index("date")
        .drop(columns=["durations_half", "tapping_start_date"])
    )

    return pd.concat([pi_chems1, pi_chems2]).sort_index().reset_index()


def get_pig_iron_chems_columns(elements: Iterable[str]) -> ValueDict:
    return {
        f"hotmetal{element}_chem_pct": Value(
            dtype="float32",
            id=f'{{"label": "Podiel {element} v surovom železe", "unit": "5", "type": "extensive"}}',
        )
        for element in elements
    }


# Selecting the columns to be in the preprocessed dataset
PIG_IRON_CHEMS_FEATURES: ValueDict = {
    "date": get_timestamp_with_label("Dataset index"),
    **get_pig_iron_chems_columns(PIG_IRON_ELEMENTS),
}


PIG_IRON_CHEMS_KEY = "pig-iron-chems"
PIG_IRON_CHEMS_TRANSFORMATIONS: TransformationsCallables = [
    partial(select_columns, columns=get_columns_to_keep()),
    lambda df: df.query("tapping_end_date > tapping_start_date"),
    partial(calculate_pig_iron_fe_pct, analysis_num=1),
    partial(calculate_pig_iron_fe_pct, analysis_num=2),
    assign_tapping_durations,
    distribute_pig_iron_analyses,
    partial(select_columns, columns=PIG_IRON_CHEMS_FEATURES.keys()),
]
