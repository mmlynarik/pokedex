from dbfcore.dataset.preprocessed_dataset.charge_flows_freq_15_preprocessing import (
    CHARGE_FLOWS_15_PREPROCESSED_DATASET_PATH,
)
from dbfcore.dataset.preprocessed_dataset.mineral_flows_freq_900_preprocessing import (
    MINERAL_FLOWS_900_PREPROCESSED_DATASET_PATH,
)
from dbfcore.dataset.preprocessed_dataset.temperature_prediction_preprocessing import (
    TEMPERATURE_PREDICTION_PREPROCESSED_DATASET_PATH,
)
