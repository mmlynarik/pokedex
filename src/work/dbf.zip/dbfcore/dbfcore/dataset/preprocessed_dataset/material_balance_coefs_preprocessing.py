from functools import partial
from typing import Callable

import pandas as pd
from datasets import Value

from dbfcore.dataset.preprocessed_dataset.transformations.bf_gas import (
    calculate_bf_gas_weight,
    calculate_partial_pressure,
    calculate_qcvp_volume,
    convert_bf_gas_temperature_from_C_to_K,
)
from dbfcore.dataset.preprocessed_dataset.transformations.dust_removal import (
    calculate_carbon_weight_in_dust,
    calculate_dust_weight,
)
from dbfcore.dataset.preprocessed_dataset.utils import (
    calculate_element_mass_of_chemical_compound,
    convert_mass_units,
    select_columns,
    sum_columns,
)
from dbfcore.settings import (
    CARBON_RATIO_IN_DUST,
    DUST_WEIGHT_IN_KG_PER_TON_OF_PIG_IRON,
    SENSORS_DATA_TIME_PERIOD,
)

# Selecting the columns to be in the preprocessed dataset
MATERIAL_BALANCE_COEFS_FEATURES = {
    "date": Value(dtype="timestamp[ns, tz=UTC]", id={"label": "Dataset index"}),
    "qpu_al_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Al v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_as_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť As v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_ca_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ca v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_fe_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Fe v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_k_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť K v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_mg_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mg v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_mn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mn v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_na_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Na v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_p_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť P v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_pb_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Pb v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_si_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Si v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_ti_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ti v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "qpu_zn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Zn v práškovom uhlí", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_al_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Al v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_as_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť As v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_ca_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ca v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_fe_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Fe v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_k_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť K v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_mg_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mg v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_mn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mn v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_na_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Na v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_p_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť P v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_pb_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Pb v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_si_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Si v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_ti_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ti v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "raw_material_zn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Zn v surovinách", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_al_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Al v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_as_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť As v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_ca_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ca v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_fe_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Fe v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_k_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť K v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_mg_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mn v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_mn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mn v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_na_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Na v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_p_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť P v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_pb_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Pb v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_si_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Si v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_ti_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ti v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "pig_iron_zn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Zn v surovom železe", "unit": "t", "type": "extensive"}',
    ),
    "slag_al_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Al v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_as_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť As v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_ca_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ca v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_fe_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Fe v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_k_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť K v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_mg_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mg v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_mn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Mn v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_na_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Na v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_p_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť P v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_pb_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Pb v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_si_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Si v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_ti_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Ti v troske", "unit": "t", "type": "extensive"}',
    ),
    "slag_zn_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť Zn v troske", "unit": "t", "type": "extensive"}',
    ),
    "bf_gas_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C vo vysokopecnom plyne", "unit": "t", "type": "extensive"}',
    ),
    "dust_c_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnosť C v prachu vysokopecného plynu", "unit": "t", "type": "extensive"}',
    ),
}


MATERIAL_BALANCE_COEFS_KEY = "material-balance-coefficients"
MATERIAL_BALANCE_COEFS_TRANSFORMATIONS: list[Callable[..., pd.DataFrame]] = [
    ### Al calculations
    # QPU Al calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Al2O3",
        element="Al",
        input_col="qpu_al2o3_weight",
        output_col="qpu_al_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_al_weight_kg",
        output_col="qpu_al_weight",
    ),
    # Raw material Al calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Al2O3",
        element="Al",
        input_col="al2o3_weight",
        output_col="raw_material_al_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_al_weight_kg",
        output_col="raw_material_al_weight",
    ),
    # Pig iron Al calculations
    lambda df: df.assign(pig_iron_al_weight=0),
    # Slag Al calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Al2O3",
        element="Al",
        input_col="slag_al2o3_weight",
        output_col="slag_al_weight",
    ),
    ### As calculations
    # QPU As calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_ars_weight",
        output_col="qpu_as_weight",
    ),
    # Raw material As calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="ars_weight",
        output_col="raw_material_as_weight",
    ),
    # Slag As calculations
    lambda df: df.assign(slag_as_weight=0),
    ### C calculations
    # QPU C calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_c_weight",
        output_col="qpu_c_weight",
    ),
    # Raw material C calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="c_weight",
        output_col="raw_material_c_weight",
    ),
    # BF gas C calculations
    partial(calculate_qcvp_volume, time_period=SENSORS_DATA_TIME_PERIOD),
    partial(calculate_partial_pressure, chemical_compound="CO"),
    partial(calculate_partial_pressure, chemical_compound="CO2"),
    convert_bf_gas_temperature_from_C_to_K,
    partial(calculate_bf_gas_weight, chemical_compound="CO"),
    partial(calculate_bf_gas_weight, chemical_compound="CO2"),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="CO",
        element="C",
        input_col="bf_gas_CO_weight",
        output_col="bf_gas_c1_weight",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="CO2",
        element="C",
        input_col="bf_gas_CO2_weight",
        output_col="bf_gas_c2_weight",
    ),
    partial(
        sum_columns, columns=["bf_gas_c1_weight", "bf_gas_c2_weight"], output_column="bf_gas_c_weight_kg"
    ),
    partial(
        convert_mass_units, direction="kg -> t", input_col="bf_gas_c_weight_kg", output_col="bf_gas_c_weight"
    ),
    # Dust C calculations
    partial(calculate_dust_weight, dust_unit_of_measure=DUST_WEIGHT_IN_KG_PER_TON_OF_PIG_IRON),
    partial(calculate_carbon_weight_in_dust, carbon_ratio_in_dust=CARBON_RATIO_IN_DUST),
    partial(convert_mass_units, direction="kg -> t", input_col="dust_c_weight", output_col="dust_c_weight"),
    ### Ca calculations
    # QPU Ca calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="CaO",
        element="Ca",
        input_col="qpu_cao_weight",
        output_col="qpu_ca_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_ca_weight_kg",
        output_col="qpu_ca_weight",
    ),
    # Raw material Ca calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="CaO",
        element="Ca",
        input_col="cao_weight",
        output_col="raw_material_ca_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_ca_weight_kg",
        output_col="raw_material_ca_weight",
    ),
    # Pig iron Ca calculations
    lambda df: df.assign(pig_iron_ca_weight=0),
    # Slag Ca calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="CaO",
        element="Ca",
        input_col="slag_cao_weight",
        output_col="slag_ca_weight",
    ),
    ### Fe calculations
    # QPU Fe calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Fe2O3",
        element="Fe",
        input_col="qpu_fe2o3_weight",
        output_col="qpu_fe1_weight",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_fe1_weight",
        output_col="qpu_fe1_weight_t",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="FeO",
        element="Fe",
        input_col="qpu_feo_weight",
        output_col="qpu_fe2_weight",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_fe2_weight",
        output_col="qpu_fe2_weight_t",
    ),
    partial(
        sum_columns,
        columns=["qpu_fe1_weight_t", "qpu_fe2_weight_t"],
        output_column="qpu_fe_weight",
    ),
    # Raw material Fe calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Fe2O3",
        element="Fe",
        input_col="fe2o3_weight",
        output_col="raw_material_fe1_weight",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_fe1_weight",
        output_col="raw_material_fe1_weight_t",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="FeO",
        element="Fe",
        input_col="feo_weight",
        output_col="raw_material_fe2_weight",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_fe2_weight",
        output_col="raw_material_fe2_weight_t",
    ),
    partial(
        sum_columns,
        columns=["raw_material_fe1_weight_t", "raw_material_fe2_weight_t"],
        output_column="raw_material_fe_weight",
    ),
    ### K calculations
    # QPU K calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="K2O",
        element="K",
        input_col="qpu_k2o_weight",
        output_col="qpu_k_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_k_weight_kg",
        output_col="qpu_k_weight",
    ),
    # Raw material K calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="K2O",
        element="K",
        input_col="k2o_weight",
        output_col="raw_material_k_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_k_weight_kg",
        output_col="raw_material_k_weight",
    ),
    # Pig iron K calculations
    lambda df: df.assign(pig_iron_k_weight=0),
    # Slag K calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="K2O",
        element="K",
        input_col="slag_k2o_weight",
        output_col="slag_k_weight",
    ),
    # Mg calculations
    # QPU Mg calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="MgO",
        element="Mg",
        input_col="qpu_mgo_weight",
        output_col="qpu_mg_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_mg_weight_kg",
        output_col="qpu_mg_weight",
    ),
    # Raw material Mg calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="MgO",
        element="Mg",
        input_col="mgo_weight",
        output_col="raw_material_mg_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_mg_weight_kg",
        output_col="raw_material_mg_weight",
    ),
    # Pig iron Mg calculations
    lambda df: df.assign(pig_iron_mg_weight=0),
    # Slag Mg calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="MgO",
        element="Mg",
        input_col="slag_mgo_weight",
        output_col="slag_mg_weight",
    ),
    ### Mn calculations
    # QPU Mn calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_mn_weight",
        output_col="qpu_mn_weight",
    ),
    # Raw material Mn calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="mn_weight",
        output_col="raw_material_mn_weight",
    ),
    # Na calculations
    # QPU Na calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Na2O",
        element="Na",
        input_col="qpu_na2o_weight",
        output_col="qpu_na_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_na_weight_kg",
        output_col="qpu_na_weight",
    ),
    # Raw material Na calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Na2O",
        element="Na",
        input_col="na2o_weight",
        output_col="raw_material_na_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_na_weight_kg",
        output_col="raw_material_na_weight",
    ),
    # Pig iron Na calculations
    lambda df: df.assign(pig_iron_na_weight=0),
    # Slag Na calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Na2O",
        element="Na",
        input_col="slag_na2o_weight",
        output_col="slag_na_weight",
    ),
    ### Pb calculations
    # QPU Pb calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_pb_weight",
        output_col="qpu_pb_weight",
    ),
    # Raw material Pb calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="pb_weight",
        output_col="raw_material_pb_weight",
    ),
    # Slag Pb calculations
    lambda df: df.assign(slag_pb_weight=0),
    ### P calculations
    # QPU P calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_p_weight",
        output_col="qpu_p_weight",
    ),
    # Raw material P calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="p_weight",
        output_col="raw_material_p_weight",
    ),
    # Slag P calculations
    lambda df: df.assign(slag_p_weight=0),
    ### Si calculations
    # QPU Si calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="SiO2",
        element="Si",
        input_col="qpu_sio2_weight",
        output_col="qpu_si_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_si_weight_kg",
        output_col="qpu_si_weight",
    ),
    # Raw material Si calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="SiO2",
        element="Si",
        input_col="sio2_weight",
        output_col="raw_material_si_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_si_weight_kg",
        output_col="raw_material_si_weight",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="SiO2",
        element="Si",
        input_col="slag_sio2_weight",
        output_col="slag_si_weight",
    ),
    ### Ti calculations
    # QPU Ti calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_ti_weight",
        output_col="qpu_ti1_weight",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="TiO2",
        element="Ti",
        input_col="qpu_tio2_weight",
        output_col="qpu_ti2_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_ti2_weight_kg",
        output_col="qpu_ti2_weight",
    ),
    partial(
        sum_columns,
        columns=["qpu_ti1_weight", "qpu_ti2_weight"],
        output_column="qpu_ti_weight",
    ),
    # Raw material Ti calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="ti_weight",
        output_col="raw_material_ti1_weight",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="TiO2",
        element="Ti",
        input_col="tio2_weight",
        output_col="raw_material_ti2_weight_kg",
    ),
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="raw_material_ti2_weight_kg",
        output_col="raw_material_ti2_weight",
    ),
    partial(
        sum_columns,
        columns=["raw_material_ti1_weight", "raw_material_ti2_weight"],
        output_column="raw_material_ti_weight",
    ),
    # Slag Ti calculations
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="TiO2",
        element="Ti",
        input_col="slag_tio2_weight",
        output_col="slag_ti_weight",
    ),
    ### Zn calculations
    # QPU Zn calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="qpu_zn_weight",
        output_col="qpu_zn_weight",
    ),
    # Raw material Zn calculations
    partial(
        convert_mass_units,
        direction="kg -> t",
        input_col="zn_weight",
        output_col="raw_material_zn_weight",
    ),
    # Slag Zn calculations
    lambda df: df.assign(slag_zn_weight=0),
    # select columns for preprocessed dataset
    partial(select_columns, columns=MATERIAL_BALANCE_COEFS_FEATURES.keys()),
    # create 30-day rolling window with the sum of values inside the window + drop first 30 days
    lambda df: df.fillna(0),
    lambda df: df.rolling("30D").sum().loc[df.index[0] + pd.Timedelta("30D") :],
    lambda df: df.div(100000),
    lambda df: df.reset_index(),
]
