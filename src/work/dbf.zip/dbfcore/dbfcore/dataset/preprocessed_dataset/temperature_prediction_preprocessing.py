from functools import partial

import pandas as pd
from datasets import Value

from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_charge_weight,
    calculate_total_mineral_weight,
)
from dbfcore.dataset.preprocessed_dataset.utils import (
    TransformationsCallables,
    calculate_element_mass_of_chemical_compound,
    drop_columns,
    select_columns,
)
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    get_delivery_heat_chem_columns,
    get_delivery_heat_columns,
    get_delivery_heat_mixers_columns,
)
from dbfcore.dataset.utils import get_float32_with_label, get_int32_with_label, get_timestamp_with_label
from dbfcore.settings import NUMBER_OF_RAW_MATERIAL_COLUMNS, PREPROCESSED_DATASETS_PATH

TEMPERATURE_PREDICTION_KEY = "temperature-prediction"
TEMPERATURE_PREDICTION_PREPROCESSED_DATASET_PATH = (
    PREPROCESSED_DATASETS_PATH + "/" + TEMPERATURE_PREDICTION_KEY
)

TARGET = "tapping_temperature"
TARGET_KIND = "intensive"
MINERALS = ["feo", "fe2o3", "h2o", "cao", "mgo", "sio2", "al2o3"]

SENSORS_PREDICTORS = {
    "TV": Value(dtype="float32", id='{"label": "Teplota horúceho vetra", "unit": "°C", "type": "intensive"}'),
    "QV": Value(dtype="float32", id='{"label": "Množstvo studeného vetra", "type": "extensive"}'),
    "QPU": Value(
        dtype="float32",
        id='{"label": "Množstvo práškového uhlia (priemerné)", "unit": "kg/h", "type": "extensive"}',
    ),
    "TTH": Value(
        dtype="float32",
        id='{"label": "Teoretická teplota horenia", "unit": "°C", "type": "intensive"}',
    ),
}
CHARGE_PREDICTORS = {
    "h2o_weight": Value(dtype="float32", id='{"label": "Hmotnost h2o", "type": "extensive"}'),
    "coke_charge_weight": Value(
        dtype="float32",
        id='{"label": "Hmotnost vsadzky koksu", "type": "extensive"}',
    ),
    "charge_weight": Value(dtype="float32", id='{"label": "Hmotnost vsadzky", "type": "extensive"}'),
    # **{f"{mineral}_weight": "extensive" for mineral in MINERALS},  # hmotnosti mineralov
}
DERIVED_PREDICTORS = {
    "charge_basicity": Value(dtype="float32", id='{"label": "Bazicita vsadzky", "type": "intensive"}'),
    "charge_richness": Value(dtype="float32", id='{"label": "Bohatost vsadzky", "type": "intensive"}'),
}

OTHER_COLUMNS = {
    "date": get_timestamp_with_label("Dataset index"),
    "tapping_id": get_int32_with_label("Cislo a rok odpichu"),
    TARGET: get_float32_with_label("Teplota odpichu"),
}


PREDICTORS = SENSORS_PREDICTORS | DERIVED_PREDICTORS | CHARGE_PREDICTORS


def add_charge_basicity(df: pd.DataFrame) -> pd.DataFrame:
    """Add new column - zasaditost vsadzky"""
    df["charge_basicity"] = (df["cao_weight"] + df["mgo_weight"]) / (df["sio2_weight"] + df["al2o3_weight"])
    return df


def add_charge_richness(df: pd.DataFrame) -> pd.DataFrame:
    df["charge_richness"] = (df["fe_weight_in_fe2o3"] + df["fe_weight_in_feo"]) / df["charge_weight"]
    return df


def get_coke_charge_weight(df: pd.DataFrame) -> pd.DataFrame:
    def get_coke_charge_weight_for_one_row(row, coke_material_numbers: list[int] = [34, 37, 40]) -> float:
        weight = 0
        for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1):
            if row[f"raw_material_number_{i}"] in coke_material_numbers:
                weight += row[f"raw_material_weight_{i}"]
        return weight

    # Filter unused rows to improve performance of this transformation
    df_charge = df[~df["raw_material_number_1"].isna()][
        [
            f"raw_material_{item}_{i}"
            for i in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
            for item in ["weight", "number"]
        ]
    ]
    df_charge["coke_charge_weight"] = df_charge.apply(
        lambda row: get_coke_charge_weight_for_one_row(row), axis=1
    )
    return df.merge(df_charge["coke_charge_weight"], how="left", left_index=True, right_index=True)


# To improve performance of preprocessed dataset generation, we drop raw dataset columns we don't need
cauality_analysis_columns_to_drop = {
    **get_delivery_heat_columns(),
    **get_delivery_heat_mixers_columns(),
    **get_delivery_heat_chem_columns(),
}

TEMPERATURE_PREDICTION_FEATURES = PREDICTORS | OTHER_COLUMNS
TEMPERATURE_PREDICTION_TRANSFORMATIONS: TransformationsCallables = [
    calculate_total_charge_weight,
    partial(calculate_mineral_weight_of_all_raw_materials, minerals=MINERALS),
    partial(calculate_total_mineral_weight, minerals=MINERALS),
    partial(drop_columns, columns=cauality_analysis_columns_to_drop),
    get_coke_charge_weight,
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="FeO",
        element="Fe",
        input_col="feo_weight",
        output_col="fe_weight_in_feo",
    ),
    partial(
        calculate_element_mass_of_chemical_compound,
        chemical_compound="Fe2O3",
        element="Fe",
        input_col="fe2o3_weight",
        output_col="fe_weight_in_fe2o3",
    ),
    add_charge_basicity,
    add_charge_richness,
    partial(select_columns, columns=TEMPERATURE_PREDICTION_FEATURES),
]
