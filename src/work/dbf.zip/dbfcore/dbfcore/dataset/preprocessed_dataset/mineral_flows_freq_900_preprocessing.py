from functools import partial

from dbfcore.dataset.preprocessed_dataset.transformations.charge_flows import (
    get_charge_flows_time_series_for_multiple_columns,
    select_charges_only,
)
from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_mineral_weight,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, select_columns
from dbfcore.dataset.raw_dataset.raw_dataset_columns import ChainMap, Value, ValueDict
from dbfcore.dataset.utils import get_float32_with_label, get_timestamp_with_label
from dbfcore.settings import NUMBER_OF_RAW_MATERIAL_COLUMNS, PREPROCESSED_DATASETS_PATH, RAW_MATERIAL_MINERALS

SAMPLING_FREQ_SECS = 900
MINERAL_FLOWS_900_KEY = f"mineral-flows-{SAMPLING_FREQ_SECS}"
MINERAL_FLOWS_900_PREPROCESSED_DATASET_PATH = PREPROCESSED_DATASETS_PATH + "/" + MINERAL_FLOWS_900_KEY


def get_single_raw_material_info(idx: int) -> ValueDict:
    return {
        f"raw_material_weight_{idx}": Value(
            dtype="int32",
            id='{"label": "Hmotnosť suroviny", "unit": "kg", "type": "extensive"}',
        ),
        **{
            f"raw_material_{mineral}_pct_{idx}": Value(
                dtype="float32",
                id=f'{{"label": "Podiel {mineral} v surovine", "unit": "%", "type": "intensive"}}',
            )
            for mineral in RAW_MATERIAL_MINERALS
        },
    }


def get_raw_material_info(max_idx: int) -> ValueDict:
    return dict(ChainMap(*[get_single_raw_material_info(idx) for idx in range(max_idx, 0, -1)]))


def get_mineral_weight_columns(minerals: list[str] = RAW_MATERIAL_MINERALS) -> list[str]:
    return [f"{mineral}_weight" for mineral in minerals]


def get_mineral_flow_columns(minerals: list[str] = RAW_MATERIAL_MINERALS) -> list[str]:
    return [f"{mineral}_flow_kg_h" for mineral in minerals]


MINERAL_FLOWS_900_INPUT_FEATURES = {
    "charge_date": get_timestamp_with_label("Časová značka vsádzky"),
    **get_raw_material_info(NUMBER_OF_RAW_MATERIAL_COLUMNS),
}
MINERAL_FLOWS_900_OUTPUT_FEATURES = {
    "flow_start_time": get_timestamp_with_label("Zaciatok prietokoveho intervalu"),
    "flow_end_time": get_timestamp_with_label("Koniec prietokoveho intervalu"),
    "first_charge_start_time": get_timestamp_with_label("Časová značka zaciatku vsádzky"),
    "last_charge_end_time": get_timestamp_with_label("Časová značka konca vsádzky"),
    **{
        f"{mineral}_flow_kg_h": get_float32_with_label(f"Prietok mineralu {mineral} pocas vsadzky")
        for mineral in RAW_MATERIAL_MINERALS
    },
}
MINERAL_FLOWS_900_TRANSFORMATIONS: TransformationsCallables = [
    partial(select_columns, columns=MINERAL_FLOWS_900_INPUT_FEATURES),
    partial(select_charges_only),
    partial(calculate_mineral_weight_of_all_raw_materials, minerals=RAW_MATERIAL_MINERALS),
    partial(calculate_total_mineral_weight, minerals=RAW_MATERIAL_MINERALS),
    partial(
        get_charge_flows_time_series_for_multiple_columns,
        charge_end_col="charge_date",
        cols=get_mineral_weight_columns(),
        sampling_freq_secs=SAMPLING_FREQ_SECS,
    ),
    partial(select_columns, columns=MINERAL_FLOWS_900_OUTPUT_FEATURES),
]
