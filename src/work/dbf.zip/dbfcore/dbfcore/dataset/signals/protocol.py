from typing import Callable

import pandas as pd

"""
Input parameters are following:
start: pd.Timestamp
end: pd.Timestamp

Returning dataframe should follow these rules:

Index is unique sorted time index with times in UTC
Columns are one per signal with unprocessed values signal name is given by column name
Missing data are represented with nan
Column names must be stable and known before calling

Other parameter is bool cachability flag.
"""
SignalGroupDataFrame = pd.DataFrame
SignalGroupLoader = Callable[[pd.Timestamp, pd.Timestamp], pd.DataFrame]
