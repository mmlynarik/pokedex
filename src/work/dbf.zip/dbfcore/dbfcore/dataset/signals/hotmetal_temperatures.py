import logging
from functools import partial
from typing import Callable

import numpy as np
import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.signals.gap_phase import get_gap_phase_pi_point_names
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.model.datamodule.preprocessing import get_cleaned_pi_signal_data
from dbfcore.settings import (
    AVG_TAPPING_DURATION,
    MAX_VALID_TAPPING_TEMPERATURE,
    MIN_VALID_TAPPING_TEMPERATURE,
)

logger = logging.getLogger(__name__)


# Each tuple represents 3 correction factors: `a`, `b`, and `ref` entering the correction function `(a * np.log(t + 0.00000001)) + b`
# The whole correction mechanism is defined in this module at lines 263-289 (functions: fit_fn, get_correction, correct_temperatures)
# In order to generate these correction factors, use the procedure described in notebook: `./experimental/autoencoder/hotmetal_temp_correction.ipynb`
HOTMETAL_TEMP_CORRECTION_FACTORS = {
    "bf1_hotmetalcorrected_temp_C": (17.738116112946653, 1309.2947561241247, 9000.0),
    "bf2_hotmetalcorrected_temp_C": (11.150842380961873, 1349.0124404215596, 9000.0),
    "bf3_hotmetalcorrected_temp_C": (11.305858935905658, 1362.934320138269, 9000.0),
}


HOTMETAL_TEMP_PI_POINT_NAMES = [
    ["SK1.HotMetal.Temp.MeasDevice.C"],
    ["SK2.HotMetal.Temp.MeasDevice.C"],
    ["SK3.HotMetal.Temp.MeasDevice.C"],
]


def get_hotmetal_temp_pi_point_names(furnace_id: int) -> list[str]:
    return HOTMETAL_TEMP_PI_POINT_NAMES[furnace_id - 1]


def get_hotmetal_temp_signal_group_as_tuples(furnace_id: int) -> list[tuple[str, ...]]:
    signal_group = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_hotmetal_temp_pi_point_names(furnace_id)
    ]
    if not all(len(signal_tuple) == 3 for signal_tuple in signal_group):
        raise ValueError("Hotmetal temp signal group must have two signal names per each pi point name")
    return signal_group


def get_hotmetal_temp_signal_group(furnace_id: int) -> list[str]:
    tuples = get_hotmetal_temp_signal_group_as_tuples(furnace_id)
    return [x for t in tuples for x in t]


def process_temperature_raw_df(df: pd.DataFrame) -> pd.DataFrame:
    """Rename column name to `temperature`."""

    return df.set_axis(["temperature"], axis=1)


def merge_gap_phase_and_temperatures(
    tapping_times_processed: pd.DataFrame, temperatures_processed: pd.DataFrame
) -> pd.DataFrame:
    """Concat `tapping_times` and `temperatures`."""

    return pd.concat([tapping_times_processed, temperatures_processed]).sort_index()


def process_tappings_temperatures(tappings_temperatures: pd.DataFrame) -> pd.DataFrame:
    return (
        tappings_temperatures.assign(phase=lambda df: df.phase.ffill())
        .dropna(subset="temperature")
        .loc[
            lambda df: (df.temperature >= MIN_VALID_TAPPING_TEMPERATURE)
            & (df.temperature <= MAX_VALID_TAPPING_TEMPERATURE)
        ]
    )


def load_gap_phase(pi_client, start, end, furnace_id):
    start_updated = start - 2 * AVG_TAPPING_DURATION
    gap_phase_pi_point_name = get_gap_phase_pi_point_names(furnace_id)[0]
    gp_data = get_pi_data_as_dataframe(pi_client, gap_phase_pi_point_name, start_updated, end, "phase", False)
    return gp_data


def clean_hotmetal_temp_after_slag(df: pd.DataFrame, signal_name: str, **kwargs) -> pd.DataFrame:
    gap_phase = load_gap_phase(**kwargs)

    if gap_phase.empty or any(gap_phase.isnull().all()):
        return pd.DataFrame(columns=[signal_name])

    temperatures = process_temperature_raw_df(df)
    merged = merge_gap_phase_and_temperatures(gap_phase, temperatures)
    processed_df = process_tappings_temperatures(merged)

    df_cleaned = processed_df.dropna().sort_index()
    df_cleaned = df_cleaned[~df_cleaned.index.duplicated()].sort_index()
    df_cleaned = df_cleaned.rename(columns={"temperature": signal_name})
    df_cleaned = df_cleaned.loc[df_cleaned.phase == 1, [signal_name]]

    return get_cleaned_pi_signal_data(
        df_cleaned,
        recalibration_start_margin=pd.Timedelta("0.5m"),
        recalibration_duration=pd.Timedelta("0.5m"),
        extreme_grad_threshold=0.02,
    )


def fit_fn(t: float, a: float, b: float) -> float:
    return (a * np.log(t + 0.00000001)) + b


def get_correction(fitted_fn: Callable[[float], float], ref: float) -> Callable[[pd.Series], pd.Series]:
    def correct(x):
        mask = x < ref
        corrected = fitted_fn(ref) - fitted_fn(x)
        return mask * corrected

    return correct


def correct_temperatures(df: pd.DataFrame, correction_fn):
    df["correction"] = np.apply_along_axis(correction_fn, 0, df.td_from_start.dt.total_seconds().values)
    df["corrected"] = df.temperature + df.correction

    return df


# NOTE: Temporarily commented out
# TODO: Fix this function
def clean_hotmetal_temp_corrected(df: pd.DataFrame, signal_name: str, **kwargs):
    # a, b, ref = HOTMETAL_TEMP_CORRECTION_FACTORS[signal_name]

    # correction = get_correction(partial(fit_fn, a=a, b=b), ref)
    # corrected_data = correct_temperatures(df, correction)
    # corrected_data = corrected_data.rename(columns={"corrected": signal_name}).loc[:, [signal_name]]
    # corrected_data = corrected_data.dropna().sort_index()
    # corrected_data = corrected_data[~corrected_data.index.duplicated()].sort_index()

    # return get_cleaned_pi_signal_data(
    #     corrected_data,
    #     recalibration_start_margin=pd.Timedelta("0.5m"),
    #     recalibration_duration=pd.Timedelta("0.5m"),
    #     extreme_grad_threshold=0.02,
    # )
    return df.rename(columns={"temperature": signal_name}).reindex(columns=[signal_name])


def clean_hotmetal_temp(df: pd.DataFrame, signal_name: str, **kwargs):
    return df.rename(columns={"temperature": signal_name}).reindex(columns=[signal_name])


def get_temp_cleaning_fn(signal_name: str) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if "hotmetalafterslag_temp_C" in signal_name:
        return partial(clean_hotmetal_temp_after_slag, signal_name=signal_name)
    elif "hotmetalcorrected_temp_C" in signal_name:
        return partial(clean_hotmetal_temp_corrected, signal_name=signal_name)
    elif "hotmetal_temp_C" in signal_name:
        return partial(clean_hotmetal_temp, signal_name=signal_name)
    else:
        return lambda df: df


def load_hotmetal_temps(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    pi_client: PiClient,
    log_enabled: bool = False,
) -> pd.DataFrame:
    hotmetal_temp_pi_point_name = get_hotmetal_temp_pi_point_names(furnace_id)[0]

    temperature_raw = get_pi_data_as_dataframe(
        pi_client, hotmetal_temp_pi_point_name, start, end, "temperature", log_enabled
    )
    if temperature_raw.empty:
        return pd.DataFrame()

    signal_names = get_hotmetal_temp_signal_group_as_tuples(furnace_id)[0]

    hotmetal_temp_dfs = []
    for signal_name in signal_names:
        cleaning_function = get_temp_cleaning_fn(signal_name)
        cleaned = cleaning_function(  # type: ignore
            temperature_raw, pi_client=pi_client, start=start, end=end, furnace_id=furnace_id
        )
        hotmetal_temp_dfs.append(cleaned)

    return pd.concat(hotmetal_temp_dfs, axis=1)
