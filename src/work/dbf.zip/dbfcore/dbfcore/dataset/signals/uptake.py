import numpy as np
import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

UPTAKE_PI_POINT_NAMES = [
    ["SK1.Top.Uptake1.Temp.C", "SK1.Top.Uptake2.Temp.C", "SK1.Top.Uptake3.Temp.C", "SK1.Top.Uptake4.Temp.C"],
    ["SK2.Top.Uptake1.Temp.C", "SK2.Top.Uptake2.Temp.C", "SK2.Top.Uptake3.Temp.C", "SK2.Top.Uptake4.Temp.C"],
    ["SK3.Top.Uptake1.Temp.C", "SK3.Top.Uptake2.Temp.C", "SK3.Top.Uptake3.Temp.C", "SK3.Top.Uptake4.Temp.C"],
]


def get_uptake_pi_point_names(furnace_id: int) -> list[str]:
    return UPTAKE_PI_POINT_NAMES[furnace_id - 1]


def get_uptake_output_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_uptake_temp_C"]


def get_uptake_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_uptake_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_resample_signal(df: pd.DataFrame, signal_name: str, resample_rule: str = "30s") -> pd.DataFrame:
    df = df.resample(resample_rule, label="right", closed="right").mean()
    df = df.dropna(subset=[signal_name])
    return df


def get_median_from_four_signals(dfs: list[pd.DataFrame], median_column_name: str) -> pd.DataFrame:
    return (
        pd.concat(dfs, axis=1, join="outer")
        .replace(0, np.nan)
        .median(axis=1, skipna=True)
        .to_frame()
        .set_axis([median_column_name], axis="columns")
    )


def load_uptake_phase(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_names = get_uptake_pi_point_names(furnace_id)
    signal_names = get_uptake_signal_group(furnace_id)
    uptake_dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        if not df.empty:
            df = df[~df.index.duplicated()]
            df = get_resample_signal(df, signal_name)
            uptake_dfs.append(df)

    df = get_median_from_four_signals(uptake_dfs, f"bf{furnace_id}_uptake_temp_C")
    df = df.sort_index()

    return df
