import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.raw_dataset.steelshop_data_processor import (
    add_delivery_tappings_count_for_bridge_table,
    add_heat_chems_for_bridge_table,
    add_heat_mixers_count_for_bridge_table,
)
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.settings import AVG_TAPPING_DURATION, FURNACE_IDS


def get_tapping_periods_from_pi(
    start: pd.Timestamp, end: pd.Timestamp, datasources: DataSources
) -> pd.DataFrame:
    # To obtain also boundary tappings that started before start or ended after end
    start_updated = start - 5 * AVG_TAPPING_DURATION
    end_updated = end + 5 * AVG_TAPPING_DURATION

    res = pd.DataFrame()
    for furnace_id in FURNACE_IDS:
        pi_point_name_start = f"SK{furnace_id}.CastingStart"
        pi_point_name_end = f"SK{furnace_id}.EndOfCast"
        colname = "tapping_number"

        tapping_start = get_pi_data_as_dataframe(
            datasources.pi, pi_point_name_start, start_updated, end_updated, colname
        )
        tapping_end = get_pi_data_as_dataframe(
            datasources.pi, pi_point_name_end, start_updated, end_updated, colname
        )
        if tapping_start.empty or tapping_end.empty:
            continue

        tapping_end = tapping_end.reset_index(names=["tapping_end_date"]).assign(furnace_id=furnace_id)
        tapping_start = tapping_start.reset_index(names=["tapping_start_date"])
        tapping_periods = tapping_start.merge(tapping_end, on="tapping_number")
        res = pd.concat([res, tapping_periods])

    res = res[(res["tapping_start_date"].between(start, end)) | (res["tapping_end_date"].between(start, end))]
    res["tapping_id"] = res["tapping_number"] * 10000 + res["tapping_start_date"].dt.year
    res = (
        res[["tapping_start_date", "tapping_end_date", "tapping_number", "tapping_id", "furnace_id"]]
        .sort_values("tapping_start_date")
        .reset_index(drop=True)
        .astype({"tapping_id": int, "tapping_number": int, "furnace_id": int})
    )
    return res


def get_tappings_heats_bridge_table(start: pd.Timestamp, end: pd.Timestamp, ds: DataSources) -> pd.DataFrame:
    tappings = get_tapping_periods_from_pi(start, end, ds)
    if tappings.empty:
        raise ValueError(f"No tappings found in PI API for period {start} - {end}.")

    tapping_ids = tappings["tapping_id"].to_list()

    deliveries_1 = ds.scada.get_outgoing_deliveries_from_blast_furnace_by_tapping_id_1(tapping_ids)
    deliveries_2 = ds.scada.get_outgoing_deliveries_from_blast_furnace_by_tapping_id_2(tapping_ids)
    deliveries = pd.concat([deliveries_1, deliveries_2])
    deliveries = deliveries[deliveries["estimated_weight_from_tapping"] > 0]
    deliveries = localize_date_columns_and_convert_to_utc(deliveries, False)
    delivery_ids = deliveries["delivery_id"].unique().tolist()

    heats_1 = ds.scada.get_incoming_deliveries_for_steelshop_by_delivery_id_1(delivery_ids)
    heats_2 = ds.scada.get_incoming_deliveries_for_steelshop_by_delivery_id_2(delivery_ids)
    heats = pd.concat([heats_1, heats_2])
    heats = localize_date_columns_and_convert_to_utc(heats, False)
    bridge = deliveries.merge(heats, how="inner", on="delivery_id")
    bridge = bridge.merge(tappings, how="inner", on="tapping_id")

    return bridge


def get_steelshop_chems(start: pd.Timestamp, end: pd.Timestamp, ds: DataSources) -> pd.DataFrame:
    df = ds.oko.get_steelshop_chems_for_heats(start, end)
    # TEMPORARILY TURNED OFF UNTIL IDEMPOTENCE BUG IS RESOLVED
    # df.pipe(generate_ids, "heat_number", "first_temp_date", "heat_id", True)
    return df


def add_additional_columns_to_bridge_table(bridge: pd.DataFrame, chems: pd.DataFrame):
    bridge = add_heat_mixers_count_for_bridge_table(bridge)
    bridge = add_delivery_tappings_count_for_bridge_table(bridge)
    bridge = add_heat_chems_for_bridge_table(bridge, chems)
    return bridge


INDEX_COL = "tapping_start_date"
SIGNAL_NAMES = [
    "tapping_end_date",
    "tapping_id",
    "furnace_id",
    "delivery_id",
    "mixer_id",
    "heat_id",
    "weight_from_mixer",
    "pig_iron_weight",
    "heat_mixers",
    "mixer_fill_start_date",
    "mixer_fill_end_date",
    "mixer_offload_start_date",
    "mixer_offload_end_date",
    "estimated_weight_from_tapping",
    "delivery_tappings",
    "c_pct",
    "mn_pct",
    "p_pct",
    "s_pct",
    "si_pct",
    "ti_pct",
]
OUTPUT_COLUMNS = [INDEX_COL] + SIGNAL_NAMES


def get_tapping_delivery_heat_chem_signal_group() -> list[str]:
    return SIGNAL_NAMES


def load_tapping_delivery_heat_chem(
    start: pd.Timestamp, end: pd.Timestamp, datasources: DataSources
) -> pd.DataFrame:
    bridge = get_tappings_heats_bridge_table(start, end, datasources)
    chems = get_steelshop_chems(start, end, datasources)
    bridge = add_additional_columns_to_bridge_table(bridge, chems)
    return bridge[OUTPUT_COLUMNS].set_index(INDEX_COL)
