import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

PRESSURE_PI_POINT_NAMES = [
    [
        "SK1.Furnace.UpperDeltaP.Pres.kPa",
        "SK1.Furnace.LowerDeltaP.Pres.kPa",
        "SK1.Top.Pressure1.Pres.kPa",
        "SK1.Top.Pressure2.Pres.kPa",
    ],
    [
        "SK2.Furnace.UpperDeltaP1.Pres.kPa",
        "SK2.Furnace.UpperDeltaP2.Pres.kPa",
        "SK2.Furnace.LowerDeltaP1.Pres.kPa",
        "SK2.Furnace.LowerDeltaP2.Pres.kPa",
        "SK2.Top.Pressure.Pres.kPa",
    ],
    [
        "SK3.Furnace.UpperDeltaP1.Pres.kPa",
        "SK3.Furnace.UpperDeltaP2.Pres.kPa",
        "SK3.Furnace.LowerDeltaP1.Pres.kPa",
        "SK3.Furnace.LowerDeltaP2.Pres.kPa",
        "SK3.Top.Pressure.Pres.kPa",
    ],
]


def get_pressure_pi_point_names(furnace_id: int) -> list[str]:
    return PRESSURE_PI_POINT_NAMES[furnace_id - 1]


def get_pressure_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_pressure_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_pressure_output_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_{location}_pressure_kPa" for location in ["top", "mid", "bottom"]]


def get_null_values_for_pressure_signals(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, ds: DataSources, resample: bool = False
) -> pd.DataFrame:
    signal_names = get_pressure_signal_group(furnace_id)
    df = load_pressures(start, end, furnace_id, ds.pi)[0]
    if resample:
        df = df.resample("30s").mean()
    df["month"] = df.index.year * 100 + df.index.month
    return df.groupby("month").agg({col: lambda x: x.isnull().sum() for col in signal_names}), df


def calculate_output_signals(df: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    if furnace_id == 1:
        df["bf1_top_pressure_kPa"] = df[["bf1_top_pressure1_kPa", "bf1_top_pressure2_kPa"]].mean(axis=1)
        df["bf1_mid_pressure_kPa"] = df["bf1_top_pressure_kPa"] + df["bf1_upperdelta_pressure_kPa"]
        df["bf1_bottom_pressure_kPa"] = df["bf1_mid_pressure_kPa"] + df["bf1_lowerdelta_pressure_kPa"]

    if furnace_id in [2, 3]:
        df[f"bf{furnace_id}_mid_pressure_kPa"] = df[f"bf{furnace_id}_top_pressure_kPa"] + df[
            [f"bf{furnace_id}_upperdelta_p1_pressure_kPa", f"bf{furnace_id}_upperdelta_p2_pressure_kPa"]
        ].mean(axis=1)
        df[f"bf{furnace_id}_bottom_pressure_kPa"] = (
            df[f"bf{furnace_id}_mid_pressure_kPa"]
            + df[
                [f"bf{furnace_id}_lowerdelta_p1_pressure_kPa", f"bf{furnace_id}_lowerdelta_p2_pressure_kPa"]
            ].mean(axis=1)
        ).round(4)
    return df


def load_pressures(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_names = get_pressure_pi_point_names(furnace_id)
    signal_names = get_pressure_signal_group(furnace_id)

    dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        raw_df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        df = raw_df.dropna().sort_index()
        df = df[~df.index.duplicated()].sort_index()
        dfs.append(df)

    merged_df = pd.concat(dfs, axis=1)
    merged_df = merged_df.resample("30s").mean().interpolate(method="linear")
    merged_df = merged_df.dropna()

    output_signals = calculate_output_signals(merged_df, furnace_id)

    output_signal_names = get_pressure_output_signal_names(furnace_id)
    return output_signals[output_signal_names]
