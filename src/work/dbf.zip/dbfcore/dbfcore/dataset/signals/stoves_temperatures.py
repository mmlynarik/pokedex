from functools import partial
from typing import Callable

import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.signals.utils import get_regular_time_series_data
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.model.datamodule.preprocessing import get_cleaned_pi_signal_data

STOVES_TEMPERATURES_PI_POINT_NAMES = [
    [
        "SK1.Stove.11N.Dome.Temp.C",
        "SK1.Stove11.Stack.Temp.C",
        "SK1.Stove11.WasteGas.Temp.C",
        "SK1.Stove.12.Dome.Temp.C",
        "SK1.Stove12.Stack.Temp.C",
        "SK1.Stove12.WasteGas.Temp.C",
        "SK1.Stove.13.Dome.Temp.C",
        "SK1.Stove13.Stack.Temp.C",
        "SK1.Stove13.WasteGas.Temp.C",
        "SK1.Stove.14.Dome.Temp.C",
        "SK1.Stove14.Stack.Temp.C",
        "SK1.Stove14.WasteGas.Temp.C",
    ],
]


def get_stoves_temperatures_pi_point_names(furnace_id: int) -> list[str]:
    return STOVES_TEMPERATURES_PI_POINT_NAMES[furnace_id - 1]


def get_stoves_temperatures_output_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_stove_temp_C"]


def get_stoves_temperatures_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal]
        for signal in get_stoves_temperatures_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_cleaning_fn_by_pi_point_name(pi_point_name: str) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if pi_point_name == "SK1.Stove11.Stack.Temp.C":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=30,
        )
    elif pi_point_name == "SK1.Stove.12.Dome.Temp.C":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("30s"),
            recalibration_duration=pd.Timedelta("30s"),
            extreme_grad_threshold=5,
        )
    elif pi_point_name == "SK1.Stove13.Stack.Temp.C":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("2.5m"),
            recalibration_duration=pd.Timedelta("2.5m"),
            extreme_grad_threshold=20,
        )
    elif pi_point_name == "SK1.Stove.14.Dome.Temp.C":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=20,
        )
    elif pi_point_name == "SK1.Stove14.Stack.Temp.C":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("30s"),
            recalibration_duration=pd.Timedelta("30s"),
            extreme_grad_threshold=20,
        )
    else:
        return lambda x: x


def load_stoves_temperatures(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_names = get_stoves_temperatures_pi_point_names(furnace_id)
    signal_names = get_stoves_temperatures_signal_group(furnace_id)
    dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        if not df.empty:
            df = df[~df.index.duplicated()]
            df = df[(df[signal_name] > 0)]
            cleaning_fn = get_cleaning_fn_by_pi_point_name(pi_point_name)
            df = cleaning_fn(df)
            df = get_regular_time_series_data(df)
            df = df.resample("1min", label="right", closed="right").mean()
        dfs.append(df)

    return pd.concat(dfs, axis=1)
