import cantera as ct
import numpy as np
import pandas as pd


class InvalidSignalName(Exception):
    def __init__(self, signal_name: str, allowed_signals: list[str]):
        message = f"Signal {signal_name} is not among the supported signals. Please select signal name from the following list: {allowed_signals}."

        super().__init__(message)


def get_signal_names_with_furnace_id(furnace_id: int, signal_names: list[str]) -> list[str]:
    return [f"bf{furnace_id}_{col}" for col in signal_names]


def correct_defective_years_for_id_generation(df: pd.DataFrame, semi_id_col: str) -> pd.DataFrame:
    """
    Corrects defective years.
    Defective years are assigned probably due to discrepancy between calendar and metallurgical datetimes.

    Logic:
    1. First 15 (a potential safe treshold where "old" and "current" occurencies could appear) occurencies
    are selected and the difference of semi-id column between adjacent rows is calculated
    2. Index with difference larger than 100 (potential safe treshold between the "old" and "current"
    semi-ids) is identified
    3. The year value in all tappings that follow this index is corrected to previous year value
    """

    EXPECTED_DEFECTIVE_TAPPING_ID_ROWS = 15
    LOWEST_DIFF_BETWEEN_FIRST_AND_LAST_TAPPING_NUMBER_PER_YEAR = 100
    YEAR_DROP = 1

    for year in df.year.unique():
        d = (
            df[df.year == year]
            .iloc[:EXPECTED_DEFECTIVE_TAPPING_ID_ROWS]
            .sort_values(semi_id_col)
            .assign(dif=lambda df: df[semi_id_col].diff().abs())
        )
        idx = d[d.dif > LOWEST_DIFF_BETWEEN_FIRST_AND_LAST_TAPPING_NUMBER_PER_YEAR].index

        if not idx.empty:
            idx = idx.item()
            ids = d.loc[idx:].index
            df.loc[ids, "year"] = year - YEAR_DROP

    return df


def generate_ids(
    df: pd.DataFrame,
    semi_id_col: str,
    timestamp_col: str,
    output_id_col: str = "id",
    correct_years: bool = False,
) -> pd.DataFrame:
    """
    Generate ids as a combination of a semi-ID number and the relevant year in which the semi-ID occurs.
    Semi-ID must be an integer (e.g. 30003).

    NOTE!:
    There might be occurencies that, based on their semi-ID, leak from previous years to
    another year (probably due to discrepancy between calendar and metallurgical datetimes).
    Year of these occurencies will be corrected if `correct_years` parameter is set to `True`.
    """

    df["year"] = df[timestamp_col].dt.year

    if correct_years:
        corrected_dfs = []
        for year in df["year"].unique():
            df_year = df[df["year"] == year].sort_values(timestamp_col)
            corrected_dfs.append(correct_defective_years_for_id_generation(df_year, semi_id_col))

        df = pd.concat(corrected_dfs)

    df[output_id_col] = df[semi_id_col] * 10000 + df["year"]

    return df.drop(columns="year")


def reverse_list(ls: list) -> list:
    ls.reverse()
    return ls


def calculate_charge_layers_attribute(
    input_data: pd.DataFrame, attribute: str, signal_names: list[str], num_layers: int
) -> pd.DataFrame:
    input_data = input_data.copy()
    if attribute not in input_data:
        raise ValueError(f"Input data dataframe must contain {attribute} column")
    if "charge_date" not in input_data:
        raise ValueError("Input data dataframe must contain charge_date column")
    input_data["layer"] = [reverse_list(item.to_list()) for item in input_data[attribute].rolling(num_layers)]
    return pd.DataFrame(input_data["layer"].to_list(), index=input_data["charge_date"], columns=signal_names)


def get_conditional_interpolate_series(
    s: pd.Series,
    interpolate_method: str = "linear",
    threshold: pd.Timedelta = pd.Timedelta("60min"),
) -> pd.Series:
    """
    Interpolates NaN values in the series 's' (with a regular time index)
    using the specified interpolation method (interpolate_method), but only
    if the gap (a series of consecutive NaNs) is shorter than the specified
    time threshold (threshold). If the gap (a series of consecutive NaNs)
    is longer than the specified time threshold (threshold), the interpolated
    value in this region remains NaN.
    Note: The series must have a regular time index !!!

    Parameters
    ----------
        s : input Pandas Series with a regular time index.
        interpolate_method : the interpolation method. Default is 'linear'.
        threshold : pd.Timedelta, the maximum allowed time interval of a gap that
                    will be interpolated. Default is 'pd.Timedelta("60min")'.
    Returns
    -------
        A new series where short gaps are interpolated and long gaps (greater
        than threshold) are left as NaN.
    """
    s_filled = s.interpolate(interpolate_method)
    missing = s.isna()
    groups = (missing != missing.shift()).cumsum()
    freq = pd.infer_freq(s.index)
    if freq is None:
        if s.index.freq is not None:
            freq = s.index.freq
        else:
            raise ValueError("It is not possible to determine the frequency of the index.")

    def convert_freq_to_timedelta(freq: str) -> pd.Timedelta:
        freq_map = {
            "min": "1min",
            "T": "1min",
            "s": "1s",
            "S": "1s",
            "h": "1h",
            "H": "1h",
            "D": "1D",
        }
        if freq in freq_map:
            return pd.Timedelta(freq_map[freq])
        return pd.Timedelta(freq)

    freq_td = convert_freq_to_timedelta(freq)
    max_gap_steps = int(threshold / freq_td)
    for group, mask in missing.groupby(groups):
        if mask.iloc[0] and mask.sum() > max_gap_steps:
            s_filled.loc[mask.index] = np.nan
    return s_filled


def get_conditional_interpolate_df(
    df: pd.DataFrame,
    interpolate_method: str = "linear",
    threshold: pd.Timedelta = pd.Timedelta("60min"),
) -> pd.DataFrame:
    """
    Interpolates NaN values in all numeric columns of a DataFrame containing
    time-series data (with a regular time index) using the specified interpolation
    method (interpolate_method), but only if the gap (a series of consecutive NaNs)
    is shorter than the specified time threshold (threshold). If the gap (a series
    of consecutive NaNs) is longer than the specified time threshold (threshold),
    the interpolated value in this region remains NaN.

    The function iterates through each numeric column of the DataFrame and
    applies 'get_conditional_interpolate_series' function. The input and output
    are the complete DataFrame.
    Note: The input DataFrame must have a regular time index (e.g., after resampling) !!!

    Parameters
    ----------
        df : Input DataFrame with a regular time index.
        interpolate_method : The interpolation method. Default is 'linear'.
        threshold : pd.Timedelta, the maximum allowed time interval of a gap that
                    will be interpolated. Default is 'pd.Timedelta("60min")'.
    Returns
    -------
        A DataFrame where, for each numeric column, only gaps shorter than the threshold are interpolated.
        A new series where short gaps are interpolated and long gaps (greater
        than threshold) are left as NaN.
    """
    df_filled = df.copy()
    for col in df_filled.columns:
        if pd.api.types.is_numeric_dtype(df_filled[col]):
            df_filled[col] = get_conditional_interpolate_series(df_filled[col], interpolate_method, threshold)
    return df_filled


def get_regular_time_series_data(
    df: pd.DataFrame,
    freq: str = "s",
    resample_rule: str = "1s",
    interpolate_method: str = "linear",
    threshold: pd.Timedelta = pd.Timedelta("60min"),
) -> pd.DataFrame:
    """
    Resample irregular time-series data to a target frequency to obtain
    regular time series data using interpolation to fill in missing values.

    All duplicate indexes that arise when flooring the index of input
    DataFrame are deleted within the function.

    The function only interpolates the NaN values that occur if the gap (a series
    of consecutive NaNs) is shorter than the specified time threshold (threshold).
    If the gap (a series of consecutive NaNs) is longer than the specified time
    threshold (threshold), the interpolated value in this region remains NaN.

    Parameters
    ----------
        df : Input DataFrame with irregular time-series data.
        freq : The frequency level to floor the index to. Must be a fixed frequency like 's' (second). Default 's'.
        resample_rule : String representing target resample conversion. Default '1s'.
        interpolate_method : Interpolation technique to use. Default 'linear'.
        threshold : pd.Timedelta, the maximum allowed time interval of a gap that
                    will be interpolated. Default is 'pd.Timedelta("60min")'.
    Returns
    -------
        Pandas DataFrame with regular time-series data.
    """
    df.index = df.index.floor(freq=freq)
    df = df[~df.index.duplicated()].resample(rule=resample_rule).asfreq()
    df = get_conditional_interpolate_df(df, interpolate_method, threshold)

    return df


def get_molar_pct_from_mass_pct(
    components: list[str], mass_pct: list[float], gas: ct.Solution = ct.Solution("gri30.yaml")
) -> list[float]:
    """
    Calculates molar percentage from mass percentage for specified gas with defined components.

    Example:
        >>> get_molar_pct_from_mass_pct(["O2", "N2", "H2O"], [21.0, 79.0, 3.0])
        # [0.223677615671274, 0.7637292464878671, 0.012593137840858807]
        # the molar pct is defined for ["O2", "N2", "H2O"] in exactly
        # the same order as defined in the argument

    Args:
        components (list[str]): List of gas components, e.g. ["O2", "N2", "H2O"]
        mass_pct (list[float]): List of mass pct of each component, e.g. [20.0, 78.0, 2.0]

    Returns:
        list[float]: List of molar pct for each component defined in the argument.
    """

    if abs(sum(mass_pct) - 100.0) > 0.000001:
        raise ValueError("Sum of `mass_pct` must equal 100.0")

    gas[components].X = mass_pct

    return gas[components].Y.tolist()
