from functools import partial
from typing import Callable

import numpy as np
import pandas as pd

from dbfcore.dataset.burden_drop_preprocessing import count_gradient, preprocess_burden_drop_data
from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

STOCKROD_PI_POINT_NAMES = [
    ["SK1.Top.StockRod1.Distance.m", "SK1.Top.StockRod2.Distance.m"],
    [
        "SK2.Top.StockRod1.Distance.m",
        "SK2.Top.StockRod2.Distance.m",
        "SK2.Top.StockRod3.Distance.m",
    ],
    [
        "SK3.Top.StockRod1.Distance.m",
        "SK3.Top.StockRod2.Distance.m",
    ],
]


def get_stockrod_pi_point_names(furnace_id: int) -> list[str]:
    return STOCKROD_PI_POINT_NAMES[furnace_id - 1]


def get_stockrod_signal_group_as_tuples(furnace_id: int) -> list[tuple[str, ...]]:
    signal_group = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_stockrod_pi_point_names(furnace_id)
    ]
    if not all(len(signal_tuple) == 2 for signal_tuple in signal_group):
        raise ValueError("Stockrod signal group must have two signal names per each pi point name")
    return signal_group


def get_stockrod_signal_group(furnace_id: int) -> list[str]:
    tuples = get_stockrod_signal_group_as_tuples(furnace_id)
    return [x for t in tuples for x in t]


def load_stockrod(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    stockrod_pi_point_names = get_stockrod_pi_point_names(furnace_id)
    cleaning_fn = get_cleaning_fn_by_furnace_id(furnace_id)

    stockrod_burden_drop_dfs = []
    for idx, pi_point_name in enumerate(stockrod_pi_point_names):
        signal_name, burden_drop_name = get_stockrod_signal_group_as_tuples(furnace_id)[idx]

        raw_df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        if raw_df.empty:
            return pd.DataFrame()

        cleaned_data = cleaning_fn(raw_df)

        # Apply resampling only if furnace_id == 1, due to high level of data granularity
        if furnace_id == 1:
            preprocessed_data = cleaned_data.resample("30s").mean()
        else:
            preprocessed_data = cleaned_data
        raw_gradient = count_gradient(preprocessed_data, signal_name)
        cleaned_gradient = preprocess_burden_drop_data(raw_gradient)
        cleaned_gradient = cleaned_gradient.rename(columns={"gradient": burden_drop_name})
        stockrod_burden_drop_dfs.append(pd.concat([cleaned_data, cleaned_gradient], axis=1))

    return pd.concat(stockrod_burden_drop_dfs, axis=1).sort_index()


def get_cleaning_fn_by_furnace_id(furnace_id: int) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if furnace_id == 1:
        return get_cleaned_stockrod_data_bf1
    elif furnace_id == 2:
        return get_cleaned_stockrod_data_bf2
    elif furnace_id == 3:
        return get_cleaned_stockrod_data_bf3
    raise Exception(f"Invalid furnace_id: {furnace_id}")


def get_invalid_stockrod_times(stockrod_data, column_name):
    sdata = stockrod_data[[column_name]].copy()
    # Remove consecutive nans
    sdata = sdata[sdata[column_name].shift(-1).notna() | sdata[column_name].notna()]
    sdata["nanidx"] = sdata.isna().cumsum()
    sdata["nanstart"] = sdata["nanidx"].shift(-1, fill_value=sdata[column_name].isna().sum())
    sdata["nanend"] = sdata["nanidx"].shift(2, fill_value=0)
    sdata["toremove"] = sdata["nanstart"] > sdata["nanend"]
    return sdata["toremove"]


def get_cleaned_stockrod_data(
    stockrod_data: pd.DataFrame,
    negative_grad_weight: float,
    large_positive_grad_weight: float,
    large_positive_grad_threshold: float,
    rolling_interval: str,
    invalid_data_score_threshold: float,
    outlier_threshold: float,
) -> pd.DataFrame:
    column_name = stockrod_data.columns[0]

    stockrod_data_modified = stockrod_data[[column_name]].copy()
    stockrod_data_modified.fillna(0.0, inplace=True)
    one_second_resampling = stockrod_data_modified.resample("1s", label="right").mean().interpolate("linear")
    one_second_resampling["grad"] = np.gradient(one_second_resampling[column_name])
    one_second_resampling["cleaned"] = one_second_resampling[column_name]
    one_second_resampling["removescore"] = 0

    one_second_resampling["removescore"] += (
        (one_second_resampling["grad"] < 0.0) * (-one_second_resampling["grad"]) * negative_grad_weight
    )
    one_second_resampling["removescore"] += (
        (one_second_resampling["grad"] > large_positive_grad_threshold)
        * (one_second_resampling["grad"])
        * large_positive_grad_weight
    )
    one_second_resampling["removescore_rolling"] = one_second_resampling.rolling(rolling_interval)[
        "removescore"
    ].mean()

    one_second_resampling.loc[
        one_second_resampling["removescore_rolling"] > invalid_data_score_threshold, ["cleaned"]
    ] = np.nan

    invalid_stockrod_times = get_invalid_stockrod_times(stockrod_data, column_name)
    invalid_times_one_sec = invalid_stockrod_times.resample("1s", label="right").max().ffill()

    one_second_resampling.loc[invalid_times_one_sec[invalid_times_one_sec == 1.0].index, ["cleaned"]] = np.nan

    cloned = stockrod_data.copy()
    cloned["roundedtimestamp"] = cloned.index.to_series().dt.round("1s")

    merged = pd.merge(
        cloned, one_second_resampling[["cleaned"]], left_on="roundedtimestamp", right_index=True
    )
    merged_subset = merged[~merged["cleaned"].isna()][[column_name]]

    return merged_subset[
        (merged_subset[column_name] > outlier_threshold) & ~merged_subset.index.duplicated(keep="first")
    ]


get_cleaned_stockrod_data_bf1 = partial(
    get_cleaned_stockrod_data,
    negative_grad_weight=4.0,
    large_positive_grad_weight=1.0,
    large_positive_grad_threshold=0.5,
    rolling_interval="5s",
    invalid_data_score_threshold=2.5,
    outlier_threshold=50.0,
)

get_cleaned_stockrod_data_bf2 = partial(
    get_cleaned_stockrod_data,
    negative_grad_weight=4.0,
    large_positive_grad_weight=2.0,
    large_positive_grad_threshold=0.5,
    rolling_interval="5s",
    invalid_data_score_threshold=2.5,
    outlier_threshold=50.0,
)

get_cleaned_stockrod_data_bf3 = partial(
    get_cleaned_stockrod_data,
    negative_grad_weight=4.0,
    large_positive_grad_weight=1.0,
    large_positive_grad_threshold=0.5,
    rolling_interval="5s",
    invalid_data_score_threshold=2.0,
    outlier_threshold=50.0,
)
