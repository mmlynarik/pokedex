from datetime import datetime

import pandas as pd

from dbfcore.dataset.hooks import DataSources, VPHook
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.dataset.signals.charge_flows import (
    load_raw_material_charge_data_from_data_sources,
    validate_start_end_datetimes,
)
from dbfcore.dataset.signals.utils import calculate_charge_layers_attribute, get_signal_names_with_furnace_id


def prepare_relevant_charge_date_data(
    start: datetime, end: datetime, furnace_id: int, vp_hook: VPHook
) -> pd.DataFrame:
    raw_material_charge = load_raw_material_charge_data_from_data_sources(start, end, furnace_id, vp_hook)
    if raw_material_charge.empty:
        return pd.DataFrame()
    raw_material_charge = localize_date_columns_and_convert_to_utc(raw_material_charge)
    raw_material_charge = raw_material_charge.groupby("charge_date", as_index=False).agg(
        {"raw_material_weight": "sum"}
    )

    return raw_material_charge


def get_charge_layers_input_data(
    raw_material_charge: pd.DataFrame, height_m_per_weight_kg_coef: float = 0.000016
) -> pd.DataFrame:
    # height_m_per_weight_kg_coef - the coefficient was calculated as the ratio of height in meters to
    # weight in kilograms, that is height (m) / weight (kg) - based on stockrod data (heights) and
    # raw_material_weight data (weights) without distinguishing what type of charge it is

    raw_material_charge["layer_height"] = (
        raw_material_charge["raw_material_weight"] * height_m_per_weight_kg_coef
    )
    return raw_material_charge


# TODO: adjust the value of the parameter "n_layers" with respect to the specific zone in the furnace
def get_charge_layer_height_signal_names(num_layers: int) -> list[str]:
    return [f"charge_layer{i+1}_height_m" for i in range(num_layers)]


def get_charge_layers_height_signal_group(furnace_id: int, num_layers: int) -> list[str]:
    charge_layers_signal_names = get_charge_layer_height_signal_names(num_layers)
    return get_signal_names_with_furnace_id(furnace_id, charge_layers_signal_names)


def load_charge_layers_height(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources, num_layers: int
) -> pd.DataFrame:
    # charge flows data
    vp_hook = datasources.get_vp_hook(calc_time=end, now=pd.Timestamp.utcnow())
    start, end = start.to_pydatetime(), end.to_pydatetime()
    validate_start_end_datetimes(start, end)
    raw_material_charge = prepare_relevant_charge_date_data(start, end, furnace_id, vp_hook)

    # charge layers data
    layers_input_data = get_charge_layers_input_data(raw_material_charge)
    signal_names = get_charge_layers_height_signal_group(furnace_id, num_layers)
    charge_layers_height = calculate_charge_layers_attribute(
        layers_input_data, "layer_height", signal_names, num_layers
    )
    return charge_layers_height
