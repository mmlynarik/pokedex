from functools import partial
from typing import Callable

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals.above_burden_probe import (
    get_above_burden_probe_signal_names,
    load_above_burden_probe_phase,
)
from dbfcore.dataset.signals.charge_flows import get_charge_flows_signal_group, load_charge_flows
from dbfcore.dataset.signals.charge_layer_chem import (
    get_charge_layers_chems_signal_group,
    load_charge_layers_chems,
)
from dbfcore.dataset.signals.charge_layer_height import (
    get_charge_layers_height_signal_group,
    load_charge_layers_height,
)
from dbfcore.dataset.signals.charge_layer_id import get_charge_layers_id_signal_group, load_charge_layers_id
from dbfcore.dataset.signals.gap_phase import get_gap_phase_signal_group, load_gap_phase
from dbfcore.dataset.signals.hotblast import get_hotblast_signal_group, load_hotblast
from dbfcore.dataset.signals.hotmetal_chems import get_tappings_signal_group, load_hotmetal_chems
from dbfcore.dataset.signals.hotmetal_chems_pi import (
    get_hotmetal_chems_pi_signal_group,
    load_hotmetal_chems_pi,
)
from dbfcore.dataset.signals.hotmetal_temperatures import get_hotmetal_temp_signal_group, load_hotmetal_temps
from dbfcore.dataset.signals.pressure import get_pressure_output_signal_names, load_pressures
from dbfcore.dataset.signals.protocol import SignalGroupLoader
from dbfcore.dataset.signals.pulverized_coal import load_pulverized_coal
from dbfcore.dataset.signals.stockrod import get_stockrod_signal_group, load_stockrod
from dbfcore.dataset.signals.stove_input_gases import (
    get_stoves_input_gases_signal_group,
    load_stoves_input_gases,
)
from dbfcore.dataset.signals.stoves_temperatures import (
    get_stoves_temperatures_output_signal_names,
    load_stoves_temperatures,
)
from dbfcore.dataset.signals.tapping_delivery_heat_chem import (
    get_tapping_delivery_heat_chem_signal_group,
    load_tapping_delivery_heat_chem,
)
from dbfcore.dataset.signals.topgas import get_topgas_signal_group, load_topgas
from dbfcore.dataset.signals.uptake import get_uptake_output_signal_names, load_uptake_phase
from dbfcore.settings import FURNACE_IDS, NUM_CHARGE_LAYERS, RAW_MATERIAL_MINERALS

SIGNAL_GROUP_TO_SIGNAL_MAIN_GROUP_MAP = {
    **{f"bf{bf}_gap_phase": "GAPPHASE" for bf in FURNACE_IDS},
    **{f"bf{bf}_chargeflow": "CHARGEFLOW" for bf in FURNACE_IDS},
    **{f"bf{bf}_hotblast": "HOTBLAST" for bf in FURNACE_IDS},
    **{f"bf{bf}_topgas": "TOPGAS" for bf in FURNACE_IDS},
    **{f"bf{bf}_hotmetal_temp": "HOTMETALTEMP" for bf in FURNACE_IDS},
    **{f"bf{bf}_hotmetal_chem": "HOTMETALCHEM" for bf in FURNACE_IDS},
    **{f"bf{bf}_hotmetal_chem_pi": "HOTMETALCHEMPI" for bf in FURNACE_IDS},
    **{f"bf{bf}_stockrod": "STOCKROD" for bf in FURNACE_IDS},
    **{f"bf{bf}_chargelayers_height": "CHARGELAYERSHEIGHT" for bf in FURNACE_IDS},
    **{f"bf{bf}_chargelayers_id": "CHARGELAYERSID" for bf in FURNACE_IDS},
    **{f"bf{bf}_chargelayers_chems": "CHARGELAYERSCHEMS" for bf in FURNACE_IDS},
    **{"tapping_delivery_heat_chem": "TAPPINGDELIVERYHEATCHEM"},
    **{f"bf{bf}_above_burden_probe": "ABOVEBURDENPROBE" for bf in FURNACE_IDS},
    **{f"bf{bf}_pressure": "PRESSURE" for bf in FURNACE_IDS},
    **{f"bf{bf}_uptake": "UPTAKE" for bf in FURNACE_IDS},
    **{f"bf{bf}_stoves_temperatures": "STOVESTEMPERATURES" for bf in FURNACE_IDS},
    **{f"bf{bf}_stoves_input_gases": "STOVESINPUTGASES" for bf in FURNACE_IDS},
}


SIGNAL_TO_SIGNAL_GROUP_MAP = {
    **{signal_name: "bf1_gap_phase" for signal_name in get_gap_phase_signal_group(1)},
    **{signal_name: "bf2_gap_phase" for signal_name in get_gap_phase_signal_group(2)},
    **{signal_name: "bf3_gap_phase" for signal_name in get_gap_phase_signal_group(3)},
    **{signal_name: "bf1_chargeflow" for signal_name in get_charge_flows_signal_group(1)},
    **{signal_name: "bf2_chargeflow" for signal_name in get_charge_flows_signal_group(2)},
    **{signal_name: "bf3_chargeflow" for signal_name in get_charge_flows_signal_group(3)},
    **{signal_name: "bf1_hotblast" for signal_name in get_hotblast_signal_group(1)},
    **{signal_name: "bf2_hotblast" for signal_name in get_hotblast_signal_group(2)},
    **{signal_name: "bf3_hotblast" for signal_name in get_hotblast_signal_group(3)},
    **{signal_name: "bf1_hotmetal_temp" for signal_name in get_hotmetal_temp_signal_group(1)},
    **{signal_name: "bf2_hotmetal_temp" for signal_name in get_hotmetal_temp_signal_group(2)},
    **{signal_name: "bf3_hotmetal_temp" for signal_name in get_hotmetal_temp_signal_group(3)},
    **{signal_name: "bf1_stockrod" for signal_name in get_stockrod_signal_group(1)},
    **{signal_name: "bf2_stockrod" for signal_name in get_stockrod_signal_group(2)},
    **{signal_name: "bf3_stockrod" for signal_name in get_stockrod_signal_group(3)},
    **{signal_name: "bf1_hotmetal_chem" for signal_name in get_tappings_signal_group(1)},
    **{signal_name: "bf2_hotmetal_chem" for signal_name in get_tappings_signal_group(2)},
    **{signal_name: "bf3_hotmetal_chem" for signal_name in get_tappings_signal_group(3)},
    **{signal_name: "bf1_hotmetal_chem_pi" for signal_name in get_hotmetal_chems_pi_signal_group(1)},
    **{signal_name: "bf2_hotmetal_chem_pi" for signal_name in get_hotmetal_chems_pi_signal_group(2)},
    **{signal_name: "bf3_hotmetal_chem_pi" for signal_name in get_hotmetal_chems_pi_signal_group(3)},
    **{signal_name: "bf1_topgas" for signal_name in get_topgas_signal_group(1)},
    **{signal_name: "bf2_topgas" for signal_name in get_topgas_signal_group(2)},
    **{signal_name: "bf3_topgas" for signal_name in get_topgas_signal_group(3)},
    **{
        signal_name: "bf1_chargelayers_height"
        for signal_name in get_charge_layers_height_signal_group(1, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf2_chargelayers_height"
        for signal_name in get_charge_layers_height_signal_group(2, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf3_chargelayers_height"
        for signal_name in get_charge_layers_height_signal_group(3, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf1_chargelayers_id"
        for signal_name in get_charge_layers_id_signal_group(1, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf2_chargelayers_id"
        for signal_name in get_charge_layers_id_signal_group(2, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf3_chargelayers_id"
        for signal_name in get_charge_layers_id_signal_group(3, NUM_CHARGE_LAYERS)
    },
    **{
        signal_name: "bf1_chargelayers_chems"
        for signal_name in get_charge_layers_chems_signal_group(1, NUM_CHARGE_LAYERS, RAW_MATERIAL_MINERALS)
    },
    **{
        signal_name: "bf2_chargelayers_chems"
        for signal_name in get_charge_layers_chems_signal_group(2, NUM_CHARGE_LAYERS, RAW_MATERIAL_MINERALS)
    },
    **{
        signal_name: "bf3_chargelayers_chems"
        for signal_name in get_charge_layers_chems_signal_group(3, NUM_CHARGE_LAYERS, RAW_MATERIAL_MINERALS)
    },
    **{
        signal_name: "tapping_delivery_heat_chem"
        for signal_name in get_tapping_delivery_heat_chem_signal_group()
    },
    **{signal_name: "bf1_above_burden_probe" for signal_name in get_above_burden_probe_signal_names(1)},
    **{signal_name: "bf2_above_burden_probe" for signal_name in get_above_burden_probe_signal_names(2)},
    **{signal_name: "bf3_above_burden_probe" for signal_name in get_above_burden_probe_signal_names(3)},
    **{signal_name: "bf1_pressure" for signal_name in get_pressure_output_signal_names(1)},
    **{signal_name: "bf2_pressure" for signal_name in get_pressure_output_signal_names(2)},
    **{signal_name: "bf3_pressure" for signal_name in get_pressure_output_signal_names(3)},
    **{signal_name: "bf1_uptake" for signal_name in get_uptake_output_signal_names(1)},
    **{signal_name: "bf2_uptake" for signal_name in get_uptake_output_signal_names(2)},
    **{signal_name: "bf3_uptake" for signal_name in get_uptake_output_signal_names(3)},
    **{
        signal_name: "bf1_stoves_temperatures"
        for signal_name in get_stoves_temperatures_output_signal_names(1)
    },
    **{signal_name: "bf1_stoves_input_gases" for signal_name in get_stoves_input_gases_signal_group(1)},
}

SIGNALVAESIMPLE_SIGNAL_MAIN_GROUPS = ["HOTMETALTEMP", "HOTMETALCHEM"]


SIGNAL_GROUP_TO_LOADER_MAP: dict[str, Callable[[DataSources], SignalGroupLoader]] = {
    "bf1_gap_phase": lambda datasources: partial(load_gap_phase, furnace_id=1, pi_client=datasources.pi),
    "bf2_gap_phase": lambda datasources: partial(load_gap_phase, furnace_id=2, pi_client=datasources.pi),
    "bf3_gap_phase": lambda datasources: partial(load_gap_phase, furnace_id=3, pi_client=datasources.pi),
    "bf1_chargeflow": lambda datasources: partial(load_charge_flows, furnace_id=1, datasources=datasources),
    "bf2_chargeflow": lambda datasources: partial(load_charge_flows, furnace_id=2, datasources=datasources),
    "bf3_chargeflow": lambda datasources: partial(load_charge_flows, furnace_id=3, datasources=datasources),
    "bf1_hotblast": lambda datasources: partial(load_hotblast, furnace_id=1, pi_client=datasources.pi),
    "bf2_hotblast": lambda datasources: partial(load_hotblast, furnace_id=2, pi_client=datasources.pi),
    "bf3_hotblast": lambda datasources: partial(load_hotblast, furnace_id=3, pi_client=datasources.pi),
    "bf1_hotmetal_temp": lambda datasources: partial(
        load_hotmetal_temps, furnace_id=1, pi_client=datasources.pi
    ),
    "bf2_hotmetal_temp": lambda datasources: partial(
        load_hotmetal_temps, furnace_id=2, pi_client=datasources.pi
    ),
    "bf3_hotmetal_temp": lambda datasources: partial(
        load_hotmetal_temps, furnace_id=3, pi_client=datasources.pi
    ),
    "bf1_stockrod": lambda datasources: partial(load_stockrod, furnace_id=1, pi_client=datasources.pi),
    "bf2_stockrod": lambda datasources: partial(load_stockrod, furnace_id=2, pi_client=datasources.pi),
    "bf3_stockrod": lambda datasources: partial(load_stockrod, furnace_id=3, pi_client=datasources.pi),
    "bf1_hotmetal_chem": lambda datasources: partial(
        load_hotmetal_chems, furnace_id=1, datasources=datasources
    ),
    "bf2_hotmetal_chem": lambda datasources: partial(
        load_hotmetal_chems, furnace_id=2, datasources=datasources
    ),
    "bf3_hotmetal_chem": lambda datasources: partial(
        load_hotmetal_chems, furnace_id=3, datasources=datasources
    ),
    "bf1_hotmetal_chem_pi": lambda datasources: partial(
        load_hotmetal_chems_pi, furnace_id=1, datasources=datasources
    ),
    "bf2_hotmetal_chem_pi": lambda datasources: partial(
        load_hotmetal_chems_pi, furnace_id=2, datasources=datasources
    ),
    "bf3_hotmetal_chem_pi": lambda datasources: partial(
        load_hotmetal_chems_pi, furnace_id=1, datasources=datasources
    ),
    "bf1_topgas": lambda datasources: partial(load_topgas, furnace_id=1, pi_client=datasources.pi),
    "bf2_topgas": lambda datasources: partial(load_topgas, furnace_id=2, pi_client=datasources.pi),
    "bf3_topgas": lambda datasources: partial(load_topgas, furnace_id=3, pi_client=datasources.pi),
    "bf1_chargelayers_height": lambda datasources: partial(
        load_charge_layers_height, furnace_id=1, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf2_chargelayers_height": lambda datasources: partial(
        load_charge_layers_height, furnace_id=2, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf3_chargelayers_height": lambda datasources: partial(
        load_charge_layers_height, furnace_id=3, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf1_chargelayers_id": lambda datasources: partial(
        load_charge_layers_id, furnace_id=1, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf2_chargelayers_id": lambda datasources: partial(
        load_charge_layers_id, furnace_id=2, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf3_chargelayers_id": lambda datasources: partial(
        load_charge_layers_id, furnace_id=3, datasources=datasources, num_layers=NUM_CHARGE_LAYERS
    ),
    "bf1_chargelayers_chems": lambda datasources: partial(
        load_charge_layers_chems,
        furnace_id=1,
        datasources=datasources,
        num_layers=1,
        minerals=RAW_MATERIAL_MINERALS,
    ),
    "bf2_chargelayers_chems": lambda datasources: partial(
        load_charge_layers_chems,
        furnace_id=2,
        datasources=datasources,
        num_layers=1,
        minerals=RAW_MATERIAL_MINERALS,
    ),
    "bf3_chargelayers_chems": lambda datasources: partial(
        load_charge_layers_chems,
        furnace_id=3,
        datasources=datasources,
        num_layers=1,
        minerals=RAW_MATERIAL_MINERALS,
    ),
    "pulverized_coal": lambda datasources: partial(load_pulverized_coal, datasources=datasources),
    "tapping_delivery_heat_chem": lambda datasources: partial(
        load_tapping_delivery_heat_chem, datasources=datasources
    ),
    "bf1_above_burden_probe": lambda datasources: partial(
        load_above_burden_probe_phase, furnace_id=1, pi_client=datasources.pi
    ),
    "bf2_above_burden_probe": lambda datasources: partial(
        load_above_burden_probe_phase, furnace_id=2, pi_client=datasources.pi
    ),
    "bf3_above_burden_probe": lambda datasources: partial(
        load_above_burden_probe_phase, furnace_id=3, pi_client=datasources.pi
    ),
    "bf1_pressure": lambda datasources: partial(load_pressures, furnace_id=1, pi_client=datasources.pi),
    "bf2_pressure": lambda datasources: partial(load_pressures, furnace_id=2, pi_client=datasources.pi),
    "bf3_pressure": lambda datasources: partial(load_pressures, furnace_id=3, pi_client=datasources.pi),
    "bf1_uptake": lambda datasources: partial(load_uptake_phase, furnace_id=1, pi_client=datasources.pi),
    "bf2_uptake": lambda datasources: partial(load_uptake_phase, furnace_id=2, pi_client=datasources.pi),
    "bf3_uptake": lambda datasources: partial(load_uptake_phase, furnace_id=3, pi_client=datasources.pi),
    "bf1_stoves_input_gases": lambda datasources: partial(
        load_stoves_input_gases, furnace_id=1, datasources=datasources
    ),
    "bf1_stoves_temperatures": lambda datasources: partial(
        load_stoves_temperatures, furnace_id=1, pi_client=datasources.pi
    ),
}


def get_signal_group_loader(signal_group_name: str, datasources: DataSources) -> SignalGroupLoader:
    if signal_group_name not in SIGNAL_GROUP_TO_LOADER_MAP:
        raise Exception(f"Signal group with name {signal_group_name} is not registered yet")

    return SIGNAL_GROUP_TO_LOADER_MAP[signal_group_name](datasources)


def get_signal_main_group(signal_name: str) -> str:
    return SIGNAL_GROUP_TO_SIGNAL_MAIN_GROUP_MAP[SIGNAL_TO_SIGNAL_GROUP_MAP[signal_name]]
