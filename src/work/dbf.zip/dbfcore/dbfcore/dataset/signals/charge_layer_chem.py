import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals.charge_flows import (
    calculate_minerals_weight,
    prepare_relevant_charge_data,
    validate_start_end_datetimes,
)
from dbfcore.dataset.signals.utils import calculate_charge_layers_attribute, get_signal_names_with_furnace_id


def get_charge_layers_input_data(mineral_weights: pd.DataFrame, minerals: list[str]) -> pd.DataFrame:
    chem_cols = [f"{col}_weight" for col in minerals]
    return mineral_weights[["charge_date"] + chem_cols]


def get_charge_layers_one_chem_signal_names(num_layers: int, mineral: str) -> list[str]:
    return [f"charge_layer{i+1}_{mineral}_weight" for i in range(num_layers)]


def get_charge_layers_one_chem_signal_group(furnace_id: int, num_layers: int, mineral: str) -> list[str]:
    charge_layers_signal_names = get_charge_layers_one_chem_signal_names(num_layers, mineral)
    return get_signal_names_with_furnace_id(furnace_id, charge_layers_signal_names)


def get_charge_layers_chems_signal_group(furnace_id: int, num_layers: int, minerals: list[str]) -> list[str]:
    signal_group = [
        get_charge_layers_one_chem_signal_group(furnace_id, num_layers, mineral) for mineral in minerals
    ]
    return [signal for group in signal_group for signal in group]


def load_charge_layers_chems(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    num_layers: int,
    minerals: list[str],
) -> pd.DataFrame:
    vp_hook = datasources.get_vp_hook(calc_time=end, now=pd.Timestamp.utcnow())
    validate_start_end_datetimes(start, end)
    charge_data = prepare_relevant_charge_data(start, end, minerals, furnace_id, vp_hook)
    mineral_weights = calculate_minerals_weight(charge_data, minerals)

    layers_input_data = get_charge_layers_input_data(mineral_weights, minerals)
    charge_layers_chems = pd.DataFrame()
    for mineral in minerals:
        signal_names = get_charge_layers_one_chem_signal_group(furnace_id, num_layers, mineral)
        charge_layers_chem = calculate_charge_layers_attribute(
            layers_input_data, f"{mineral}_weight", signal_names, num_layers
        )
        charge_layers_chems = pd.concat([charge_layers_chems, charge_layers_chem], axis=1)

    return charge_layers_chems
