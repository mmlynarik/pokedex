import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

ABOVE_BURDEN_PROBE_PI_POINT_NAMES = [
    [
        "SK1.AboveBurdenProbe.1-1.Temp.C",
        "SK1.AboveBurdenProbe.1-2.Temp.C",
        "SK1.AboveBurdenProbe.1-3.Temp.C",
        "SK1.AboveBurdenProbe.1-4.Temp.C",
        "SK1.AboveBurdenProbe.1-5.Temp.C",
        "SK1.AboveBurdenProbe.1-6.Temp.C",
        "SK1.AboveBurdenProbe.2-1.Temp.C",
        "SK1.AboveBurdenProbe.2-2.Temp.C",
        "SK1.AboveBurdenProbe.2-3.Temp.C",
        "SK1.AboveBurdenProbe.2-4.Temp.C",
        "SK1.AboveBurdenProbe.2-5.Temp.C",
        "SK1.AboveBurdenProbe.2-6.Temp.C",
        "SK1.AboveBurdenProbe.2-7.Temp.C",
    ],
    [
        "SK2.AboveBurdenProbe.TNS11.Temp.C",
        "SK2.AboveBurdenProbe.TNS12.Temp.C",
        "SK2.AboveBurdenProbe.TNS13.Temp.C",
        "SK2.AboveBurdenProbe.TNS14.Temp.C",
        "SK2.AboveBurdenProbe.TNS15.Temp.C",
        "SK2.AboveBurdenProbe.TNS16.Temp.C",
        "SK2.AboveBurdenProbe.TNS21.Temp.C",
        "SK2.AboveBurdenProbe.TNS22.Temp.C",
        "SK2.AboveBurdenProbe.TNS23.Temp.C",
        "SK2.AboveBurdenProbe.TNS24.Temp.C",
        "SK2.AboveBurdenProbe.TNS25.Temp.C",
        "SK2.AboveBurdenProbe.TNS26.Temp.C",
        "SK2.AboveBurdenProbe.TNS27.Temp.C",
        "SK2.AboveBurdenProbe.TNS28.Temp.C",
    ],
    [
        "SK3.AboveBurdenProbe11.Temp.°C",
        "SK3.AboveBurdenProbe12.Temp.°C",
        "SK3.AboveBurdenProbe13.Temp.°C",
        "SK3.AboveBurdenProbe14.Temp.°C",
        "SK3.AboveBurdenProbe15.Temp.°C",
        "SK3.AboveBurdenProbe16.Temp.°C",
        "SK3.AboveBurdenProbe17.Temp.°C",
        "SK3.AboveBurdenProbe21.Temp.°C",
        "SK3.AboveBurdenProbe22.Temp.°C",
        "SK3.AboveBurdenProbe23.Temp.°C",
        "SK3.AboveBurdenProbe24.Temp.°C",
        "SK3.AboveBurdenProbe25.Temp.°C",
        "SK3.AboveBurdenProbe26.Temp.°C",
        "SK3.AboveBurdenProbe27.Temp.°C",
        "SK3.AboveBurdenProbe31.Temp.°C",
        "SK3.AboveBurdenProbe32.Temp.°C",
        "SK3.AboveBurdenProbe33.Temp.°C",
        "SK3.AboveBurdenProbe34.Temp.°C",
        "SK3.AboveBurdenProbe35.Temp.°C",
        "SK3.AboveBurdenProbe36.Temp.°C",
        "SK3.AboveBurdenProbe37.Temp.°C",
        "SK3.AboveBurdenProbe41.Temp.°C",
        "SK3.AboveBurdenProbe42.Temp.°C",
        "SK3.AboveBurdenProbe43.Temp.°C",
        "SK3.AboveBurdenProbe44.Temp.°C",
        "SK3.AboveBurdenProbe45.Temp.°C",
        "SK3.AboveBurdenProbe46.Temp.°C",
        "SK3.AboveBurdenProbe47.Temp.°C",
    ],
]


def get_above_burden_probe_pi_point_names(furnace_id: int) -> list[str]:
    return ABOVE_BURDEN_PROBE_PI_POINT_NAMES[furnace_id - 1]


def get_above_burden_probe_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal]
        for signal in get_above_burden_probe_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_above_burden_probe_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_aboveburdenprobe_temp_C"]


def get_resample_signal(df: pd.DataFrame, signal_name: str, resample_rule: str = "30s") -> pd.DataFrame:
    df = df.resample(resample_rule, label="right", closed="right").mean()
    df = df.dropna(subset=[signal_name])
    return df


def get_median_from_signals(dfs: list[pd.DataFrame], median_column_name: str) -> pd.DataFrame:
    return (
        pd.concat(dfs, axis=1, join="outer")
        .median(axis=1, skipna=True)
        .to_frame()
        .set_axis([median_column_name], axis="columns")
    )


def get_only_positive_values(df: pd.DataFrame) -> pd.DataFrame:
    # If the temperature sensor is faulty, it either shows zero or negative values.
    # Therefore, we select only positive temperature values.
    return df[df > 0].dropna()


def load_above_burden_probe_phase(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_names = get_above_burden_probe_pi_point_names(furnace_id)
    signal_names = get_above_burden_probe_signal_group(furnace_id)
    above_burden_probe_dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        if not df.empty:
            df = get_only_positive_values(df)
            if not df.empty:
                df = df[~df.index.duplicated()]
                df = get_resample_signal(df, signal_name)
                above_burden_probe_dfs.append(df)
    df = get_median_from_signals(above_burden_probe_dfs, get_above_burden_probe_signal_names(furnace_id)[0])
    df = df.sort_index()

    return df
