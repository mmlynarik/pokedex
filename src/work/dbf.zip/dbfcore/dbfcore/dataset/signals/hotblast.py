from functools import partial
from typing import Callable

import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.model.datamodule.preprocessing import get_cleaned_pi_signal_data

HOTBLAST_PI_POINT_NAMES = [
    [
        "SK1.HotBlast.Flow.Nm3/hr",
        "SK1.HotBlast.Temperature1.Temp.C",
        "SK1.HotBlast.Moisture.Flow.g/Nm3",
        "SK1.NaturalGas.Tuyeres.Vol.m3/h",
        "SK1.HotBlast.O2.Flow.Nm3/hr",
        "SK1.HotBlast.PCI.Flow.kghr",
    ],
    [
        "SK2.HotBlast.Flow.Nm3hr",
        "SK2.HotBlast.Temperature.Temp.C",
        "SK2.HotBlast.Moisture.Flow.gNm3",
        "SK2.HotBlast.O2.Flow.Nm3hr",
        "SK2.HotBlast.PCI.Flow.kghr",
    ],
    [
        "SK3.HotBlast.Flow.Nm3hr",
        "SK3.HotBlast.Temperature.Temp.C",
        "SK3.HotBlast.Moisture.Flow.gNm3",
        "SK3.HotBlast.O2.Flow.Nm3hr",
        "SK3.HotBlast.PCI.Flow.kghr",
    ],
]


def get_hotblast_pi_point_names(furnace_id: int) -> list[str]:
    return HOTBLAST_PI_POINT_NAMES[furnace_id - 1]


def get_hotblast_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_hotblast_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_cleaning_fn_by_pi_point_name(pi_point_name: str) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if pi_point_name == "SK1.HotBlast.Flow.Nm3/hr":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("5m"),
            recalibration_duration=pd.Timedelta("5m"),
            extreme_grad_threshold=2000,
        )
    elif pi_point_name == "SK1.HotBlast.O2.Flow.Nm3/hr":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("2m"),
            recalibration_duration=pd.Timedelta("2m"),
            extreme_grad_threshold=500,
            lower_outlier_threshold=2000,
        )
    elif pi_point_name == "SK1.HotBlast.Moisture.Flow.g/Nm3":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("15m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.4,
            lower_outlier_threshold=0,
        )
    elif pi_point_name in ["SK2.HotBlast.Flow.Nm3hr", "SK3.HotBlast.Flow.Nm3hr"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=100,
        )
    elif pi_point_name in ["SK2.HotBlast.Temperature.Temp.C", "SK3.HotBlast.Temperature.Temp.C"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("0.5m"),
            recalibration_duration=pd.Timedelta("0.5m"),
            extreme_grad_threshold=0.1,
        )
    elif pi_point_name in ["SK2.HotBlast.Moisture.Flow.gNm3", "SK3.HotBlast.Moisture.Flow.gNm3"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("5m"),
            recalibration_duration=pd.Timedelta("5m"),
            extreme_grad_threshold=0.1,
        )
    elif pi_point_name in ["SK2.HotBlast.O2.Flow.Nm3hr", "SK3.HotBlast.O2.Flow.Nm3hr"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=20,
        )
    elif pi_point_name in ["SK2.HotBlast.PCI.Flow.kghr", "SK3.HotBlast.PCI.Flow.kghr"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=50,
        )
    else:
        return lambda x: x


def load_hotblast(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_names = get_hotblast_pi_point_names(furnace_id)
    signal_names = get_hotblast_signal_group(furnace_id)
    hotblast_dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        cleaning_fn = get_cleaning_fn_by_pi_point_name(pi_point_name)
        raw_df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        cleaned_data = cleaning_fn(raw_df)
        df = cleaned_data.dropna().sort_index()
        df = df[~df.index.duplicated()].sort_index()
        hotblast_dfs.append(df)

    return pd.concat(hotblast_dfs, axis=1)
