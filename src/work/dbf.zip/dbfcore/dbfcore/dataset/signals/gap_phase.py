import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

GAP_PHASE_PI_POINT_NAMES = [["SK1.Gap.Phase"], ["SK2.Gap.Phase"], ["SK3.Gap.Phase"]]


def get_gap_phase_pi_point_names(furnace_id: int) -> list[str]:
    return GAP_PHASE_PI_POINT_NAMES[furnace_id - 1]


def get_gap_phase_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_gap_phase_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def load_gap_phase(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient
) -> pd.DataFrame:
    pi_point_name = get_gap_phase_pi_point_names(furnace_id)[0]
    signal_name = get_gap_phase_signal_group(furnace_id)[0]
    raw_df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
    df = raw_df.dropna().sort_index()

    return df[~df.index.duplicated()].sort_index()
