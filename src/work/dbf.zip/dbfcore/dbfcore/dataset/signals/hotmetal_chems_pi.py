import logging

import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP

logger = logging.getLogger(__name__)


HOTMETAL_CHEMS_PI_POINT_NAMES = [
    ["SK1.HotMetal.Samples.Si.Content.%", "SK1.HotMetal.Si.MeasDevice.%"],
    ["SK2.HotMetal.Samples.Si.Content.%", "SK2.HotMetal.Si.MeasDevice.%"],
    ["SK3.HotMetal.Samples.Si.Content.%"],
]


def get_hotmetal_chems_pi_point_names(furnace_id: int) -> list[str]:
    return HOTMETAL_CHEMS_PI_POINT_NAMES[furnace_id - 1]


def get_hotmetal_chems_pi_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_hotmetal_chems_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def load_hotmetal_chems_pi(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
) -> pd.DataFrame:
    """Returns hotmetal chems from PI"""
    dfs = []
    pi_point_names = get_hotmetal_chems_pi_point_names(furnace_id)
    signal_names = get_hotmetal_chems_pi_signal_group(furnace_id)

    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(datasources.pi, pi_point_name, start, end, signal_name)
        dfs.append(df)

    return pd.concat(dfs, axis=1)
