from datetime import datetime
from typing import Optional

import pandas as pd

from dbfcore.dataset.hooks import AZVPHook, DataSources, PZVPHook
from dbfcore.dataset.preprocessed_dataset.autoencoder_flows_preprocessing import (
    FLOWS_SAMPLING_FREQ,
    get_mineral_weight_columns,
)
from dbfcore.dataset.preprocessed_dataset.transformations.charge_flows import (
    get_charge_flows_time_series_for_multiple_columns,
)
from dbfcore.dataset.preprocessed_dataset.transformations.raw_material import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_mineral_weight,
)
from dbfcore.dataset.raw_dataset.raw_material_data_processor import (
    exclude_sinter_from_raw_material_numbers,
    get_relevant_charge_data_in_wide_format,
)
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.dataset.signals.utils import InvalidSignalName, get_signal_names_with_furnace_id
from dbfcore.utils import is_utc

VPHook = PZVPHook | AZVPHook


SIGNAL_NAME_TO_MINERAL_MAP = {
    "bf1_chargeal2o3_flow_kgh": "al2o3",
    "bf1_chargears_flow_kgh": "ars",
    "bf1_chargec_flow_kgh": "c",
    "bf1_chargecao_flow_kgh": "cao",
    "bf1_chargecu_flow_kgh": "cu",
    "bf1_chargefe2o3_flow_kgh": "fe2o3",
    "bf1_chargefeo_flow_kgh": "feo",
    "bf1_chargeh2o_flow_kgh": "h2o",
    "bf1_chargehg_flow_kgh": "hg",
    "bf1_chargek2o_flow_kgh": "k2o",
    "bf1_chargemgo_flow_kgh": "mgo",
    "bf1_chargemn_flow_kgh": "mn",
    "bf1_chargena2o_flow_kgh": "na2o",
    "bf1_chargep_flow_kgh": "p",
    "bf1_chargepb_flow_kgh": "pb",
    "bf1_charges_flow_kgh": "s",
    "bf1_chargesio2_flow_kgh": "sio2",
    "bf1_chargeti_flow_kgh": "ti",
    "bf1_chargetio2_flow_kgh": "tio2",
    "bf1_chargezn_flow_kgh": "zn",
    "bf2_chargeal2o3_flow_kgh": "al2o3",
    "bf2_chargears_flow_kgh": "ars",
    "bf2_chargec_flow_kgh": "c",
    "bf2_chargecao_flow_kgh": "cao",
    "bf2_chargecu_flow_kgh": "cu",
    "bf2_chargefe2o3_flow_kgh": "fe2o3",
    "bf2_chargefeo_flow_kgh": "feo",
    "bf2_chargeh2o_flow_kgh": "h2o",
    "bf2_chargehg_flow_kgh": "hg",
    "bf2_chargek2o_flow_kgh": "k2o",
    "bf2_chargemgo_flow_kgh": "mgo",
    "bf2_chargemn_flow_kgh": "mn",
    "bf2_chargena2o_flow_kgh": "na2o",
    "bf2_chargep_flow_kgh": "p",
    "bf2_chargepb_flow_kgh": "pb",
    "bf2_charges_flow_kgh": "s",
    "bf2_chargesio2_flow_kgh": "sio2",
    "bf2_chargeti_flow_kgh": "ti",
    "bf2_chargetio2_flow_kgh": "tio2",
    "bf2_chargezn_flow_kgh": "zn",
    "bf3_chargeal2o3_flow_kgh": "al2o3",
    "bf3_chargears_flow_kgh": "ars",
    "bf3_chargec_flow_kgh": "c",
    "bf3_chargecao_flow_kgh": "cao",
    "bf3_chargecu_flow_kgh": "cu",
    "bf3_chargefe2o3_flow_kgh": "fe2o3",
    "bf3_chargefeo_flow_kgh": "feo",
    "bf3_chargeh2o_flow_kgh": "h2o",
    "bf3_chargehg_flow_kgh": "hg",
    "bf3_chargek2o_flow_kgh": "k2o",
    "bf3_chargemgo_flow_kgh": "mgo",
    "bf3_chargemn_flow_kgh": "mn",
    "bf3_chargena2o_flow_kgh": "na2o",
    "bf3_chargep_flow_kgh": "p",
    "bf3_chargepb_flow_kgh": "pb",
    "bf3_charges_flow_kgh": "s",
    "bf3_chargesio2_flow_kgh": "sio2",
    "bf3_chargeti_flow_kgh": "ti",
    "bf3_chargetio2_flow_kgh": "tio2",
    "bf3_chargezn_flow_kgh": "zn",
}


SIGNAL_NAME_TO_DATASET_COLUMN_NAME_MAP = {
    "bf1_chargeal2o3_flow_kgh": "chargeal2o3_flow_kgh",
    "bf1_chargears_flow_kgh": "chargears_flow_kgh",
    "bf1_chargec_flow_kgh": "chargec_flow_kgh",
    "bf1_chargecao_flow_kgh": "chargecao_flow_kgh",
    "bf1_chargecu_flow_kgh": "chargecu_flow_kgh",
    "bf1_chargefe2o3_flow_kgh": "chargefe2o3_flow_kgh",
    "bf1_chargefeo_flow_kgh": "chargefeo_flow_kgh",
    "bf1_chargeh2o_flow_kgh": "chargeh2o_flow_kgh",
    "bf1_chargehg_flow_kgh": "chargehg_flow_kgh",
    "bf1_chargek2o_flow_kgh": "chargek2o_flow_kgh",
    "bf1_chargemgo_flow_kgh": "chargemgo_flow_kgh",
    "bf1_chargemn_flow_kgh": "chargemn_flow_kgh",
    "bf1_chargena2o_flow_kgh": "chargena2o_flow_kgh",
    "bf1_chargep_flow_kgh": "chargep_flow_kgh",
    "bf1_chargepb_flow_kgh": "chargepb_flow_kgh",
    "bf1_charges_flow_kgh": "charges_flow_kgh",
    "bf1_chargesio2_flow_kgh": "chargesio2_flow_kgh",
    "bf1_chargeti_flow_kgh": "chargeti_flow_kgh",
    "bf1_chargetio2_flow_kgh": "chargetio2_flow_kgh",
    "bf1_chargezn_flow_kgh": "chargezn_flow_kgh",
    "bf1_chargecoke_flow_kgh": "chargecoke_flow_kgh",
    "bf2_chargeal2o3_flow_kgh": "chargeal2o3_flow_kgh",
    "bf2_chargears_flow_kgh": "chargears_flow_kgh",
    "bf2_chargec_flow_kgh": "chargec_flow_kgh",
    "bf2_chargecao_flow_kgh": "chargecao_flow_kgh",
    "bf2_chargecu_flow_kgh": "chargecu_flow_kgh",
    "bf2_chargefe2o3_flow_kgh": "chargefe2o3_flow_kgh",
    "bf2_chargefeo_flow_kgh": "chargefeo_flow_kgh",
    "bf2_chargeh2o_flow_kgh": "chargeh2o_flow_kgh",
    "bf2_chargehg_flow_kgh": "chargehg_flow_kgh",
    "bf2_chargek2o_flow_kgh": "chargek2o_flow_kgh",
    "bf2_chargemgo_flow_kgh": "chargemgo_flow_kgh",
    "bf2_chargemn_flow_kgh": "chargemn_flow_kgh",
    "bf2_chargena2o_flow_kgh": "chargena2o_flow_kgh",
    "bf2_chargep_flow_kgh": "chargep_flow_kgh",
    "bf2_chargepb_flow_kgh": "chargepb_flow_kgh",
    "bf2_charges_flow_kgh": "charges_flow_kgh",
    "bf2_chargesio2_flow_kgh": "chargesio2_flow_kgh",
    "bf2_chargeti_flow_kgh": "chargeti_flow_kgh",
    "bf2_chargetio2_flow_kgh": "chargetio2_flow_kgh",
    "bf2_chargezn_flow_kgh": "chargezn_flow_kgh",
    "bf2_chargecoke_flow_kgh": "chargecoke_flow_kgh",
    "bf3_chargeal2o3_flow_kgh": "chargeal2o3_flow_kgh",
    "bf3_chargears_flow_kgh": "chargears_flow_kgh",
    "bf3_chargec_flow_kgh": "chargec_flow_kgh",
    "bf3_chargecao_flow_kgh": "chargecao_flow_kgh",
    "bf3_chargecu_flow_kgh": "chargecu_flow_kgh",
    "bf3_chargefe2o3_flow_kgh": "chargefe2o3_flow_kgh",
    "bf3_chargefeo_flow_kgh": "chargefeo_flow_kgh",
    "bf3_chargeh2o_flow_kgh": "chargeh2o_flow_kgh",
    "bf3_chargehg_flow_kgh": "chargehg_flow_kgh",
    "bf3_chargek2o_flow_kgh": "chargek2o_flow_kgh",
    "bf3_chargemgo_flow_kgh": "chargemgo_flow_kgh",
    "bf3_chargemn_flow_kgh": "chargemn_flow_kgh",
    "bf3_chargena2o_flow_kgh": "chargena2o_flow_kgh",
    "bf3_chargep_flow_kgh": "chargep_flow_kgh",
    "bf3_chargepb_flow_kgh": "chargepb_flow_kgh",
    "bf3_charges_flow_kgh": "charges_flow_kgh",
    "bf3_chargesio2_flow_kgh": "chargesio2_flow_kgh",
    "bf3_chargeti_flow_kgh": "chargeti_flow_kgh",
    "bf3_chargetio2_flow_kgh": "chargetio2_flow_kgh",
    "bf3_chargezn_flow_kgh": "chargezn_flow_kgh",
    "bf3_chargecoke_flow_kgh": "chargecoke_flow_kgh",
    "bf1_hotmetalas_chem_pct": "hotmetalas_chem_pct",
    "bf1_hotmetalc_chem_pct": "hotmetalc_chem_pct",
    "bf1_hotmetalfe_chem_pct": "hotmetalfe_chem_pct",
    "bf1_hotmetalmn_chem_pct": "hotmetalmn_chem_pct",
    "bf1_hotmetalp_chem_pct": "hotmetalp_chem_pct",
    "bf1_hotmetalpb_chem_pct": "hotmetalpb_chem_pct",
    "bf1_hotmetals_chem_pct": "hotmetals_chem_pct",
    "bf1_hotmetalsi_chem_pct": "hotmetalsi_chem_pct",
    "bf1_hotmetalti_chem_pct": "hotmetalti_chem_pct",
    "bf1_hotmetalzn_chem_pct": "hotmetalzn_chem_pct",
    "bf2_hotmetalas_chem_pct": "hotmetalas_chem_pct",
    "bf2_hotmetalc_chem_pct": "hotmetalc_chem_pct",
    "bf2_hotmetalfe_chem_pct": "hotmetalfe_chem_pct",
    "bf2_hotmetalmn_chem_pct": "hotmetalmn_chem_pct",
    "bf2_hotmetalp_chem_pct": "hotmetalp_chem_pct",
    "bf2_hotmetalpb_chem_pct": "hotmetalpb_chem_pct",
    "bf2_hotmetals_chem_pct": "hotmetals_chem_pct",
    "bf2_hotmetalsi_chem_pct": "hotmetalsi_chem_pct",
    "bf2_hotmetalti_chem_pct": "hotmetalti_chem_pct",
    "bf2_hotmetalzn_chem_pct": "hotmetalzn_chem_pct",
    "bf3_hotmetalas_chem_pct": "hotmetalas_chem_pct",
    "bf3_hotmetalc_chem_pct": "hotmetalc_chem_pct",
    "bf3_hotmetalfe_chem_pct": "hotmetalfe_chem_pct",
    "bf3_hotmetalmn_chem_pct": "hotmetalmn_chem_pct",
    "bf3_hotmetalp_chem_pct": "hotmetalp_chem_pct",
    "bf3_hotmetalpb_chem_pct": "hotmetalpb_chem_pct",
    "bf3_hotmetals_chem_pct": "hotmetals_chem_pct",
    "bf3_hotmetalsi_chem_pct": "hotmetalsi_chem_pct",
    "bf3_hotmetalti_chem_pct": "hotmetalti_chem_pct",
    "bf3_hotmetalzn_chem_pct": "hotmetalzn_chem_pct",
    "bf1_gap_phase_enum": "gap_phase_enum",
    "bf1_hotblast_flow_Nm3h": "hotblast_flow_Nm3h",
    "bf1_hotblast_temp_C": "hotblast_temp_C",
    "bf1_hotblastmoisture_flow_gNm3": "hotblastmoisture_flow_gNm3",
    "bf1_hotblastng_flow_m3h": "hotblastng_flow_m3h",
    "bf1_hotblasto2_flow_Nm3h": "hotblasto2_flow_Nm3h",
    "bf1_hotblastpci_flow_kgh": "hotblastpci_flow_kgh",
    "bf1_hotmetal_temp_C": "hotmetal_temp_C",
    "bf1_stockrod1_distance_m": "stockrod1_distance_m",
    "bf1_stockrod2_distance_m": "stockrod2_distance_m",
    "bf1_topgasco_chem_pct": "topgasco_chem_pct",
    "bf1_topgasco2_chem_pct": "topgasco2_chem_pct",
    "bf1_topgash2_chem_pct": "topgash2_chem_pct",
    "bf2_gap_phase_enum": "gap_phase_enum",
    "bf2_hotblast_flow_Nm3h": "hotblast_flow_Nm3h",
    "bf2_hotblast_temp_C": "hotblast_temp_C",
    "bf2_hotblastmoisture_flow_gNm3": "hotblastmoisture_flow_gNm3",
    "bf2_hotblastng_flow_m3h": "hotblastng_flow_m3h",
    "bf2_hotblasto2_flow_Nm3h": "hotblasto2_flow_Nm3h",
    "bf2_hotblastpci_flow_kgh": "hotblastpci_flow_kgh",
    "bf2_hotmetal_temp_C": "hotmetal_temp_C",
    "bf2_stockrod1_distance_m": "stockrod1_distance_m",
    "bf2_stockrod2_distance_m": "stockrod2_distance_m",
    "bf2_topgasco_chem_pct": "topgasco_chem_pct",
    "bf2_topgasco2_chem_pct": "topgasco2_chem_pct",
    "bf2_topgash2_chem_pct": "topgash2_chem_pct",
    "bf3_gap_phase_enum": "gap_phase_enum",
    "bf3_hotblast_flow_Nm3h": "hotblast_flow_Nm3h",
    "bf3_hotblast_temp_C": "hotblast_temp_C",
    "bf3_hotblastmoisture_flow_gNm3": "hotblastmoisture_flow_gNm3",
    "bf3_hotblastng_flow_m3h": "hotblastng_flow_m3h",
    "bf3_hotblasto2_flow_Nm3h": "hotblasto2_flow_Nm3h",
    "bf3_hotblastpci_flow_kgh": "hotblastpci_flow_kgh",
    "bf3_hotmetal_temp_C": "hotmetal_temp_C",
    "bf3_stockrod1_distance_m": "stockrod1_distance_m",
    "bf3_stockrod2_distance_m": "stockrod2_distance_m",
    "bf3_topgasco_chem_pct": "topgasco_chem_pct",
    "bf3_topgasco2_chem_pct": "topgasco2_chem_pct",
    "bf3_topgash2_chem_pct": "topgash2_chem_pct",
}


CHARGE_FLOWS_COLUMNS_FROM_DATASET = [
    "chargec_flow_kgh",
    "chargecao_flow_kgh",
    "chargefe2o3_flow_kgh",
    "chargefeo_flow_kgh",
    "chargeh2o_flow_kgh",
    "chargemgo_flow_kgh",
    "chargemn_flow_kgh",
    "chargesio2_flow_kgh",
]


def get_minerals_from_signal_names(signal_names: list[str]) -> list[str]:
    minerals = []
    for signal_name in signal_names:
        if signal_name not in SIGNAL_NAME_TO_MINERAL_MAP:
            raise InvalidSignalName(signal_name, list(SIGNAL_NAME_TO_MINERAL_MAP))
        minerals.append(SIGNAL_NAME_TO_MINERAL_MAP[signal_name])
    return minerals


def get_column_names_from_signal_names(signal_names: list[str]) -> list[str]:
    column_names = []
    for signal_name in signal_names:
        if signal_name not in SIGNAL_NAME_TO_DATASET_COLUMN_NAME_MAP:
            raise InvalidSignalName(signal_name, list(SIGNAL_NAME_TO_DATASET_COLUMN_NAME_MAP))
        column_names.append(SIGNAL_NAME_TO_DATASET_COLUMN_NAME_MAP[signal_name])
    return column_names


def get_extended_raw_material_charge_period_dates(
    start: datetime, end: datetime, furnace_id: int, vp_hook: VPHook
) -> tuple[datetime, datetime]:
    extended_start = vp_hook.get_raw_material_charge_extended_start_date(start, furnace_id)
    extended_end = vp_hook.get_raw_material_charge_extended_end_date(end, furnace_id)
    return extended_start, extended_end or end


def load_raw_material_charge_data_from_data_sources(
    start: datetime, end: datetime, furnace_id: int, vp_hook: VPHook
) -> pd.DataFrame:
    start, end = get_extended_raw_material_charge_period_dates(start, end, furnace_id, vp_hook)
    raw_material_charge = vp_hook.get_raw_material_charge(start, end, furnace_id)
    return raw_material_charge


def load_charge_and_analyses_data_from_data_sources(
    start: datetime, end: datetime, furnace_id: int, vp_hook: VPHook
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    start, end = get_extended_raw_material_charge_period_dates(start, end, furnace_id, vp_hook)
    raw_material_charge = vp_hook.get_raw_material_charge(start, end, furnace_id)
    charge_summary = vp_hook.get_raw_material_charge_summary(start, end, furnace_id)
    raw_mat_numbers = exclude_sinter_from_raw_material_numbers(raw_material_charge["raw_material_number"])
    raw_material_analysis = vp_hook.get_raw_material_analysis(start, end, raw_mat_numbers)
    sinter_analysis = vp_hook.get_sinter_analysis(start, end)
    return raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary


def utcify_date_columns(
    raw_material_analysis: pd.DataFrame,
    sinter_analysis: pd.DataFrame,
    raw_material_charge: pd.DataFrame,
    charge_summary: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    raw_material_analysis = localize_date_columns_and_convert_to_utc(raw_material_analysis)
    sinter_analysis = localize_date_columns_and_convert_to_utc(sinter_analysis)
    raw_material_charge = localize_date_columns_and_convert_to_utc(raw_material_charge)
    charge_summary = localize_date_columns_and_convert_to_utc(charge_summary)
    return raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary


def prepare_relevant_charge_data(
    start: datetime, end: datetime, minerals: list[str], furnace_id: int, vp_hook: VPHook
) -> pd.DataFrame:
    raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = (
        load_charge_and_analyses_data_from_data_sources(start, end, furnace_id, vp_hook)
    )
    if raw_material_analysis.empty:
        return pd.DataFrame()
    raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
    )
    output = get_relevant_charge_data_in_wide_format(
        raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary, minerals
    )
    return output


def get_max_num_raw_materials(charge_data: pd.DataFrame) -> int:
    return max(int(x.split("_")[-1]) for x in charge_data.columns if "weight" in x)


def calculate_minerals_weight(charge_data: pd.DataFrame, minerals: list[str]) -> pd.DataFrame:
    num_raw_materials = get_max_num_raw_materials(charge_data)
    df = calculate_mineral_weight_of_all_raw_materials(charge_data, minerals, num_raw_materials)
    df = calculate_total_mineral_weight(df, minerals, num_raw_materials)
    return df


def filter_flow_columns_and_index(data: pd.DataFrame, signal_names: list[str]) -> pd.DataFrame:
    column_names = get_column_names_from_signal_names(signal_names)
    data = data[["date", *column_names]].set_index("date")
    data.index.name = "Timestamp"
    return data


def validate_start_end_datetimes(start: datetime, end: datetime) -> None:
    if not is_utc(start):
        raise ValueError("Start datetime must be in UTC timezone.")
    if not is_utc(end):
        raise ValueError("End datetime must be in UTC timezone.")


def fill_missing_values(data: pd.DataFrame, end: datetime, sampling_freq: pd.Timedelta) -> pd.DataFrame:
    """For window_size periods, which don't have charge after their end, the flows will be extrapolated"""
    index = pd.date_range(data.index[-1], end, freq=sampling_freq, inclusive="right", name=data.index.name)
    filled_values = pd.DataFrame([data.iloc[-1] for _ in index], index=index, columns=data.columns)
    concatenated = pd.concat([data, filled_values])
    result = concatenated[~concatenated.index.duplicated()].sort_index()
    return result


# TODO: Refactor this and get_charge_flows_time_series_for_multiple_columns function,
# move missing values for last window right after charge flows calculation or inside it
def live_charge_data_loader(
    signal_name: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
) -> pd.DataFrame:
    """
    Returns fetched data and cacheability flag. First fetched charge must begin before start datetime and
    last fetched charge must finish after end datetime in order to calculate charge flows for full period.
    """
    return load_charge_flows(start, end, furnace_id, datasources, signal_name)


def get_charge_flows_signal_group(furnace_id: int) -> list[str]:
    return get_signal_names_with_furnace_id(furnace_id, CHARGE_FLOWS_COLUMNS_FROM_DATASET)


def load_charge_flows(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    signal_name: Optional[str] = None,
) -> pd.DataFrame:
    signal_names = get_charge_flows_signal_group(furnace_id) if not signal_name else [signal_name]
    vp_hook = datasources.get_vp_hook(calc_time=end, now=pd.Timestamp.utcnow())
    start, end = start.to_pydatetime(), end.to_pydatetime()
    validate_start_end_datetimes(start, end)
    minerals = get_minerals_from_signal_names(signal_names)
    data = prepare_relevant_charge_data(start, end, minerals, furnace_id, vp_hook)
    # If there is no charge after and during the window_size period simultaneously (i.e. the only fetched
    # charge is before period, ie, len(data)=1, flows can't be calculated. Empty df is not possible - there is
    # always a charge before the period.
    # If there is one charge before and one charge during the window_size and the charge during the
    # window_size has charge date not after first flow period, no flow period can be correctly calculated.
    if len(data) == 1 or (len(data) == 2 and data["charge_date"][1] <= start + FLOWS_SAMPLING_FREQ):
        return pd.DataFrame()

    data = calculate_minerals_weight(data, minerals)
    data = get_charge_flows_time_series_for_multiple_columns(
        data,
        get_mineral_weight_columns(minerals),
        "charge_date",
        FLOWS_SAMPLING_FREQ,
        start,
        end,
    )
    data = filter_flow_columns_and_index(data, signal_names)
    data = data.dropna().sort_index()
    data = data[~data.index.duplicated()].sort_index()

    data = fill_missing_values(data, end, FLOWS_SAMPLING_FREQ)
    data = data.rename(columns=dict(zip(CHARGE_FLOWS_COLUMNS_FROM_DATASET, signal_names)))
    return data
