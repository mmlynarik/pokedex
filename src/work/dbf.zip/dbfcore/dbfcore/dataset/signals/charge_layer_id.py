from datetime import datetime

import pandas as pd

from dbfcore.dataset.hooks import DataSources, VPHook
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.dataset.signals.charge_flows import (
    load_raw_material_charge_data_from_data_sources,
    validate_start_end_datetimes,
)
from dbfcore.dataset.signals.utils import calculate_charge_layers_attribute, get_signal_names_with_furnace_id


def prepare_charge_numbers_data(
    start: datetime, end: datetime, furnace_id: int, vp_hook: VPHook
) -> pd.DataFrame:
    raw_material_charge = load_raw_material_charge_data_from_data_sources(start, end, furnace_id, vp_hook)
    if raw_material_charge.empty:
        return pd.DataFrame()
    raw_material_charge = localize_date_columns_and_convert_to_utc(raw_material_charge)
    return raw_material_charge.groupby("charge_date", as_index=False).agg({"charge_number": "min"})


def get_charge_layers_input_data(charge_numbers: pd.DataFrame) -> pd.DataFrame:
    charge_numbers["layer_id"] = (
        charge_numbers["charge_number"] * 10000 + charge_numbers["charge_date"].dt.year
    )
    return charge_numbers


def get_charge_layer_id_signal_names(num_layers: int) -> list[str]:
    return [f"charge_layer{i+1}_id" for i in range(num_layers)]


def get_charge_layers_id_signal_group(furnace_id: int, num_layers: int) -> list[str]:
    charge_layers_signal_names = get_charge_layer_id_signal_names(num_layers)
    return get_signal_names_with_furnace_id(furnace_id, charge_layers_signal_names)


def load_charge_layers_id(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources, num_layers: int
) -> pd.DataFrame:
    vp_hook = datasources.get_vp_hook(calc_time=end, now=pd.Timestamp.utcnow())
    start, end = start.to_pydatetime(), end.to_pydatetime()
    validate_start_end_datetimes(start, end)
    charge_numbers = prepare_charge_numbers_data(start, end, furnace_id, vp_hook)

    layers_input_data = get_charge_layers_input_data(charge_numbers)
    signal_names = get_charge_layers_id_signal_group(furnace_id, num_layers)
    charge_layers_id = calculate_charge_layers_attribute(
        layers_input_data, "layer_id", signal_names, num_layers
    )

    return charge_layers_id
