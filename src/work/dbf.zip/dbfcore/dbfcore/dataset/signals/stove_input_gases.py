import math
from typing import Sequence

import numpy as np
import pandas as pd
from pandas import DataFrame

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.dataset.signals.topgas import load_topgas
from dbfcore.dataset.signals.utils import get_molar_pct_from_mass_pct, get_regular_time_series_data
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.settings import (
    SPP_NATURAL_GAS_CHEM_COMPOSITION,
    STOVE_AIR_CHEMS,
    STOVE_BFG_CHEMS,
    STOVE_COG_CHEMS,
    STOVE_NUMBERS,
)

STOVES_INPUT_GASES_PI_POINT_NAMES = [
    [
        "SK1.Stove.11.COGGas.Vol.m3/h",
        "SK1.Stove11.Blend Gas.Vol.m3/h",
        "SK1.Stove11.CombustionAir.Vol.m3/h",
        "SK1.Stove.12.COGGas.Vol.m3/h",
        "SK1.Stove12.Blend Gas.Vol.m3/h",
        "SK1.Stove12.CombustionAir.Vol.m3/h",
        "SK1.Stove.13.COGGas.Vol.m3/h",
        "SK1.Stove13.Blend Gas.Vol.m3/h",
        "SK1.Stove13.CombustionAir.Vol.m3/h",
        "SK1.Stove.14.COGGas.Vol.m3/h",
        "SK1.Stove14.Blend Gas.Vol.m3/h",
        "SK1.Stove14.CombustionAir.Vol.m3/h",
    ],
]

NATURAL_GAS_PI_POINT_NAMES = [["SK1.NaturalGas.Vol.m3/h"]]
STOVES_TEMP_PI_POINT_NAMES = [
    [
        "SK1.Preheating.CombAir.Output.Temp.C",
        "SK1.Preheating.BFGas.Output.Temp.C",
        "SK3.Air.Exterior.Temp.C",
    ],
]
AIR_PROPERTIES_PI_POINT_NAMES = [
    [
        "SK1.AtmosphericMoisture",  # relative atmospheric humidity
        "SK3.Air.Exterior.Temp.C",  # atmospheric temperature (°C)
    ]
]
BFG_PROPERTIES_PI_POINT_NAMES = [
    [
        "SK1.Preheating.BFGas.Input.Temp.C",  # BFG temperature before preheating (°C)
        "SK1.Preheating.BFGas.Input.Pres.Pa",  # BFG pressure before preheating (kPa)
    ]
]

WASTE_GAS_ASO_PI_POINT_NAMES = [
    [
        "SK1.Stove11.WasteGas.O2.Comtent.%",
        "SK1.Stove12.WasteGas.O2.Comtent.%",
        "SK1.Stove13.WasteGas.O2.Comtent.%",
        "SK1.Stove14.WasteGas.O2.Comtent.%",
    ]
]


def get_stoves_input_gases_pi_point_names(furnace_id: int) -> list[str]:
    return STOVES_INPUT_GASES_PI_POINT_NAMES[furnace_id - 1]


def get_natural_gas_pi_point_name(furnace_id: int) -> str:
    return NATURAL_GAS_PI_POINT_NAMES[furnace_id - 1][0]


def get_stoves_temp_pi_point_names(furnace_id: int) -> list[str]:
    return STOVES_TEMP_PI_POINT_NAMES[furnace_id - 1]


def get_air_properties_pi_point_names(furnace_id: int) -> list[str]:
    return AIR_PROPERTIES_PI_POINT_NAMES[furnace_id - 1]


def get_bfg_properties_pi_point_names(furnace_id: int) -> list[str]:
    return BFG_PROPERTIES_PI_POINT_NAMES[furnace_id - 1]


def get_waste_gas_aso_pi_point_names(furnace_id: int) -> list[str]:
    return WASTE_GAS_ASO_PI_POINT_NAMES[furnace_id - 1]


def get_stoves_temp_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        (
            PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal]
            if signal != "SK3.Air.Exterior.Temp.C"
            else [f"bf{furnace_id}_{PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal][0]}"]
        )
        for signal in get_stoves_temp_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_stove_number_from_signal_name(signal_name: str) -> int:
    signal_name_parts = signal_name.split("_")
    for part in signal_name_parts:
        if "stove" in part:
            return int(part.replace("stove", ""))
    raise ValueError(f"Invalid signal_name: {signal_name}")


def get_waste_gas_aso_pi_point_name(furnace_id: int, stove_number: int) -> str:
    result = [
        pi_point_name
        for pi_point_name in WASTE_GAS_ASO_PI_POINT_NAMES[furnace_id - 1]
        if f"Stove{stove_number}" in pi_point_name
    ]
    if result:
        return result[0]
    raise ValueError(f"Invalid stove_number: {stove_number}")


def get_waste_gas_aso_signal_name(furnace_id: int, stove_number: int) -> str:
    result = [
        signal_name
        for signal_name in get_waste_gas_aso_signal_names(furnace_id)
        if f"stove{stove_number}" in signal_name
    ]
    if result:
        return result[0]
    raise ValueError(f"Invalid stove_number: {stove_number}")


def get_stoves_cog_bfg_air_signal_names(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal]
        for signal in get_stoves_input_gases_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_waste_gas_aso_signal_names(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_waste_gas_aso_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_natural_gas_signal_name(furnace_id: int) -> str:
    return PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[get_natural_gas_pi_point_name(furnace_id)][0]


def calc_topgas_n2_chem_pct_from_topgas_data(topgas_data: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    topgas_data[f"bf{furnace_id}_topgasn2_chem_pct"] = 100 - topgas_data.sum(axis=1)
    return topgas_data


def get_topgas_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    # Pandas function `interpolate` cannot fill in missing values ​​at the beginning of the dataset,
    # and if the missing values ​​are at the end of the dataset, it fills in the last known value.
    # Therefore, we need to adjust the start and end dates to obtain all the data we need.
    # 1 hour is just arbitrary ensuring that we always get all the information about topgas data.
    start_updated = start - pd.Timedelta(hours=1)
    end_updated = end + pd.Timedelta(hours=1)
    topgas_data = load_topgas(start_updated, end_updated, furnace_id, datasources.pi)
    topgas_data_preprocessed = get_regular_time_series_data(topgas_data)
    topgas_data_resampled = (
        topgas_data_preprocessed.resample("1min", label="right", closed="right").mean().loc[start:end]
    )

    return calc_topgas_n2_chem_pct_from_topgas_data(topgas_data_resampled, furnace_id)


def get_cog_data(start: pd.Timestamp, end: pd.Timestamp, datasources: DataSources) -> pd.DataFrame:
    # We only have measurements available circa once every 8 hours,
    # so we consider that the given measurement is valid until the next measurement.
    # COG data without C5_C8, C4, C3 - that is 0.417% from whole chemical composition of COG.
    # Therefore, we need to add the remaining chemical elements proportionally to 100.
    start_updated = start - pd.Timedelta(days=1)
    return (
        datasources.pvis.get_cog_chem_composition(start_updated, end)
        .pipe(localize_date_columns_and_convert_to_utc)
        .set_index("last_update")
        .resample("1min", label="right", closed="right")
        .mean()
        .reindex(pd.date_range(start=start_updated, end=end, freq="1min"))
        .pipe(lambda df: df.div(df.sum(axis=1), axis=0) * 100)
        .ffill()
        .loc[start:]
        .rename_axis("Timestamp")
    )


def get_stove_cog_signal_name(furnace_id: int, stove_number: int) -> str:
    return f"bf{furnace_id}_stove{stove_number}_cog_flow_m3h"


def get_cog_chem_composition_signal_names(furnace_id: int, stove_number: int) -> list[str]:
    return [f"bf{furnace_id}_stove{stove_number}_cog_{chem}_flow_m3h" for chem in STOVE_COG_CHEMS]


def get_appropriate_cog_column_name(cog_chem_signal_name: str, furnace_id: int, stove_number: int) -> str:
    prefix = f"bf{furnace_id}_stove{stove_number}_cog_"
    suffix = "_flow_m3h"

    if cog_chem_signal_name.startswith(prefix) and cog_chem_signal_name.endswith(suffix):
        return cog_chem_signal_name[len(prefix) : -len(suffix)] + "_pct"
    raise ValueError(f"Invalid cog_chem_signal_name: {cog_chem_signal_name}")


def get_cog_molar_pct_from_mass_pct(mass_pct_df: pd.DataFrame) -> pd.DataFrame:
    molar_pct_lst = []
    for row in mass_pct_df.values:
        molar_pct_lst.append(get_molar_pct_from_mass_pct(STOVE_COG_CHEMS, row))

    return pd.DataFrame(index=mass_pct_df.index, data=molar_pct_lst, columns=mass_pct_df.columns)


def calculate_stove_cog_chem_composition(
    cog_data: pd.DataFrame, stove_data: pd.DataFrame, furnace_id: int, stove_number: int
) -> pd.DataFrame:
    cog_molar = get_cog_molar_pct_from_mass_pct(cog_data)
    stove_cog_signal_name = get_stove_cog_signal_name(furnace_id, stove_number)
    cog_chem_signal_names = get_cog_chem_composition_signal_names(furnace_id, stove_number)

    cog_and_stove_data = pd.concat([cog_molar, stove_data], axis=1).dropna()

    for cog_chem_signal_name in cog_chem_signal_names:
        cog_column_name = get_appropriate_cog_column_name(cog_chem_signal_name, furnace_id, stove_number)
        cog_and_stove_data[cog_chem_signal_name] = cog_and_stove_data[stove_cog_signal_name] * (
            cog_and_stove_data[cog_column_name]
        )

    return cog_and_stove_data[cog_chem_signal_names]


def get_bfg_properties_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    # Pandas function `interpolate` cannot fill in missing values ​​at the beginning of the dataset,
    # and if the missing values ​​are at the end of the dataset, it fills in the last known value.
    # Therefore, we need to adjust the start and end dates to obtain all the data we need.
    # 2 hours is just arbitrary ensuring that we always get all the information about BFG properties data.
    start_updated = start - pd.Timedelta(hours=2)
    end_updated = end + pd.Timedelta(hours=2)
    pi_point_names = get_bfg_properties_pi_point_names(furnace_id)
    signal_names = ["bfg_temperature", "bfg_pressure"]

    dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(datasources.pi, pi_point_name, start_updated, end_updated, signal_name)
        if not df.empty:
            df = get_regular_time_series_data(df, threshold="300min")
            df = df.resample("1min", label="right", closed="right").mean()
        dfs.append(df)

    return pd.concat(dfs, axis=1)


def get_stove_bfg_signal_name(furnace_id: int, stove_number: int) -> str:
    return f"bf{furnace_id}_stove{stove_number}_bfg_flow_m3h"


def get_bfg_chem_composition_signal_names(furnace_id: int, stove_number: int) -> list[str]:
    return [f"bf{furnace_id}_stove{stove_number}_bfg_{chem}_flow_m3h" for chem in STOVE_BFG_CHEMS]


def get_appropriate_topgas_signal_name(bfg_chem_signal_name: str, furnace_id: int, stove_number: int) -> str:
    prefix = f"bf{furnace_id}_stove{stove_number}_bfg_"
    suffix = "_flow_m3h"

    if bfg_chem_signal_name.startswith(prefix) and bfg_chem_signal_name.endswith(suffix):
        return f"bf{furnace_id}_topgas" + bfg_chem_signal_name[len(prefix) : -len(suffix)] + "_chem_pct"
    raise ValueError(f"Invalid bfg_chem_signal_name: {bfg_chem_signal_name}")


def calculate_saturation_vapour_pressure(temperature: float) -> float:
    """
    This function calculates a saturation vapour pressure that is important to further calculation of absolute humidity.

    It is an empirical formula invented by Buck - Buck's equation. There are several similar equations to calculate
    saturation vapour pressure, but this one seemed to be the most robust one.

    Reference:
        https://en.wikipedia.org/wiki/Vapour_pressure_of_water#Approximation_formulas
        https://en.wikipedia.org/wiki/Arden_Buck_equation#Formula

    Args:
        temperature (float): Ambient temperature [°C]

    Returns:
        float: Value of a saturation vapour pressure [kPa]
    """

    if temperature > 0:
        return 0.61121 * math.e ** ((18.678 - temperature / 234.5) * temperature / (257.14 + temperature))
    else:
        return 0.61115 * math.e ** ((23.036 - temperature / 333.7) * temperature / (279.82 + temperature))


def calculate_actual_vapour_pressure(relative_humidity: float, saturation_vapour_pressure: float) -> float:
    """
    Calculates partial pressure of water vapour in air.

    In a scientific notion, the relative humidity of an air-water mixture is defined as the ratio of the partial
    pressure of water vapour in air to the saturation vapour pressure of water at the same temperature:
        φ = p / ps

    Args:
        relative_humidity (float): Value of a relative humidity expressed as a decimal fraction
        saturation_vapour_pressure (float): Value of a saturation vapour pressure [kPa]

    Returns:
        float: Value of the partial vapour pressure [kPa]
    """

    return relative_humidity * saturation_vapour_pressure


def calculate_bfg_humidity_pct(temperature: float, pressure: float) -> float:
    relative_humidity = 1  # [pct point]
    normal_air_pressure = 101.325  # [kPa]

    es = calculate_saturation_vapour_pressure(temperature)
    p = calculate_actual_vapour_pressure(relative_humidity, es)

    return p / (pressure + normal_air_pressure)


def get_bfg_humidity_pct(bfg_properties_data: pd.DataFrame) -> pd.DataFrame:
    col_name = "bfg_humidity_pct"
    calc_bfg_humidity_vectorized = np.vectorize(calculate_bfg_humidity_pct)
    bfg_humidity_pct = calc_bfg_humidity_vectorized(
        bfg_properties_data.bfg_temperature, bfg_properties_data.bfg_pressure
    )

    return pd.DataFrame(index=bfg_properties_data.index, data=bfg_humidity_pct, columns=[col_name])


def get_bfg_molar_pct_from_mass_pct(mass_pct_df: pd.DataFrame) -> pd.DataFrame:
    dry_bfg_chems = STOVE_BFG_CHEMS[:-1]
    molar_pct_lst = []
    for row in mass_pct_df.values:
        molar_pct_lst.append(get_molar_pct_from_mass_pct(dry_bfg_chems, row))

    return pd.DataFrame(index=mass_pct_df.index, data=molar_pct_lst, columns=mass_pct_df.columns)


def get_bfg_chem_pct(
    topgas_data: pd.DataFrame,
    bfg_properties_data: pd.DataFrame,
    bfg_chem_signal_names: Sequence[str],
    furnace_id: int,
    stove_number: int,
) -> pd.DataFrame:
    topgas_molar = get_bfg_molar_pct_from_mass_pct(topgas_data)
    bfg_humidity_pct = get_bfg_humidity_pct(bfg_properties_data)
    df = pd.DataFrame()

    for bfg_chem_signal_name in bfg_chem_signal_names[:-1]:
        topgas_signal_name = get_appropriate_topgas_signal_name(
            bfg_chem_signal_name, furnace_id, stove_number
        )

        df[bfg_chem_signal_name] = (topgas_molar[topgas_signal_name]) * (
            1 - bfg_humidity_pct.bfg_humidity_pct
        )

    df[bfg_chem_signal_names[-1]] = bfg_humidity_pct.bfg_humidity_pct

    return df


def calculate_stove_bfg_chem_composition(
    topgas_data: pd.DataFrame,
    stove_data: pd.DataFrame,
    bfg_properties_data: pd.DataFrame,
    furnace_id: int,
    stove_number: int,
) -> pd.DataFrame:
    stove_bfg_signal_name = get_stove_bfg_signal_name(furnace_id, stove_number)
    bfg_chem_signal_names = get_bfg_chem_composition_signal_names(furnace_id, stove_number)
    bfg_chem_pct = get_bfg_chem_pct(
        topgas_data, bfg_properties_data, bfg_chem_signal_names, furnace_id, stove_number
    )

    df = pd.DataFrame()
    for bfg_chem_signal_name in bfg_chem_signal_names:
        df[bfg_chem_signal_name] = stove_data[stove_bfg_signal_name] * bfg_chem_pct[bfg_chem_signal_name]

    return df


def get_air_properties_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    # Pandas function `interpolate` cannot fill in missing values ​​at the beginning of the dataset,
    # and if the missing values ​​are at the end of the dataset, it fills in the last known value.
    # Therefore, we need to adjust the start and end dates to obtain all the data we need.
    # 1 hour is just arbitrary ensuring that we always get all the information about topgas data.
    start_updated = start - pd.Timedelta(hours=1)
    end_updated = end + pd.Timedelta(hours=1)
    pi_point_names = get_air_properties_pi_point_names(furnace_id)
    signal_names = ["air_relative_humidity", "air_temperature"]

    dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        df = get_pi_data_as_dataframe(datasources.pi, pi_point_name, start_updated, end_updated, signal_name)
        if not df.empty:
            df = df[~df.index.duplicated()]
            df = get_regular_time_series_data(df)
            df = df.resample("1min", label="right", closed="right").mean()
            if signal_name == "air_relative_humidity":
                df = df / 100
        dfs.append(df)

    return pd.concat(dfs, axis=1)


def get_stove_air_signal_name(furnace_id: int, stove_number: int) -> str:
    return f"bf{furnace_id}_stove{stove_number}_air_flow_m3h"


def get_air_chem_composition_signal_names(furnace_id: int, stove_number: int) -> list[str]:
    return [f"bf{furnace_id}_stove{stove_number}_air_{chem}_flow_m3h" for chem in STOVE_AIR_CHEMS]


def calculate_air_humidity_pct(relative_humidity: float, temperature: float) -> float:
    normal_air_pressure = 101.325  # [kPa]

    es = calculate_saturation_vapour_pressure(temperature)
    p = calculate_actual_vapour_pressure(relative_humidity, es)

    return p / normal_air_pressure


def get_air_humidity_pct(air_properties_data: pd.DataFrame) -> pd.DataFrame:
    col_name = "air_humidity_pct"
    calc_air_humidity_vectorized = np.vectorize(calculate_air_humidity_pct)
    air_humidity_pct = calc_air_humidity_vectorized(
        air_properties_data.air_relative_humidity, air_properties_data.air_temperature
    )

    return pd.DataFrame(index=air_properties_data.index, data=air_humidity_pct, columns=[col_name])


def get_air_chem_pct(
    air_chem_signal_name: str, air_properties_data: pd.DataFrame, furnace_id: int, stove_number: int
) -> pd.Series:
    air_humidity_pct = get_air_humidity_pct(air_properties_data)

    if air_chem_signal_name == f"bf{furnace_id}_stove{stove_number}_air_o2_flow_m3h":
        return 0.21 * (1 - air_humidity_pct.air_humidity_pct)
    elif air_chem_signal_name == f"bf{furnace_id}_stove{stove_number}_air_n2_flow_m3h":
        return 0.79 * (1 - air_humidity_pct.air_humidity_pct)
    elif air_chem_signal_name == f"bf{furnace_id}_stove{stove_number}_air_h2o_flow_m3h":
        return air_humidity_pct.air_humidity_pct
    raise ValueError(f"Invalid air_chem_signal_name: {air_chem_signal_name}")


def calculate_stove_air_chem_composition(
    stove_data: pd.DataFrame, air_properties_data: pd.DataFrame, furnace_id: int, stove_number: int
) -> pd.DataFrame:
    stove_air_signal_name = get_stove_air_signal_name(furnace_id, stove_number)
    air_chem_signal_names = get_air_chem_composition_signal_names(furnace_id, stove_number)

    for air_chem_signal_name in air_chem_signal_names:
        air_chem_pct = get_air_chem_pct(air_chem_signal_name, air_properties_data, furnace_id, stove_number)
        stove_data[air_chem_signal_name] = stove_data[stove_air_signal_name] * air_chem_pct

    return stove_data[air_chem_signal_names]


def clean_stove_data(stove_data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
    # There are some duplicate indexes in the stove_data dataframe
    # and also some negative values, which doesn't make sense.
    stove_data.index = stove_data.index.floor("s")
    stove_data_cleaned = stove_data[~stove_data.index.duplicated(keep="first")].copy()
    stove_data_cleaned.loc[stove_data_cleaned[signal_name] < 0, signal_name] = 0
    return stove_data_cleaned


def fill_missing_values_in_stove_data(stove_data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
    # Based on the data analysis, we found that the time between two heatings lasts 50 minutes or more.
    # Based on this threshold, it is necessary to fill in the missing values ​​to zero in these cases.
    # The remaining missing values ​​are filled in by linear interpolation.
    valid_times = stove_data[signal_name].dropna().index
    time_diffs = valid_times.to_series().diff().dt.total_seconds() / 60

    large_gap_indices = np.where(time_diffs >= 50)[0]
    gap_starts = valid_times[large_gap_indices - 1] if len(large_gap_indices) > 0 else []
    gap_ends = valid_times[large_gap_indices] if len(large_gap_indices) > 0 else []

    for start, end in zip(gap_starts, gap_ends):
        stove_data.loc[(stove_data.index > start) & (stove_data.index < end), signal_name] = 0

    stove_data[signal_name] = stove_data[signal_name].interpolate(method="linear")
    return stove_data


def get_chem_composition_columns_by_signal_name(
    signal_name: str, furnace_id: int, stove_number: int
) -> list[str]:
    if "cog" in signal_name:
        return get_cog_chem_composition_signal_names(furnace_id, stove_number)
    if "bfg" in signal_name:
        return get_bfg_chem_composition_signal_names(furnace_id, stove_number)
    if "air" in signal_name:
        return get_air_chem_composition_signal_names(furnace_id, stove_number)
    raise ValueError(f"Invalid signal_name: {signal_name}")


def preprocess_stove_data(raw_stove_data: pd.DataFrame, signal_name: str) -> pd.DataFrame:
    raw_stove_data.loc[raw_stove_data[signal_name] < 0, signal_name] = 0
    stove_regular_data = get_regular_time_series_data(df=raw_stove_data, threshold="50min")
    stove_data_filled = fill_missing_values_in_stove_data(stove_regular_data, signal_name)
    # Airflow sensors also measure very low airflow values ​​in the non-heating phase, so it is necessary
    # to replace these values ​​with zero in order to clearly define which phase the stove is in.
    # For this purpose, an airflow threshold of 550 m3/h was set.
    if "air_flow" in signal_name:
        stove_data_filled.loc[stove_data_filled[signal_name] < 550, signal_name] = 0
    return stove_data_filled


def calculate_stove_chem_composition_by_signal_name(
    signal_name: str,
    cog_data: pd.DataFrame,
    topgas_data: pd.DataFrame,
    stove_data: pd.DataFrame,
    air_properties_data: pd.DataFrame,
    bfg_properties_data: pd.DataFrame,
    furnace_id: int,
) -> pd.DataFrame:
    stove_number = get_stove_number_from_signal_name(signal_name)
    if "cog" in signal_name:
        return calculate_stove_cog_chem_composition(cog_data, stove_data, furnace_id, stove_number)
    if "bfg" in signal_name:
        return calculate_stove_bfg_chem_composition(
            topgas_data, stove_data, bfg_properties_data, furnace_id, stove_number
        )
    if "air" in signal_name:
        return calculate_stove_air_chem_composition(stove_data, air_properties_data, furnace_id, stove_number)
    raise ValueError(f"Invalid signal_name: {signal_name}")


def get_ng_chem_composition_signal_names(furnace_id: int, stove_number: int) -> list[str]:
    return [
        f"bf{furnace_id}_stove{stove_number}_ng_{chem}_flow_m3h" for chem in SPP_NATURAL_GAS_CHEM_COMPOSITION
    ]


def get_stoves_input_gases_signal_group(furnace_id: int) -> list[str]:
    return (
        [
            signal
            for stove_number in STOVE_NUMBERS
            for signal in (
                get_cog_chem_composition_signal_names(furnace_id, stove_number)
                + get_bfg_chem_composition_signal_names(furnace_id, stove_number)
                + get_air_chem_composition_signal_names(furnace_id, stove_number)
                + get_ng_chem_composition_signal_names(furnace_id, stove_number)
            )
        ]
        # aso signals
        + get_waste_gas_aso_signal_names(furnace_id)
        # temperature signals
        + get_stoves_temp_signal_group(furnace_id)
        + ["bf1_stove_ng_temp_C"]
    )


def get_stoves_natural_gas_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    start_updated = start - pd.Timedelta(hours=10)
    end_updated = end + pd.Timedelta(hours=10)
    pi_point_name = get_natural_gas_pi_point_name(furnace_id)
    signal_name = get_natural_gas_signal_name(furnace_id)
    stoves_natural_gas_df = get_pi_data_as_dataframe(
        datasources.pi, pi_point_name, start_updated, end_updated, signal_name
    )
    if not stoves_natural_gas_df.empty:
        stoves_natural_gas_preprocessed_df = get_regular_time_series_data(stoves_natural_gas_df)
        stoves_natural_gas_resampled_df = stoves_natural_gas_preprocessed_df.resample(
            "1min", closed="right", label="right"
        ).mean()
        return stoves_natural_gas_resampled_df.loc[start:end]
    else:
        return pd.DataFrame(
            0, index=pd.date_range(start=start, end=end, freq="T", name="Timestamp"), columns=[signal_name]
        )


def get_total_bfg_per_stove_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_stove{stove_number}_bfg_flow_m3h" for stove_number in STOVE_NUMBERS]


def get_total_bfg_signal_name(furnace_id: int) -> str:
    return f"bf{furnace_id}_total_bfg_flow_m3h"


def get_total_ng_per_stove_signal_names(furnace_id: int) -> list[str]:
    return [f"bf{furnace_id}_stove{stove_number}_ng_flow_m3h" for stove_number in STOVE_NUMBERS]


def calculate_bfg_flow_per_stove_and_total_bfg_flow(
    stoves_data: pd.DataFrame, furnace_id: int
) -> pd.DataFrame:
    stoves_bfg_cols = get_total_bfg_per_stove_signal_names(furnace_id)
    for stove_bfg_col in stoves_bfg_cols:
        stove_number = get_stove_number_from_signal_name(stove_bfg_col)
        stoves_data[stove_bfg_col] = stoves_data.filter(like=f"bf{furnace_id}_stove{stove_number}_bfg").sum(
            axis=1
        )

    stoves_data[get_total_bfg_signal_name(furnace_id)] = stoves_data[stoves_bfg_cols].sum(axis=1)
    return stoves_data


def calculate_ng_flow_per_stove_based_on_bfg_flow(stoves_data: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    total_ng_col = get_natural_gas_signal_name(furnace_id)
    stoves_bfg_cols = get_total_bfg_per_stove_signal_names(furnace_id)
    stoves_ng_cols = get_total_ng_per_stove_signal_names(furnace_id)

    for stove_bfg_col, stove_ng_col in zip(stoves_bfg_cols, stoves_ng_cols):
        # Distribute NG proportionally based on BFG flow and fill NaN values (in case total BFG flow is 0)
        stoves_data[stove_ng_col] = (
            (stoves_data[stove_bfg_col] / stoves_data[get_total_bfg_signal_name(furnace_id)])
            * stoves_data[total_ng_col]
        ).fillna(0)

    return stoves_data


def calculate_stove_natural_gas_chem_composition(stoves_data: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    stoves_data_with_total_bfg_flow = calculate_bfg_flow_per_stove_and_total_bfg_flow(stoves_data, furnace_id)
    stoves_data_with_ng_flow = calculate_ng_flow_per_stove_based_on_bfg_flow(
        stoves_data_with_total_bfg_flow, furnace_id
    )
    stoves_ng_cols = get_total_ng_per_stove_signal_names(furnace_id)

    new_columns = {}
    for stove_ng_col in stoves_ng_cols:
        for chem, pct in SPP_NATURAL_GAS_CHEM_COMPOSITION.items():
            stove_number = get_stove_number_from_signal_name(stove_ng_col)
            new_col_name = f"bf{furnace_id}_stove{stove_number}_ng_{chem}_flow_m3h"
            new_columns[new_col_name] = stoves_data_with_ng_flow[stove_ng_col] * (pct / 100)

    return pd.concat([stoves_data_with_ng_flow, pd.DataFrame(new_columns)], axis=1)


def create_new_signal_from_existing(
    dfs: list[DataFrame], new_signal_name: str, from_signal_name: str
) -> list[DataFrame]:
    dfs = [
        df.rename(columns={from_signal_name: new_signal_name}) for df in dfs if from_signal_name in df.columns
    ]

    return dfs


def get_waste_gas_aso_data(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    air_signal_name: str,
    air_stove_data: pd.DataFrame,
) -> pd.DataFrame:
    stove_number = get_stove_number_from_signal_name(air_signal_name)
    aso_pi_point_name = get_waste_gas_aso_pi_point_name(furnace_id, stove_number)
    aso_signal_name = get_waste_gas_aso_signal_name(furnace_id, stove_number)

    waste_gas_aso_data = get_pi_data_as_dataframe(
        datasources.pi, aso_pi_point_name, start, end, aso_signal_name
    )

    if not waste_gas_aso_data.empty:
        waste_gas_aso_data = get_regular_time_series_data(waste_gas_aso_data)
        waste_gas_aso_data = waste_gas_aso_data.resample("1min", label="right", closed="right").mean()
        stove_air_and_aso_data = pd.concat([air_stove_data, waste_gas_aso_data], axis=1)
        return stove_air_and_aso_data[stove_air_and_aso_data[air_signal_name] > 0][[aso_signal_name]]
    return pd.DataFrame(
        columns=[aso_signal_name],
        index=pd.date_range(start=start, end=end, freq="1min", name="Timestamp"),
    )


def preprocess_stove_data_based_on_airflow(stoves_data: pd.DataFrame) -> pd.DataFrame:
    # There are measurements from flow sensors (with very low flow values) when the stove is not in
    # the heating phase. There are also cases where such very low values ​​are measured during the entire
    # time when the stove is not in the heating phase. It is necessary to replace these values with zero
    # to clearly define which phase the stove is in.
    # For this purpose, data from the BFG, COG, NG flow sensors were filtered according to airflow data.
    temp_columns = [col for col in stoves_data.columns if "temp_C" in col]
    preprocessed_stove_data = []
    for stove_number in STOVE_NUMBERS:
        stove_data = stoves_data.filter(like=f"stove{stove_number}")
        air_flow_columns = [col for col in stove_data.columns if "air" in col]
        airflow_zero_mask = (stove_data[air_flow_columns] == 0).any(axis=1)
        non_wastegas_columns = [col for col in stove_data.columns if "wastegas_aso" not in col]
        stove_data.loc[airflow_zero_mask, non_wastegas_columns] = 0
        preprocessed_stove_data.append(stove_data)

    preprocessed_stove_data.append(stoves_data[temp_columns])

    return pd.concat(preprocessed_stove_data, axis=1)


def load_stoves_input_gases(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    cog_data = get_cog_data(start, end, datasources)
    topgas_data = get_topgas_data(start, end, furnace_id, datasources)
    air_properties = get_air_properties_data(start, end, furnace_id, datasources)
    bfg_properties = get_bfg_properties_data(start, end, furnace_id, datasources)

    pi_point_names = get_stoves_input_gases_pi_point_names(furnace_id)
    signal_names = get_stoves_cog_bfg_air_signal_names(furnace_id)

    dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        # We need to adjust the start and end dates to obtain all the data we need.
        # 5 hours is just arbitrary ensuring that we always get all the information about stove data.
        start_updated = start - pd.Timedelta(hours=5)
        end_updated = end + pd.Timedelta(hours=5)
        stove_data = get_pi_data_as_dataframe(
            datasources.pi, pi_point_name, start_updated, end_updated, signal_name
        )
        if stove_data.empty:
            return pd.DataFrame()
        stove_data_preprocessed = preprocess_stove_data(stove_data, signal_name)
        stove_data_resampled_1min = stove_data_preprocessed.resample(
            "1min", label="right", closed="right"
        ).mean()

        if "air_flow" in signal_name:
            waste_gas_aso_data = get_waste_gas_aso_data(
                start, end, furnace_id, datasources, signal_name, stove_data_resampled_1min
            )
            dfs.append(waste_gas_aso_data)
        stove_data_chem_composition = calculate_stove_chem_composition_by_signal_name(
            signal_name,
            cog_data,
            topgas_data,
            stove_data_resampled_1min,
            air_properties,
            bfg_properties,
            furnace_id,
        ).loc[start:end]

        dfs.append(stove_data_chem_composition)

    pi_point_names_temp = get_stoves_temp_pi_point_names(furnace_id)
    signal_names_temp = get_stoves_temp_signal_group(furnace_id)
    start_updated_temp = start - pd.Timedelta(hours=1)
    end_updated_temp = end + pd.Timedelta(hours=1)
    for pi_point_name, signal_name in zip(pi_point_names_temp, signal_names_temp):
        df = get_pi_data_as_dataframe(
            datasources.pi, pi_point_name, start_updated_temp, end_updated_temp, signal_name
        )
        if not df.empty:
            df = df[~df.index.duplicated()]
            df = get_regular_time_series_data(df)
            df = df.resample("1min", label="right", closed="right").mean().loc[start:end]
        dfs.append(df)

    dfs_new_col = create_new_signal_from_existing(dfs, "bf1_stove_ng_temp_C", "bf1_stove_bfg_temp_C")
    dfs.extend(dfs_new_col)
    dfs.append(get_stoves_natural_gas_data(start, end, furnace_id, datasources))
    stoves_data = pd.concat(dfs, axis=1)

    stoves_data_with_ng_chem_composition = calculate_stove_natural_gas_chem_composition(
        stoves_data, furnace_id
    )
    df = stoves_data_with_ng_chem_composition[get_stoves_input_gases_signal_group(furnace_id)].loc[start:end]

    return preprocess_stove_data_based_on_airflow(df)
