import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc


def rename_cols_and_set_index(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.rename(
            columns=lambda col: (
                "Timestamp" if col in ["pc_analysis_date", "pc_ash_monthly_analysis_date"] else f"pc_{col}"
            )
        )
        .set_index("Timestamp")
        .sort_index()
    )


def bfill_missing_pc_heat_values(df: pd.DataFrame) -> pd.DataFrame:
    # Pulverized coal heat value data are available from 1.3.2024 17:23 (UTC).
    if df.index[0] < pd.Timestamp(2023, 3, 1, 17, 23, tz="UTC"):
        first_known_idx = df["pc_heat_value_MJkg"].first_valid_index()
        non_na_heat_values_mask = df.index >= first_known_idx
        df.loc[non_na_heat_values_mask, "pc_heat_value_MJkg"] = df.loc[
            non_na_heat_values_mask, "pc_heat_value_MJkg"
        ].bfill()
    else:
        df["pc_heat_value_MJkg"] = df["pc_heat_value_MJkg"].bfill()

    return df


def preprocess_pulverized_coal_data(
    pc_analysis: pd.DataFrame, pc_ash_monthly_analysis: pd.DataFrame
) -> pd.DataFrame:

    pc_analysis_processed_df = rename_cols_and_set_index(pc_analysis)

    # Original datetime values are datetime values when the data was added into the DB.
    # Therefore, it is necessary to move these datetime values back one day,
    # so that we know the datetime on which the given data are valid.
    pc_analysis_processed_df.index = pc_analysis_processed_df.index.map(lambda x: x - pd.Timedelta(hours=24))

    pc_ash_monthly_analysis_processed_df = rename_cols_and_set_index(pc_ash_monthly_analysis)

    # If we do not have the latest data for the last month, the data for the last month is duplicated
    # with the month before last. Therefore, in this case, it must be removed.
    if pc_ash_monthly_analysis_processed_df.iloc[-1].equals(pc_ash_monthly_analysis_processed_df.iloc[-2]):
        redundant_values_in_monthly_report = True
        timestamp_of_redundant_values = pc_ash_monthly_analysis_processed_df.index[-1]
        pc_ash_monthly_analysis_processed_df = pc_ash_monthly_analysis_processed_df.drop(
            pc_ash_monthly_analysis_processed_df.index[-1]
        )
    else:
        redundant_values_in_monthly_report = False

    df_merged = pd.concat([pc_analysis_processed_df, pc_ash_monthly_analysis_processed_df], axis=1)

    columns_to_bfill = ["pc_h2o_pct", "pc_h2o_an_pct", "pc_ash_pct", "pc_volatile_matter_pct", "pc_s_pct"]
    columns_to_ffill = [
        "pc_fe2o3_ash_pct",
        "pc_sio2_ash_pct",
        "pc_cao_ash_pct",
        "pc_mgo_ash_pct",
        "pc_al2o3_ash_pct",
        "pc_mn_ash_pct",
        "pc_p_ash_pct",
        "pc_nao_ash_pct",
        "pc_k2o_ash_pct",
        "pc_tio2_ash_pct",
        "pc_pb_ash_pct",
        "pc_zn_ash_pct",
        "pc_cu_ash_pct",
    ]

    df_merged = bfill_missing_pc_heat_values(df_merged)
    df_merged[columns_to_bfill] = df_merged[columns_to_bfill].bfill()

    # If the data from the monthly report are duplicated (i.e. we do not have current data for the last month),
    # we can only fill the missing values ​​for the previous month, no more.
    if redundant_values_in_monthly_report:
        df_merged.loc[df_merged.index < timestamp_of_redundant_values, columns_to_ffill] = df_merged.loc[
            df_merged.index < timestamp_of_redundant_values, columns_to_ffill
        ].ffill()
    else:
        df_merged[columns_to_ffill] = df_merged[columns_to_ffill].ffill()

    return df_merged


def load_pulverized_coal(start: pd.Timestamp, end: pd.Timestamp, datasources: DataSources) -> pd.DataFrame:
    """Returns fetched data"""
    pzvp_hook = datasources.pzvp
    pc_analysis = pzvp_hook.get_pulverized_coal_analysis(start, end)
    pc_ash_monthly_analysis = pzvp_hook.get_pulverized_coal_ash_monthly_analysis(start, end)
    processed_df = preprocess_pulverized_coal_data(
        localize_date_columns_and_convert_to_utc(pc_analysis),
        localize_date_columns_and_convert_to_utc(pc_ash_monthly_analysis),
    )

    return processed_df
