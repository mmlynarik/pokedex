import logging
from typing import Optional

import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.signals.utils import generate_ids, get_signal_names_with_furnace_id
from dbfcore.settings import ANALYSIS_PROCESSING_DURATION, AVG_TAPPING_DURATION, TZ_LOCAL, TZ_UTC

logger = logging.getLogger(__name__)

TAPPINGS_COLUMNS_FROM_DATASET = [
    "pig_iron_analysis_date",
    "hotmetalas_chem_pct",
    "hotmetalc_chem_pct",
    "hotmetalfe_chem_pct",
    "hotmetalmn_chem_pct",
    "hotmetalp_chem_pct",
    "hotmetalpb_chem_pct",
    "hotmetals_chem_pct",
    "hotmetalsi_chem_pct",
    "hotmetalti_chem_pct",
    "hotmetalzn_chem_pct",
]


def merge_tapping_start_slag_end_dfs(
    start_df: pd.DataFrame, slag_df: pd.DataFrame, end_df: pd.DataFrame
) -> pd.DataFrame:
    tapping_phases = ["starts", "slags", "ends"]
    tapping_dts = [start_df, slag_df, end_df]

    taps = [
        df.reset_index(names=phase)
        # following drops duplicated timestamps and keep one of them
        .drop_duplicates(subset=phase)
        # following drops all occurencies of duplicated tapping numbers
        # cases when tapping numbers are duplicated, but timestamps are different
        .pipe(generate_ids, "tapping_number", phase, "tapping_id", True)
        .drop_duplicates(subset="tapping_id", keep=False)
        .set_index("tapping_id")
        for df, phase in zip(tapping_dts, tapping_phases)
    ]

    return pd.concat(taps, axis=1).sort_values(by="starts", ascending=True, na_position="first")


def calculate_fe_pct(analysis_df: pd.DataFrame) -> pd.DataFrame:
    cols = (col for col in analysis_df.columns if "pct" in col)

    return analysis_df.assign(fe_pct=lambda df: 100 - df[cols].sum(axis=1))


def assign_tapping_ids(analysis_df: pd.DataFrame) -> pd.DataFrame:
    return generate_ids(analysis_df, "tapping_number", "pig_iron_analysis_date", "tapping_id", True)


def calc_est_dt_tapping_start_dt_available(
    tapping_start_dt: pd.Timestamp,
    est_dt: pd.Timestamp,
    prev_est_sample_collection_dts: list[pd.Timestamp],
    tolerance: pd.Timedelta,
) -> pd.Timestamp:
    if not prev_est_sample_collection_dts:
        quarter_duration = AVG_TAPPING_DURATION / 4
        quarter_dt = tapping_start_dt + quarter_duration
        return min(quarter_dt, est_dt)
    else:
        return (
            est_dt
            if est_dt > prev_est_sample_collection_dts[-1]
            else prev_est_sample_collection_dts[-1] + tolerance
        )


def calc_est_dt_tapping_and_slag_start_dt_available(
    slag_start_dt: pd.Timestamp,
    est_dt: pd.Timestamp,
    prev_est_sample_collection_dts: list[pd.Timestamp],
    tolerance: pd.Timedelta,
) -> pd.Timestamp:
    if not prev_est_sample_collection_dts:
        return min(est_dt, slag_start_dt)
    elif len(prev_est_sample_collection_dts) == 1:
        return est_dt if est_dt > slag_start_dt else slag_start_dt + tolerance
    else:
        return (
            est_dt
            if est_dt > prev_est_sample_collection_dts[-1]
            else prev_est_sample_collection_dts[-1] + tolerance
        )


def calc_est_dt_all_dts_available(
    tapping_start_dt: pd.Timestamp,
    slag_start_dt: pd.Timestamp,
    tapping_end_dt: pd.Timestamp,
    est_dt: pd.Timestamp,
    prev_est_sample_collection_dts: list[pd.Timestamp],
    tolerance: pd.Timedelta,
) -> pd.Timestamp:
    if not prev_est_sample_collection_dts:
        quarter_duration = (tapping_end_dt - tapping_start_dt) / 4
        quarter_dt = tapping_start_dt + quarter_duration
        return min(quarter_dt, slag_start_dt)
    elif len(prev_est_sample_collection_dts) == 1:
        return est_dt if est_dt < tapping_end_dt and est_dt > slag_start_dt else slag_start_dt + tolerance
    else:
        return (
            est_dt
            if est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]
            else tapping_end_dt - tolerance
        )


def calc_est_dt_slag_start_dt_not_available(
    tapping_start_dt: pd.Timestamp,
    tapping_end_dt: pd.Timestamp,
    est_dt: pd.Timestamp,
    prev_est_sample_collection_dts: list[pd.Timestamp],
    tolerance: pd.Timedelta,
) -> pd.Timestamp:
    if not prev_est_sample_collection_dts:
        quarter_duration = (tapping_end_dt - tapping_start_dt) / 4
        quarter_dt = tapping_start_dt + quarter_duration
        return quarter_dt
    elif len(prev_est_sample_collection_dts) == 1:
        return (
            est_dt
            if est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]
            else prev_est_sample_collection_dts[-1] + tolerance
        )
    else:
        return (
            est_dt
            if est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]
            else tapping_end_dt - tolerance
        )


def get_estimated_sample_collection_dt(
    pig_iron_analysis_date: pd.Timestamp,
    tapping_start_dt: pd.Timestamp,
    slag_start_dt: Optional[pd.Timestamp],
    tapping_end_dt: Optional[pd.Timestamp],
    prev_est_sample_collection_dts: list[pd.Timestamp],
) -> pd.Timestamp:
    """
    Calculates the estimated sample collection datetime based on various process timestamps.

    The estimated sample collection datetime (`est_dt`) is initially calculated as:
        est_dt = pig_iron_analysis_date - ANALYSIS_PROCESSING_DURATION

    This represents the latest possible time when the sample could have been collected
    before being analyzed. The final estimated timestamp is adjusted based on the
    available timestamp of tapping start, slag start, tapping end and previous estimated
    sample collection timestamps.

    Conditions and Adjustments:
    1. If only `tapping_start_dt` is available (`slag_start_dt` and `tapping_end_dt` are missing):
        - first sample - If no previous samples exist, calculate a quarter of the average tapping duration and add it to `tapping_start_dt`.
            - If this calculated time is earlier than `est_dt`, return it; otherwise, return `est_dt`.
        - more samples (second sample, third sample, fourth sample, ...) - If one or more previous samples exist:
            - If `est_dt` is earlier than last previous sample, return `est_dt`.
            - Otherwise, return last previous sample plus 5 minutes buffer.

    2. If `tapping_start_dt` and `slag_start_dt` are available, but `tapping_end_dt` is missing:
        - first sample - If no previous samples exist, return the earlier of `slag_start_dt` or `est_dt`.
        - second sample - If one previous sample exists:
            - If `est_dt` is earlier than `slag_start_dt`, return `est_dt`.
            - Otherwise, return `slag_start_dt` plus 5 minutes buffer.
        - more samples (third sample, fourth sample, ...) - If more than one previous samples exist:
            - If `est_dt` is later than the last previous sample, return `est_dt`.
            - Otherwise, return the last previous sample plus 5 minutes buffer.

    3. If `tapping_start_dt`, `slag_start_dt`, and `tapping_end_dt` are all available:
        - first sample - If no previous samples exist:
            - Calculate a quarter of the tapping duration (`(tapping_end_dt - tapping_start_dt) / 4`) and add it to `tapping_start_dt`.
            - Return the earlier of this calculated time or `slag_start_dt`.
        - second sample - If one previous sample exists:
            - If `est_dt` is earlier than `tapping_end_dt` and later than `slag_start_dt`, return `est_dt`.
            - Otherwise, return `slag_start_dt` plus 5 minutes buffer.
        - more samples (third sample, fourth sample, ...) - If more than one previous samples exist:
            - If `est_dt` is earlier than `tapping_end_dt` and later than the last previous sample, return `est_dt`.
            - Otherwise, return `tapping_end_dt` minus 5 minutes buffer.

    4. If `tapping_start_dt` and `tapping_end_dt` are available, but `slag_start_dt` is missing:
        - first sample - If no previous samples exist:
            - Return quarter of the tapping duration (`(tapping_end_dt - tapping_start_dt) / 4`) and add it to `tapping_start_dt`.
        - second sample - If one previous sample exists:
            - If `est_dt` is earlier than `tapping_end_dt` and later than last previous sample, return `est_dt`.
            - Otherwise, return the last previous sample plus 5 minutes buffer.
        - more samples (third sample, fourth sample, ...) - If more than one previous samples exist:
            - If `est_dt` is earlier than `tapping_end_dt` and later than the last previous sample, return `est_dt`.
            - Otherwise, return `tapping_end_dt` minus 5 minutes buffer.
    """
    tolerance = pd.Timedelta(minutes=5)  # Arbitrarily chosen time buffer
    est_dt = pig_iron_analysis_date - ANALYSIS_PROCESSING_DURATION

    if pd.notna(tapping_start_dt) and pd.isna(slag_start_dt) and pd.isna(tapping_end_dt):
        return calc_est_dt_tapping_start_dt_available(
            tapping_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )

    elif pd.notna(tapping_start_dt) and pd.notna(slag_start_dt) and pd.isna(tapping_end_dt):
        return calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )

    elif pd.notna(tapping_start_dt) and pd.notna(slag_start_dt) and pd.notna(tapping_end_dt):
        return calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
    # Case, when `tapping_start_dt`, `tapping_end_dt` are available and `slag_start_dt` is missing.
    else:
        return calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )


def get_estimated_sample_collection_dts(tapping_dts: pd.DataFrame, analyses: pd.DataFrame) -> pd.DataFrame:
    dfs = []
    for tapping_id, tapping_row in tapping_dts.iterrows():
        # When tapping_start_dt is NaT, we cannot compute
        # estimated sample collection dates for that tapping_id.
        if pd.isna(tapping_row["starts"]):
            continue

        analyses_for_tapping_id = analyses.query(f"tapping_id=={tapping_id}")

        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        for _, analysis_row in analyses_for_tapping_id.iterrows():
            est_sample_collection_dt = get_estimated_sample_collection_dt(
                pig_iron_analysis_date=analysis_row["pig_iron_analysis_date"],
                tapping_start_dt=tapping_row["starts"],
                slag_start_dt=(
                    tapping_row["slags"]
                    if tapping_row["slags"] <= analysis_row["pig_iron_analysis_date"]
                    else None
                ),
                tapping_end_dt=(
                    tapping_row["ends"]
                    if tapping_row["ends"] <= analysis_row["pig_iron_analysis_date"]
                    else None
                ),
                prev_est_sample_collection_dts=prev_est_sample_collection_dts,
            )
            prev_est_sample_collection_dts.append(est_sample_collection_dt)

            est_sample_collection_dt_df = (
                pd.DataFrame({"est_sample_collection_dt": [est_sample_collection_dt]})
                .set_index("est_sample_collection_dt")
                .rename_axis("Timestamp")
                .assign(
                    **analysis_row.to_dict(),
                )
            )

            dfs.append(est_sample_collection_dt_df)

    return pd.concat(dfs).sort_index()


def get_tappings_signal_group(furnace_id: int) -> list[str]:
    return get_signal_names_with_furnace_id(furnace_id, TAPPINGS_COLUMNS_FROM_DATASET)


def pick_defined_signals(
    estimated_dts: pd.DataFrame, furnace_id: int, signal_name: Optional[str] = None
) -> pd.DataFrame:
    cols = ["pig_iron_analysis_date"] + sorted(col for col in estimated_dts.columns if "pct" in col)
    signal_names = get_tappings_signal_group(furnace_id)

    return estimated_dts.rename(columns=dict(zip(cols, signal_names)))[
        [signal_name] if signal_name else signal_names
    ]


### This function needs to be refactored if we want to use the result of it
### Now we don;t need it - therefore it is commented out
# def get_cacheable_flag_from_tapping_times(tapping_times: pd.DataFrame) -> bool:
#     return not pd.isna(tapping_times.ends.iloc[-1])


def load_hotmetal_chems(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    signal_name: Optional[str] = None,
) -> pd.DataFrame:
    """Returns tappings data"""
    # We need to adjust the start dates because of situations when we get,
    # in a lookback window, tappings with missing start and/or end dates
    # To obtain all the data we need, we adjust the start dates;
    # in this case the number 5 is just arbitrary ensuring taht we always get
    # all the information about start/end tapping dates
    start_updated = start - 5 * AVG_TAPPING_DURATION
    pi_point_name_start = f"SK{furnace_id}.CastingStart"
    pi_point_name_slag = f"SK{furnace_id}.SlagStart"
    pi_point_name_end = f"SK{furnace_id}.EndOfCast"
    colname = "tapping_number"

    tapping_start = get_pi_data_as_dataframe(datasources.pi, pi_point_name_start, start_updated, end, colname)
    slag_start = get_pi_data_as_dataframe(datasources.pi, pi_point_name_slag, start_updated, end, colname)
    tapping_end = get_pi_data_as_dataframe(datasources.pi, pi_point_name_end, start_updated, end, colname)

    if tapping_start.empty or slag_start.empty or tapping_end.empty:
        return pd.DataFrame()

    tapping_datetimes = merge_tapping_start_slag_end_dfs(tapping_start, slag_start, tapping_end)

    vp_hook = datasources.get_vp_hook(calc_time=end, now=pd.Timestamp.utcnow())
    pig_iron_analysis = vp_hook.get_pig_iron_analysis(start_updated, end, furnace_id)
    if pig_iron_analysis.empty:
        return pd.DataFrame()
    analyses = pig_iron_analysis.pipe(calculate_fe_pct).pipe(assign_tapping_ids)
    analyses["pig_iron_analysis_date"] = (
        analyses["pig_iron_analysis_date"].dt.tz_localize(TZ_LOCAL, ambiguous="NaT").dt.tz_convert(TZ_UTC)
    )
    estimated_dts = get_estimated_sample_collection_dts(tapping_datetimes, analyses)

    return estimated_dts.pipe(pick_defined_signals, furnace_id, signal_name).loc[start:]
