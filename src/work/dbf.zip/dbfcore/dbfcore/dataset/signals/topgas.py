from functools import partial
from typing import Callable

import pandas as pd

from dbfcore.dataset.hooks.piclient.piclient import PiClient
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.model.datamodule.preprocessing import get_cleaned_pi_signal_data

TOPGAS_PI_POINT_NAMES = [
    ["SK1.Top.Gas.CO.%", "SK1.Top.Gas.CO2.%", "SK1.Top.Gas.H2.%"],
    ["SK2.Top.Gas.CO.Percent", "SK2.Top.Gas.CO2.Percent", "SK2.Top.Gas.H2.Percent"],
    ["SK3.Top.Gas.CO.Percent", "SK3.Top.Gas.CO2.Percent", "SK3.Top.Gas.H2.Percent"],
]


def get_topgas_pi_point_names(furnace_id: int) -> list[str]:
    return TOPGAS_PI_POINT_NAMES[furnace_id - 1]


def get_topgas_signal_group(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_topgas_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_cleaning_fn_by_pi_point_name(pi_point_name: str) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if pi_point_name == "SK1.Top.Gas.CO.%":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.2,
        )
    elif pi_point_name == "SK1.Top.Gas.CO2.%":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.2,
        )
    elif pi_point_name in ["SK2.Top.Gas.CO2.Percent", "SK3.Top.Gas.CO2.Percent"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("10m"),
            extreme_grad_threshold=0.005,
        )
    elif pi_point_name == "SK1.Top.Gas.H2.%":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.03,
        )
    elif pi_point_name in ["SK2.Top.Gas.H2.Percent", "SK3.Top.Gas.H2.Percent"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("15m"),
            recalibration_duration=pd.Timedelta("30m"),
            extreme_grad_threshold=0.005,
        )
    else:
        return lambda x: x


def load_topgas(start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, pi_client: PiClient) -> pd.DataFrame:
    pi_point_names = get_topgas_pi_point_names(furnace_id)
    signal_names = get_topgas_signal_group(furnace_id)

    topgas_dfs = []
    for pi_point_name, signal_name in zip(pi_point_names, signal_names):
        cleaning_fn = get_cleaning_fn_by_pi_point_name(pi_point_name)
        raw_df = get_pi_data_as_dataframe(pi_client, pi_point_name, start, end, signal_name)
        cleaned_data = cleaning_fn(raw_df)
        df = cleaned_data.dropna().sort_index()
        df = df[~df.index.duplicated()].sort_index()
        topgas_dfs.append(df)

    return pd.concat(topgas_dfs, axis=1)
