import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.utils import get_template_df_columns
from dbfcore.dataset.signals.utils import generate_ids
from dbfcore.settings import NUMBER_OF_SLAG_POT_COLUMNS, SLAG_POT_COLUMN_NAME


class SlagDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.slag_weights = raw_dfs.slag_weights
        self.slag_analysis = raw_dfs.slag_analysis

    def _pivot_slag_weights(self) -> pd.DataFrame:
        df = (
            self.slag_weights.pipe(generate_ids, "tapping_number", "slag_start_date", "tapping_id", True)
            .assign(
                weight_num=lambda df: df.slag_pot_order.astype(str),
            )
            .drop(columns=["slag_start_date", "tapping_number", "slag_pot_order"])
            .drop_duplicates(subset=["tapping_id", "weight_num"])
            .pivot(index=["tapping_id"], columns="weight_num")
        )
        df.columns = df.columns.map("_".join)
        template_df_columns = get_template_df_columns([SLAG_POT_COLUMN_NAME], NUMBER_OF_SLAG_POT_COLUMNS)

        return df.reset_index().reindex(["tapping_id"] + template_df_columns, axis=1)

    def _process_slag_analysis(self) -> pd.DataFrame:
        return (
            self.slag_analysis.pipe(generate_ids, "tapping_number", "slag_analysis_date", "tapping_id", True)
            .drop(columns=["slag_analysis_date", "tapping_number"])
            .rename(columns=lambda col: f"slag_{col}" if col != "tapping_id" else col)
        )

    def process_slag_data(self) -> pd.DataFrame:
        pivoted_slag_weights = self._pivot_slag_weights()
        processed_slag_analysis = self._process_slag_analysis()

        return pivoted_slag_weights.merge(processed_slag_analysis, on="tapping_id").astype(
            {"tapping_id": float}
        )
