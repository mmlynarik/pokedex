import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames


def _merge_sensors_qpu_analysis(sensors_data: pd.DataFrame, qpu_analysis: pd.DataFrame) -> pd.DataFrame:
    return (
        pd.merge_asof(
            sensors_data,
            qpu_analysis,
            left_on="sensors_date",
            right_on="qpu_analysis_date",
            direction="backward",
        )
        # we have QPU analysis data only from the end of 2019
        # therefore we need the following condition to return DF with proper columns
        # in case "2018", when the QPU analysis DF is empty
        if not qpu_analysis.empty
        else sensors_data.reindex(
            columns=sensors_data.columns.tolist() + qpu_analysis.columns.tolist()
        ).astype({"qpu_analysis_date": "datetime64[D]"})
    )


class SensorsDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.sensors_section_11 = raw_dfs.sensors_11
        self.sensors_section_21 = raw_dfs.sensors_21
        self.sensors_section_31 = raw_dfs.sensors_31
        self.qpu_analysis = raw_dfs.qpu_analysis

    def process_sensors_data(self) -> pd.DataFrame:
        return (
            self.sensors_section_11.merge(self.sensors_section_21, on="sensors_date")
            .merge(self.sensors_section_31, on="sensors_date")
            .rename(columns=lambda col: str.upper(col) if col != "sensors_date" else col)
            .pipe(_merge_sensors_qpu_analysis, self.qpu_analysis)
        )
