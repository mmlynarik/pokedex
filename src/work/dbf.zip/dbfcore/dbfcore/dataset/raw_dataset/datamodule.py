import pandas as pd
from attrs import define


@define(frozen=True, auto_attribs=True)
class RawDataFrames:
    one_min_date_range: pd.DataFrame
    sensors_21: pd.DataFrame
    sensors_11: pd.DataFrame
    sensors_31: pd.DataFrame
    qpu_analysis: pd.DataFrame
    sinter_analysis: pd.DataFrame
    raw_material_analysis: pd.DataFrame
    raw_material_charge: pd.DataFrame
    raw_material_charge_summary: pd.DataFrame
    tapping_times: pd.DataFrame
    pig_iron_weights: pd.DataFrame
    pig_iron_analysis: pd.DataFrame
    slag_weights: pd.DataFrame
    slag_analysis: pd.DataFrame
    deliveries: pd.DataFrame
    heats: pd.DataFrame
    chems: pd.DataFrame
    all_tappings: pd.DataFrame
    tappings_temperatures: pd.Series
    granulometry: pd.DataFrame
