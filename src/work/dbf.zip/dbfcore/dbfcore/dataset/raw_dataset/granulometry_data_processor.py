import numpy as np
import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.utils import (
    generate_column_names_with_trailing_integer,
    get_template_df_columns,
)
from dbfcore.settings import GRANULOMETRY_AZVP_COLUMN_NAMES, NUMBER_OF_RAW_MATERIAL_COLUMNS

RAW_MATERIAL_GRANULOMETRY_COLUMN_NAMES = [f"raw_material_{col}" for col in GRANULOMETRY_AZVP_COLUMN_NAMES]


class GranulometryDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.date_range = raw_dfs.one_min_date_range
        self.raw_material_charge = raw_dfs.raw_material_charge
        self.granulometry = raw_dfs.granulometry

    def merge_raw_material_and_granulometry(
        self, raw_material_charge: pd.DataFrame, granulometry: pd.DataFrame
    ) -> pd.DataFrame:
        return pd.concat(
            [
                pd.merge_asof(
                    raw_material_charge[raw_material_charge["raw_material_number"] == num],
                    granulometry[granulometry["number_at_granulometry"] == num],
                    left_on="charge_date",
                    right_on="granulometry_date",
                    direction="backward",
                )
                for num in raw_material_charge["raw_material_number"].unique()
            ]
        ).drop_duplicates()

    def transform_charge_and_granulometry_into_ravel(self, df: pd.DataFrame) -> pd.DataFrame:
        return (
            df.groupby(["charge_date", "charge_number"])
            .apply(lambda x: x[[col for col in GRANULOMETRY_AZVP_COLUMN_NAMES]].values.ravel())
            .reset_index()
            .rename(columns={0: "values"})
        )

    def transform_ravel_into_df(self, df: pd.DataFrame) -> pd.DataFrame:
        values_max_len = df["values"].apply(len).max()
        column_list_len = len(
            generate_column_names_with_trailing_integer(RAW_MATERIAL_GRANULOMETRY_COLUMN_NAMES, 0)
        )

        columns = [
            generate_column_names_with_trailing_integer(RAW_MATERIAL_GRANULOMETRY_COLUMN_NAMES, num)
            for num in range(1, (values_max_len + column_list_len) // column_list_len)
        ]

        return pd.DataFrame(df["values"].to_list(), columns=np.concatenate(columns))

    def process_granulometry_data(self) -> pd.DataFrame:
        charge_granulometry = self.merge_raw_material_and_granulometry(
            self.raw_material_charge, self.granulometry
        )
        ravel = charge_granulometry.pipe(self.transform_charge_and_granulometry_into_ravel)
        left = ravel.loc[:, ["charge_date", "charge_number"]]
        right = ravel.pipe(self.transform_ravel_into_df)
        merged = pd.concat([left, right], axis=1)
        template_df_columns = get_template_df_columns(
            RAW_MATERIAL_GRANULOMETRY_COLUMN_NAMES, NUMBER_OF_RAW_MATERIAL_COLUMNS
        )
        reindexed = merged.reindex(["charge_date", "charge_number"] + template_df_columns, axis=1)

        raw_material_dates = [
            f"raw_material_granulometry_date_{idx}" for idx in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
        ]
        reindexed[raw_material_dates] = reindexed[raw_material_dates].apply(pd.to_datetime, utc=True)

        return pd.merge_asof(
            self.date_range,
            reindexed,
            left_on="date",
            right_on="charge_date",
            direction="forward",
            tolerance=pd.Timedelta("59s"),
        ).drop(columns=["charge_date", "charge_number"])
