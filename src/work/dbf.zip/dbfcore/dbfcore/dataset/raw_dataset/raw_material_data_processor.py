from typing import Callable, Collection

import numpy as np
import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.utils import (
    generate_column_names_with_trailing_integer,
    get_template_df_columns,
)
from dbfcore.settings import (
    CARBONATES,
    COKE_1_OR_3,
    COKES,
    NUMBER_OF_RAW_MATERIAL_COLUMNS,
    RAW_MATERIAL_MINERALS,
)


def get_raw_material_data_column_names(minerals: list[str] = RAW_MATERIAL_MINERALS) -> list[str]:
    return [
        "raw_material_number",
        "raw_material_weight",
        "raw_material_analysis_date",
        *[f"raw_material_{mineral}_pct" for mineral in minerals],
    ]


def get_raw_material_mineral_pcts_columns(cols: list[str] = RAW_MATERIAL_MINERALS) -> list[str]:
    return [f"{m}_pct" for m in cols]


def get_mineral_pct_multiplication_fn(mineral: str) -> Callable:
    def multiply_mineral_pct_by_multiplier(df: pd.DataFrame) -> pd.DataFrame:
        return df[f"{mineral}_pct"] * df["multiplier"]

    return multiply_mineral_pct_by_multiplier


def get_recalculated_c_pct_column() -> Callable:
    return lambda df: np.where(
        df["raw_material_number"].isin(COKES),
        100 - df[get_raw_material_mineral_pcts_columns()].sum(axis=1),
        df["c_pct"],
    )


def get_h2o_orig_pct_column() -> Callable:
    return lambda df: df["h2o_pct"]


def get_h2o_measured_pct_column() -> Callable:
    return lambda df: np.where(
        df["raw_material_number"].isin(COKE_1_OR_3), df["moisture_pct"], df["h2o_orig_pct"]
    )


def get_zero_h2o_for_coke_column() -> Callable:
    return lambda df: np.where(df["raw_material_number"].isin(COKES), 0, df["h2o_pct"])


def get_multiplied_mineral_pct_columns(
    minerals: list[str] = RAW_MATERIAL_MINERALS, exclude: list[str] | None = None
) -> dict[str, Callable]:
    exclude = exclude or []
    return {f"{m}_pct": get_mineral_pct_multiplication_fn(m) for m in minerals if m not in exclude}


def get_multiplier_to_unity_sum_column() -> Callable:
    return lambda df: 100 / df[[f"{m}_pct" for m in RAW_MATERIAL_MINERALS]].sum(axis=1)


def get_multiplier_to_dry_state_column() -> Callable:
    return lambda df: 100 / (df[[f"{m}_pct" for m in RAW_MATERIAL_MINERALS]].sum(axis=1) - df["h2o_pct"])


def get_multiplier_to_real_state_column() -> Callable:
    return lambda df: (100 - df["h2o_pct"]) / 100


def get_carbonates_for_selected_raw_materials(raw_material_analysis: pd.DataFrame) -> pd.DataFrame:
    return raw_material_analysis.fillna(0).assign(
        caco3_pct=lambda df: np.where(df["raw_material_number"].isin(CARBONATES), df["cao_pct"] * 1.7848, 0),
        cao_pct=lambda df: np.where(df["raw_material_number"].isin(CARBONATES), 0, df["cao_pct"]),
        mgco3_pct=lambda df: np.where(df["raw_material_number"].isin(CARBONATES), df["mgo_pct"] * 2.0920, 0),
        mgo_pct=lambda df: np.where(df["raw_material_number"].isin(CARBONATES), 0, df["mgo_pct"]),
        c_pct=lambda df: np.where(df["raw_material_number"].isin(CARBONATES), 0, df["c_pct"]),
    )


def get_dry_state_raw_material_analysis(raw_material_analysis: pd.DataFrame) -> pd.DataFrame:
    return (
        raw_material_analysis.fillna(0)
        .assign(h2o_orig_pct=get_h2o_orig_pct_column())
        .assign(h2o_pct=get_zero_h2o_for_coke_column())
        .assign(c_pct=get_recalculated_c_pct_column())
        .assign(multiplier=get_multiplier_to_unity_sum_column())
        .assign(**get_multiplied_mineral_pct_columns())
        .assign(multiplier=get_multiplier_to_dry_state_column())
        .assign(**get_multiplied_mineral_pct_columns())
    )


def get_dry_state_sinter_analysis(sinter_analysis: pd.DataFrame) -> pd.DataFrame:
    return (
        sinter_analysis.rename(columns={"sinter_analysis_date": "raw_material_analysis_date"})
        .fillna(0)
        .assign(raw_material_number=1)
        .assign(h2o_orig_pct=get_h2o_orig_pct_column())
        .assign(multiplier=get_multiplier_to_unity_sum_column())
        .assign(**get_multiplied_mineral_pct_columns())
        .assign(multiplier=get_multiplier_to_dry_state_column())
        .assign(**get_multiplied_mineral_pct_columns())
    )


def get_dry_state_analyses(
    raw_material_analysis: pd.DataFrame, sinter_analysis: pd.DataFrame
) -> pd.DataFrame:
    dry_raw_material_analysis = get_dry_state_raw_material_analysis(raw_material_analysis)
    dry_sinter_analysis = get_dry_state_sinter_analysis(sinter_analysis)
    return pd.concat([dry_raw_material_analysis, dry_sinter_analysis])


def join_prev_analysis_to_charged_raw_material(
    raw_material_charge: pd.DataFrame, dry_state_analyses: pd.DataFrame
) -> pd.DataFrame:
    return (
        pd.concat(
            [
                pd.merge_asof(
                    raw_material_charge[raw_material_charge["raw_material_number"] == num],
                    dry_state_analyses[dry_state_analyses["raw_material_number"] == num],
                    left_on="charge_date",
                    right_on="raw_material_analysis_date",
                    direction="backward",
                )
                for num in raw_material_charge["raw_material_number"].unique()
            ]
        )
        .drop(columns="raw_material_number_y")
        .rename(columns={"raw_material_number_x": "raw_material_number"})
        .sort_values(["charge_date", "raw_material_number"])
    )


def join_charge_summary_to_charges_and_analyses(
    charges_and_analyses: pd.DataFrame, raw_material_charge_summary: pd.DataFrame
):
    return charges_and_analyses.merge(raw_material_charge_summary, on="charge_date", how="inner")


def transform_raw_material_weight_and_analysis_into_ravel(
    df: pd.DataFrame, minerals: list[str]
) -> pd.DataFrame:
    return (
        df.groupby(["charge_date", "charge_number"])
        .apply(
            lambda x: x[
                [
                    "raw_material_number",
                    "raw_material_weight",
                    "raw_material_analysis_date",
                ]
                + get_raw_material_mineral_pcts_columns(minerals)
            ].values.ravel(),
            include_groups=False,  # to avoid deprecation warning in tests,
        )
        .reset_index()
        .rename(columns={0: "values_list"})
    )


def transform_ravel_into_df(df: pd.DataFrame, minerals: list[str] = RAW_MATERIAL_MINERALS) -> pd.DataFrame:
    values_list_max_len = df["values_list"].str.len().max()
    raw_material_column_names = get_raw_material_data_column_names(minerals)
    column_list_len = len(generate_column_names_with_trailing_integer(raw_material_column_names, 0))

    columns = [
        generate_column_names_with_trailing_integer(raw_material_column_names, num)
        for num in range(1, (values_list_max_len + column_list_len) // column_list_len)
    ]

    return pd.DataFrame(df["values_list"].to_list(), columns=np.concatenate(columns))


def transform_charge_data_to_wide_format(full_charge_info: pd.DataFrame, minerals: list[str]):
    temp = transform_raw_material_weight_and_analysis_into_ravel(full_charge_info, minerals)
    df_left = temp[["charge_date", "charge_number"]]
    df_right = transform_ravel_into_df(temp, minerals)
    return pd.concat([df_left, df_right], axis=1)


def transform_dry_state_into_measured_wet_state(relevant_charge_data: pd.DataFrame) -> pd.DataFrame:
    return relevant_charge_data.assign(
        h2o_pct=get_h2o_measured_pct_column(),
        multiplier=get_multiplier_to_real_state_column(),
        **get_multiplied_mineral_pct_columns(exclude=["h2o"]),
    )


def get_relevant_charge_data_in_wide_format(
    raw_material_charge: pd.DataFrame,
    raw_material_analysis: pd.DataFrame,
    sinter_analysis: pd.DataFrame,
    charge_summary: pd.DataFrame,
    minerals: list[str] = RAW_MATERIAL_MINERALS,
) -> pd.DataFrame:
    raw_material_analysis = get_carbonates_for_selected_raw_materials(raw_material_analysis)
    dry_state_analyses = get_dry_state_analyses(raw_material_analysis, sinter_analysis)
    charges_and_analyses = join_prev_analysis_to_charged_raw_material(raw_material_charge, dry_state_analyses)
    relevant_charge_data = join_charge_summary_to_charges_and_analyses(charges_and_analyses, charge_summary)
    relevant_charge_data = transform_dry_state_into_measured_wet_state(relevant_charge_data)
    charge_data_in_wide_format = transform_charge_data_to_wide_format(relevant_charge_data, minerals)
    return charge_data_in_wide_format


def reindex_raw_material_weights_to_fixed_size_dataframe(
    weights: pd.DataFrame, minerals: list[str] = RAW_MATERIAL_MINERALS
) -> pd.DataFrame:
    raw_material_column_names = raw_material_column_names = get_raw_material_data_column_names(minerals)
    template_df_columns = get_template_df_columns(raw_material_column_names, NUMBER_OF_RAW_MATERIAL_COLUMNS)
    df_reindexed = weights.reindex(["charge_date", "charge_number"] + template_df_columns, axis=1)
    raw_material_dates = [
        f"raw_material_analysis_date_{idx}" for idx in range(1, NUMBER_OF_RAW_MATERIAL_COLUMNS + 1)
    ]
    df_reindexed[raw_material_dates] = df_reindexed[raw_material_dates].apply(pd.to_datetime, utc=True)
    return df_reindexed


def exclude_sinter_from_raw_material_numbers(numbers: Collection[int]) -> set[int]:
    return set(numbers).difference([1])


class RawMaterialDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.date_range = raw_dfs.one_min_date_range
        self.raw_material_charge = raw_dfs.raw_material_charge
        self.raw_material_analysis = raw_dfs.raw_material_analysis
        self.sinter_analysis = raw_dfs.sinter_analysis
        self.charge_summary = raw_dfs.raw_material_charge_summary
        self.minerals = RAW_MATERIAL_MINERALS

    def process_raw_material_data(self) -> pd.DataFrame:
        weights = get_relevant_charge_data_in_wide_format(
            self.raw_material_charge,
            self.raw_material_analysis,
            self.sinter_analysis,
            self.charge_summary,
            self.minerals,
        )
        reindexed_weights = reindex_raw_material_weights_to_fixed_size_dataframe(weights, self.minerals)
        reindexed_weights_with_one_min_date_range = pd.merge_asof(
            self.date_range,
            reindexed_weights,
            left_on="date",
            right_on="charge_date",
            direction="forward",
            tolerance=pd.Timedelta("59s"),
        )
        return reindexed_weights_with_one_min_date_range
