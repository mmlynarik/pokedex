from datetime import date

import pandas as pd


class DateRangeGenerator:
    def __init__(self, start_date: date, end_date: date, freq: str):
        self.start_date = start_date
        self.end_date = end_date
        self.freq = freq

    def generate_date_range(self) -> pd.DataFrame:
        return pd.DataFrame(
            pd.date_range(self.start_date, self.end_date, freq=self.freq, tz="UTC", name="date")
        )
