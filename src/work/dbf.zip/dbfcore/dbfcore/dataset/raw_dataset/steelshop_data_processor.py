from collections import defaultdict

import numpy as np
import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    BASE_STEELSHOP_DATA_COLUMNS,
    STEELSHOP_DATA_COLUMNS,
)
from dbfcore.settings import (
    ELIGIBLE_CHEM_PRECISIONS,
    MAX_DELIVERIES_PER_TAPPING,
    MAX_HEATS_PER_DELIVERY,
    STEELSHOP_ANALYSIS_CHEMS,
)

MAX_DELIVERIES_RANGE = range(1, MAX_DELIVERIES_PER_TAPPING + 1)
BRIDGE_TABLE_COLUMNM_NAMES = [
    "tapping_id",
    "tapping_start_date",
    "tapping_end_date",
    "furnace_id",
    "delivery_id",
    "mixer_id",
    "heat_id",
]
BRIDGE_TABLE_SORTING_COLUMNM_NAMES = ["tapping_id", "delivery_id", "heat_id"]


def get_bridge_df_sample(bridge_df: pd.DataFrame) -> pd.DataFrame:
    tappings = [120972021, 120982021, 121072021, 121082021, 121092021]
    return bridge_df[bridge_df["tapping_id"].isin(tappings)].sort_values("tapping_id")


def summarize_tappings(bridge_df: pd.DataFrame) -> pd.DataFrame:
    deliveries = bridge_df.groupby("tapping_id")["delivery_id"].apply(set).rename("deliveries")
    heats = bridge_df.groupby("tapping_id")["heat_id"].apply(set).rename("heats")
    mixers = bridge_df.groupby("tapping_id")["mixer_id"].apply(set).rename("mixers")

    return (
        pd.DataFrame(deliveries)
        .merge(heats, how="inner", left_index=True, right_index=True)
        .merge(mixers, how="inner", left_index=True, right_index=True)
    )


def left_join_on_indices(left_df: pd.DataFrame, right_df: pd.DataFrame) -> pd.DataFrame:
    return left_df.merge(right_df, how="left", left_index=True, right_index=True)


def check_eligible_heats_for_delivery(delivery_id: int, eligible_heats: set) -> bool:
    """Check if for given delivery there exists a set of eligible heats or delivery_id is nan."""
    return (isinstance(delivery_id, int) and isinstance(eligible_heats, set)) or (
        np.isnan(delivery_id) and np.isnan(eligible_heats)
    )


def get_eligible_chems_precision_verdict_for_one_tapping(row):
    number_of_eligible_chems = sum(
        all(row[f"delivery_{i}_eligible_chem_{chem}_verdict"] for i in MAX_DELIVERIES_RANGE)
        for chem in STEELSHOP_ANALYSIS_CHEMS
    )
    if number_of_eligible_chems == len(STEELSHOP_ANALYSIS_CHEMS):
        return "best"
    elif number_of_eligible_chems >= len(STEELSHOP_ANALYSIS_CHEMS) / 2:
        return "medium"
    else:
        return "worst"


def generate_tappings_heats_bridge_table(
    tappings: pd.DataFrame,
    deliveries: pd.DataFrame,
    heats: pd.DataFrame,
    chems: pd.DataFrame,
    max_deliveries_per_tapping: int,
    furnace_id: int,
) -> pd.DataFrame:
    bridge = get_tappings_heats_bridge_table_base(tappings, deliveries, heats)
    bridge = add_heat_mixers_count_for_bridge_table(bridge)
    bridge = add_delivery_tappings_count_for_bridge_table(bridge)
    bridge = filter_outlier_deliveries_per_tapping(bridge, max_deliveries_per_tapping)
    bridge = filter_selected_furnace(bridge, furnace_id)
    bridge = add_heat_chems_for_bridge_table(bridge, chems)
    return bridge


def get_tappings_heats_bridge_table_base(
    tappings: pd.DataFrame, deliveries: pd.DataFrame, heats: pd.DataFrame
) -> pd.DataFrame:
    merged_1 = tappings.merge(deliveries, how="inner", left_on="tapping_id", right_on="tapping_id_1")
    merged_2 = tappings.merge(deliveries, how="inner", left_on="tapping_id", right_on="tapping_id_2")
    merged = pd.concat([merged_1, merged_2])

    bridge_1 = merged.merge(heats, how="inner", left_on="delivery_id", right_on="delivery_id_1")
    bridge_2 = merged.merge(heats, how="inner", left_on="delivery_id", right_on="delivery_id_2")
    bridge = pd.concat([bridge_1, bridge_2])

    bridge = bridge[BRIDGE_TABLE_COLUMNM_NAMES]
    bridge = bridge.sort_values(BRIDGE_TABLE_SORTING_COLUMNM_NAMES)
    return bridge


def add_heat_mixers_count_for_bridge_table(bridge: pd.DataFrame) -> pd.DataFrame:
    heat_mixers = (
        bridge[["heat_id", "delivery_id"]].groupby("heat_id").agg(heat_mixers=("delivery_id", "nunique"))
    )
    bridge = bridge.set_index("heat_id")
    bridge = bridge.merge(heat_mixers, how="inner", left_index=True, right_index=True).reset_index()
    return bridge


def add_delivery_tappings_count_for_bridge_table(bridge: pd.DataFrame) -> pd.DataFrame:
    delivery_tappings = (
        bridge[["delivery_id", "tapping_id"]]
        .groupby("delivery_id")
        .agg(delivery_tappings=("tapping_id", "nunique"))
    )
    bridge = (
        bridge.set_index("delivery_id")
        .merge(delivery_tappings, how="inner", left_index=True, right_index=True)
        .reset_index()
    )
    return bridge


def get_tapping_deliveries_heats_summary(bridge: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate
    - how many deliveries in how many cases were produced from single tapping (1..5)
    - how many heats in how many cases were produced from single mixer (1..7)
    For modelling purposes we take max 3 deliveries per tapping and 6 heats per delivery
    """
    deliveries_counts = (
        bridge.groupby("tapping_id")
        .agg(counts=("delivery_id", "nunique"))
        .value_counts()
        .rename("num_deliveries_from_single_tapping")
    )

    heats_counts = (
        bridge.groupby("delivery_id")
        .agg(count=("heat_id", "nunique"))
        .value_counts()
        .sort_index()
        .rename("num_heats_from_single_delivery")
    )
    return pd.concat([deliveries_counts, heats_counts], axis=1).fillna(0).astype(int)


def filter_outlier_deliveries_per_tapping(
    bridge: pd.DataFrame, max_deliveries_per_tapping: int
) -> pd.DataFrame:
    deliveries_from_single_tapping = (
        bridge.groupby("tapping_id").agg(counts=("delivery_id", "nunique")).counts
    )
    filtered_tappings = deliveries_from_single_tapping[
        deliveries_from_single_tapping <= max_deliveries_per_tapping
    ].index.values
    bridge = bridge[bridge["tapping_id"].isin(filtered_tappings)]
    return bridge


def add_heat_chems_for_bridge_table(bridge: pd.DataFrame, chems: pd.DataFrame) -> pd.DataFrame:
    chems_df = chems[["heat_id"] + [f"{chem}_pct" for chem in STEELSHOP_ANALYSIS_CHEMS]]
    bridge = bridge.merge(chems_df, how="left", on="heat_id")
    return bridge


def filter_selected_furnace(bridge: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    bridge = bridge[bridge["furnace_id"] == furnace_id]
    return bridge


class SteelshopDataProcessor:
    def __init__(self, furnace_id: int, raw_dfs: RawDataFrames):
        self.furnace_id = furnace_id
        self.tappings = raw_dfs.all_tappings
        self.deliveries = raw_dfs.deliveries
        self.heats = raw_dfs.heats
        self.chems = raw_dfs.chems
        self.weights = raw_dfs.pig_iron_weights
        self.bridge: pd.DataFrame
        self.tappings_with_steelshop: pd.DataFrame

    def process_steelshop_data(self, max_deliveries_per_tapping: int) -> pd.DataFrame:
        self.bridge = generate_tappings_heats_bridge_table(
            self.tappings,
            self.deliveries,
            self.heats,
            self.chems,
            max_deliveries_per_tapping,
            self.furnace_id,
        )
        self.add_steelshop_data_from_bridge_to_tapping()
        self.add_delivery_weights()
        self.add_eligible_heats_to_tapping()
        self.add_top_dq_tapping_flag()
        self.add_eligible_chems_sets_to_tapping()
        self.add_eligible_chems_precision_verdict_per_delivery_and_chem()
        self.add_eligible_chems_precision_verdict_per_tapping()
        self.add_eligible_chems_avg_per_delivery()
        df = self.add_eligible_chems_wavg()
        return df[list(STEELSHOP_DATA_COLUMNS)]

    def add_steelshop_data_from_bridge_to_tapping(self):
        """Transform bridge table into base tappings-with-steelshop-data table."""
        header_only = pd.DataFrame()
        header_only.index.name = "tapping_id"
        out = []
        for tapping_id in self.bridge["tapping_id"].unique():
            tapping_df = self.bridge[self.bridge["tapping_id"] == tapping_id]
            row_out = pd.DataFrame(index=[tapping_id])
            row_out.index.name = "tapping_id"
            tapping_deliveries = sorted(list(set(tapping_df["delivery_id"])))
            for idx, delivery_id in enumerate(tapping_deliveries):
                row_out[f"delivery_{idx + 1}"] = [delivery_id]
                delivery_df = tapping_df[tapping_df["delivery_id"] == delivery_id]
                delivery_heats = sorted(list(set(delivery_df["heat_id"])))
                # row_out["date"] = delivery_df["date"].min().date()
                for _, row in delivery_df.iterrows():
                    heat_idx = delivery_heats.index(row["heat_id"])
                    row_out[f"delivery_{idx + 1}_heat_{heat_idx + 1}"] = row["heat_id"]
                    row_out[f"delivery_{idx + 1}_tappings"] = row["delivery_tappings"]
                    row_out[f"delivery_{idx + 1}_heat_{heat_idx + 1}_mixers"] = row["heat_mixers"]
                    for chem in STEELSHOP_ANALYSIS_CHEMS:
                        row_out[f"delivery_{idx + 1}_heat_{heat_idx + 1}_chems_{chem}"] = row[f"{chem}_pct"]

            out.append(row_out)
        output: pd.DataFrame = pd.concat(out) if out else header_only
        self.tappings_with_steelshop = output.reindex(BASE_STEELSHOP_DATA_COLUMNS, axis=1)

    def add_eligible_heats_to_tapping(self):
        """
        Eligible heat means:
        1. heat is single-delivery
        2. heat's delivery is single-tapping
        3. heat's chem exists
        4. heat's delivery weight exists
        """
        eligible_heats: list[dict] = [defaultdict(set) for _ in range(MAX_DELIVERIES_PER_TAPPING)]
        for idx, row in self.tappings_with_steelshop.iterrows():
            for i in MAX_DELIVERIES_RANGE:
                for j in range(1, MAX_HEATS_PER_DELIVERY + 1):
                    if (
                        row[f"delivery_{i}_tappings"] == 1
                        and row[f"delivery_{i}_heat_{j}_mixers"] == 1
                        and not np.isnan(row[f"delivery_{i}_heat_{j}_chems_c"])
                        and not np.isnan(row[f"delivery_{i}_weight"])
                    ):
                        eligible_heats[i - 1][idx].add(f"delivery_{i}_heat_{j}")

        eligible_heats_df = pd.DataFrame(eligible_heats).T
        eligible_heats_df.columns = [f"delivery_{i}_eligible_heats" for i in MAX_DELIVERIES_RANGE]
        self.tappings_with_steelshop = left_join_on_indices(self.tappings_with_steelshop, eligible_heats_df)

    def add_eligible_chems_sets_to_tapping(self):
        """Add eligible chems sets calculated from eligible heats."""
        for chem in STEELSHOP_ANALYSIS_CHEMS:
            delivery_chems: list[dict] = [defaultdict(set) for _ in range(MAX_DELIVERIES_PER_TAPPING)]
            for idx, row in self.tappings_with_steelshop.iterrows():
                for i in MAX_DELIVERIES_RANGE:
                    if isinstance(row[f"delivery_{i}_eligible_heats"], set):
                        for item in row[f"delivery_{i}_eligible_heats"]:
                            col = f"{item}_chems_{chem}"
                            delivery_chems[i - 1][idx].add(row[col])

            delvry_chems_df = pd.DataFrame(delivery_chems).T
            delvry_chems_df.columns = [f"delivery_{i}_eligible_chem_{chem}" for i in MAX_DELIVERIES_RANGE]
            self.tappings_with_steelshop = left_join_on_indices(self.tappings_with_steelshop, delvry_chems_df)

    def add_top_dq_tapping_flag(self):
        """
        Top-data-quality tapping means at least one eligible heat exists for each delivery of given tapping
        Eligible heat is defined in `add_eligible_heats_to_tapping` method.
        """
        tapping_top_dq = {}
        for idx, row in self.tappings_with_steelshop.iterrows():
            tapping_top_dq[idx] = (
                True
                if all(
                    check_eligible_heats_for_delivery(
                        row[f"delivery_{i}"], row[f"delivery_{i}_eligible_heats"]
                    )
                    for i in MAX_DELIVERIES_RANGE
                )
                else False
            )

        tapping_top_dq = pd.Series(tapping_top_dq, name="tapping_top_data_quality")
        self.tappings_with_steelshop = left_join_on_indices(self.tappings_with_steelshop, tapping_top_dq)

    def add_eligible_chems_precision_verdict_per_delivery_and_chem(self):
        """Add eligible chems verdict per delivery & chem based on predefined threshold for range (max-min)"""
        for i in MAX_DELIVERIES_RANGE:
            for chem in STEELSHOP_ANALYSIS_CHEMS:
                self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}_range"] = (
                    self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}"].apply(
                        lambda x: max(x) - min(x) if isinstance(x, set) else np.nan
                    )
                )
                self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}_precision"] = (
                    ELIGIBLE_CHEM_PRECISIONS[chem]
                )
                self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}_verdict"] = (
                    self.tappings_with_steelshop.apply(
                        lambda row: row[f"delivery_{i}_eligible_chem_{chem}_range"]
                        <= row[f"delivery_{i}_eligible_chem_{chem}_precision"]
                        or np.isnan(row[f"delivery_{i}_eligible_chem_{chem}_range"]),
                        axis=1,
                    )
                )

    def add_eligible_chems_precision_verdict_per_tapping(self):
        self.tappings_with_steelshop["eligible_chems_verdict"] = self.tappings_with_steelshop.apply(
            get_eligible_chems_precision_verdict_for_one_tapping, axis=1
        )

    def add_eligible_chems_avg_per_delivery(self):
        for i in MAX_DELIVERIES_RANGE:
            for chem in STEELSHOP_ANALYSIS_CHEMS:
                self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}_avg"] = (
                    self.tappings_with_steelshop[f"delivery_{i}_eligible_chem_{chem}"].apply(
                        lambda x: np.nanmean(list(x)) if isinstance(x, set) else np.nan
                    )
                )

    def add_delivery_weights(self):
        delivery_weights = self.weights.groupby("delivery_id")["pig_iron_weight"].sum()
        for i in MAX_DELIVERIES_RANGE:
            self.tappings_with_steelshop[f"delivery_{i}_weight"] = self.tappings_with_steelshop.merge(
                delivery_weights, how="left", left_on=f"delivery_{i}", right_index=True
            )["pig_iron_weight"]
        self.tappings_with_steelshop

    def add_eligible_chems_wavg(self) -> pd.DataFrame:
        for chem in STEELSHOP_ANALYSIS_CHEMS:
            self.tappings_with_steelshop[f"eligible_chem_{chem}_wavg"] = self.tappings_with_steelshop.apply(
                lambda row: (
                    (
                        np.nansum(
                            [
                                row[f"delivery_{i}_eligible_chem_{chem}_avg"] * row[f"delivery_{i}_weight"]
                                for i in MAX_DELIVERIES_RANGE
                            ]
                        )
                        / np.nansum([row[f"delivery_{i}_weight"] for i in MAX_DELIVERIES_RANGE])
                    )
                    if np.nansum([row[f"delivery_{i}_weight"] for i in MAX_DELIVERIES_RANGE])
                    else np.nan
                ),
                axis=1,
            )

        return self.tappings_with_steelshop
