import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.utils import get_template_df_columns
from dbfcore.dataset.signals.utils import generate_ids
from dbfcore.settings import (
    NUMBER_OF_PIG_IRON_ANALYSIS_COLUMNS,
    NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS,
    PIG_IRON_ANALYSIS_COLUMN_NAMES,
    PIG_IRON_WEIGHT_COLUMN_NAME,
)


def pivot_pig_iron_analysis(df: pd.DataFrame) -> pd.DataFrame:
    df = (
        df.pipe(generate_ids, "tapping_number", "pig_iron_analysis_date", "tapping_id", True)
        .assign(
            sample_num=lambda df: df.pig_iron_sample_number.astype(str),
        )
        .drop(columns=["pig_iron_analysis_date", "tapping_number", "pig_iron_sample_number"])
        .drop_duplicates(subset=["tapping_id", "sample_num"], keep="last")
        .rename(
            columns={
                "as_pct": "pig_iron_as_pct",
                "c_pct": "pig_iron_c_pct",
                "mn_pct": "pig_iron_mn_pct",
                "p_pct": "pig_iron_p_pct",
                "pb_pct": "pig_iron_pb_pct",
                "s_pct": "pig_iron_s_pct",
                "si_pct": "pig_iron_si_pct",
                "ti_pct": "pig_iron_ti_pct",
                "zn_pct": "pig_iron_zn_pct",
            }
        )
        .pivot(index=["tapping_id"], columns="sample_num")
    )
    df.columns = df.columns.map("_".join)

    template_df_columns = get_template_df_columns(
        PIG_IRON_ANALYSIS_COLUMN_NAMES, NUMBER_OF_PIG_IRON_ANALYSIS_COLUMNS
    )

    return df.reset_index().reindex(["tapping_id"] + template_df_columns, axis=1)


class PigIronDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.date_range = raw_dfs.one_min_date_range
        self.tapping_times = raw_dfs.tapping_times
        self.pig_iron_weights = raw_dfs.pig_iron_weights
        self.pig_iron_analysis = raw_dfs.pig_iron_analysis

    def _pivot_pig_iron_weights(self) -> pd.DataFrame:
        df = (
            self.pig_iron_weights.pipe(generate_ids, "tapping_number", "pig_iron_date", "tapping_id", True)
            .assign(
                weight_num=lambda df: (df.groupby("tapping_id").cumcount().add(1)).astype(str),
            )
            .drop(columns=["pig_iron_date", "tapping_number"])
            .pivot(index=["tapping_id"], columns="weight_num")
        )
        df.columns = df.columns.map("_".join)

        template_df_columns = get_template_df_columns(
            [PIG_IRON_WEIGHT_COLUMN_NAME], NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS
        )
        return df.reset_index().reindex(["tapping_id"] + template_df_columns, axis=1)

    def process_pig_iron_data(self) -> pd.DataFrame:
        pivoted_weights = self._pivot_pig_iron_weights()
        pivoted_analysis = pivot_pig_iron_analysis(self.pig_iron_analysis)

        df = (
            self.tapping_times.pipe(generate_ids, "tapping_number", "tapping_start_date", "tapping_id", True)
            .merge(pivoted_weights, on="tapping_id", how="left")
            .merge(pivoted_analysis, on="tapping_id", how="left")
            .dropna(subset="tapping_start_date")
        ).astype({"tapping_id": float})

        return pd.merge_asof(
            self.date_range,
            df,
            left_on="date",
            right_on="tapping_start_date",
            direction="forward",
            tolerance=pd.Timedelta("59s"),
        )
