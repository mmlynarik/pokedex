import pandas as pd

from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames


class PIDataProcessor:
    def __init__(self, raw_dfs: RawDataFrames):
        self.temperatures = raw_dfs.tappings_temperatures

    def process_pi_data(self) -> pd.DataFrame:
        return self.temperatures
