import logging
import warnings
from datetime import datetime

import pandas as pd
from attrs import define
from pandas.errors import PerformanceWarning

from dbfcore.dataset.hooks.azvp_hook import AZVPDbDataSelector
from dbfcore.dataset.hooks.oko_hook import OkoDbDataSelector
from dbfcore.dataset.hooks.pi_hook import PIHook
from dbfcore.dataset.hooks.pzvp_hook import PZVPDbDataSelector
from dbfcore.dataset.hooks.scada_hook import ScadaDbDataSelector
from dbfcore.dataset.raw_dataset.datamodule import RawDataFrames
from dbfcore.dataset.raw_dataset.date_range_generator import DateRangeGenerator
from dbfcore.dataset.raw_dataset.granulometry_data_processor import GranulometryDataProcessor
from dbfcore.dataset.raw_dataset.pi_data_processor import PIDataProcessor
from dbfcore.dataset.raw_dataset.pig_iron_data_processor import PigIronDataProcessor
from dbfcore.dataset.raw_dataset.raw_dataset_columns import RAW_DATASET_COLUMNS
from dbfcore.dataset.raw_dataset.raw_material_data_processor import (
    RawMaterialDataProcessor,
    exclude_sinter_from_raw_material_numbers,
)
from dbfcore.dataset.raw_dataset.sensors_data_processor import SensorsDataProcessor
from dbfcore.dataset.raw_dataset.slag_data_processor import SlagDataProcessor
from dbfcore.dataset.raw_dataset.steelshop_data_processor import SteelshopDataProcessor
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.settings import MAX_DELIVERIES_PER_TAPPING

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


@define(frozen=True, auto_attribs=True)
class ProcessedDataFrames:
    sensors_data: pd.DataFrame
    raw_material_data: pd.DataFrame
    pig_iron_data: pd.DataFrame
    slag_data: pd.DataFrame
    steelshop_data: pd.DataFrame
    pi_data: pd.DataFrame
    raw_material_granulometry_data: pd.DataFrame


class RawDatasetGenerator:
    def __init__(
        self,
        azvp_hook: AZVPDbDataSelector,
        pzvp_hook: PZVPDbDataSelector,
        scada_hook: ScadaDbDataSelector,
        oko_hook: OkoDbDataSelector,
        pi_hook: PIHook,
    ):
        self.azvp_hook = azvp_hook
        self.pzvp_hook = pzvp_hook
        self.scada_hook = scada_hook
        self.oko_hook = oko_hook
        self.pi_hook = pi_hook

    def _collect_data(self, start: datetime, end: datetime, blast_furnace_id: int) -> RawDataFrames:
        date_range_generator = DateRangeGenerator(start, end, "1min")
        one_min_date_range = date_range_generator.generate_date_range()
        logging.info(f"Date range data was loaded for period {start} - {end}")

        sensors_21 = self.azvp_hook.get_sensors_for_bf1_5min_section_21(start, end)
        logging.info("Sensors_section_21 data was loaded from the database")
        sensors_21 = localize_date_columns_and_convert_to_utc(sensors_21)
        logging.info("Sensors_section_21 timestamps converted to UTC")

        sensors_11 = self.azvp_hook.get_sensors_for_bf1_5min_section_11(start, end)
        logging.info("Sensors_section_11 data was loaded from the database")
        sensors_11 = localize_date_columns_and_convert_to_utc(sensors_11)
        logging.info("Sensors_section_11 timestamps converted to UTC")

        sensors_31 = self.azvp_hook.get_sensors_for_bf1_5min_section_31(start, end)
        logging.info("Sensors_section_31 data was loaded from the database")
        sensors_31 = localize_date_columns_and_convert_to_utc(sensors_31)
        logging.info("Sensors_section_31 timestamps converted to UTC")

        qpu_analysis = self.azvp_hook.get_qpu_analysis(start, end)
        logging.info("QPU analysis data was loaded from the database")
        qpu_analysis = localize_date_columns_and_convert_to_utc(qpu_analysis)
        logging.info("QPU analysis timestamps converted to UTC")

        sinter_analysis = self.azvp_hook.get_sinter_analysis(start, end)
        logging.info("Sinter analysis data was loaded from the database")
        sinter_analysis = localize_date_columns_and_convert_to_utc(sinter_analysis)
        logging.info("Sinter analysis timestamps converted to UTC")

        # Extended logging of fetched charge dates enabling validation of data extraction logic
        raw_material_charge = self.azvp_hook.get_raw_material_charge(start, end, blast_furnace_id)
        logging.info("Raw material charge data was loaded from database")
        firstloc, lastloc = raw_material_charge["charge_date"].min(), raw_material_charge["charge_date"].max()
        raw_material_charge = localize_date_columns_and_convert_to_utc(raw_material_charge)
        logging.info("Raw material charge timestamps converted to UTC")
        firstutc, lastutc = raw_material_charge["charge_date"].min(), raw_material_charge["charge_date"].max()
        logging.info(f"Raw material charge dates (before conversion): {firstloc}       -> {lastloc}")
        logging.info(f"Raw material charge dates (after  conversion): {firstutc} -> {lastutc}")

        raw_material_charge_summary = self.azvp_hook.get_raw_material_charge_summary(
            start, end, blast_furnace_id
        )
        logging.info("Raw material charge summary data was loaded from database")
        raw_material_charge_summary = localize_date_columns_and_convert_to_utc(raw_material_charge_summary)
        logging.info("Raw material charge summary timestamps converted to UTC")

        raw_mat_numbers = exclude_sinter_from_raw_material_numbers(raw_material_charge["raw_material_number"])
        raw_material_analysis = self.azvp_hook.get_raw_material_analysis(start, end, raw_mat_numbers)
        logging.info("Raw material analysis data was loaded from the database")
        raw_material_analysis = localize_date_columns_and_convert_to_utc(raw_material_analysis)
        logging.info("Raw material analysis timestamps converted to UTC")

        tapping_times = self.azvp_hook.get_tapping_start_end_datetimes(start, end, blast_furnace_id)
        logging.info("Tapping times data was loaded from the database")
        tapping_times = localize_date_columns_and_convert_to_utc(tapping_times)
        logging.info("Tapping times timestamps converted to UTC")

        pig_iron_weights = self.pzvp_hook.get_pig_iron_weights(start, end, blast_furnace_id)
        logging.info("Pig iron weights data was loaded from the database")
        pig_iron_weights = localize_date_columns_and_convert_to_utc(pig_iron_weights)
        logging.info("Pig iron weights timestamps converted to UTC")

        pig_iron_analysis = self.azvp_hook.get_pig_iron_analysis(start, end, blast_furnace_id)
        logging.info("Pig iron analysis data was loaded from the database")
        pig_iron_analysis = localize_date_columns_and_convert_to_utc(pig_iron_analysis)
        logging.info("Pig iron analysis timestamps converted to UTC")

        slag_weights = self.azvp_hook.get_slag_weights(start, end, blast_furnace_id)
        logging.info("Slag weights data was loaded from the database")
        slag_weights = localize_date_columns_and_convert_to_utc(slag_weights)
        logging.info("Slag weights timestamps converted to UTC")

        slag_analysis = self.azvp_hook.get_slag_analysis(start, end, blast_furnace_id)
        logging.info("Slag analysis data was loaded from the database")
        slag_analysis = localize_date_columns_and_convert_to_utc(slag_analysis)
        logging.info("Slag analysis timestamps converted to UTC")

        deliveries = self.scada_hook.get_outgoing_deliveries_from_blast_furnace(start, end)
        logging.info("Deliveries data was loaded from SCADA")
        deliveries = localize_date_columns_and_convert_to_utc(deliveries)
        logging.info("Deliveries timestamps converted to UTC")

        heats = self.scada_hook.get_incoming_deliveries_for_steelshop(start, end)
        logging.info("Heats data was loaded from SCADA")
        heats = localize_date_columns_and_convert_to_utc(heats)
        logging.info("Heats timestamps converted to UTC")

        chems = self.oko_hook.get_steelshop_chems_for_heats(start, end)
        logging.info("Chems data was loaded from OKO")
        chems = localize_date_columns_and_convert_to_utc(chems)
        logging.info("Chems timestamps converted to UTC")

        all_tappings = self.azvp_hook.get_tapping_ids_from_all_furnaces(start, end)
        logging.info("All tappings data was loaded from AZVP")
        all_tappings = localize_date_columns_and_convert_to_utc(all_tappings)
        logging.info("All tappings timestamps converted to UTC")

        tappings_temperatures = self.pi_hook.get_tapping_temperature_from_pi_db(start, end, blast_furnace_id)
        logging.info("Tappings temperatures data was loaded from PI API")
        logging.info("Tappings temperatures timestamps already in UTC")

        granulometry = self.azvp_hook.get_granulometry(start, end, blast_furnace_id)
        logging.info("Granulometry data was loaded from AZVP")
        granulometry = localize_date_columns_and_convert_to_utc(granulometry)
        logging.info("Granulometry timestamps converted to UTC")

        return RawDataFrames(  # type: ignore
            one_min_date_range,
            sensors_21,
            sensors_11,
            sensors_31,
            qpu_analysis,
            sinter_analysis,
            raw_material_analysis,
            raw_material_charge,
            raw_material_charge_summary,
            tapping_times,
            pig_iron_weights,
            pig_iron_analysis,
            slag_weights,
            slag_analysis,
            deliveries,
            heats,
            chems,
            all_tappings,
            tappings_temperatures,
            granulometry,
        )

    def _process_data(self, raw_dfs: RawDataFrames, furnace_id: int) -> ProcessedDataFrames:
        sensors_data_processor = SensorsDataProcessor(raw_dfs)
        raw_material_data_processor = RawMaterialDataProcessor(raw_dfs)
        pig_iron_data_processor = PigIronDataProcessor(raw_dfs)
        slag_data_processor = SlagDataProcessor(raw_dfs)
        steelshop_data_processor = SteelshopDataProcessor(furnace_id, raw_dfs)
        pi_data_processor = PIDataProcessor(raw_dfs)
        granulometry_processor = GranulometryDataProcessor(raw_dfs)

        sensors_data = sensors_data_processor.process_sensors_data()
        logging.info("Sensors data was processed")
        raw_material_data = raw_material_data_processor.process_raw_material_data()
        logging.info("Raw material data was processed")
        pig_iron_data = pig_iron_data_processor.process_pig_iron_data()
        logging.info("Pig iron data was processed")
        slag_data = slag_data_processor.process_slag_data()
        logging.info("Slag data was processed")

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=PerformanceWarning)
            steelshop_data = steelshop_data_processor.process_steelshop_data(MAX_DELIVERIES_PER_TAPPING)
        logging.info("Steelshop data was processed")

        pi_data = pi_data_processor.process_pi_data()
        logging.info("PI API data was processed")

        raw_material_granulometry_data = granulometry_processor.process_granulometry_data()
        logging.info("Granulometry data was processed")

        return ProcessedDataFrames(  # type: ignore
            sensors_data,
            raw_material_data,
            pig_iron_data,
            slag_data,
            steelshop_data,
            pi_data,
            raw_material_granulometry_data,
        )

    def generate_raw_dataset(self, start: datetime, end: datetime, blast_furnace_id: int) -> pd.DataFrame:
        raw_dfs = self._collect_data(start, end, blast_furnace_id)
        processed_dfs = self._process_data(raw_dfs, blast_furnace_id)
        return (
            raw_dfs.one_min_date_range.merge(
                processed_dfs.sensors_data, left_on="date", right_on="sensors_date", how="left"
            )
            .merge(processed_dfs.raw_material_data, on="date", how="left")
            .merge(processed_dfs.pig_iron_data, on="date", how="left")
            .merge(processed_dfs.slag_data, on="tapping_id", how="left")
            .merge(processed_dfs.steelshop_data, on="tapping_id", how="left")
            .merge(processed_dfs.pi_data, on="date", how="left")
            .merge(processed_dfs.raw_material_granulometry_data, on="date", how="left")
            .filter(RAW_DATASET_COLUMNS, axis="columns")
        )
