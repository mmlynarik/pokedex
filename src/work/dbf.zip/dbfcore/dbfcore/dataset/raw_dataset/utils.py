import os
from datetime import datetime
from typing import Iterator

import numpy as np
import pandas as pd
from pytz import timezone

from dbfcore.settings import INVALID_TIMESTAMPS, TZ_LOCAL, TZ_UTC
from dbfcore.utils import is_utc


def change_cwd_for_jupyter():
    cwd = os.getenv("CWD", "")
    if not cwd:
        raise ValueError("Environment variable CWD is not set. Please set it to repository root directory.")
    os.chdir(cwd)


def generate_column_names_with_trailing_integer(cols: list[str], num: int) -> list[str]:
    """
    Takes a list of column names and transform them into column names with a trailing integer (given as an argument)

    Example:
        _generate_column_names_with_trailing_integer(["date", "col"], 5)
        >>> ["date_5", "col_5"]
    """
    return [f"{element}_{num}" for element in cols]


def get_template_df_columns(cols: list[str], num_of_column_groups: int) -> list[str]:
    """Creates template dataframe columns used to get dataframes with predefined columns."""
    columns = [
        generate_column_names_with_trailing_integer(cols, num) for num in range(1, num_of_column_groups + 1)
    ]
    return list(np.concatenate(columns))


def filter_out_invalid_timestamps(df: pd.DataFrame, col: str) -> pd.DataFrame:
    """Returns dataframe without invalid timestamps defined in `INVALID_TIMESTAMPS` dictionary."""
    year = df[col].dt.year.min()
    for year in INVALID_TIMESTAMPS:
        df = df[~df[col].between(*INVALID_TIMESTAMPS[year])].copy()
    return df


def localize_date_columns_and_convert_to_utc(df: pd.DataFrame, dropna: bool = True) -> pd.DataFrame:
    """
    Converts all timestamps of the `date` columns in the defined DataFrame to UTC.

    Implicitly drops all invalid or ambiguous timestamps that cannot be converted to UTC
    or that are marked as `NaT`.
    """

    cols = [col for col in df.columns if "date" in col]

    for col in cols:
        # We need to chceck if DF is empty because sometimes we get empty data from DB (e.g. QPU analysis)
        # and then the following functions end up with error
        if not df.empty:
            df = filter_out_invalid_timestamps(df, col)
            df[col] = df[col].dt.tz_localize("Europe/Bratislava", ambiguous="NaT").dt.tz_convert("UTC")

    return df.dropna(subset=cols) if dropna else df


def utc_to_local(dt: datetime) -> datetime:
    if not is_utc(dt):
        raise ValueError("Input datetime must be in UTC.")
    return dt.astimezone(timezone("Europe/Bratislava"))


def local_naive_to_utc(dt: datetime) -> datetime:
    return TZ_LOCAL.localize(dt).astimezone(TZ_UTC)


def parse_naive_string_as_utc_datetime(dt: str) -> datetime:
    parsed = TZ_UTC.localize(datetime.fromisoformat(dt))
    if parsed.second > 0:
        raise ValueError("Seconds are not supported in start and end datetimes.")
    return parsed


def parse_naive_string_as_utc_timestamp(dt: str) -> pd.Timestamp:
    return pd.Timestamp(parse_naive_string_as_utc_datetime(dt))


def split_into_chunks(lst: list, chunk_size: int = 1000) -> Iterator:
    n = len(lst) // chunk_size + 1
    for i in range(0, n):
        yield lst[i::n]
