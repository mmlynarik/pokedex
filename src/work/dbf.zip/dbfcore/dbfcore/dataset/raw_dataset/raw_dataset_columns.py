from collections import ChainMap

from datasets import Value

from dbfcore.dataset.utils import (
    ValueDict,
    get_bool_with_label,
    get_float32_with_label,
    get_int32_with_label,
    get_sequence_of_floats_with_label,
    get_sequence_of_strings_with_label,
    get_string_with_label,
    get_timestamp_with_label,
)
from dbfcore.settings import (
    GRANULOMETRY_AZVP_COLUMN_NAMES,
    MAX_DELIVERIES_PER_TAPPING,
    MAX_HEATS_PER_DELIVERY,
    NUMBER_OF_PIG_IRON_ANALYSIS_COLUMNS,
    NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS,
    NUMBER_OF_RAW_MATERIAL_COLUMNS,
    NUMBER_OF_SLAG_POT_COLUMNS,
    PIG_IRON_ELEMENTS,
    RAW_MATERIAL_MINERALS,
    SLAG_MINERALS,
    STEELSHOP_ANALYSIS_CHEMS,
)


def get_single_raw_material_columns(idx: int) -> ValueDict:
    return {
        f"raw_material_number_{idx}": get_int32_with_label("Kódové označenie (ID) suroviny"),
        f"raw_material_weight_{idx}": Value(
            dtype="int32",
            id='{"label": "Hmotnosť suroviny", "unit": "kg", "type": "extensive"}',
        ),
        f"raw_material_analysis_date_{idx}": get_timestamp_with_label(
            "Dátum mineralogickej analýzy suroviny"
        ),
        **{
            f"raw_material_{mineral}_pct_{idx}": Value(
                dtype="float32",
                id=f'{{"label": "Podiel {mineral} v surovine", "unit": "%", "type": "intensive"}}',
            )
            for mineral in RAW_MATERIAL_MINERALS
        },
    }


def get_single_granulometry_columns(idx: int) -> ValueDict:
    return {
        f"raw_material_granulometry_date_{idx}": get_timestamp_with_label(
            "Dátum granulometrickej analýzy suroviny"
        ),
        f"raw_material_number_at_granulometry_{idx}": get_int32_with_label("ID suroviny pri granulometrii"),
        **{
            f"raw_material_{col}_{idx}": Value(
                dtype="float32",
                id=f'{{"label": "Frakcia {col} v surovine", "unit": "%", "type": "intensive"}}',
            )
            for col in GRANULOMETRY_AZVP_COLUMN_NAMES[2:-1]
        },
        f"raw_material_kind_{idx}": get_string_with_label("Kategoria suroviny"),
    }


def get_sensors_data_columns() -> ValueDict:
    return {
        "QZPC": Value(
            dtype="float32",
            id='{"label": "Množstvo zemného plynu pre VP1", "unit": "m^3/h", "type": "extensive"}',
        ),
        "QPUA": Value(
            dtype="float32",
            id='{"label": "Množstvo práškového uhlia A", "unit": "kg/h", "type": "extensive"}',
        ),
        "QPUB": Value(
            dtype="float32",
            id='{"label": "Množstvo práškového uhlia B", "unit": "kg/h", "type": "extensive"}',
        ),
        "QV": Value(dtype="float32", id='{"label": "Množstvo studeného vetra", "type": "extensive"}'),
        "QW": Value(dtype="float32", id='{"label": "Množstvo pary na vlhčenie", "type": "extensive"}'),
        "QO2": Value(
            dtype="float32",
            id='{"label": "Množstvo O2 pridávaného do SV", "unit": "Nm^3/h", "type": "extensive"}',
        ),
        "POS": Value(dtype="float32", id='{"label": "Poloha snortu"}'),
        "TV": Value(
            dtype="float32", id='{"label": "Teplota horúceho vetra", "unit": "°C", "type": "intensive"}'
        ),
        "QCVP": Value(
            dtype="float32",
            id='{"label": "Množstvo vysokopecného plynu", "unit": "m^3/h",  "type": "intensive"}',
        ),
        "PS": Value(
            dtype="float32",
            id='{"label": "Tlak vysokopecného plynu", "unit": "kPa", "type": "intensive"}',
        ),
        "CO": Value(
            dtype="float32",
            id='{"label": "Podiel CO vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
        ),
        "CO2": Value(
            dtype="float32",
            id='{"label": "Podiel CO2 vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
        ),
        "H2": Value(
            dtype="float32",
            id='{"label": "Podiel H2 vo vysokopecnom plyne", "unit": "%", "type": "intensive"}',
        ),
        "POKHV": Value(dtype="float32", id='{"label": "Poloha regulačnej klapy horúceho vetra"}'),
        "POKVLH": Value(dtype="float32", id='{"label": "Poloha regulačnej klapy vlhčenia"}'),
        "POKEXA": Value(dtype="float32", id='{"label": "Poloha otvorenia klapy Expandera A"}'),
        "POKEXB": Value(dtype="float32", id='{"label": "Poloha otvorenia klapy Expandera B"}'),
        "POKEXC": Value(dtype="float32", id='{"label": "Poloha otvorenia klapy Expandera C"}'),
        "POKEXD": Value(dtype="float32", id='{"label": "Poloha otvorenia klapy Expandera D"}'),
        "QVSK": Value(dtype="float32", id='{"label": "Množstvo vody na skrápanie", "type": "extensive"}'),
        "O2V": Value(
            dtype="float32", id='{"label": "Obohatenie vetra kyslíkom", "unit": "%", "type": "intensive"}'
        ),
        "WV": Value(dtype="float32", id='{"label": "Vlhkosť vetra", "unit": "g/Nm^3", "type": "intensive"}'),
        "QPU": Value(
            dtype="float32",
            id='{"label": "Množstvo práškového uhlia (priemerné)", "unit": "kg/h",  "type": "extensive"}',
        ),
        "S_KO": Value(dtype="float32", id='{"label": "Spotreba koksu - orech", "type": "extensive"}'),
        "TTH": Value(
            dtype="float32",
            id='{"label": "Teoretická teplota horenia", "unit": "°C","type": "intensive"}',
        ),
        "TKP": Value(
            dtype="float32",
            id='{"label": "Teplota plynu na sadzobni (priemerná)", "unit": "°C", "type": "intensive"}',
        ),
    }


def get_qpu_analysis_columns() -> ValueDict:
    return {
        "qpu_analysis_date": get_timestamp_with_label("Dátum mineralogickej analýzy práškového uhlia"),
        **{
            f"qpu_{mineral}_pct": Value(
                dtype="float32",
                id=f'{{"label": "Percentuálne zastúpenie {mineral} v práškovom uhlí", "unit": "%", "type": "intensive"}}',
            )
            for mineral in RAW_MATERIAL_MINERALS
        },
    }


def get_raw_material_columns(max_idx: int) -> ValueDict:
    return dict(ChainMap(*[get_single_raw_material_columns(idx) for idx in range(max_idx, 0, -1)]))


def get_granulometry_columns(max_idx: int) -> ValueDict:
    return dict(ChainMap(*[get_single_granulometry_columns(idx) for idx in range(max_idx, 0, -1)]))


def get_pig_iron_weight_columns(max_idx: int) -> ValueDict:
    return {
        f"pig_iron_weight_{idx}": Value(
            dtype="float32",
            id=f'{{"label": "Hmotnosť surového železa v miešači {idx}", "unit": "t", "type": "extensive"}}',
        )
        for idx in range(1, max_idx + 1)
    }


def get_slag_pot_fill_value_columns(max_idx: int) -> ValueDict:
    return {
        f"slag_pot_fill_value_{idx}": get_int32_with_label(
            f"Podiel naplnenia koliby {idx} (1 = 1/4, 2 = 2/4, 3 = 3/4, a 4 = 4/4)"
        )
        for idx in range(1, max_idx + 1)
    }


def get_pig_iron_chem_analysis_columns(max_analysis: int) -> ValueDict:
    return {
        f"pig_iron_{chem}_pct_{analysis_idx}": Value(
            dtype="float32",
            id=f'{{"label": "Podiel {chem} v surovom železe - analýza {analysis_idx}", "unit": "%", "type": "intensive"}}',
        )
        for analysis_idx in range(1, max_analysis + 1)
        for chem in PIG_IRON_ELEMENTS
    }


def get_slag_mineral_columns() -> ValueDict:
    return {
        f"slag_{chem}_pct": Value(
            dtype="float32",
            id=f'{{"label": "Podiel {chem} v troske", "unit": "%", "type": "intensive"}}',
        )
        for chem in SLAG_MINERALS
    }


def get_delivery_heat_columns() -> ValueDict:
    return dict(
        {
            f"delivery_{delivery_idx}_heat_{heat_idx}": get_int32_with_label("Tavba i vyliata z dodávky j")
            for delivery_idx in range(1, MAX_DELIVERIES_PER_TAPPING + 1)
            for heat_idx in range(1, MAX_HEATS_PER_DELIVERY + 1)
        }
    )


def get_delivery_heat_mixers_columns() -> ValueDict:
    return dict(
        {
            f"delivery_{delivery_idx}_heat_{heat_idx}_mixers": get_int32_with_label(
                "Celkový počet mixérov, z ktorých bola vyliata tavba i dodávky j"
            )
            for delivery_idx in range(1, MAX_DELIVERIES_PER_TAPPING + 1)
            for heat_idx in range(1, MAX_HEATS_PER_DELIVERY + 1)
        }
    )


def get_delivery_heat_chem_columns() -> ValueDict:
    return dict(
        {
            f"delivery_{delivery_idx}_heat_{heat_idx}_chems_{chem}": get_float32_with_label(
                "Chémia ch tavby i dodávky j"
            )
            for delivery_idx in range(1, MAX_DELIVERIES_PER_TAPPING + 1)
            for heat_idx in range(1, MAX_HEATS_PER_DELIVERY + 1)
            for chem in STEELSHOP_ANALYSIS_CHEMS
        }
    )


def get_delivery_eligible_chem_columns() -> ValueDict:
    return dict(
        {
            f"delivery_{delivery_idx}_eligible_chem_{chem}": get_sequence_of_floats_with_label(
                "Chémie eligible tavieb z i-tej dodávky"
            )
            for delivery_idx in range(1, MAX_DELIVERIES_PER_TAPPING + 1)
            for chem in STEELSHOP_ANALYSIS_CHEMS
        }
    )


def get_delivery_eligible_chem_verdict_columns() -> ValueDict:
    return dict(
        ChainMap(
            *[
                {
                    f"delivery_{delivery_idx}_eligible_chem_{chem}_range": get_float32_with_label(
                        "Rozsah hodnôt chémií eligible tavieb z i-tej dodávky"
                    ),
                    f"delivery_{delivery_idx}_eligible_chem_{chem}_precision": get_float32_with_label(
                        "Určená presnosť, ktorá musia splňať chémie eligible tavieb z i-tej dodávky"
                    ),
                    f"delivery_{delivery_idx}_eligible_chem_{chem}_verdict": get_bool_with_label(
                        "Verdikt chémie eligible tavieb z i-tej dodávky"
                    ),
                }
                for delivery_idx in range(MAX_DELIVERIES_PER_TAPPING, 0, -1)
                for chem in STEELSHOP_ANALYSIS_CHEMS[::-1]
            ]
        )
    )


def get_delivery_eligible_chem_avg() -> ValueDict:
    return dict(
        {
            f"delivery_{delivery_idx}_eligible_chem_{chem}_avg": get_float32_with_label(
                "Priemer chémií eligible tavieb z i-tej dodávky"
            )
            for delivery_idx in range(1, MAX_DELIVERIES_PER_TAPPING + 1)
            for chem in STEELSHOP_ANALYSIS_CHEMS
        }
    )


def get_eligible_chem_wavg() -> ValueDict:
    return dict(
        {
            f"eligible_chem_{chem}_wavg": get_float32_with_label(
                "Celkový vážený priemer chémie eligible tavieb"
            )
            for chem in STEELSHOP_ANALYSIS_CHEMS
        }
    )


BASE_STEELSHOP_DATA_COLUMNS = [
    "delivery_1",
    "delivery_2",
    "delivery_3",
    *get_delivery_heat_columns().keys(),
    "delivery_1_tappings",
    "delivery_2_tappings",
    "delivery_3_tappings",
    *get_delivery_heat_mixers_columns().keys(),
    *get_delivery_heat_chem_columns().keys(),
]


STEELSHOP_DATA_COLUMNS = dict(
    {
        "delivery_1": get_int32_with_label("Číslo prvej dodávky vyliatej z odpichu s číslom tapping_id"),
        "delivery_2": get_int32_with_label("Číslo druhej dodávky vyliatej z odpichu s číslom tapping_id"),
        "delivery_3": get_int32_with_label("Číslo tretej dodávky vyliatej z odpichu s číslom tapping_id"),
        **get_delivery_heat_columns(),
        "delivery_1_tappings": get_int32_with_label("Počet odpichov z ktorých vznikla dodávka 1"),
        "delivery_2_tappings": get_int32_with_label("Počet odpichov z ktorých vznikla dodávka 2"),
        "delivery_3_tappings": get_int32_with_label("Počet odpichov z ktorých vznikla dodávka 3"),
        **get_delivery_heat_mixers_columns(),
        **get_delivery_heat_chem_columns(),
        "delivery_1_weight": get_float32_with_label("Hmotnosť prvej dodávky"),
        "delivery_2_weight": get_float32_with_label("Hmotnosť druhej dodávky"),
        "delivery_3_weight": get_float32_with_label("Hmotnosť tretej dodávky"),
        "delivery_1_eligible_heats": get_sequence_of_strings_with_label(
            "Eligible tavby (pozri metodu `add_eligible_heats_to_tapping`) vyliate z prvej dodávky"
        ),
        "delivery_2_eligible_heats": get_sequence_of_strings_with_label(
            "Eligible tavby (pozri metodu `add_eligible_heats_to_tapping`) vyliate z druhej dodávky"
        ),
        "delivery_3_eligible_heats": get_sequence_of_strings_with_label(
            "Eligible tavby (pozri metodu `add_eligible_heats_to_tapping`) vyliate z tretej dodávky"
        ),
        "tapping_top_data_quality": get_bool_with_label(
            "Binárny flag hovoriaci o tom, či je odpich top data quality podľa `add_top_dq_tapping_flag`"
        ),
        **get_delivery_eligible_chem_columns(),
        **get_delivery_eligible_chem_verdict_columns(),
        "eligible_chems_verdict": get_string_with_label(
            "Kategorická premenná hodnotiaca eligibilitu chémií podľa metódy `add_eligible_chems_precision_verdict_per_tapping`"
        ),
        **get_delivery_eligible_chem_avg(),
        **get_eligible_chem_wavg(),
    }
)

COLS_WITH_INCORRECTLY_INFERRED_TYPES = [
    "delivery_1_eligible_heats",
    "delivery_2_eligible_heats",
    "delivery_3_eligible_heats",
    *get_delivery_eligible_chem_columns().keys(),
]

RAW_DATASET_COLUMNS = {
    "date": get_timestamp_with_label("Dataset index"),
    "sensors_date": get_timestamp_with_label("Časová značna dát zo senzorov"),
    **get_sensors_data_columns(),
    **get_qpu_analysis_columns(),
    "charge_date": get_timestamp_with_label("Časová značka vsádzky"),
    "charge_number": get_int32_with_label("Číslo vsádzky"),
    **get_raw_material_columns(NUMBER_OF_RAW_MATERIAL_COLUMNS),
    **get_granulometry_columns(NUMBER_OF_RAW_MATERIAL_COLUMNS),
    "tapping_number": get_int32_with_label("Číslo odpichu"),
    "tapping_start_date": get_timestamp_with_label("Časová značka začiatku odpichu"),
    "tapping_end_date": get_timestamp_with_label("Časová značka konca odpichu"),
    "tapping_slag_start": get_timestamp_with_label("Časová značka začiatku trosky"),
    "tapping_id": get_int32_with_label("ID odpichu"),
    "tapping_temperature": get_float32_with_label("Teplota odpichu"),
    **get_pig_iron_weight_columns(NUMBER_OF_PIG_IRON_WEIGHT_COLUMNS),
    **get_pig_iron_chem_analysis_columns(NUMBER_OF_PIG_IRON_ANALYSIS_COLUMNS),
    **get_slag_pot_fill_value_columns(NUMBER_OF_SLAG_POT_COLUMNS),
    **get_slag_mineral_columns(),
    **STEELSHOP_DATA_COLUMNS,
}
