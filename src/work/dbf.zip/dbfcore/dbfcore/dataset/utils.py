from datasets import Sequence, Value

ValueDict = dict[str, Value | Sequence]


def get_timestamp_with_label(label: str) -> Value:
    return Value(dtype="timestamp[ns, tz=UTC]", id=f'{{"label": "{label}"}}')


def get_int32_with_label(label: str) -> Value:
    return Value(dtype="int32", id=f'{{"label": "{label}"}}')


def get_float32_with_label(label: str) -> Value:
    return Value(dtype="float32", id=f'{{"label": "{label}"}}')


def get_sequence_of_strings_with_label(label: str) -> Sequence:
    return Sequence(feature=Value(dtype="string", id=f'{{"label": "{label}"}}'))


def get_sequence_of_floats_with_label(label: str) -> Sequence:
    return Sequence(feature=Value(dtype="float32", id=f'{{"label": "{label}"}}'))


def get_bool_with_label(label: str) -> Value:
    return Value(dtype="bool", id=f'{{"label": "{label}"}}')


def get_string_with_label(label: str) -> Value:
    return Value(dtype="string", id=f'{{"label": "{label}"}}')
