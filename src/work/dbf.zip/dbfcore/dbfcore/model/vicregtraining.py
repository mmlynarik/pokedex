from typing import Union

import lightning as L
import pandas as pd
import torch
from torch import nn

from dbfcore.model.chordmixer3 import ChordMixer3
from dbfcore.model.utils import FixedInputNormalizer2

# where B = batch_size, S = sequence length. The two columns represent time in seconds from first value and
# original values in their range, respectively.
# The second tensor has shape [B] and represents signal indices in line with config.yaml
RealVicRegBatch = tuple[torch.Tensor, torch.Tensor, torch.Tensor]


class ThreeLayerPerceptron(nn.Module):
    """
    A simple Three-Layer Perceptron (MLP) module in PyTorch.

    Args:
    in_features (int): Number of input features.
    hidden_features_1 (int, optional): First hidden layer size.
    hidden_features_2 (int, optional): Second hidden layer size.
    out_features (int, optional): Output size.
    """

    def __init__(self, in_features: int, hidden_features_1: int, hidden_features_2: int, out_features: int):
        super().__init__()

        self.model = nn.Sequential(
            nn.Linear(in_features, hidden_features_1),
            nn.LayerNorm(hidden_features_1, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features_1, hidden_features_2),
            nn.LayerNorm(hidden_features_2, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features_2, out_features),
        )

    def forward(self, x):
        return self.model(x)


class RealVicReg(L.LightningModule):
    def __init__(
        self,
        window_size: str,
        input_features: int,
        track_size: int,
        latent_dim: int,
        projector_sizes: tuple[int, ...],
        seq_len: int,
        signal_normalizers_params: tuple[dict[str, Union[str, float]], ...],
        invariance_loss_weight: float,
        variance_loss_weight: float,
        covariance_loss_weight: float,
    ):
        super().__init__()

        self.projector_sizes = projector_sizes
        self.seq_len = seq_len
        self.window_size = window_size
        self.max_time = pd.Timedelta(window_size).total_seconds()
        time_param = self.max_time / 2
        num_signals = len(signal_normalizers_params)

        means = torch.stack(
            [
                torch.ones(num_signals) * time_param,
                torch.tensor([p["mean"] for p in signal_normalizers_params]),
            ],
            dim=1,
        )
        stds = torch.stack(
            [
                torch.ones(num_signals) * time_param,
                torch.tensor([p["std"] for p in signal_normalizers_params]),
            ],
            dim=1,
        )

        self.signal_names = [p["signal_name"] for p in signal_normalizers_params]

        self.input_normalizer = FixedInputNormalizer2(means, stds)
        self.time_normalizer = FixedInputNormalizer2(
            self.input_normalizer.means[:, 0:1],
            self.input_normalizer.stds[:, 0:1],
        )
        self.value_normalizer = FixedInputNormalizer2(
            self.input_normalizer.means[:, 1:2],
            self.input_normalizer.stds[:, 1:2],
        )
        self.encoder = ChordMixer3(input_features, latent_dim, seq_len, track_size)
        self.projector = ThreeLayerPerceptron(
            latent_dim, projector_sizes[0], projector_sizes[1], projector_sizes[2]
        )

        self.invariance_loss_weight = invariance_loss_weight
        self.variance_loss_weight = variance_loss_weight
        self.covariance_loss_weight = covariance_loss_weight

        self.latent_dim = latent_dim

        # nondiag_mask has shape (latent_dim, latent_dim) with 1s on all non-diagonal entries.
        # it is used in covariance loss calculation
        self.nondiag_mask: torch.Tensor
        self.register_buffer(
            "nondiag_mask", (~torch.eye(projector_sizes[-1], dtype=torch.bool)) * 1.0, persistent=False
        )
        self.signal_normalizers_params = signal_normalizers_params

        self.save_hyperparameters()

    def get_idx_for_signal_name(self, signal_name: str) -> int:
        return self.signal_names.index(signal_name)

    def encode_and_project(self, inputs, indices):
        return self.projector(self.encoder(self.input_normalizer(inputs, indices)))

    def encode(self, inputs, indices):
        normalized = self.input_normalizer(inputs, indices)
        return self.encoder(normalized)

    def get_empty_embedding(self) -> torch.Tensor:
        return torch.zeros(self.latent_dim)

    def encode_one(self, input_tensor: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
        return self.encode(input_tensor.unsqueeze(0), idx.unsqueeze(0))[0]

    def invariance_loss(self, x1, x2):
        return torch.nn.functional.mse_loss(x1, x2)

    # TODO hinge constant 1.0 does not make sense in vae setting
    def variance_loss(self, x):
        """Returns VICReg variance loss. eps for numerical stability"""
        std = torch.sqrt(x.var(dim=0) + 0.0001)
        loss = torch.mean(nn.functional.relu(1.0 - std))
        return loss

    def covariance_loss(self, x):
        """Returns VICReg covariance loss."""
        x = x - x.mean(dim=0)
        # cov has shape (..., dim, dim)
        # nondiag_mask has shape (dim, dim) with 1s on all non-diagonal entries.
        cov = torch.einsum("b...c,b...d->...cd", x, x).div_((x.size(0) - 1)).mul_(self.nondiag_mask).pow_(2)
        return cov.sum(dim=0).mean()

    def training_step(self, batch: RealVicRegBatch, batch_idx: int):
        inputs1, inputs2, indices = batch

        embeddings1 = self.encode(inputs1, indices)
        embeddings2 = self.encode(inputs2, indices)

        projected1 = self.projector(embeddings1)
        projected2 = self.projector(embeddings2)

        invariance_loss = self.invariance_loss(projected1, projected2)
        variance_loss = self.variance_loss(projected1) + self.variance_loss(projected2)
        covariance_loss = self.covariance_loss(projected1) + self.covariance_loss(projected2)

        total_loss = (
            (variance_loss * self.variance_loss_weight)
            + (covariance_loss * self.covariance_loss_weight)
            + (invariance_loss * self.invariance_loss_weight)
        )

        self.log("train/variance_loss", variance_loss)
        self.log("train/covariance_loss", covariance_loss)
        self.log("train/invariance_loss", invariance_loss)
        self.log("train/total_loss", total_loss)

        sch = self.lr_schedulers()
        if sch is not None:
            sch.step(total_loss)  # type: ignore

        return total_loss

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer
