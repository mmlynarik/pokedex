from functools import lru_cache
from typing import Union

import lightning as L
import matplotlib.pyplot as plt
import pandas as pd
import torch
from torch import nn

from dbfcore.model.chordmixer3 import ChordMixer3
from dbfcore.model.deeponet2 import DeepONet2
from dbfcore.model.utils import FixedInputNormalizer2, PerSignalStatsBuffer


def load_autoencoder_from_path(path: str):
    return SignalVAESimple2.load_from_checkpoint(path).cpu().eval()


@lru_cache(maxsize=128)
def load_autoencoder_from_path_cached(path: str):
    return load_autoencoder_from_path(path)


# Autoencoder batch is a tuple of two tensors. First tensor has shape [B, S, 2], where B = batch_size, S =
# sequence length. The two columns represent time in seconds from first value and original values in their
# range, respectively. The second tensor has shape [B] and represents signal indices in line with config.yaml
SignalVAESimple2Batch = tuple[torch.Tensor, torch.Tensor]


class SignalVAESimple2(L.LightningModule):
    def __init__(
        self,
        window_size: str,
        input_features: int,
        track_size: int,
        latent_dim: int,
        decoder_hidden_sizes: tuple[int, int],
        output_rep_size: int,
        max_seq_len: int,
        signal_normalizers_params: tuple[dict[str, Union[str, float]], ...],
        kldiv_loss_weight: float,
        log_images_every_n_train_steps: int,
        log_images_every_n_val_steps: int,
    ):
        super().__init__()

        self.max_seq_len = max_seq_len
        self.window_size = window_size
        self.max_time = pd.Timedelta(window_size).total_seconds()
        time_param = self.max_time / 2
        num_signals = len(signal_normalizers_params)

        self.val_error_buffer = PerSignalStatsBuffer(num_signals, 1024, max_seq_len)

        means = torch.stack(
            [
                torch.ones(num_signals) * time_param,
                torch.tensor([p["mean"] for p in signal_normalizers_params]),
            ],
            dim=1,
        )
        stds = torch.stack(
            [
                torch.ones(num_signals) * time_param,
                torch.tensor([p["std"] for p in signal_normalizers_params]),
            ],
            dim=1,
        )

        self.mae_percentiles: torch.Tensor
        self.register_buffer("mae_percentiles", torch.tensor([0.85, 0.9, 0.95, 0.99]))

        self.signal_names = [p["signal_name"] for p in signal_normalizers_params]
        self.mae_log_keys = [f"{p['signal_name']}_mae" for p in signal_normalizers_params]
        self.mean_error_log_keys = [f"{p['signal_name']}_mean_error" for p in signal_normalizers_params]
        self.mae_percentile_keys = [
            [f"{p['signal_name']}_mae_{pct.item()*100:.0f}_pct" for p in signal_normalizers_params]
            for pct in self.mae_percentiles
        ]

        self.input_normalizer = FixedInputNormalizer2(means, stds)
        self.time_normalizer = FixedInputNormalizer2(
            self.input_normalizer.means[:, 0:1],
            self.input_normalizer.stds[:, 0:1],
        )
        self.value_normalizer = FixedInputNormalizer2(
            self.input_normalizer.means[:, 1:2],
            self.input_normalizer.stds[:, 1:2],
        )
        self.encoder = ChordMixer3(input_features, latent_dim * 2, max_seq_len, track_size)
        self.decoder = DeepONet2(latent_dim, decoder_hidden_sizes, output_rep_size)

        self.kldiv_loss_weight = kldiv_loss_weight

        self.log_images_every_n_train_steps = log_images_every_n_train_steps
        self.log_images_every_n_val_steps = log_images_every_n_val_steps
        self.latent_dim = latent_dim

        # nondiag_mask has shape (latent_dim, latent_dim) with 1s on all non-diagonal entries.
        # it is used in covariance loss calculation
        self.nondiag_mask: torch.Tensor
        self.register_buffer(
            "nondiag_mask", (~torch.eye(self.latent_dim, dtype=torch.bool)) * 1.0, persistent=False
        )
        self.signal_normalizers_params = signal_normalizers_params

        self.save_hyperparameters()

    def get_idx_for_signal_name(self, signal_name: str) -> int:
        return self.signal_names.index(signal_name)

    def reparameterize(self, mu, logvar):
        """
        Reparameterization trick to sample from N(mu, var) from
        N(0,1).
        :param mu: (Tensor) Mean of the latent Gaussian [B x D]
        :param logvar: (Tensor) Standard deviation of the latent Gaussian [B x D]
        :return: (Tensor) [B x D]
        """
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return (eps * std) + mu

    def encode_internal(self, batch: SignalVAESimple2Batch):
        inputs, indices = batch
        normalized = self.input_normalizer(inputs, indices)
        encoded = self.encoder(normalized)
        return encoded.chunk(2, dim=1)

    def encode(self, batch: SignalVAESimple2Batch):
        return self.encode_internal(batch)[0]

    def encode_and_project(self, data, indices):
        return self.encode((data, indices))

    def get_empty_embedding(self) -> torch.Tensor:
        return torch.zeros(self.latent_dim)

    def encode_one(self, input_tensor: torch.Tensor, idx: torch.Tensor) -> torch.Tensor:
        inputs = input_tensor.unsqueeze(0)
        indices = idx.unsqueeze(0)
        return self.encode((inputs, indices))[0]

    def decode_internal(self, embedding: torch.Tensor, test_values: torch.Tensor, indices: torch.Tensor):
        return self.decoder(embedding, self.time_normalizer(test_values, indices))

    def decode(
        self, embedding: torch.Tensor, test_values: torch.Tensor, indices: torch.Tensor
    ) -> torch.Tensor:
        return self.value_normalizer.denormalize(
            self.decode_internal(embedding, test_values, indices), indices
        )

    def variate_embedding(self, mu: torch.Tensor, log_var: torch.Tensor):
        if self.training:
            return self.reparameterize(mu, log_var)
        return mu

    def forward_internal(self, batch: SignalVAESimple2Batch, test_values: torch.Tensor):
        _, indices = batch
        mu, log_var = self.encode_internal(batch)
        generation = self.variate_embedding(mu, log_var)
        decoded = self.decode_internal(generation, test_values, indices)

        return decoded, mu, log_var

    def forward(self, batch: SignalVAESimple2Batch, test_values: torch.Tensor):
        return self.forward_internal(batch, test_values)[0]

    def get_losses(self, x_hat, normalized, latent_mu, latent_log_var):
        reconstruction_loss = nn.functional.mse_loss(x_hat, normalized[:, :, 1], reduction="none")

        reconstruction_quality_order = reconstruction_loss.detach().mean(dim=1).argsort()
        reconstruction_loss = reconstruction_loss.mean()

        kldiv_loss = torch.mean(
            -0.5 * torch.sum(1 + latent_log_var - latent_mu**2 - latent_log_var.exp(), dim=1), dim=0
        )

        # logging
        std = torch.exp(0.5 * latent_log_var)
        self.log("train/latent_std_min", std.min())
        self.log("train/latent_std_mean", std.mean())

        return {
            "reconstruction_loss": reconstruction_loss,
            "kldiv_loss": kldiv_loss,
        }, reconstruction_quality_order

    def get_metrics(self, x_hat, normalized, indices):
        reconstruction_loss = nn.functional.mse_loss(x_hat, normalized[:, :, 1])

        denormalized_x_hat = self.value_normalizer.denormalize(x_hat, indices)
        denormalized_x = self.value_normalizer.denormalize(normalized[:, :, 1], indices)
        error = denormalized_x - denormalized_x_hat

        self.val_error_buffer.push_all_signals(error, indices)

        per_signal_mae = self.val_error_buffer.per_signal_abs_mean()
        per_signal_mean_error = self.val_error_buffer.per_signal_mean()
        per_signal_percentiles = self.val_error_buffer.per_signal_abs_quantiles(self.mae_percentiles)

        metrics = {"reconstruction_loss": reconstruction_loss}
        for log_key, mae in zip(self.mae_log_keys, per_signal_mae):
            metrics[log_key] = mae
        for log_key, mean_error in zip(self.mean_error_log_keys, per_signal_mean_error):
            metrics[log_key] = mean_error
        for log_keys, percentiles in zip(self.mae_percentile_keys, per_signal_percentiles):
            for log_key, percentile in zip(log_keys, percentiles):
                metrics[log_key] = percentile

        return metrics

    def log_scalars(self, stage, losses, metrics, total_loss):
        for name in losses:
            self.log(f"{stage}/{name}", losses[name])
        for name in metrics:
            self.log(f"{stage}/{name}", metrics[name])
        if stage == "train":
            self.log(f"{stage}/total_loss", total_loss)

    def get_losses_step(self, batch: SignalVAESimple2Batch):
        inputs, indices = batch
        normalized = self.input_normalizer(inputs, indices)
        x_hat, latent_mu, latent_log_var = self.forward_internal(batch, inputs[:, :, 0])
        losses, reconstruction_quality_order = self.get_losses(x_hat, normalized, latent_mu, latent_log_var)
        # metrics = self.get_metrics(x_hat, normalized, indices)
        return losses, reconstruction_quality_order

    def get_metrics_step(self, batch: SignalVAESimple2Batch):
        inputs, indices = batch
        normalized = self.input_normalizer(inputs, indices)
        x_hat, _, _ = self.forward_internal(batch, inputs[:, :, 0])
        metrics = self.get_metrics(x_hat, normalized, indices)
        return metrics

    def training_step(self, batch: SignalVAESimple2Batch, batch_idx: int):
        losses, reconstruction_quality_order = self.get_losses_step(batch)

        # print(losses)
        total_loss = losses["reconstruction_loss"] + (losses["kldiv_loss"] * self.kldiv_loss_weight)

        self.log_scalars("train", losses, {}, total_loss)

        sch = self.lr_schedulers()
        if sch is not None:
            sch.step(self.trainer.callback_metrics["train/total_loss"])  # type: ignore

        if (batch_idx % self.log_images_every_n_train_steps) == 0:
            self.log_reconstruction_by_quality_order(
                batch, reconstruction_quality_order, "train/reconstruction"
            )

        return total_loss

    def validation_step(self, batch: SignalVAESimple2Batch, batch_idx: int):
        metrics = self.get_metrics_step(batch)

        self.log_scalars("val", {}, metrics, None)

    def log_reconstruction_by_quality_order(
        self, batch: SignalVAESimple2Batch, reconstruction_quality_order: torch.Tensor, prefix: str
    ):
        self.log_reconstruction(
            batch,
            [
                (reconstruction_quality_order[0], "best"),
                (reconstruction_quality_order[len(reconstruction_quality_order) // 2], "middle"),
                (reconstruction_quality_order[-1], "worst"),
            ],
            prefix,
        )

    def log_reconstruction(
        self, batch: SignalVAESimple2Batch, selected_indexes: list[tuple[torch.Tensor, str]], prefix: str
    ):
        logger = self.get_tensorboard_logger()
        if logger is None:
            return
        with torch.no_grad():
            inputs, indices = batch
            test_times = (
                torch.linspace(0, self.max_time, 128, device=inputs.device)
                .unsqueeze(0)
                .repeat(inputs.size(0), 1)
            )

            reconstruction = self.forward(batch, test_times)
            denormalized_rec = self.value_normalizer.denormalize(reconstruction, indices)

            cpu_batch = inputs.cpu().detach()
            cpu_test_times = test_times.cpu().detach()
            cpu_denormalized = denormalized_rec.cpu().detach()
            for idx, name in selected_indexes:
                signal_idx = indices[idx]
                signal_name = self.signal_names[signal_idx]
                fig, ax = plt.subplots(figsize=(18, 6))
                ax.plot(cpu_test_times[idx], cpu_denormalized[idx], label="reconstruction")
                ax.scatter(cpu_batch[idx, :, 0], cpu_batch[idx, :, 1], color="red", label="orig")
                ax.set(
                    xlabel="Time (s)",
                    ylabel=signal_name,
                    title=f"{signal_name} {name} reconstruction",
                )
                ax.legend()
                ax.grid()

                logger.add_figure(f"{prefix}/{name}", fig, global_step=self.global_step)

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer

    def get_tensorboard_logger(self):
        tb_logger = None
        for logger in self.trainer.loggers:
            if isinstance(logger, L.pytorch.loggers.TensorBoardLogger):
                tb_logger = logger.experiment
                break
        return tb_logger
