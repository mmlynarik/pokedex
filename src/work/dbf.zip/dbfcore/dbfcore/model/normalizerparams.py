from pathlib import Path

import numpy as np
import pandas as pd

from dbfcore.model.datamodule.pisignal import prepare_train_val_data


# TODO refactor - this is duplicate code with what is done in Signal Datasets
# please use SignalDataset or SignalDatamodule instead of this
def get_data_for_normalizer_params_calculation(
    signal_name: str, data_path: Path, train_size: float
) -> np.ndarray:
    df = pd.read_parquet(data_path, engine="pyarrow")
    train_start, val_end = df.index.min(), df.index.max()
    train_end = train_start + ((val_end - train_start) * train_size)
    val_start = train_end
    train_data, _ = prepare_train_val_data(df, train_start, train_end, val_start, val_end)
    return train_data[signal_name].values


# SIGNAL_NORMALIZERS_PARAMS = {
#     "gap_phase_enum": SignalNormalizer(1.0, 1.0),
#     "hotblast_flow_Nm3h": SignalNormalizer(171000.0, 2100.0),
#     "hotblast_temp_C": SignalNormalizer(1000.0, 100.0),
#     "hotblastmoisture_flow_gNm3": SignalNormalizer(85.0, 440.0),
#     "hotblastng_flow_m3h": SignalNormalizer(2100.0, 500.0),
#     "hotblasto2_flow_Nm3h": SignalNormalizer(3900.0, 3100.0),
#     "hotblastpci_flow_kgh": SignalNormalizer(14200.0, 6600.0),
#     "hotmetal_temp_C": SignalNormalizer(1450.0, 30.0),
#     "hotmetalc_chem_pct": SignalNormalizer(5, 0.2),
#     "hotmetalmn_chem_pct": SignalNormalizer(0.5, 0.1),
#     "hotmetalp_chem_pct": SignalNormalizer(0.05, 0.01),
#     "hotmetals_chem_pct": SignalNormalizer(0.05, 0.03),
#     "hotmetalsi_chem_pct": SignalNormalizer(0.5, 0.3),
#     "hotmetalzn_chem_pct": SignalNormalizer(0.001, 0.003),
#     "chargec_flow_kgh": SignalNormalizer(50160, 20361),
#     "chargecao_flow_kgh": SignalNormalizer(16198, 6939),
#     "chargefe2o3_flow_kgh": SignalNormalizer(178037, 73108),
#     "chargefeo_flow_kgh": SignalNormalizer(7768, 3848),
#     "chargeh2o_flow_kgh": SignalNormalizer(4754, 2098),
#     "chargemgo_flow_kgh": SignalNormalizer(3297, 1502),
#     "chargemn_flow_kgh": SignalNormalizer(687, 353),
#     "chargesio2_flow_kgh": SignalNormalizer(16072, 6697),
#     "stockrod1_distance_m": SignalNormalizer(100.0, 100.0),
#     "stockrod2_distance_m": SignalNormalizer(100.0, 100.0),
#     "topgasco_chem_pct": SignalNormalizer(20.0, 3.0),
#     "topgasco2_chem_pct": SignalNormalizer(20.0, 3.0),
#     "topgash2_chem_pct": SignalNormalizer(2.5, 0.7),
# }
