from typing import Tuple

import lightning as L
import pandas as pd
import torch
from torch import nn

from dbfcore.model.datamodule.common import get_user_friendly_pipoint_name
from dbfcore.model.deeponet import DeepONet
from dbfcore.model.utils import FixedInputNormalizer


class DeepONetDecoder(L.LightningModule):
    def __init__(
        self,
        pi_point_name: str,
        window_size: str,
        latent_dim: int,
        decoder_hidden_sizes: Tuple[int, ...],
        output_rep_size: int,
        signal_normalizer_mean: float,
        signal_normalizer_std: float,
        lip_decoder_weight: float,
        lip_trunk_weight: float,
    ):
        super().__init__()

        self.pi_point_name = pi_point_name
        self.signal_name = get_user_friendly_pipoint_name(pi_point_name)
        self.window_size = window_size
        total_seconds = pd.Timedelta(window_size).total_seconds() / 2
        self.input_normalizer = FixedInputNormalizer(
            torch.tensor([total_seconds, signal_normalizer_mean]),
            torch.tensor([total_seconds, signal_normalizer_std]),
        )
        self.time_normalizer = FixedInputNormalizer(
            self.input_normalizer.mean[0:1], self.input_normalizer.std[0:1]
        )
        self.value_normalizer = FixedInputNormalizer(
            self.input_normalizer.mean[1:2], self.input_normalizer.std[1:2]
        )
        self.decoder = DeepONet(latent_dim, decoder_hidden_sizes, output_rep_size)

        self.lip_decoder_weight = lip_decoder_weight
        self.lip_trunk_weight = lip_trunk_weight
        self.save_hyperparameters()

    def forward(self, embeddings, test_values):
        test_times_normalized = self.time_normalizer(test_values)
        return self.decoder(embeddings, test_times_normalized)

    def get_losses(self, embeddings, sequence):
        normalized = self.input_normalizer(sequence)
        x_hat = self.forward(embeddings, normalized[:, :, 0])

        reconstruction_loss = nn.functional.mse_loss(x_hat, normalized[:, :, 1])

        decoder_loss = self.decoder.branch_net.get_lipschitz_loss()
        trunk_lip_loss = self.decoder.trunk_net.get_lipschitz_loss()

        max_reg_const = 1e10
        lipschitz_reg_loss = (
            (decoder_loss)
            .nan_to_num(nan=max_reg_const, posinf=max_reg_const, neginf=max_reg_const)
            .clamp(max=max_reg_const)
        )
        trunk_reg_loss = (
            (trunk_lip_loss)
            .nan_to_num(nan=max_reg_const, posinf=max_reg_const, neginf=max_reg_const)
            .clamp(max=max_reg_const)
        )

        return {
            "reconstruction_loss": reconstruction_loss,
            "lip_decoder_loss": lipschitz_reg_loss,
            "lip_trunk_loss": trunk_reg_loss,
        }

    def training_step(self, batch, batch_idx):
        embeddings, sequence = batch

        losses = self.get_losses(embeddings, sequence)

        for name in losses:
            self.log(f"train/{self.signal_name}/{name}", losses[name])

        total_loss = (
            losses["reconstruction_loss"]
            + (losses["lip_decoder_loss"] * self.lip_decoder_weight)
            + (losses["lip_trunk_loss"] * self.lip_trunk_weight)
        )

        self.log("train/total_loss", total_loss)

        sch = self.lr_schedulers()
        if sch is not None:
            sch.step(self.trainer.callback_metrics["train/total_loss"])  # type: ignore

        return total_loss

    def validation_step(self, batch, batch_idx):
        losses = self.get_losses(*batch)

        for name in losses:
            self.log(f"val/{self.signal_name}/{name}", losses[name])

        self.log("val/total_loss", losses["reconstruction_loss"])

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer
