# from lightning.pytorch.callbacks.callback import Callback
# from pympler import muppy, summary


# class MemoryLogger(Callback):
#     def __init__(self, check_every_n_steps: int = 100):
#         self.check_every_n_steps = check_every_n_steps
#         self.previous_summary = None
#         self.last_summary = None

#     def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
#         if (batch_idx % self.check_every_n_steps) != 0:
#             return

#         self.previous_summary = self.last_summary

#         all_objects = muppy.get_objects()
#         self.last_summary = summary.summarize(all_objects)

#         summary.print_(self.last_summary)

#         if self.previous_summary:
#             diff = summary.get_diff(self.previous_summary, self.last_summary)
#             summary.print_(diff)
