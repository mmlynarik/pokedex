import lightning as L
import matplotlib.pyplot as plt
import torch
from torch import nn

from dbfcore.model.deeponet import DeepONet
from dbfcore.model.utils import PerSignalStatsBuffer
from dbfcore.model.vicregtraining import RealVicReg

# range, respectively. The second tensor has shape [B] and represents signal indices in line with config.yaml
VicRegDecoderBatch = tuple[torch.Tensor, torch.Tensor]


class VicRegDecoder(L.LightningModule):
    def __init__(
        self,
        encoder_path: str,
        decoder_hidden_sizes: tuple[int, ...],
        output_rep_size: int,
        lip_decoder_loss_weight: float,
        lip_trunk_loss_weight: float,
        log_images_every_n_train_steps: int,
        log_images_every_n_val_steps: int,
    ):
        super().__init__()

        # TODO this should be loaded automatically
        self.encoder = RealVicReg.load_from_checkpoint(encoder_path)
        self.encoder.freeze()

        self.max_seq_len = self.encoder.seq_len
        self.window_size = self.encoder.window_size
        self.max_time = self.encoder.max_time

        signal_normalizers_params = self.encoder.signal_normalizers_params
        num_signals = len(signal_normalizers_params)

        self.val_error_buffer = PerSignalStatsBuffer(num_signals, 1024, self.max_seq_len)

        self.input_normalizer = self.encoder.input_normalizer
        self.time_normalizer = self.encoder.time_normalizer
        self.value_normalizer = self.encoder.value_normalizer

        self.mae_percentiles: torch.Tensor
        self.register_buffer("mae_percentiles", torch.tensor([0.85, 0.9, 0.95, 0.99]))

        self.signal_names = [p["signal_name"] for p in signal_normalizers_params]
        self.mae_log_keys = [f"{p['signal_name']}_mae" for p in signal_normalizers_params]
        self.mean_error_log_keys = [f"{p['signal_name']}_mean_error" for p in signal_normalizers_params]
        self.mae_percentile_keys = [
            [f"{p['signal_name']}_mae_{pct.item()*100:.0f}_pct" for p in signal_normalizers_params]
            for pct in self.mae_percentiles
        ]

        self.latent_dim = self.encoder.projector_sizes[-1]
        self.decoder = DeepONet(self.latent_dim, decoder_hidden_sizes, output_rep_size)

        self.lip_decoder_loss_weight = lip_decoder_loss_weight
        self.lip_trunk_loss_weight = lip_trunk_loss_weight

        self.log_images_every_n_train_steps = log_images_every_n_train_steps
        self.log_images_every_n_val_steps = log_images_every_n_val_steps

        self.save_hyperparameters()

    def forward(self, input_data: torch.Tensor, indices: torch.Tensor, test_values: torch.Tensor):
        encoded = self.encoder.encode_and_project(input_data, indices)
        return self.decoder(encoded, self.time_normalizer(test_values, indices))

    def get_losses(self, normalized_reconstruction, normalized_values):
        reconstruction_loss = nn.functional.mse_loss(
            normalized_reconstruction, normalized_values, reduction="none"
        )

        reconstruction_quality_order = reconstruction_loss.detach().mean(dim=1).argsort()
        reconstruction_loss = reconstruction_loss.mean()

        decoder_loss = self.decoder.branch_net.get_lipschitz_loss()
        trunk_lip_loss = self.decoder.trunk_net.get_lipschitz_loss()

        max_reg_const = 1e10
        lipschitz_reg_loss = (
            (decoder_loss)
            .nan_to_num(nan=max_reg_const, posinf=max_reg_const, neginf=max_reg_const)
            .clamp(max=max_reg_const)
        )
        trunk_reg_loss = (
            (trunk_lip_loss)
            .nan_to_num(nan=max_reg_const, posinf=max_reg_const, neginf=max_reg_const)
            .clamp(max=max_reg_const)
        )

        return {
            "reconstruction_loss": reconstruction_loss,
            "lip_decoder_loss": lipschitz_reg_loss,
            "lip_trunk_loss": trunk_reg_loss,
        }, reconstruction_quality_order

    def get_metrics(self, normalized_reconstruction, normalized_values, indices):
        reconstruction_loss = nn.functional.mse_loss(normalized_reconstruction, normalized_values)

        denormalized_x_hat = self.value_normalizer.denormalize(normalized_reconstruction, indices)
        denormalized_x = self.value_normalizer.denormalize(normalized_values, indices)
        error = denormalized_x - denormalized_x_hat

        self.val_error_buffer.push_all_signals(error, indices)

        per_signal_mae = self.val_error_buffer.per_signal_abs_mean()
        per_signal_mean_error = self.val_error_buffer.per_signal_mean()
        per_signal_percentiles = self.val_error_buffer.per_signal_abs_quantiles(self.mae_percentiles)

        metrics = {"reconstruction_loss": reconstruction_loss}
        for log_key, mae in zip(self.mae_log_keys, per_signal_mae):
            metrics[log_key] = mae
        for log_key, mean_error in zip(self.mean_error_log_keys, per_signal_mean_error):
            metrics[log_key] = mean_error
        for log_keys, percentiles in zip(self.mae_percentile_keys, per_signal_percentiles):
            for log_key, percentile in zip(log_keys, percentiles):
                metrics[log_key] = percentile

        return metrics

    def log_scalars(self, stage, losses, metrics, total_loss):
        for name in losses:
            self.log(f"{stage}/{name}", losses[name])
        for name in metrics:
            self.log(f"{stage}/{name}", metrics[name])
        if stage == "train":
            self.log(f"{stage}/total_loss", total_loss)

    def get_losses_step(self, batch: VicRegDecoderBatch):
        inputs, indices = batch
        normalized_reconstruction = self.forward(inputs, indices, inputs[:, :, 0])
        normalized_real_values = self.value_normalizer(inputs[:, :, 1], indices)

        losses, reconstruction_quality_order = self.get_losses(
            normalized_reconstruction, normalized_real_values
        )
        return losses, reconstruction_quality_order

    def get_metrics_step(self, batch: VicRegDecoderBatch):
        inputs, indices = batch
        normalized_reconstruction = self.forward(inputs, indices, inputs[:, :, 0])
        normalized_real_values = self.value_normalizer(inputs[:, :, 1], indices)

        metrics = self.get_metrics(normalized_reconstruction, normalized_real_values, indices)
        return metrics

    def training_step(self, batch: VicRegDecoderBatch, batch_idx: int):
        losses, reconstruction_quality_order = self.get_losses_step(batch)

        # print(losses)
        total_loss = (
            losses["reconstruction_loss"]
            + (losses["lip_decoder_loss"] * self.lip_decoder_loss_weight)
            + (losses["lip_trunk_loss"] * self.lip_trunk_loss_weight)
        )

        self.log_scalars("train", losses, {}, total_loss)

        sch = self.lr_schedulers()
        if sch is not None:
            sch.step(self.trainer.callback_metrics["train/total_loss"])  # type: ignore

        if (batch_idx % self.log_images_every_n_train_steps) == 0:
            self.log_reconstruction_by_quality_order(
                batch, reconstruction_quality_order, "train/reconstruction"
            )

        return total_loss

    def validation_step(self, batch: VicRegDecoderBatch, batch_idx: int):
        metrics = self.get_metrics_step(batch)

        self.log_scalars("val", {}, metrics, None)

    def log_reconstruction_by_quality_order(
        self, batch: VicRegDecoderBatch, reconstruction_quality_order: torch.Tensor, prefix: str
    ):
        self.log_reconstruction(
            batch,
            [
                (reconstruction_quality_order[0], "best"),
                (reconstruction_quality_order[len(reconstruction_quality_order) // 2], "middle"),
                (reconstruction_quality_order[-1], "worst"),
            ],
            prefix,
        )

    def log_reconstruction(
        self, batch: VicRegDecoderBatch, selected_indexes: list[tuple[torch.Tensor, str]], prefix: str
    ):
        logger = self.get_tensorboard_logger()
        if logger is None:
            return
        with torch.no_grad():
            inputs, indices = batch
            test_times = (
                torch.linspace(0, self.max_time, 128, device=inputs.device)
                .unsqueeze(0)
                .repeat(inputs.size(0), 1)
            )

            reconstruction = self.forward(inputs, indices, test_times)
            denormalized_rec = self.value_normalizer.denormalize(reconstruction, indices)

            cpu_batch = inputs.cpu().detach()
            cpu_test_times = test_times.cpu().detach()
            cpu_denormalized = denormalized_rec.cpu().detach()
            for idx, name in selected_indexes:
                signal_idx = indices[idx]
                signal_name = self.signal_names[signal_idx]
                fig, ax = plt.subplots(figsize=(18, 6))
                ax.plot(cpu_test_times[idx], cpu_denormalized[idx], label="reconstruction")
                ax.scatter(cpu_batch[idx, :, 0], cpu_batch[idx, :, 1], color="red", label="orig")
                ax.set(
                    xlabel="Time (s)",
                    ylabel=signal_name,
                    title=f"{signal_name} {name} reconstruction",
                )
                ax.legend()
                ax.grid()

                logger.add_figure(f"{prefix}/{name}", fig, global_step=self.global_step)

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer

    def get_tensorboard_logger(self):
        tb_logger = None
        for logger in self.trainer.loggers:
            if isinstance(logger, L.pytorch.loggers.TensorBoardLogger):
                tb_logger = logger.experiment
                break
        return tb_logger

    def set_regularization_loss_weight(self, name: str, value: float):
        setattr(self, name, value)
