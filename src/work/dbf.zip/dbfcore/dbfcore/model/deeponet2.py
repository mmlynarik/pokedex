import torch
from torch import nn

from dbfcore.model.vicregtraining import ThreeLayerPerceptron


class DeepONet2(nn.Module):
    def __init__(self, latent_rep_size: int, hidden_sizes: tuple[int, int], rep_size: int):
        super().__init__()
        self.branch_net = ThreeLayerPerceptron(latent_rep_size, hidden_sizes[0], hidden_sizes[1], rep_size)
        self.trunk_net = ThreeLayerPerceptron(1, hidden_sizes[0], hidden_sizes[1], rep_size)
        self.bias = nn.Parameter(torch.zeros((1), requires_grad=True))
        self.latent_rep_size = latent_rep_size

    # latent rep is Batch x Latent rep size
    # eval points is Batch x Points
    # return tensor is Batch x Points
    def forward(self, latent_rep, eval_points):
        branch = self.branch_net(latent_rep)
        trunk = self.trunk_net(eval_points.unsqueeze(2))
        dotproduct = branch.unsqueeze(1) * trunk
        return dotproduct.sum(dim=2) + self.bias

    @property
    def latent_dim(self):
        return self.latent_rep_size
