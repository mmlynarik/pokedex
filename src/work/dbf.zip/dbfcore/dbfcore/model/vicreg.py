import lightning as L
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from dbfcore.model.chordmixer import ChordMixer2
from dbfcore.model.datamodule.common import get_user_friendly_pipoint_name
from dbfcore.model.utils import FixedInputNormalizer


class MLP(torch.nn.Module):
    def __init__(self, dims):
        """
        dim[0]: input dim
        dim[1:-1]: hidden dims
        dim[-1]: out dim

        assume len(dims) >= 3
        """
        super().__init__()

        self.layers = torch.nn.ModuleList()
        for ii in range(len(dims) - 2):
            self.layers.append(nn.Linear(dims[ii], dims[ii + 1]))

        self.layer_output = nn.Linear(dims[-2], dims[-1])
        self.relu = torch.nn.ReLU()

    def forward(self, x):
        for ii in range(len(self.layers)):
            x = self.layers[ii](x)
            x = self.relu(x)
        return self.layer_output(x)


class VicReg(L.LightningModule):
    def __init__(
        self,
        pi_point_name: str,
        window_size: str,
        input_features: int,
        track_size: int,
        hidden_size: int,
        latent_dim: int,
        max_seq_len: int,
        signal_normalizer_mean: float,
        signal_normalizer_std: float,
        invariance_weight: float = 25.0,
        variance_weight: float = 25.0,
        covariance_weight: float = 1.0,
        eps=0.0001,
    ):
        super().__init__()

        self.pi_point_name = pi_point_name
        self.signal_name = get_user_friendly_pipoint_name(pi_point_name)
        self.window_size = window_size
        self.max_seq_len = max_seq_len
        self.input_seq_len = self.max_seq_len * 2
        total_seconds = pd.Timedelta(window_size).total_seconds() / 2
        self.input_normalizer = FixedInputNormalizer(
            torch.tensor([total_seconds, signal_normalizer_mean]),
            torch.tensor([total_seconds, signal_normalizer_std]),
        )
        self.time_normalizer = FixedInputNormalizer(
            self.input_normalizer.mean[0:1], self.input_normalizer.std[0:1]
        )
        self.value_normalizer = FixedInputNormalizer(
            self.input_normalizer.mean[1:2], self.input_normalizer.std[1:2]
        )
        self.encoder = ChordMixer2(
            input_features, latent_dim, max_seq_len, track_size, hidden_size, 0.0, 0.0, False
        )
        self.projector = MLP((latent_dim, latent_dim, latent_dim, latent_dim))
        self.eps = eps
        self.invariance_weight = invariance_weight
        self.variance_weight = variance_weight
        self.covariance_weight = covariance_weight

        self.save_hyperparameters()

    def forward(self, batch):
        normalized = self.input_normalizer(batch)

        first_idxes, second_idxes = torch.chunk(torch.randperm(self.input_seq_len), 2)
        first_data, second_data = normalized[:, first_idxes, :], normalized[:, second_idxes, :]

        first_encoded, second_encoded = self.encoder(first_data), self.encoder(second_data)
        first_projected, second_projected = self.projector(first_encoded), self.projector(second_encoded)

        return first_encoded, second_encoded, first_projected, second_projected

    def invariance_loss(self, x: Tensor, y: Tensor) -> Tensor:
        """Returns VICReg invariance loss.

        Args:
            x:
                Tensor with shape (batch_size, ..., dim).
            y:
                Tensor with shape (batch_size, ..., dim).
        """
        return F.mse_loss(x, y)

    def variance_loss(self, x: Tensor) -> Tensor:
        """Returns VICReg variance loss.

        Args:
            x:
                Tensor with shape (batch_size, ..., dim).
            eps:
                Epsilon for numerical stability.
        """
        std = torch.sqrt(x.var(dim=0) + self.eps)
        loss = torch.mean(F.relu(1.0 - std))
        return loss

    def covariance_loss(self, x: Tensor) -> Tensor:
        """Returns VICReg covariance loss.

        Generalized version of the covariance loss with support for tensors with more than
        two dimensions. Adapted from VICRegL:
        https://github.com/facebookresearch/VICRegL/blob/803ae4c8cd1649a820f03afb4793763e95317620/main_vicregl.py#L299

        Args:
            x:
                Tensor with shape (batch_size, ..., dim).
        """
        x = x - x.mean(dim=0)
        batch_size = x.size(0)
        dim = x.size(-1)
        # nondiag_mask has shape (dim, dim) with 1s on all non-diagonal entries.
        nondiag_mask = ~torch.eye(dim, device=x.device, dtype=torch.bool)
        # cov has shape (..., dim, dim)
        cov = torch.einsum("b...c,b...d->...cd", x, x) / (batch_size - 1)
        loss = cov[..., nondiag_mask].pow(2).sum(-1) / dim
        return loss.mean()

    def get_losses(self, batch):
        _, _, first_projected, second_projected = self.forward(batch)

        # invariance term of the loss
        inv_loss = self.invariance_loss(x=first_projected, y=second_projected)

        var_loss = 0.5 * (self.variance_loss(x=first_projected) + self.variance_loss(x=second_projected))
        cov_loss = self.covariance_loss(x=first_projected) + self.covariance_loss(x=second_projected)

        return {"invariance_loss": inv_loss, "variance_loss": var_loss, "covariance_loss": cov_loss}

    def training_step(self, batch, batch_idx):
        losses = self.get_losses(batch)

        for name in losses:
            self.log(f"train/{self.signal_name}/{name}", losses[name])

        total_loss = (
            (losses["invariance_loss"] * self.invariance_weight)
            + (losses["variance_loss"] * self.variance_weight)
            + (losses["covariance_loss"] * self.covariance_weight)
        )

        self.log("train/total_loss", total_loss)

        sch = self.lr_schedulers()
        if sch is not None:
            sch.step(self.trainer.callback_metrics["train/total_loss"])  # type: ignore

        return total_loss

    def validation_step(self, batch, batch_idx):
        losses = self.get_losses(batch)

        for name in losses:
            self.log(f"val/{self.signal_name}/{name}", losses[name])

        total_loss = losses["invariance_loss"]
        self.log("val/total_loss", total_loss)

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters(), lr=1e-3)
        return optimizer
