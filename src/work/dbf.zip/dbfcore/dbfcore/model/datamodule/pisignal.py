import logging
import math
import sqlite3
import warnings
from datetime import datetime
from pathlib import Path
from typing import Optional, Protocol, Sequence, Tuple, Union

import lightning as L
import numpy as np
import pandas as pd
import torch
from attrs import define, field
from torch.utils.data import ConcatDataset, DataLoader, Dataset, IterableDataset

from dbfcore.settings import NANOSECONDS_IN_SECOND, TZ_UTC


def get_row_count(connection: sqlite3.Connection, table_name: str) -> int:
    try:
        return connection.cursor().execute(f"SELECT COUNT(*) FROM {table_name};").fetchone()[0]
    except sqlite3.OperationalError as e:
        if str(e).startswith("no such table"):
            return 0
        raise


# TODO larger refactoring needed
# Transform_timestamps should be internal function of FixedWindowFixedSeqlenSignalDataset
# Start times should be done in datetime format and transformed to internal format in FixedWindowFixedSeqlenSignalDataset


def transform_timestamps(df: pd.DataFrame, drop_timestamps: bool = False) -> pd.DataFrame:
    if df.empty:
        return df
    df = df.set_index(df.index.astype(np.int64)).sort_index().reset_index()
    df["Timestamp"] = df["Timestamp"] / NANOSECONDS_IN_SECOND

    return df.set_index("Timestamp", drop=drop_timestamps).sort_index()


def get_start_times(df: pd.DataFrame, window_seconds: float) -> list[float]:
    return list(df[df.index < (df.last_valid_index() - window_seconds)].index)


def prepare_train_val_data(
    data: pd.DataFrame, train_start: datetime, train_end: datetime, val_start: datetime, val_end: datetime
) -> tuple[pd.DataFrame, pd.DataFrame]:
    train_data = data[train_start:train_end].copy()  # type: ignore
    train_data = transform_timestamps(train_data)
    val_data = data[val_start:val_end].copy()  # type: ignore
    val_data = transform_timestamps(val_data)

    return train_data, val_data


def get_timestamps_sequence(start: datetime, end: datetime, step: pd.Timedelta) -> np.ndarray:
    start_timestamp = start.timestamp()
    end_timestamp = (end - step).timestamp()
    return np.arange(start_timestamp, end_timestamp, step.total_seconds())


def sample_2D_array(input_array: np.ndarray, sample_size: int, mode: str) -> np.ndarray:
    """
    Samples 2D array resulting in an output array of length equal to the `sample_size`.

    Logic:
        * if `sample_size` is greater than the length of the input array:
            1. calculates how many times the input array with its length fits into a sample size (`repeats`)
            2. finds out how many elements left after repeating the input array (`left`)
            3. concatenates the input array repeating the number of times defined by `repeats` and
               an array consisting of random samples from the input array of length defined by `left`
        * else:
            1. splits the input array into approximately equal chunks - the number of chunks equals the `sample_size`
            2. randomly selects one sample from each chunk in `stratified_train` mode
               in `live` mode always selects the last sample from each chunk
            3. concatenates samples of each chunk

    Example:
        input_array = np.array([[1,2],[3,4],[5,6],[7,8]])

        sample_2D_array(input_array, 6, "live")
        >>> array([[1, 2],
                   [3, 4],
                   [5, 6],
                   [7, 8],
                   [3, 4],
                   [7, 8]])
        sample_2D_array(input_array, 3, "stratified_train")
        >>> array([[3, 4],
                   [5, 6],
                   [7, 8]])
    """
    if sample_size < 1:
        raise Exception("Sample size must be greater than or equal to 1.")
    if mode not in ("stratified_train", "live"):
        raise Exception(
            f"There is no mode named {mode}. Please choose from these two options: `stratified_train` or `live`."
        )

    input_array_length = input_array.shape[0]

    if sample_size >= input_array_length:
        repeats = sample_size // input_array_length
        left = sample_size - input_array_length * repeats
        if left == 0:
            samples = np.tile(input_array, (repeats, 1))
        else:
            samples = np.concatenate(
                (np.tile(input_array, (repeats, 1)), sample_2D_array(input_array, left, mode))
            )
    else:
        chunks = np.array_split(input_array, sample_size)

        if mode == "stratified_train":
            samples = np.array([chunk[np.random.choice(len(chunk), 1), :] for chunk in chunks])
        elif mode == "live":
            samples = np.array([chunk[-1:] for chunk in chunks])

        samples = np.concatenate(samples)

    return samples


# TODO move to model
# https://vdevops.sk.uss.com/AADT/DBF/_workitems/edit/1311/


def resample_to_len(data: np.ndarray, sample_size: int, mode: str = "train") -> np.ndarray:
    if len(data) > 0:
        if mode == "train":
            full_data = data[np.random.choice(len(data), sample_size, replace=True), :]
        elif mode == "stratified_train":
            full_data = sample_2D_array(data, sample_size, "stratified_train")
        elif mode == "live":
            full_data = sample_2D_array(data, sample_size, "live")
        else:
            raise Exception(
                f"There is no mode named {mode}. Please choose from these three options: `train`, `stratified_train` or `live`."
            )
        return full_data.copy()
    return np.zeros((sample_size, 2), dtype=np.float32)


def normalize_start_and_convert_to_torch(data: np.ndarray, start: float) -> torch.Tensor:
    data[:, 0] = data[:, 0] - start
    # TODO better handling of empty data
    # If there are empty data we should not subtract start but for now hack below will do it
    data[:, 0] = data[:, 0].clip(0.0)
    return torch.from_numpy(data).type(torch.float32)


# TODO remove typing to float32 and leave it to lightning
# https://vdevops.sk.uss.com/AADT/DBF/_workitems/edit/1464


# TODO better name for this function is needed
def select_and_resample_to_len(
    orig_sorted_data: pd.DataFrame, start: float, end: float, sample_size: int, mode: str = "train"
) -> torch.Tensor:
    if orig_sorted_data.empty:
        return torch.tensor([])

    # Code below does the same thing as commented code but in more performant way
    # selection = orig_sorted_data[(orig_sorted_data.index > start) & (orig_sorted_data.index <= end)]
    start_idx = orig_sorted_data.index.searchsorted(start, side="right")
    end_idx = orig_sorted_data.index.searchsorted(end, side="right")
    selection = orig_sorted_data.iloc[start_idx:end_idx]

    full_data = resample_to_len(selection.values, sample_size, mode)
    return normalize_start_and_convert_to_torch(full_data, start)


@define(slots=False, frozen=True)
class FixedTrainValTimestamps:
    train_start: str
    train_end: str
    val_start: str
    val_end: str
    step: str

    @property
    def train_start_ts(self) -> datetime:
        return datetime.fromisoformat(self.train_start).replace(tzinfo=TZ_UTC)

    @property
    def train_end_ts(self) -> datetime:
        return datetime.fromisoformat(self.train_end).replace(tzinfo=TZ_UTC)

    @property
    def val_start_ts(self) -> datetime:
        return datetime.fromisoformat(self.val_start).replace(tzinfo=TZ_UTC)

    @property
    def val_end_ts(self) -> datetime:
        return datetime.fromisoformat(self.val_end).replace(tzinfo=TZ_UTC)

    @property
    def step_timedelta(self) -> pd.Timedelta:
        return pd.Timedelta(self.step)

    @property
    def train_timestamps(self):
        return get_timestamps_sequence(self.train_start_ts, self.train_end_ts, self.step_timedelta)

    @property
    def val_timestamps(self):
        return get_timestamps_sequence(self.val_start_ts, self.val_end_ts, self.step_timedelta)


def isoformat_to_utc_pandas_timestamp(isodatetime: str) -> pd.Timestamp:
    return pd.Timestamp(datetime.fromisoformat(isodatetime).replace(tzinfo=TZ_UTC))


@define(slots=False, frozen=True)
class TrainValIntervals:
    train_start: str
    train_end: str
    val_start: str
    val_end: str
    step: str = field(default="1min")
    train_size_limit: int = field(default=-1)
    val_size_limit: int = field(default=-1)

    @property
    def train_start_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.train_start)

    @property
    def train_end_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.train_end)

    @property
    def val_start_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.val_start)

    @property
    def val_end_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.val_end)

    @property
    def step_timedelta(self) -> pd.Timedelta:
        return pd.Timedelta(self.step)

    @property
    def train_timestamps(self):
        return get_timestamps_sequence(self.train_start_ts, self.train_end_ts, self.step_timedelta)

    @property
    def val_timestamps(self):
        return get_timestamps_sequence(self.val_start_ts, self.val_end_ts, self.step_timedelta)


@define(slots=False, frozen=True)
class Signal2:
    name: str
    data_path: Path
    mean: float
    std: float
    train_val_split: TrainValIntervals


# TODO remove when all training are v2
class FixedWindowFixedSeqlenSignalDataset(Dataset):
    """
    Returned values consist of
    Time tensor is time in seconds from first value
    Value tensor is in shape [sequence_length] x [number of columns] and contains original values in their range

    When sequence length is larger than number of items in window oversampling is done by repeating values

    Retured shape is [sequence_length] x [1 + number of columns]
    """

    def __init__(
        self,
        data_df: pd.DataFrame,
        window_size: pd.Timedelta,
        sequence_length: int,
        start_times: Sequence[float],
    ):
        self.sorted_data = data_df
        self.window_size = window_size
        self.window_total_seconds = window_size.total_seconds()
        self.sequence_length = sequence_length
        self.start_times = start_times

    def get_orig_data(self) -> pd.DataFrame:
        return self.sorted_data.set_index(pd.to_datetime(self.sorted_data.index, unit="s", utc=True)).copy()

    def get_time_selection(self, idx: int) -> Tuple[float, pd.DataFrame]:
        range_start = self.start_times[idx]
        range_end = range_start + self.window_total_seconds
        return range_start, self.sorted_data[range_start:range_end]  # type: ignore

    def __len__(self) -> int:
        return len(self.start_times)

    def __getitem__(self, idx: int) -> torch.Tensor:
        # This should be the same code as in get_time selection method
        # It is copied here for performance reasons
        # Please keep in sync
        range_start = self.start_times[idx]
        range_end = range_start + self.window_total_seconds
        return select_and_resample_to_len(self.sorted_data, range_start, range_end, self.sequence_length)


class SignalDatasource(Protocol):
    def get_data_in_interval(self, start: float, end: float) -> pd.DataFrame:
        """
        This function should return dataframe with signal data in selected interval in following format:

        | Index - Timestamp (epoch time - float), sorted asc
        | Column 0 - Timestamp (epoch time - float) - same as index
        | Column 1 - Signal data - name can be random values are floats

        | For now the interval should be open from left and closed from right [start < x <= end]

        Example:
        | Timestamp(index) Timestamp	    bf1_stockrod1_distance_m
        | 1.514765e+09	   1.514765e+09	    91.548450
        | 1.514766e+09	   1.514766e+09	    91.548450
        | 1.514767e+09	   1.514767e+09	    92.011390
        """
        ...


class InMemoryDatasource:
    def __init__(self, data: pd.DataFrame):
        self.sorted_data = data

        dataset_memory_usage_mb = self.sorted_data.memory_usage().sum() / 1024 / 1024
        if dataset_memory_usage_mb > 100:
            warnings.warn(
                f"Dataset size: {dataset_memory_usage_mb}MB.\n"
                + "Using in memory dataset for large data can lead to memory issues.\n"
                + "Consider using other dataset if your RAM is not infinite."
            )

    def get_data_in_interval(self, start: float, end: float) -> pd.DataFrame:
        start_idx = self.sorted_data.index.searchsorted(start, side="right")
        end_idx = self.sorted_data.index.searchsorted(end, side="right")
        return self.sorted_data.iloc[start_idx:end_idx]


class SQLiteDatasource:
    def __init__(self, database_path: Path, table_name: str):
        if not database_path.exists():
            raise ValueError(f"SQLite database on path {database_path} does not exist.")
        self.db_connection: Optional[sqlite3.Connection] = None
        self.database_path = database_path
        self.query_template = (
            f"SELECT * FROM {table_name} WHERE Timestamp > {{}} AND Timestamp <= {{}} ORDER BY Timestamp ASC;"
        )

    def get_connection(self) -> sqlite3.Connection:
        if self.db_connection is None:
            # Open connection in readonly mode
            self.db_connection = sqlite3.connect(f"file:{self.database_path}?mode=ro", uri=True)
        return self.db_connection

    def get_data_in_interval(self, start: float, end: float) -> pd.DataFrame:
        query = self.query_template.format(start, end)
        data = pd.read_sql(query, self.get_connection(), index_col="Timestamp")
        data.insert(0, "Timestamp", data.index)
        return data


class InMemoryStartTimesDataset(Dataset):
    def __init__(self, start_times: Sequence[float]):
        if len(start_times) > 1_000_000:
            warnings.warn(
                "For large datasets consider using calculated form of start times.\n"
                + "Using in memory form will cause slow worker startup time and high memory usage."
            )
        self.start_times = start_times

    def __len__(self) -> int:
        return len(self.start_times)

    def __getitem__(self, idx: int) -> float:
        return self.start_times[idx]


class CalculatedStartTimesDataset(Dataset):
    def __init__(
        self,
        start: pd.Timestamp,
        end: pd.Timestamp,
        step: pd.Timedelta,
        window_size: pd.Timedelta,
        limit: int = -1,
    ):
        self.total_steps_count = math.ceil(((end - window_size) - start) / step)
        self.step_multiplier = 1.0
        if self.total_steps_count <= 0:
            raise ValueError(
                "Invalid settings for start times dataset.\n"
                + f"Start: {start} End: {end} Step: {step} \n"
                + f"Total expected step count: {self.total_steps_count}"
            )

        if (self.total_steps_count > limit) and (limit != -1):
            self.step_multiplier = self.total_steps_count / limit
            self.total_steps_count = limit

        self.start = start
        self.step = step

    def __len__(self) -> int:
        return self.total_steps_count

    def __getitem__(self, idx: int) -> float:
        return (self.start + (self.step * math.floor(idx * self.step_multiplier))).timestamp()


class SignalDataset(Dataset):
    """
    Each dataset sample is a tuple of tensor and integer. Tensor is a (seq_len, 2)-shaped tensor, where the
    two columns represent time in seconds from first value and original values in their range, respectively.
    When sequence length is larger than number of items in window, oversampling is done by repeating values.
    Integer element of the dataset sample represents signal index in the config.yaml used to train the model.
    """

    def __init__(
        self,
        datasource: SignalDatasource,
        window_size: pd.Timedelta,
        sequence_length: int,
        start_times: Union[InMemoryStartTimesDataset, CalculatedStartTimesDataset],
        signal_idx: int,
        sampling_mode: str = "stratified_train",
    ):
        self.datasource = datasource
        self.window_size = window_size
        self.window_total_seconds = window_size.total_seconds()
        self.sequence_length = sequence_length
        self.start_times = start_times
        self.signal_idx = signal_idx
        self.sampling_mode = sampling_mode

    # get_orig_data Only used in experimental - potentially dangerous with large data
    # Commented out for now - better way needs to be found to do this
    # def get_orig_data(self) -> pd.DataFrame:
    #     return self.sorted_data.set_index(pd.to_datetime(self.sorted_data.index, unit="s", utc=True)).copy()

    def get_time_selection(self, idx: int) -> Tuple[float, pd.DataFrame]:
        range_start = self.start_times[idx]
        range_end = range_start + self.window_total_seconds
        return range_start, self.datasource.get_data_in_interval(range_start, range_end)

    def __len__(self) -> int:
        return len(self.start_times)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, int]:
        range_start, selected_data = self.get_time_selection(idx)
        resampled = resample_to_len(selected_data.values, self.sequence_length, self.sampling_mode)
        return normalize_start_and_convert_to_torch(resampled, range_start), self.signal_idx


def is_empty_sequence(data: torch.Tensor) -> bool:
    return bool((data == 0.0).all().item())


def is_empty_sequence_batched(data: torch.Tensor) -> torch.Tensor:
    return (data.view(data.shape[0], -1) == 0.0).all(dim=1)


class EmptySequenceFilteringIterator:
    def __init__(self, signal_dataset: SignalDataset):
        self.signal_dataset = signal_dataset
        self.current_idx = 0
        self.max_idx = len(self.signal_dataset)

    def __next__(self):
        while self.current_idx < self.max_idx:
            current_data = self.signal_dataset[self.current_idx]
            self.current_idx = self.current_idx + 1

            if is_empty_sequence(current_data[0]):
                continue

            return current_data

        raise StopIteration()


class SignalDatasetWithoutEmptySeqences(IterableDataset):
    def __init__(self, signal_dataset: SignalDataset):
        self.signal_dataset = signal_dataset

    def __iter__(self):
        return EmptySequenceFilteringIterator(self.signal_dataset)


# This is not ideal but a pragmatic solution to empty data problem
#
# Iterable dataset is not ideal as shuffling does not work properly
# Handling it in model is problematic because it needs changing all losses
# Handling it in collate_fn is less problematic but it has a problem when all data are empty in one batch
# Precalculating takes long time and caching is non trivial
class SignalDatasetWithoutEmptySequencesWithReplacement(Dataset):
    def __init__(self, signal_dataset: SignalDataset):
        self.signal_dataset = signal_dataset
        self.non_empty_iterator = EmptySequenceFilteringIterator(self.signal_dataset)

    # Test if at least one non empty value exist
    def test_nonempty_exists(self):
        try:
            next(EmptySequenceFilteringIterator(self.signal_dataset))
        except StopIteration:
            raise ValueError("Dataset must contain at least one non empty value")

    def get_next_non_empty(self) -> tuple[torch.Tensor, int]:
        try:
            return next(self.non_empty_iterator)
        except StopIteration:
            self.test_nonempty_exists()
            self.non_empty_iterator = EmptySequenceFilteringIterator(self.signal_dataset)
            return next(self.non_empty_iterator)

    def __len__(self) -> int:
        return len(self.signal_dataset)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, int]:
        current_data = self.signal_dataset[idx]
        if is_empty_sequence(current_data[0]):
            return self.get_next_non_empty()
        return current_data


class SignalDatasetForEmbeddingsGeneration(Dataset):
    def __init__(self, signal_dataset: SignalDataset):
        self.signal_dataset = signal_dataset

        if signal_dataset.sampling_mode != "live":
            raise Exception("Sampling mode must be set to `live`")

    def __len__(self) -> int:
        return len(self.signal_dataset)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, int, bool, float]:
        data, signal_idx = self.signal_dataset[idx]
        return data, signal_idx, not is_empty_sequence(data), self.signal_dataset.start_times[idx]


class SignalsDataModule2(L.LightningDataModule):
    def __init__(
        self,
        signals: list[Signal2],
        sqlite_database_path: Optional[str] = None,
        window_size: str = "1h",
        sequence_length: int = 128,
        batch_size: int = 32,
        num_workers: int = 0,
        shuffle_train: bool = True,
        shuffle_val: bool = False,
        prefetch_factor: Optional[int] = None,
        pin_memory: bool = False,
        signal_idx: Optional[int] = None,
        eval_mode: bool = False,
    ):
        super().__init__()
        self.window_size = pd.Timedelta(window_size)
        self.sequence_length = sequence_length
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.signals = signals
        self.shuffle_train = shuffle_train
        self.shuffle_val = shuffle_val
        self.prefetch_factor = prefetch_factor
        self.pin_memory = pin_memory
        self.signal_indices = (
            {signals[0].name: signal_idx}
            if signal_idx is not None and len(signals) == 1
            else {signal.name: idx for idx, signal in enumerate(signals)}
        )
        self.eval_mode = eval_mode

        logging.info(f"SignalsDataModule for signals {[signal.name for signal in self.signals]}")
        logging.info(f"SignalsDataModule window size: {self.window_size}")
        logging.info(f"SignalsDataModule sequence length: {self.sequence_length}")
        logging.info(f"SignalsDatamodule batch_size: {self.batch_size}")
        logging.info(f"SignalsDataModule num workers: {self.num_workers}")
        logging.info(f"Working on eval mode: {self.eval_mode}")

        self.sqlite_path = Path(sqlite_database_path) if sqlite_database_path else None
        if self.sqlite_path:
            logging.info(f"SQLite data source will be used with db on path: {self.sqlite_path}")
            if self.sqlite_path.exists():
                logging.info(
                    "SQLite data source already exists. "
                    + "Signals with same name will not be reimported to database."
                    + "If you changed underlying data you need to delete database file manually"
                )
        else:
            logging.info("In memory data source will be used - please be careful with large data")

        if not self.shuffle_train:
            warnings.warn(
                "SignalsDataModule training shuffle is turned off.\n"
                + "It is recommended to have it on if you are not doing something special."
            )
        if self.shuffle_val:
            warnings.warn(
                "SignalsDataModule validation shuffle is turned on.\n"
                + "It is recommended to have it off if you are not doing something special."
            )
        for signal in signals:
            if not signal.data_path.exists():
                raise FileNotFoundError(
                    f"{signal.name} signal cached file not found on path {signal.data_path}.\n"
                    + "Please use `generate_signal_dataframe` script to generate it first."
                )

    def import_data_to_database(self, data: pd.DataFrame, signal: Signal2):
        if self.sqlite_path:
            logging.info(f"Importing data to sqlite database for signal {signal.name}")
            db_connection = sqlite3.connect(f"file:{self.sqlite_path}", uri=True)
            current_row_count = get_row_count(db_connection, signal.name)
            logging.info(f"Current row count for {signal.name} is {current_row_count}.")
            logging.info(f"Row count of data to be imported: {len(data)}")
            if current_row_count != len(data):
                logging.info("Importing data - old data in database (if any) will be replaced")
                import_dataset = transform_timestamps(data, drop_timestamps=True)
                import_dataset.to_sql(signal.name, db_connection, chunksize=1000, if_exists="replace")
            else:
                logging.info("Data in database have same lenght as new data - new data will NOT be imported")
                logging.info("If it is coincidence and data changed please delete database file manually")

    def get_datasets_from_dataframe(self, data: pd.DataFrame, signal: Signal2) -> tuple[Dataset, Dataset]:
        self.import_data_to_database(data, signal)

        data_split = signal.train_val_split

        logging.info(f"Train start: {data_split.train_start_ts}; Train end: {data_split.train_end_ts}")
        logging.info(f"Val start: {data_split.val_start_ts}; Val end: {data_split.val_end_ts}")

        train_start_times = CalculatedStartTimesDataset(
            data_split.train_start_ts,
            data_split.train_end_ts,
            data_split.step_timedelta,
            self.window_size,
            data_split.train_size_limit,
        )

        val_start_times = CalculatedStartTimesDataset(
            data_split.val_start_ts,
            data_split.val_end_ts,
            data_split.step_timedelta,
            self.window_size,
            data_split.val_size_limit,
        )

        logging.info(f"Train start times start: {train_start_times[0]}; end: {train_start_times[-1]}")
        logging.info(f"Val start times start: {val_start_times[0]}; end: {val_start_times[-1]}")

        datasource: SignalDatasource
        if self.sqlite_path:
            datasource = SQLiteDatasource(self.sqlite_path, signal.name)
        else:
            datasource = InMemoryDatasource(transform_timestamps(data))

        sampling_mode = "live" if self.eval_mode else "stratified_train"

        raw_train_dataset = SignalDataset(
            datasource,
            self.window_size,
            self.sequence_length,
            train_start_times,
            self.signal_indices[signal.name],
            sampling_mode,
        )
        raw_val_dataset = SignalDataset(
            datasource,
            self.window_size,
            self.sequence_length,
            val_start_times,
            self.signal_indices[signal.name],
            sampling_mode,
        )

        if self.eval_mode:
            return SignalDatasetForEmbeddingsGeneration(
                raw_train_dataset
            ), SignalDatasetForEmbeddingsGeneration(raw_val_dataset)
        else:
            return SignalDatasetWithoutEmptySequencesWithReplacement(
                raw_train_dataset
            ), SignalDatasetWithoutEmptySequencesWithReplacement(raw_val_dataset)

    def load_signal_dataframe(self, signal: Signal2) -> pd.DataFrame:
        return pd.read_parquet(signal.data_path, engine="pyarrow")

    def setup(self, stage: str):
        train_datasets, val_datasets = [], []
        for signal in self.signals:
            df = self.load_signal_dataframe(signal)
            train_dataset, val_dataset = self.get_datasets_from_dataframe(df, signal)
            train_datasets.append(train_dataset)
            val_datasets.append(val_dataset)

        self.train_dataset: Dataset = ConcatDataset(train_datasets)
        self.val_dataset: Dataset = ConcatDataset(val_datasets)

        logging.info(f"Train dataset length: {len(self.train_dataset)}")
        logging.info(f"Val dataset length: {len(self.val_dataset)}")

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle_train,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
            prefetch_factor=self.prefetch_factor,
            pin_memory=self.pin_memory,
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle_val,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
            prefetch_factor=self.prefetch_factor,
            pin_memory=self.pin_memory,
        )


@define(slots=False, frozen=True)
class VicRegSignal:
    name: str
    data_path: Path
    mean: float
    std: float
    start: str
    end: str
    step: str = field(default="1min")
    size_limit: int = field(default=-1)

    @property
    def start_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.start)

    @property
    def end_ts(self) -> pd.Timestamp:
        return isoformat_to_utc_pandas_timestamp(self.end)

    @property
    def step_timedelta(self) -> pd.Timedelta:
        return pd.Timedelta(self.step)


class VicRegDataset(Dataset):
    """
    Each dataset sample is a tuple of tensor and integer. Tensor is a (seq_len, 2)-shaped tensor, where the
    two columns represent time in seconds from first value and original values in their range, respectively.
    When sequence length is larger than number of items in window, oversampling is done by repeating values.
    Integer element of the dataset sample represents signal index in the config.yaml used to train the model.
    """

    def __init__(
        self,
        datasource: SignalDatasource,
        window_size: pd.Timedelta,
        sequence_length: int,
        start_times: Union[InMemoryStartTimesDataset, CalculatedStartTimesDataset],
        signal_idx: int,
        sampling_mode: str = "stratified_train",
        min_data_count: int = 2,
    ):
        self.datasource = datasource
        self.window_size = window_size
        self.window_total_seconds = window_size.total_seconds()
        self.sequence_length = sequence_length
        self.start_times = start_times
        self.signal_idx = signal_idx
        self.sampling_mode = sampling_mode
        self.min_data_count = min_data_count

    # get_orig_data Only used in experimental - potentially dangerous with large data
    # Commented out for now - better way needs to be found to do this
    # def get_orig_data(self) -> pd.DataFrame:
    #     return self.sorted_data.set_index(pd.to_datetime(self.sorted_data.index, unit="s", utc=True)).copy()

    def get_time_selection(self, idx: int) -> Tuple[float, pd.DataFrame]:
        range_start = self.start_times[idx]
        range_end = range_start + self.window_total_seconds
        return range_start, self.datasource.get_data_in_interval(range_start, range_end)

    def __len__(self) -> int:
        return len(self.start_times)

    def __getitem__(self, idx: int) -> Optional[tuple[torch.Tensor, torch.Tensor, int]]:
        range_start, selected_data = self.get_time_selection(idx)
        if len(selected_data) < self.min_data_count:
            return None

        odd_rows = selected_data.iloc[::2]
        even_rows = selected_data.iloc[1::2]

        resampled1 = resample_to_len(odd_rows.values, self.sequence_length, self.sampling_mode)
        resampled2 = resample_to_len(even_rows.values, self.sequence_length, self.sampling_mode)

        torch1 = normalize_start_and_convert_to_torch(resampled1, range_start)
        torch2 = normalize_start_and_convert_to_torch(resampled2, range_start)

        return torch1, torch2, self.signal_idx


class NoneFilteringIterator:
    def __init__(self, signal_dataset: VicRegDataset):
        self.signal_dataset = signal_dataset
        self.current_idx = 0
        self.max_idx = len(self.signal_dataset)

    def __next__(self):
        while self.current_idx < self.max_idx:
            current_data = self.signal_dataset[self.current_idx]
            self.current_idx = self.current_idx + 1

            if current_data is None:
                continue

            return current_data

        raise StopIteration()


class VicRegDatasetWithLargeSequences(Dataset):
    def __init__(self, signal_dataset: VicRegDataset):
        self.signal_dataset = signal_dataset
        self.non_empty_iterator = NoneFilteringIterator(self.signal_dataset)

    # Test if at least one non empty value exist
    def test_nonempty_exists(self):
        try:
            next(NoneFilteringIterator(self.signal_dataset))
        except StopIteration:
            raise ValueError("Dataset must contain at least one non empty value")

    def get_next_non_empty(self) -> tuple[torch.Tensor, torch.Tensor, int]:
        try:
            return next(self.non_empty_iterator)
        except StopIteration:
            self.test_nonempty_exists()
            self.non_empty_iterator = NoneFilteringIterator(self.signal_dataset)
            return next(self.non_empty_iterator)

    def __len__(self) -> int:
        return len(self.signal_dataset)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, torch.Tensor, int]:
        current_data = self.signal_dataset[idx]
        if current_data is None:
            return self.get_next_non_empty()
        return current_data


class VicRegDataModule(L.LightningDataModule):
    def __init__(
        self,
        signals: list[VicRegSignal],
        sqlite_database_path: Optional[str] = None,
        window_size: str = "1h",
        sequence_length: int = 128,
        batch_size: int = 32,
        num_workers: int = 0,
        shuffle_train: bool = True,
        prefetch_factor: Optional[int] = None,
        pin_memory: bool = False,
        eval_mode: bool = False,
    ):
        super().__init__()
        self.window_size = pd.Timedelta(window_size)
        self.sequence_length = sequence_length
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.signals = signals
        self.shuffle_train = shuffle_train
        self.prefetch_factor = prefetch_factor
        self.pin_memory = pin_memory
        self.signal_indices = {signal.name: idx for idx, signal in enumerate(signals)}
        self.eval_mode = eval_mode

        logging.info(f"VicRegDataModule for signals {[signal.name for signal in self.signals]}")
        logging.info(f"VicRegDataModule window size: {self.window_size}")
        logging.info(f"VicRegDataModule sequence length: {self.sequence_length}")
        logging.info(f"VicRegDataModule batch_size: {self.batch_size}")
        logging.info(f"VicRegDataModule num workers: {self.num_workers}")
        logging.info(f"Working in eval mode: {self.eval_mode}")

        self.sqlite_path = Path(sqlite_database_path) if sqlite_database_path else None
        if self.sqlite_path:
            logging.info(f"SQLite data source will be used with db on path: {self.sqlite_path}")
            if self.sqlite_path.exists():
                logging.info(
                    "SQLite data source already exists. "
                    + "Signals with same name will not be reimported to database."
                    + "If you changed underlying data you need to delete database file manually"
                )
        else:
            logging.info("In memory data source will be used - please be careful with large data")

        if not self.shuffle_train:
            warnings.warn(
                "SignalsDataModule training shuffle is turned off.\n"
                + "It is recommended to have it on if you are not doing something special."
            )

        for signal in signals:
            if not signal.data_path.exists():
                raise FileNotFoundError(
                    f"{signal.name} signal cached file not found on path {signal.data_path}.\n"
                    + "Please use `generate_signal_dataframe` script to generate it first."
                )

    def import_data_to_database(self, data: pd.DataFrame, signal: VicRegSignal):
        if self.sqlite_path:
            logging.info(f"Importing data to sqlite database for signal {signal.name}")
            db_connection = sqlite3.connect(f"file:{self.sqlite_path}", uri=True)
            current_row_count = get_row_count(db_connection, signal.name)
            logging.info(f"Current row count for {signal.name} is {current_row_count}.")
            logging.info(f"Row count of data to be imported: {len(data)}")
            if current_row_count != len(data):
                logging.info("Importing data - old data in database (if any) will be replaced")
                import_dataset = transform_timestamps(data, drop_timestamps=True)
                import_dataset.to_sql(signal.name, db_connection, chunksize=1000, if_exists="replace")
            else:
                logging.info("Data in database have same length as new data - new data will NOT be imported")
                logging.info("If it is coincidence and data changed please delete database file manually")

    def get_dataset_from_dataframe(self, data: pd.DataFrame, signal: VicRegSignal) -> Dataset:
        self.import_data_to_database(data, signal)

        start_times = CalculatedStartTimesDataset(
            signal.start_ts,
            signal.end_ts,
            signal.step_timedelta,
            self.window_size,
            signal.size_limit,
        )

        logging.info(f"Train start times start: {start_times[0]}; end: {start_times[-1]}")

        datasource: SignalDatasource
        if self.sqlite_path:
            datasource = SQLiteDatasource(self.sqlite_path, signal.name)
        else:
            datasource = InMemoryDatasource(transform_timestamps(data))

        if self.eval_mode:
            raw_train_dataset = SignalDataset(
                datasource,
                self.window_size,
                self.sequence_length,
                start_times,
                self.signal_indices[signal.name],
                "live",
            )
            return SignalDatasetForEmbeddingsGeneration(raw_train_dataset)
        else:
            return VicRegDatasetWithLargeSequences(
                VicRegDataset(
                    datasource,
                    self.window_size,
                    self.sequence_length,
                    start_times,
                    self.signal_indices[signal.name],
                )
            )

    def load_signal_dataframe(self, signal: VicRegSignal) -> pd.DataFrame:
        return pd.read_parquet(signal.data_path, engine="pyarrow")

    def setup(self, stage: str):
        train_datasets = []
        for signal in self.signals:
            df = self.load_signal_dataframe(signal)
            train_datasets.append(self.get_dataset_from_dataframe(df, signal))

        self.train_dataset: Dataset = ConcatDataset(train_datasets)

        logging.info(f"Train dataset length: {len(self.train_dataset)}")

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle_train,
            num_workers=self.num_workers,
            persistent_workers=self.num_workers > 0,
            prefetch_factor=self.prefetch_factor,
            pin_memory=self.pin_memory,
        )
