from functools import partial
from typing import Callable, Optional

import numpy as np
import pandas as pd

from dbfcore.dataset.signals.stockrod import (
    get_cleaned_stockrod_data_bf1,
    get_cleaned_stockrod_data_bf2,
    get_cleaned_stockrod_data_bf3,
)


def filter_outliers(
    df: pd.DataFrame, column: str, lower: Optional[float] = None, upper: Optional[float] = None
) -> pd.DataFrame:
    if lower is not None:
        df = df[df[column] > lower]
    if upper is not None:
        df = df[df[column] < upper]

    return df


def get_cleaned_pi_signal_data(
    pi_data: pd.DataFrame,
    recalibration_start_margin: pd.Timedelta,
    recalibration_duration: pd.Timedelta,
    extreme_grad_threshold: float,
    lower_outlier_threshold: Optional[float] = None,
    upper_outlier_threshold: Optional[float] = None,
) -> pd.DataFrame:
    pi_data = pi_data.copy()
    if len(pi_data) < 2:
        return pi_data

    signal_name = pi_data.columns[0]
    pi_data = pi_data[~pi_data.index.duplicated()]
    pi_data = pi_data[~pi_data[signal_name].isna()]

    if len(pi_data) < 2:
        return pi_data

    pi_data["seconds"] = (pi_data.index - pi_data.index[0]).total_seconds()
    pi_data["grad"] = abs(np.gradient(pi_data[signal_name], pi_data["seconds"]))
    pi_data["Timestamp"] = pi_data.index
    pi_data["exclude"] = 0

    extreme_grad_timestamps = pi_data[pi_data["grad"] >= extreme_grad_threshold]["Timestamp"].tolist()
    for tstp in extreme_grad_timestamps:
        pi_data.loc[tstp - recalibration_start_margin : tstp + recalibration_duration, "exclude"] = 1

    cleaned_data = pi_data[pi_data["exclude"] != 1][signal_name].to_frame()
    filtered_data = filter_outliers(
        cleaned_data, signal_name, lower_outlier_threshold, upper_outlier_threshold
    )

    return filtered_data


# TODO runmodels finalization - delete this when runmodels.py will be finished
def get_pi_cleaning_fn(signal_name: str) -> Callable[[pd.DataFrame], pd.DataFrame]:
    if signal_name in ["bf1_stockrod1_distance_m", "bf1_stockrod2_distance_m"]:
        return get_cleaned_stockrod_data_bf1
    elif signal_name in ["bf2_stockrod1_distance_m", "bf2_stockrod2_distance_m", "bf2_stockrod3_distance_m"]:
        return get_cleaned_stockrod_data_bf2
    elif signal_name in ["bf3_stockrod1_distance_m", "bf3_stockrod2_distance_m"]:
        return get_cleaned_stockrod_data_bf3
    elif signal_name == "bf1_topgasco_chem_pct":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.2,
        )
    elif signal_name == "bf1_topgasco2_chem_pct":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.2,
        )
    elif signal_name in ["bf2_topgasco2_chem_pct", "bf3_topgasco2_chem_pct"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("10m"),
            extreme_grad_threshold=0.005,
        )
    elif signal_name == "bf1_topgash2_chem_pct":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("10m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.03,
        )
    elif signal_name in ["bf2_topgash2_chem_pct", "bf3_topgash2_chem_pct"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("15m"),
            recalibration_duration=pd.Timedelta("30m"),
            extreme_grad_threshold=0.005,
        )
    elif signal_name == "bf1_hotblast_flow_Nm3h":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("5m"),
            recalibration_duration=pd.Timedelta("5m"),
            extreme_grad_threshold=2000,
        )
    elif signal_name == "bf1_hotblasto2_flow_Nm3h":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("2m"),
            recalibration_duration=pd.Timedelta("2m"),
            extreme_grad_threshold=500,
            lower_outlier_threshold=2000,
        )
    elif signal_name == "bf1_hotblastmoisture_flow_gNm3":
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("15m"),
            recalibration_duration=pd.Timedelta("15m"),
            extreme_grad_threshold=0.4,
            lower_outlier_threshold=0,
        )
    elif signal_name in ["bf2_hotblast_flow_Nm3h", "bf3_hotblast_flow_Nm3h"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=100,
        )
    elif signal_name in ["bf2_hotblast_temp_C", "bf3_hotblast_temp_C"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("0.5m"),
            recalibration_duration=pd.Timedelta("0.5m"),
            extreme_grad_threshold=0.1,
        )
    elif signal_name in ["bf2_hotblastmoisture_flow_gNm3", "bf3_hotblastmoisture_flow_gNm3"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("5m"),
            recalibration_duration=pd.Timedelta("5m"),
            extreme_grad_threshold=0.1,
        )
    elif signal_name in ["bf2_hotblasto2_flow_Nm3h", "bf3_hotblasto2_flow_Nm3h"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=20,
        )
    elif signal_name in ["bf2_hotblastpci_flow_kgh", "bf3_hotblastpci_flow_kgh"]:
        return partial(
            get_cleaned_pi_signal_data,
            recalibration_start_margin=pd.Timedelta("1m"),
            recalibration_duration=pd.Timedelta("1m"),
            extreme_grad_threshold=50,
        )
    else:
        return lambda x: x
