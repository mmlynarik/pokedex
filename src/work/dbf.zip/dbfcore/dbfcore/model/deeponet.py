from typing import Iterable

import torch
from torch import nn

from dbfcore.model.lipschitz import LipMLP


class DeepONet(nn.Module):
    def __init__(self, latent_rep_size: int, hidden_sizes: Iterable[int], rep_size: int):
        super().__init__()
        self.branch_net = LipMLP((latent_rep_size, *hidden_sizes, rep_size))
        self.trunk_net = LipMLP((1, *hidden_sizes, rep_size))
        self.bias = nn.Parameter(torch.zeros((1), requires_grad=True))

    # latent rep is Batch x Latent rep size
    # eval points is Batch x Points
    # return tensor is Batch x Points
    def forward(self, latent_rep, eval_points):
        branch = self.branch_net(latent_rep)
        trunk = self.trunk_net(eval_points.unsqueeze(2))
        dotproduct = branch.unsqueeze(1) * trunk
        return dotproduct.sum(dim=2) + self.bias

    @property
    def latent_dim(self):
        return self.branch_net.layers[0].weight.size(1)
