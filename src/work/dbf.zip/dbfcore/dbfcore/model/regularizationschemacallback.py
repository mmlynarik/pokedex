import math
from typing import Any

import attrs
import torch
from lightning.pytorch.callbacks.callback import Callback
from torch import nn

MAX_WEIGHT_CAP = 1.0


def assert_float(value: Any):
    if not isinstance(value, float):
        raise TypeError("Value should be float (tensors are not wanted here)")


@attrs.define(slots=False, frozen=True)
class RegularizationsWeights:
    """
    Each attribute represents user-defined regularization and its integer weight from which actual
    regularization loss weight will be calculated in the RegularizationSchema callback.
    """

    covariance: int
    variance: int
    kldiv: int
    lip_trunk: int
    lip_decoder: int
    negative_value: int


@attrs.define(slots=False, frozen=True)
class RegularizationRegime:
    """
    Strength attribute represents fraction of primary (reconstruction) loss that is made up of regularization
    losses.
    """

    weights: RegularizationsWeights
    strength: float

    @property
    def weights_as_dict(self) -> dict[str, int]:
        return {k: v for k, v in self.weights.__dict__.items()}

    def get_relative_weight(self, regularization: str):
        return self.weights_as_dict[regularization] / sum(self.weights_as_dict.values())


class ScalarBuffer(nn.Module):
    def __init__(self, buffer_size: int, device=None, dtype=None):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.buffer: torch.Tensor
        self.register_buffer("buffer", torch.zeros(buffer_size, **factory_kwargs))

    def push(self, value: torch.Tensor):
        # If you consider changes in this implementation do performance testing first
        self.buffer = self.buffer.roll(1)
        self.buffer[0] = value


# TODO make somehow explicit which parameters are required - probably make it module
# Maybe callback is not the best interface for it as callback should be usable with all models
#
# Currently required properties are:
# | kldiv_loss_weight
# | lip_decoder_loss_weight
# | lip_trunk_loss_weight
# | variance_loss_weight
# | covariance_loss_weight
# | negative_value_loss_weight
#
# Besides that model must log:
# | train/reconstruction_loss
# | train/kldiv_loss
# | train/lip_decoder_loss
# | train/lip_trunk_loss
# | train/variance_loss
# | train/covariance_loss
# | train/negative_value_loss
#
# Also set_regularization_loss_weight method is required
class RegularizationSchema(Callback):
    def __init__(
        self,
        min_delta: float,
        regularization_regimes: list[RegularizationRegime],
        check_every_n_steps: int = 100,
        cooldown_period_n_steps: int = 1000,
    ):
        self.check_every_n_steps = check_every_n_steps
        self.min_delta = min_delta
        self.cooldown_period_n_steps = cooldown_period_n_steps
        self.regimes = regularization_regimes
        self.current_regime: int = 0
        # Will be set in first on_train_batch_end to set correctly on resume from checkpoint
        # In on_fit_start global_step is 0
        self.current_cooldown_period_end_step = -1
        # Initialized in on fit start because here we do not know device used
        self.last_main_losses: ScalarBuffer
        self.half_point = self.cooldown_period_n_steps // 2

        if cooldown_period_n_steps % check_every_n_steps != 0:
            raise ValueError("Attribute cooldown_period_n_steps must be a multiple of check_every_n_steps.")

    def apply_regime(self, trainer, pl_module, main_loss: float, regime: RegularizationRegime):
        assert_float(main_loss)

        target_losses_sum = main_loss * regime.strength
        for regularization in regime.weights_as_dict:
            full_reg_name = f"train/{regularization}_loss"
            current_loss = trainer.callback_metrics[full_reg_name].detach().cpu().item()
            target_loss = target_losses_sum * regime.get_relative_weight(regularization)
            loss_weight = target_loss / (current_loss + 0.0000001)  # eps for numerical stability

            if (not math.isfinite(loss_weight)) or (loss_weight > MAX_WEIGHT_CAP):
                loss_weight = MAX_WEIGHT_CAP

            pl_module.set_regularization_loss_weight(f"{regularization}_loss_weight", loss_weight)
            self.log(f"{full_reg_name}_weight", loss_weight)  # type: ignore

    def on_fit_start(self, trainer, pl_module):
        if not self.regimes:
            return
        for regularization in self.regimes[0].weights_as_dict:
            name = f"{regularization}_loss_weight"
            pl_module.logger.experiment.add_scalar(f"train/{name}", getattr(pl_module, name))

        # HACK to initialize callback parameters on same device as module
        self.last_main_losses = ScalarBuffer(self.cooldown_period_n_steps, pl_module.device, pl_module.dtype)

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        if self.current_regime >= len(self.regimes):
            return

        if self.current_cooldown_period_end_step == -1:
            self.current_cooldown_period_end_step = pl_module.global_step + self.cooldown_period_n_steps - 1

        reconstruction_loss_name = "train/reconstruction_loss"

        primary_loss = trainer.callback_metrics[reconstruction_loss_name].detach()
        self.last_main_losses.push(primary_loss)

        if pl_module.global_step % self.check_every_n_steps != 0:
            return

        if pl_module.global_step <= self.current_cooldown_period_end_step:
            return

        self.log("train/regularization_step", self.current_regime)  # type: ignore

        current_buffer = self.last_main_losses.buffer

        total_mean = current_buffer.mean()
        half_mean = current_buffer[: self.half_point].mean()
        half_w_total_w_diff = half_mean - total_mean

        self.log("train/total_window", total_mean)  # type: ignore
        self.log("train/half_window", half_mean)  # type: ignore
        self.log("train/half_w_total_w_diff", half_w_total_w_diff)  # type: ignore

        if half_w_total_w_diff > self.min_delta:
            regularization_regime = self.regimes[self.current_regime]
            self.apply_regime(trainer, pl_module, primary_loss.cpu().item(), regularization_regime)
            self.current_cooldown_period_end_step = pl_module.global_step + self.cooldown_period_n_steps - 1
            self.current_regime += 1
