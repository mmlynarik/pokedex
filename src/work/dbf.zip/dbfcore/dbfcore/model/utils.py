import torch
from torch import nn


class FixedInputNormalizer(nn.Module):
    def __init__(self, mean, std, device=None, dtype=None):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()

        if (std == 0).any():
            raise ValueError("None of the standard deviation values must not be 0.")

        self.register_buffer("mean", mean.clone().detach().to(**factory_kwargs))
        self.register_buffer("std", std.clone().detach().to(**factory_kwargs))
        self.dim_size = self.mean.size(0)

    def forward(self, x):
        only_last_dim = x.view(-1, self.dim_size)
        normalized = (only_last_dim - self.mean) / self.std
        return normalized.view(x.size())

    def denormalize(self, x):
        only_last_dim = x.view(-1, self.dim_size)
        denormalized = (only_last_dim * self.std) + self.mean
        return denormalized.view(x.size())


class FixedInputNormalizer2(nn.Module):
    def __init__(self, means: torch.Tensor, stds: torch.Tensor, device=None, dtype=None):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.means: torch.Tensor
        self.stds: torch.Tensor
        self.register_buffer("means", means.clone().detach().to(**factory_kwargs))
        self.register_buffer("stds", stds.clone().detach().to(**factory_kwargs))
        self.dim_size = self.means.size(1)

    def forward(self, x, indices):
        mean = self.means[indices].unsqueeze(1)
        std = self.stds[indices].unsqueeze(1)
        only_last_dim = x.view(x.size(0), -1, self.dim_size)
        normalized = (only_last_dim - mean) / std
        return normalized.view(x.size())

    def denormalize(self, x, indices):
        mean = self.means[indices].unsqueeze(1)
        std = self.stds[indices].unsqueeze(1)
        only_last_dim = x.view(x.size(0), -1, self.dim_size)
        denormalized = (only_last_dim * std) + mean
        return denormalized.view(x.size())


def index_split(tensor, indices, all_idxs):
    counts = torch.count_nonzero(indices == all_idxs, dim=1)
    sorter = torch.argsort(indices)
    return torch.split(tensor[sorter], counts.tolist())


class PerSignalStatsBuffer(nn.Module):
    def __init__(self, signal_count: int, buffer_size: int, value_size: int, device=None, dtype=None):
        factory_kwargs = {"device": device, "dtype": dtype}
        super().__init__()
        self.buffer: torch.Tensor
        self.all_idxs: torch.Tensor
        self.register_buffer("buffer", torch.zeros(signal_count, buffer_size, value_size, **factory_kwargs))
        self.register_buffer(
            "all_idxs", torch.arange(signal_count, **factory_kwargs).reshape(signal_count, 1)
        )
        self.buffer_size = buffer_size
        self.signal_count = signal_count

    def push_all_signals(self, metric: torch.Tensor, indices: torch.Tensor):
        values = index_split(metric.detach(), indices.detach(), self.all_idxs)

        for i, val in enumerate(values):
            self.push_to_buffer(i, val)

    def push_to_buffer(self, signal_id: int, value: torch.Tensor):
        input_size = value.size(0)
        buffer_slicing = (slice(input_size - self.buffer_size, None),) + (slice(None),)
        self.buffer[signal_id] = torch.cat((self.buffer[signal_id][buffer_slicing], value), dim=0)[
            -self.buffer_size :
        ]

    def per_signal_mean(self):
        return self.buffer.mean(dim=(1, 2))

    def per_signal_abs_mean(self):
        return self.buffer.abs().mean(dim=(1, 2))

    def per_signal_abs_quantiles(self, quantiles: torch.Tensor):
        return (
            self.buffer.abs().reshape(self.signal_count, -1).quantile(quantiles, interpolation="lower", dim=1)
        )
