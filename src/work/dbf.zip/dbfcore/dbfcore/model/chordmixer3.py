import torch
from torch import nn


def prepare_rotation(sequence_len: int, data_size: int, track_size: int) -> torch.Tensor:
    # Shape: 1 x S x D
    all_indexes = torch.arange(0, sequence_len).unsqueeze(0).repeat(data_size, 1).T.unsqueeze(0)
    indices_per_track = torch.split(tensor=all_indexes, split_size_or_sections=track_size, dim=-1)

    rotated_tracks = [indices_per_track[0]]
    for i in range(1, len(indices_per_track)):
        offset = -(2 ** (i - 1))
        rotated_tracks.append(torch.roll(indices_per_track[i], shifts=offset, dims=1))

    return torch.cat(rotated_tracks, -1)


class RotateChord3(nn.Module):
    """
    A PyTorch module that performs a parameter-free rotation of tracks within token embeddings.

    This module can be used to augment or modify the input data in a data-driven manner. The rotation is
    performed jointly for all sequences in a batch and is based on powers of 2 (Chord protocol).

    Args:
        track_size (int): The size of tracks to be rotated.
    """

    def __init__(self, sequence_len: int, data_size: int, track_size: int):
        super().__init__()

        self.base_rotation: torch.Tensor
        self.register_buffer(
            "base_rotation", prepare_rotation(sequence_len, data_size, track_size), persistent=False
        )

        self.track_size = track_size

    def forward(self, x):
        return torch.gather(x, 1, self.base_rotation.repeat(x.size(0), 1, 1))


class TwoLayerPerceptron(nn.Module):
    """
    A simple Two-Layer Perceptron (MLP) module in PyTorch.

    Args:
    in_features (int): Number of input features.
    hidden_features (int, optional): Hidden layer size.
    out_features (int, optional): Output size.
    """

    def __init__(self, in_features: int, hidden_features: int, out_features: int):
        super().__init__()

        self.model = nn.Sequential(
            nn.Linear(in_features, hidden_features),
            nn.LayerNorm(hidden_features, elementwise_affine=False),
            nn.ReLU(),
            nn.Linear(hidden_features, out_features),
        )

    def forward(self, x):
        return self.model(x)


class ChordMixerBlock3(nn.Module):
    """
    A PyTorch module implementing the ChordMixerBlock.

    This module combines two main steps in the ChordMixer layer: Rotate and Mix.
    The dropout between too is added.

    Args:
        embedding_size (int): The size of the token embeddings.
        track_size (int): The size of tracks to be rotated.
    """

    def __init__(self, seq_len: int, embedding_size: int, track_size: int):
        super().__init__()

        self.chord_mixer = nn.Sequential(
            TwoLayerPerceptron(embedding_size, embedding_size * 2, embedding_size),
            RotateChord3(seq_len, embedding_size, track_size),
        )

    def forward(self, x):
        return x + self.chord_mixer(x)


class AveragePooling(nn.Module):
    """
    Returns average through sequence length
    """

    def __init__(self):
        super().__init__()

    def forward(self, x):
        return torch.mean(x, dim=1)


class ChordMixer3(nn.Module):
    """
    The ChordMixer model. Encoder is a stack of ChordMixer blocks. Decoder a global average pooling, followed by a linear layer.

    Args:
        input_size (int): The input size of the embedding layer.
        output_size (int): The output size of the decoder layer.
        seq_len (int): The sequence length in the data.
        track_size (int): The size of tracks to be rotated.
    """

    def __init__(
        self,
        input_size: int,
        output_size: int,
        seq_len: int,
        track_size: int,
    ):
        super().__init__()
        n_layers = int(torch.ceil(torch.log2(torch.tensor(seq_len))).long().item())
        embedding_size = int((n_layers + 1) * track_size)

        embedding = nn.Linear(input_size, embedding_size)

        encoder_blocks = [ChordMixerBlock3(seq_len, embedding_size, track_size) for _ in range(n_layers)]
        pooling = AveragePooling()
        decoder = TwoLayerPerceptron(embedding_size, embedding_size * 2, output_size)

        self.model = nn.Sequential(embedding, *encoder_blocks, pooling, decoder)

    def forward(self, x):
        return self.model(x)
