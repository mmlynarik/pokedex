from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Iterator, Union

import numpy as np
import pandas as pd
import torch
import yaml  # type: ignore
from pandas import Timestamp
from torch import Tensor

from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from dbfcore.model.vicregdecoder import VicRegDecoder
from dbfcore.model.vicregtraining import RealVicReg
from dbfcore.predictionmodel.model import PredictionModel

EMBEDDING_MODEL = SignalVAESimple2 | RealVicReg
LIGHTNING_MODEL = EMBEDDING_MODEL | PredictionModel | VicRegDecoder


def is_utc(timestamp: Union[Timestamp, datetime]) -> bool:
    offset = timestamp.utcoffset()
    if offset is None:
        return False
    return offset.total_seconds() == 0


def flat_tensor_to_float32_bytes(flat_tensor: Tensor) -> bytes:
    if flat_tensor.dim() != 1:
        raise ValueError("Only 1D tensors (vectors) can be saved in this way")
    return flat_tensor.numpy().astype(np.float32).tobytes()


def float32_bytes_to_flat_tensor(data: bytes) -> Tensor:
    return torch.from_numpy(np.frombuffer(data, dtype=np.float32))


def is_proba(instance, attribute, value):
    if not 0 <= value <= 1:
        raise ValueError("Value has to be probability between 0 and 1.")


def load_yaml_into_dict(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@lru_cache
def load_lightning_model_from_path_cached(model_class: type[LIGHTNING_MODEL], path: str):
    return load_lightning_model_from_path(model_class, path)


def load_lightning_model_from_path(model_class: type[LIGHTNING_MODEL], path: str):
    return model_class.load_from_checkpoint(path)


def partition_range_into_intervals(
    start: pd.Timestamp, end: pd.Timestamp, interval: pd.Timedelta
) -> Iterator[tuple[pd.Timestamp, pd.Timestamp]]:
    if end - start <= interval:
        yield start, end
        return

    timestamps = pd.date_range(start, end, freq=interval, inclusive="left").append(pd.Index([end]))
    for idx in range(len(timestamps) - 1):
        yield timestamps[idx], timestamps[idx + 1]
