import argparse
import logging
from collections import defaultdict

import numpy as np
import yaml  # type: ignore

from dbfcore.model.normalizerparams import get_data_for_normalizer_params_calculation
from dbfcore.utils import load_yaml_into_dict

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def aggregate_signal_names(signal_names: list[str], to_be_aggregated: list[str]) -> list[set[str]]:
    if not to_be_aggregated:
        return []
    aggregated_signals: dict[str, set] = defaultdict(set, {item: set() for item in to_be_aggregated})
    for signal_name in signal_names:
        added = []
        for item in to_be_aggregated:
            if item in signal_name:
                aggregated_signals[item].add(signal_name)
                added.append(item)
        if len(added) > 1:
            raise ValueError(
                f"Signal name {signal_name} was assigned to two different signal aggregations - {added}. Please select more specific name for aggregate argument"
            )

    return list(aggregated_signals.values())


def get_signal_config_from_list(name: str, signal_configs: list[dict]) -> dict:
    return next(signal_config for signal_config in signal_configs if signal_config["name"] == name)


def get_signal_normalizer_params_for_groups(
    aggregated_signal_names: list[set[str]], config: dict
) -> dict[str, tuple[float, float]]:
    signals_normalizer_params: dict[str, tuple[float, float]] = {}
    if not aggregated_signal_names:
        return signals_normalizer_params
    for group in aggregated_signal_names:
        group_train_data = np.array([])
        for signal_name in group:
            signal_config = get_signal_config_from_list(signal_name, config["data"]["signals"])
            signal_train_data = get_data_for_normalizer_params_calculation(
                signal_config["name"], signal_config["data_path"], signal_config["train_size"]
            )
            group_train_data = np.concatenate([group_train_data, signal_train_data])
        group_mean, group_std = group_train_data.mean(), group_train_data.std()
        for signal_name in group:
            signals_normalizer_params[signal_name] = (group_mean, group_std)
    return signals_normalizer_params


def update_config_with_normalizers_params(config_path: str, to_be_aggregated: list[str]):
    config = load_yaml_into_dict(config_path)
    signal_names = [signal["name"] for signal in config["data"]["signals"]]
    aggregated_signal_names = aggregate_signal_names(signal_names, to_be_aggregated)
    signals_normalizer_params = get_signal_normalizer_params_for_groups(aggregated_signal_names, config)

    for idx, signal in enumerate(config["data"]["signals"]):
        if signal["name"] not in signals_normalizer_params:
            train_data = get_data_for_normalizer_params_calculation(
                signal["name"], signal["data_path"], signal["train_size"]
            )
            signals_normalizer_params[signal["name"]] = (train_data.mean(), train_data.std())
        config["data"]["signals"][idx]["mean"] = float(signals_normalizer_params[signal["name"]][0])
        config["data"]["signals"][idx]["std"] = float(signals_normalizer_params[signal["name"]][1])

    with open(config_path, "w") as f:
        yaml.dump(config, f, sort_keys=False)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Update autoencoder training configuration file with normalizer params."
    )
    parser.add_argument(
        "-c",
        "--config",
        help="Path to config.yaml file that should be updated with normalzier params",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-a",
        "--to-be-aggregated",
        help="""List of signal names' roots (e.g. 'chargec' for bf1_chargec_flow_kgh) which should identify signals that should be aggregated and whose params should be identical across furnaces""",
        nargs="+",
        type=str,
    )
    return parser.parse_args()


def main():
    args = parse_args()
    logging.info("Calculating normalizer params and saving them into config.yaml")
    update_config_with_normalizers_params(args.config, args.to_be_aggregated)


if __name__ == "__main__":
    main()
