import argparse
import logging
from typing import Optional

import torch
from lightning.fabric.utilities.exceptions import MisconfigurationException
from lightning.pytorch.cli import LightningCLI
from torch.utils.data import DataLoader
from tqdm import tqdm

from dbfcore.model.datamodule.pisignal import SignalsDataModule2, VicRegDataModule
from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from dbfcore.model.vicregtraining import RealVicReg
from dbfcore.scripts.trainrealvicreg import RealVicRegCLI
from dbfcore.scripts.trainsignalvaesimple2 import SignalVAESimpleCLI

logging.basicConfig(level=logging.INFO)


def get_embeddings(
    model: RealVicReg | SignalVAESimple2, dataloader: DataLoader, desc: Optional[str] = None
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    embeddings = []
    masks = []
    start_times_all = []
    all_indices = []
    with torch.no_grad():
        # TODO: odstranit TQDM (teraz nechavame kvoli zlozitosti riesenia)
        for batch in tqdm(dataloader, desc="" if desc is None else desc, disable=desc is None):
            inputs, indices, mask, start_times = batch
            inputs = inputs.to(model.device)
            indices = indices.to(model.device)

            masks.append(mask)
            start_times_all.append(start_times)
            all_indices.append(indices.detach().cpu())

            embedding = model.encode_and_project(inputs, indices)
            embeddings.append(embedding.detach().cpu())
    return torch.cat(embeddings), torch.cat(masks), torch.cat(start_times_all), torch.cat(all_indices)


def parse_args():
    parser = argparse.ArgumentParser(
        prog="Generate embeddings",
        description="Generate embeddings used as features for the prediction model.",
    )
    parser.add_argument(
        "-c",
        "--configpath",
        help="Path to config file for model training.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-m",
        "--modelpath",
        help="Path to the model checkpoint. It will be used to name the file with embeddings.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-n",
        "--name",
        help="The name of the file with embeddings.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--modeltype",
        help="The name of the file with embeddings.",
        choices=["vicreg", "signalvaesimple"],
        type=str,
        required=True,
    )

    return parser.parse_args()


def main():
    args = parse_args()

    cli: LightningCLI

    if args.modeltype == "vicreg":
        cli = RealVicRegCLI(
            RealVicReg,
            VicRegDataModule,
            args=["-c", args.configpath, "--data.eval_mode", "true"],
            run=False,
        )
    elif args.modeltype == "signalvaesimple":
        cli = SignalVAESimpleCLI(
            SignalVAESimple2,
            SignalsDataModule2,
            args=["-c", args.configpath, "--data.eval_mode", "true"],
            run=False,
        )

    device = torch.device("cuda" if "CUDA" in str(type(cli.trainer.accelerator)) else "cpu")
    model = cli.model
    datamodule = cli.datamodule

    model.load_state_dict(torch.load(args.modelpath, map_location=device)["state_dict"])
    model = model.to(device).eval()
    datamodule.setup("")

    results = []

    try:
        results.append(get_embeddings(model, datamodule.train_dataloader(), "Train"))
    except MisconfigurationException:
        logging.info("Train dataloader not configured.")
    except Exception as e:
        raise Exception(e)
    try:
        results.append(get_embeddings(model, datamodule.val_dataloader(), "Val"))
    except MisconfigurationException:
        logging.info("Val dataloader not configured.")
    except Exception as e:
        raise Exception(e)

    results_dict = {"signal_normalizers_params": model.signal_normalizers_params}

    for j, key in enumerate(["embeddings", "masks", "start_times", "indices"]):
        results_dict[key] = torch.cat([results[i][j] for i in range(len(results))])

    torch.save(results_dict, args.name)


if __name__ == "__main__":
    main()
