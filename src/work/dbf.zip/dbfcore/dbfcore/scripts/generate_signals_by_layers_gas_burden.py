import argparse
import logging
from datetime import datetime
from pathlib import Path

import pandas as pd

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.scripts.generate_signal_dataframe import get_signal_group_loader
from dbfcore.settings import DATAMODULE_CACHE
from dbfcore.utils import partition_range_into_intervals

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

DEFAULT_TIME_SHIFT_OF_GASES_SEC: int = 300
"""Default value for gas backward time shift in seconds"""

DEFAULT_RESAMPLE_RULE_VALUE: str = "300s"
"""Default time interval (resample_rule) for which we want to resample the data"""

DEFAULT_BATCH_SIZE_IN_HOURS: float = 5.0 * 24
"""Default value of batch size in hours, the interval at which the signal will be loaded"""

H2O_SIGNAL_PERC: float = 4.0
"""The H2O signal in percent. The signal is currently a constant 4%, but this needs to be refined in the future."""

CHARGE_SIGNAL_TEMP_C: float = 25.0
"""Charge temperature signal - Initially as a constant 25°C, later we might change it."""


def parse_args():
    parser = argparse.ArgumentParser(description="Generate signals by layers for gas and burden")
    parser.add_argument(
        "-s",
        "--start",
        help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        required=True,
    )
    parser.add_argument(
        "-e",
        "--end",
        help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        required=True,
    )
    parser.add_argument(
        "-f",
        "--furnace_id",
        help="Blast furnace number",
        type=int,
        required=True,
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        help="Path to a output dataframe directory",
        type=str,
        default=DATAMODULE_CACHE,
    )
    parser.add_argument(
        "-t",
        "--time-shift-of-gases",
        help="Backward time shift of gases in seconds",
        type=int,
        default=DEFAULT_TIME_SHIFT_OF_GASES_SEC,
    )
    parser.add_argument(
        "-b",
        "--batch-size-in-hours",
        help="Batch size in hours, the interval at which the signal will be loaded",
        type=float,
        default=DEFAULT_BATCH_SIZE_IN_HOURS,
    )

    return parser.parse_args()


def generate_signal_as_dataframe(
    start: pd.Timestamp, end: pd.Timestamp, signal_group_name: str, datasources: DataSources
) -> pd.DataFrame:
    """Generates the signal as a dataframe."""
    signal_group_loader = get_signal_group_loader(signal_group_name, datasources)
    df = signal_group_loader(start, end)
    return df


def get_only_output_columns(df: pd.DataFrame, output_columns: list[str]) -> pd.DataFrame:
    """Selects only the signals we need. Some signals we do not need."""
    return df[[col for col in output_columns if col in df.columns]]


def get_resample_signal(
    df: pd.DataFrame, func: str, resample_rule: str = DEFAULT_RESAMPLE_RULE_VALUE
) -> pd.DataFrame:
    """Resamples the signal, computing either the average (func='mean') or the sum (func='sum')."""
    if df.empty:
        return df
    aggregators = {"sum": lambda x: x.sum(min_count=1), "mean": lambda x: x.mean()}
    return df.resample(resample_rule, label="right", closed="right").agg(aggregators[func.lower()])


def shift_frame_back_in_time(df: pd.DataFrame, time_shift_of_gases_in_sec: int) -> pd.DataFrame:
    """Shifts the signal back in time by a given number of seconds."""
    if df.empty:
        return df
    df.index = df.index - pd.Timedelta(seconds=time_shift_of_gases_in_sec)
    return df


def add_nitrogen_n2_signal(df: pd.DataFrame, new_signal_name: str) -> pd.DataFrame:
    """Adds a nitrogen N2 signal (to the end of DataFrame) as 100% minus the sum of the other gases."""
    if df.empty:
        return df
    df[new_signal_name] = 100 - df.sum(axis=1, skipna=False)
    return df


def add_h2o_signal(df: pd.DataFrame, new_signal_name: str) -> pd.DataFrame:
    """Adds a H2O signal in percent (to the end of DataFrame) - The H2O signal is currently a constant H2O_SIGNAL_PERC, but this needs to be refined in the future."""
    df[new_signal_name] = H2O_SIGNAL_PERC
    return df


def recalc_gas_composition(df: pd.DataFrame, h2o_signal_name: str) -> pd.DataFrame:
    """Recalculate the gas composition for water content, because we measure the composition of dry gas."""
    if df.empty:
        return df
    columns_to_adjust = df.columns.difference([h2o_signal_name])
    correction_factor = 1 - df[h2o_signal_name] / 100
    df[columns_to_adjust] = df[columns_to_adjust].mul(correction_factor, axis=0)
    return df


def add_charge_temp_signal(df: pd.DataFrame, new_signal_name: str) -> pd.DataFrame:
    """Adds a charge temperature signal (to the beginning of DataFrame) - Initially as a constant CHARGE_SIGNAL_TEMP_C, later we might change it."""
    df.insert(0, new_signal_name, CHARGE_SIGNAL_TEMP_C)
    return df


def get_close_interval_from_dataframe(
    df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    """Selects an close interval from the DataFrame."""
    if df.empty:
        return df
    return df.loc[(df.index >= start) & (df.index <= end)]


def load_signal_by_layers_one_batch(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    time_shift_of_gases_in_sec: int = DEFAULT_TIME_SHIFT_OF_GASES_SEC,
) -> pd.DataFrame:
    """Loads the signals by layers for one batch"""
    output_gas_columns = [
        f"bf{furnace_id}_uptake_temp_C",
        f"bf{furnace_id}_top_pressure_kPa",
        f"bf{furnace_id}_topgasco_chem_pct",
        f"bf{furnace_id}_topgasco2_chem_pct",
        f"bf{furnace_id}_topgash2_chem_pct",
    ]

    uptake_df = generate_signal_as_dataframe(start, end, f"bf{furnace_id}_uptake", datasources)
    uptake_df = get_only_output_columns(uptake_df, output_gas_columns)
    uptake_df = get_resample_signal(uptake_df, "mean")

    pressure_df = generate_signal_as_dataframe(start, end, f"bf{furnace_id}_pressure", datasources)
    pressure_df = get_only_output_columns(pressure_df, output_gas_columns)
    pressure_df = get_resample_signal(pressure_df, "mean")

    topgas_signal_group_name = f"bf{furnace_id}_topgas"
    topgas_df = generate_signal_as_dataframe(start, end, topgas_signal_group_name, datasources)
    topgas_df = get_only_output_columns(topgas_df, output_gas_columns)
    topgas_df = shift_frame_back_in_time(topgas_df, time_shift_of_gases_in_sec)
    topgas_df = get_resample_signal(topgas_df, "mean")
    topgas_df = add_nitrogen_n2_signal(topgas_df, f"{topgas_signal_group_name}n2_chem_pct")

    topgas_h2o_signal_name = f"{topgas_signal_group_name}h2o_chem_pct"
    topgas_df = add_h2o_signal(topgas_df, topgas_h2o_signal_name)
    topgas_df = recalc_gas_composition(topgas_df, topgas_h2o_signal_name)

    charge_df = generate_signal_as_dataframe(start, end, f"bf{furnace_id}_chargelayers_chems", datasources)
    charge_df.index.name = "Timestamp"
    charge_df = get_resample_signal(charge_df, "sum")

    charge_df = add_charge_temp_signal(charge_df, f"bf{furnace_id}_charge_temp_C")

    df = pd.concat([uptake_df, pressure_df, topgas_df, charge_df], axis=1, join="outer").sort_index()

    return df


def load_signal_by_layers(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    datasources: DataSources,
    time_shift_of_gases_in_sec: int = DEFAULT_TIME_SHIFT_OF_GASES_SEC,
    batch_size_in_hours: float = DEFAULT_BATCH_SIZE_IN_HOURS,
) -> pd.DataFrame:
    """Loads the signals by layers in batches"""
    adjusted_start = pd.Timestamp(start).ceil(DEFAULT_RESAMPLE_RULE_VALUE)
    adjusted_end = pd.Timestamp(end).floor(DEFAULT_RESAMPLE_RULE_VALUE)

    batch_size = pd.Timedelta(hours=batch_size_in_hours)
    intervals = list(partition_range_into_intervals(adjusted_start, adjusted_end, batch_size))

    dfs = []
    for i in range(len(intervals)):
        batch_start = intervals[i][0]
        batch_end = intervals[i][1]
        logging.info(
            f"... loading batch {i} from {batch_start} to {batch_end} (range={batch_end-batch_start})"
        )
        df_batch = load_signal_by_layers_one_batch(
            start=batch_start,
            end=batch_end
            + pd.Timedelta(seconds=time_shift_of_gases_in_sec).ceil(DEFAULT_RESAMPLE_RULE_VALUE),
            furnace_id=furnace_id,
            datasources=datasources,
            time_shift_of_gases_in_sec=time_shift_of_gases_in_sec,
        )
        df_batch = get_close_interval_from_dataframe(
            df_batch, (batch_start + pd.Timedelta(DEFAULT_RESAMPLE_RULE_VALUE)), batch_end
        )
        dfs.append(df_batch)
    df = pd.concat(dfs)

    return df


def get_filename_dir(
    output_dir: str,
    furnace_id: int,
    start: datetime,
    end: datetime,
) -> Path:
    return Path(
        output_dir, f"bf{furnace_id}_signals_by_layers_from_{start:%Y%m%dT%H%M}_to_{end:%Y%m%dT%H%M}.parquet"
    )


def main():
    args = parse_args()
    datasources = get_datasources_configured_with_env()

    df = load_signal_by_layers(
        pd.Timestamp(args.start),
        pd.Timestamp(args.end),
        args.furnace_id,
        datasources,
        args.time_shift_of_gases,
        args.batch_size_in_hours,
    )

    output_file_dir = get_filename_dir(args.output_dir, args.furnace_id, args.start, args.end)

    df.to_parquet(output_file_dir)
    logging.info(f"File was successfully saved to: {output_file_dir}")


if __name__ == "__main__":
    main()
