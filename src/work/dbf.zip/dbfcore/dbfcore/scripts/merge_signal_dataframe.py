import argparse
import logging
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def parse_args():
    parser = argparse.ArgumentParser(description="Merge signal dataframe")
    parser.add_argument(
        "-i",
        "--input-files",
        nargs="+",
        help="List of input filenames with path - provide at least two input files",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-o",
        "--output-file",
        help="Output file name with path",
        type=str,
        default="file_output.parquet",
    )
    parser.add_argument(
        "-m",
        "--processing-method",
        help="Processing method - 'ram' - in RAM (memory), 'disk' - on disk (batch processing)",
        choices=["ram", "disk"],
        type=str,
        default="ram",
    )
    return parser.parse_args()


def merge_dataframes_in_memory(dataframes: list[pd.DataFrame]) -> pd.DataFrame:
    df = pd.concat(dataframes).sort_index()
    return df[~df.index.duplicated()]


def merge_files_on_disk(input_files: list[Path], output_path: Path):
    try:
        schema = pq.ParquetFile(input_files[0]).schema.to_arrow_schema()
        with pq.ParquetWriter(output_path, schema) as writer:
            for file in input_files:
                with pq.ParquetFile(file) as pf:
                    for batch in pf.iter_batches():
                        table = pa.Table.from_batches([batch])
                        writer.write_table(table)
    except Exception as e:
        raise Exception(f"Error during merging files on disk: {e}")


def main():

    args = parse_args()

    logging.info(f"ARGUMENTS: {args}")

    if args.processing_method == "ram":
        dataframes = [pd.read_parquet(file) for file in args.input_files]
        df = merge_dataframes_in_memory(dataframes)
        logging.info(" Files successfully merged in RAM")
        df.to_parquet(args.output_file)
        logging.info(" File saved successfully")

    elif args.processing_method == "disk":
        merge_files_on_disk(args.input_files, args.output_file)
        logging.info(" The files were successfully merged on disk and saved to a file")
    else:
        raise Exception(f"Incorect argument arg_processing_method = {args.processing_method}")

    logging.info(f"RETURN: The merged files were successfully saved to: {args.output_file}")


if __name__ == "__main__":
    main()
