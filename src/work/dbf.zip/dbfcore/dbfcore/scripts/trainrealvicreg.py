import logging

from lightning.pytorch.cli import LightningCLI

from dbfcore.model.datamodule.pisignal import VicRegDataModule
from dbfcore.model.vicregtraining import RealVicReg
from dbfcore.scripts.utils import get_signal_normalizers_params

logging.basicConfig(level=logging.INFO)


class RealVicRegCLI(LightningCLI):
    def add_arguments_to_parser(self, parser):
        parser.link_arguments("data.sequence_length", "model.seq_len")
        parser.link_arguments("data.window_size", "model.window_size")
        parser.link_arguments(
            "data.signals", "model.signal_normalizers_params", get_signal_normalizers_params
        )


def main():
    RealVicRegCLI(RealVicReg, VicRegDataModule)


if __name__ == "__main__":
    main()
