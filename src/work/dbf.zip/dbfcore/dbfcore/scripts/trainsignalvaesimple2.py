import logging

from lightning.pytorch.cli import LightningCLI

from dbfcore.model.datamodule.pisignal import SignalsDataModule2
from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from dbfcore.scripts.utils import get_signal_normalizers_params

logging.basicConfig(level=logging.INFO)


class SignalVAESimpleCLI(LightningCLI):
    def add_arguments_to_parser(self, parser):
        parser.link_arguments("data.sequence_length", "model.max_seq_len")
        parser.link_arguments("data.window_size", "model.window_size")
        parser.link_arguments(
            "data.signals",
            "model.signal_normalizers_params",
            get_signal_normalizers_params,
        )


def main():
    SignalVAESimpleCLI(SignalVAESimple2, SignalsDataModule2)


if __name__ == "__main__":
    main()
