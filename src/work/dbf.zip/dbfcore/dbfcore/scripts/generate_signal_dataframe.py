import argparse
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Literal

import pandas as pd

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.dataset.signals import get_signal_group_loader
from dbfcore.settings import DATAMODULE_CACHE

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate final signal dataframe for pytorch datamodule.")
    parser.add_argument(
        "-s",
        "--start",
        help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        default="2023-01-01T00:00",
    )
    parser.add_argument(
        "-e",
        "--end",
        help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        default="2024-01-01T00:00",
    )
    parser.add_argument(
        "-g",
        "--signalgroup",
        help="Name of signal group for which dataframes will be generated",
        type=str,
        required=False,
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        help="Path to a output dataframe directory",
        type=str,
        default=DATAMODULE_CACHE,
    )
    parser.add_argument(
        "-f",
        "--format",
        help="File format of output dataframe",
        choices=["parquet", "csv"],
        default="parquet",
    )
    parser.add_argument(
        "-x", "--one-file", help="Set this flag to output full signal group in one file", action="store_true"
    )
    return parser.parse_args()


def get_cache_filename(name: str, start: datetime, end: datetime, format: Literal["parquet", "csv"]) -> str:
    return f"{name}_from_{start:%Y%m%dT%H%M}_to_{end:%Y%m%dT%H%M}.{format}"


def get_cache_path(
    signal_name: str, start: datetime, end: datetime, format: Literal["parquet", "csv"], folder: str
) -> Path:
    return Path(folder, get_cache_filename(signal_name, start, end, format))


def save_dataframe(data: pd.DataFrame, format: str, cache_path: Path):
    if format == "parquet":
        data.to_parquet(cache_path, engine="pyarrow")
    if format == "csv":
        data.to_csv(cache_path)


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)
    logging.info("Loading signal group data from its data source")

    datasources = get_datasources_configured_with_env()
    signal_group_loader = get_signal_group_loader(args.signalgroup, datasources)

    data = signal_group_loader(pd.Timestamp(args.start), pd.Timestamp(args.end))

    logging.info(f"Saving signal DataFrame into directory {output_dir}")
    if args.one_file:
        file_path = get_cache_path(args.signalgroup, args.start, args.end, args.format, args.output_dir)
        save_dataframe(data, args.format, file_path)

        logging.info(f"DataFrame for signal group {args.signalgroup} was saved to {file_path}")
    else:
        for signal_name in data:
            cache_path = get_cache_path(signal_name, args.start, args.end, args.format, args.output_dir)
            signal_df = data[signal_name].to_frame().dropna()
            save_dataframe(signal_df, args.format, cache_path)

            logging.info(f"DataFrame for signal {signal_name} was saved to {cache_path}")


if __name__ == "__main__":
    main()
