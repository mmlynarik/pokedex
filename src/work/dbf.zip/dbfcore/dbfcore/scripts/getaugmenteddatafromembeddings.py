import argparse
import logging
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from dbfcore.model.datamodule.pisignal import Signal2, SignalsDataModule2, TrainValIntervals
from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from dbfcore.settings import TZ_UTC

logging.basicConfig(level=logging.INFO)


def clean_orig_data(data: pd.DataFrame, signal_name: str, data_spacing: str) -> pd.DataFrame:
    return (
        data.assign(date=lambda df: pd.to_datetime(df.Timestamp, unit="s", utc=True))
        .set_index("date")
        .rename(columns={signal_name: "orig_data"})
        .resample(data_spacing)
        .mean()
        .reindex(columns=["orig_data"])
        .dropna()
    )


def get_orig_data(signal: Signal2, data_spacing: str) -> pd.DataFrame:
    datamodule = SignalsDataModule2([signal])
    datamodule.setup("")

    train_orig_data = datamodule.train_dataset.datasets[0].datasource.sorted_data  # type: ignore
    val_orig_data = datamodule.val_dataset.datasets[0].datasource.sorted_data  # type: ignore
    train_data = clean_orig_data(train_orig_data, signal.name, data_spacing)
    val_data = clean_orig_data(val_orig_data, signal.name, data_spacing)

    return pd.concat([train_data, val_data])


def decode_embeddings(
    model: SignalVAESimple2,
    signal_name: str,
    train_embeddings: torch.Tensor,
    val_embeddings: torch.Tensor,
    data_spacing: str,
    batch_size: int,
) -> np.ndarray:
    embeddings = torch.cat((train_embeddings, val_embeddings))
    dataloader = DataLoader(TensorDataset(embeddings), batch_size=batch_size, shuffle=False)
    spacing = pd.Timedelta(data_spacing).total_seconds()
    signal_idx = model.get_idx_for_signal_name(signal_name)

    decoded_data = []
    with torch.no_grad():
        for batch in tqdm(dataloader, "Decoding embeddings"):
            batch = batch[0].to(device=model.device)
            batch_size = batch.size(0)
            times = (
                torch.arange(0, model.max_time + spacing, spacing, device=model.device)
                .unsqueeze(0)
                .repeat(batch_size, 1)
            )
            indices = torch.ones(batch_size).long() * signal_idx
            decoded_data.append(model.decode(batch, times, indices).detach().cpu())

    return np.concatenate(decoded_data)


def recognize_valid_rows(df, col):
    df = df.copy()

    first_valid = df[(df[col].notnull()) & (df.orig_data.notnull())].index.min()
    last_valid = df[(df[col].notnull()) & (df.orig_data.notnull())].index.max()

    df.loc[first_valid:last_valid, "valid"] = 1

    return df


def cancel_invalid_rows(df, col):
    df = df.copy()
    df.loc[df.valid != 1, col] = np.nan
    return df


def get_mean_decoded_data_from_embeddings(
    decoded_data: pd.DataFrame,
    orig_data: pd.DataFrame,
    start_date: datetime,
    signal_name: str,
    embeddings_step: str,
    data_spacing: str,
) -> pd.DataFrame:
    df_times = pd.date_range(start_date, periods=len(decoded_data[0]), freq=data_spacing)
    dfs = []

    for decoded in tqdm(decoded_data, desc="Processing decoded data"):
        dfs.append(
            pd.DataFrame(index=df_times, data=decoded, columns=[signal_name])
            .assign(
                date=lambda df: df.index,
            )
            .set_index("date")
            .merge(orig_data, how="left", left_index=True, right_index=True)
            .pipe(recognize_valid_rows, signal_name)
            .pipe(cancel_invalid_rows, signal_name)
        )
        df_times = df_times + pd.Timedelta(embeddings_step)

    return pd.concat(dfs).groupby("date").mean().reindex(columns=[signal_name]).dropna()


def parse_args():
    parser = argparse.ArgumentParser(
        prog="Get data from embeddings",
        description="Get decoded dataset from embeddings for the future modelling.",
    )
    parser.add_argument(
        "-d",
        "--datapath",
        help="Path of parquet file containing signal dataframe.",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "-m",
        "--modelpath",
        help="Path to the model checkpoint.",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "-p",
        "--embeddingspath",
        help="Path to the embeddings.",
        type=Path,
        required=True,
    )
    parser.add_argument(
        "-n",
        "--signalname",
        help="Signal name for which the embeddings were defined.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-s",
        "--startdate",
        help="Start date for which embeddings were defined.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-l",
        "--splitdate",
        help="Split date between signal train and validation set.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-e",
        "--enddate",
        help="End date for which embeddings were defined.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-t",
        "--embeddingsstep",
        help="Step by which the embeddings window is moved.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-g",
        "--dataspacing",
        help="Time spacing of the output data.",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-b",
        "--batchsize",
        help="Batch size for decoding the embeddings.",
        type=int,
        default=1024,
    )

    return parser.parse_args()


def main():
    args = parse_args()

    datapath = args.datapath.resolve()
    model_path = args.modelpath.resolve()
    embeddings_path = args.embeddingspath.resolve()
    start_date = datetime.fromisoformat(args.startdate).replace(tzinfo=TZ_UTC)
    end_date = datetime.fromisoformat(args.enddate).replace(tzinfo=TZ_UTC)
    trainvalswitch = datetime.fromisoformat(args.splitdate).replace(tzinfo=TZ_UTC)

    model = SignalVAESimple2.load_from_checkpoint(model_path).cuda().eval()
    signal_idx = model.get_idx_for_signal_name(args.signalname)
    embeddings = torch.load(embeddings_path)
    signal = Signal2(
        name=args.signalname,
        data_path=datapath,
        mean=model.value_normalizer.means[signal_idx].item(),
        std=model.value_normalizer.stds[signal_idx].item(),
        train_val_split=TrainValIntervals(
            start_date.isoformat(),
            trainvalswitch.isoformat(),
            trainvalswitch.isoformat(),
            end_date.isoformat(),
            args.embeddingsstep,
        ),
    )
    orig_data = get_orig_data(signal, data_spacing=args.dataspacing)

    decoded_data = decode_embeddings(
        model, signal.name, embeddings["train"], embeddings["val"], args.dataspacing, args.batchsize
    )
    mean_embeddings_data = get_mean_decoded_data_from_embeddings(
        decoded_data, orig_data, start_date, args.signalname, args.embeddingsstep, args.dataspacing
    )

    mean_embeddings_data.to_parquet(embeddings_path.with_suffix(".parquet"))


if __name__ == "__main__":
    main()
