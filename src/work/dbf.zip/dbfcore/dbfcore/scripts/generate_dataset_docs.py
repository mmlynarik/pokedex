import argparse
import json
import logging

from datasets import Dataset, Sequence
from tqdm import tqdm

from dbfcore.dataset import load_dataset

DocsDict = dict[str, dict[str, str]]


logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate documentation for specified dataset as JSON")
    parser.add_argument(
        "-n",
        "--name",
        help="Name of the documentation JSON file",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-p",
        "--path",
        help="Path to a directory where dataset is stored",
        type=str,
        required=True,
    )

    return parser.parse_args()


def generate_documentation_dictionary(dataset: Dataset) -> DocsDict:
    return {
        feature: (
            json.loads(dataset.features[feature].feature.id)
            if isinstance(feature, Sequence)
            else json.loads(dataset.features[feature].id)
        )
        for feature in tqdm(dataset.features)
        if dataset.features[feature].id is not None
    }


def main():
    args = parse_args()

    logging.info(f"Loading dataset from directory {args.path}")
    dataset = load_dataset(path=args.path)

    logging.info("Generating documentation")
    documentation = generate_documentation_dictionary(dataset)

    logging.info(f"Saving documentation into {args.name}.json")
    with open(f"{args.name}.json", "w", encoding="utf-8") as file:
        json.dump(documentation, file, ensure_ascii=False)
    logging.info(f"Documentation saved in {args.name}.json")


if __name__ == "__main__":
    main()
