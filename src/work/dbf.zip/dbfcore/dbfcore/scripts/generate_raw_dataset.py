import argparse
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Iterator

import pandas as pd
import pymssql
from datasets import Dataset, Features, concatenate_datasets

from dbfcore.dataset.hooks import get_azvp_hook, get_oko_hook, get_pi_hook, get_pzvp_hook, get_scada_hook
from dbfcore.dataset.raw_dataset.raw_dataset_columns import (
    COLS_WITH_INCORRECTLY_INFERRED_TYPES,
    RAW_DATASET_COLUMNS,
)
from dbfcore.dataset.raw_dataset.raw_dataset_generator import RawDatasetGenerator
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.settings import (
    DEFAULT_RAW_DATASET_END_DATE,
    DEFAULT_RAW_DATASET_START_DATE,
    RAW_DATASET_PATH,
    TZ_UTC,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate a training dataset for a silicon blast furnace model"
    )
    parser.add_argument(
        "-s",
        "--start",
        help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        default=DEFAULT_RAW_DATASET_START_DATE.strftime("%Y-%m-%dT%H:%M"),
    )
    parser.add_argument(
        "-e",
        "--end",
        help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
        type=parse_naive_string_as_utc_datetime,
        default=DEFAULT_RAW_DATASET_END_DATE.strftime("%Y-%m-%dT%H:%M"),
    )
    parser.add_argument(
        "-t",
        "--test",
        help="Test run with exact date range (otherwise yearly periods are processed)",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-b",
        "--blastfurnaceid",
        help="ID of the blast furnace for which the dataset is to be generated",
        required=True,
        type=int,
    )
    parser.add_argument(
        "-p",
        "--path",
        help="Path to a directory where training dataset is stored",
        type=str,
        default=RAW_DATASET_PATH,
    )

    return parser.parse_args()


def generate_yearly_periods(
    start: datetime, end: datetime, test: bool = False
) -> Iterator[tuple[datetime, datetime]]:
    if test:
        yield start, end
    else:
        for year in range(start.year, end.year):
            yield datetime(year, 1, 1, tzinfo=TZ_UTC), datetime(year, 12, 31, 23, 59, tzinfo=TZ_UTC)


def print_versions():
    logging.info(f"Pandas version {pd.__version__}...")
    logging.info(f"pymssql version {pymssql.__version__}...")


def main():
    args = parse_args()
    print_versions()

    if args.end <= args.start:
        raise ValueError("The start date must precede the end date")

    path_stem = "vp" + str(args.blastfurnaceid)
    dataset_path = Path(args.path, path_stem)

    if not os.path.exists(dataset_path):
        os.makedirs(dataset_path)
        logging.info(f"Directory {dataset_path} was created")

    raw_dataset_generator = RawDatasetGenerator(
        get_azvp_hook(), get_pzvp_hook(), get_scada_hook(), get_oko_hook(), get_pi_hook()
    )
    periods = list(generate_yearly_periods(args.start, args.end, args.test))
    effective_start, effective_end = periods[0][0], periods[-1][1]
    logging.info(
        f"Generating dataset into directory {dataset_path} for period {effective_start} -> {effective_end} in {len(periods)} iteration(s)"
    )
    chunks: list[Dataset] = []
    for start, end in periods:
        df = raw_dataset_generator.generate_raw_dataset(start, end, args.blastfurnaceid)
        df[COLS_WITH_INCORRECTLY_INFERRED_TYPES] = df[COLS_WITH_INCORRECTLY_INFERRED_TYPES].astype("object")
        chunks.append(Dataset.from_pandas(df, features=Features(RAW_DATASET_COLUMNS)))
    dataset = concatenate_datasets(chunks)
    dataset.save_to_disk(str(dataset_path))
    logging.info(f"Raw dataset was created in directory {dataset_path}")


if __name__ == "__main__":
    main()
