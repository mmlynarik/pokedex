import logging

from lightning.pytorch.cli import LightningCLI

from dbfcore.model.datamodule.pisignal import SignalsDataModule2
from dbfcore.model.vicregdecoder import VicRegDecoder

logging.basicConfig(level=logging.INFO)


def main():
    LightningCLI(VicRegDecoder, SignalsDataModule2)


if __name__ == "__main__":
    main()
