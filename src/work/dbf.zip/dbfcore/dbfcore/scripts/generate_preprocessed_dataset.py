import argparse
import logging
import os
from pathlib import Path

from datasets import Dataset, Features

from dbfcore.dataset import load_dataset_as_dataframe
from dbfcore.dataset.preprocessed_dataset.autoencoder_flows_preprocessing import (
    AUTOENCODER_FLOWS_KEY,
    AUTOENCODER_FLOWS_OUTPUT_FEATURES,
    AUTOENCODER_FLOWS_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.causality_analysis_preprocessing import (
    CAUSALITY_ANALYSIS_FEATURES,
    CAUSALITY_ANALYSIS_KEY,
    CAUSALITY_ANALYSIS_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.charge_flows_freq_15_preprocessing import (
    CHARGE_FLOWS_15_KEY,
    CHARGE_FLOWS_15_OUTPUT_FEATURES,
    CHARGE_FLOWS_15_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.material_balance_base_preprocessing import (
    BASE_MATERIAL_BALANCE_FEATURES,
    BASE_MATERIAL_BALANCE_KEY,
    BASE_MATERIAL_BALANCE_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.material_balance_coefs_preprocessing import (
    MATERIAL_BALANCE_COEFS_FEATURES,
    MATERIAL_BALANCE_COEFS_KEY,
    MATERIAL_BALANCE_COEFS_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.mineral_flows_freq_900_preprocessing import (
    MINERAL_FLOWS_900_KEY,
    MINERAL_FLOWS_900_OUTPUT_FEATURES,
    MINERAL_FLOWS_900_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.pig_iron_chems_preprocessing import (
    PIG_IRON_CHEMS_FEATURES,
    PIG_IRON_CHEMS_KEY,
    PIG_IRON_CHEMS_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.temperature_prediction_preprocessing import (
    TEMPERATURE_PREDICTION_FEATURES,
    TEMPERATURE_PREDICTION_KEY,
    TEMPERATURE_PREDICTION_TRANSFORMATIONS,
)
from dbfcore.dataset.preprocessed_dataset.utils import TransformationsCallables, make_transformations
from dbfcore.dataset.utils import ValueDict
from dbfcore.settings import PREPROCESSED_DATASETS_PATH, RAW_DATASET_PATH

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate a preprocessed dataset from the raw dataset.")
    parser.add_argument(
        "-p",
        "--path",
        help="Path to a parent directory where preprocessed datasets will be stored in child directories",
        type=str,
        default=PREPROCESSED_DATASETS_PATH,
    )
    parser.add_argument(
        "-r",
        "--raw-path",
        help="Path to a raw dataset directory",
        type=str,
        default=RAW_DATASET_PATH,
    )
    parser.add_argument(
        "-n",
        "--name",
        help="Name of preprocessed dataset also used as a child directory where dataset will be stored.",
        choices=preprocessed_datasets_config.keys(),
        required=True,
    )
    parser.add_argument(
        "-b",
        "--blastfurnaceid",
        help="Blast furnace id",
        required=True,
        type=int,
    )

    return parser.parse_args()


preprocessed_datasets_config: dict[str, tuple[TransformationsCallables, ValueDict]] = {
    CAUSALITY_ANALYSIS_KEY: (CAUSALITY_ANALYSIS_TRANSFORMATIONS, CAUSALITY_ANALYSIS_FEATURES),
    BASE_MATERIAL_BALANCE_KEY: (BASE_MATERIAL_BALANCE_TRANSFORMATIONS, BASE_MATERIAL_BALANCE_FEATURES),
    MATERIAL_BALANCE_COEFS_KEY: (MATERIAL_BALANCE_COEFS_TRANSFORMATIONS, MATERIAL_BALANCE_COEFS_FEATURES),
    TEMPERATURE_PREDICTION_KEY: (TEMPERATURE_PREDICTION_TRANSFORMATIONS, TEMPERATURE_PREDICTION_FEATURES),
    CHARGE_FLOWS_15_KEY: (CHARGE_FLOWS_15_TRANSFORMATIONS, CHARGE_FLOWS_15_OUTPUT_FEATURES),
    MINERAL_FLOWS_900_KEY: (MINERAL_FLOWS_900_TRANSFORMATIONS, MINERAL_FLOWS_900_OUTPUT_FEATURES),
    AUTOENCODER_FLOWS_KEY: (AUTOENCODER_FLOWS_TRANSFORMATIONS, AUTOENCODER_FLOWS_OUTPUT_FEATURES),
    PIG_IRON_CHEMS_KEY: (PIG_IRON_CHEMS_TRANSFORMATIONS, PIG_IRON_CHEMS_FEATURES),
}


def main():
    args = parse_args()

    path_stem = "vp" + str(args.blastfurnaceid)
    dataset_path = Path(args.path, args.name, path_stem)
    os.makedirs(dataset_path, exist_ok=True)
    logging.info(f"Directory {dataset_path} was created")

    raw_dataset_path = Path(args.raw_path, path_stem)
    if not Path(raw_dataset_path).exists():
        raise FileNotFoundError(
            "Raw dataset not found. Run the `generate_raw_dataset` command with appropriate arguments first to generate necessary raw dataset."
        )

    logging.info(f"Loading raw dataset from directory {raw_dataset_path}")
    raw_dataset = load_dataset_as_dataframe(path=str(raw_dataset_path))

    logging.info(f"Applying {args.name}-relevant transformations upon raw dataset")
    transformations, features = preprocessed_datasets_config[args.name]
    preprocessed_dataset = make_transformations(raw_dataset, transformations)

    logging.info(f"Saving preprocessed dataset into directory {dataset_path}")
    preprocessed_dataset = Dataset.from_pandas(preprocessed_dataset, features=Features(features))
    preprocessed_dataset.save_to_disk(str(dataset_path))
    logging.info(f"Preprocessed dataset for {args.name} was saved in directory {dataset_path}")


if __name__ == "__main__":
    main()
