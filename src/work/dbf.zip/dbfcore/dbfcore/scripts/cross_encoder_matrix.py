import argparse
import logging
from pathlib import Path

import torch

from dbfcore.model.datamodule.pisignal import Signal2, SignalsDataModule2, TrainValIntervals
from dbfcore.model.signalvaesimple2 import SignalVAESimple2, load_autoencoder_from_path_cached

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def prepare_model(model_name) -> SignalVAESimple2:
    model_path = f"Y:/Departments/IT/DSE/DBF-Y/!MODELS/{model_name}.ckpt"
    return load_autoencoder_from_path_cached(path=model_path)


def prepare_datamodule(signal_name: str, model_orig: SignalVAESimple2, window_size: str, seq_len: int):
    data_path = Path(
        f"Y:/Departments/IT/DSE/DBF-Y/datamodule/{signal_name}_from_20230101T0000_to_20240101T0000.parquet"
    )
    TrainValIntervals("2023-01-01", "2023-10-01", "2023-10-01", "2024-01-01", "4h"),
    signal_idx = model_orig.get_idx_for_signal_name(signal_name)
    signal = Signal2(
        name=signal_name,
        data_path=data_path,
        mean=model_orig.value_normalizer.means[signal_idx].item(),
        std=model_orig.value_normalizer.means[signal_idx].item(),
        train_val_split=TrainValIntervals("2023-01-01", "2023-10-01", "2023-10-01", "2024-01-01", "4h"),
    )
    datamodule = SignalsDataModule2(
        signals=[signal],
        window_size=window_size,
        sequence_length=seq_len,
        shuffle_train=False,
        shuffle_val=False,
        num_workers=0,
        signal_idx=signal_idx,
    )
    datamodule.setup("")

    return datamodule


def perform_cross_predictions(
    datamodule: SignalsDataModule2,
    orig_model: SignalVAESimple2,
    alt_model: SignalVAESimple2,
    signal_name_alt: str,
):
    orig_model_signal_idx = datamodule.signal_indices[datamodule.signals[0].name]
    alt_model_signal_idx = alt_model.get_idx_for_signal_name(signal_name_alt)
    maes = []
    with torch.no_grad():
        for batch in datamodule.train_dataloader():
            batch_size = batch.size(0)
            orig_indices = torch.ones(batch_size).long() * orig_model_signal_idx
            alt_indices = torch.ones(batch_size).long() * alt_model_signal_idx
            transformed_batch = alt_model.input_normalizer.denormalize(
                orig_model.input_normalizer(batch, orig_indices), alt_indices
            )
            norm_trans_results = alt_model(transformed_batch, transformed_batch[:, :, 0])
            decoded_trans = orig_model.value_normalizer.denormalize(norm_trans_results, orig_indices)
            orig_values = batch[:, :, 1]
            mae_trans = (decoded_trans - orig_values).abs().mean().detach()
            maes.append(mae_trans)

    return torch.stack(maes).mean().item()


def parse_args():
    parser = argparse.ArgumentParser(
        prog="Perform cross encoding test",
        description="Perform cross encoding test with encoder primarily intended for encoding another signal.",
    )
    parser.add_argument(
        "--signal_name_orig",
        help="Signal name encoded by the original model (e.g. bf1_hotmetal_temp_C)",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--signal_name_alt",
        help="Signal name encoded by the alternative model (e.g. bf2_topgasco_chem_pct)",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--model_name_orig",
        help="Name of the original model (e.g. hotmetal_temp_C_24h)",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--model_name_alt",
        help="Name of the alternative model (e.g. topgasco2_chem_pct_0.5h)",
        type=str,
        required=True,
    )
    parser.add_argument(
        "--num_steps",
        help="Number of steps to iterate through datamodule",
        type=int,
        default=10,
    )

    return parser.parse_args()


def main():
    args = parse_args()

    model_orig = prepare_model(args.model_name_orig)
    model_alt = prepare_model(args.model_name_alt)
    datamodule = prepare_datamodule(
        args.signal_name_orig,
        model_orig,
        model_alt.window_size,
        model_alt.max_seq_len,
    )
    signal_name_alt = args.signal_name_alt
    mae = perform_cross_predictions(
        datamodule=datamodule, orig_model=model_orig, alt_model=model_alt, signal_name_alt=signal_name_alt
    )

    logging.info(f"Writing into file ... MAE = {mae:.4f}")

    with open(f"{args.signal_name}-{args.model_name_alt}.txt", "w") as f:
        f.write(str(mae))


if __name__ == "__main__":
    main()
