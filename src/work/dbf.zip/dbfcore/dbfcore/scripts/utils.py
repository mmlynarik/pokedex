from typing import Union

from dbfcore.model.datamodule.pisignal import Signal2


def get_signal_normalizers_params(signals: list[Signal2]) -> tuple[dict[str, Union[str, float]], ...]:
    return tuple([{"signal_name": signal.name, "mean": signal.mean, "std": signal.std} for signal in signals])
