import logging

from lightning.pytorch.cli import LightningCLI

from dbfcore.predictionmodel.datamodule import PredictionModelDataModule
from dbfcore.predictionmodel.model import PredictionModel

logging.basicConfig(level=logging.INFO)


class PredictionModelCLI(LightningCLI):
    def add_arguments_to_parser(self, parser): ...


def main():
    PredictionModelCLI(PredictionModel, PredictionModelDataModule)


if __name__ == "__main__":
    main()
