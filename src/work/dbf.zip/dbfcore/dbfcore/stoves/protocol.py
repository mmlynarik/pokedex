from typing import Protocol, Sequence

import pandas as pd
from attrs import frozen


@frozen
class StoveInitialState:
    dome_temperature: float  # [°C]
    stack_temperature: float  # [°C]
    wastegas_temperature: float  # [°C]


@frozen
class GasComposition:
    "The sum of the respective components is equal to 1"

    c2h2: float  # [molar ratio]
    c2h4: float  # [molar ratio]
    c2h6: float  # [molar ratio]
    c3h8: float  # [molar ratio]
    ch4: float  # [molar ratio]
    co: float  # [molar ratio]
    co2: float  # [molar ratio]
    h2: float  # [molar ratio]
    h2o: float  # [molar ratio]
    n2: float  # [molar ratio]
    o2: float  # [molar ratio]


@frozen
class Gas:
    flow: float  # [m3/h]
    temperature: float  # [°C]
    composition: GasComposition

    def get_molecule_flow(self, molecule: str) -> float:
        return self.flow * getattr(self.composition, molecule)


@frozen
class StoveGasRegime:
    duration: int  # [min]
    cog: Gas
    bfg: Gas
    ng: Gas
    air: Gas


@frozen
class StoveTemperaturePrediction:
    dome_temperature: float  # [°C]
    wastegas_temperature: float  # [°C]


class StoveModel(Protocol):
    def temperature_prediction(
        self, initial_state: StoveInitialState, gas_regime: Sequence[StoveGasRegime]
    ) -> dict[pd.Timedelta, StoveTemperaturePrediction]: ...
