from math import isfinite
from typing import Optional, TypedDict

import cantera as ct

from dbfcore.stoves import STANDARD_TEMPERATURE_K


def calculate_theoretical_lhv_for_one_molecule_fuel(fuel: str) -> float:
    """
    Value returned in MJ/kg
    """
    if fuel in ["O2", "N2", "O", "OH", "H2O", "HO2", "H2O2", "CO2", "NO", "NO2", "N2O", "HNO", "AR"]:
        return 0.0

    gas = ct.Solution(thermo="ideal-gas", species=ct.Species.list_from_file("gri30.yaml"))
    gas.TP = STANDARD_TEMPERATURE_K, ct.one_atm
    gas.set_equivalence_ratio(1.0, f"{fuel}:1.0", "O2:1.0")

    enthalpy_before = gas.enthalpy_mass
    y_fuel = (gas[fuel].Y).item()

    X_products = {
        "CO2": gas.elemental_mole_fraction("C"),
        "H2O": 0.5 * gas.elemental_mole_fraction("H"),
        "N2": 0.5 * gas.elemental_mole_fraction("N"),
    }

    gas.TPX = STANDARD_TEMPERATURE_K, ct.one_atm, X_products
    enthalpy_after = gas.enthalpy_mass
    lhv = -(enthalpy_after - enthalpy_before) / 1e6

    return lhv / y_fuel


def calculate_theoretical_lhv(fuel: ct.Quantity) -> tuple[float, float]:
    """
    Value returned in MJ/kg and MJ/m3
    """
    gas = ct.Solution(thermo="ideal-gas", species=ct.Species.list_from_file("gri30.yaml"))
    gas.TP = fuel.TP
    gas.set_equivalence_ratio(1.0, fuel.X, "O2:1.0")

    enthalpy_before = gas.enthalpy_mass

    o2_in_fuel = fuel.phase["O2"].Y
    y_fuel = 1 - gas["O2"].Y + (gas.mixture_fraction(fuel.X, "O2:1.0") * o2_in_fuel)
    y_fuel = y_fuel.item()

    X_products = {
        "CO2": gas.elemental_mole_fraction("C"),
        "H2O": 0.5 * gas.elemental_mole_fraction("H"),
        "N2": 0.5 * gas.elemental_mole_fraction("N"),
    }

    gas.TPX = STANDARD_TEMPERATURE_K, ct.one_atm, X_products
    enthalpy_after = gas.enthalpy_mass
    lhv = -(enthalpy_after - enthalpy_before) / y_fuel / 1e6

    return lhv, lhv * fuel.density_mass


class CalorificValues(TypedDict):
    MJ_m3_fuel: float
    MJ_kg_fuel: float
    MJ_m3_mixture: float
    MJ_kg_mixture: float


class BurningResult(TypedDict):
    adiabatic_flame_temperature_K: float
    calorific_value_cooled_to_input_temp: CalorificValues
    calorific_value_cooled_to_normal_temp: CalorificValues
    calorific_value_cooled_to_real_flue_temp: CalorificValues


EMPTY_BURNING_RESULT: BurningResult = {
    "adiabatic_flame_temperature_K": float("nan"),
    "calorific_value_cooled_to_input_temp": {
        "MJ_m3_fuel": float("nan"),
        "MJ_kg_fuel": float("nan"),
        "MJ_m3_mixture": float("nan"),
        "MJ_kg_mixture": float("nan"),
    },
    "calorific_value_cooled_to_normal_temp": {
        "MJ_m3_fuel": float("nan"),
        "MJ_kg_fuel": float("nan"),
        "MJ_m3_mixture": float("nan"),
        "MJ_kg_mixture": float("nan"),
    },
    "calorific_value_cooled_to_real_flue_temp": {
        "MJ_m3_fuel": float("nan"),
        "MJ_kg_fuel": float("nan"),
        "MJ_m3_mixture": float("nan"),
        "MJ_kg_mixture": float("nan"),
    },
}


def calculate_real_burning(
    fuel: Optional[ct.Quantity], oxidizer: Optional[ct.Quantity], flue_gas_temperature_K: Optional[float]
) -> BurningResult:
    if (fuel is None) or (oxidizer is None):
        return EMPTY_BURNING_RESULT

    full_gas = fuel + oxidizer
    density_before = full_gas.density_mass
    fuel_density = fuel.density_mass
    enthalpy_before = full_gas.enthalpy_mass

    y_fuel = (fuel.mass / full_gas.mass).item()

    full_gas.equilibrate("HP")

    adiabatic_flame_temperature = full_gas.T

    # This is a way how to create new gas object but we will change all parameters in the next step
    flue_gas = fuel + oxidizer
    flue_gas.X = full_gas.X

    enthalpy_after_cooled_to_input_temp = flue_gas.enthalpy_mass
    hv_cooled_to_input_temp = -(enthalpy_after_cooled_to_input_temp - enthalpy_before) / 1e6
    hv_cooled_to_input_temp_per_fuel = hv_cooled_to_input_temp / y_fuel

    cv_cit: CalorificValues = {
        "MJ_m3_fuel": hv_cooled_to_input_temp_per_fuel * fuel_density,
        "MJ_kg_fuel": hv_cooled_to_input_temp_per_fuel,
        "MJ_m3_mixture": hv_cooled_to_input_temp * density_before,
        "MJ_kg_mixture": hv_cooled_to_input_temp,
    }

    flue_gas.TP = STANDARD_TEMPERATURE_K, flue_gas.P

    enthalpy_after_cooled_to_normal_temp = flue_gas.enthalpy_mass
    hv_cooled_to_normal_temp = -(enthalpy_after_cooled_to_normal_temp - enthalpy_before) / 1e6
    hv_cooled_to_noraml_temp_per_fuel = hv_cooled_to_normal_temp / y_fuel

    cv_cnt: CalorificValues = {
        "MJ_m3_fuel": hv_cooled_to_noraml_temp_per_fuel * fuel_density,
        "MJ_kg_fuel": hv_cooled_to_noraml_temp_per_fuel,
        "MJ_m3_mixture": hv_cooled_to_normal_temp * density_before,
        "MJ_kg_mixture": hv_cooled_to_normal_temp,
    }

    cv_real: CalorificValues
    if (flue_gas_temperature_K is not None) and (isfinite(flue_gas_temperature_K)):
        flue_gas.TP = flue_gas_temperature_K, flue_gas.P

        enthalpy_after_cooled_to_real_flue_temp = flue_gas.enthalpy_mass
        hv_cooled_to_real_temp = -(enthalpy_after_cooled_to_real_flue_temp - enthalpy_before) / 1e6
        hv_cooled_to_real_temp_per_fuel = hv_cooled_to_real_temp / y_fuel

        cv_real = {
            "MJ_m3_fuel": hv_cooled_to_real_temp_per_fuel * fuel_density,
            "MJ_kg_fuel": hv_cooled_to_real_temp_per_fuel,
            "MJ_m3_mixture": hv_cooled_to_real_temp * density_before,
            "MJ_kg_mixture": hv_cooled_to_real_temp,
        }
    else:
        cv_real = {
            "MJ_m3_fuel": float("nan"),
            "MJ_kg_fuel": float("nan"),
            "MJ_m3_mixture": float("nan"),
            "MJ_kg_mixture": float("nan"),
        }

    return {
        "adiabatic_flame_temperature_K": adiabatic_flame_temperature,
        "calorific_value_cooled_to_input_temp": cv_cit,
        "calorific_value_cooled_to_normal_temp": cv_cnt,
        "calorific_value_cooled_to_real_flue_temp": cv_real,
    }
