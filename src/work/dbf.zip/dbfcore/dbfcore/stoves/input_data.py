from typing import List, Sequence, TypedDict, cast

import cattrs
import pandas as pd
from attrs import fields

from dbfcore.stoves.protocol import Gas, GasComposition, StoveGasRegime, StoveInitialState

StoveGases = ["cog", "bfg", "ng", "air"]


class StoveInitialStateInput(TypedDict):
    stove_id: int
    dome_temp: float
    stack_temp: float
    wastegas_temp: float


class StoveGasRegimeInput(TypedDict):
    duration: int
    cog_flow: float
    cog_temp: float
    cog_comp: str
    bfg_flow: float
    bfg_temp: float
    bfg_comp: str
    ng_flow: float
    ng_temp: float
    ng_comp: str
    air_flow: float
    air_temp: float
    air_comp: str


class StoveGasCompositionInput(TypedDict):
    name: str
    type: str
    c2h2: float
    c2h4: float
    c2h6: float
    c3h8: float
    ch4: float
    co: float
    co2: float
    h2: float
    h2o: float
    n2: float
    o2: float


class StructuredStovesInputData(TypedDict):
    initial_data: StoveInitialStateInput
    regimes: List[StoveGasRegimeInput]
    compositions: List[StoveGasCompositionInput]


def get_stove_initial_state(
    heating_phase_start: pd.Timestamp,
    heating_phase_end: pd.Timestamp,
    stove_temperatures: pd.DataFrame,
    stove_number: int,
) -> StoveInitialState:
    temperature_filtered_df = stove_temperatures.loc[
        heating_phase_start:heating_phase_end, stove_temperatures.columns.str.contains(f"stove{stove_number}")
    ]
    temp_averages = temperature_filtered_df.mean()
    dome_avg_temp = temp_averages[temp_averages.index.str.contains("dome")].values[0]
    stack_avg_temp = temp_averages[temp_averages.index.str.contains("stack")].values[0]
    wastegas_avg_temp = temp_averages[temp_averages.index.str.contains("wastegas")].values[0]

    return StoveInitialState(dome_avg_temp, stack_avg_temp, wastegas_avg_temp)


def get_segments_by_zero_flow(df: pd.DataFrame, gas: str) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    df["is_zero"] = (df[f"total_{gas}_flow"] == 0).astype(int)
    df["group"] = (df["is_zero"] != df["is_zero"].shift()).cumsum()
    return (
        df.groupby("group", group_keys=False)
        .apply(lambda g: (g.index[0], g.index[-1]), include_groups=False)
        .tolist()
    )


def get_segments_by_trend(
    df: pd.DataFrame, column: str, window: int, threshold: float, min_group_size: int
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    df["slope"] = df[column].diff().rolling(window=window, center=True).mean()
    df["trend"] = (df["slope"].abs() > threshold).astype(int)
    trend_group = (df["trend"] != df["trend"].shift()).cumsum()
    group_sizes = df.groupby(trend_group)["trend"].transform("size")
    df.loc[group_sizes < min_group_size, "trend"] = 0

    is_trend_start = (df["trend"] != 0) & (df["trend"].shift() == 0)
    changepoints = df.index[is_trend_start].tolist()

    if not changepoints:
        return [(df.index[0], df.index[-1])]

    segments = [(df.index[0], df.index[df.index.get_loc(changepoints[0]) - 1])]
    for i in range(len(changepoints) - 1):
        start = changepoints[i]
        end = df.index[df.index.get_loc(changepoints[i + 1]) - 1]
        segments.append((start, end))

    last_start_idx = df.index.get_loc(changepoints[-1])
    if last_start_idx < len(df):
        segments.append((df.index[last_start_idx], df.index[-1]))

    return segments


def get_gas_flow_segments(
    heating_phase_start: pd.Timestamp,
    heating_phase_end: pd.Timestamp,
    input_gases: pd.DataFrame,
    stove_number: int,
    gas: str,
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    cols = input_gases.columns[
        input_gases.columns.str.contains(f"stove{stove_number}") & input_gases.columns.str.contains(gas)
    ]
    df = input_gases.loc[heating_phase_start:heating_phase_end, cols].copy()
    df[f"total_{gas}_flow"] = df.sum(axis=1)

    if gas == "ng":
        flow_segments = get_segments_by_zero_flow(df, gas)
    elif gas == "cog":
        flow_segments = get_segments_by_trend(
            df, column=f"total_{gas}_flow", window=3, threshold=100, min_group_size=3
        )
    elif gas in ["bfg", "air"]:
        flow_segments = get_segments_by_trend(
            df, column=f"total_{gas}_flow", window=5, threshold=1000, min_group_size=4
        )
    else:
        raise ValueError(f"Unsupported gas type: {gas}")

    return flow_segments


def get_temp_segments_by_threshold(
    df: pd.DataFrame, column: str, threshold: float
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    segments = []
    prev_above_threshold = None
    segment_start_time = df.index[0]

    for i in range(len(df)):
        value = df.iloc[i][column]
        timestamp = df.index[i]
        is_above_threshold = value > threshold

        if prev_above_threshold is None:
            prev_above_threshold = is_above_threshold

        if is_above_threshold != prev_above_threshold:
            end_time = df.index[i - 1]
            segments.append((segment_start_time, end_time))
            segment_start_time = timestamp
            prev_above_threshold = is_above_threshold

    segments.append((segment_start_time, df.index[-1]))

    return segments


def get_gas_temp_segments(
    heating_phase_start: pd.Timestamp,
    heating_phase_end: pd.Timestamp,
    input_gases: pd.DataFrame,
    gas: str,
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    df = input_gases.loc[
        heating_phase_start:heating_phase_end, input_gases.columns.str.contains(f"{gas}_temp")
    ].copy()
    df[f"{gas}_temp"] = df.sum(axis=1)

    thresholds = {"ng": 185, "bfg": 185, "air": 170}

    if gas == "cog":
        return [(df.index[0], df.index[-1])]
    elif gas in thresholds:
        return get_temp_segments_by_threshold(df, column=f"{gas}_temp", threshold=thresholds[gas])
    else:
        raise ValueError(f"Unsupported gas type: {gas}")


def get_gas_data(
    gas: str,
    segment_start: pd.Timestamp,
    segment_end: pd.Timestamp,
    input_gases: pd.DataFrame,
    furnace_id: int,
    stove_number: int,
    components: list[str],
) -> Gas:
    gas_cols = input_gases.columns.str.contains(f"stove{stove_number}") & input_gases.columns.str.contains(
        gas
    )
    filtered_df = input_gases.loc[segment_start:segment_end, gas_cols]

    flow = filtered_df.sum(axis=1).mean()
    temp_col = input_gases.columns.str.contains(f"{gas}_temp_C")
    temperature = input_gases.loc[segment_start:segment_end, temp_col].mean().iloc[0]

    total_flows = {
        component: filtered_df[f"bf{furnace_id}_stove{stove_number}_{gas}_{component}_flow_m3h"].sum()
        for component in components
        if f"bf{furnace_id}_stove{stove_number}_{gas}_{component}_flow_m3h" in filtered_df.columns
    }

    total_flow = sum(total_flows.values())
    molar_ratios = {
        component: (flow / total_flow) if total_flow > 0 else 0.0 for component, flow in total_flows.items()
    }

    composition = GasComposition(**{component: molar_ratios.get(component, 0.0) for component in components})
    return Gas(flow, temperature, composition)


def filter_segments_dts(
    segments: list[tuple[pd.Timestamp, pd.Timestamp]]
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    unique_dts = sorted({t for seg in segments for t in seg})
    filtered_dts = [
        timestamp
        for i, timestamp in enumerate(unique_dts)
        if i == 0
        or i == len(unique_dts) - 1
        or not (
            unique_dts[i] - unique_dts[i - 1] == pd.Timedelta(minutes=1)
            and unique_dts[i + 1] - unique_dts[i] == pd.Timedelta(minutes=1)
        )
    ]

    dts = [
        timestamp
        for i, timestamp in enumerate(filtered_dts[:-1])
        if filtered_dts[i + 1] - timestamp != pd.Timedelta(minutes=1)
    ] + [filtered_dts[-1]]

    return [(start, end) for start, end in zip(dts, dts[1:])]


def get_stove_gas_regimes(
    heating_phase_start: pd.Timestamp,
    heating_phase_end: pd.Timestamp,
    input_gases: pd.DataFrame,
    furnace_id: int,
    stove_number: int,
) -> Sequence[StoveGasRegime]:
    components = [field.name for field in fields(GasComposition)]

    segments = [
        seg
        for gas in StoveGases
        for seg in (
            get_gas_flow_segments(heating_phase_start, heating_phase_end, input_gases, stove_number, gas)
            + get_gas_temp_segments(heating_phase_start, heating_phase_end, input_gases, gas)
        )
    ]
    filtered_segments = filter_segments_dts(segments)

    gas_regimes = []
    for segment_start, segment_end in filtered_segments:
        duration = int((segment_end - segment_start).total_seconds() / 60)
        gas_objects = [
            get_gas_data(gas, segment_start, segment_end, input_gases, furnace_id, stove_number, components)
            for gas in StoveGases
        ]
        gas_regime = StoveGasRegime(duration, *gas_objects)
        gas_regimes.append(gas_regime)

    return gas_regimes


def get_structured_stoves_input_data(
    stove_initial_state: StoveInitialState, stove_gas_regimes: Sequence[StoveGasRegime], stove_number: int
) -> StructuredStovesInputData:
    structured_initial_state = cattrs.unstructure(stove_initial_state)
    structured_stove_gas_regimes = cattrs.unstructure(stove_gas_regimes)

    output: StructuredStovesInputData = {
        "initial_data": {
            "stove_id": stove_number,
            "dome_temp": structured_initial_state["dome_temperature"],
            "stack_temp": structured_initial_state["stack_temperature"],
            "wastegas_temp": structured_initial_state["wastegas_temperature"],
        },
        "regimes": cast(List[StoveGasRegimeInput], []),
        "compositions": cast(List[StoveGasCompositionInput], []),
    }

    for idx, entry in enumerate(structured_stove_gas_regimes):
        regime = {
            "duration": entry["duration"],
            "cog_flow": entry["cog"]["flow"],
            "cog_temp": entry["cog"]["temperature"],
            "cog_comp": f"Rezim{idx + 1}",
            "bfg_flow": entry["bfg"]["flow"],
            "bfg_temp": entry["bfg"]["temperature"],
            "bfg_comp": f"Rezim{idx + 1}",
            "ng_flow": entry["ng"]["flow"],
            "ng_temp": entry["ng"]["temperature"],
            "ng_comp": f"Rezim{idx + 1}",
            "air_flow": entry["air"]["flow"],
            "air_temp": entry["air"]["temperature"],
            "air_comp": f"Rezim{idx + 1}",
        }
        output["regimes"].append(cast(StoveGasRegimeInput, regime))

        for gas_type in StoveGases:
            comp = entry[gas_type]["composition"]

            composition = {
                "name": f"Rezim{idx + 1}",
                "type": gas_type,
                "c2h2": comp["c2h2"],
                "c2h4": comp["c2h4"],
                "c2h6": comp["c2h6"],
                "c3h8": comp["c3h8"],
                "ch4": comp["ch4"],
                "co": comp["co"],
                "co2": comp["co2"],
                "h2": comp["h2"],
                "h2o": comp["h2o"],
                "n2": comp["n2"],
                "o2": comp["o2"],
            }
            output["compositions"].append(cast(StoveGasCompositionInput, composition))
    return output


def get_stoves_input_data(
    heating_phase_start: pd.Timestamp,
    heating_phase_end: pd.Timestamp,
    input_gases_df: pd.DataFrame,
    stove_temperatures_df: pd.DataFrame,
    furnace_id: int,
    stove_number: int,
) -> StructuredStovesInputData:
    stove_initial_state = get_stove_initial_state(
        heating_phase_start, heating_phase_end, stove_temperatures_df, stove_number
    )

    stove_gas_regimes = get_stove_gas_regimes(
        heating_phase_start, heating_phase_end, input_gases_df, furnace_id, stove_number
    )

    return get_structured_stoves_input_data(stove_initial_state, stove_gas_regimes, stove_number)
