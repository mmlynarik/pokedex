from typing import Sequence, cast

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

from dbfcore.stoves import Stove
from dbfcore.stoves.dataset import (
    calculate_quantities,
    generate_burning_features,
    prepare_data_for_gas,
    sum_quantities_dict,
)
from dbfcore.stoves.protocol import StoveGasRegime, StoveInitialState, StoveTemperaturePrediction


def prepare_stove_model_features(waste_gas_temp: float, gas_regime: StoveGasRegime) -> dict:
    bf = 1  # It was agreed that this variable would be hardcoded.
    stove = 11  # It was agreed that this variable would be hardcoded.

    data_values = {
        "cog_ch4_flow_m3h": gas_regime.cog.get_molecule_flow("ch4"),
        "cog_h2_flow_m3h": gas_regime.cog.get_molecule_flow("h2"),
        "cog_o2_flow_m3h": gas_regime.cog.get_molecule_flow("o2"),
        "cog_n2_flow_m3h": gas_regime.cog.get_molecule_flow("n2"),
        "cog_co2_flow_m3h": gas_regime.cog.get_molecule_flow("co2"),
        "cog_c2h4_flow_m3h": gas_regime.cog.get_molecule_flow("c2h4"),
        "cog_c2h6_flow_m3h": gas_regime.cog.get_molecule_flow("c2h6"),
        "cog_c2h2_flow_m3h": gas_regime.cog.get_molecule_flow("c2h2"),
        "cog_co_flow_m3h": gas_regime.cog.get_molecule_flow("co"),
        "bfg_co_flow_m3h": gas_regime.bfg.get_molecule_flow("co"),
        "bfg_co2_flow_m3h": gas_regime.bfg.get_molecule_flow("co2"),
        "bfg_h2_flow_m3h": gas_regime.bfg.get_molecule_flow("h2"),
        "bfg_n2_flow_m3h": gas_regime.bfg.get_molecule_flow("n2"),
        "bfg_h2o_flow_m3h": gas_regime.bfg.get_molecule_flow("h2o"),
        "air_o2_flow_m3h": gas_regime.air.get_molecule_flow("o2"),
        "air_n2_flow_m3h": gas_regime.air.get_molecule_flow("n2"),
        "air_h2o_flow_m3h": gas_regime.air.get_molecule_flow("h2o"),
        "ng_ch4_flow_m3h": gas_regime.ng.get_molecule_flow("ch4"),
        "ng_c2h6_flow_m3h": gas_regime.ng.get_molecule_flow("c2h6"),
        "ng_c3h8_flow_m3h": gas_regime.ng.get_molecule_flow("c3h8"),
        "ng_co2_flow_m3h": gas_regime.ng.get_molecule_flow("co2"),
        "ng_n2_flow_m3h": gas_regime.ng.get_molecule_flow("n2"),
        "ng_h2_flow_m3h": gas_regime.ng.get_molecule_flow("h2"),
        "ng_o2_flow_m3h": gas_regime.ng.get_molecule_flow("o2"),
    }

    stove_values = {
        "air_temp_C": gas_regime.air.temperature,
        "bfg_temp_C": gas_regime.bfg.temperature,
        "cog_temp_C": gas_regime.cog.temperature,
        "ng_temp_C": gas_regime.ng.temperature,
    }

    bf_pref = f"bf{bf}_stove"
    bf_stove = f"bf{bf}_stove{stove}"

    now = pd.Timestamp.now()

    prefixed_data = {f"{bf_stove}_{k}": v for k, v in data_values.items()}

    prefixed_data.update({f"{bf_pref}_{k}": v for k, v in stove_values.items()})

    df_data = pd.DataFrame([prefixed_data], index=[now])
    df_data.index.name = "Timestamp"

    wastegas_temps = pd.DataFrame({f"{bf_stove}_wastegas_temp_C": waste_gas_temp}, index=[now])
    wastegas_temps.index.name = "Timestamp"

    bf_stove_choise = cast(Stove, bf_stove)

    cog = prepare_data_for_gas(df_data, bf_stove_choise, "cog")
    bfg = prepare_data_for_gas(df_data, bf_stove_choise, "bfg")
    air = prepare_data_for_gas(df_data, bf_stove_choise, "air")
    ng = prepare_data_for_gas(df_data, bf_stove_choise, "ng")

    cog_quantities = calculate_quantities(*cog)
    bfg_quantities = calculate_quantities(*bfg)
    ng_quantities = calculate_quantities(*ng)
    air_quantities = calculate_quantities(*air)

    fuel = sum_quantities_dict(list(cog_quantities.keys()), [cog_quantities, bfg_quantities, ng_quantities])

    stove_temperature = wastegas_temps["bf1_stove11_wastegas_temp_C"].dropna().to_dict()

    features = generate_burning_features(list(fuel.keys()), fuel, air_quantities, stove_temperature)

    return features.iloc[0].to_dict()


class PolyStoveModel:
    def __init__(
        self,
        fitted_poly_dome: LinearRegression,
        poly_features_dome: PolynomialFeatures,
        fitted_poly_wg: LinearRegression,
        poly_features_wg: PolynomialFeatures,
    ):
        self.fitted_poly_dome = fitted_poly_dome
        self.poly_features_dome = poly_features_dome
        self.fitted_poly_wg = fitted_poly_wg
        self.poly_features_wg = poly_features_wg

    def predict_wg(
        self,
        adiabatic_flame_temperature_K: float,
        cv_real_MJ_m3_fuel: float,
        cv_real_MJ_m3_mixture: float,
        dome_temp: float,
        wastegas_temp: float,
    ) -> float:
        raw_X = np.array(
            [
                [
                    adiabatic_flame_temperature_K,
                    cv_real_MJ_m3_fuel,
                    cv_real_MJ_m3_mixture,
                    dome_temp,
                    wastegas_temp,
                ]
            ]
        )
        preprocessed_X = self.poly_features_wg.fit_transform(raw_X)
        wg_temp_preds = self.fitted_poly_wg.predict(preprocessed_X)
        return wg_temp_preds[0]

    def predict_dome(
        self,
        adiabatic_flame_temperature_K: float,
        cv_real_MJ_m3_fuel: float,
        cv_real_MJ_m3_mixture: float,
        dome_temp: float,
    ) -> float:
        raw_X = np.array(
            [[adiabatic_flame_temperature_K, cv_real_MJ_m3_fuel, cv_real_MJ_m3_mixture, dome_temp]]
        )
        preprocessed_X = self.poly_features_dome.fit_transform(raw_X)
        dome_temp_preds = self.fitted_poly_dome.predict(preprocessed_X)
        return dome_temp_preds[0]

    def temperature_prediction(
        self, initial_state: StoveInitialState, gas_regime: Sequence[StoveGasRegime]
    ) -> dict[pd.Timedelta, StoveTemperaturePrediction]:
        current_time_delta = pd.Timedelta(0)
        current_wg_temp = initial_state.wastegas_temperature
        current_dome_temp = initial_state.dome_temperature

        results = {}
        results[current_time_delta] = StoveTemperaturePrediction(current_dome_temp, current_wg_temp)

        for regime in gas_regime:
            for _ in range(regime.duration):
                preprocessed_gas_data = prepare_stove_model_features(current_wg_temp, regime)

                prediction_time = current_time_delta + pd.Timedelta(minutes=1)
                predicted_dome = self.predict_dome(
                    preprocessed_gas_data["adiabatic_flame_temperature_K"],
                    preprocessed_gas_data["cv_real_MJ_m3_fuel"],
                    preprocessed_gas_data["cv_real_MJ_m3_mixture"],
                    current_dome_temp,
                )
                predicted_wg = self.predict_wg(
                    preprocessed_gas_data["adiabatic_flame_temperature_K"],
                    preprocessed_gas_data["cv_real_MJ_m3_fuel"],
                    preprocessed_gas_data["cv_real_MJ_m3_mixture"],
                    current_dome_temp,
                    current_wg_temp,
                )

                results[prediction_time] = StoveTemperaturePrediction(predicted_dome, predicted_wg)

                current_wg_temp = predicted_wg
                current_dome_temp = predicted_dome
                current_time_delta = prediction_time

        return results
