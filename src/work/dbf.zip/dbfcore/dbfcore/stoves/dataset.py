from typing import Hashable, Optional, Sequence

import cantera as ct
import pandas as pd

from dbfcore.stoves import STANDARD_TEMPERATURE_K, Stove, StoveGas
from dbfcore.stoves.burning import calculate_real_burning


def get_gas_composition(stove_data: pd.DataFrame, stove_name: Stove, gas: StoveGas) -> pd.DataFrame:
    """
    Extract information about gas composition for one stove from signal group per whole blast furnace

    stove_data is expected to be output of bf*_stoves_input_gases signal groups
    """
    return stove_data[[column for column in stove_data.columns if column.startswith(f"{stove_name}_{gas}")]]


def extract_molecule_name_from_column_name(column_name: str) -> str:
    """
    Extract molecule name in gri30 model name convention from our column name
    column name is in format [bf id]_[stove id]_[gas id]_[molecule]_flow_m3h
    for example bf1_stove11_cog_n2_flow_m3h gets converted to N2
    """
    return column_name.split("_")[3].upper()


def get_normal_density_mass_kg_m3(row: pd.Series, species=ct.Species.list_from_file("gri30.yaml")):
    """
    Get density mass in kg/m3 at normal conditions - Standard temperature and standard pressure
    """
    gas = ct.Solution(thermo="ideal-gas", species=species)
    if row.sum() == 0.0:
        return 0.0
    gas.X = row.to_dict()
    gas.TP = STANDARD_TEMPERATURE_K, ct.one_atm
    return gas.density_mass


def get_density_mass_kg_m3(data: pd.DataFrame) -> pd.Series:
    return data.apply(get_normal_density_mass_kg_m3, axis=1)


def enhance_gas_dataframe(gas_composition_data: pd.DataFrame, temperature_data: pd.Series) -> pd.DataFrame:
    renamed_gas_data = gas_composition_data.rename(columns=extract_molecule_name_from_column_name)

    density = get_density_mass_kg_m3(renamed_gas_data)
    flow = renamed_gas_data.sum(axis=1)

    extra_data_df = pd.DataFrame(
        index=renamed_gas_data.index,
        data={
            "normal_density_kg_m3": density,
            "normal_flow_m3_h": flow,
            "mass_kg_h": density * flow,
            "temp_K": temperature_data + 273.15,
        },
    )

    return renamed_gas_data, extra_data_df


def get_gas_temperature_column_name(stove_data: pd.DataFrame, gas: StoveGas) -> str:
    all_selected_columns = [column for column in stove_data.columns if column.endswith(f"{gas}_temp_C")]
    if len(all_selected_columns) != 1:
        raise ValueError(f"Temperature column is not unique. Found columns: {all_selected_columns}")
    return all_selected_columns[0]


def prepare_data_for_gas(
    stove_data: pd.DataFrame, stove: Stove, gas: StoveGas
) -> tuple[pd.DataFrame, pd.DataFrame]:
    return enhance_gas_dataframe(
        get_gas_composition(stove_data, stove, gas),
        stove_data[get_gas_temperature_column_name(stove_data, gas)],
    )


def get_quantity(
    composition: tuple[Hashable, pd.Series], extra_data: tuple[Hashable, pd.Series]
) -> Optional[ct.Quantity]:
    if composition[0] != extra_data[0]:
        raise Exception("Quantity is calculable only for same index")

    composition_row = composition[1].to_dict()
    total_mass = extra_data[1]["mass_kg_h"]

    if total_mass == 0.0:
        return None

    gas_temperature = extra_data[1]["temp_K"]

    gas = ct.Solution(thermo="ideal-gas", species=ct.Species.list_from_file("gri30.yaml"))
    gas.TPX = gas_temperature, ct.one_atm, composition_row
    return ct.Quantity(gas, mass=total_mass)


def calculate_quantities(
    compositions: pd.DataFrame, extra_data: pd.DataFrame
) -> dict[Hashable, Optional[ct.Quantity]]:
    return {
        composition[0]: get_quantity(composition, extras)
        for composition, extras in zip(compositions.iterrows(), extra_data.iterrows())
    }


def sum_quantities(quants: Sequence[Optional[ct.Quantity]]) -> Optional[ct.Quantity]:
    defined_quants = [q for q in quants if q is not None]
    return sum(defined_quants[1:], start=defined_quants[0]) if defined_quants else None


def sum_quantities_dict(
    keys: Sequence[Hashable], quants: Sequence[dict[Hashable, Optional[ct.Quantity]]]
) -> dict[Hashable, Optional[ct.Quantity]]:
    return {key: sum_quantities([q.get(key) for q in quants]) for key in keys}


def generate_burning_features(
    keys: Sequence[Hashable],
    fuel: dict[Hashable, Optional[ct.Quantity]],
    oxidizer: dict[Hashable, Optional[ct.Quantity]],
    flue_temperature: dict[Hashable, Optional[float]],
) -> pd.DataFrame:
    burning_results = [
        calculate_real_burning(fuel.get(key), oxidizer.get(key), flue_temperature.get(key)) for key in keys
    ]

    df = pd.DataFrame(burning_results, index=keys)

    cv_cit = df["calorific_value_cooled_to_input_temp"].apply(pd.Series).add_prefix("cv_cit_")
    cv_cnt = df["calorific_value_cooled_to_normal_temp"].apply(pd.Series).add_prefix("cv_cnt_")
    cv_real = df["calorific_value_cooled_to_real_flue_temp"].apply(pd.Series).add_prefix("cv_real_")
    temperature = df[["adiabatic_flame_temperature_K"]]

    return pd.concat([temperature, cv_cit, cv_cnt, cv_real], axis=1)
