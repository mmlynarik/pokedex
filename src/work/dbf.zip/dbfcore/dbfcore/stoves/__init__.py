from typing import Literal

STANDARD_TEMPERATURE_K = 293.15

StoveGas = Literal["bfg", "ng", "cog", "air"]
Stove = Literal[
    "bf1_stove11",
    "bf1_stove12",
    "bf1_stove13",
    "bf1_stove14",
    "bf2_stove11",
    "bf2_stove12",
    "bf2_stove13",
    "bf2_stove14",
    "bf3_stove11",
    "bf3_stove12",
    "bf3_stove13",
    "bf3_stove14",
]
