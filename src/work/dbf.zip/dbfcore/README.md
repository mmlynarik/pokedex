# Introduction
`DBFCORE` is the main package of the DBF project. It contains all the information about data (how to download, store and process it), models (its features, training and inference) and various scripts to handle all tasks leading to an optimal setting of models for the control of blast furnaces (BF).

In order to train a **prediction model**, we need an initial information about the state of the BF. The initial information is obtained through the **embeddings** from **autoencoders** that are trained using **signal datasets**. Currently, we monitor multiple signals, which we use to generate multiple signal datasets. These datasets are subsequently used for training of the particular autoencoders and to get embeddings.


# Table of contents
- [Introduction](#introduction)
- [Table of contents](#table-of-contents)
- [Dataset](#dataset)
    - [Merging signal datasets](#merging-signal-datasets)
    - [Generating Gas and Burden Signals by Layers](#generating-gas-and-burden-signals-by-layers)
- [Datamodule](#datamodule)
- [Autoencoder training](#autoencoder-training)
    - [Local autoencoder training (w/o docker)](#local-autoencoder-training-wo-docker)
    - [Dockerized autoencoder training](#dockerized-autoencoder-training)
    - [Run tensorboard](#run-tensorboard)
- [Autoencoder embeddings](#autoencoder-embeddings)
- [Prediction model training](#prediction-model-training)
    - [Local prediction model training (w/o docker)](#local-prediction-model-training-wo-docker)
    - [Dockerized prediction model training](#dockerized-prediction-model-training)
- [Static file check and formatting](#static-file-check-and-formatting)
- [Unit tests](#unit-tests)
- [Legacy code](#legacy-code)
    - [Raw dataset](#raw-dataset)
        - [How to generate raw dataset](#how-to-generate-raw-dataset)
        - [How to load raw dataset](#how-to-load-raw-dataset)
        - [How to add a new column to the charge raw dataset](#how-to-add-a-new-column-to-the-charge-raw-dataset)
    - [Preprocessed dataset](#preprocessed-dataset)
        - [How to generate a preprocessed dataset](#how-to-generate-a-preprocessed-dataset)
        - [How to load a preprocessed dataset](#how-to-load-a-preprocessed-dataset)
    - [Dataset documentation](#dataset-documentation)
        - [How to generate the dataset documentation](#how-to-generate-the-dataset-documentation)


# Dataset
The first step in the prediction of the BF target variables (e.g. concentration of silicon in pig iron or pig iron temperature) is the feature extraction. In this step, specific autoencoder models are trained separately on individual signals over the defined time period. Signals relevant for autoencoder training form signal datasets in the 2-column-format consisting of timestamp (index) and actual value. Individual signal datasets are stored as `.parquet` files by default in the `.data/datamodule` folder.

*Example format of a signal dataset*
| Timestamp (index)   | Value |
| ------------------- | ----- |
| 2024-01-01 10:00:00 | 1500  |

<br>

To generate the relevant datasets as `.parquet` files use the following command (for more details see `./dbfcore/dbfcore/scripts/generate_signal_dataframe.py`):

```shell
generate_signal_dataframe -s 2018-01-01T00:00 -e 2024-01-01T00:00 -g {signal_group_name}
```
### Merging signal datasets
If we have multiple generated .parquet files of signal datasets from different time periods, we can merge them into a single .parquet file. Merging can take place in memory (RAM) or on disk (in batches). When merging in memory, the resulting file is sorted by the Timestamp field and does not contain duplicate records. When merging on disk, the user must ensure that:
1. the input files are sorted from the oldest to the newest, and
2. the input files do not overlap in time

To merge the individual files of signal datasets, use the following command (for more details see `./dbfcore/dbfcore/scripts/merge_signal_dataframe.py`):

```shell
merge_signal_dataframe -i data/datamodule/bf2_hotmetalfe_chem_pct_from_20250116T0000_to_20250117T0000.parquet data/datamodule/bf2_hotmetalfe_chem_pct_from_20250101T0000_to_20250101T0400.parquet bf2_hotmetalfe_chem_pct_from_20250115T0000_to_20250116T0000.parquet [-o output_filename] [-m disk]
```
### Generating Gas and Burden Signals by Layers
We can generate signals by layers over time and save them as a single .parquet file. The dataset, in a 5-minute time interval, contains the following data:
 - Gas – Temperature, Pressure, Composition (a total of 5 columns)
 - Burden – Temperature, Composition (a total of n columns)

To generate datasets as .parquet files use the following command (for more details see ./dbfcore/dbfcore/scripts/generate_signals_by_layers_gas_burden.py):
```shell
generate_signals_by_layers_gas_burden -s 2025-01-01T00:00 -e 2025-02-01T00:00 -f 1 [-o output_dir] [-t time_shift_of_gases_sec] [-b batch_size_hours]
```

# Datamodule
The `SignalsDataModule` or `VicRegDataModule` classes encapsulate all data-related objects necessary for training of autoencoder models. The most relevant input parameters of these datamodules are `signals`, `window_size` and `sequence_length`. The `Signal` class is identified by its `name`, `data_path` (path to preprocessed dataset), `mean` and `std`, and  datetimes specifying the amount of data used for training and validation of model.

The actual initialization of datamodule is performed in its `setup` divided into two steps:
   * loading signal dataframe from cached `.parquet` file by providing the path to this file
   * transforming dataframe into train and val dataloaders


# Autoencoder training
Autoencoders encode the state of a blast furnace at specified time into compressed form of essential features. Currently we use two autoencoders: `SignalVAESimple2` (for hotmetalchem and hotmetaltemp signals) and `VicReg` (for hotblast, stockrod, topgas, and chargeflow signals).

There are two options to train autoencoders. The first option is to train autoencoders locally. The other option, recommended, is to use containerized training via docker on either SkyNet or HalNet server. If everything is set up correctly, the following commands can be used to run the autoencoder training locally:

```shell
# SIgnalVAESImple training
train_autoencoder2 fit --config path/to/config.yaml

# VicReg training
train_vicreg fit -c path/to/config.yaml
```

### Local autoencoder training (w/o docker)
To train autoencoders locally there are several preparation steps that need to be done before the start:
  1. geneate signal datasets as `.parquet` files and save them (for more information see [Dataset](#dataset))
  2. create a config file
      * inside the config file, specify paths to the signal dataset `.parquet` files
      * use `update_config_with_normalizers_params` script to add normalizer params into the config file
  3. run `train_autoencoder2 fit --config path/to/config.yaml` or `train_vicreg_decoder fit -c path/to/config.yaml` in your local terminal

### Dockerized autoencoder training
To train autoencoders via docker on one of our servers (SkyNet or HalNet), there are several preparation steps that need to be done before the start:
  1. geneate signal datasets as `.parquet` files and save them (for more information see [Dataset](#dataset))
  2. check the disk capacity on WSL2 using the following set of commands (see also [Microsoft WSL2](https://learn.microsoft.com/en-us/windows/wsl/disk-space#how-to-expand-the-size-of-your-wsl-2-virtual-hard-disk)):
     *NOTE: if there is NO enough space on WSL2 disk, do NOT copy into the volume!*

     ```shell
     # 1. Find the wsl distro BasePath where ext4.vhdx file is located
     Get-ChildItem "HKCU:\Software\Microsoft\Windows\CurrentVersion\Lxss" -Recurse

     # 2. Check the disk capacity using DISKPART commands
     diskpart
     Select vdisk file="<BasePath\from\previous\command\ext4.vhdx>"
     detail vdisk
     ```

  3. create volume in docker (the easiest way is to use `volumes` tab in docker desktop)
     *NOTE: there are volumes that have already been created for the purpose of this project both on SkyNet and HalNet - these volumes are: `dbf-training-data` (SkyNet) and `autoencoder-training-data` (HalNet)*

     ```shell
     docker volume create <volume_name>
     ```

  4. copy datasets `.parquet` files into the volume (either using commands or just using the windows explorer):
     * copy using commands:

       ```shell
         # Create an interactive container
         docker container create --name dummyautoencodertraining -v autoencoder-training-data:/training  tianon/true
         # Copy files into the volume
         docker cp path\to\data\folder\in\explorer dummyautoencodertraining:/path/to/data/folder/in/docker
       ```

     * copy via Windows Explorer:
        * on SkyNet you can find the address to the docker volume here:
        `\\wsl.localhost\docker-desktop\mnt\docker-desktop-disk\data\docker\volumes\dbf-training-data\_data`
        * on HalNet you can find the address to the docker volume here:
        `\\wsl.localhost\docker-desktop-data\mnt\wslg\distro\data\docker\volumes\autoencoder-training-data\_data`
  5. create a config file and copy it into the docker volume
     * inside the config file, specify paths to the signal dataset `.parquet` files
     * use `update_config_with_normalizers_params` script to add normalizer params into the config file
  6. [OPTIONAL] create a `.ps1` script with the necessary parameters to run autoencoder training (example below)

      ```shell
      docker run -it `
        --gpus all `
        --entrypoint "/bin/bash" `
        --volume dbf-training-data:/training `
        --shm-size=4gb `
        dockregistry.kbs.sk.uss.com/digital/dbf_training:20241017.2 `
        -c "source activate dbf && train_autoencoder2 fit -c /training/config/config.yaml"
      ```

  7. run the `.ps1` script created in the previous step or command specified inside the script

### Run tensorboard
TensorBoard is a suite of web applications for inspecting and understanding ML model training runs and graphs. It enables tracking experiment metrics like loss and accuracy, visualizing the model graph, projecting embeddings to a lower dimensional space, and much more.

1. In order to run tensorboard locally, use the following command:

```shell
  tensorboard --logdir ./path/to/lightning_logs
```

2. In order to run tensorboard for dockerized training, use the following example:
   *NOTE: for easier access/manipulation, the following command can be embedded inside a `.ps1` file*

```shell
  docker run -it `
    --entrypoint "/bin/bash" `
    --volume autoencoder-training-data:/training `
    -p 6006:6006 `
    dockregistry.kbs.sk.uss.com/digital/dbf_training:20240919.4 `
    -c "source activate dbf && pip install protobuf==4.25 && tensorboard --logdir /training/lightning_logs --host 0.0.0.0"
```

# Autoencoder embeddings
Autoencoder embeddings is a collection of `.embedding` files that capture the state of a blast furnace at the defined time. They serve as necessary inputs for modelling of prediction models. To be able to use them, it is necessary to generate them using the following command (for more details see `./dbfcore/dbfcore/scripts/getembeddings.py`):

```shell
get_embeddings -c path/to/autoencoder/training/config.yaml -m path/to/autoencoder/model.ckpt -n path/emb_name.embeddings --modeltype "signalvaesimple"
```


# Prediction model training
Prediction model predicts a future state of a blast furnace. Based on the actual model, it predicts the future concentration of silicon in pig iron and/or the pig iron temperature. Training of prediction models is a final step in the `dbfcore` package.

Similarly as in autoencoders, there are two options to train prediction models. The first option is a local training. The other option, recommended, is a containerized training in docker. If everything is set up correctly, the following command can be used to run the prediction model training locally:

```shell
train_predictionmodel fit --config path/to/config.yaml
```

### Local prediction model training (w/o docker)
To train prediction models locally there are several preparation steps that need to be done before the start:
  1. get input embeddings (for more information see [Autoencoder embeddings](#autoencoder-embeddings))
  2. geneate target signal dataset as `.parquet` file (usually already generated before autoencoder training; for more information see [Dataset](#dataset))
  3. create a config file and inside the config file:
      * specify paths to the input embeddings (`.embeddings`)
      * specify the path to the target signal dataset `.parquet` file
      * specify the path to `.sqlite` database where embeddings will be stored during the training
      * specify train/val split ranges
  4. run `train_predictionmodel fit --config path/to/config.yaml` in your local terminal

### Dockerized prediction model training
To train prediction model via docker, there are several preparation steps that need to be done before the start (for more information see [Dockerized autoencoder training](#dockerized-autoencoder-training)):
  1. get embeddings as `.embeddings` files (for more information see [Autoencoder embeddings](#autoencoder-embeddings))
  2. geneate target signal dataset as `.parquet` file (for more information see [Dataset](#dataset))
  3. check the disk capacity on WSL2 using the following set of commands (see [Microsoft WSL2](https://learn.microsoft.com/en-us/windows/wsl/disk-space#how-to-expand-the-size-of-your-wsl-2-virtual-hard-disk))
  *!NOTE: if there is NO enough space on WSL2 disk, do NOT copy into the volume!*
  4. create volume in docker
  5. copy target signal dataset, embeddings, configs, and autoencoder checkpoints into the volume
  6. create a config file for prediction model training and copy it into the docker volume
      * specify paths to the input embeddings (`.embeddings`)
      * specify the path to the target signal dataset `.parquet` file
      * specify the path to `.sqlite` database where embeddings will be stored during the training
      * specify train/val split ranges
  7. [OPTIONAL] create a `.ps1` script with the necessary parameters to run autoencoder training (example below)

      ```shell
      docker run -it `
        --gpus all `
        --entrypoint "/bin/bash" `
        --volume dbf-training-data:/training `
        --shm-size=4gb `
        dockregistry.kbs.sk.uss.com/digital/dbf_training:20241017.2 `
        -c "source activate dbf && train_predictionmodel fit -c /training/config/config.yaml"
      ```

  8. run the `.ps1` script created in the previous step or command specified inside the script


# Static file check and formatting
To run the usual static file checkers and code formatters use the following commands:

```shell
echo "Running Mypy static-typing check"
mypy --config-file path/to/config/file .

echo "Running Black formatting check"
black --config path/to/config/file --check .

echo "Running Isort imports sorting check"
isort --settings path/to/config/file --check .

echo "Running Ruff linting check"
ruff check --config path/to/config/file .
echo "Linting check completed. No issues found."
```


# Unit tests
To run the unittests use the following command:

```shell
python -m unittest discover -s .\tests -t .
```





---

# Legacy code

### Raw dataset
The raw dataset is either a compilation of various data sources into one table where columns are generally only selected and not overly processed (now referred as a charge raw dataset) or a collection of multiple tables coming from PI database (now referred as a PI raw dataset).

In more detail:
   1. charge raw dataset
       * one big table saved as a pyarrow dataset
       * contains raw data about charges, pig iron tappings, granulometry, ...
       * by default stored in `./data/raw_dataset`
   2. PI raw dataset
       * composed of several `parquet` files
       * contains data coming from sensors, such as hotblast, topgas, stockrod, ...
       * by default stored in `./data/piapi`

##### How to generate raw dataset
To generate raw datasets, the first thing is to have configured access to databases. All environment variables needed to configure such access are specified in `config.env.template` file. The `setupenv.ps1` script can help you set the necessary environment variables. If you had set them up other way, just skip this step.

1. charge raw dataset
   * to generate BF1 data for 2021 use this command:

        ```shell
        generate_raw_dataset -s 2021-01-01 -e 2021-12-31 -b 1 [-p ./data]
        ```

   * to generate full development dataset for given blast furnace, start and end dates can be omitted, such as:

        ```shell
        generate_raw_dataset -b 1
        ```

2. PI raw dataset
   * TODO: add script to generate pi raw dataset (potentially unify datasets to one pyarrow dataset)

##### How to load raw dataset
To load charge raw dataset you need to specify the path to the **folder** where the charge raw dataset is stored. By default the charge raw dataset is stored in `./data/raw_dataset` folder.

```python
from dbfcore.dataset import load_dataset, load_dataset_as_dataframe

dataset = load_dataset("./path/to/dataset")
dataset_df = load_dataset_as_dataframe("./path/to/dataset")
```

After running this, `dataset` will contain full dataset in format specified in [datasets](https://huggingface.co/docs/datasets/index) library format. `dataset_df` will contain full dataset in pandas dataframe format.

Another feature is ability to load only selected columns:

```python
from dbfcore.dataset import load_dataset, load_dataset_as_dataframe

columns_to_load = ['date', 'tapping_number', 'tapping_start_date', 'tapping_end_date']
dataset = load_dataset("./path/to/dataset", columns_to_load)
dataset_df = load_dataset_as_dataframe("./path/to/dataset", columns_to_load)
```

<br>

To load PI raw dataset you need to specify a path to a specific `parquet` file in which individual data tables are stored. By default a collection of PI raw datasets is stored in `./data/piapi` folder.

```python
from dbfcore.dataset.hooks.piclient import get_pi_client, get_pi_point_by_name
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_cached_data

pi_point_name = get_pi_point_name_from_user_friendly_name(signal_name)
pi_point = get_pi_point_by_name(get_pi_client(), pi_point_name)
pi_data = get_pi_cached_data(pi_point, signal_name, start_date, end_date, "./path/to/dataset")
```

##### How to add a new column to the charge raw dataset
1. Add a new column to some query in DB hook
2. Add a new column along with its type to the relevant columns-generating function defined in `dataset.raw_dataset.raw_dataset_columns.py`
3. Re-generate the charge raw dataset to refresh the stored dataset


### Preprocessed dataset
For analytical purposes and further modelling, the charge raw dataset is transformed into a preprocessed dataset using the specified set of transformation functions. In contrast to raw dataset, **you can define and use multiple preprocessed datasets at the same time**. Each preprocessed dataset is identified by its unique name and stored in the dedicated subfolder (with the dataset name being the name of the subfolder) within `PREPROCESSED_DATASETS_PATH` folder. In general, each instance of preprocessed dataset should correspond to some analytical or other similar use case, e.g. `causality-analysis` (see below).

##### How to generate a preprocessed dataset
To generate a preprocessed dataset, you first need to define three constants that unambiguously specify how the dataset will look like. By convention, they should be defined in a dedicated module along with other related code such as transformation functions. For the `causality-analysis` dataset, they are defined in `causality_analysis_preprocessing.py` located in `./data/preprocessed_datasets` folder. The naming convention for these constants is that the dataset name is their prefix:

The three constants you need to define are:

1. the **dataset key** which is used as a dictionary key:
    ```python
    CAUSALITY_ANALYSIS_KEY = "causality-analysis"
    ```

2. a set of **dataset transformations** corresponding to the list of transformation functions (if parametrized, defined using a `partial` function):
    ```python
    TransformationsCallables = list[Callable[..., pd.DataFrame]]

    CAUSALITY_ANALYSIS_TRANSFORMATIONS: TransformationsCallables = [
        calculate_total_charge_weight,
        partial(calculate_mineral_weight_of_all_raw_materials, minerals=MINERALS),
        partial(calculate_total_mineral_weight, minerals=MINERALS),
        partial(drop_columns, columns=cauality_analysis_columns_to_drop),
        get_coke_charge_weight,
        partial(select_columns, columns=CAUSALITY_ANALYSIS_FEATURES.keys()),
    ]
    ```

3. a set of **dataset output columns** corresponding to the list of features the preprocessed dataset will contain:
    ```python
    ValueDict = dict[str, Value | Sequence]

    CAUSALITY_ANALYSIS_FEATURES: ValueDict = dict(
        {
            **PREDICTORS,
            "tapping_id": get_int32_with_label("ID odpichu"),
            TARGET: get_float32_with_label("Vážený priemer kremíka z eligible tavieb"),
            "date": get_timestamp_with_label("Dataset index"),
        }
    )
    ```

These three constants must be then added to `preprocessed_datasets_config` dictionary in `dataset.preprocessed_dataset.generate_preprocessed_dataset.py` module as follows:
```python
preprocessed_datasets_config: dict[str, tuple[TransformationsCallables, ValueDict]] = {
    CAUSALITY_ANALYSIS_KEY: (CAUSALITY_ANALYSIS_TRANSFORMATIONS, CAUSALITY_ANALYSIS_FEATURES)
    ANOTHER_KEY: (ANOTHER_TRANSFORMATIONS, ANOTHER_FEATURES),
    ...
}
```

Finally, the preprocessed dataset can be generated and saved into the specified folder (by default it's `./data/preprocessed_datasets`) by running the following shell command. Please note that the charge raw dataset must be already generated and saved in the respective folder in order for this command to run correctly. If the raw dataset is stored in custom folder, the parameter `-r` or `--raw-dataset` must be set to point to that folder.

```shell
generate_preprocessed_dataset -n causality-analysis
```

##### How to load a preprocessed dataset
Loading of a preprocessed dataset works the same way as loadig of the charge raw dataset (described [here](#1.2-load-raw-dataset)). As an argument, you have to define the path to a preprocessed dataset.


### Dataset documentation
Documentation is an elemental component of a dataset. The dataset documentation provides basic information about the columns of a dataset, their description and the unit in which the value is measured.

##### How to generate the dataset documentation
To generate dataset documentation you simply use the following command created for this purpose. This command takes two arguments:
1. path to dataset from which you want to generate the documentation
2. the name for the documentation file

Documentation is stored as a JSON file.

```shell
generate_dataset_documentation -p ./path/to/dataset -n documentation_name
```