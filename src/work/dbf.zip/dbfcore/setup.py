"""A setuptools based setup module.

See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

from os import path

# Always prefer setuptools over distutils
from setuptools import find_packages, setup

here = path.abspath(path.dirname(__file__))

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

with open(path.join(here, "install_requires.txt"), encoding="utf-8") as f:
    install_requires = f.read().splitlines()

setup(
    name="dbfcore",
    version="0.1.0",
    package_data={},
    packages=find_packages(),
    description="Calculations for blast furnace model",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=install_requires,
    zip_safe=False,
    entry_points={
        "console_scripts": [
            "generate_raw_dataset=dbfcore.scripts.generate_raw_dataset:main",
            "generate_preprocessed_dataset=dbfcore.scripts.generate_preprocessed_dataset:main",
            "generate_dataset_documentation=dbfcore.scripts.generate_dataset_docs:main",
            "generate_signal_dataframe=dbfcore.scripts.generate_signal_dataframe:main",
            "generate_signals_by_layers_gas_burden=dbfcore.scripts.generate_signals_by_layers_gas_burden:main",
            "merge_signal_dataframe=dbfcore.scripts.merge_signal_dataframe:main",
            "train_mb_model=dbfcore.materialbalancemodel.cli:main",
            "train_autoencoder2=dbfcore.scripts.trainsignalvaesimple2:main",
            "train_predictionmodel=dbfcore.scripts.trainpredictionmodel:main",
            "get_embeddings=dbfcore.scripts.getembeddings:main",
            "get_augmented_data_from_embeddings=dbfcore.scripts.getaugmenteddatafromembeddings:main",
            "update_config_with_normalizer_params=dbfcore.scripts.update_config_with_normalizer_params:main",
            "train_vicreg=dbfcore.scripts.trainrealvicreg:main",
            "train_vicreg_decoder=dbfcore.scripts.trainvicregdecoder:main",
        ]
    },
)
