# Connection to OKO

In some version configuration of python, FreeTDS and pymssql there are problems to connect. Application starts to hang and there is nothing you can do. 

The underlying problem is in default settings of communication encryption. In newer versions encryption is turned on as a default. To connect to oko one needs to turn this encryption off.

The only possibility how to turn the encryption off in our setting is to use freetds.conf file. 

There are several default paths for freetds.conf file c:\freetds.conf and C:\Users\[your account]\AppData\Roaming/.freetds.conf or see `https://www.freetds.org/userguide/freetdsconf.html#freetdsconflocation` but you can also set it through environment variable FREETDS.

