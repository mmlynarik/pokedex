# How to connect to MSSQL from django
## Linux/Docker
1. Install dependencies `apt-get install unixodbc tdsodbc freetds-bin`
1. Create config files `odbc.ini` and `odbcinst.ini` and place them to `/etc` folder
1. Optionally create `freetds.conf` and place it to config folder. You can find out config folder by using `tsql -C`
1. Now you can test connection by using `isql connection_name username password`. Connection name is reference to connection from `odbc.ini`
1. Other way to test connection is to use `tsql -S connection_name -U username -P password` but this requires to have `freetds.conf` config in place. For details see FreeTDS website
1. If this is working you can set up django. Install dependencies `pip install mssql-django`
1. Configure by documentation of `mssql-django` Find example configuration below.

### odbcinst.ini
You can turn on/off logging for debugging purposes by using Trace options.

```ini
[FreeTDS]
Description = FreeTDS unixODBC Driver
Driver = /usr/lib/x86_64-linux-gnu/odbc/libtdsodbc.so
Setup = /usr/lib/x86_64-linux-gnu/odbc/libtdsS.so
UsageCount = 1
Trace        = No
TraceFile    = /tmp/sql.log
ForceTrace   = No
```

### odbc.ini
`FreeTDS` below is name of configuration from `odbcinst.ini` other stuff is self explanatory.

```ini
[connection_name]
Driver = FreeTDS
Description = ODBC connection via FreeTDS
Server = vsqldev17.sk.uss.com
Port = 1433
Database = digital_dbf
Trace        = No
TraceFile    = /tmp/sql.log
ForceTrace   = No
```

## Windows
1. Download and install ODBC Driver for SQL Server (new version is needed >17) Google: `Download ODBC Driver for SQL Server` for newest version
1. Setup configuration in ODBC Data Sources
 ![image](./windowsdocs/winstep1.PNG)
1. Setup configuration, do not forget to click on Trust server certificates
![image](./windowsdocs/winstep2.PNG)
![image](./windowsdocs/winstep3.PNG)
![image](./windowsdocs/winstep4.PNG)
![image](./windowsdocs/winstep5.PNG)
![image](./windowsdocs/winstep6.PNG)
![image](./windowsdocs/winstep7.PNG)

## Example django configuration
```python
BACKEND_DB_SETTINGS = {
    "ENGINE": "mssql",
    "NAME": "digital_dbf", # Name of database
    "USER": "SK\\vbofoc",
    "PASSWORD": "******",
    "OPTIONS": {
        "driver": "FreeTDS",
        "dsn": "connection_name" # Reference to odbc.ini or name in ODBC Data Source
    },
}
```