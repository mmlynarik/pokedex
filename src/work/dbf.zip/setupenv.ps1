foreach ($line in Get-Content .\config.env.template) {
    if ($line -match "^#.*") {
        Write-Host Ignoring line $line
    }
    else {
        $name, $value = $line -split "="
        if ($value -match 'xxxxxxxx') {
            $prompt = 'Please enter ' + $name
            $value = Read-Host -Prompt $prompt
        }
        $x = '$env:' + $name + '="' + $value + '"'
        Write-Host Setting up env variable $name to $value
        Invoke-Expression $x
    }
}