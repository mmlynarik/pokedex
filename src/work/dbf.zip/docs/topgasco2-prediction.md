# Introduction

The following document describes baseline models used to predict topgasco2 signal. The code that generated the results below is at `experimental/topgasco2-prediction/topgasco2-prediction.ipynb`.

## Dataset

Dataset consists of target and predictor variables calculated based on specified lookback period (further defined by lag period and number of lags) and forecast period. Each observation is constructed such that each predictor variable is calculated for the number of lags with the most recent lag (t=0) being forecast period before target variable. Each lagged variable is calculated as an average over given lag period.


## Simple average-based baseline model

As a non-parametric baseline model, we've chosen a simple training dataset average. The MSE and MAE metrics for this baseline are as follows:

![baseline-avg](images/topgasco2-prediction-avg-baseline.png)


## Time-series regression baseline model

The dataset used for time series baseline model was constructed using following six different setups:
- 2 lags, 1h lag period, 1h forecast period
- 4 lags, 30min lag period, 1h forecast period
- 8 lags, 15min lag period, 1h forecast period
- 2 lags, 1h lag period, 30min forecast period
- 4 lags, 30min lag period, 30min forecast period
- 8 lags, 15min lag period, 3min forecast period

The results for **1h forecast period** with lags 2, 4 and 8 are as follows. The 8-lag results are affected by low number of observations due to missing values in at least one calculated lag:

![1h-forecast](images/topgasco2-prediction-1h-forecast.png)

The results for **30min forecast period** with lags 2, 4 and 8 are as follows. The 8-lag results are affected by low number of observations due to missing values in at least one calculated lag:

![30min-forecast](images/topgasco2-prediction-30min-forecast.png)
