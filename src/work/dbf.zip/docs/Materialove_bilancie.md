# BILANCIA FE

### VSTUPY

- <u>vsadzka zvrchu:</u>
  
  1. fe2o3_weight
  
  2. feo_weight

. <u>PCI:</u>

1. *zatial som neriesil*

### VYSTUPY

- <u>zelezo:</u>
  
  1. analyza:
     
     - mineralogicka analyza zeleza v %
     
     - analyzu `Fe_pct` vypocitat pomocou vzorca: `100 - sum(pct_vsetky_ostatne_prvky)`
     
     - tabulky, v ktorych mame udaje o mineralogickej analyze: 
       
       1. `AZVP.EKONOM.ANALYZY_VZORIEK` - k dispozicii su analyzy z troch vzoriek odobratych pocas odpichu
       
       2. `AZVP.EKONOM.ANALYZY_ZELEZA` - priemer analyz vsetkych vzoriek v ramci odpichu
  
  2. hmotnost:
     
     - hmotnost suroveho zeleza po odpichu
     
     - zelezo sa po odpichu prevaza na oceliaren v pojazdnych miesacoch
     
     - hmotnost sa urcuje po vyliati zeleza z pojazdneho miesaca
     
     - postup pri vazeni je popisany v dokumente [Hmotnosti_a_analyzy_suroveho_zeleza.md](Hmotnosti_a_analyzy_suroveho_zeleza.md)
     
     - tabulky, v ktorych mame udaje o hmotnosti:
       
       1. `AZVP.EKONOM.DODAVKY_FE` - nie su vsetky hmotnosti, pretoze miesacu, ktory je naplneny viacerymi odpichmi sa priradi cislo odpichu, ktory sa plni ako posledny
       
       2. `PZVP.DISP.PRIRADENIE` - vsetky hmotnosti, aj ciastkove priradene k jednotlivym odpichom

- <u>troska:</u>
  
  1. analyza:
     
     - k dispozicii mineralogicka analyza trosky v % spolu s casom analyzy
     
     - tabulky, v ktorych mame udaje o mineralogickej analyze:
       
       1. `AZVP.EKONOM.ANALYZA_TROSKY` - zaujima nas polozka `PER_FE`
  
  2. hmotnost:
     
     - hmotnost trosky po odpichu
     
     - hmotnost sa urcuje podla poctu naliatych kolib, kde sa troska zbiera (hmotnost koliby = 30t)
     
     - mesacny sumar hmotnosti je k dispozicii v reportovacej tabulke po zvazeni externou firmou
     
     - postup pri vazeni je popisany v dokumente [Hmotnosti_a_analyzy_suroveho_zeleza.md](Hmotnosti_a_analyzy_suroveho_zeleza.md)
     
     - tabulky, v ktorych mame udaje o hmotnosti:
       
       1. `AZVP.EKONOM.KOLIBY` - hmotnosti per odpich na zaklade poctu kolib
       
       2. `PZVP.EKONOM.THU_HUVP` - mesacny sumar po zvazeni

---
# CELKOVA MATERIALOVA BILANCIA
For now, the full material balance is calculated as a balance between **inputs**:
- blast furnace charge
- QPU (praskove uhlie)

and **outputs**:
- pig iron
- slag
- blast furnace dust (odprasenie)
- blast furnace gas

NOTE: For the complete *full material balance*, we are still missing the weights of hot wind and natural gas in the inputs and the weight of solids (zliatky) in the outputs.

**INPUTS**
1. *Blast furnace charge weight* is calculated as a sum of weights of all raw materials entering the blast furnace in one charge
2. *QPU weight* is calculated  from the  QPU flow rate measured using sensors in kilograms per hour [kg/h] - thus simple calculation is performed to calculate QPU weight per 5 minutes (sensors data interval)

**OUTPUTS**
1. *Pig iron weight* is calculated as a sum of the pig iron parts poured into (1-6) mixers during the tapping
2. *Slag weight* is calculated as a sum of "slags" poured into the slag pots (1-10); one full pot weights 30 tons and operators estimate the filling of slag pots by quarters
3. *Blast furnace dust weight* is calculated using simple calculation - 20 kg of dust per 1 ton of pig iron
4. *Blast furnace gas weight* is calculated as a sum of partial weights of chemical compounds contained in the blast furnace gas (`CO`, `CO2`, `H2`, and `N2`); sensors measure the flow rate of the gas, its temperature and pressure, as well as the percentage representation of each compound; the resulting weight of the particular compound is calculated using the ideal gas law formula `m = (pVM)/(RT)`, where `p` is the partial pressure of the particular compound, `V` is the volume of the gas, `M` is the molar mass of the compound, `R` is the ideal gas constant, and `T` is the thermodynamic temperature of the gas

All of the above mentioned variables are calculated in transformations resulting in a set of inputs (charge and QPU) and outputs (pig iron, slag, BF dust, and BF gas) to be summarized. In the end, all inputs and outputs are summed up to create one `input` and one `output` time series to be analyzed. Using the function `calculate_output_input_weight_ratio_per_standard_time_period` input and output time series are grouped by the defined time period, summed up and the ratio between output and input time series is calculated.

**Current material balance results:**

![image.png](https://vdevops.sk.uss.com/AADT/dcb4030d-c5f6-4a2a-aa05-61ea7203bb80/_apis/git/repositories/1259c2d2-d119-4701-b18a-25cbaa2a7b5e/pullRequests/1564/attachments/image.png) 

**TODO:**
- add hot wind to inputs
- natural gas to inputs
- add solids to outputs

---
# MATERIALOVA BILANCIA UHLIKU
Material balance of carbon is calculated as a balance between **inputs**:
- blast furnace charge
- QPU (praskove uhlie)

and **outputs**:
- pig iron
- slag
- blast furnace gas
- blast furnace dust (odprasenie)

NOTE: We ommited natural gas in the inputs and the weight of solids (zliatky) in the outputs.

**INPUTS**
1. *Blast furnace charge weight* - same as in the full material balance - the weight of carbon was calculated
2. *QPU weight* - same as in the full material balance - the weight of carbon was calculated (we assume the presence of 80% of carbon in QPU)

**OUTPUTS**
1. *Pig iron weight* - same as in the full material balance - the weight of carbon was calculated
2. *Slag weight* - same as in the full material balance - the weight of carbon was calculated
3. *Blast furnace gas weight* - same as in the full material balance - the weight of carbon in CO as well as CO2 was calculated
4. *Blast furnace dust weight* - same as in the full material balance - we assume that the dust contains about 20% of carbon

All of the above mentioned variables are calculated in transformations resulting in a set of inputs (charge and QPU) and outputs (pig iron, slag, BF dust, and BF gas) to be summarized. In the end, all inputs and outputs are summed up to create one `input` and one `output` time series to be analyzed. Using the function `calculate_output_input_weight_ratio_per_standard_time_period` input and output time series are grouped by the defined time period, summed up and the ratio between output and input time series is calculated.

**Current material balance results:**

![image (2).png](blob:http://vdevops.sk.uss.com/8e4d9a27-1eb8-431f-b89e-5f93da2b2a4e) 
![image (3).png](blob:http://vdevops.sk.uss.com/8f3cb732-ffec-4446-a4fd-eda540f42165) 