## Introduction
The forecast aggregation function is the final component of the blast furnace models' pipeline which processes multiple model predictions and outputs final `expected-value` forecast. The following document
describes how to evaluate various forecast aggregation functions in order to identify the optimal one.

## Prerequsites
The evaluation of aggregation functions requires that
- `PredictionModel` from which forecasts will be generated is defined in the database
- `PI` datasource is properly configured and the PI API is responding
- Aggregation functions to be evaluated are defined in `reduce_predictions` function within `expectedvalue.py` module

## Evaluation of aggregation functions
The evaluation procedure can be run from the `forecast_expected_value.ipynb` notebook. The procedure has the following steps:
- **Configuration of input parameters**
  - `model` -> PredictionModel used to generate forecasts
  - `start` -> Start date of the evaluation period from which target samples will be fetched
  - `end` -> End date of the evaluation period from which target samples will be fetched
  - `num_samples` -> Number of target samples used for evaluation. If all samples from the evaluation period are needed, use `None` value
  - `num_calc_times` -> Number of calculation times evenly distributed over forecast horizon for which each target sample will be evaluated.
       - **Example**: if e.g. `forecast_horizon = 4h`, `num_calc_times = 4`, `target_timestamp = 2024-07-15 13:10:26`, then `forecast_time = 2024-07-15 13:10:00`, `calc_times` for this forecasted target
       will be `2024-07-15 09:10:00` (4h forecast), `2024-07-15 10:10:00` (3h forecast), `2024-07-15 11:10:00` (2h forecast) and `2024-07-15 12:10:00` (1h forecast)
- **Calculation of evaluation dataset**
  - Function `get_forecast_expected_value_eval_data` takes input parameters and returns DataFrame with targets and calculated forecasts for each combination of forecast time, calc_time and aggregation function
  - Function `get_forecast_expected_value_errors` takes output of previous function and adds to the evaluation dataset absolute forecast errors
    ![alt text](images/forecast_expected_value_data.png)
- **Calculation of mean absolute errors for each distance (i.e. difference between `forecast_time` and `calc_time`) and aggregation function**
  - Function `get_forecast_expected_value_mae` takes evaluation dataset and returns results
  - Currently implemented aggregation functions are `mean`, `weighted mean`, `median,` `weighted median`, `truncated mean`.
  - ![alt text](images/forecast_expected_value_results.png)

## New aggregation function
If new aggregation function is required, it can be added into `reduce_predictions` function in `expectedvalue.py` module, which accepts as its first argument a tuple of two lists `tuple[list[float], list[int]]`,
where first list contains `values` and the second `weights`. The weights are currently calculated linearly from `distance` variable. If other logic for weight variable is required, modify `calculate_forecast_weight`
function first.
