## How to download database from test

1. [Working connection to k8s](https://vdevops.sk.uss.com/AADT/LEAF/_wiki/wikis/LEAF.wiki/72/Kubernetes)
1. Find out name of the pod `kubectl get pod`
1. Exec into web app pod `kubectl exec [pod name] -it -- bash`
1. In pod container activate environment `conda activate dbf`
1. In pod container make db backup `python manage.py dumpdata --exclude auth --exclude admin --exclude contenttypes --exclude sessions --exclude messages
   --exclude staticfiles --format json > [backup file location on pod]`
1. Copy backup file from test environment to local machine `kubectl cp [pod name]:[backup file location on pod] [local path] --retries 100`
1. Optionally copy media folder as models are stored there `kubectl cp [pod name]:/source/dbfapp/media [local folder with media] --retries 100`
1. Flush local database. Check twice that you are using local database. `python manage.py flush`
1. Load backup to local database `python manage.py loaddata [local path of backup file]`
1. Copy downloaded media to local media folder

## How to run application in local Kubernetes cluster

- Run `minikube start` to start local k8s cluster
- Delete `secret.yaml.template` file
- Copy `secret.yaml` file from devops into `k8s/dbf/charts/configuration/templates` folder
- Run `make image`
- Run `make save`
- Run `make load`
- Add `python manage.py migrate` to command of all containers that need to work with db
- In `configmap.yaml` change `DBFAPP_USEDB` to `local`
- In `persistentvolumeclaim.yaml` comment `storageClassName: rook-cephfs` and change `accessModes` to `ReadWriteOnce`
- In all pod/container definitions, change image to `dbf:latest`, and add `imagePullPolicy` to `Never`
- Run `make helm`
- Run `minikube dashboard --url` to start minikube dashboard
- Run `service minikube service [service name]` to publish your service
