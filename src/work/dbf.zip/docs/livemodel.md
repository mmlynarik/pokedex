# Live model

## How to run live model locally
1. Setup environment variables according to config.env.template
1. All of next actions need to be done in django app folder: `cd dbfapp`
1. `python manage.py migrate`
1. If new database was created run `python manage.py createsuperuser` to create admin user to get to django admin
1. To run django admin run `python manage.py runserver`
1. Setup model in django admin
1. Run model calculation by `python manage.py runmodels --interval 30s` or `python manage.py runmodels --interval 30s --autoreload` to reload changed files automatically

## How to setup model in django admin
1. Add trained encoders that will be needed through `Encoders` section in admin - name could be anything path to autoencoder is path to `*.ckpt` of autoencoder
1. Add signals through `Signals` section. Source is one of `pi`. Name is name of signal in `pi` system for `pi`
1. Add connection of signal and encoder through `Signal Encoders` admin section.
1. Add prediction model through `Prediction models` section. Name can be anything.
1. Add model input definitions through `Model input outputs` Order is important and inputs need to be in order in which model was trained.


## How to import prediction model configuration into django admin
1. In Kubernetes, exec into container of the **web** pod `dbf-web-test-XXXXXX-YYYYY`
1. Activate virtual environment `conda activate dbf`
1. Change dir to scripts `cd /source/scripts`
1. Run shell script `source map_network_hdd.sh -u $AD_USERNAME_Y_IT_DSE -p $AD_PASSWORD_Y_IT_DSE -w $WIN_SHARED_TRAINED_MODELS_DIR -m $TRAINED_MODELS_DIR`
1. Change dir to dbfapp `cd /source/dbfapp`
1. Import model by specifying correct model config.yaml and name `python manage.py importmodel [model_name] --config /source/dbfcore/dbfcore/predictionmodel/configs/[model_name].yaml --ckpts /source/trained_models/`
