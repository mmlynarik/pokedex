### Natrenovane modely (autoenkodery)

| Snimac                           | Signal                     | Data precistene                     | Stav modelu                                                | Link na model                       |
| :------------------------------- | -------------------------- | :---------------------------------- | :--------------------------------------------------------- | :---------------------------------- |
| SK1.Gap.Phase                    | gap_phase_enum             | Nie (netreba) / ine predspracovanie | OK (1h) - mensi latent space? vacsie casove okno?          | HalNet/ verzia 30                   |
| SK1.HotBlast.Flow.Nm3/hr         | hotblast_flow_Nm3h         | Ano                                 | +/- OK (0.5h a 1h) - mensia seq_len?                       | HalNet/ verzia 52 pre 1h            |
| SK1.HotBlast.PCI.Flow.kghr       | hotblastpci_flow_kgh       | Nie (netreba)                       | +/- OK (0.1 alebo 0.05h)                                   | HalNet/ verzia 38 a 44              |
| SK1.HotBlast.O2.Flow.Nm3/hr      | hotblasto2_flow_Nm3h       | Ano                                 | +/- OK - neoptimalne (mensie casove okno? mensia seq_len?) | HalNet/ verzia 53 pre 1h            |
| SK1.HotBlast.Moisture.Flow.g/Nm3 | hotblastmoisture_flow_gNm3 | Ano                                 | +/- OK                                                     | HalNet/ verzia 58 pre 0.5h          |
| SK1.HotBlast.Temperature1.Temp.C | hotblast_temp_C            | Nie (netreba)                       | +/- OK (1h)                                                | HalNet/ verzia 34 pre 1h            |
| SK1.Top.StockRod1.Distance.m     | stockrod1_distance_m       | Ano (stockrod)/ male vylepsenia     | OK - pre 0.5h (ale nevyuzivame cely latentny priestor)     | HalNet/ verzia 19 pre 0.5h          |
| SK1.Top.StockRod2.Distance.m     | stockrod2_distance_m       | Ano (stockrod)/ male vylepsenia     | OK - pre 0.5h                                              | HalNet/ verzia 20 pre 0.5h (val)    |
| SK1.Top.Gas.CO.%                 | topgasco_chem_pct         | Ano                                 | OK - pre 0.5h                                              | HalNet/ verzia 47 pre 0.5h          |
| SK1.Top.Gas.CO2.%                | topgasco2_chem_pct        | Ano                                 | OK - pre 0.5h                                              | HalNet/ verzia 49 pre 0.5h          |
| SK1.Top.Gas.H2.%                 | topgash2_chem_pct         | Ano                                 | OK - pre 0.5h                                              | HalNet/ verzia 51 pre 0.5h          |
| Vsadzka podla chemii - C         | chargec_flow_kgh           | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 21            |
| Vsadzka podla chemii - CaO       | chargecao_flow_kgh         | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 34            |
| Vsadzka podla chemii - Fe2O3     | chargefe2o3_flow_kgh       | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 23            |
| Vsadzka podla chemii - FeO       | chargefeo_flow_kgh         | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 25            |
| Vsadzka podla chemii - H2O       | chargeh2o_flow_kgh         | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 28            |
| Vsadzka podla chemii - MgO       | chargemgo_flow_kgh         | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 32            |
| Vsadzka podla chemii - Mn        | chargemn_flow_kgh          | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 26            |
| Vsadzka podla chemii - SiO2      | chargesio2_flow_kgh        | Ano (autoencoder-flows)             | OK - pre 0.5h                                              | HalNet/Ubuntu/ verzia 30            |
| SK1.HotMetal.Temp.MeasDevice.C   | hotmetal_temp_C            | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 77 (24h) / 106 (1h)  |
| Chemia suroveho zeleza - C       | hotmetalc_chem_pct        | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 88 (24h) / 123 (1h)  |
| Chemia suroveho zeleza - Mn      | hotmetalmn_chem_pct       | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 93 (24h) / 127 (1h)  |
| Chemia suroveho zeleza - P       | hotmetalp_chem_pct        | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 99 (24h) / 124 (1h)  |
| Chemia suroveho zeleza - S       | hotmetals_chem_pct        | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 109 (24h) / 125 (1h) |
| Chemia suroveho zeleza - Si      | hotmetalsi_chem_pct       | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 114 (24h) / 126 (1h) |
| Chemia suroveho zeleza - Zn      | hotmetalzn_chem_pct       | Nie (netreba)                       | OK - dlhy autoenkoder (24h) -> kratky (1h)                 | HalNet/ verzia 119 (24h) / 128 (1h) |
|                                  |                            |                                     |                                                            |                                     |
| SK1.NaturalGas.Tuyeres.Vol.m3/h  | hotblastng_flow_m3h        | Nie - otazne ci treba               | Nezacaty                                                   |                                     |
| Granulometria vsadzky            |                            |                                     | Nemusi byt v prvej verzii                                  |                                     |
| Teploty odtahov                  |                            |                                     | Nemusi byt v prvej verzii                                  |                                     |
| Ostatne podla DTP                |                            |                                     | Nezacaty                                                   |                                     |

**NOTE!: Vsetky modely su tiez dostupne na disku Y na adrese `Y:\Departments\IT\DSE\DBF Y\!MODELS` vo formate `{signal_name}.ckpt`**

<br>

### Limity

| Snimac                | Hodnota 95 percentilu L1 chyby na vycistenych datach |
| :-------------------- | :--------------------------------------------------- |
| Mnozstvo vetra        | 1000                                                 |
| Kyslik vo vetre       | 100                                                  |
| CO                    | 0.1                                                  |
| CO2                   | 0.1                                                  |
| H2                    | 0.1                                                  |
| PCI                   | 100 (pravdepodobne 1000)                             |
| Koks                  | ??                                                   |
| Vsadzka               | ??                                                   |
| Teplota odtahov       | 10                                                   |
| Miera pece (stockrod) | 10                                                   |
| Vlhcenie vetra        | 1                                                    |
| Zemny plyn            | 100                                                  |
| Teplota vetra         | 10                                                   |

<br>

### Embedingy
Vsetky embedingy su dostupne na disku Y na adrese `Y:\Departments\IT\DSE\DBF Y\!EMBEDDINGS` vo formate `{signal_name}.embeddings`**