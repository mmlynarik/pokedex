### HMOTNOST SUROVEHO ZELEZA

- surove zelezo pri odpichu tecie do pojazdnych miesacov
- surove zelezo z jedneho odpichu sa moze rozdelit do viacerych pojazdnych miesacov
- **NOTE!:** hmotnost zeleza sa zadava rucne -> chybajuce udaje su mozne (ludsky faktor)

Tabulky, kde hladat hmotnosti suroveho zeleza:

1. `AZVP.EKONOM.DODAVKY_FE`
   
   - v tejto tabulke su skutocne hmotnosti celych pojazdnych miesacov
   
   - ak je pojazdny miesac plneny z viacerych odpichov, hmotnost sa priradi k poslednemu odpichu, ktorym sa miesac plnil

2. `PZVP.DISP.PRIRADENIE`
   
   - v tejto tabulke su skutocne hmotnosti jednotlivych frakcii suroveho zeleza, ktore sa plnili do jednotlivych miesacov
   
   - **pre nas lepsia (presnejsia)**
   
   - hmotnost suroveho zeleza v ramci jedneho odpichu sa urcuje nasledovne:
     
     1. odpich sa plni do 3 miesacov
     
     2. prvy miesac sa naplni cely - operator zahlasi, ze miesac je plny a priradi sa mu odhadovana hmotnost 300t
     
     3. druhy miesac sa naplni do polovice - operator zahlasi, ze v miesaci je odhadovane mnozstvo 150t, cize frakcia 0.5
     
     4. treti miesac sa naplni do tretiny - operator zahlasi, ze v miesaci je odhadovane mnozstvo 100t, cize frakcia 0.333
     
     5. miesac pride na oceliaren, kde sa zelezo zo vsetkych miesacov zvazi
     
     6. zelezo z prveho miesaca sa zvazi a ma hmotnost 305t
     
     7. zelezo z druheho miesaca, kde bola frakcia 0.5, sa zvazi a ma hmotnost 300t
     
     8. z druheho miesaca sa urci hmotnost pre dany odpich 0.5 * 300 = 150t
     
     9. hmotnost zeleza z tretieho miesaca sa urci analogicky ako hmotnost z druheho miesaca

   - Hmotnost zeleza z daneho odpichu v danom miesaci sa teda urci pomocou podielu / frakcie zadanej na vysokej peci a realnej hmotnosti miesaca nameranej na oceliarni.

### HMOTNOST TROSKY

- troska sa v ramci odpichu zachytava do kolib
- pocas jedneho odpichu sa naplni niekolko kolib (moze az 22)
- hmotnost jednej koliby je zhruba 30t
- v reporte THU_VP_Komplet (strana 7) je zadana aj hmotnost trosky v tonach - hmotnost zmerana firmou DANUCEN

Tabulky, kde hladat hmotnosti trosky:

1. `AZVP.EKONOM.KOLIBY`
   
   - definuje odhadovane mnozstvo trosky
   
   - hmotnost trosky v ramci jedneho odpichu sa urcuje nasledovne:
     
     1. v ramci odpichu sa naplni niekolko kolib
     
     2. pre dany odpich, po doliati koliby, operator urci kolko trosky vytieklo do danej koliby (definuje sa na stvrtiny)
     
     3. po doteceni operator zahlasi, ze sa naplnila cela koliba -> 4/4 cize `MNOZSTVO = 4` (hmotnost = 30t)
     
     4. po doteceni trosky do inej koliby operator zahlasi, ze troska zaplnila 1/4 koliby -> `MNOZSTVO = 1`(hmotnost = 7.5t)

2. `PZVP.EKONOM.THU_HUVP`
   
   - mesacne zaznamy o hmotnosti trosky merane firmou DANUCEN
   
   - hmotnost trosky hlasi zamestnanec firmy DANUCEN telefonicky operatorom a ti to zapisu do DB
   
   - najmensia granularita dat su mesacne udaje
   
   - hmotnost trosky sa urcuje nasledovne:
     
     1. hmotnost trosky sa skryva pod poradim 32 a 67
     
     2. poradie 32 urcuje hmotnost trosky za dany mesiac
     
     3. poradie 67 urcuje hmotnost trosky od zaciatku roka po dany mesiac

### ODBER VZORIEK SUROVEHO ZELEZA / ANALYZA SUROVEHO ZELEZA

- odber vzoriek prebieha pocas odpichu

- casovy rozdiel medzi odberom vzorky a analyzou moze byt vyznamny (aj niekolko hodin)

- priradenie analyzy k vsadzke na zaklade casu analyzy moze byt (a zrejme aj je) dost nepresne

- odber vzoriek pocas odpichu prebieha nasledovne:
  
  1. vzorka - po naliati 100 ton zeleza / po naliati 1. miesaca
  
  2. vzorka - ked vyjde troska
  
  3. vzorka - na konci odpichu
