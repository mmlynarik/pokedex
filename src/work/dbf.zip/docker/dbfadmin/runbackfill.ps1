docker run -it `
    --entrypoint /bin/bash `
    --volume F:/Jano/runbackfill/db.sqlite3:/source/dbfapp/db.sqlite3 `
    --volume dbf-runbackfill:/source/dbfapp/trained_models `
    --env-file F:/Jano/runbackfill/config.env `
    dockregistry.kbs.sk.uss.com/digital/dbf_app:20241113.3 `
    -c "source activate dbf && python manage.py runbackfill -m <model-name> -s <start-date> -e <end-date> -i <interval>"