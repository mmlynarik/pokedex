docker run -it `
    --gpus all `
    --entrypoint "/bin/bash" `
    --volume C:/Data/dtrain:/training `
    dockregistry.kbs.sk.uss.com/digital/dbf_training:20240820.5 `
    -c "source activate dbf && train_autoencoder2 fit -c /training/config/config-stockrod.yaml"