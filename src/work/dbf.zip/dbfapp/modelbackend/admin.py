from django.apps import apps
from django.contrib import admin
from django.contrib.admin.sites import AlreadyRegistered
from modelbackend.models import (
    BackfillJobConfig,
    BlastFurnaceEmbeddingModel,
    BlastFurnaceModelDefinition,
    BlastFurnaceModelDeployment,
    BlastFurnacePredictionResult,
    BlastFurnaceTarget,
    DummyBlastFurnaceModelDefinition,
    ForecastExportPIPointName,
    NeuralBlastFurnaceModelDefinition,
    TappingDeliveryHeatChem,
)


class BlastFurnaceModelDefinitionAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "neural_model_def",
        "dummy_model_def",
    ]


class BlastFurnaceModelDeploymentAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "furnace_id",
        "target_id",
        "model_definition",
    ]


class BlastFurnaceEmbeddingModelAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_filter = ("signal_main_group",)
    list_display = [
        "id",
        "name",
        "signal_main_group",
        "embedding_model",
    ]


class DummyBlastFurnaceModelDefinitionAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "name",
        "target_signal",
    ]


class NeuralBlastFurnaceModelDefinitionAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "name",
        "value_resolution",
        "time_resolution",
        "config",
        "prediction_model",
    ]
    filter_horizontal = ("embedding_models",)


class BlastFurnacePredictionResultAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "model_definition",
        "calc_time",
    ]
    list_filter = ("model_definition",)


class BlastFurnaceTargetsAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "furnace_id",
        "valid_asof",
        "silicon",
        "temperature",
    ]
    list_filter = ("furnace_id",)


class BackfillJobConfigAdmin(admin.ModelAdmin):
    ordering = ("id",)
    readonly_fields = ("started_on", "finished_on", "is_done")
    list_display = [
        "id",
        "kind",
        "start",
        "end",
        "interval",
        "model_definition_id",
        "freq",
        "started_on",
        "finished_on",
        "is_done",
    ]
    list_filter = ("model_definition_id",)

    def save_model(self, request, obj, form, change):
        if form.changed_data:
            obj.started_on = None
            obj.finished_on = None
            obj.is_done = False
            super().save_model(request, obj, form, change)


class ForecastExportPIPointNameAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "deployment",
        "forecast_kind",
        "pi_point_name",
    ]
    list_filter = ("deployment", "forecast_kind")


class TappingDeliveryHeatChemAdmin(admin.ModelAdmin):
    ordering = ("id",)
    list_display = [
        "id",
        "tapping_start_date",
        "tapping_end_date",
        "tapping_id",
        "furnace_id",
        "mixer_id",
        "heat_id",
        "pig_iron_weight",
        "weight_from_mixer",
        "estimated_weight_from_tapping",
        "ok_heat",
    ]
    list_filter = ("tapping_id", "heat_id", "furnace_id", "ok_heat")


class SignalEncoderAdmin(admin.ModelAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.prefetch_related("signal", "encoder")
        return queryset


class ModelInputOutputAdmin(admin.ModelAdmin):
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.prefetch_related("model", "signalencoder__encoder", "signalencoder__signal")
        return queryset


admin.site.register(BlastFurnaceModelDeployment, BlastFurnaceModelDeploymentAdmin)
admin.site.register(BlastFurnaceEmbeddingModel, BlastFurnaceEmbeddingModelAdmin)
admin.site.register(NeuralBlastFurnaceModelDefinition, NeuralBlastFurnaceModelDefinitionAdmin)
admin.site.register(DummyBlastFurnaceModelDefinition, DummyBlastFurnaceModelDefinitionAdmin)
admin.site.register(BlastFurnaceModelDefinition, BlastFurnaceModelDefinitionAdmin)
admin.site.register(BlastFurnacePredictionResult, BlastFurnacePredictionResultAdmin)
admin.site.register(BlastFurnaceTarget, BlastFurnaceTargetsAdmin)
admin.site.register(BackfillJobConfig, BackfillJobConfigAdmin)
admin.site.register(ForecastExportPIPointName, ForecastExportPIPointNameAdmin)
admin.site.register(TappingDeliveryHeatChem, TappingDeliveryHeatChemAdmin)

app_models = apps.get_app_config("modelbackend").get_models()
for model in app_models:
    try:
        admin.site.register(model)
    except AlreadyRegistered:
        pass
