import time


class Pacemaker:
    """
    The Pacemaker class keeps a loop operating at a steady rhythm,
    according to a wall clock.

    Usage:
    pacemaker = Pacemaker(5) # do loop every 5 seconds
    while True:
        off_by = pacemaker.beat()
        do_real_work()
    """

    def __init__(self, repeat_every_secs: float):
        self.clock_period = repeat_every_secs
        self.last_run_completed = time.monotonic()
        self.start_time = time.monotonic()
        self.i_iter = -1

    def beat(self):
        self.i_iter += 1
        end = self.start_time + (self.i_iter + 1) * self.clock_period

        sleep_time = end - time.monotonic()
        if sleep_time > 0:
            time.sleep(sleep_time)

        this_run_completed = time.monotonic()
        dt = this_run_completed - self.last_run_completed
        overtime = dt - self.clock_period
        self.last_run_completed = this_run_completed
        return overtime
