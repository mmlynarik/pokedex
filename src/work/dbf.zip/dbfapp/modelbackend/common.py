import os
from collections import Counter
from pathlib import Path
from typing import Iterator

import pandas as pd
from modelbackend.models import (
    BackfillJobConfig,
    BlastFurnaceModelDefinition,
    BlastFurnacePredictionResult,
    BlastFurnaceTarget,
)

from dbfapp.settings import MEDIA_ROOT
from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals import get_signal_group_loader
from dbfcore.predictionmodel.inference import DummyBlastFurnaceModel, NeuralBlastFurnaceModel
from dbfcore.predictionmodel.protocols import BlastFurnaceModel, DataDefinition, SignalGroupData
from dbfcore.settings import TZ_LOCAL, TZ_UTC


def get_furnace_targets_file_path(furnace_id: int) -> Path:
    furnace_targets_dir = os.getenv("FURNACE_TARGETS_DIR")
    path_stem = os.getenv(f"FURNACE_TARGETS_BF{furnace_id}_PATH_STEM")
    if furnace_targets_dir is None:
        raise ValueError(
            "Environment variable FURNACE_TARGETS_DIR not set. Please set it before importing furnace targets"
        )
    if path_stem is None:
        raise ValueError(
            f"""Environment variable FURNACE_TARGETS_BF{furnace_id}_PATH_STEM not set. Please set it before importing furnace targets."""
        )
    return Path(furnace_targets_dir, path_stem)


def get_forecasts_from_furnace_targets_file(furnace_id: int) -> pd.DataFrame:
    xlsx = pd.ExcelFile(get_furnace_targets_file_path(furnace_id))
    df = xlsx.parse("vstupy", skiprows=1, index_col=None, na_values=["NA"])
    df = df[["dátum", "čas", "predpovedany Si"]].dropna().drop_duplicates(subset=["dátum", "čas"])
    df["forecast_time"] = (
        (
            pd.to_datetime(df["dátum"], errors="coerce")
            + df.apply(lambda row: pd.Timedelta(hours=row["čas"].hour, minutes=row["čas"].minute), axis=1)
        )
        .dt.tz_localize(TZ_LOCAL, ambiguous="NaT")
        .dt.tz_convert(TZ_UTC)
    )
    df["calc_time"] = df["forecast_time"] - pd.Timedelta(minutes=30)  # current excel has 30min ahead forecast
    df = df.rename(columns={"predpovedany Si": "forecast_si"})
    return df.dropna()


def partition_range_into_intervals(
    start: pd.Timestamp, end: pd.Timestamp, interval: pd.Timedelta
) -> Iterator[tuple[pd.Timestamp, pd.Timestamp]]:
    if end - start <= interval:
        yield start, end
        return

    timestamps = pd.date_range(start, end, freq=interval, inclusive="left").append(pd.Index([end]))
    for idx in range(len(timestamps) - 1):
        yield timestamps[idx], timestamps[idx + 1]


def get_signal_group_data(data_definition: DataDefinition, datasources: DataSources) -> SignalGroupData:
    data = {}
    for group, (start, end) in data_definition.items():
        if end > pd.Timestamp.utcnow():
            raise Exception(
                f"You are trying to load data from the future for {group} group. Such action is not valid!"
            )

        loader = get_signal_group_loader(group, datasources)
        df = loader(start, end)  # type: ignore
        data[group] = df
    return data


def get_blast_furnace_model(model_definition: BlastFurnaceModelDefinition) -> BlastFurnaceModel:
    if model_definition.neural_model_def is not None:
        embedding_models = model_definition.neural_model_def.embedding_models.all().values_list(
            "signal_main_group", "embedding_model"
        )
        most_common_group, most_common_count = Counter([m[0] for m in embedding_models]).most_common(1)[0]
        if most_common_count > 1:
            raise ValueError(
                f"{model_definition.name} has {most_common_count} {most_common_group} embedding models assigned. Please select only one."
            )
        return NeuralBlastFurnaceModel(  # type: ignore
            value_resolution=model_definition.neural_model_def.value_resolution,
            time_resolution=model_definition.neural_model_def.time_resolution,
            config_path=Path(MEDIA_ROOT, model_definition.neural_model_def.config.path),
            prediction_model_path=Path(MEDIA_ROOT, model_definition.neural_model_def.prediction_model.path),
            embedding_model_paths={group: Path(MEDIA_ROOT, model) for group, model in embedding_models},
            eval_mode=model_definition.neural_model_def.eval_mode,
        )
    elif model_definition.dummy_model_def is not None:
        return DummyBlastFurnaceModel(name=model_definition.dummy_model_def.target_signal)  # type: ignore
    else:
        raise ValueError(
            f"Model definition {model_definition} is not configured properly. At least one model config field must be non-null"
        )


def calculate_prediction_result(
    model: BlastFurnaceModel,
    model_definition: BlastFurnaceModelDefinition,
    calc_time: pd.Timestamp,
    datasources: DataSources,
) -> BlastFurnacePredictionResult:
    if calc_time > pd.Timestamp.utcnow():
        raise ValueError(f"Calc time {calc_time} cannot be in the future.")

    data_definition = model.get_data_definition(calc_time)
    signal_group_data = get_signal_group_data(data_definition, datasources)
    model_result = model.calculate_batch(signal_group_data, [calc_time])[0]
    result, _ = BlastFurnacePredictionResult.objects.update_or_create(
        model_definition=model_definition,
        calc_time=calc_time,
        defaults={"encoded": model_result.to_bytes()},
    )
    return result


def get_furnace_targets(furnace_id: int, start: pd.Timestamp, end: pd.Timestamp) -> list[dict]:
    last_previous_furnace_target = (
        BlastFurnaceTarget.objects.filter(furnace_id=furnace_id, valid_asof__lte=start)
        .order_by("-valid_asof")
        .first()
    )
    valid_asof_range = [
        last_previous_furnace_target.valid_asof if last_previous_furnace_target is not None else end,
        end,
    ]

    return list(
        BlastFurnaceTarget.objects.filter(furnace_id=furnace_id, valid_asof__range=valid_asof_range).values()
    )


def get_n_previous_days_start_end_timestamps(
    reference_date: pd.Timestamp | None = None, n_previous_days: int = 1
) -> tuple[pd.Timestamp, pd.Timestamp]:
    if not reference_date:
        reference_date = pd.Timestamp.utcnow()
    prev_day_start = reference_date.normalize() - pd.Timedelta(days=n_previous_days)
    prev_day_end = prev_day_start + pd.Timedelta(days=n_previous_days)
    return prev_day_start, prev_day_end


def initiate_backfill(config_pk: int | None, **options):
    if options["mode"] == "BACKFILL-DB" and config_pk:
        config = BackfillJobConfig.objects.get(pk=config_pk)
        config.started_on = pd.Timestamp.utcnow()
        config.save()


def finalize_backfill(config_pk: int | None, **options):
    if options["mode"] == "BACKFILL-DB" and config_pk:
        config = BackfillJobConfig.objects.get(pk=config_pk)
        config.is_done = True
        config.finished_on = pd.Timestamp.utcnow()
        config.save()
