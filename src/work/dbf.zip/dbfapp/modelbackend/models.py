from abc import ABC, abstractmethod

from django.core.exceptions import ValidationError
from django.db import models

from dbfcore.settings import MAX_PRED_FREQ


class Validator(ABC):
    fields: list[str]
    message: dict[str, str]

    @classmethod
    def register(cls, fields: list[str], message: dict[str, str]):
        cls.fields = fields
        cls.message = message
        return cls()

    @abstractmethod
    def run(self, model: models.Model): ...


class ModelValidationMixin(models.Model):
    validators: list[Validator] = []

    class Meta:
        abstract = True

    def clean(self):
        for validator in self.validators:
            if not validator.run(self):
                raise ValidationError(validator.message)

    def save(self, *args, **kwargs):
        self.full_clean()
        super(ModelValidationMixin, self).save(*args, **kwargs)


class BlastFurnaceEmbeddingModel(models.Model):
    class SignalMainGroup(models.TextChoices):
        CHARGEFLOW = "CHARGEFLOW", "CHARGEFLOW"
        GAPPHASE = "GAPPHASE", "GAPPHASE"
        HOTBLAST = "HOTBLAST", "HOTBLAST"
        HOTMETALCHEM = "HOTMETALCHEM", "HOTMETALCHEM"
        HOTMETALTEMP = "HOTMETALTEMP", "HOTMETALTEMP"
        STOCKROD = "STOCKROD", "STOCKROD"
        TOPGAS = "TOPGAS", "TOPGAS"

    name = models.CharField(max_length=128)
    signal_main_group = models.CharField(max_length=64, choices=SignalMainGroup.choices)
    embedding_model = models.FileField(upload_to="embedding_models")

    def __str__(self):
        return f"{self.signal_main_group}: {self.name}"


class NeuralBlastFurnaceModelDefinition(models.Model):
    name = models.CharField(max_length=128)
    value_resolution = models.IntegerField(default=200)
    time_resolution = models.IntegerField(default=240)
    config = models.FileField(upload_to="configs")
    prediction_model = models.FileField(upload_to="prediction_models")
    embedding_models = models.ManyToManyField(BlastFurnaceEmbeddingModel)
    eval_mode = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class DummyBlastFurnaceModelDefinition(models.Model):
    name = models.CharField(max_length=128)
    target_signal = models.CharField(max_length=64)

    def __str__(self):
        return self.name


class BlastFurnaceModelDefinition(models.Model):
    neural_model_def = models.ForeignKey(
        NeuralBlastFurnaceModelDefinition, null=True, blank=True, on_delete=models.DO_NOTHING
    )
    dummy_model_def = models.ForeignKey(
        DummyBlastFurnaceModelDefinition, null=True, blank=True, on_delete=models.DO_NOTHING
    )

    def __str__(self):
        return self.name

    @property
    def name(self) -> str:
        return (self.neural_model_def or self.dummy_model_def).name


class TargetID(models.TextChoices):
    TEMPERATURE = "TEMPERATURE", "TEMPERATURE"
    SILICON = "SILICON", "SILICON"


class BlastFurnaceModelDeployment(models.Model):
    furnace_id = models.IntegerField()
    target_id = models.CharField(max_length=32, choices=TargetID.choices)
    model_definition = models.ForeignKey(BlastFurnaceModelDefinition, on_delete=models.DO_NOTHING)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["furnace_id", "target_id"], name="Unique deployment"),
        ]

    def __str__(self):
        return f"Furnace ID: {self.furnace_id}, Target ID: {self.target_id}"


class ForecastKind(models.TextChoices):
    RAW = "RAW", "RAW"
    COMBINED = "COMBINED", "COMBINED"


class ForecastExportPIPointName(models.Model):
    deployment = models.ForeignKey(BlastFurnaceModelDeployment, on_delete=models.CASCADE)
    pi_point_name = models.CharField(max_length=64)
    forecast_kind = models.CharField(max_length=64, choices=ForecastKind.choices)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["deployment", "forecast_kind"], name="Unique pipoint kind and deployment"
            ),
        ]


class BlastFurnacePredictionResult(models.Model):
    model_definition = models.ForeignKey(BlastFurnaceModelDefinition, on_delete=models.CASCADE)
    calc_time = models.DateTimeField()
    encoded = models.BinaryField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["model_definition", "calc_time"], name="Unique model and calc time"
            ),
        ]


class BlastFurnaceTarget(models.Model):
    furnace_id = models.IntegerField(null=False)
    valid_asof = models.DateTimeField(null=False)
    silicon = models.FloatField()
    temperature = models.IntegerField()

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["furnace_id", "valid_asof"], name="Unique furnace targets"),
        ]


class BackfillKind(models.TextChoices):
    PREDICTION = "PREDICTION", "PREDICTION"
    TAPPINGHEATMAP = "TAPPINGHEATMAP", "TAPPINGHEATMAP"


class BackfillInterval(models.TextChoices):
    WEEK = "1W", "1W"
    DAY = "1D", "1D"


class ModelDefinitionIDOnlyForPredictionBackfill(Validator):
    def run(self, model: "BackfillJobConfig"):
        return (model.model_definition_id is not None and model.kind == BackfillKind.PREDICTION) or (
            model.model_definition_id is None and model.kind == BackfillKind.TAPPINGHEATMAP
        )


class FreqOnlyForPredictionBackfill(Validator):
    def run(self, model: "BackfillJobConfig"):
        return (model.freq is not None and model.kind == BackfillKind.PREDICTION) or (
            model.freq is None and model.kind == BackfillKind.TAPPINGHEATMAP
        )


class BackfillJobConfig(ModelValidationMixin, models.Model):
    # MANDATORY FIELDS
    kind = models.CharField(max_length=32, choices=BackfillKind.choices, default=BackfillKind.PREDICTION)
    start = models.DateTimeField()
    end = models.DateTimeField()
    interval = models.CharField(max_length=32, choices=BackfillInterval.choices)
    # JOB-SPECIFIC FIELDS
    model_definition_id = models.IntegerField(null=True, blank=True)
    freq = models.CharField(max_length=32, default=MAX_PRED_FREQ, null=True, blank=True)
    # CONTROL READONLY FIELDS
    started_on = models.DateTimeField(null=True, blank=True)
    finished_on = models.DateTimeField(null=True, blank=True)
    is_done = models.BooleanField()

    validators = [
        ModelDefinitionIDOnlyForPredictionBackfill.register(
            fields=[],
            message={
                "model_definition_id": "Model definition id is allowed and required only for PREDICTION backfill kind"
            },
        ),
        FreqOnlyForPredictionBackfill.register(
            fields=[], message={"freq": "Freq is allowed and required only for PREDICTION backfill kind"}
        ),
    ]


class BlastFurnaceEvalData(models.Model):
    furnace_id = models.IntegerField()
    calc_time = models.DateTimeField()
    pig_iron_analysis_date = models.DateTimeField(null=True, blank=True)
    est_sample_collection_date = models.DateTimeField(null=True, blank=True)
    si_pct = models.FloatField(null=True)
    forecast_0 = models.FloatField(null=True)
    forecast_30 = models.FloatField(null=True)
    forecast_60 = models.FloatField(null=True)
    forecast_90 = models.FloatField(null=True)
    forecast_120 = models.FloatField(null=True)
    forecast_150 = models.FloatField(null=True)
    forecast_180 = models.FloatField(null=True)
    forecast_210 = models.FloatField(null=True)
    forecast_240 = models.FloatField(null=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["calc_time", "furnace_id"], name="Unique furnace eval data"),
        ]


class TappingDeliveryHeatChem(models.Model):
    tapping_start_date = models.DateTimeField(null=False)
    tapping_end_date = models.DateTimeField(null=False)
    tapping_id = models.IntegerField(null=False)
    furnace_id = models.IntegerField(null=False)
    delivery_id = models.IntegerField(null=False)
    mixer_id = models.BigIntegerField(null=False)
    heat_id = models.IntegerField(null=False)
    pig_iron_weight = models.IntegerField(null=True, blank=True)
    weight_from_mixer = models.IntegerField(null=False)
    estimated_weight_from_tapping = models.IntegerField(null=False)
    si_pct = models.FloatField(null=True, blank=True)
    si_target = models.FloatField(null=True, blank=True)
    si_prediction = models.FloatField(null=True, blank=True)
    ok_heat = models.BooleanField(default=True)

    class Meta:
        indexes = [
            models.Index(fields=["tapping_start_date"]),
            models.Index(fields=["tapping_end_date"]),
            models.Index(fields=["tapping_id"]),
            models.Index(fields=["tapping_id", "delivery_id"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["tapping_id", "delivery_id", "heat_id"], name="Unique tapping combination"
            )
        ]


class StoveHeatingPhase(models.Model):
    heating_phase_id = models.CharField(max_length=17, unique=True)
    start = models.DateTimeField()
    end = models.DateTimeField()
    input_data = models.TextField(default="")
