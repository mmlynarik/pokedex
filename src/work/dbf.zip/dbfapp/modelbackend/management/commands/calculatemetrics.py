import pandas as pd
import torch
from django.core.management.base import BaseCommand
from modelbackend.common import get_blast_furnace_model, get_furnace_targets, get_signal_group_data
from modelbackend.management.commands.runbackfill import partition_range_into_intervals
from modelbackend.models import BlastFurnaceModelDefinition, BlastFurnacePredictionResult
from modelfrontend.views import get_blast_furnace_model_result
from tqdm import tqdm

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.predictionmodel.inference import get_minmax_data_definition
from dbfcore.predictionmodel.metrics.loader import load_metrics_from_dict
from dbfcore.settings import FURNACE_IDS, TZ_UTC
from dbfcore.utils import load_yaml_into_dict

torch.set_grad_enabled(False)


class Command(BaseCommand):
    help = "Calculate score for defined prediction model."

    def add_arguments(self, parser):
        parser.add_argument("-m", "--modelid", type=str, help="Model definition ID in DB", required=True)
        parser.add_argument("-c", "--config", type=str, help="Path to config yaml", required=True)
        parser.add_argument("-o", "--output", help="Path to the output parquet file", required=True)

    def handle(self, *args, **options):
        mid = options["modelid"]
        config_path = options["config"]
        output_file = options["output"]

        config = load_yaml_into_dict(config_path)
        start = TZ_UTC.localize(pd.Timestamp(config["start"]))
        end = TZ_UTC.localize(pd.Timestamp(config["end"]))
        interval = pd.Timedelta(config["batchinterval"])
        metrics = load_metrics_from_dict(config["metrics"])
        pre_offset = pd.Timedelta(config.get("pre_interval_offset", "0h"))

        model_definition = BlastFurnaceModelDefinition.objects.get(id=mid)
        model = get_blast_furnace_model(model_definition)
        datasources = get_datasources_configured_with_env()

        interval_metric_results = []
        intervals = list(partition_range_into_intervals(start, end, interval))

        for interval_start, interval_end in tqdm(intervals, total=len(intervals)):
            prediction_results = BlastFurnacePredictionResult.objects.filter(
                model_definition=model_definition,
                calc_time__range=[interval_start - pre_offset, interval_end],
            )

            if not prediction_results:
                continue

            bf_model_results = [
                get_blast_furnace_model_result(prediction_result, model)
                for prediction_result in prediction_results
            ]

            calc_times = prediction_results.values_list("calc_time", flat=True)
            data_definitions = [metric.get_data_definition(calc_times) for metric in metrics]
            data_definition = get_minmax_data_definition(data_definitions)
            signal_group_data = get_signal_group_data(data_definition, datasources)

            all_furnaces_targets = [
                get_furnace_targets(furnace_id, min(calc_times), max(calc_times))
                for furnace_id in FURNACE_IDS
            ]

            interval_metric_results_per_metric = [
                metric.calculate_metric(calc_times, bf_model_results, signal_group_data, all_furnaces_targets)  # type: ignore
                for metric in metrics
            ]
            interval_metric_results.append(pd.concat(interval_metric_results_per_metric, axis=1))

        metric_results = pd.concat(interval_metric_results)
        metric_results = metric_results[~metric_results.index.duplicated()]
        metric_results = metric_results.loc[pd.Timestamp(start) : pd.Timestamp(end)]
        metric_results.to_parquet(output_file)
