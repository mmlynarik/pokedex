import logging
from typing import Sequence

import torch
from django.core.management.base import BaseCommand
from django.utils import autoreload
from modelbackend.common import calculate_prediction_result, get_blast_furnace_model
from modelbackend.models import BlastFurnaceModelDefinition, BlastFurnaceModelDeployment, TargetID
from modelbackend.utils import Pacemaker
from pandas import Timedelta, Timestamp

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.predictionmodel.protocols import BlastFurnaceModel
from dbfcore.settings import FURNACE_IDS, MAX_PRED_FREQ

logger = logging.getLogger(__name__)


def round_datetime_to_max_prediction_frequency(timestamp: Timestamp, max_pred_freq: str) -> Timestamp:
    return timestamp.floor(max_pred_freq)


def load_last_utc_model_calc_time(max_pred_freq: str) -> Timestamp:
    return round_datetime_to_max_prediction_frequency(Timestamp.utcnow(), max_pred_freq)


def calculate_prediction_results(
    models_with_defs: list[tuple[BlastFurnaceModel, BlastFurnaceModelDefinition]],
    datasources: DataSources,
    interval: str,
):
    for model, model_def in models_with_defs:
        try:
            model_calc_time = load_last_utc_model_calc_time(interval)
            logger.info(f"Starting calculation for {model_def.name} with calc time {model_calc_time}")
            result = calculate_prediction_result(model, model_def, model_calc_time, datasources)
            logger.info(f"Calculation successful for {model_def.name} with calc time {model_calc_time}")
            logger.info(f"{result} saved into database")
        except Exception as e:
            logger.error(f"Calculation failed for model: {model} and time {model_calc_time}")
            logger.exception(e)


def get_zipped_models_with_definitions(
    only_deployments: bool,
    furnace_ids: Sequence[int] = FURNACE_IDS,
    target_ids: Sequence[str] = TargetID.values,
) -> list[tuple[BlastFurnaceModel, BlastFurnaceModelDefinition]]:
    model_definitions_ids = (
        (
            BlastFurnaceModelDeployment.objects.filter(furnace_id__in=furnace_ids, target_id__in=target_ids)
            .values_list("model_definition", flat=True)
            .distinct()
        )
        if only_deployments
        else BlastFurnaceModelDefinition.objects.all().values_list("pk", flat=True)
    )
    model_definitions = BlastFurnaceModelDefinition.objects.filter(id__in=model_definitions_ids)
    models = [get_blast_furnace_model(d) for d in model_definitions]
    return list(zip(models, model_definitions))


# TODO require migration check
class Command(BaseCommand):
    help = "Run all models in specified interval and save all results to db"

    def add_arguments(self, parser):
        parser.add_argument("--interval", type=str, default=MAX_PRED_FREQ, help="How often should models run")
        parser.add_argument("--autoreload", action="store_true", help="Autoreload code on changes")
        parser.add_argument(
            "--only-deployments", action="store_true", default=True, help="Calculate only deployed models"
        )

    def handle(self, *args, **options):
        if options["autoreload"]:
            autoreload.run_with_reloader(self.main, *args, **options)
        else:
            self.main(*args, **options)

    def main(self, *args, **options):
        torch.set_grad_enabled(False)

        datasources = get_datasources_configured_with_env()
        pacemaker = Pacemaker(Timedelta(options["interval"]).total_seconds())
        logger.info(f'Models will be calculated every: {options["interval"]}')

        while True:
            missed_by = pacemaker.beat()
            if abs(missed_by) > 1.0:
                logger.warning(
                    "Current calculation interval is too fast\n"
                    + " improve performance of the model or calculate results less frequently.\n"
                    + f" Expected calculation time missed by: {missed_by}"
                )

            models_with_defs = get_zipped_models_with_definitions(options["only_deployments"])
            logger.info(f"{len(models_with_defs)} model definition(s) loaded sucessfully")
            calculate_prediction_results(models_with_defs, datasources, options["interval"])
            logger.info("Models calculated sucessfully\n")
