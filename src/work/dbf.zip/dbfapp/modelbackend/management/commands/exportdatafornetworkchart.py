import logging
from datetime import datetime
from typing import Callable

import attrs
import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import (
    finalize_backfill,
    get_blast_furnace_model,
    get_n_previous_days_start_end_timestamps,
    initiate_backfill,
    partition_range_into_intervals,
)
from modelbackend.management.commands.evalsiliconmodelonsteelshop import filter_error_heats
from modelbackend.models import (
    BackfillJobConfig,
    BackfillKind,
    BlastFurnaceModelDeployment,
    TappingDeliveryHeatChem,
)
from modelfrontend.common import get_blast_furnace_model_result, get_results_from_db, get_signal_history
from modelfrontend.views import get_max_pred_freq_minutes

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.dataset.signals.tapping_delivery_heat_chem import load_tapping_delivery_heat_chem
from dbfcore.settings import FURNACE_IDS

logger = logging.getLogger(__name__)


def get_data_to_add_to_tapping_delivery_heat_chem_table(
    start_date: pd.Timestamp, end_date: pd.Timestamp
) -> pd.DataFrame:

    datasources = get_datasources_configured_with_env()
    df_orig = load_tapping_delivery_heat_chem(start_date, end_date, datasources)
    forecast_horizon = pd.Timedelta(minutes=0)
    forecast_frequency = pd.Timedelta(minutes=get_max_pred_freq_minutes())
    target_id = "SILICON"
    df_all = pd.DataFrame()

    for furnace_id in FURNACE_IDS:
        deployment = BlastFurnaceModelDeployment.objects.get(furnace_id=furnace_id, target_id=target_id)

        model = get_blast_furnace_model(deployment.model_definition)
        results_db = get_results_from_db(
            deployment.model_definition,
            start_date - forecast_horizon,
            end_date - forecast_horizon,
            forecast_frequency,
        )
        if not results_db:
            continue

        model_results = [get_blast_furnace_model_result(result_db, model) for result_db in results_db]
        forecasts = pd.DataFrame(
            index=[r.calc_time + forecast_horizon for r in model_results],
            data=[r.get_expected_value(forecast_horizon) for r in model_results],
            columns=["expected_value"],
        )

        signal_name = model_results[0].target_signal_name
        targets_history = get_signal_history(signal_name, start_date, end_date, datasources)[[signal_name]]

        df_non_index = df_orig[df_orig["furnace_id"] == furnace_id].reset_index()

        lst_targets = []
        lst_predictions = []
        for start, end in df_non_index[["tapping_start_date", "tapping_end_date"]].values:
            lst_targets.append(targets_history[start:end].values.mean())
            lst_predictions.append(
                forecasts[(forecasts.index >= start) & (forecasts.index <= end)].values.mean()
            )

        df_extended = df_non_index.assign(prediction=lst_predictions, target=lst_targets)
        df_all = pd.concat([df_all, df_extended], ignore_index=True)

    if df_all.empty:
        raise ValueError(
            f"No predictions found for period {start_date}-{end_date} for any furnace. Please generate them first."
        )

    selected_df = df_all[df_all["tapping_start_date"] > start_date].copy()
    filtered_heats = filter_error_heats(selected_df, datasources)["heat_id"].unique().tolist()
    selected_df["ok_heat"] = selected_df.apply(
        lambda row: True if row["heat_id"] in filtered_heats else False, axis=1
    )
    return selected_df


def save_data_to_tapping_delivery_heat_chem_table(df: pd.DataFrame):
    for row in df.itertuples():
        si_pct_value = None if pd.isna(row.si_pct) else row.si_pct
        si_target = None if pd.isna(row.target) else row.target
        si_prediction = None if pd.isna(row.prediction) else row.prediction

        TappingDeliveryHeatChem.objects.update_or_create(
            tapping_id=row.tapping_id,
            delivery_id=row.delivery_id,
            heat_id=row.heat_id,
            defaults={
                "tapping_start_date": row.tapping_start_date,
                "tapping_end_date": row.tapping_end_date,
                "furnace_id": row.furnace_id,
                "mixer_id": row.mixer_id,
                "weight_from_mixer": row.weight_from_mixer,
                "estimated_weight_from_tapping": row.estimated_weight_from_tapping,
                "pig_iron_weight": row.pig_iron_weight,
                "si_pct": si_pct_value,
                "si_target": si_target,
                "si_prediction": si_prediction,
                "ok_heat": row.ok_heat,
            },
        )


@attrs.define(frozen=True, slots=False)
class TappingHeatMapBackfillParams:
    start: datetime
    end: datetime
    interval: str
    config_pk: int | None = None


def resolve_cli_params(**options) -> TappingHeatMapBackfillParams | None:
    if options["start"] is None:
        raise ValueError("Start parameter is required when CLI mode is used")
    if options["end"] is None:
        raise ValueError("End parameter is required when CLI mode is used")
    return TappingHeatMapBackfillParams(options["start"], options["end"], options["interval"])


def resolve_db_params(**options) -> TappingHeatMapBackfillParams | None:
    params = BackfillJobConfig.objects.filter(is_done=False, kind=BackfillKind.TAPPINGHEATMAP)
    if not params:
        logger.info("No active backfill params found in the database. No action taken")
        return None
    if len(params) > 1:
        logger.info(f"Only one active backfill params can be defined at a time. Found {len(params)}")
        return None

    return TappingHeatMapBackfillParams(
        params[0].start.replace(second=0),
        params[0].end.replace(second=0),
        params[0].interval,
        params[0].pk,
    )


def get_params_resolver(mode: str) -> Callable:
    resolvers = {"BACKFILL-DB": resolve_db_params, "BACKFILL-CLI": resolve_cli_params}
    return resolvers[mode]


class Command(BaseCommand):
    help = "Export tapping delivery heat chem data from previous day into application database."

    def add_arguments(self, parser):
        parser.add_argument(
            "-s",
            "--start",
            help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
            required=False,
        )
        parser.add_argument(
            "-e",
            "--end",
            help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
            required=False,
        )
        parser.add_argument(
            "-i",
            "--interval",
            help="Interval to which total date range will be broken down",
            type=str,
            default="1W",
        )
        parser.add_argument(
            "--mode",
            help="Mode in which the export will run: 'BACKFILL-DB', 'BACKFILL-CLI' or 'LIVE'. In DB, params will be sourced from BACKEND DB table `BackfillJobConfig`",
            choices=["BACKFILL-DB", "BACKFILL-CLI", "LIVE"],
            default="LIVE",
        )

    def handle(self, *args, **options):
        if options["mode"] == "LIVE":
            start_date, end_date = get_n_previous_days_start_end_timestamps(n_previous_days=2)
            logger.info(f"Calculating tapping heat mapping data for period {start_date} - {end_date}")
            df = get_data_to_add_to_tapping_delivery_heat_chem_table(start_date, end_date)
            save_data_to_tapping_delivery_heat_chem_table(df)
            return

        params_resolver = get_params_resolver(options["mode"])
        params: TappingHeatMapBackfillParams | None = params_resolver(**options)
        if not params:
            return

        initiate_backfill(params.config_pk, **options)

        interval = pd.Timedelta(params.interval)
        start, end = params.start, params.end
        print(params)
        if end <= start:
            raise ValueError("The start date must precede the end date")

        intervals = list(partition_range_into_intervals(start, end, interval))
        reference_dates = [i[1] for i in intervals]
        n_previous_days = (interval + pd.Timedelta("1D")).days
        for reference_date in reference_dates:
            start_date, end_date = get_n_previous_days_start_end_timestamps(reference_date, n_previous_days)
            logger.info(f"Calculating tapping heat mapping data for period {start_date} - {end_date}")
            df = get_data_to_add_to_tapping_delivery_heat_chem_table(start_date, end_date)

            save_data_to_tapping_delivery_heat_chem_table(df)

        finalize_backfill(params.config_pk, **options)
