import logging
import time

import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import (
    get_blast_furnace_model,
    get_forecasts_from_furnace_targets_file,
    get_signal_group_data,
    partition_range_into_intervals,
)
from modelbackend.models import BlastFurnaceModelDefinition, BlastFurnacePredictionResult
from tqdm import tqdm

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.predictionmodel.inference import get_minmax_data_definition
from dbfcore.settings import TZ_UTC

logger = logging.getLogger(__name__)


class MissingEmbeddingsException(Exception):
    "Raised when there are missing embeddings"
    ...


def get_calc_times_from_interval_boundaries(
    start: pd.Timestamp, end: pd.Timestamp, freq: pd.Timedelta
) -> list[pd.Timestamp]:
    if not ((end - start) / freq).is_integer():
        raise ValueError(f"Range defined by {start} and {end} times must be divisible by freq {freq}.")
    return list(pd.date_range(start, end, freq=freq, tz=TZ_UTC))


class Command(BaseCommand):
    help = "Generate historical predictions for given model and given calc times extracted from excel file."

    def add_arguments(self, parser):
        parser.add_argument("-m", "--model_id", type=str, help="Model definition name", required=True)
        parser.add_argument(
            "-i",
            "--interval",
            help="Interval to which total date range will be broken down",
            type=str,
            default="1W",
        )
        parser.add_argument(
            "--bf",
            help="Furnace ID for which furnace targets file will be opened and calc times will be extracted",
            type=int,
            required=True,
        )

    def handle(self, *args, **options):
        model_definition = BlastFurnaceModelDefinition.objects.get(pk=options["model_id"])
        interval = pd.Timedelta(options["interval"])
        datasources = get_datasources_configured_with_env()
        model = get_blast_furnace_model(model_definition)

        t = time.perf_counter()
        calc_times = get_forecasts_from_furnace_targets_file(options["bf"])["calc_time"]
        start, end = calc_times.iloc[0], calc_times.iloc[-1]
        logger.info(f"Calculation started for period {start} - {end}")

        intervals = list(partition_range_into_intervals(start, end, interval))
        for start, end in tqdm(intervals, total=len(intervals)):
            logger.info(f"Processing period {start} - {end}")
            chunk = calc_times[(calc_times >= start) & (calc_times <= end)]
            if chunk.empty:
                logger.info(f"No data for period {start} - {end}")
                continue
            data_definitions = [model.get_data_definition(calc_time) for calc_time in chunk]
            data_definition = get_minmax_data_definition(data_definitions)
            signal_group_data = get_signal_group_data(data_definition, datasources)
            model_results = model.calculate_batch(signal_group_data, chunk)

            for model_result in model_results:
                BlastFurnacePredictionResult.objects.update_or_create(
                    model_definition=model_definition,
                    calc_time=model_result.calc_time,
                    defaults={"encoded": model_result.to_bytes()},
                )
        t2 = time.perf_counter()
        logger.info(f"Calculation took {t2 - t}")
        logger.info("Calculation of predictions finished")
