import logging
from pathlib import Path
from typing import Any

import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import get_furnace_targets_file_path
from modelbackend.models import BlastFurnaceTarget

logger = logging.getLogger(__name__)


def get_furnace_targets_from_file(filepath: Path) -> dict[str, Any]:
    df = pd.read_excel(filepath, sheet_name="Aparátnik")
    timestamp = pd.Timestamp.utcnow()
    target_si = df.iloc[11, 2]
    target_temp = df.iloc[19, 2]
    return {"timestamp": timestamp, "silicon": target_si, "temperature": target_temp}


def import_furnace_targets_from_excel(blastfurnaceids: list[int]):
    for bfid in blastfurnaceids:
        filepath = get_furnace_targets_file_path(bfid)
        targets = get_furnace_targets_from_file(filepath)
        BlastFurnaceTarget(
            furnace_id=bfid,
            valid_asof=targets["timestamp"],
            temperature=targets["temperature"],
            silicon=targets["silicon"],
        ).save()


class Command(BaseCommand):
    help = "Import current blast furnace targets from MS Excel files into application database."

    def add_arguments(self, parser):
        parser.add_argument(
            "-b",
            "--blastfurnaceid",
            type=int,
            nargs="+",
            required=True,
            help="Blast furnace IDs for which targets will be imported",
        )

    def handle(self, *args, **options):
        import_furnace_targets_from_excel(options["blastfurnaceid"])
