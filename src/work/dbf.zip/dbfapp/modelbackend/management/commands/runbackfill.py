import logging
import time
from datetime import datetime
from typing import Callable

import attrs
import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import (
    finalize_backfill,
    get_blast_furnace_model,
    get_signal_group_data,
    initiate_backfill,
    partition_range_into_intervals,
)
from modelbackend.models import (
    BackfillJobConfig,
    BackfillKind,
    BlastFurnaceModelDefinition,
    BlastFurnacePredictionResult,
)
from tqdm import tqdm

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.predictionmodel.inference import get_minmax_data_definition
from dbfcore.settings import MAX_PRED_FREQ, TZ_UTC

logger = logging.getLogger(__name__)


class MissingEmbeddingsException(Exception):
    "Raised when there are missing embeddings"
    ...


def get_calc_times_from_interval_boundaries(
    start: pd.Timestamp, end: pd.Timestamp, freq: pd.Timedelta
) -> list[pd.Timestamp]:
    if not ((end - start) / freq).is_integer():
        raise ValueError(f"Range defined by {start} and {end} times must be divisible by freq {freq}.")
    return list(pd.date_range(start, end, freq=freq, tz=TZ_UTC))


@attrs.define(frozen=True, slots=False)
class PredictionBackfillParams:
    model_definition_id: int
    start: datetime
    end: datetime
    interval: str
    freq: str
    config_pk: int | None = None


def resolve_cli_params(**options) -> PredictionBackfillParams | None:
    if options["start"] is None:
        raise ValueError("Start parameter is required when CLI mode is used")
    if options["end"] is None:
        raise ValueError("End parameter is required when CLI mode is used")
    if options["model_definition_id"] is None:
        raise ValueError("Model definition id parameter is required when CLI mode is used")
    return PredictionBackfillParams(
        options["model_definition_id"], options["start"], options["end"], options["interval"], options["freq"]
    )


def resolve_db_params(**options) -> PredictionBackfillParams | None:
    params = BackfillJobConfig.objects.filter(is_done=False, kind=BackfillKind.PREDICTION)
    if not params:
        logger.info("No active backfill params found in the database. No action taken")
        return None
    if len(params) > 1:
        logger.info(f"Only one active backfill params can be defined at a time. Found {len(params)}")
        return None

    return PredictionBackfillParams(
        params[0].model_definition_id,
        params[0].start.replace(second=0),
        params[0].end.replace(second=0),
        params[0].interval,
        params[0].freq,
        params[0].pk,
    )


def get_params_resolver(mode: str) -> Callable:
    resolvers = {"BACKFILL-DB": resolve_db_params, "BACKFILL-CLI": resolve_cli_params}
    return resolvers[mode]


class Command(BaseCommand):
    help = "Generate historical predictions for given model and time period."

    def add_arguments(self, parser):
        parser.add_argument("-m", "--model_definition_id", type=int, help="Model definition ID")
        parser.add_argument(
            "-s",
            "--start",
            help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-e",
            "--end",
            help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-i",
            "--interval",
            help="Interval to which total date range will be broken down",
            type=str,
            default="1W",
        )
        parser.add_argument("-f", "--freq", help="Max pred freq", type=str, default=MAX_PRED_FREQ)
        parser.add_argument(
            "--mode",
            help="Mode in which the backfill will run. In DB, params will be sourced from BACKEND DB table `BackfillJobConfig`",
            choices=["BACKFILL-DB", "BACKFILL-CLI"],
            default="CLI",
        )

    def handle(self, *args, **options):
        params_resolver = get_params_resolver(options["mode"])
        params: PredictionBackfillParams | None = params_resolver(**options)
        if not params:
            return

        initiate_backfill(params.config_pk, **options)

        model_definition = BlastFurnaceModelDefinition.objects.get(pk=params.model_definition_id)
        interval = pd.Timedelta(params.interval)
        freq = pd.Timedelta(params.freq)
        start, end = params.start, params.end

        if end <= start:
            raise ValueError("The start date must precede the end date")

        datasources = get_datasources_configured_with_env()
        model = get_blast_furnace_model(model_definition)

        logger.info(f"Calculate predictions for date range: {start} - {end} for model {model_definition}")
        intervals = list(partition_range_into_intervals(start, end, interval))

        t = time.perf_counter()
        for start, end in tqdm(intervals, total=len(intervals)):
            calc_times = get_calc_times_from_interval_boundaries(start, end, freq)
            data_definitions = [model.get_data_definition(calc_time) for calc_time in calc_times]
            data_definition = get_minmax_data_definition(data_definitions)
            signal_group_data = get_signal_group_data(data_definition, datasources)
            model_results = model.calculate_batch(signal_group_data, calc_times)

            for model_result in model_results:
                BlastFurnacePredictionResult.objects.update_or_create(
                    model_definition=model_definition,
                    calc_time=model_result.calc_time,
                    defaults={"encoded": model_result.to_bytes()},
                )
        finalize_backfill(params.config_pk, **options)

        t2 = time.perf_counter()
        logger.info(f"Calculation took {t2 - t}")
        logger.info("Calculation of predictions finished")
