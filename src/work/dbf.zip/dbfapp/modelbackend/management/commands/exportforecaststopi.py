import logging
from typing import Any, Literal

import attrs
import numpy as np
import pandas as pd
import torch
from django.core.management.base import BaseCommand
from modelbackend.common import get_blast_furnace_model
from modelbackend.management.commands.runmodels import load_last_utc_model_calc_time
from modelbackend.models import (
    BlastFurnaceModelDeployment,
    BlastFurnacePredictionResult,
    ForecastExportPIPointName,
    TargetID,
)
from modelfrontend.common import get_blast_furnace_model_result, get_result_from_db

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.hooks.piclient.piclient import PiClient, get_pi_point_by_name
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_timestamp
from dbfcore.dataset.signals import get_signal_group_loader
from dbfcore.dataset.signals.protocol import SignalGroupLoader
from dbfcore.predictionmodel.protocols import BlastFurnaceModel
from dbfcore.settings import FURNACE_IDS

logger = logging.getLogger(__name__)


TARGET_ID_TO_SIGNAL_GROUP_SLUG_MAP = {"SILICON": "hotmetal_chem_pi", "TEMPERATURE": "hotmetal_temp"}


@attrs.define(frozen=True)
class ForecastExport:
    pi_point_name: str
    kind: Literal["RAW", "COMBINED"]
    forecast: float


# RAW FORECAST #
def get_forecast_from_prediction_result(
    result_db: BlastFurnacePredictionResult, model: BlastFurnaceModel, forecast_horizons_mins: list[int]
) -> pd.Series:
    forecast_horizons = [pd.Timedelta(minutes=fhm) for fhm in forecast_horizons_mins]
    result = get_blast_furnace_model_result(result_db, model)
    return pd.Series(
        data=[result.get_expected_value(horizon) for horizon in forecast_horizons],
        name=result.calc_time,
        index=[f"forecast_{int(horizon.total_seconds()/60)}" for horizon in forecast_horizons],
    )


def get_raw_forecast_export(
    calc_time: pd.Timestamp,
    deployment: BlastFurnaceModelDeployment,
    horizons: list[int],
    pi_point_names_db: Any,
) -> ForecastExport | None:
    raw_pi_point_name_db: ForecastExportPIPointName = pi_point_names_db.filter(forecast_kind="RAW").first()
    if not raw_pi_point_name_db:
        raise ValueError("Pi point name for RAW kind of forecast must be defined.")

    result_db = get_result_from_db(deployment.model_definition, calc_time)
    if not result_db:
        return None

    model = get_blast_furnace_model(deployment.model_definition)
    forecast = get_forecast_from_prediction_result(result_db, model, horizons)["forecast_0"].item()
    return ForecastExport(
        forecast=forecast,
        kind="RAW",
        pi_point_name=raw_pi_point_name_db.pi_point_name,
    )


# COMBINED FORECAST #
def get_signal_group_for_target_and_furnace(target_id: str, furnace_id: int) -> str:
    return f"bf{furnace_id}_{TARGET_ID_TO_SIGNAL_GROUP_SLUG_MAP[target_id]}"


def get_recent_measurement_for_temperature_combined_forecast(
    calc_time: pd.Timestamp,
    recent_measurement_delay: pd.Timedelta,
    furnace_id: int,
    loader: SignalGroupLoader,
) -> float | None:
    signal_name = f"bf{furnace_id}_hotmetal_temp_C"
    data = loader(calc_time - recent_measurement_delay, calc_time)
    if data.empty:
        return None

    return data.sort_index()[signal_name].iloc[-1].item()


def get_recent_measurement_for_silicon_combined_forecast(
    calc_time: pd.Timestamp,
    recent_measurement_delay: pd.Timedelta,
    furnace_id: int,
    loader: SignalGroupLoader,
) -> float | None:
    lab_signal_name = f"bf{furnace_id}_hotmetalsi_pi_chem_pct"
    probe_signal_name = f"bf{furnace_id}_hotmetalsi_pi_probe_chem_pct"

    data = loader(calc_time - recent_measurement_delay, calc_time)

    if lab_signal_name in data.columns:
        lab_data = data[lab_signal_name].dropna()
        if not lab_data.empty:
            return lab_data.sort_index().iloc[-1].item()

    if probe_signal_name in data.columns:
        probe_data = data[probe_signal_name].dropna()
        if not probe_data.empty:
            return probe_data.sort_index().iloc[-1].item()
    return None


def get_recent_measurement_for_combined_forecast(
    calc_time: pd.Timestamp,
    recent_measurement_delay: pd.Timedelta,
    target_id: str,
    furnace_id: int,
    datasources: DataSources,
) -> float | None:
    signal_group = get_signal_group_for_target_and_furnace(target_id, furnace_id)
    loader = get_signal_group_loader(signal_group, datasources)

    if target_id == "SILICON":
        return get_recent_measurement_for_silicon_combined_forecast(
            calc_time, recent_measurement_delay, furnace_id, loader
        )
    if target_id == "TEMPERATURE":
        return get_recent_measurement_for_temperature_combined_forecast(
            calc_time, recent_measurement_delay, furnace_id, loader
        )
    raise ValueError(f"Target_id {target_id} is not defined. Allowed values are SILICON or TEMPERATURE.")


def get_combined_forecast_export(
    recent_measurement: float | None, raw_forecast: float, pi_point_names_db: Any
) -> ForecastExport | None:
    combined_pi_point_name_db: ForecastExportPIPointName = pi_point_names_db.filter(
        forecast_kind="COMBINED"
    ).first()
    if not combined_pi_point_name_db:
        return None

    return ForecastExport(
        forecast=recent_measurement or raw_forecast,
        kind="COMBINED",
        pi_point_name=combined_pi_point_name_db.pi_point_name,
    )


# EXPORT #
def export_forecasts_to_pi(
    forecast_exports: list[ForecastExport | None], calc_time: pd.Timestamp, pi_client: PiClient
):
    for fe in forecast_exports:
        if not fe:
            continue
        pi_point = get_pi_point_by_name(pi_client, fe.pi_point_name)
        pi_point.add_or_update_value(fe.forecast, calc_time)
        logger.info(
            f"""{fe.kind} forecast {fe.forecast} at {calc_time} for {fe.pi_point_name} exported to PI"""
        )


class Command(BaseCommand):
    help = "Generate and export model forecasts for given calc time."

    def add_arguments(self, parser):
        parser.add_argument(
            "-b",
            "--furnace-id",
            type=int,
            nargs="+",
            default=FURNACE_IDS,
            help="Furnaces for which forecasts will be exported",
        )
        parser.add_argument(
            "-t",
            "--target-id",
            type=str,
            nargs="+",
            default=TargetID.values,
            help="Targets for which forecasts will be exported",
        )
        parser.add_argument(
            "--horizons",
            type=int,
            nargs="+",
            default=[0],
            help="Forecast horizons in minutes used for calculating forecasts",
        )
        parser.add_argument(
            "-r",
            "--recent-measurement-delay",
            type=int,
            default=30,
            help="Max time in minutes before now in which measured signal will be used for combined forecast",
        )
        parser.add_argument(
            "-c",
            "--calc-time",
            help=" UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_timestamp,
            required=False,
        )

    def handle(self, *args, **options):
        torch.set_grad_enabled(False)
        calc_time = options["calc_time"] or load_last_utc_model_calc_time("1min")
        datasources = get_datasources_configured_with_env()
        furnace_ids = options["furnace_id"]
        target_ids = options["target_id"]
        horizons = options["horizons"]
        recent_measurement_delay = pd.Timedelta(minutes=options["recent_measurement_delay"])

        for furnace_id in furnace_ids:
            for target_id in target_ids:
                deployment = BlastFurnaceModelDeployment.objects.filter(
                    furnace_id=furnace_id, target_id=target_id
                ).first()
                pi_point_names_db = ForecastExportPIPointName.objects.filter(deployment=deployment)
                if not pi_point_names_db:
                    continue

                raw_forecast_export = get_raw_forecast_export(
                    calc_time, deployment, horizons, pi_point_names_db
                )
                if raw_forecast_export is None or np.isnan(raw_forecast_export.forecast):
                    pi_point_names = list(pi_point_names_db.values_list("pi_point_name", flat=True))
                    logger.info(f"Forecasts for {pi_point_names} not available.")
                    continue

                recent_measurement = get_recent_measurement_for_combined_forecast(
                    calc_time, recent_measurement_delay, target_id, furnace_id, datasources
                )
                combined_forecast_export = get_combined_forecast_export(
                    recent_measurement, raw_forecast_export.forecast, pi_point_names_db
                )
                export_forecasts_to_pi(
                    [raw_forecast_export, combined_forecast_export], calc_time, datasources.pi
                )
