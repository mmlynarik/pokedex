from functools import reduce

import numpy as np
import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import get_blast_furnace_model, get_signal_group_data, partition_range_into_intervals
from modelbackend.models import BlastFurnaceModelDefinition
from tqdm import tqdm

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.dataset.signals.tapping_delivery_heat_chem import load_tapping_delivery_heat_chem
from dbfcore.predictionmodel.inference import get_minmax_data_definition
from dbfcore.predictionmodel.protocols import BlastFurnaceModel, BlastFurnaceModelResult
from dbfcore.settings import EXPECTED_DELIVERY_WEIGHT_T, FURNACE_IDS


def get_avg_forecast_for_result(r: BlastFurnaceModelResult, forecast_horizons: list[pd.Timedelta]) -> float:
    return np.array([r.get_expected_value(f) for f in forecast_horizons]).mean().item()


def get_forecasts_from_results(
    results: dict[int, BlastFurnaceModelResult], avg_tapping_period_mins: int
) -> dict[int, float]:
    forecast_horizons = [pd.Timedelta(f"{i}m") for i in range(1, avg_tapping_period_mins + 1)]
    forecasts = [get_avg_forecast_for_result(r, forecast_horizons) for r in results.values()]
    return dict(zip(results.keys(), forecasts))


def get_model_results_for_calc_times(
    model: BlastFurnaceModel, calc_times: list[pd.Timestamp], ds: DataSources
) -> list[BlastFurnaceModelResult]:
    data_definitions = [model.get_data_definition(calc_time) for calc_time in calc_times]
    data_definition = get_minmax_data_definition(data_definitions)
    signal_group_data = get_signal_group_data(data_definition, ds)
    model_results = model.calculate_batch(signal_group_data, calc_times)
    return model_results


def calculate_model_results_at_tapping_starts(
    df: pd.DataFrame,
    furnace_to_model_def_map: dict[int, int],
    interval: str,
    ds: DataSources,
) -> dict[int, BlastFurnaceModelResult]:
    df = df[df["furnace_id"].isin(furnace_to_model_def_map)]
    tappings = df[["tapping_id", "tapping_start_date", "furnace_id"]].drop_duplicates()
    results: dict[int, BlastFurnaceModelResult] = {}
    for furnace_id in furnace_to_model_def_map:
        model_definition = BlastFurnaceModelDefinition.objects.get(pk=furnace_to_model_def_map[furnace_id])
        model = get_blast_furnace_model(model_definition)
        bft = tappings[tappings["furnace_id"] == furnace_id]
        if bft.empty:
            continue

        first_calc_time, last_calc_time = bft["tapping_start_date"].min(), bft["tapping_start_date"].max()
        intervals = list(partition_range_into_intervals(first_calc_time, last_calc_time, interval))

        for start, end in tqdm(intervals, total=len(intervals)):
            chunk = bft[(bft["tapping_start_date"] >= start) & (bft["tapping_start_date"] <= end)]
            calc_times = chunk["tapping_start_date"]
            if chunk.empty:
                continue

            model_results = get_model_results_for_calc_times(model, calc_times, ds)
            results = results | dict(zip(chunk["tapping_id"], model_results))
    return results


def get_deliveries_proportions_in_heats(df: pd.DataFrame) -> pd.DataFrame:
    heats = df.groupby(["heat_id", "pig_iron_weight"], as_index=False).agg(
        {"delivery_id": list, "weight_from_mixer": list}
    )
    heats["deliveries"] = heats.apply(
        lambda row: dict(zip(row["delivery_id"], row["weight_from_mixer"])), axis=1
    )
    heats["deliveries"] = heats.apply(
        lambda row: {k: v / row["pig_iron_weight"] for k, v in row["deliveries"].items()}, axis=1
    )
    return heats.reindex(columns=["heat_id", "pig_iron_weight", "deliveries"])


def get_tapping_proportions_in_deliveries(df: pd.DataFrame) -> pd.DataFrame:
    deliveries = df.groupby("delivery_id", as_index=False).agg(
        {"tapping_id": list, "estimated_weight_from_tapping": list}
    )
    deliveries["tappings"] = deliveries.apply(
        lambda row: dict(zip(row["tapping_id"], row["estimated_weight_from_tapping"])), axis=1
    )
    deliveries["estimated_mixer_weight"] = deliveries.apply(
        lambda row: sum(list(row["tappings"].values())), axis=1
    )
    deliveries["tappings"] = deliveries.apply(
        lambda row: {k: v / row["estimated_mixer_weight"] for k, v in row["tappings"].items()}, axis=1
    )
    return deliveries.reindex(columns=["delivery_id", "estimated_mixer_weight", "tappings"])


def get_suspicious_overweight_deliveries(df: pd.DataFrame) -> list[int]:
    mixer_weights = (
        df[["delivery_id", "estimated_weight_from_tapping"]]
        .drop_duplicates()
        .groupby("delivery_id", as_index=False)
        .agg(mixer_weight=("estimated_weight_from_tapping", "sum"))
    )
    return mixer_weights[mixer_weights["mixer_weight"] > EXPECTED_DELIVERY_WEIGHT_T]["delivery_id"].tolist()


def filter_heats_affected_by_overweight_deliveries(df: pd.DataFrame, to_exclude: list[int]) -> pd.DataFrame:
    heats_to_exclude = df[df["delivery_id"].isin(to_exclude)]["heat_id"].unique().tolist()
    return df[~df["heat_id"].isin(heats_to_exclude)]


def filter_heats_with_two_mixers_one_delivery_id(df: pd.DataFrame, ds: DataSources) -> pd.DataFrame:
    error_heats = ds.scada.get_two_mixers_one_delivery_error_heats()["heat_id"].tolist()
    return df[~df["heat_id"].isin(error_heats)]


def filter_heats_with_misaligned_mixer_weights(df: pd.DataFrame, ds: DataSources) -> pd.DataFrame:
    error_heats = ds.scada.get_misaligned_mixer_weights_error_heats()["heat_id"].tolist()
    return df[~df["heat_id"].isin(error_heats)]


def filter_error_heats(df: pd.DataFrame, ds: DataSources) -> pd.DataFrame:
    overweight_deliveries = get_suspicious_overweight_deliveries(df)
    df = filter_heats_affected_by_overweight_deliveries(df, overweight_deliveries)
    df = filter_heats_with_two_mixers_one_delivery_id(df, ds)
    df = filter_heats_with_misaligned_mixer_weights(df, ds)
    df["ok_heat"] = True
    return df


def sum_dict_values_reducer(accumulator, element):
    for key, value in element.items():
        accumulator[key] = accumulator.get(key, 0) + value
    return accumulator


def get_tapping_proportions_for_deliveries(tapping_proportions_map: dict, deliveries: dict) -> dict:
    return {
        did: {k: v * dprop for k, v in tapping_proportions_map[did].items()}
        for did, dprop in deliveries.items()
    }


def get_final_tappings_proportions_in_heats(
    tapping_proportions: pd.DataFrame, delivery_proportions: pd.DataFrame
) -> pd.DataFrame:
    tapping_proportions_map = dict(zip(tapping_proportions["delivery_id"], tapping_proportions["tappings"]))
    delivery_proportions["deliveries_tappings"] = delivery_proportions.apply(
        lambda row: get_tapping_proportions_for_deliveries(tapping_proportions_map, row["deliveries"]),
        axis=1,
    )
    delivery_proportions["tappings"] = delivery_proportions.apply(
        lambda row: reduce(sum_dict_values_reducer, list(row["deliveries_tappings"].values()), {}), axis=1
    )
    return delivery_proportions


def filter_boundary_heats_with_non_unity_proportions(final_proportions: pd.DataFrame) -> pd.DataFrame:
    final_proportions["error"] = final_proportions["deliveries"].apply(lambda x: sum(x.values()) != 1)
    return final_proportions[~final_proportions["error"]].sort_values("heat_id").drop(columns=["error"])


def get_heat_si_forecast_and_measurement(
    final_proportions: pd.DataFrame, tapping_si_forecasts: dict[int, float], df: pd.DataFrame
) -> pd.DataFrame:
    final_proportions["heat_si_forecast"] = final_proportions.apply(
        lambda row: sum(tapping_si_forecasts[k] * v for k, v in row["tappings"].items()), axis=1
    )
    final_proportions = final_proportions.merge(
        df[["heat_id", "si_pct"]].drop_duplicates(), how="inner", on="heat_id"
    )
    return final_proportions


def export_output_to_csv(output: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp):
    output.to_csv(f"eval_si_forecast_{start.strftime('%Y-%m-%d')}_{end.strftime('%Y-%m-%d')}.csv")


def get_tapping_proportions_in_heats(start: pd.Timestamp, end: pd.Timestamp, ds: DataSources):
    df = load_tapping_delivery_heat_chem(start, end, ds).reset_index()
    df = filter_error_heats(df, ds)
    return calculate_tapping_proportions_in_heats(df)


def calculate_tapping_proportions_in_heats(df: pd.DataFrame) -> pd.DataFrame:
    deliveries_proportions = get_deliveries_proportions_in_heats(df)
    tappings_proportions = get_tapping_proportions_in_deliveries(df)
    final_proportions = get_final_tappings_proportions_in_heats(tappings_proportions, deliveries_proportions)
    final_proportions = filter_boundary_heats_with_non_unity_proportions(final_proportions)
    final_proportions = final_proportions.merge(
        df[["heat_id", "si_pct", "ok_heat"]].drop_duplicates(), how="inner", on="heat_id"
    )
    return final_proportions


def get_bf_proportions_in_heats(df: pd.DataFrame) -> pd.DataFrame:
    for bf in FURNACE_IDS:
        df[f"bf{bf}_proportion"] = df["tappings"].apply(
            lambda x: sum(v for k, v in x.items() if str(k)[0] == str(bf))
        )
    return df


def get_bf_proportions_by_tappings(start: pd.Timestamp, end: pd.Timestamp, ds: DataSources):
    tapping_proprtions = get_tapping_proportions_in_heats(start, end, ds)
    bf_proportions = get_bf_proportions_in_heats(tapping_proprtions)
    return bf_proportions


def get_si_forecasts_evaluation_on_steelshop(
    start: pd.Timestamp,
    end: pd.Timestamp,
    ds: DataSources,
    furnace_to_model_def_map: dict[int, int],
    interval: pd.Timedelta = pd.Timedelta("1W"),
    avg_tapping_period_mins: int = 90,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df = load_tapping_delivery_heat_chem(start, end, ds).reset_index()
    df = filter_error_heats(df, ds)
    results = calculate_model_results_at_tapping_starts(df, furnace_to_model_def_map, interval, ds)
    tapping_si_forecasts = get_forecasts_from_results(results, avg_tapping_period_mins)
    deliveries_proportions = get_deliveries_proportions_in_heats(df)
    tappings_proportions = get_tapping_proportions_in_deliveries(df)
    final_proportions = get_final_tappings_proportions_in_heats(tappings_proportions, deliveries_proportions)
    final_proportions = filter_boundary_heats_with_non_unity_proportions(final_proportions)
    output = get_heat_si_forecast_and_measurement(final_proportions, tapping_si_forecasts, df)
    return output, tapping_si_forecasts, df


class Command(BaseCommand):
    help = "Generate silicon forecast evaluation on steelshop."

    def add_arguments(self, parser):
        parser.add_argument("--model-def-bf1", type=int, help="Model definition ID for furnace 1")
        parser.add_argument("--model-def-bf2", type=int, help="Model definition ID for furnace 2")
        parser.add_argument("--model-def-bf3", type=int, help="Model definition ID for furnace 3")
        parser.add_argument(
            "-s",
            "--start",
            help="Start UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-e",
            "--end",
            help="End UTC datetime in ISO 8601 format w/o seconds and tzinfo, e.g. 2023-01-05T14:20",
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-i",
            "--interval",
            help="Interval to which total date range will be broken down",
            type=str,
            default="1W",
        )
        parser.add_argument(
            "-t", "--tapping-avg-period", help="Average tapping period in minutes", type=int, default=90
        )

    def handle(self, *args, **options):
        start = options["start"]
        end = options["end"]
        avg_tapping_period_mins = options["tapping_avg_period"]
        interval = pd.Timedelta(options["interval"])
        furnace_to_model_def_map = {
            1: options["model_def_bf1"],
            2: options["model_def_bf2"],
            3: options["model_def_bf3"],
        }
        ds = get_datasources_configured_with_env()
        output, _, _ = get_si_forecasts_evaluation_on_steelshop(
            start,
            end,
            ds,
            furnace_to_model_def_map,
            interval,
            avg_tapping_period_mins,
        )
        export_output_to_csv(output, start, end)
