import base64
import json
import logging
from datetime import datetime
from typing import TypedDict

import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import get_n_previous_days_start_end_timestamps
from modelbackend.models import StoveHeatingPhase

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.hooks.piclient.preprocessing import get_pi_data_as_dataframe
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.dataset.signals.stove_input_gases import load_stoves_input_gases, preprocess_stove_data
from dbfcore.dataset.signals.stoves_temperatures import load_stoves_temperatures
from dbfcore.model.datamodule.common import PI_POINT_NAME_TO_SIGNAL_NAMES_MAP
from dbfcore.settings import FURNACE_IDS
from dbfcore.stoves.input_data import get_stoves_input_data

logger = logging.getLogger(__name__)

STOVES_AIR_PI_POINT_NAMES = [
    [
        "SK1.Stove11.CombustionAir.Vol.m3/h",
        "SK1.Stove12.CombustionAir.Vol.m3/h",
        "SK1.Stove13.CombustionAir.Vol.m3/h",
        "SK1.Stove14.CombustionAir.Vol.m3/h",
    ],
]


class HeatingPhase(TypedDict):
    stove_number: int
    start: datetime
    end: datetime


def get_stoves_air_pi_point_names(furnace_id: int) -> list[str]:
    return STOVES_AIR_PI_POINT_NAMES[furnace_id - 1]


def get_stoves_air_signal_names(furnace_id: int) -> list[str]:
    signal_names = [
        PI_POINT_NAME_TO_SIGNAL_NAMES_MAP[signal] for signal in get_stoves_air_pi_point_names(furnace_id)
    ]
    return [names_tuple[0] for names_tuple in signal_names]


def get_stoves_air_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    air_pi_point_names = get_stoves_air_pi_point_names(furnace_id)
    air_signal_names = get_stoves_air_signal_names(furnace_id)

    dfs = []
    for pi_point_name, signal_name in zip(air_pi_point_names, air_signal_names):
        stove_data = get_pi_data_as_dataframe(datasources.pi, pi_point_name, start, end, signal_name)
        if stove_data.empty:
            return pd.DataFrame()
        stove_data_preprocessed = preprocess_stove_data(stove_data, signal_name)
        stove_data_resampled_1min = stove_data_preprocessed.resample(
            "1min", label="right", closed="right"
        ).mean()
        dfs.append(stove_data_resampled_1min)

    return pd.concat(dfs, axis=1)


def merge_heating_phases(group: pd.DataFrame, stove_number: int) -> pd.DataFrame:
    # In some cases, one heating phase appears as two separate ones, because the air flow (and fuel flow)
    # dropped to zero for a few minutes. For this reason, we defined the threshold of the time difference
    # between two heating phases to 30 minutes, i.e. if the time difference between two heating phases is
    # less than or equal to 30 minutes, then these phases will be merged into one.
    group = group.sort_values("start").reset_index(drop=True)
    merged = []

    current_start, current_end = group.loc[0, "start"], group.loc[0, "end"]

    for row in group.itertuples(index=False):
        if row.start <= current_end + pd.Timedelta(minutes=30):
            current_end = max(current_end, row.end)
        else:
            merged.append((stove_number, current_start, current_end))
            current_start, current_end = row.start, row.end

    merged.append((stove_number, current_start, current_end))

    return pd.DataFrame(merged, columns=["stove_number", "start", "end"])


def detect_heating_phases(stoves_air_df: pd.DataFrame) -> list[HeatingPhase]:
    heating_phases: list[HeatingPhase] = []

    for column in stoves_air_df.columns:
        stove_number = int(column.split("_")[1][-2:])

        is_heating = False

        for i, (timestamp, value) in enumerate(stoves_air_df[column].items()):
            if value > 0 and not is_heating:
                is_heating = True
                start_time = timestamp
            elif value == 0 and is_heating:
                is_heating = False
                end_time = stoves_air_df.index[i - 1]
                heating_phases.append({"stove_number": stove_number, "start": start_time, "end": end_time})

        if is_heating:
            heating_phases.append(
                {"stove_number": stove_number, "start": start_time, "end": stoves_air_df.index[-1]}
            )

    return heating_phases


def get_heating_phases(stoves_air_df: pd.DataFrame, furnace_id: int) -> pd.DataFrame:
    heating_phases = detect_heating_phases(stoves_air_df)

    heating_phases_df = (
        pd.DataFrame(heating_phases)
        .groupby("stove_number", group_keys=False)
        .apply(lambda group: merge_heating_phases(group, group.name), include_groups=False)
    )

    heating_phases_df["heating_phase_id"] = heating_phases_df.apply(
        lambda row: f"{furnace_id}_{row['stove_number']}_{row['start'].strftime('%Y%m%d%H%M')}", axis=1
    )
    return heating_phases_df.set_index("heating_phase_id").drop(columns=["stove_number"])


def get_stoves_heating_phases_dts(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    start_updated = start - pd.Timedelta(hours=5)
    end_updated = end + pd.Timedelta(hours=5)
    stoves_air_df = get_stoves_air_data(start_updated, end_updated, furnace_id, datasources)
    stoves_heating_phases_df = get_heating_phases(stoves_air_df, furnace_id)

    return stoves_heating_phases_df[
        ((stoves_heating_phases_df["start"] >= start) & (stoves_heating_phases_df["end"] <= end))
        | (
            (stoves_heating_phases_df["start"] >= start)
            & (stoves_heating_phases_df["start"] <= end)
            & (stoves_heating_phases_df["end"] > end)
        )
    ].sort_values(by="start")


class Command(BaseCommand):
    help = "Export stove heating phase datetimes (as .parquet file) for given time period into Y."

    def add_arguments(self, parser):
        parser.add_argument(
            "-b",
            "--blastfurnaceid",
            type=int,
            nargs="+",
            required=True,
            help="Blast furnace IDs for which data will be exported",
        )
        parser.add_argument(
            "-s",
            "--start",
            help="Start UTC date in ISO 8601 format w/o tzinfo, e.g. 2023-01-01",
            required=False,
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-e",
            "--end",
            required=False,
            help="End UTC date in ISO 8601 format w/o tzinfo, e.g. 2023-01-01",
            type=parse_naive_string_as_utc_datetime,
        )

    def handle(self, *args, **options):
        start, end = options["start"], options["end"]
        if start is None or end is None:
            start, end = get_n_previous_days_start_end_timestamps()
        datasources = get_datasources_configured_with_env()
        for furnace_id in options["blastfurnaceid"]:
            if furnace_id not in FURNACE_IDS:
                raise ValueError(f"Invalid blast furnace ID: {furnace_id}. Valid IDs are: {FURNACE_IDS}")

            # TODO: Remove this restriction in the future to allow other blast furnace IDs
            if furnace_id != 1:
                raise ValueError(
                    f"Not allowed blast furnace ID: {furnace_id}. This command is currently restricted to Blast Furnace ID 1."
                )

            if start >= end:
                raise ValueError("Start date must be earlier than end date.")

            result_df = get_stoves_heating_phases_dts(start, end, furnace_id, datasources)

            if result_df.empty:
                raise ValueError(
                    f"No data found for the given time period: {start} - {end} for blast furnace ID: {furnace_id}."
                )

            for index, row in result_df.iterrows():
                furnace_id = int(index.split("_")[0])
                stove_number = int(index.split("_")[1])

                input_gases_df = load_stoves_input_gases(row["start"], row["end"], furnace_id, datasources)
                stove_temperatures_df = load_stoves_temperatures(
                    row["start"], row["end"], furnace_id, datasources.pi
                )
                stoves_input_data = get_stoves_input_data(
                    row["start"], row["end"], input_gases_df, stove_temperatures_df, furnace_id, stove_number
                )
                stoves_input_data_base64_str = base64.b64encode(
                    json.dumps(stoves_input_data).encode()
                ).decode()

                StoveHeatingPhase.objects.update_or_create(
                    heating_phase_id=index,
                    defaults={
                        "start": row["start"],
                        "end": row["end"],
                        "input_data": stoves_input_data_base64_str,
                    },
                )
