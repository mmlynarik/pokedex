import logging

import pandas as pd
from django.core.management.base import BaseCommand
from modelbackend.common import (
    get_blast_furnace_model,
    get_n_previous_days_start_end_timestamps,
    partition_range_into_intervals,
)
from modelbackend.models import BlastFurnaceEvalData, BlastFurnaceModelDeployment
from modelfrontend.common import get_blast_furnace_model_result, get_results_from_db
from tqdm import tqdm

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import parse_naive_string_as_utc_datetime
from dbfcore.dataset.signals.hotmetal_chems import load_hotmetal_chems
from dbfcore.settings import EVAL_MODE_FORECAST_FREQUENCY, EVAL_MODE_FORECAST_HORIZONS_MINS

logger = logging.getLogger(__name__)


def get_analysis_date_and_si_data(
    start: pd.Timestamp, end: pd.Timestamp, furnace_id: int, datasources: DataSources
) -> pd.DataFrame:
    hotmetal_chems_df = load_hotmetal_chems(start, end, furnace_id, datasources)
    if hotmetal_chems_df.empty:
        return pd.DataFrame()
    analysis_date_and_si_data = hotmetal_chems_df.loc[
        :, [f"bf{furnace_id}_pig_iron_analysis_date", f"bf{furnace_id}_hotmetalsi_chem_pct"]
    ].assign(est_sample_collection_date=lambda df: df.index)

    analysis_date_and_si_data.index = analysis_date_and_si_data.index.ceil("15min")
    analysis_date_and_si_data = analysis_date_and_si_data[
        ~analysis_date_and_si_data.index.duplicated(keep="first")
    ]
    return analysis_date_and_si_data


def get_silicon_models_forecast_data(
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
    forecast_horizons_mins: list[int] = EVAL_MODE_FORECAST_HORIZONS_MINS,
    forecast_frequency: pd.Timedelta = EVAL_MODE_FORECAST_FREQUENCY,
) -> pd.DataFrame:
    forecasts = []
    deployment = BlastFurnaceModelDeployment.objects.get(furnace_id=furnace_id, target_id="SILICON")
    forecast_horizons = [pd.Timedelta(minutes=fhm) for fhm in forecast_horizons_mins]
    model = get_blast_furnace_model(deployment.model_definition)
    results_db = get_results_from_db(deployment.model_definition, start, end, forecast_frequency, True)
    results = [get_blast_furnace_model_result(result_db, model) for result_db in results_db]

    for result in results:
        forecasted_expected_values = pd.Series(
            data=[result.get_expected_value(horizon) for horizon in forecast_horizons],
            name=result.calc_time,
            index=[f"forecast_{int(horizon.total_seconds()/60)}" for horizon in forecast_horizons],
        )
        forecasts.append(forecasted_expected_values)

    return pd.concat(forecasts, axis=1).T


class Command(BaseCommand):
    help = "Export eval data from previous day into application database."

    def add_arguments(self, parser):
        parser.add_argument(
            "-b",
            "--blastfurnaceid",
            type=int,
            nargs="+",
            required=True,
            help="Blast furnace IDs for which data will be exported",
        )
        parser.add_argument(
            "-s",
            "--start",
            help="Start UTC date in ISO 8601 format w/o tzinfo, e.g. 2023-01-01",
            required=False,
            type=parse_naive_string_as_utc_datetime,
        )
        parser.add_argument(
            "-e",
            "--end",
            required=False,
            help="End UTC date in ISO 8601 format w/o tzinfo, e.g. 2023-01-01",
            type=parse_naive_string_as_utc_datetime,
        )

    def handle(self, *args, **options):
        start, end = options["start"], options["end"]
        if start is None or end is None:
            start, end = get_n_previous_days_start_end_timestamps()
        logger.info(f"Calculating eval data for period {start} - {end}")
        intervals = list(partition_range_into_intervals(start, end, pd.Timedelta("1D")))
        datasources = get_datasources_configured_with_env()
        for start, end in tqdm(intervals, total=len(intervals)):

            data_for_export = pd.DataFrame()
            for furnace_id in options["blastfurnaceid"]:
                analysis_date_and_si_data = get_analysis_date_and_si_data(start, end, furnace_id, datasources)
                if analysis_date_and_si_data.empty:
                    continue

                forecast_data = get_silicon_models_forecast_data(start, end, furnace_id)
                eval_data = (
                    pd.concat([analysis_date_and_si_data, forecast_data], axis=1)
                    .sort_index()
                    .assign(furnace_id=furnace_id)
                )
                if not eval_data.empty:
                    data_for_export = pd.concat([data_for_export, eval_data])
                for index, row in data_for_export.iterrows():
                    BlastFurnaceEvalData.objects.update_or_create(
                        defaults={
                            "pig_iron_analysis_date": (
                                row[f"bf{furnace_id}_pig_iron_analysis_date"]
                                if pd.notna(row[f"bf{furnace_id}_pig_iron_analysis_date"])
                                else None
                            ),
                            "est_sample_collection_date": (
                                row["est_sample_collection_date"]
                                if pd.notna(row["est_sample_collection_date"])
                                else None
                            ),
                            "si_pct": (
                                row[f"bf{furnace_id}_hotmetalsi_chem_pct"]
                                if pd.notna(row[f"bf{furnace_id}_hotmetalsi_chem_pct"])
                                else None
                            ),
                            **{
                                f"forecast_{horizon}": (
                                    row[f"forecast_{horizon}"]
                                    if pd.notna(row[f"forecast_{horizon}"])
                                    else None
                                )
                                for horizon in EVAL_MODE_FORECAST_HORIZONS_MINS
                            },
                        },
                        calc_time=index,
                        furnace_id=row["furnace_id"],
                    )
