# Introduction
`DBFAPP` is a Django application that serves as a GUI for DBF project. This app consists of just one page with several charts depicting historical values of monitored features as well as their predictions. 


# Table of contents
- [Introduction](#introduction)
- [Table of contents](#table-of-contents)
- [Production deployment](#production-deployment)
    - [Initialize DB](#initialize-db)
- [Test deployment](#test-deployment)
    - [Initialize DB](#initialize-db-1)
- [Development](#development)
    - [Run DBF app locally](#run-dbf-app-locally)
    - [Initialize DB](#initialize-db-2)
- [Commands](#commands)
    - [Runmodels](#runmodels)
    - [Runbackfill](#runbackfill)
    - [Calculatemetrics](#calculatemetrics)
- [Static File Checkers](#static-file-checkers)
- [Unit tests](#unit-tests)


# Production deployment
Production operation of the DBF app's GUI runs in kubernetes on servers that can be accessed by linking to the following addresses:
  * dbf.sk.uss.com

### Initialize DB
In order to deploy and get outputs from pre-trained models, it is necessary to load them to production DB. To load production models into DB use the following steps:
  1. Navigate to application's admin page (`dbf.sk.uss.com/admin`)
     * If necessary create a superuser - for more information see the [official documentation](https://docs.djangoproject.com/en/1.8/intro/tutorial02/#creating-an-admin-user) 
  2. In the navigation menu choose `Blast furnace embedding models` and add as many autoencoder models needed
     * fill in name, signal main group and choose particular model using the context window (it will be copied into project's media folder)
     * currently, 4 embedding models are being used: hotblast, hotmetalchem, hotmetaltemp, and topgas
     * currently used embedding models can be found here: `Y:/Departments/IT/DSE/DBF-Y/!MODELS/EMBEDDINGS`
  3. In the navigation menu choose `Neural blast furnace model definitions` and add as many prediction models as needed
     * fill in name
     * value resolution (currently 201)
     * time sresolution (currently 241)
     * particular model with its config file using the context window (models with configs will be copied into project's media folder)
     * choose autoencoder (embedding) models to be used for embeddings encoding
     * currently used prediction models can be found here: `Y:/Departments/IT/DSE/DBF-Y/!MODELS/BF1 (BF2 or BF3)`
  4. In the navigation menu choose `Blast furnace model definitions` and select from drop-down menu neural model definitions to be used
  5. In the navigation menu choose `Blast furnace model deployments` and select model definitions to be used
  6. [OPTIONAL] In the navigation menu choose `Blast furnace targets` and add targets if necessary


# Test deployment
Test operation of the DBF app's GUI runs in kubernetes on servers that can be accessed by linking to the following addresses:
  * dbf.sk.uss.com:8080
  * http://10.8.12.30:30030/

### Initialize DB
For more information see how to [initialize DB](#initialize-db).


# Development
There are two crucial commands that need to run to be able to access the DBF web app: `runmodels` and `runserver`. The `runmodels` command ensures continual generation of predictions from prediction model. The `runserver` command is the basic Django command that runs the Django app.

### Run DBF app locally
In order to run the application locally, follow the instructions:

1. In your terminal navigate to the folder where `manage.py` takes place:
    ```shell
    cd ./dbfapp
    ```
2. Migrate database changes:
    ```shell
    python manage.py migrate
    ```
3. Run the application
    ```shell
    python manage.py runserver
    ```
4. Choose a blast furnace model screen and proceed

### Initialize DB
Initialization of DB entities is the same as in case of production or test deployment.
For more information see how to [initialize DB](#initialize-db).


# Commands

### Runmodels
`Runmodels` is an elementary command ensuring the generation of predictions from the prediction model. It needs to run to be able to get the model predictions and to evaluate them. Finally, prediction results are stored as DB objects - `Neural prediction results`

In order to run the `runmodels` command, follow the instructions:

1. Run the application locally (see [Run DBF app locally](#run-dbf-app-locally))
2. Navigate to the Django admin page (for more info visit [Django admin page](https://docs.djangoproject.com/en/5.1/ref/contrib/admin/))
3. Insert a *Neural blast furnace model deployment*
4. Insert paths to autoencoders via *Signal main group embedding models*
5. In your terminal navigate to the folder where `manage.py` takes place:
    ```shell
    cd ./dbfapp
    ```
6. Run the `runmodels` command:
    ```shell
    python manage.py runmodels
    ```

### Runbackfill
Backfill command serves to save prediction model results to DB for defined period. In order to backfill model results, first navigate to the folder where `manage.py` takes place ant then use the following command:

```shell
python manage.py runbackfill -m [model_id] -s [start_datetime] -e [end_datetime] -i [interval]
```

### Calculatemetrics
`Calculatemetrics` serves to calculate some metrics for defined model. Currently, the following metrics can be used:
 - `SimpleOrAbsoluteErrorMetric`
    - calculates either simple or absolute error between forecast and real measurement
 - `TargetHitConfusionMatrixMetric`
    - defines the number of forecasts and real value measurements that belong to the specified categories
    - the categories are: *on target*, *over target*, *under target*
    - `category_tolerance` determines the metric groups (defined in config yaml file)
 - `ZeroForecastTrendMetric`
    - determines the current trend of forecasts and real measurements and compares their directions
    - trends for both forecasts and real values are calculated as a difference between current value (time 1) and previous value (time 0)
      - `forecast_trend = forecast_value_at_time_1 - forecast_value_at_time_0`
      - `real_value_trend = real_value_at_time_1 - real_value_at_time_0`
    - output forms: *trend histogram (trend_hist)* and *confusion matrix (conf_matrix)*
    - *trend histogram*
      - calculates the difference between forecasts trends and real values trends and normalizes it to the time window between adjacent measurments
      - standard deviation is the method of choice to evaluate the results
    - *confusion matrix*
      - defines the number of forecasts and real value trends that belong to the specified categories
      - there are 2 category limits that determine boundaries: `category_boundary_1` and `category_boundary_2`
      - category limits are defined in config yaml file
 - `PredictionTrendMetric`
    - determines the current trend of forecasts and real measurements and compares their directions
    - trends for real values are calculated as a difference between current value (rv_time_1) and previous value (rv_time_0)
      - `real_value_trend = real_value_at_time_1 - real_value_at_time0`
    - trends for forecasts are calculated as a difference between forecast x and forecast 0
      - x represents a forecast window calculated as a difference between *rv_time_1* and *rv_time_0*
      - `forecast_trend = forecast_value_at_forecast_window_x - forecast_value_at_forecast_window_0`
    - output forms: *trend histogram (trend_hist)* and *confusion matrix (conf_matrix)*
    - *trend histogram*
      - calculates the difference between forecasts trends and real values trends and normalizes it to the time window between adjacent measurments
      - standard deviation is the method of choice to evaluate the results
    - *confusion matrix*
      - defines the number of forecasts and real value trends that belong to the specified categories
      - there are 2 category limits that determine boundaries: `category_boundary_1` and `category_boundary_2`

The configuration to metrics calculation is specified in `yaml` file. Following are templates for such `yaml` files:

 ```yaml
start: 2025-01-01
end: 2025-02-01
batchinterval: 12h
pre_interval_offset: 0h  # offset that updates start (if offset > 0 -> start = start - offset)
metrics:
  - name: SimpleOrAbsoluteErrorMetric
    signal_name: bf1_hotmetalafterslag_temp_C
    forecast_window: 0min
    tolerance: 1min
    metric_type: absolute
  - name: TargetHitConfusionMatrixMetric
    signal_name: bf1_hotmetalafterslag_temp_C
    forecast_window: 0min
    tolerance: 1min
    furnace_id: 1
    metric_type: silicon
    category_tolerance: 0.1
  - name: ZeroForecastTrendMetric
    signal_name: bf1_hotmetalafterslag_temp_C
    forecast_window: 0min
    tolerance: 1min
    metric_type: conf_matrix
    category_boundary_1: 20
    category_boundary_2: 50
  - name: PredictionTrendMetric
    signal_name: bf1_hotmetalafterslag_temp_C
    tolerance: 1min
    metric_type: trend_hist
    category_boundary_1: 20
    category_boundary_2: 50
```

NOTE!: In order to calculate metrics for defined model, it is necessary to have prediction results - use [`runbackfill`](#runbackfill) command to generate particular prediction results.

```shell
python manage.py calculatemetrics -m [model_id] -c [path/to/metrics.yaml] -o [path/to/output.parquet]
```


# Static File Checkers
To run the usual static file checkers use the following commands:

```shell
echo "Running Mypy static-typing check"
mypy --config-file path/to/config/file .

echo "Running Black formatting check"
black --config path/to/config/file --check .

echo "Running Isort imports sorting check"
isort --settings path/to/config/file --check .

echo "Running Ruff linting check"
ruff check --config path/to/config/file .
echo "Linting check completed. No issues found."
```


# Unit tests
To run the unittests, navigate to `./dbfapp` folder (where `manage.py` is located) and run the following command:

```shell
python manage.py test
```
