import json
import logging
from functools import lru_cache, partial, reduce
from http import HTTPStatus
from operator import add
from random import randint
from typing import Sequence, TypedDict

import cattrs
import cvxpy as cp
import numpy as np
from django.http import HttpResponse, JsonResponse
from modelfrontend.common import BfHeaterOptimizationResult, BfOptimizerInput, ItemType

logger = logging.getLogger(__name__)


class StoveGas(TypedDict):
    price: float
    cal_val: float


class StoveGases(TypedDict):
    blast_furnace_gas: StoveGas
    coke_gas: StoveGas
    natural_gas: StoveGas


class GasLimit(TypedDict):
    minimum: float
    maximum: float


class GasLimits(TypedDict):
    mixed_gas: GasLimit
    coke_gas: GasLimit


def get_stove_index_mapping(stoves_on_off: Sequence[bool]) -> dict[int, int]:
    result = {}
    current_max_index = 0
    for i, stove_on_off in enumerate(stoves_on_off):
        if stove_on_off:
            result[i] = current_max_index
            current_max_index += 1
        else:
            result[i] = -1
    return result


# TODO this should go to dbfcore code
# stoves_on_off - lenght N - N is number of stoves
# stoves_temperature_target - length N - N is number of stoves
# limits - length N - N is number of stoves
# gas_settings
# enrichment_factor - percentage of natural gas mixed to blast furnace gas
def optimize_for_enrichment_ratio(
    stoves_on_off: Sequence[bool],
    stoves_temperature_target: Sequence[float],
    limits: Sequence[GasLimits],
    gas_settings: StoveGases,
    enrichment_factor: float,
):
    if (enrichment_factor < 0.0) or (enrichment_factor > 1.0):
        raise ValueError("Enrichment factor must be between 0.0 and 1.0")

    stoves_on = len([stove_on for stove_on in stoves_on_off if stove_on])
    stoves_cal_val_wanted = ((0.0081 * np.array(stoves_temperature_target)) - 7.1257) * 1000
    on_stoves_cal_vals_wanted = [
        cvw for cvw, stove_on in zip(stoves_cal_val_wanted, stoves_on_off) if stove_on
    ]
    on_stoves_limits = [limit for limit, stove_on in zip(limits, stoves_on_off) if stove_on]

    # VARIABLES
    mixed_gases = [cp.Variable(name=f"Mixed gas for stove {i}", pos=True) for i in range(stoves_on)]
    coke_gases = [cp.Variable(name=f"Coke gas for stove {i}", pos=True) for i in range(stoves_on)]

    # MIXED GAS CONSTRAINTS
    mg_lb = [mg >= limit["mixed_gas"]["minimum"] for mg, limit in zip(mixed_gases, on_stoves_limits)]
    mg_ub = [mg <= limit["mixed_gas"]["maximum"] for mg, limit in zip(mixed_gases, on_stoves_limits)]
    # COKE GAS CONSTRAINTS
    cg_lb = [cg >= limit["coke_gas"]["minimum"] for cg, limit in zip(coke_gases, on_stoves_limits)]
    cg_ub = [cg <= limit["coke_gas"]["maximum"] for cg, limit in zip(coke_gases, on_stoves_limits)]

    # CAL VAL CONSTRAINTS
    mixed_gas_cal_val = (enrichment_factor * gas_settings["natural_gas"]["cal_val"]) + (
        (1.0 - enrichment_factor) * gas_settings["blast_furnace_gas"]["cal_val"]
    )
    cal_val_constraints = [
        (((mixed_gas_cal_val * mg) + (gas_settings["coke_gas"]["cal_val"] * cg)) / (mg + cg))
        >= cal_val_wanted
        for mg, cg, cal_val_wanted in zip(mixed_gases, coke_gases, on_stoves_cal_vals_wanted)
    ]

    # OBJECTIVE
    mixed_gas_price = (enrichment_factor * gas_settings["natural_gas"]["price"]) + (
        (1.0 - enrichment_factor) * gas_settings["blast_furnace_gas"]["price"]
    )
    mixed_gas_prices = [mixed_gas_price * mg for mg in mixed_gases]
    coke_gas_prices = [gas_settings["coke_gas"]["price"] * cg for cg in coke_gases]

    obj = cp.Minimize(reduce(add, [*mixed_gas_prices, *coke_gas_prices], 0.0))

    # Form and solve problem.
    prob = cp.Problem(obj, [*cal_val_constraints, *mg_lb, *mg_ub, *cg_lb, *cg_ub])
    prob.solve(qcp=True, eps=0.1)  # Returns the optimal value.
    return prob.status, prob.value, [(mg.value, cg.value) for mg, cg in zip(mixed_gases, coke_gases)]


# TODO otestovat pre vsetky ohrievace vypnute


def get_heater_result(
    heater_index: int, results: list[tuple[float, float]], gas_settings: StoveGases, ng_enrichment: float
) -> dict[ItemType, float]:
    if heater_index == -1:
        return {
            "VPP [Nm3/h]": 0.0,
            "KP [Nm3/h]": 0.0,
            "ZP [Nm3/h]": 0.0,
            "Výhrevnosť [MJ/m3]": 0.0,
            "Cena [€ za Nm3/h]": 0.0,
        }

    mixed_gas, coke_gas = results[heater_index]

    if (mixed_gas is None) or (coke_gas is None):
        return {
            "VPP [Nm3/h]": -1.0,
            "KP [Nm3/h]": -1.0,
            "ZP [Nm3/h]": -1.0,
            "Výhrevnosť [MJ/m3]": -1.0,
            "Cena [€ za Nm3/h]": -1.0,
        }

    bfg = mixed_gas * (1.0 - ng_enrichment)
    ng = mixed_gas * ng_enrichment

    cal_val = (
        (gas_settings["blast_furnace_gas"]["cal_val"] * bfg)
        + (gas_settings["natural_gas"]["cal_val"] * ng)
        + (gas_settings["coke_gas"]["cal_val"] * coke_gas)
    ) / (bfg + ng + coke_gas)

    total_price = (
        (gas_settings["blast_furnace_gas"]["price"] * bfg)
        + (gas_settings["natural_gas"]["price"] * ng)
        + (gas_settings["coke_gas"]["price"] * coke_gas)
    ) / (bfg + ng + coke_gas)

    return {
        "VPP [Nm3/h]": bfg,
        "KP [Nm3/h]": coke_gas,
        "ZP [Nm3/h]": ng,
        "Výhrevnosť [MJ/m3]": cal_val,
        "Cena [€ za Nm3/h]": total_price,
    }


def find_result_with_minimal_enrichment_ratio(fn, minimum: float, maximum: float):
    if abs(minimum - maximum) < 0.0001:
        minimal_result = fn(minimum)
        _, minimal_cost, _ = minimal_result
        if minimal_cost < float("inf"):
            return minimum, minimal_result
        return maximum, fn(maximum)

    maximal_result = fn(maximum)
    _, maximal_cost, _ = maximal_result
    # Result not achievable
    if maximal_cost == float("inf"):
        return maximum, maximal_result

    minimal_result = fn(minimum)
    _, minimal_cost, _ = minimal_result

    # If minimum is achievable return minimum
    if minimal_cost < float("inf"):
        return minimum, minimal_result

    test_value = (minimum + maximum) / 2

    test_result = fn(test_value)
    _, test_cost, _ = test_result

    if test_cost < maximal_cost:
        return find_result_with_minimal_enrichment_ratio(fn, minimum, test_value)
    return find_result_with_minimal_enrichment_ratio(fn, test_value, maximum)


def optimize(
    stoves_on_off: Sequence[bool],
    stoves_temperature_target: Sequence[float],
    limits: Sequence[GasLimits],
    gas_settings: StoveGases,
) -> BfHeaterOptimizationResult:
    stove_index_mapping = get_stove_index_mapping(stoves_on_off)

    subobtimizer = lru_cache(maxsize=None)(
        partial(optimize_for_enrichment_ratio, stoves_on_off, stoves_temperature_target, limits, gas_settings)
    )

    ng_enrichment, result = find_result_with_minimal_enrichment_ratio(subobtimizer, 0.0, 1.0)
    status, total_cost, gas_results = result

    return BfHeaterOptimizationResult(
        heaters=tuple(
            [
                get_heater_result(stove_index_mapping[heater_id], gas_results, gas_settings, ng_enrichment)
                for heater_id in range(len(stoves_on_off))
            ]
        )
    )


def bf_heater_dummy_optimizer(optimizer_input: BfOptimizerInput) -> BfHeaterOptimizationResult:
    return BfHeaterOptimizationResult(
        heaters=tuple(
            [
                {
                    "VPP [Nm3/h]": randint(1, 100) if heater.settings.is_on else 0,
                    "KP [Nm3/h]": randint(1, 100) if heater.settings.is_on else 0,
                    "ZP [Nm3/h]": randint(1, 100) if heater.settings.is_on else 0,
                    "Výhrevnosť [MJ/m3]": randint(1, 100) if heater.settings.is_on else 0,
                    "Cena [€]": randint(1, 100) if heater.settings.is_on else 0,
                }
                for heater in optimizer_input.heaters
            ]
        )
    )


def simple_optimizer(optimizer_input: BfOptimizerInput) -> BfHeaterOptimizationResult:
    stoves_on_off = [stove.settings.is_on for stove in optimizer_input.heaters]
    stoves_temperature_target = [
        stove.settings.temperature_aim_celsius + stove.settings.mutable_constant
        for stove in optimizer_input.heaters
    ]
    stoves_limits: list[GasLimits] = [
        {
            "mixed_gas": {
                "minimum": stove.gas_boundries["VPP + ZP"].minimum,
                "maximum": stove.gas_boundries["VPP + ZP"].maximum,
            },
            "coke_gas": {
                "minimum": stove.gas_boundries["KP"].minimum,
                "maximum": stove.gas_boundries["KP"].maximum,
            },
        }
        for stove in optimizer_input.heaters
    ]
    gas_settings: StoveGases = {
        "blast_furnace_gas": {
            "price": optimizer_input.gas_properties["VPP"].price,
            "cal_val": optimizer_input.gas_properties["VPP"].calorific_value,
        },
        "coke_gas": {
            "price": optimizer_input.gas_properties["KP"].price,
            "cal_val": optimizer_input.gas_properties["KP"].calorific_value,
        },
        "natural_gas": {
            "price": optimizer_input.gas_properties["ZP"].price,
            "cal_val": optimizer_input.gas_properties["ZP"].calorific_value,
        },
    }

    return optimize(stoves_on_off, stoves_temperature_target, stoves_limits, gas_settings)


def bf_heater_optimization_start(request):
    if request.method == "POST":
        body = json.loads(request.body.decode("utf-8"))
        optimizer_input = cattrs.structure(body, BfOptimizerInput)

        logger.info(optimizer_input)

        return JsonResponse(cattrs.unstructure(simple_optimizer(optimizer_input)))

    return HttpResponse(status=HTTPStatus.METHOD_NOT_ALLOWED)
