from django.urls import path, register_converter
from modelfrontend.converters import BoolConverter

from . import api_views, views

register_converter(BoolConverter, "bool")


urlpatterns = [
    path("", views.index, name="modelfrontend-index"),
    # LIVE CHART
    path("chart/live/<int:furnace_id>", views.live_chart, name="live-chart"),
    # LIVEFORECAST CHART JSON
    path(
        "chart/liveforecast/json/<int:furnace_id>",
        views.liveforecast_chart_json,
        name="liveforecast-chart-json-default",
    ),
    path(
        "chart/liveforecast/json/<int:furnace_id>/<int:now>/<int:lookback_minutes>/<int:forecast_minutes>",
        views.liveforecast_chart_json,
        name="liveforecast-chart-json-parametrized",
    ),
    # AVAILABILITY CHART JSON
    path(
        "chart/availability/json/<int:furnace_id>",
        views.availability_chart_json,
        name="availability-chart-json-default",
    ),
    path(
        "chart/availability/json/<int:furnace_id>/<int:now>/<int:lookback_minutes>/<int:forecast_minutes>",
        views.availability_chart_json,
        name="availability-chart-json-parametrized",
    ),
    # EVAL CHART
    path("chart/eval/<int:furnace_id>", views.eval_chart, name="eval-chart"),
    path("chart/eval/json/<int:furnace_id>", views.eval_chart_json, name="eval-chart-json-default"),
    path(
        "chart/eval/json/<int:furnace_id>/<int:start>/<int:evaluation_period>/<int:forecast_horizon>/<int:forecast_frequency>",
        views.eval_chart_json,
        name="eval-chart-json-parametrized",
    ),
    # NETWORK CHART JSON
    path("chart/network/<int:furnace_id>", views.eval_chart, name="network-chart"),
    path("chart/network/json/<int:furnace_id>", views.network_chart_json, name="network-chart-json-default"),
    path(
        "chart/network/json/<int:furnace_id>/<int:start>/<int:evaluation_period>",
        views.network_chart_json,
        name="network-chart-json-parametrized",
    ),
    # EXPORT EVAL DATA
    path("chart/eval/export/<int:furnace_id>", views.export, name="export"),
    path(
        "chart/eval/export/excel/<int:furnace_id>",
        views.export_eval_data,
        name="export-eval-data-default",
    ),
    path(
        "chart/eval/export/excel/<int:furnace_id>/<int:start_date>/<int:end_date>",
        views.export_eval_data,
        name="export-eval-data-parametrized",
    ),
    # PCI CHART
    path("chart/pci/<int:furnace_id>", views.pci_chart, name="pci-chart"),
    path("chart/pci/<int:furnace_id>", views.pci_chart_json, name="pci-chart-json-default"),
    path(
        "chart/pci/<int:furnace_id>/<int:now>/<int:lookback_minutes>/<int:forecast_minutes>",
        views.pci_chart_json,
        name="pci-chart-json-parametrized",
    ),
    # BF 2D VISUALIZATION
    path("chart/visualization/<int:furnace_id>", views.bf_visualization, name="bf-visualization"),
    path(
        "chart/visualization/<int:furnace_id>",
        views.bf_visualization_json,
        name="bf-visualization-default",
    ),
    path(
        "chart/visualization/<int:furnace_id>/<int:start_date>/<int:end_date>",
        views.bf_visualization_json,
        name="bf-visualization-parametrized",
    ),
    # BF HEATER OPTIMIZER
    path("bf_heater_optimizer", views.bf_heater_optimizer, name="bf-heater-optimizer"),
    path(
        "bf_heater_optimizer/start_optimization",
        api_views.bf_heater_optimization_start,
        name="start-bf-heater-optimizer",
    ),
    # STEELSHOP CHART
    path("chart/steelshop/", views.steelshop_chart, name="steelshop-chart"),
    path("chart/steelshop/json", views.steelshop_chart_json, name="steelshop-chart-json-default"),
    path(
        "chart/steelshop/json/<int:now>/<int:lookback_minutes>/<int:offset_minutes>/",
        views.steelshop_chart_json,
        name="steelshop-chart-json-parametrized",
    ),
    # STOVES HEATING PHASES CHART
    path(
        "chart/stoves_heating_phases/<int:furnace_id>/",
        views.stoves_heating_phases,
        name="stoves-heating-phases-chart",
    ),
    path(
        "chart/stoves_heating_phases/<int:furnace_id>/",
        views.stoves_heating_phases_chart,
        name="stoves-heating-phases-chart-default",
    ),
    path(
        "chart/stoves_heating_phases/<int:furnace_id>/<int:start_date>/<int:end_date>/",
        views.stoves_heating_phases_chart,
        name="stoves-heating-phases-chart-parametrized",
    ),
    # STOVES CHART
    path("chart/stoves/<str:base64_safe_url_data>", views.stoves_chart, name="stoves-chart"),
    path("chart/stoves/json/<str:base64_safe_url_data>", views.stoves_chart_json, name="stoves-chart-json"),
]
