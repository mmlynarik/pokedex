from django.apps import AppConfig


class ModelfrontendConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "modelfrontend"
