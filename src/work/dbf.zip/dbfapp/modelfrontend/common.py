import logging
from typing import Dict, Optional, Tuple

import attrs
import pandas as pd
from django.core.exceptions import ObjectDoesNotExist
from modelbackend.common import calculate_prediction_result, get_blast_furnace_model, get_furnace_targets
from modelbackend.models import (
    BlastFurnaceEvalData,
    BlastFurnaceModelDefinition,
    BlastFurnacePredictionResult,
)

from dbfcore.dataset.hooks import DataSources, get_datasources_configured_with_env
from dbfcore.dataset.signals import SIGNAL_TO_SIGNAL_GROUP_MAP, get_signal_group_loader
from dbfcore.predictionmodel.inference import DummyBlastFurnaceModelResult, NeuralBlastFurnaceModelResult
from dbfcore.predictionmodel.protocols import BlastFurnaceModel, BlastFurnaceModelResult
from dbfcore.settings import FURNACE_IDS
from dbfcore.settings import LOCAL as LOCAL_TIMEZONE

logger = logging.getLogger(__name__)

GasType = str
ItemType = str


@attrs.define(frozen=True, slots=False)
class GasProperties:
    calorific_value: float
    price: float


@attrs.define(frozen=True, slots=False)
class GasBoundries:
    minimum: float
    maximum: float


@attrs.define(frozen=True, slots=False)
class BfHeatersSettings:
    is_on: bool
    temperature_aim_celsius: int
    mutable_constant: int
    min_heating_value: float


@attrs.define(frozen=True, slots=False)
class BfHeaters:
    settings: BfHeatersSettings
    gas_boundries: Dict[GasType, GasBoundries]


@attrs.define(frozen=True, slots=False)
class BfOptimizerInput:
    gas_properties: Dict[GasType, GasProperties]
    # TODO rename to stoves
    heaters: Tuple[BfHeaters, ...]


@attrs.define(frozen=True, slots=False)
class BfHeaterOptimizationResult:
    heaters: Tuple[Dict[ItemType, float], ...]


@attrs.define(frozen=True, slots=False)
class ForecastsChartDataForTarget:
    target_id: str
    target_signal_name: str
    forecasts: pd.DataFrame


@attrs.define(frozen=True, slots=False)
class ForecastsWithHistoryChartDataForTarget(ForecastsChartDataForTarget):
    target_history: pd.DataFrame
    probe_history: pd.DataFrame


@attrs.define(frozen=True, slots=False)
class LiveForecastChartDataForTarget(ForecastsWithHistoryChartDataForTarget):
    furnace_targets: pd.DataFrame


@attrs.define(frozen=True, slots=False)
class AvailabilityChartData:
    data_availability: list[pd.DataFrame]


@attrs.define(frozen=True, slots=False)
class EvalChartDataForTarget(ForecastsWithHistoryChartDataForTarget):
    tapping_times: pd.DataFrame


@attrs.define(frozen=True, slots=False)
class SteelshopChartData:
    forecasts: pd.DataFrame
    heat_data: pd.DataFrame


def get_results_from_db(
    model_definition: BlastFurnaceModelDefinition,
    start: pd.Timestamp,
    end: pd.Timestamp,
    forecast_frequency: pd.Timedelta,
    calculate_if_missing: bool = False,
) -> list[BlastFurnacePredictionResult]:
    rng = pd.date_range(start, end, freq=forecast_frequency, inclusive="left").to_pydatetime()
    if not calculate_if_missing:
        return list(
            BlastFurnacePredictionResult.objects.filter(model_definition=model_definition, calc_time__in=rng)
        )
    results = []
    for calc_time in rng:
        result = get_result_from_db(model_definition, pd.Timestamp(calc_time))
        if result:
            results.append(result)
    return results


def get_result_from_db(
    model_definition: BlastFurnaceModelDefinition, calc_time: pd.Timestamp
) -> Optional[BlastFurnacePredictionResult]:
    model = get_blast_furnace_model(model_definition)
    try:
        result_db = BlastFurnacePredictionResult.objects.get(
            model_definition=model_definition, calc_time=calc_time
        )
    except ObjectDoesNotExist:
        logger.info(
            f"Prediction not found in database for {calc_time} for {model_definition.name}, generating on the fly"
        )
        datasources = get_datasources_configured_with_env()
        try:
            result_db = calculate_prediction_result(model, model_definition, calc_time, datasources)
        except Exception:
            logger.warning("On the fly model calculation failed", exc_info=True)
            return None

    return result_db


def get_blast_furnace_model_result(
    result_db: BlastFurnacePredictionResult, model: BlastFurnaceModel
) -> BlastFurnaceModelResult:
    model_definition = result_db.model_definition
    calc_time = pd.Timestamp(result_db.calc_time)
    if model_definition.neural_model_def:
        return NeuralBlastFurnaceModelResult.from_bytes(
            result_db.encoded,
            calc_time,
            time_resolution=model_definition.neural_model_def.time_resolution,
            value_resolution=model_definition.neural_model_def.value_resolution,
            prediction_model=model.prediction_model,  # type: ignore
            input_signals=model.input_signals,  # type: ignore
            target_signal_name=model.target_signal["name"],  # type: ignore
        )
    elif model_definition.dummy_model_def:
        return DummyBlastFurnaceModelResult.from_bytes(
            result_db.encoded, calc_time, model_definition.dummy_model_def.target_signal
        )
    raise ValueError(
        f"Model definition {model_definition} is not configured properly. At least one model config field must be non-null"
    )


def get_furnace_targets_for_chart(
    furnace_id: int, start: pd.Timestamp, now: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    targets = get_furnace_targets(furnace_id, start, now)
    if not targets:
        raise ValueError(
            f"No furnace targets found in the database for furnace {furnace_id}. Enter values into database using Django Admin and refresh the page."
        )
    targets_df = pd.DataFrame(targets).sort_values("valid_asof").reset_index(drop=True)
    targets_df.loc[0, "valid_asof"] = start
    chart_end_obs = pd.DataFrame(targets_df.iloc[-1]).T
    chart_end_obs["valid_asof"] = end
    targets_df = pd.concat([targets_df, chart_end_obs], axis=0, ignore_index=True)
    targets_df["valid_asof"] = targets_df["valid_asof"].apply(lambda x: x.tz_convert(LOCAL_TIMEZONE))
    return targets_df


def get_tapping_times(tapping_events: pd.DataFrame) -> pd.DataFrame:
    signal_name = tapping_events.columns[0]
    tapping_times = tapping_events[tapping_events[signal_name].isin([0, 2])]
    tapping_times = tapping_times.copy()
    tapping_times[signal_name] = tapping_times[signal_name].map({0: "start", 2: "end"})
    return tapping_times


def get_signal_history(
    signal: str, start: pd.Timestamp, end: pd.Timestamp, datasources: DataSources
) -> pd.DataFrame:
    loader = get_signal_group_loader(SIGNAL_TO_SIGNAL_GROUP_MAP[signal], datasources)
    history_df = loader(start, end)

    if signal not in history_df:
        history_df = pd.DataFrame(columns=[signal], index=[start, end])

    return history_df


def get_raw_si_forecasts(start: pd.Timestamp, end: pd.Timestamp, offset: pd.Timedelta) -> pd.DataFrame:
    offset_start = (start - offset).to_pydatetime()
    offset_end = (end - offset).to_pydatetime()

    nowcasts_with_offset = []
    for furnace_id in FURNACE_IDS:
        bf_eval_data = BlastFurnaceEvalData.objects.filter(
            calc_time__range=[offset_start, offset_end], furnace_id=furnace_id
        )
        bf_nowcasts = pd.Series(
            [d.forecast_0 for d in bf_eval_data],
            index=[pd.Timestamp(d.calc_time) + offset for d in bf_eval_data],
            name=f"bf{furnace_id}",
        )
        if bf_nowcasts.empty:
            bf_nowcasts.index = bf_nowcasts.index.astype("datetime64[ns, UTC]")

        nowcasts_with_offset.append(bf_nowcasts)

    nowcasts_with_offset_df = pd.concat(nowcasts_with_offset, axis=1)
    return nowcasts_with_offset_df
