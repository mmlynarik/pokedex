import pandas as pd
import plotly.graph_objects as go
from modelfrontend.common import EvalChartDataForTarget
from modelfrontend.visualization.live_chart import forecasts_chart


def get_forecast_fmt(signal_name: str) -> str:
    return ".0f" if "hotmetalafterslag_temp_C" in signal_name else ".2f"


def add_vrect_to_fig(
    fig: go.Figure,
    tapping_start: pd.Timestamp,
    tapping_end: pd.Timestamp,
    target_signal_name: str,
    forecasts: pd.DataFrame | None,
    history: pd.DataFrame | None,
    target_idx: int,
) -> go.Figure:
    annotation = ""
    if forecasts is not None and history is not None:
        mean_forecast = forecasts[(forecasts.index >= tapping_start) & (forecasts.index <= tapping_end)][
            "expected_value"
        ].mean()
        real = history[target_signal_name].loc[tapping_start:tapping_end].mean()
        annotation = f"""AVG FORECAST/REAL: {mean_forecast:{get_forecast_fmt(target_signal_name)}}/{real:{get_forecast_fmt(target_signal_name)}}"""

    fig.add_shape(
        go.layout.Shape(
            type="rect",
            yref="paper",
            xref="x",
            x0=tapping_start,
            y0=0 if target_idx == 2 else 0.54,
            x1=tapping_end,
            y1=0.46 if target_idx == 2 else 1,
            fillcolor="green",
            opacity=0.14,
            line_width=0,
            label=dict(text=f"{annotation}", font=dict(size=10, weight="bold"), textposition="top center"),
        ),
    )
    return fig


def add_shaded_tapping_periods(
    fig: go.Figure,
    eval_chart_data: list[EvalChartDataForTarget],
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> go.Figure:
    tapping_times = eval_chart_data[0].tapping_times
    for target_idx, eval_chart_data_for_target in enumerate(eval_chart_data, start=1):
        target_signal_name = eval_chart_data_for_target.target_signal_name
        forecasts = eval_chart_data_for_target.forecasts
        history = eval_chart_data_for_target.target_history
        for idx, (timestamp, row) in enumerate(eval_chart_data_for_target.tapping_times.iterrows()):
            if row.item() == "end" and idx != 0:
                continue
            elif row.item() == "end" and idx == 0:
                fig = add_vrect_to_fig(fig, start, timestamp, target_signal_name, None, None, target_idx)
            elif row.item() == "start" and idx == len(tapping_times) - 1:
                fig = add_vrect_to_fig(fig, timestamp, end, target_signal_name, None, None, target_idx)
            else:
                next_timestamp = tapping_times.iloc[idx + 1].name
                fig = add_vrect_to_fig(
                    fig, timestamp, next_timestamp, target_signal_name, forecasts, history, target_idx
                )

    return fig


def get_traces_data_for_figure(eval_chart_data: list[EvalChartDataForTarget]) -> list[go.Trace]:
    traces_data = []
    for idx, eval_chart_data_for_target in enumerate(eval_chart_data, start=1):
        forecasts_fig = forecasts_chart(eval_chart_data_for_target, idx)
        for trace in forecasts_fig.data:
            trace.yaxis = f"y{idx}"
            traces_data.append(trace)

    return traces_data


def update_layout(fig: go.Figure, start: pd.Timestamp, end: pd.Timestamp, num_targets: int) -> go.Figure:
    fig.update_layout(
        grid=dict(rows=num_targets, columns=1, ygap=0.14),
        hovermode="x",
        height=640,
        hoversubplots="axis",
        legend=dict(orientation="h", yanchor="bottom", y=1.06, xanchor="right", x=1),
        margin=dict(r=5, b=1, l=5),
        **{
            f"xaxis{idx}": dict(
                type="date",
                range=[start, end],
                maxallowed=end,
                dtick=60 * 60 * 1000,  # every 1 hour
            )
            for idx in range(1, num_targets + 1)
        },
    )
    return fig


def add_annotations(fig: go.Figure, eval_chart_data: list[EvalChartDataForTarget]) -> go.Figure:
    for idx, eval_chart_data_for_target in enumerate(eval_chart_data, start=1):
        fig.add_annotation(
            text=eval_chart_data_for_target.target_id,
            xref="paper",
            yref="paper",
            x=0,
            y=1.06 if idx == 1 else 0.5,
            showarrow=False,
            font=dict(size=18),
        )
    return fig


def get_eval_chart_figure(
    eval_chart_data: list[EvalChartDataForTarget], start: pd.Timestamp, end: pd.Timestamp
) -> go.Figure:
    traces_data = get_traces_data_for_figure(eval_chart_data)

    fig = go.Figure(data=traces_data)
    fig = add_annotations(fig, eval_chart_data)
    fig = add_shaded_tapping_periods(fig, eval_chart_data, start, end)
    fig = update_layout(fig, start, end, len(eval_chart_data))

    return fig
