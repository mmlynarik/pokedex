import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def create_stoves_heating_phases_chart(heating_phases_df: pd.DataFrame) -> go.Figure:
    heating_phases_df["stove_number"] = heating_phases_df["heating_phase_id"].str.split("_").str[1]

    fig = px.timeline(
        heating_phases_df,
        x_start="start",
        x_end="end",
        y="stove_number",
        category_orders={"stove_number": ["11", "12", "13", "14"]},
    )
    fig.update_traces(marker_color="#cc3333")
    fig.update_layout(xaxis_title="Time", yaxis_title="Stove Number")

    return fig
