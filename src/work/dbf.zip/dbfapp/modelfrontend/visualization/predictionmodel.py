import logging

import pandas as pd
import plotly.graph_objects as go
from modelfrontend.common import (
    LOCAL_TIMEZONE,
    AvailabilityChartData,
    EvalChartDataForTarget,
    LiveForecastChartDataForTarget,
    SteelshopChartData,
    get_signal_history,
)
from modelfrontend.visualization.eval_chart import get_eval_chart_figure
from modelfrontend.visualization.live_chart import (
    get_availability_chart_figure,
    get_liveforecast_chart_figure,
)
from modelfrontend.visualization.pci_chart import get_pci_chart
from modelfrontend.visualization.steelshop_chart import get_steelshop_chart_figure

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.predictionmodel.inference import generate_synthetic_future_data
from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult

logger = logging.getLogger(__name__)


def convert_df_index_to_local_tz(df: pd.DataFrame, tz: str):
    return df.assign(time=lambda df: df.index.tz_convert(tz)).reset_index(drop=True).set_index("time")


def create_liveforecast_chart(
    results: dict[str, BlastFurnaceModelResult],
    targets_history: dict[str, pd.DataFrame],
    probes_history: dict[str, pd.DataFrame],
    furnace_targets: pd.DataFrame,
    lookback: pd.Timedelta,
    forecast: pd.Timedelta,
) -> go.Figure:
    now = list(results.values())[0].calc_time
    start = now - lookback
    end = now + forecast

    live_chart_data: list[LiveForecastChartDataForTarget] = []
    for target_id, result in results.items():
        forecasted_quantiles = result.get_predicted_quantiles([0.05, 0.5, 0.95])
        forecasted_expected_values = result.get_expected_values()
        forecasts = pd.concat([forecasted_quantiles, forecasted_expected_values], axis=1)
        target_history = targets_history[target_id]

        if target_id == "TEMPERATURE":
            probe_history = pd.DataFrame(
                columns=["bf2_hotmetalsi_pi_chem_pct", "bf2_hotmetalsi_pi_probe_chem_pct"]
            )
        else:
            probe_history = convert_df_index_to_local_tz(probes_history[target_id], LOCAL_TIMEZONE)

        live_chart_data.append(
            LiveForecastChartDataForTarget(
                target_id,
                result.target_signal_name,
                convert_df_index_to_local_tz(forecasts, LOCAL_TIMEZONE),
                convert_df_index_to_local_tz(target_history, LOCAL_TIMEZONE),
                probe_history,
                furnace_targets[["valid_asof", target_id.lower()]],
            )
        )

    return get_liveforecast_chart_figure(
        live_chart_data,
        start.tz_convert(LOCAL_TIMEZONE),
        end.tz_convert(LOCAL_TIMEZONE),
        now.tz_convert(LOCAL_TIMEZONE),
    )


def create_availability_chart(
    results: dict[str, BlastFurnaceModelResult],
    lookback: pd.Timedelta,
    forecast: pd.Timedelta,
) -> go.Figure:
    now = list(results.values())[0].calc_time
    start = now - lookback
    end = now + forecast
    live_chart_data = AvailabilityChartData([result.get_data_availability() for result in results.values()])

    return get_availability_chart_figure(
        live_chart_data,
        start.tz_convert(LOCAL_TIMEZONE),
        end.tz_convert(LOCAL_TIMEZONE),
        now.tz_convert(LOCAL_TIMEZONE),
    )


def create_eval_chart(
    results: dict[str, list[BlastFurnaceModelResult]],
    tapping_times: pd.DataFrame,
    targets_history: dict[str, pd.DataFrame],
    probes_history: dict[str, pd.DataFrame],
    evaluation_period: pd.Timedelta,
    forecast_horizon: pd.Timedelta,
) -> go.Figure:
    first_result_calc_time = list(results.values())[0][0].calc_time
    start = first_result_calc_time + forecast_horizon
    end = start + evaluation_period

    eval_chart_data: list[EvalChartDataForTarget] = []
    for target_id, results_for_target in results.items():
        forecasted_quantiles = pd.concat(
            [r.get_predicted_quantiles([0.05, 0.5, 0.95], forecast_horizon) for r in results_for_target]
        )
        forecasted_expected_values = pd.Series(
            [r.get_expected_value(forecast_horizon) for r in results_for_target],
            name="expected_value",
            index=[r.calc_time + forecast_horizon for r in results_for_target],
        )
        forecasts = pd.concat([forecasted_quantiles, forecasted_expected_values], axis=1)
        target_history = targets_history[target_id]

        if target_id == "TEMPERATURE":
            probe_history = pd.DataFrame(
                columns=["bf2_hotmetalsi_pi_chem_pct", "bf2_hotmetalsi_pi_probe_chem_pct"]
            )
        else:
            probe_history = convert_df_index_to_local_tz(probes_history[target_id], LOCAL_TIMEZONE)

        eval_chart_data.append(
            EvalChartDataForTarget(
                target_id,
                results_for_target[0].target_signal_name,
                convert_df_index_to_local_tz(forecasts, LOCAL_TIMEZONE),
                convert_df_index_to_local_tz(target_history, LOCAL_TIMEZONE),
                # convert_df_index_to_local_tz(probe_history, LOCAL_TIMEZONE),
                probe_history,
                convert_df_index_to_local_tz(tapping_times, LOCAL_TIMEZONE),
            )
        )
    return get_eval_chart_figure(
        eval_chart_data,
        start.tz_convert(LOCAL_TIMEZONE),
        end.tz_convert(LOCAL_TIMEZONE),
    )


def create_pci_chart(
    now: pd.Timestamp,
    start: pd.Timestamp,
    end: pd.Timestamp,
    furnace_id: int,
) -> go.Figure:
    datasources = get_datasources_configured_with_env()
    signal_name = f"bf{furnace_id}_hotblastpci_flow_kgh"
    history_data = get_signal_history(signal_name, start, now, datasources)

    future_data = generate_synthetic_future_data(history_data[[signal_name]], now, end)
    future_plus_100 = future_data + 1000
    future_minus_100 = future_data - 1000

    return get_pci_chart(
        convert_df_index_to_local_tz(history_data, LOCAL_TIMEZONE),
        convert_df_index_to_local_tz(future_data, LOCAL_TIMEZONE),
        convert_df_index_to_local_tz(future_plus_100, LOCAL_TIMEZONE),
        convert_df_index_to_local_tz(future_minus_100, LOCAL_TIMEZONE),
        signal_name,
        now.tz_convert(LOCAL_TIMEZONE),
        start.tz_convert(LOCAL_TIMEZONE),
        end.tz_convert(LOCAL_TIMEZONE),
    )


def create_steelshop_chart(
    forecasts: pd.DataFrame,
    heat_data: pd.DataFrame,
    start: pd.Timestamp,
    end: pd.Timestamp,
    now: pd.Timestamp,
) -> go.Figure:
    data = SteelshopChartData(
        convert_df_index_to_local_tz(forecasts, LOCAL_TIMEZONE),
        convert_df_index_to_local_tz(heat_data, LOCAL_TIMEZONE),
    )
    return get_steelshop_chart_figure(
        data,
        start.tz_convert(LOCAL_TIMEZONE),
        end.tz_convert(LOCAL_TIMEZONE),
        now.tz_convert(LOCAL_TIMEZONE),
    )
