import pandas as pd
import plotly.graph_objects as go
from modelfrontend.common import SteelshopChartData


def forecasts_chart(data: SteelshopChartData) -> go.Figure:
    raw_forecasts = data.forecasts
    heat_data = data.heat_data
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            name="BF1 raw forecast",
            x=raw_forecasts.index,
            y=raw_forecasts["bf1"],
            mode="lines",
            line=dict(width=3, color="rgba(250, 0, 0, 0.5)"),
            showlegend=True,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="BF2 raw forecast",
            x=raw_forecasts.index,
            y=raw_forecasts["bf2"],
            line=dict(width=3, color="rgba(0, 128, 128, 0.5)"),
            mode="lines",
            showlegend=True,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="BF3 raw forecast",
            x=raw_forecasts.index,
            y=raw_forecasts["bf3"],
            line=dict(width=3, color="rgba(106, 90, 205, 0.5)"),
            mode="lines",
            showlegend=True,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Minimum forecast",
            x=heat_data.index,
            y=heat_data["minimum_forecast"],
            mode="markers",
            marker={"size": 15, "symbol": "x", "color": "rgb(31, 119, 180)"},
            showlegend=True,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Proportional forecast",
            x=heat_data.index,
            y=heat_data["proportional_forecast"],
            mode="markers",
            marker={"size": 15, "symbol": "x", "color": "rgb(161, 119, 180)"},
            showlegend=True,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="real",
            x=heat_data.index,
            y=heat_data["si_pct"],
            mode="markers",
            marker={"size": 15, "symbol": "x", "color": "rgb(223, 61, 136)"},
            showlegend=True,
        )
    )

    return fig


def add_steelshop_chart_annotations(fig: go.Figure, now: pd.Timestamp) -> go.Figure:
    fig.add_annotation(
        text="SILICON",
        xref="paper",
        yref="paper",
        x=0,
        y=1.06,
        showarrow=False,
        font=dict(size=18),
    )
    fig.add_annotation(
        x=now,
        y=1.06,
        yref="paper",
        text="now",
        font_color="red",
        showarrow=False,
    )
    return fig


def add_vline(fig: go.Figure, now: pd.Timestamp) -> go.Figure:
    fig.add_shape(
        go.layout.Shape(
            type="line",
            yref="paper",
            xref="x",
            x0=now,
            y0=0,
            x1=now,
            y1=1,
            line=dict(color="red", width=3),
        ),
    )
    return fig


def get_traces_data_for_steelshop_chart_figure(
    steelshop_chart_data: SteelshopChartData,
) -> list[go.Trace]:
    traces_data = []
    forecasts_fig = forecasts_chart(steelshop_chart_data)
    for trace in forecasts_fig.data:
        trace.yaxis = "y1"
        traces_data.append(trace)

    return traces_data


def update_steelshopchart_layout(
    fig: go.Figure,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> go.Figure:
    fig.update_layout(
        grid=dict(rows=1, columns=1, ygap=0.14),
        hovermode="x",
        height=630,
        hoversubplots="axis",
        legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="right", x=1),
        margin=dict(r=5, b=1, l=5),
        xaxis1=dict(
            type="date",
            range=[start, end],
            maxallowed=end,
            dtick=60 * 60 * 1000,  # every 1 hour
        ),
    )
    return fig


def get_steelshop_chart_figure(
    steelshop_chart_data: SteelshopChartData,
    start: pd.Timestamp,
    end: pd.Timestamp,
    now: pd.Timestamp,
) -> go.Figure:
    traces_data = get_traces_data_for_steelshop_chart_figure(steelshop_chart_data)
    fig = go.Figure(data=traces_data)
    fig = add_steelshop_chart_annotations(fig, now)
    fig = add_vline(fig, now)
    update_steelshopchart_layout(fig, start, end)

    return fig
