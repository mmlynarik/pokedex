from typing import TypedDict, Union

import attrs
import numpy as np


@attrs.define(frozen=True, slots=False)
class BFScheme:
    x0_zero_stockline: float
    x1_zero_stockline: float
    x_zero_stockline: int
    y_zero_stockline: float
    x_stockrod_annotation: int
    x0_stockrod_shape: int
    x1_stockrod_shape: float
    outer_shape_path: str
    inner_shape_path: str
    left_tuyere_path: str
    right_tuyere_path: str
    left_iron_notch_path: str
    right_iron_notch_path: str
    cx_left_tuyere: float
    cy_left_tuyere: float
    cx_right_tuyere: float
    cy_right_tuyere: float
    outer_radius_tuyere: int
    inner_radius_tuyere: float
    x_iron_notch_annotation: int
    y_iron_notch_annotation: float
    inner_shape_key_points: dict[float, tuple[float, float]]
    x0_fixed_line: float
    x1_fixed_line: float
    y_fixed_line: float


bf1_scheme = BFScheme(
    x0_zero_stockline=2.77,
    x1_zero_stockline=10.17,
    x_zero_stockline=0,
    y_zero_stockline=37.3,
    x_stockrod_annotation=15,
    x0_stockrod_shape=0,
    x1_stockrod_shape=13.0,
    outer_shape_path="""M 5.14 41.32 L 2.32 38.32 L 1.87 36.96 L 1.87 35.47 L 0.8445 25.725
                            L 0.115 17.825 L 0.115 16.4 L 0.945 13.7 L 0 8.18 L 0 0 L 12.94 0 
                            L 12.94 8.18 L 11.995 13.7 L 12.825 16.4 L 12.825 17.825 L 12.0955 25.725 
                            L 11.07 35.47 L 11.07 36.96 L 10.620 38.32 L 7.8 41.32 Z""",
    inner_shape_path="""M 5.14 41.19 L 2.77 38.65 L 2.77 35.47 L 1.2495 25.785 L 0.52 17.825 
                            L 0.52 16.4 L 1.47 13.7 L 1.47 6.826 L 11.47 6.826 L 11.47 13.7 
                            L 12.42 16.4 L 12.42 17.825 L 11.6905 25.785 L 10.17 35.47 
                            L 10.17 38.65 L 7.8 41.19 Z""",
    left_tuyere_path="""M 1.7 12.3 L 1.5 12.3 L 0.6 12.1 L 0.6 12.3 L -0.8 12.3
                        L -0.8 12.5 L -0.7 12.5 L -1.5 13.705 L -2 13.9 L -1.08 14.49 
                        L -1.08 13.95 L -0.4 12.7 L -0.2 12.6 L 0.6 12.6 L 0.6 12.8 
                        L 1.5 12.6 L 1.7 12.6 Z""",
    right_tuyere_path="""M 11.2 12.3 L 11.4 12.3 L 12.35 12.1 L 12.35 12.3 L 13.75 12.3
                        L 13.75 12.5 L 13.65 12.5 L 14.5 13.705 L 15 13.9 L 14.08 14.49 
                        L 14.08 13.95 L 13.4 12.7 L 13.15 12.6 L 12.35 12.6 L 12.35 12.8 
                        L 11.45 12.6 L 11.2 12.6 Z""",
    left_iron_notch_path="""M 1.6 8.34 L 0.09 8.7 L 0.055 8.5 L -0.2 8.55 L -0.07 9.35 
                            L 0.19 9.3 L 0.155 9.1 L 1.6 8.74 Z""",
    right_iron_notch_path="""M 12.852 8.7 L 11.35 8.34 L 11.35 8.74 L 12.787 9.1 
                            L 12.75 9.3 L 13.01 9.35 L 13.16 8.55 L 12.89 8.5 Z""",
    cx_left_tuyere=-2.0,
    cy_left_tuyere=14.9,
    cx_right_tuyere=15.0,
    cy_right_tuyere=14.9,
    outer_radius_tuyere=1,
    inner_radius_tuyere=0.8,
    x_iron_notch_annotation=-1,
    y_iron_notch_annotation=8.9,
    inner_shape_key_points={
        41.19: (5.14, 7.8),
        38.65: (2.77, 10.17),
        35.47: (2.77, 10.17),
        25.785: (1.2495, 11.6905),
        17.825: (0.52, 12.42),
        16.4: (0.52, 12.42),
        13.7: (1.47, 11.47),
        6.826: (1.47, 11.47),
    },
    x0_fixed_line=0.52,
    x1_fixed_line=12.42,
    y_fixed_line=17.805,
)


bf2_scheme = BFScheme(
    x0_zero_stockline=3.056,
    x1_zero_stockline=11.306,
    x_zero_stockline=0,
    y_zero_stockline=38.4,
    x_stockrod_annotation=15,
    x0_stockrod_shape=0,
    x1_stockrod_shape=14.2,
    outer_shape_path="""M 5.681 43.02 L 2.556 39.97 L 2.211 38.77 L 2.211 37 L 0.436 21.73
                            L 0.171 18.695 L 0.171 17 L 1.111 13.9 L 0 8.3 L 0 0 L 14.362 0
                            L 14.362 8.3 L 13.251 13.9 L 14.191 17 L 14.191 18.695 L 13.926 21.73
                            L 12.151 37 L 12.151 38.77 L 11.806 39.97 L 8.681 43.02 Z""",
    inner_shape_path="""M 5.681 42.89 L 3.056 40.32 L 3.056 37 L 0.816 21.73 L 0.551 18.695 
                            L 0.551 17 L 1.781 13.9 L 1.781 7.559 L 12.581 7.559 L 12.581 13.9
                            L 13.881 17 L 13.881 18.695 L 13.546 21.73 L 11.306 37 L 11.306 40.32
                            L 8.681 42.89 Z""",
    left_tuyere_path="""M 1.9 12.8 L 1.7 12.8 L 0.8 12.6 L 0.8 12.8 L -0.6 12.8
                        L -0.6 13 L -0.5 13 L -1.3 14.205 L -1.8 14.4 L -0.88 14.99 
                        L -0.88 14.45 L -0.2 13.2 L 0 13.1 L 0.8 13.1 L 0.8 13.3 
                        L 1.7 13.1 L 1.9 13.1 Z""",
    right_tuyere_path="""M 12.45 12.8 L 12.65 12.8 L 13.6 12.6 L 13.6 12.8 L 15 12.8
                        L 15 13 L 14.9 13 L 15.75 14.205 L 16.25 14.4 L 15.33 14.99 
                        L 15.33 14.45 L 14.65 13.2 L 14.4 13.1 L 13.6 13.1 L 13.6 13.3 
                        L 12.7 13.1 L 12.45 13.1 Z""",
    left_iron_notch_path="""M 1.89 8.84 L 0.18 9.2 L 0.135 9 L -0.11 9.05 L 0.02 9.85 
                                L 0.28 9.8 L 0.245 9.6 L 1.89 9.24 Z""",
    right_iron_notch_path="""M 14.172 9.2 L 12.47 8.84 L 12.47 9.24 L 14.107 9.6 
                                L 14.07 9.8 L 14.33 9.85 L 14.48 9.05 L 14.21 9 Z""",
    cx_left_tuyere=-1.8,
    cy_left_tuyere=15.4,
    cx_right_tuyere=16.25,
    cy_right_tuyere=15.4,
    outer_radius_tuyere=1,
    inner_radius_tuyere=0.8,
    x_iron_notch_annotation=-1,
    y_iron_notch_annotation=9.4,
    inner_shape_key_points={
        42.89: (5.681, 8.681),
        40.32: (3.056, 11.306),
        37.0: (3.056, 11.306),
        21.73: (0.816, 13.546),
        18.695: (0.551, 13.881),
        17.0: (0.551, 13.881),
        13.9: (1.781, 12.581),
        7.559: (1.781, 12.581),
    },
    x0_fixed_line=0.551,
    x1_fixed_line=13.881,
    y_fixed_line=18.71,
)


bf3_scheme = BFScheme(
    x0_zero_stockline=2.298,
    x1_zero_stockline=9.698,
    x_zero_stockline=0,
    y_zero_stockline=35.75,
    x_stockrod_annotation=14,
    x0_stockrod_shape=0,
    x1_stockrod_shape=12.0,
    outer_shape_path="""M 4.648 40.9 L 1.648 37.74 L 1.248 36.54 L 1.248 35.05 L 0.318 25.39
                            L -0.302 19.59 L -0.302 17.635 L 0.198 14.273 L 0 0 L 11.996 0
                            L 11.798 14.273 L 12.298 17.635 L 12.298 19.59 L 11.678 25.39 L 10.748 35.05
                            L 10.748 36.54 L 10.348 37.74 L 7.348 40.9 Z""",
    inner_shape_path="""M 4.648 40.77 L 2.298 38.3 L 2.298 35.05 L 0.818 25.39 L 0.198 19.59
                            L 0.198 17.635 L 0.605 14.273 L 0.998 13 L 0.998 6.826 L 10.998 6.826
                            L 10.998 13 L 11.391 14.273 L 11.798 17.635 L 11.798 19.59 L 11.178 25.39
                            L 9.698 35.05 L 9.698 38.3 L 7.348 40.77 Z""",
    left_tuyere_path="""M 1.15 12.3 L 0.95 12.3 L 0.05 12.1 L 0.05 12.3 L -1.35 12.3
                        L -1.35 12.5 L -1.25 12.5 L -2.05 13.705 L -2.55 13.9 L -1.63 14.49 
                        L -1.63 13.95 L -0.95 12.7 L -0.75 12.6 L 0.05 12.6 L 0.05 12.8 
                        L 0.95 12.6 L 1.15 12.6 Z""",
    right_tuyere_path="""M 10.8 12.3 L 11 12.3 L 11.95 12.1 L 11.95 12.3 L 13.35 12.3
                        L 13.35 12.5 L 13.25 12.5 L 14.1 13.705 L 14.6 13.9 L 13.68 14.49 
                        L 13.68 13.95 L 13 12.7 L 12.75 12.6 L 11.95 12.6 L 11.95 12.8 
                        L 11.05 12.6 L 10.8 12.6 Z""",
    left_iron_notch_path="""M 1.1 8.34 L 0.12 8.7 L 0.1175 8.5 L -0.15 8.5 L -0.15 9.35 
                                L 0.13 9.35 L 0.125 9.1 L 1.1 8.74 Z""",
    right_iron_notch_path="""M 11.88 8.7 L 10.9 8.34 L 10.9 8.74 L 11.87 9.1 
                                L 11.87 9.35 L 12.16 9.35 L 12.16 8.5 L 11.88 8.5 Z""",
    cx_left_tuyere=-2.55,
    cy_left_tuyere=14.9,
    cx_right_tuyere=14.6,
    cy_right_tuyere=14.9,
    outer_radius_tuyere=1,
    inner_radius_tuyere=0.8,
    x_iron_notch_annotation=-1,
    y_iron_notch_annotation=8.9,
    inner_shape_key_points={
        40.77: (4.648, 7.348),
        38.3: (2.298, 9.698),
        35.05: (2.298, 9.698),
        25.39: (0.818, 11.178),
        19.59: (0.198, 11.798),
        17.635: (0.198, 11.798),
        14.273: (0.605, 11.391),
        13.0: (0.998, 10.998),
        6.826: (0.998, 10.998),
    },
    x0_fixed_line=0.198,
    x1_fixed_line=11.798,
    y_fixed_line=19.506,
)


def get_bf_scheme(furnace_id: int) -> BFScheme:
    if furnace_id == 1:
        return bf1_scheme
    elif furnace_id == 2:
        return bf2_scheme
    elif furnace_id == 3:
        return bf3_scheme
    else:
        raise Exception(f"Invalid furnace_id: {furnace_id}")


class Annotation(TypedDict):
    x: int
    y: float
    text: str
    showarrow: bool
    font: dict[str, Union[int, str]]
    xanchor: str


class CircleShape(TypedDict):
    type: str
    xref: str
    yref: str
    x0: float
    y0: float
    x1: float
    y1: float
    line: dict[str, Union[int, str]]
    fillcolor: str


class LineShape(TypedDict):
    type: str
    x0: float
    x1: float
    y0: float
    y1: float
    line: dict[str, Union[int, str]]


class PathShape(TypedDict):
    type: str
    path: str
    line: dict[str, Union[int, str]]
    fillcolor: str


def create_zero_stockline_annotation(bf_scheme: BFScheme) -> Annotation:
    return {
        "x": bf_scheme.x_zero_stockline,
        "y": bf_scheme.y_zero_stockline,
        "text": "Zero Stockline",
        "showarrow": False,
        "font": dict(size=14, color="red"),
        "xanchor": "right",
    }


def create_stockrod_annotation(
    bf_scheme: BFScheme, stockrod_y_position: float, stockrod_value: float
) -> Annotation:
    return {
        "x": bf_scheme.x_stockrod_annotation,
        "y": stockrod_y_position,
        "text": f"Distance: {stockrod_value:.3f} m",
        "showarrow": False,
        "font": dict(size=14, color="blue"),
        "xanchor": "left",
    }


def create_gap_phase_iron_annotation(bf_scheme: BFScheme) -> Annotation:
    return {
        "x": bf_scheme.x_iron_notch_annotation,
        "y": bf_scheme.y_iron_notch_annotation,
        "text": "Gap phase 0 - IRON",
        "showarrow": False,
        "font": dict(size=14, color="orange"),
        "xanchor": "right",
    }


def create_gap_phase_slag_annotation(bf_scheme: BFScheme) -> Annotation:
    return {
        "x": bf_scheme.x_iron_notch_annotation,
        "y": bf_scheme.y_iron_notch_annotation,
        "text": "Gap phase 1 - SLAG",
        "showarrow": False,
        "font": dict(size=14, color="orange"),
        "xanchor": "right",
    }


def create_gap_phase_pause_annotation(bf_scheme: BFScheme) -> Annotation:
    return {
        "x": bf_scheme.x_iron_notch_annotation,
        "y": bf_scheme.y_iron_notch_annotation,
        "text": "Gap phase 2 - PAUSE",
        "showarrow": False,
        "font": dict(size=14, color="grey"),
        "xanchor": "right",
    }


def create_shape_of_inner_circle_of_left_tuyere(bf_scheme: BFScheme) -> CircleShape:
    return {
        "type": "circle",
        "xref": "x",
        "yref": "y",
        "x0": bf_scheme.cx_left_tuyere - bf_scheme.inner_radius_tuyere,
        "y0": bf_scheme.cy_left_tuyere - bf_scheme.inner_radius_tuyere,
        "x1": bf_scheme.cx_left_tuyere + bf_scheme.inner_radius_tuyere,
        "y1": bf_scheme.cy_left_tuyere + bf_scheme.inner_radius_tuyere,
        "line": dict(color="black", width=1),
        "fillcolor": "grey",
    }


def create_shape_of_inner_circle_of_right_tuyere(bf_scheme: BFScheme) -> CircleShape:
    return {
        "type": "circle",
        "xref": "x",
        "yref": "y",
        "x0": bf_scheme.cx_right_tuyere - bf_scheme.inner_radius_tuyere,
        "y0": bf_scheme.cy_right_tuyere - bf_scheme.inner_radius_tuyere,
        "x1": bf_scheme.cx_right_tuyere + bf_scheme.inner_radius_tuyere,
        "y1": bf_scheme.cy_right_tuyere + bf_scheme.inner_radius_tuyere,
        "line": dict(color="black", width=1),
        "fillcolor": "grey",
    }


def create_shape_of_outer_circle_of_left_tuyere(bf_scheme: BFScheme) -> CircleShape:
    return {
        "type": "circle",
        "xref": "x",
        "yref": "y",
        "x0": bf_scheme.cx_left_tuyere - bf_scheme.outer_radius_tuyere,
        "y0": bf_scheme.cy_left_tuyere - bf_scheme.outer_radius_tuyere,
        "x1": bf_scheme.cx_left_tuyere + bf_scheme.outer_radius_tuyere,
        "y1": bf_scheme.cy_left_tuyere + bf_scheme.outer_radius_tuyere,
        "line": dict(color="black", width=1),
        "fillcolor": "grey",
    }


def create_shape_of_outer_circle_of_right_tuyere(bf_scheme: BFScheme) -> CircleShape:
    return {
        "type": "circle",
        "xref": "x",
        "yref": "y",
        "x0": bf_scheme.cx_right_tuyere - bf_scheme.outer_radius_tuyere,
        "y0": bf_scheme.cy_right_tuyere - bf_scheme.outer_radius_tuyere,
        "x1": bf_scheme.cx_right_tuyere + bf_scheme.outer_radius_tuyere,
        "y1": bf_scheme.cy_right_tuyere + bf_scheme.outer_radius_tuyere,
        "line": dict(color="black", width=1),
        "fillcolor": "grey",
    }


def create_shape_of_zero_stockline(bf_scheme: BFScheme) -> LineShape:
    return {
        "type": "line",
        "x0": bf_scheme.x0_zero_stockline,
        "x1": bf_scheme.x1_zero_stockline,
        "y0": bf_scheme.y_zero_stockline,
        "y1": bf_scheme.y_zero_stockline,
        "line": dict(color="red", width=2),
    }


def create_shape_of_stockrod_line(bf_scheme: BFScheme, stockrod_y_position: float) -> LineShape:
    return {
        "type": "line",
        "x0": bf_scheme.x0_stockrod_shape,
        "x1": bf_scheme.x1_stockrod_shape,
        "y0": stockrod_y_position,
        "y1": stockrod_y_position,
        "line": dict(color="blue", width=2),
    }


# fixed line - y position up to which the charge layers will be displayed
def create_shape_of_fixed_line(bf_scheme: BFScheme) -> LineShape:
    return {
        "type": "line",
        "x0": bf_scheme.x0_fixed_line,
        "x1": bf_scheme.x1_fixed_line,
        "y0": bf_scheme.y_fixed_line,
        "y1": bf_scheme.y_fixed_line,
        "line": dict(color="yellow", width=2),
    }


def create_outer_path_shape(bf_scheme: BFScheme) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.outer_shape_path,
        "line": dict(color="black", width=3),
        "fillcolor": "grey",
    }


def create_inner_path_shape(bf_scheme: BFScheme) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.inner_shape_path,
        "line": dict(color="grey", width=1),
        "fillcolor": "lightgrey",
    }


def create_left_tuyere_path_shape(bf_scheme: BFScheme) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.left_tuyere_path,
        "line": dict(color="black", width=2),
        "fillcolor": "grey",
    }


def create_right_tuyere_path_shape(bf_scheme: BFScheme) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.right_tuyere_path,
        "line": dict(color="black", width=2),
        "fillcolor": "grey",
    }


def create_left_iron_notch_path_shape(bf_scheme: BFScheme, fillcolor: str) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.left_iron_notch_path,
        "line": dict(color="black", width=2),
        "fillcolor": fillcolor,
    }


def create_right_iron_notch_path_shape(bf_scheme: BFScheme, fillcolor: str) -> PathShape:
    return {
        "type": "path",
        "path": bf_scheme.right_iron_notch_path,
        "line": dict(color="black", width=2),
        "fillcolor": fillcolor,
    }


def calculate_inner_width(
    y: float, inner_shape_key_points: dict[float, tuple[float, float]]
) -> tuple[float, float]:
    y_points = sorted(inner_shape_key_points.keys())
    x0_points = [inner_shape_key_points[yi][0] for yi in y_points]
    x1_points = [inner_shape_key_points[yi][1] for yi in y_points]
    return float(np.interp(y, y_points, x0_points)), float(np.interp(y, y_points, x1_points))


def create_charge_layer_polygon_points(
    start_y: float, end_y: float, bf_scheme: BFScheme
) -> dict[str, list[float]]:
    x0_start, x1_start = calculate_inner_width(start_y, bf_scheme.inner_shape_key_points)
    x0_end, x1_end = calculate_inner_width(end_y, bf_scheme.inner_shape_key_points)
    return {
        "x": [x0_start, x1_start, x1_end, x0_end, x0_start],
        "y": [start_y, start_y, end_y, end_y, start_y],
    }


def create_charge_layer_path_shape(
    layer_y_start_distance: float, layer_y_end_distance: float, bf_scheme: BFScheme
) -> PathShape:
    layer_start_y_position = bf_scheme.y_zero_stockline - layer_y_start_distance
    layer_end_y_position = bf_scheme.y_zero_stockline - layer_y_end_distance

    # Create polygon points for the charge layer with updated layer_start_y_position and layer_end_y_position
    polygon = create_charge_layer_polygon_points(layer_start_y_position, layer_end_y_position, bf_scheme)

    return dict(
        type="path",
        path=f"M {polygon['x'][0]},{polygon['y'][0]} "
        + " ".join([f"L {x},{y}" for x, y in zip(polygon["x"][1:], polygon["y"][1:])])
        + " Z",
        fillcolor="rgba(159, 130, 97, 0.5)",
        line=dict(color="rgba(102, 82, 60, 1)", width=1),
    )
