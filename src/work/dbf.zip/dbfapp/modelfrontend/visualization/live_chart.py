import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from modelfrontend.common import (
    AvailabilityChartData,
    ForecastsWithHistoryChartDataForTarget,
    LiveForecastChartDataForTarget,
)


def forecasts_chart(data: ForecastsWithHistoryChartDataForTarget, idx: int) -> go.Figure:
    forecasts = data.forecasts
    history = data.target_history
    probe = data.probe_history
    target_signal_name = data.target_signal_name
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            name="Upper Bound",
            x=forecasts.index,
            y=forecasts["0.95"],
            mode="lines",
            marker=dict(color="#444"),
            line=dict(width=0),
            showlegend=False,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Lower Bound",
            x=forecasts.index,
            y=forecasts["0.05"],
            marker=dict(color="#444"),
            line=dict(width=0),
            mode="lines",
            fillcolor="rgba(68, 68, 68, 0.3)",
            fill="tonexty",
            showlegend=False,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Forecast",
            x=forecasts.index,
            y=forecasts["expected_value"],
            mode="lines",
            line=dict(color="rgb(31, 119, 180)"),
            showlegend=True if idx == 1 else False,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="real",
            x=history.index,
            y=history[target_signal_name],
            mode="markers",
            marker={"size": 15, "symbol": "x", "color": "rgb(223, 61, 136)"},
            showlegend=True if idx == 1 else False,
        )
    )
    fig.add_trace(
        go.Scatter(
            name="probe",
            x=probe.index,
            y=probe.iloc[:, 1],
            mode="markers",
            marker={"size": 15, "symbol": "x", "color": "cyan"},
            showlegend=True if idx == 2 else False,
        )
    )

    return fig


def data_availability_chart(df: pd.DataFrame) -> go.Figure:
    fig = px.timeline(
        df,
        x_start="start",
        x_end="now",
        y="signal_id",
        hover_name="signal_name",
        color="input_sequence_masks",
        color_discrete_map={"Data N/A": "red", "Data OK": "green"},
    )

    return fig


def targets_chart(furnace_targets: pd.DataFrame, target_id: str, idx: int) -> go.Figure:
    fig = go.Figure()
    column_name = target_id.lower()
    fig.add_trace(
        go.Scatter(
            name="Target",
            x=furnace_targets["valid_asof"],
            y=furnace_targets[column_name],
            mode="lines+markers",
            line_shape="hv",
            line={"dash": "dot"},
            marker={"size": 8, "symbol": "circle", "color": "rgb(5, 213, 250)"},
            showlegend=True if idx == 1 else False,
        )
    )

    return fig


def merge_data_availability_dfs(live_chart_data: AvailabilityChartData) -> pd.DataFrame:
    return (
        pd.concat(live_chart_data.data_availability)
        .drop_duplicates(subset=["signal_name"])
        .reset_index(drop=True)
        .assign(signal_id=lambda x: x.index)
    )


def add_liveforecast_chart_annotations(
    fig: go.Figure, live_chart_data: list[LiveForecastChartDataForTarget], now: pd.Timestamp
) -> go.Figure:
    for idx, live_chart_data_for_target in enumerate(live_chart_data, start=1):
        fig.add_annotation(
            text=live_chart_data_for_target.target_id,
            xref="paper",
            yref="paper",
            x=0,
            y=1.06 if idx == 1 else 0.50,
            showarrow=False,
            font=dict(size=18),
        )
    fig.add_annotation(
        x=now,
        y=1.06,
        yref="paper",
        text="now",
        font_color="red",
        showarrow=False,
    )
    return fig


def add_availability_chart_annotations(fig: go.Figure, now: pd.Timestamp) -> go.Figure:
    fig.add_annotation(
        text="DATA AVAILABILITY",
        xref="paper",
        yref="paper",
        x=0,
        y=1.14,
        showarrow=False,
        font=dict(size=18),
    )

    fig.add_annotation(
        x=now,
        y=1.13,
        yref="paper",
        text="now",
        font_color="red",
        showarrow=False,
    )
    return fig


def add_vline(fig: go.Figure, now: pd.Timestamp) -> go.Figure:
    fig.add_shape(
        go.layout.Shape(
            type="line",
            yref="paper",
            xref="x",
            x0=now,
            y0=0,
            x1=now,
            y1=1,
            line=dict(color="red", width=3),
        ),
    )
    return fig


def get_traces_data_for_liveforecast_figure(
    live_chart_data: list[LiveForecastChartDataForTarget],
) -> list[go.Trace]:
    traces_data = []
    for idx, live_chart_data_for_target in enumerate(live_chart_data, start=1):
        forecasts_fig = forecasts_chart(live_chart_data_for_target, idx)
        furnace_targets = live_chart_data_for_target.furnace_targets
        targets_fig = targets_chart(furnace_targets, live_chart_data_for_target.target_id, idx)
        for trace in forecasts_fig.data:
            trace.yaxis = f"y{idx}"
            traces_data.append(trace)
        for trace in targets_fig.data:
            trace.yaxis = f"y{idx}"
            traces_data.append(trace)

    return traces_data


def update_liveforecast_layout(
    fig: go.Figure,
    start: pd.Timestamp,
    end: pd.Timestamp,
    num_targets: int,
) -> go.Figure:
    fig.update_layout(
        grid=dict(rows=num_targets, columns=1, ygap=0.14),
        hovermode="x",
        height=630,
        hoversubplots="axis",
        legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="right", x=1),
        margin=dict(r=5, b=1, l=5),
        **{
            f"xaxis{idx}": dict(
                type="date",
                range=[start, end],
                maxallowed=end,
                dtick=60 * 60 * 1000,  # every 1 hour
            )
            for idx in range(1, num_targets + 1)
        },
    )
    return fig


def update_availability_layout(
    fig: go.Figure,
    start: pd.Timestamp,
    end: pd.Timestamp,
    data_availability_df: pd.DataFrame,
) -> go.Figure:
    fig.update_layout(
        grid=dict(rows=1, columns=1, ygap=0.14),
        height=315,
        legend=dict(orientation="h", yanchor="bottom", y=1.04, xanchor="right", x=1),
        margin=dict(r=5, b=1, l=5),
        yaxis=dict(
            type="category",
            tickvals=data_availability_df["signal_id"],
            categoryarray=data_availability_df["signal_id"].sort_values(),
            showgrid=True,
            tickson="boundaries",
        ),
        xaxis=dict(
            type="date",
            range=[start, end],
            maxallowed=end,
            dtick=60 * 60 * 1000,  # every 1 hour
        ),
    )
    return fig


def get_liveforecast_chart_figure(
    live_chart_data: list[LiveForecastChartDataForTarget],
    start: pd.Timestamp,
    end: pd.Timestamp,
    now: pd.Timestamp,
) -> go.Figure:
    traces_data = get_traces_data_for_liveforecast_figure(live_chart_data)
    fig = go.Figure(data=traces_data)
    fig = add_liveforecast_chart_annotations(fig, live_chart_data, now)
    fig = add_vline(fig, now)
    update_liveforecast_layout(fig, start, end, len(live_chart_data))

    return fig


def get_availability_chart_figure(
    live_chart_data: AvailabilityChartData,
    start: pd.Timestamp,
    end: pd.Timestamp,
    now: pd.Timestamp,
) -> go.Figure:
    data_availability_df = merge_data_availability_dfs(live_chart_data)
    fig = data_availability_chart(data_availability_df)
    fig = add_availability_chart_annotations(fig, now)
    fig = add_vline(fig, now)
    update_availability_layout(fig, start, end, data_availability_df)

    return fig
