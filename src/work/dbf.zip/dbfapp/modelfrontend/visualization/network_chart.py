from collections import defaultdict
from typing import DefaultDict

import networkx as nx
import pandas as pd
import plotly.graph_objects as go
from modelbackend.models import TappingDeliveryHeatChem


def create_graph(df: pd.DataFrame) -> nx.DiGraph:
    # The creation of a directed graph
    G = nx.DiGraph()
    for _, row in df.iterrows():
        G.add_edge(row["tapping_id"], row["delivery_id"])
        G.add_edge(row["delivery_id"], row["heat_id"])
    return G


def get_layers(df: pd.DataFrame) -> dict[str, list[int]]:
    # Manually defined layout for a hierarchical appearance
    layers = {
        "tapping_id": sorted(df["tapping_id"].unique(), reverse=True),
        "delivery_id": df.sort_values("tapping_id", ascending=False)["delivery_id"].unique(),
        "heat_id": df.sort_values("tapping_id", ascending=False)["heat_id"].unique(),
    }
    return layers


def calculate_positions(layers: dict) -> dict:
    pos = {}
    x_spacing = 4  # Distance between layers
    # Setting different spacings for individual layers
    y_spacings = {
        "tapping_id": 1,  # Larger spacing for tapping_id
        "delivery_id": 1,  # Larger spacing for delivery_id
        "heat_id": 0.8,  # Regular spacing for heat_id
    }

    # Dynamic calculation of y_offset for better spacing
    for i, (layer_name, nodes) in enumerate(layers.items()):
        y_spacing = y_spacings.get(layer_name, 2)
        # Calculation of y_offset for centering the layer
        total_height = (len(nodes) - 1) * y_spacing
        y_offset = -total_height / 2  # Offset to ensure that the nodes are centered

        for j, node in enumerate(nodes):
            pos[node] = (i * x_spacing, y_offset + j * y_spacing)
    return pos


def create_edges_trace(G: nx.DiGraph, pos: dict) -> tuple[go.Scatter, list]:
    # Creating lists for nodes and edges
    edge_x = []
    edge_y = []
    annotations = []

    for u, v in G.edges():
        x0, y0 = pos[u]
        x1, y1 = pos[v]

        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])

        # Adding an arrow as an annotation
        annotations.append(
            dict(
                ax=x0,
                ay=y0,
                axref="x",
                ayref="y",
                x=x1,
                y=y1,
                xref="x",
                yref="y",
                showarrow=True,
                arrowhead=3,  # Arrow shape (size 3 is suitable)
                arrowsize=1.5,
                arrowwidth=2,
                arrowcolor="black",
            )
        )
    edge_trace = go.Scatter(
        x=edge_x, y=edge_y, line=dict(width=0.5, color="gray"), hoverinfo="none", mode="lines"
    )

    return edge_trace, annotations


def create_node_trace(
    G: nx.DiGraph, pos: dict, layers: dict, si_pct_dict: dict, mixer_by_delivery: dict
) -> go.Scatter:
    # Creating nodes
    node_x = []
    node_y = []
    node_color = []
    node_text = []
    node_hover_text = []
    node_size = []
    node_symbols = []
    text_positions = []

    for node in G.nodes():
        x, y = pos[node]
        node_x.append(x)
        node_y.append(y)

        if node in layers["tapping_id"]:
            node_color.append("red")
            node_size.append(40)
            p_si_value = si_pct_dict.get(f"p_{node}", "NaN")
            t_si_value = si_pct_dict.get(f"t_{node}", "NaN")
            node_text.append(f"<b>{node}</b><br><b>(For/Real = {p_si_value:.2f}/{t_si_value:.2f})</b>")
            node_hover_text.append(f"<b>{node}</b><br><b>(For/Real = {p_si_value:.2f}/{t_si_value:.2f})</b>")
            node_symbols.append("square")
            text_positions.append("middle left")
        elif node in layers["delivery_id"]:
            node_color.append("green")
            node_size.append(50)
            mixer_id_for_deliv_id = mixer_by_delivery[node]["mixer_id"]
            wght_avg_real = mixer_by_delivery[node]["weighted_avg_si_target"]
            wght_avg_forecast = mixer_by_delivery[node]["weighted_avg_si_prediction"]
            node_text.append(f"<b>{node}</b><br><b>(Mixer {mixer_id_for_deliv_id})</b>")
            node_hover_text.append(f"<b>Wght avg For/Real = {wght_avg_forecast:.2f}/{wght_avg_real:.2f}</b>")
            node_symbols.append("triangle-down")
            text_positions.append("bottom center")
        else:
            node_color.append("blue")
            node_size.append(35)
            si_pct_value = si_pct_dict.get(node, "NaN")

            weighted_real = mixer_by_delivery.get(node, {}).get("weighted_avg_si_target", None)
            weighted_pred = mixer_by_delivery.get(node, {}).get("weighted_avg_si_prediction", None)

            if weighted_real is not None and weighted_pred is not None:
                node_text.append(
                    f"<b>{node} (Si = {si_pct_value:.2f})</b><br><b>Wght Avg For/Real = {weighted_pred:.2f}/{weighted_real:.2f}</b>"
                )
                node_hover_text.append(
                    f"<b>{node}</b><br><b>(Si = {si_pct_value:.2f})</b><br><b>Wght Avg For/Real = {weighted_pred:.2f}/{weighted_real:.2f}</b>"
                )
            else:
                node_text.append(f"<b>{node}</b><br><b>(Si = {si_pct_value:.2f})</b>")
                node_hover_text.append(f"<b>{node}</b><br><b>(Si = {si_pct_value:.2f})</b>")

            node_symbols.append("hexagon")
            text_positions.append("middle right")

    node_trace = go.Scatter(
        x=node_x,
        y=node_y,
        mode="markers+text",
        text=node_text,
        textposition=text_positions,
        hovertext=node_hover_text,
        hoverinfo="text",
        marker=dict(
            symbol=node_symbols,  # Using different shapes
            size=node_size,
            color=node_color,
            line=dict(width=2),
        ),
        textfont=dict(color="black", size=14, family="Arial"),
    )

    return node_trace


def get_network_data_for_figure(furnace_id: int, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    queryset = TappingDeliveryHeatChem.objects.filter(
        furnace_id=furnace_id, tapping_start_date__gte=start, tapping_start_date__lte=end
    ).values()

    unique_heat_ids = list(set([item["heat_id"] for item in queryset]))

    tapping_extended = TappingDeliveryHeatChem.objects.filter(heat_id__in=unique_heat_ids).values()

    df = pd.DataFrame.from_records(tapping_extended)
    return df


def get_network_chart(df: pd.DataFrame) -> go.Figure:
    G = create_graph(df)
    layers = get_layers(df)
    pos = calculate_positions(layers)

    edge_trace, annotations = create_edges_trace(G, pos)

    if df.empty:
        node_trace = go.Scatter(
            x=[], y=[], mode="markers", hoverinfo="text", marker=dict(color=[], size=[], symbol=[])
        )
        width, height = 1200, 300
        x_range = [0, 1]
        y_range = [0, 1]
        annotations.extend(
            [
                dict(
                    text="For this date range, no data is available. /",
                    x=0.5,
                    y=0.55,
                    xref="paper",
                    yref="paper",
                    showarrow=False,
                    font=dict(size=14, color="red"),
                ),
                dict(
                    text="Pre tento rozsah dátumov nie sú dáta k dispozícii.",
                    x=0.5,
                    y=0.45,
                    xref="paper",
                    yref="paper",
                    showarrow=False,
                    font=dict(size=14, color="red"),
                ),
            ]
        )
    else:

        si_pct_dict: dict[str, float] = {}
        mixer_by_delivery: DefaultDict[str, DefaultDict[str, float]] = defaultdict(lambda: defaultdict(float))
        heat_by_id: DefaultDict[str, list[tuple[str, float]]] = defaultdict(list)

        for row in df.itertuples():
            si_pct_dict[row.heat_id] = row.si_pct
            si_pct_dict[f"p_{row.tapping_id}"] = row.si_prediction
            si_pct_dict[f"t_{row.tapping_id}"] = row.si_target

            weight_tapping = row.estimated_weight_from_tapping
            weight_mixer = row.weight_from_mixer

            # Mixer-level aggregation
            mixer_by_delivery[row.delivery_id]["mixer_id"] = row.mixer_id
            mixer_by_delivery[row.delivery_id]["total_weight"] += weight_tapping
            mixer_by_delivery[row.delivery_id]["weighted_target_sum"] += weight_tapping * row.si_target
            mixer_by_delivery[row.delivery_id]["weighted_prediction_sum"] += (
                weight_tapping * row.si_prediction
            )

            # For heat-level aggregation (using result later)
            heat_by_id[row.heat_id].append((row.delivery_id, weight_mixer))

        # Final mixer-level results
        result: dict[str, dict[str, float]] = {}

        for delivery_id, data in mixer_by_delivery.items():
            total_weight = data["total_weight"]
            if total_weight > 0:
                weighted_avg_target = data["weighted_target_sum"] / total_weight
                weighted_avg_prediction = data["weighted_prediction_sum"] / total_weight
            else:
                weighted_avg_target = 0
                weighted_avg_prediction = 0

            result[delivery_id] = {
                "mixer_id": data["mixer_id"],
                "weighted_avg_si_target": weighted_avg_target,
                "weighted_avg_si_prediction": weighted_avg_prediction,
            }

        # === Heat-level aggregation from mixer results ===
        for heat_id, delivery_entries in heat_by_id.items():
            total_weight = 0.0
            weighted_target_sum = 0.0
            weighted_prediction_sum = 0.0

            for delivery_id, weight in delivery_entries:
                delivery_data = result.get(delivery_id)
                if not delivery_data:
                    continue

                weighted_avg_target = delivery_data["weighted_avg_si_target"]
                weighted_avg_prediction = delivery_data["weighted_avg_si_prediction"]

                total_weight += weight
                weighted_target_sum += weight * weighted_avg_target
                weighted_prediction_sum += weight * weighted_avg_prediction

            if total_weight > 0:
                heat_avg_target = weighted_target_sum / total_weight
                heat_avg_prediction = weighted_prediction_sum / total_weight
            else:
                heat_avg_target = 0.0
                heat_avg_prediction = 0.0

            result[heat_id] = {
                "weighted_avg_si_target": heat_avg_target,
                "weighted_avg_si_prediction": heat_avg_prediction,
            }

        node_trace = create_node_trace(G, pos, layers, si_pct_dict, result)

        node_x = node_trace.x
        node_y = node_trace.y

        # === Range of X ===
        x_padding = 2
        x_range = [min(node_x) - x_padding, max(node_x) + x_padding]

        # === Y range based on actual positions ===
        y_padding = 0.5  # Minimal offset for visual separation
        y_min = min(node_y) - y_padding
        y_max = max(node_y) + y_padding
        y_range = [y_min, y_max]
        width = 1600
        # Dynamic height based on the Y range (distance between the highest and lowest point)
        y_span = y_max - y_min
        height = int(y_span * 100)  # Each 'step' in the vertical direction will be 100px

    # Create the plotly figure
    fig = go.Figure(
        data=[edge_trace, node_trace],
        layout=go.Layout(
            title="Hierarchical Network Graph",
            titlefont_size=16,
            showlegend=False,
            hovermode="closest",
            width=width,
            height=height,
            xaxis=dict(range=x_range, showgrid=False, zeroline=False, showticklabels=False),
            yaxis=dict(range=y_range, showgrid=False, zeroline=False, showticklabels=False),
            annotations=annotations,  # Adding arrows as annotations
        ),
    )
    return fig
