import pandas as pd
import plotly.graph_objects as go
from modelfrontend.visualization.bf_schemes import (
    BFScheme,
    create_charge_layer_path_shape,
    create_gap_phase_iron_annotation,
    create_gap_phase_pause_annotation,
    create_gap_phase_slag_annotation,
    create_inner_path_shape,
    create_left_iron_notch_path_shape,
    create_left_tuyere_path_shape,
    create_outer_path_shape,
    create_right_iron_notch_path_shape,
    create_right_tuyere_path_shape,
    create_shape_of_fixed_line,
    create_shape_of_inner_circle_of_left_tuyere,
    create_shape_of_inner_circle_of_right_tuyere,
    create_shape_of_outer_circle_of_left_tuyere,
    create_shape_of_outer_circle_of_right_tuyere,
    create_shape_of_stockrod_line,
    create_shape_of_zero_stockline,
    create_stockrod_annotation,
    create_zero_stockline_annotation,
)

from dbfcore.settings import TZ_LOCAL


def preprocess_stockrod_data_for_bf_visualization(
    signal_name: str, stockrod_data: pd.DataFrame, bf_scheme: BFScheme
) -> pd.DataFrame:
    stockrod_data = stockrod_data[[signal_name]].dropna()
    stockrod_data[signal_name] = stockrod_data[signal_name] / 100
    stockrod_data["y_position"] = bf_scheme.y_zero_stockline - stockrod_data[signal_name]

    return stockrod_data


def preprocess_charge_layer_height_data_for_bf_visualization(
    charge_layer_height_data: pd.DataFrame,
) -> pd.DataFrame:
    charge_layer_height_data.index = charge_layer_height_data.index.ceil("5min")
    return charge_layer_height_data


def merge_stockrod_and_gap_phase_data(
    bf_scheme: BFScheme,
    stockrod_data: pd.DataFrame,
    gap_phase_data: pd.DataFrame,
    stockrod_signal_name: str,
    gap_phase_signal_name: str,
) -> pd.DataFrame:
    if stockrod_data.empty:
        return pd.DataFrame()

    preprocessed_stockrod_data = preprocess_stockrod_data_for_bf_visualization(
        stockrod_signal_name, stockrod_data, bf_scheme
    )
    df = pd.concat([preprocessed_stockrod_data, gap_phase_data], axis=1)
    df[gap_phase_signal_name] = df[gap_phase_signal_name].ffill()

    first_valid_index = df[gap_phase_signal_name].first_valid_index()
    first_valid_value = df.loc[first_valid_index, gap_phase_signal_name]

    rows_to_fill = df.index.get_loc(first_valid_index)
    if rows_to_fill > 0:
        if first_valid_value == 0:
            df[gap_phase_signal_name] = df[gap_phase_signal_name].fillna(2)
        elif first_valid_value == 1:
            df[gap_phase_signal_name] = df[gap_phase_signal_name].fillna(0)
        elif first_valid_value == 2:
            df[gap_phase_signal_name] = df[gap_phase_signal_name].fillna(1)

    df_resampled = df.resample("5min").mean().dropna()

    return df_resampled


def create_blast_furnace_figure(bf_scheme: BFScheme) -> go.Figure:
    fig = go.Figure()
    fig.add_shape(create_outer_path_shape(bf_scheme))
    fig.add_shape(create_inner_path_shape(bf_scheme))
    fig.add_shape(create_left_tuyere_path_shape(bf_scheme))
    fig.add_shape(create_right_tuyere_path_shape(bf_scheme))
    fig.add_shape(create_left_iron_notch_path_shape(bf_scheme, "gray"))
    fig.add_shape(create_right_iron_notch_path_shape(bf_scheme, "gray"))
    fig.add_shape(create_shape_of_outer_circle_of_left_tuyere(bf_scheme)),
    fig.add_shape(create_shape_of_outer_circle_of_right_tuyere(bf_scheme)),
    fig.add_shape(create_shape_of_inner_circle_of_left_tuyere(bf_scheme)),
    fig.add_shape(create_shape_of_inner_circle_of_right_tuyere(bf_scheme)),
    fig.add_shape(create_shape_of_zero_stockline(bf_scheme))
    fig.add_annotation(create_zero_stockline_annotation(bf_scheme))
    fig.add_shape(create_shape_of_fixed_line(bf_scheme))

    return fig


def create_frames_for_figure(
    bf_scheme: BFScheme,
    fig: go.Figure,
    stockrod_and_gap_phase_data: pd.DataFrame,
    charge_layer_height_data: pd.DataFrame,
    stockrod_signal_name: str,
    gap_phase_signal_name: str,
) -> go.Figure:
    frames = []
    for current_timestamp, current_row in stockrod_and_gap_phase_data.iterrows():
        stockrod_y_position = current_row["y_position"]
        stockrod_value = current_row[stockrod_signal_name]

        # Annotations and shapes same for each frame
        annotations = [create_zero_stockline_annotation(bf_scheme)]
        shapes = [
            create_outer_path_shape(bf_scheme),
            create_inner_path_shape(bf_scheme),
            create_left_tuyere_path_shape(bf_scheme),
            create_right_tuyere_path_shape(bf_scheme),
            create_shape_of_outer_circle_of_left_tuyere(bf_scheme),
            create_shape_of_outer_circle_of_right_tuyere(bf_scheme),
            create_shape_of_inner_circle_of_left_tuyere(bf_scheme),
            create_shape_of_inner_circle_of_right_tuyere(bf_scheme),
            create_shape_of_zero_stockline(bf_scheme),
            create_shape_of_fixed_line(bf_scheme),
        ]

        # Visualization of stockrod data
        if not pd.isna(stockrod_y_position) and not pd.isna(stockrod_value):
            annotations.append(create_stockrod_annotation(bf_scheme, stockrod_y_position, stockrod_value))
            shapes.append(create_shape_of_stockrod_line(bf_scheme, stockrod_y_position))

        # Visualization of charge layer data
        last_actual_charge_layers = charge_layer_height_data.loc[
            charge_layer_height_data.index <= current_timestamp
        ].iloc[-1]
        for layer_height in last_actual_charge_layers.values:
            if pd.notnull(layer_height):
                layer_y_start_distance = stockrod_value + layer_height
                layer_y_end_distance = stockrod_value

                y_position_start = bf_scheme.y_zero_stockline - layer_y_start_distance
                if y_position_start >= bf_scheme.y_fixed_line:
                    layer_shape = create_charge_layer_path_shape(
                        layer_y_start_distance, layer_y_end_distance, bf_scheme
                    )
                    shapes.append(layer_shape)
                    stockrod_value = layer_y_start_distance
                else:
                    continue

        # Visualization of gap phase data
        fillcolor = "orange" if current_row[gap_phase_signal_name] in [0, 1] else "gray"
        shapes.extend(
            [
                create_left_iron_notch_path_shape(bf_scheme, fillcolor),
                create_right_iron_notch_path_shape(bf_scheme, fillcolor),
            ]
        )
        if current_row[gap_phase_signal_name] == 0:
            annotations.append(create_gap_phase_iron_annotation(bf_scheme))
        elif current_row[gap_phase_signal_name] == 1:
            annotations.append(create_gap_phase_slag_annotation(bf_scheme))
        else:
            annotations.append(create_gap_phase_pause_annotation(bf_scheme))

        frame = go.Frame(
            data=[],
            layout=dict(shapes=shapes, annotations=annotations),
            name=str(current_timestamp),
        )
        frames.append(frame)
    fig.update(frames=frames)
    return fig


def update_layout(fig: go.Figure) -> go.Figure:
    fig.update_layout(
        xaxis=dict(range=[0, 14], scaleanchor="y", visible=False),
        yaxis=dict(range=[0, 44], scaleanchor="x"),
        height=1000,
        updatemenus=[
            {
                "type": "buttons",
                "showactive": False,
                "buttons": [
                    {
                        "label": "Play",
                        "method": "animate",
                        "args": [None, {"frame": {"duration": 500, "redraw": False}, "fromcurrent": True}],
                    },
                    {
                        "label": "Stop",
                        "method": "animate",
                        "args": [
                            [None],
                            {
                                "frame": {"duration": 0, "redraw": False},
                                "mode": "immediate",
                                "transition": {"duration": 0},
                            },
                        ],
                    },
                ],
            }
        ],
        sliders=[
            {
                "font": {"size": 13},
                "steps": [
                    {
                        "args": [
                            [f.name],
                            {"frame": {"duration": 500, "redraw": False}, "mode": "immediate"},
                        ],
                        "label": pd.Timestamp(f.name).tz_convert(TZ_LOCAL).strftime("%H:%M<br>%b %d, %Y"),
                        "method": "animate",
                    }
                    for f in fig.frames
                ],
                "transition": {"duration": 250},
                "x": 0,
                "len": 1,
                "currentvalue": {
                    "prefix": "Time: ",
                    "visible": True,
                    "xanchor": "left",
                    "font": {"size": 14, "color": "#888"},
                },
            }
        ],
    )
    return fig


def get_bf_visualization(
    bf_scheme: BFScheme,
    stockrod_and_gap_phase_data: pd.DataFrame,
    charge_layer_height_data: pd.DataFrame,
    stockrod_signal_name: str,
    gap_phase_signal_name: str,
) -> go.Figure:
    fig = create_blast_furnace_figure(bf_scheme)
    fig = create_frames_for_figure(
        bf_scheme,
        fig,
        stockrod_and_gap_phase_data,
        charge_layer_height_data,
        stockrod_signal_name,
        gap_phase_signal_name,
    )
    fig = update_layout(fig)
    return fig
