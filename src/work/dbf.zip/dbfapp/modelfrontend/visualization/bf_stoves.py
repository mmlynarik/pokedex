from collections import defaultdict
from typing import Mapping

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

from dbfcore.stoves.input_data import StoveGasCompositionInput, StoveGasRegimeInput, StoveInitialStateInput
from dbfcore.stoves.protocol import (
    Gas,
    GasComposition,
    StoveGasRegime,
    StoveInitialState,
    StoveTemperaturePrediction,
)

GAS_COMPOSITIONS = {
    "cog": {
        "comp1": {
            "c2h2": 0.00182953,
            "c2h4": 0.04312869,
            "c2h6": 0.01384705,
            "c3h8": 0,
            "ch4": 0.32928713,
            "co": 0.15356892,
            "co2": 0.07911426,
            "h2": 0.11021038,
            "h2o": 0,
            "n2": 0.25197763,
            "o2": 0.01703644,
        },
        "comp2": {
            "c2h2": 0.00182953,
            "c2h4": 0.04312869,
            "c2h6": 0.01384705,
            "c3h8": 0,
            "ch4": 0.32928713,
            "co": 0.15356892,
            "co2": 0.07911426,
            "h2": 0.11021038,
            "h2o": 0,
            "n2": 0.25197763,
            "o2": 0.01703644,
        },
        "comp3": {
            "c2h2": 0.00189934,
            "c2h4": 0.05022187,
            "c2h6": 0.0164742,
            "c3h8": 0,
            "ch4": 0.39531071,
            "co": 0.05852084,
            "co2": 0.08353858,
            "h2": 0.1342492,
            "h2o": 0,
            "n2": 0.24739372,
            "o2": 0.01239184,
        },
        "comp4": {
            "c2h2": 0.00188808,
            "c2h4": 0.04690002,
            "c2h6": 0.01508584,
            "c3h8": 0,
            "ch4": 0.35254723,
            "co": 0.16157921,
            "co2": 0.07971854,
            "h2": 0.11830215,
            "h2o": 0,
            "n2": 0.21075674,
            "o2": 0.01322228,
        },
    },
    "bfg": {
        "comp1": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0.21046776,
            "co2": 0.28717156,
            "h2": 0.00146841,
            "h2o": 0.03567381,
            "n2": 0.46521847,
            "o2": 0,
        },
        "comp2": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0.19505375,
            "co2": 0.30008179,
            "h2": 0.00145028,
            "h2o": 0.0330147,
            "n2": 0.47039947,
            "o2": 0,
        },
        "comp3": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0.20335265,
            "co2": 0.30491789,
            "h2": 0.00149134,
            "h2o": 0.03259022,
            "n2": 0.45764792,
            "o2": 0,
        },
        "comp4": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0.18942773,
            "co2": 0.31417058,
            "h2": 0.00151405,
            "h2o": 0.0334892,
            "n2": 0.46139845,
            "o2": 0,
        },
    },
    "ng": {
        "comp1": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 3.6512,
            "c3h8": 1.6064,  # included: c4h10 (0.3028), c5h12 (0.0525), c6h14 (0.0243)
            "ch4": 93.6643,
            "co": 0,
            "co2": 0.5691,
            "h2": 0.0007,
            "h2o": 0,
            "n2": 0.7081,
            "o2": 0.0003,
        },
    },
    "air": {
        "comp1": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0,
            "co2": 0,
            "h2": 0,
            "h2o": 0.00199668,
            "n2": 0.7881235,
            "o2": 0.20987982,
        },
        "comp2": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0,
            "co2": 0,
            "h2": 0,
            "h2o": 0.01205406,
            "n2": 0.78311312,
            "o2": 0.20483282,
        },
        "comp3": {
            "c2h2": 0,
            "c2h4": 0,
            "c2h6": 0,
            "c3h8": 0,
            "ch4": 0,
            "co": 0,
            "co2": 0,
            "h2": 0,
            "h2o": 0.020993,
            "n2": 0.77810922,
            "o2": 0.20089778,
        },
    },
}

INTERCEPT_DOME = 456.10079405402837
COEFS_DOME = np.array(
    [
        0.00000000e00,
        -1.01700875e-01,
        -1.39968813e-01,
        1.76760512e02,
        3.07490226e-01,
        4.13350964e-07,
        1.25355871e-03,
        2.23526651e-02,
        5.57764559e-05,
        2.54946216e-06,
        -9.79536938e-01,
        -1.80516860e-04,
        -2.21665906e01,
        -1.12316922e-01,
        2.63134854e-04,
    ]
)
LR_DOME = LinearRegression()
LR_DOME.intercept_ = INTERCEPT_DOME
LR_DOME.coef_ = COEFS_DOME
POLY_DOME = PolynomialFeatures(degree=2)

# Wastegas model parameters
INTERCEPT_WG = 363.3287390168739
COEFS_WG = np.array(
    [
        0.00000000e00,
        2.54878218e-01,
        -3.46728435e-02,
        -2.02289956e02,
        -2.37121317e-01,
        -9.74727031e-01,
        1.11658829e-05,
        4.27997873e-03,
        -7.43502180e-02,
        -1.24641137e-04,
        -1.13692388e-04,
        1.36647219e-06,
        -4.21438233e00,
        -6.42210227e-04,
        -1.00507756e-03,
        5.49416341e01,
        6.37798174e-02,
        3.48254090e-01,
        2.00507837e-05,
        1.07508494e-03,
        4.81957207e-04,
    ]
)
LR_WG = LinearRegression()
LR_WG.intercept_ = INTERCEPT_WG
LR_WG.coef_ = COEFS_WG
POLY_WG = PolynomialFeatures(degree=2)


def get_stove_initial_state(stove_init_state: StoveInitialStateInput) -> StoveInitialState:
    return StoveInitialState(
        stove_init_state["dome_temp"],
        stove_init_state["stack_temp"],
        stove_init_state["wastegas_temp"],
    )


def get_gas_composition(gas_type: str, composition_type: str) -> GasComposition:
    gas_compositions_dict = GAS_COMPOSITIONS.get(gas_type.lower())

    if gas_compositions_dict:
        gas_composition = gas_compositions_dict.get(composition_type.lower())
        if gas_composition:
            return GasComposition(**gas_composition)
        else:
            raise KeyError(f"Unknown composition type: {composition_type}")
    else:
        raise KeyError(f"Unknown composition type: {gas_type}")


def get_gas_compositions(data: list[StoveGasCompositionInput]) -> Mapping[str, dict[str, GasComposition]]:
    compositions: Mapping[str, dict[str, GasComposition]] = defaultdict(dict)
    for comp_input in data:
        compositions[comp_input["type"]][comp_input["name"]] = GasComposition(
            comp_input["c2h2"],
            comp_input["c2h4"],
            comp_input["c2h6"],
            comp_input["c3h8"],
            comp_input["ch4"],
            comp_input["co"],
            comp_input["co2"],
            comp_input["h2"],
            comp_input["h2o"],
            comp_input["n2"],
            comp_input["o2"],
        )
    return compositions


def get_stove_gas_regime(
    stove_gas_regime: StoveGasRegimeInput, gas_compositions: Mapping[str, dict[str, GasComposition]]
) -> StoveGasRegime:
    cog_comp = gas_compositions["cog"][stove_gas_regime["cog_comp"]]
    bfg_comp = gas_compositions["bfg"][stove_gas_regime["bfg_comp"]]
    ng_comp = gas_compositions["ng"][stove_gas_regime["ng_comp"]]
    air_comp = gas_compositions["air"][stove_gas_regime["air_comp"]]

    cog = Gas(stove_gas_regime["cog_flow"], stove_gas_regime["cog_temp"], cog_comp)
    bfg = Gas(stove_gas_regime["bfg_flow"], stove_gas_regime["bfg_temp"], bfg_comp)
    ng = Gas(stove_gas_regime["ng_flow"], stove_gas_regime["ng_temp"], ng_comp)
    air = Gas(stove_gas_regime["air_flow"], stove_gas_regime["air_temp"], air_comp)

    return StoveGasRegime(stove_gas_regime["duration"], cog, bfg, ng, air)


def generate_stoves_chart(
    durations_list: list[int], data: dict[pd.Timedelta, StoveTemperaturePrediction], temps: pd.DataFrame
) -> go.Figure:

    x_vals = [td.total_seconds() / 60 for td, _ in data.items()]
    y_dome_pred = [pred.dome_temperature for _, pred in data.items()]
    y_waste_pred = [pred.wastegas_temperature for _, pred in data.items()]

    # Extract original temperatures
    orig_temperature = extract_orig_temps_from_temp_df(temps)
    orig_x = orig_temperature["time_int"]
    y_dome_actual = orig_temperature["dome_temp"]
    y_waste_actual = orig_temperature["wg_temp"]

    # Create subplots: 2 rows, same x-axis
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
    )

    # Row 1: Dome actual & predicted
    fig.add_trace(
        go.Scatter(
            x=orig_x, y=y_dome_actual, name="Dome actual", mode="lines", line=dict(dash="dash", color="blue")
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(x=x_vals, y=y_dome_pred, name="Dome predicted", mode="lines", line=dict(color="blue")),
        row=1,
        col=1,
    )

    # Row 2: Waste actual & predicted
    fig.add_trace(
        go.Scatter(
            x=orig_x, y=y_waste_actual, name="Waste actual", mode="lines", line=dict(dash="dash", color="red")
        ),
        row=2,
        col=1,
    )
    fig.add_trace(
        go.Scatter(x=x_vals, y=y_waste_pred, name="Waste predicted", mode="lines", line=dict(color="red")),
        row=2,
        col=1,
    )

    # Add vertical regime lines to both rows
    if durations_list:
        x_positions = pd.Series(durations_list).cumsum().tolist()
        shapes = [
            dict(
                type="line",
                x0=x,
                x1=x,
                y0=0,
                y1=1,
                xref="x",
                yref="paper",
                line=dict(color="black", width=1, dash="dot"),
            )
            for x in x_positions
        ]
        fig.update_layout(shapes=shapes)

    # Axis titles and layout
    fig.update_yaxes(title_text="Dome temp (°C)", row=1, col=1)
    fig.update_yaxes(title_text="Wastegas temp (°C)", row=2, col=1)
    fig.update_xaxes(title_text="Duration (minutes)", row=2, col=1)

    return fig


def extract_orig_temps_from_temp_df(orig_temperatures: pd.DataFrame) -> pd.DataFrame:

    temps_to_graph_non_idx = orig_temperatures.set_axis(["dome_temp", "wg_temp"], axis=1).reset_index()
    first_timestamp = temps_to_graph_non_idx["Timestamp"].iloc[0]

    temps_to_graph_non_idx["time_delta"] = temps_to_graph_non_idx["Timestamp"] - first_timestamp
    temps_to_graph_non_idx["time_int"] = temps_to_graph_non_idx["time_delta"].dt.total_seconds() / 60

    return temps_to_graph_non_idx[["time_int", "dome_temp", "wg_temp"]]
