import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def pci_chart(
    history_data: pd.DataFrame,
    future_data: pd.DataFrame,
    future_plus_100: pd.DataFrame,
    future_minus_100: pd.DataFrame,
    signal_name: str,
) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            name="History",
            x=history_data.index,
            y=history_data[signal_name],
            mode="lines",
            line=dict(color="rgb(31, 119, 180)"),
            showlegend=False,
        )
    )
    fig.add_trace(
        go.Scatter(
            name="Future",
            x=future_data.index,
            y=future_data[signal_name],
            mode="lines",
            line=dict(color="rgb(31, 119, 180)"),
            showlegend=False,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Future+100",
            x=future_plus_100.index,
            y=future_plus_100[signal_name],
            mode="lines",
            line=dict(color="rgb(31, 119, 10)"),
            showlegend=False,
        )
    ),
    fig.add_trace(
        go.Scatter(
            name="Future-100",
            x=future_minus_100.index,
            y=future_minus_100[signal_name],
            mode="lines",
            line=dict(color="rgb(120, 11, 18)"),
            showlegend=False,
        )
    ),

    return fig


def get_pci_chart(
    history_data: pd.DataFrame,
    future_data: pd.DataFrame,
    future_plus_100: pd.DataFrame,
    future_minus_100: pd.DataFrame,
    signal_name: str,
    now: pd.Timestamp,
    start: pd.Timestamp,
    end: pd.Timestamp,
) -> go.Figure:
    pci_chart_fig = pci_chart(history_data, future_data, future_plus_100, future_minus_100, signal_name)

    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05)

    for trace in pci_chart_fig.data:
        fig.add_trace(trace, row=1, col=1)
    for trace in pci_chart_fig.data:
        fig.add_trace(trace, row=2, col=1)

    fig.add_vline(x=now, line_width=3, line_color="red")
    fig.add_annotation(
        x=now,
        y=1.07,
        yref="paper",
        text="now",
        font_color="red",
        showarrow=False,
    )

    fig.update_layout(
        title=dict(
            text="PCI chart",
            y=0.90,
            x=0.02,
            xanchor="left",
            yanchor="top",
            font=dict(size=20),
        ),
        xaxis1=dict(
            type="date",
            range=[start, end],
            maxallowed=end,
            dtick=60 * 60 * 1000,  # every 1 hour
        ),
        xaxis2=dict(
            type="date",
            range=[start, end],
            maxallowed=end,
            dtick=60 * 60 * 1000,  # every 1 hour
        ),
        hoversubplots="axis",
        hovermode="x unified",
        height=600,
        legend=dict(orientation="h", yanchor="bottom", y=1.06, xanchor="right", x=1),
        margin=dict(r=5, b=0, l=5),
    )

    return fig
