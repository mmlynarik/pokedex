import base64
import json
import logging
import random
from datetime import datetime

import numpy as np
import pandas as pd
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import render
from django.urls import reverse
from modelbackend.common import get_blast_furnace_model
from modelbackend.management.commands.evalsiliconmodelonsteelshop import (
    calculate_tapping_proportions_in_heats,
    get_bf_proportions_in_heats,
)
from modelbackend.models import (
    BlastFurnaceEvalData,
    BlastFurnaceModelDeployment,
    StoveHeatingPhase,
    TappingDeliveryHeatChem,
)
from modelfrontend.common import (
    get_blast_furnace_model_result,
    get_furnace_targets_for_chart,
    get_raw_si_forecasts,
    get_result_from_db,
    get_results_from_db,
    get_signal_history,
    get_tapping_times,
)
from modelfrontend.visualization.bf_schemes import get_bf_scheme
from modelfrontend.visualization.bf_stoves import (
    LR_DOME,
    LR_WG,
    POLY_DOME,
    POLY_WG,
    generate_stoves_chart,
    get_gas_compositions,
    get_stove_gas_regime,
    get_stove_initial_state,
)
from modelfrontend.visualization.bf_visualization import (
    get_bf_visualization,
    merge_stockrod_and_gap_phase_data,
    preprocess_charge_layer_height_data_for_bf_visualization,
)
from modelfrontend.visualization.network_chart import get_network_chart, get_network_data_for_figure
from modelfrontend.visualization.predictionmodel import (
    create_availability_chart,
    create_eval_chart,
    create_liveforecast_chart,
    create_pci_chart,
    create_steelshop_chart,
)
from modelfrontend.visualization.stoves_heating_phases_chart import create_stoves_heating_phases_chart

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.dataset.raw_dataset.utils import localize_date_columns_and_convert_to_utc
from dbfcore.dataset.signals.tapping_delivery_heat_chem import get_steelshop_chems
from dbfcore.predictionmodel.protocols import BlastFurnaceModelResult
from dbfcore.settings import FURNACE_IDS, MAX_PRED_FREQ, TZ_LOCAL, TZ_UTC
from dbfcore.stoves.protocol import StoveTemperaturePrediction
from dbfcore.stoves.stove_model import PolyStoveModel

logger = logging.getLogger(__name__)


def get_max_pred_freq_minutes():
    return int(pd.Timedelta(MAX_PRED_FREQ).total_seconds() / 60)


def index(request):
    return render(request, "modelfrontend/index.html")


def steelshop_chart(request):
    context = {"steelshop_chart_url": reverse("steelshop-chart-json-default")}
    return render(request, "modelfrontend/steelshop_chart.html", context=context)


def live_chart(request, furnace_id: int):
    context = {
        "chart_liveforecast_url": reverse(
            "liveforecast-chart-json-default", kwargs={"furnace_id": furnace_id}
        ),
        "chart_availability_url": reverse(
            "availability-chart-json-default", kwargs={"furnace_id": furnace_id}
        ),
    }

    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/live_chart.html", context=context)


def eval_chart(request, furnace_id: int):
    context = {
        "eval_chart_url": reverse("eval-chart-json-default", kwargs={"furnace_id": furnace_id}),
        "network_chart_url": reverse("network-chart-json-default", kwargs={"furnace_id": furnace_id}),
    }
    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/eval_chart.html", context=context)


def pci_chart(request, furnace_id: int):
    context = {"pci_chart_url": reverse("pci-chart-json-default", kwargs={"furnace_id": furnace_id})}
    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/pci_chart.html", context=context)


def export(request, furnace_id: int):
    context = {"export_url": reverse("export-eval-data-default", kwargs={"furnace_id": furnace_id})}
    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/export_eval_data.html", context)


def bf_visualization(request, furnace_id: int):
    context = {"bf_visualization_url": reverse("bf-visualization-default", kwargs={"furnace_id": furnace_id})}
    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/bf_visualization.html", context)


def stoves_heating_phases(request, furnace_id: int):
    context = {
        "stoves_heating_phases_url": reverse(
            "stoves-heating-phases-chart-default", kwargs={"furnace_id": furnace_id}
        )
    }
    context.update({"furnace_id": furnace_id})
    return render(request, "modelfrontend/stoves_heating_phases.html", context)


def stoves_chart(request, base64_safe_url_data: str = ""):

    context = {
        "stoves_chart_url": reverse("stoves-chart-json", kwargs={"base64_safe_url_data": "+"}).strip("+"),
        "base64_encoded_table_data": base64_safe_url_data,
    }
    return render(request, "modelfrontend/stoves_chart.html", context=context)


def export_eval_data(request, furnace_id: int, start_date: int, end_date: int):
    if start_date > end_date:
        return HttpResponseBadRequest(
            "The start date cannot be greater than the end date.", content_type="application/json"
        )

    start_datetime = datetime.fromtimestamp(start_date, tz=TZ_UTC)
    end_datetime = datetime.fromtimestamp(end_date, tz=TZ_UTC)

    df = pd.DataFrame(
        list(
            BlastFurnaceEvalData.objects.filter(
                furnace_id=furnace_id,
                forecast_time__range=[start_datetime, end_datetime],
            ).values()
        )
    )

    if df.empty:
        return HttpResponseBadRequest(
            "No data found for the selected time range.", content_type="application/json"
        )

    for col in ["forecast_time", "pig_iron_analysis_date", "est_sample_collection_date"]:
        if col in df.columns:
            if df[col].notna().any():
                df[col] = df[col].dt.tz_convert(TZ_LOCAL).dt.tz_localize(None)

    start_date_str = start_datetime.strftime("%Y%m%d%H%M")
    end_date_str = end_datetime.strftime("%Y%m%d%H%M")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="model_eval_data_bf{furnace_id}_{start_date_str}_{end_date_str}.xlsx"'
        },
    )
    with pd.ExcelWriter(response, engine="openpyxl") as writer:
        df.to_excel(writer, index=False)
    return response


def liveforecast_chart_json(
    request,
    furnace_id: int,
    now: int = 0,
    lookback_minutes: int = 480,
    forecast_minutes: int = 240,
):
    if now == 0:
        now_datetime = pd.Timestamp.now(tz="UTC")
    elif now <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        now_datetime = pd.Timestamp.fromtimestamp(now, tz="UTC")

    if not (0 <= lookback_minutes <= 1440):
        return HttpResponseBadRequest(
            "Lookback minutes need to be between 0 and 1440", content_type="application/json"
        )

    if not (0 <= forecast_minutes <= 240):
        return HttpResponseBadRequest(
            "Forecast minutes need to be between 0 and 240", content_type="application/json"
        )

    lookback = pd.Timedelta(minutes=lookback_minutes)
    forecast = pd.Timedelta(minutes=forecast_minutes)
    deployments = BlastFurnaceModelDeployment.objects.filter(furnace_id=furnace_id).order_by("-target_id")
    datasources = get_datasources_configured_with_env()

    start = now_datetime - lookback
    end = now_datetime + forecast

    furnace_targets = get_furnace_targets_for_chart(furnace_id, start, now_datetime, end)
    results: dict[str, BlastFurnaceModelResult] = {}
    targets_history: dict[str, pd.DataFrame] = {}
    probes_history: dict[str, pd.DataFrame] = {}
    for deployment in deployments:
        model = get_blast_furnace_model(deployment.model_definition)
        result_db = get_result_from_db(deployment.model_definition, now_datetime)

        if result_db is None:
            return HttpResponse({}, content_type="application/json")

        result = get_blast_furnace_model_result(result_db, model)
        probe_signal_name = f"bf{furnace_id}_hotmetalsi_pi_probe_chem_pct"
        target_history = get_signal_history(result.target_signal_name, start, end, datasources)
        results[deployment.target_id] = result
        targets_history[deployment.target_id] = target_history
        probes_history[deployment.target_id] = get_signal_history(probe_signal_name, start, end, datasources)

    fig = create_liveforecast_chart(
        results, targets_history, probes_history, furnace_targets, lookback, forecast
    )
    return HttpResponse(fig.to_json(), content_type="application/json")


def availability_chart_json(
    request,
    furnace_id: int,
    now: int = 0,
    lookback_minutes: int = 480,
    forecast_minutes: int = 240,
):
    if now == 0:
        now_datetime = pd.Timestamp.now(tz="UTC")
    elif now <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        now_datetime = pd.Timestamp.fromtimestamp(now, tz="UTC")

    if not (0 <= lookback_minutes <= 1440):
        return HttpResponseBadRequest(
            "Lookback minutes need to be between 0 and 1440", content_type="application/json"
        )

    if not (0 <= forecast_minutes <= 240):
        return HttpResponseBadRequest(
            "Forecast minutes need to be between 0 and 240", content_type="application/json"
        )

    lookback = pd.Timedelta(minutes=lookback_minutes)
    forecast = pd.Timedelta(minutes=forecast_minutes)
    deployments = BlastFurnaceModelDeployment.objects.filter(furnace_id=furnace_id).order_by("-target_id")

    results: dict[str, BlastFurnaceModelResult] = {}
    for deployment in deployments:
        model = get_blast_furnace_model(deployment.model_definition)
        result_db = get_result_from_db(deployment.model_definition, now_datetime)

        if result_db is None:
            return HttpResponse({}, content_type="application/json")

        result = get_blast_furnace_model_result(result_db, model)
        results[deployment.target_id] = result

    fig = create_availability_chart(results, lookback, forecast)
    return HttpResponse(fig.to_json(), content_type="application/json")


def eval_chart_json(
    request,
    furnace_id: int,
    start: int = 0,
    evaluation_period: int = 12,
    forecast_horizon: int = 60,
    forecast_frequency: int = get_max_pred_freq_minutes(),
):
    if start == 0:
        start_datetime = pd.Timestamp.now(tz="UTC")
    elif start <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        start_datetime = pd.Timestamp.fromtimestamp(start, tz="UTC")

    if not (0 <= evaluation_period <= 96):
        return HttpResponseBadRequest(
            "Evaluation period hours need to be between 0 and 96", content_type="application/json"
        )
    if not (0 <= forecast_horizon <= 240):
        return HttpResponseBadRequest(
            "Forecast horizon minutes need to be between 0 and 240", content_type="application/json"
        )

    evaluation_period = pd.Timedelta(hours=evaluation_period)
    forecast_horizon = pd.Timedelta(minutes=forecast_horizon)
    forecast_frequency = pd.Timedelta(minutes=forecast_frequency)
    start, end = start_datetime, start_datetime + evaluation_period

    datasources = get_datasources_configured_with_env()
    tapping_events = get_signal_history(f"bf{furnace_id}_gap_phase_enum", start, end, datasources)
    tapping_times = get_tapping_times(tapping_events)

    deployments = BlastFurnaceModelDeployment.objects.filter(furnace_id=furnace_id).order_by("-target_id")
    results: dict[str, list[BlastFurnaceModelResult]] = {}
    targets_history: dict[str, pd.DataFrame] = {}
    probes_history: dict[str, pd.DataFrame] = {}
    for deployment in deployments:
        target_id = deployment.target_id
        model = get_blast_furnace_model(deployment.model_definition)
        results_db = get_results_from_db(
            deployment.model_definition, start - forecast_horizon, end - forecast_horizon, forecast_frequency
        )
        if not results_db:
            return HttpResponse({}, content_type="application/json")

        results_for_target = [get_blast_furnace_model_result(result_db, model) for result_db in results_db]
        signal_name = results_for_target[0].target_signal_name
        probe_signal_name = f"bf{furnace_id}_hotmetalsi_pi_probe_chem_pct"
        results[target_id] = results_for_target
        targets_history[target_id] = get_signal_history(signal_name, start, end, datasources)
        probes_history[target_id] = get_signal_history(probe_signal_name, start, end, datasources)

    fig = create_eval_chart(
        results, tapping_times, targets_history, probes_history, evaluation_period, forecast_horizon
    )

    return HttpResponse(fig.to_json(), content_type="application/json")


def network_chart_json(
    request,
    furnace_id: int,
    start: int = 0,
    evaluation_period: int = 12,
    forecast_horizon: int = 60,
    forecast_frequency: int = get_max_pred_freq_minutes(),
):
    if start == 0:
        start_datetime = pd.Timestamp.now(tz="UTC")
    elif start <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        start_datetime = pd.Timestamp.fromtimestamp(start, tz="UTC")

    if not (0 <= evaluation_period <= 96):
        return HttpResponseBadRequest(
            "Evaluation period hours need to be between 0 and 96", content_type="application/json"
        )
    if not (0 <= forecast_horizon <= 240):
        return HttpResponseBadRequest(
            "Forecast horizon minutes need to be between 0 and 240", content_type="application/json"
        )

    evaluation_period = pd.Timedelta(hours=evaluation_period)
    forecast_horizon = pd.Timedelta(minutes=forecast_horizon)
    forecast_frequency = pd.Timedelta(minutes=forecast_frequency)
    start, end = start_datetime, start_datetime + evaluation_period

    network_data = get_network_data_for_figure(furnace_id, start, end)
    if network_data.empty:
        network_data = pd.DataFrame(
            columns=[
                "tapping_start_date",
                "tapping_end_date",
                "tapping_id",
                "furnace_id",
                "delivery_id",
                "mixer_id",
                "heat_id",
                "si_pct",
                "si_target",
                "si_prediction",
            ]
        )

    fig = get_network_chart(network_data)
    return HttpResponse(fig.to_json(), content_type="application/json")


def pci_chart_json(
    request,
    furnace_id: int,
    now: int = 0,
    lookback_minutes: int = 480,
    forecast_minutes: int = 240,
):
    if now == 0:
        now_datetime = pd.Timestamp.now(tz="UTC")
    elif now <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        now_datetime = pd.Timestamp.fromtimestamp(now, tz="UTC")

    if not (0 <= lookback_minutes <= 1440):
        return HttpResponseBadRequest(
            "Lookback minutes need to be between 0 and 1440", content_type="application/json"
        )

    if not (0 <= forecast_minutes <= 240):
        return HttpResponseBadRequest(
            "Forecast minutes need to be between 0 and 240", content_type="application/json"
        )
    lookback = pd.Timedelta(minutes=lookback_minutes)
    forecast = pd.Timedelta(minutes=forecast_minutes)
    start, end = now_datetime - lookback, now_datetime + forecast

    fig = create_pci_chart(now_datetime, start, end, furnace_id)

    return HttpResponse(fig.to_json(), content_type="application/json")


def bf_visualization_json(request, start_date: int, end_date: int, furnace_id: int):
    if start_date > end_date:
        return HttpResponseBadRequest(
            "The start date cannot be greater than the end date.", content_type="application/json"
        )

    start_datetime = pd.Timestamp.fromtimestamp(start_date, tz="UTC")
    end_datetime = pd.Timestamp.fromtimestamp(end_date, tz="UTC")
    datasources = get_datasources_configured_with_env()
    # We only visualize stockrod data from one probe, that`s why we chose only "stockrod1".
    stockrod_signal_name = f"bf{furnace_id}_stockrod1_distance_m"
    gap_phase_signal_name = f"bf{furnace_id}_gap_phase_enum"
    charge_layer_height_signal_name = f"bf{furnace_id}_charge_layer1_height_m"

    stockrod_data = get_signal_history(stockrod_signal_name, start_datetime, end_datetime, datasources)
    gap_phase_data = get_signal_history(gap_phase_signal_name, start_datetime, end_datetime, datasources)

    # We need to adjust the start dates because of situations when we select data for a short
    # period of time and for this reason we do not have data available for a given number of layers.
    # To obtain all the data we need, we adjust the start dates. In this case the number 5 is just
    # arbitrary ensuring that we always get all the information about charge layers.
    start_updated = start_datetime - pd.Timedelta(hours=5)
    charge_layer_height_data = get_signal_history(
        charge_layer_height_signal_name, start_updated, end_datetime, datasources
    ).pipe(preprocess_charge_layer_height_data_for_bf_visualization)

    bf_scheme = get_bf_scheme(furnace_id)

    stockrod_and_gap_phase_data = merge_stockrod_and_gap_phase_data(
        bf_scheme, stockrod_data, gap_phase_data, stockrod_signal_name, gap_phase_signal_name
    )
    if stockrod_and_gap_phase_data.empty:
        return HttpResponseBadRequest(
            "No data found for the selected time range.", content_type="application/json"
        )

    fig = get_bf_visualization(
        bf_scheme,
        stockrod_and_gap_phase_data,
        charge_layer_height_data,
        stockrod_signal_name,
        gap_phase_signal_name,
    )

    return HttpResponse(fig.to_json(), content_type="application/json")


def bf_heater_optimizer(request):
    return render(request, "modelfrontend/bf_heater_optimizer.html")


def get_tapping_map_for_heats(heat_ids: list[int]) -> pd.DataFrame:
    tap_from_db_for_heats = []
    for item in TappingDeliveryHeatChem.objects.filter(heat_id__in=heat_ids):
        row = {
            "tapping_start_date": item.tapping_start_date,
            "tapping_end_date": item.tapping_end_date,
            "tapping_id": item.tapping_id,
            "delivery_id": item.delivery_id,
            "furnace_id": item.furnace_id,
            "mixer_id": item.mixer_id,
            "heat_id": item.heat_id,
            "weight_from_mixer": item.weight_from_mixer,
            "pig_iron_weight": item.pig_iron_weight,
            "estimated_weight_from_tapping": item.estimated_weight_from_tapping,
            "si_pct": item.si_pct,
            "ok_heat": item.ok_heat,
        }
        tap_from_db_for_heats.append(row)

    return pd.DataFrame(tap_from_db_for_heats)


def steelshop_chart_json(
    request,
    now: int,
    lookback_minutes: int,
    offset_minutes: int,
):
    if now == 0:
        now_datetime = pd.Timestamp.now(tz="UTC")
    elif now <= 1356994800:
        return HttpResponseBadRequest(
            "Now needs to be later than 1.1.2013 or zero for server time.", content_type="application/json"
        )
    else:
        now_datetime = pd.Timestamp.fromtimestamp(now, tz="UTC")

    if not (0 <= lookback_minutes <= 1440):
        return HttpResponseBadRequest(
            "Lookback minutes need to be between 0 and 1440", content_type="application/json"
        )

    if not (0 <= offset_minutes <= 480):
        return HttpResponseBadRequest(
            "Forecast minutes need to be between 0 and 240", content_type="application/json"
        )
    lookback = pd.Timedelta(minutes=lookback_minutes)
    offset = pd.Timedelta(minutes=offset_minutes)
    start, end = now_datetime - lookback, now_datetime + pd.Timedelta("2h")
    ds = get_datasources_configured_with_env()

    silicon_at_desulf = get_steelshop_chems(start, end, ds)[["heat_id", "first_temp_date", "si_pct"]]
    silicon_at_desulf = localize_date_columns_and_convert_to_utc(silicon_at_desulf, dropna=False)
    silicon_at_desulf = silicon_at_desulf.sort_values("first_temp_date")
    heat_ids = silicon_at_desulf["heat_id"].tolist()
    tapping_map = get_tapping_map_for_heats(heat_ids)
    tapping_proportions = calculate_tapping_proportions_in_heats(tapping_map)
    bf_proportions = get_bf_proportions_in_heats(tapping_proportions)
    measured_data = bf_proportions.merge(
        silicon_at_desulf[["heat_id", "first_temp_date"]], on="heat_id"
    ).sort_values("first_temp_date")

    raw_forecasts = get_raw_si_forecasts(start, end, offset).reset_index(names=["forecast_date"])

    heat_data = pd.merge_asof(
        measured_data,
        raw_forecasts,
        left_on="first_temp_date",
        right_on="forecast_date",
        direction="nearest",
    )
    heat_data["proportional_forecast"] = heat_data.apply(
        lambda row: np.nansum([row[f"bf{bf}_proportion"] * row[f"bf{bf}"] for bf in FURNACE_IDS]), axis=1
    )
    heat_data["minimum_forecast"] = heat_data.apply(
        lambda row: np.nanmin([row["bf1"], row["bf2"], row["bf3"]]), axis=1
    )
    raw_forecasts = raw_forecasts.set_index("forecast_date")
    heat_data = heat_data.set_index("first_temp_date")
    fig = create_steelshop_chart(raw_forecasts, heat_data, start, end, now_datetime)

    return HttpResponse(fig.to_json(), content_type="application/json")


def stoves_heating_phases_chart(request, furnace_id: int, start_date: int, end_date: int):
    if start_date > end_date:
        return HttpResponseBadRequest(
            "The start date cannot be greater than the end date.", content_type="application/json"
        )

    start_datetime = datetime.fromtimestamp(start_date, tz=TZ_UTC)
    end_datetime = datetime.fromtimestamp(end_date, tz=TZ_UTC)

    heating_phases_df = pd.DataFrame(
        list(
            StoveHeatingPhase.objects.filter(
                heating_phase_id__startswith=str(furnace_id),
                start__gte=start_datetime,
                end__lte=end_datetime,
            ).values()
        )
    )

    if heating_phases_df.empty:
        return HttpResponseBadRequest(
            "No data found for the selected time range.", content_type="application/json"
        )

    fig = create_stoves_heating_phases_chart(heating_phases_df)

    return HttpResponse(fig.to_json(), content_type="application/json")


def stoves_chart_json(request, base64_safe_url_data: str = ""):
    decoded_data = base64.b64decode(base64_safe_url_data).decode("utf-8")
    data = json.loads(decoded_data)

    init_state = get_stove_initial_state(data["initial_data"])
    gas_compositions = get_gas_compositions(data["compositions"])
    stove_gas_regimes = []
    durations = []
    for gas_regime in data["regimes"]:
        stove_gas_regimes.append(get_stove_gas_regime(gas_regime, gas_compositions))
        durations.append(gas_regime["duration"])

    stove_model = PolyStoveModel(LR_DOME, POLY_DOME, LR_WG, POLY_WG)
    stove_results = stove_model.temperature_prediction(init_state, stove_gas_regimes)

    ##########################################################################
    # Next code will be deleted after real dataframe with stove temperatures
    # will be included into code. Temporary dataframe 'temps' needed for generate_stoves_chart function
    ##########################################################################
    timestamps = pd.date_range(start="2025-01-01 00:00", periods=5, freq="min")
    dome_temps = [1349.8, 1351.11, 1351.84, 1352.4, 1352.86]
    wastegas_temps = [265.78, 266.66, 268.14, 270.11, 271.63]
    temps = pd.DataFrame(
        {"bf1_stove11_dome_temp_C": dome_temps, "bf1_stove11_wastegas_temp_C": wastegas_temps},
        index=timestamps,
    )
    temps.index.name = "Timestamp"
    ##########################################################################
    # End of temporary code - end of deletion
    ##########################################################################

    fig = generate_stoves_chart(durations, stove_results, temps)

    return HttpResponse(fig.to_json(), content_type="application/json")
