class BoolConverter:
    regex = "true|false|1|0"

    def to_python(self, value):
        if value in ["true", "1"]:
            return True
        elif value in ["false", "0"]:
            return False
        else:
            raise ValueError(f"Invalid boolean value: {value}")

    def to_url(self, value):
        return str(value).lower()
