import torch


class TorchNoGradMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        torch.set_grad_enabled(False)
        return self.get_response(request)
