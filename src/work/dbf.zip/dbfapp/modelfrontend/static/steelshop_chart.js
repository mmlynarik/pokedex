$(document).ready(function () {
  const timeoutDuration = 30000; // in milliseconds (= 30 seconds)
  var apiRequestRunning = false;

  function doRefresh() {
    if(apiRequestRunning){
      return;
    }

    if ($("#autoreload-on").is(":checked")) {
      var nowString = moment().format("YYYY-MM-DDTHH:mm");
      if (nowString !== $("#model-now").val()) {
        $("#model-now").val(nowString).trigger("auto-change");
      }
    }
  }

  function onDataLoadSuccess(chartData, chartWrapperId) {
    var data = chartData.data || [];
    var layout = chartData.layout || {};
    var config = chartData.config || { displayModeBar: false };
    Plotly.react(chartWrapperId, data, layout, config);
    $("#loader").attr("hidden", "true");
  }

  function onDataLoadError(jqxhr, textStatus) {
    if (textStatus == "abort") {
      alert("The request timed out. Please try again.");
    } else {
      alert("An error occurred while fetching the data.")
    }
    turnAutoreloadOff();
    $("#loader").attr("hidden", "true");
  }

  function loadDataWithTimeout(url, timeoutDuration, onSuccessCallback, onFailCallback) {
    var timeout = undefined;
    apiRequestRunning = true;

    const xhr = $.getJSON(url)
    .done(function(data) {
      apiRequestRunning = false;
      if(timeout !== undefined){
        clearTimeout(timeout);
      }
      onSuccessCallback(data);
    })
    .fail(onFailCallback);

    timeout = setTimeout(function() {
      if (xhr.readyState !== 4) {
        xhr.abort();
        apiRequestRunning = false;
      }
    }, timeoutDuration);
  }

  function turnAutoreloadOff() {
    $("#autoreload-on").prop("checked", false);
  }

  function refreshChart(dataUrlPathId, chartWrapperId) {
    var jsonSrc = $(`#${dataUrlPathId}`).text();
    if (jsonSrc.length !== 0) {
      var chartUrl = JSON.parse(jsonSrc);
      var chartNow = new Date($("#model-now").val());
      var chartNowEpoch = chartNow.getTime() / 1000;
      var lookbackWindow = $("#lookback-window").val();
      var offset = $("#offset").val();
      var urlStr = chartUrl + "/" + chartNowEpoch + "/" + lookbackWindow + "/" + offset;

      $("#loader").removeAttr("hidden");

      loadDataWithTimeout(
        urlStr,
        timeoutDuration,
        function (chartData) { onDataLoadSuccess(chartData, chartWrapperId) },
        onDataLoadError
      )
    }
  }

  function autoRefresh() {
    refreshChart("steelshop-chart-url", "steelshop-chart");
  }

  function manualRefresh() {
    turnAutoreloadOff();
    autoRefresh();
  }

  $("#main-form").on("submit", manualRefresh);
  $("#model-now").on("auto-change", autoRefresh);
  $("#model-now").on("change", turnAutoreloadOff);
  $("#autoreload-on").on("change", function () {
    if ($("#autoreload-on").is(":checked")) {
      autoRefresh();
    }
  });

  doRefresh();
  setInterval(doRefresh, 1000);
});
