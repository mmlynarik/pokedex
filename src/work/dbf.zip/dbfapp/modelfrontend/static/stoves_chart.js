import { gridGasRegimesDataApi, gridInitialDataApi } from './scripts/stove_model/main.js';

gridInitialDataApi
gridGasRegimesDataApi

$(document).ready(function () {
  const timeoutDuration = 30000; // 30 seconds
  let apiRequestRunning = false;

  function onDataLoadSuccess(chartData, chartWrapperId) {
    const data = chartData.data || [];
    const layout = chartData.layout || {};
    const config = chartData.config || { displayModeBar: false };
    Plotly.react(chartWrapperId, data, layout, config);
    $("#loader").attr("hidden", "true");
  }

  function onDataLoadError(jqxhr, textStatus) {
    if (textStatus === "abort") {
      alert("The request timed out. Please try again.");
    } else {
      alert("An error occurred while fetching the data.");
    }
    $("#loader").attr("hidden", "true");
  }

  function loadDataWithTimeout(url, timeoutDuration, onSuccessCallback, onFailCallback) {
    let timeout;
    apiRequestRunning = true;

    const xhr = $.getJSON(url)
      .done((data) => {
        apiRequestRunning = false;
        if (timeout !== undefined) {
          clearTimeout(timeout);
        }
        onSuccessCallback(data);
      })
      .fail(onFailCallback);

    timeout = setTimeout(() => {
      if (xhr.readyState !== 4) {
        xhr.abort();
        apiRequestRunning = false;
      }
    }, timeoutDuration);
  }

  function refreshChart(dataUrlPathId, chartWrapperId) {
    const jsonSrc = $(`#${dataUrlPathId}`).text();
    if (jsonSrc.length === 0) return;

    const urlStr = JSON.parse(jsonSrc);
    //const jsonString = JSON.stringify("default");
    //const base64Str = btoa(jsonString);
    //const base64Safe = encodeURIComponent(base64Str);
    //const urlStr = `${chartUrl}/${base64Safe}`;

    console.log(urlStr);

    $("#loader").removeAttr("hidden");

    loadDataWithTimeout(
      urlStr,
      timeoutDuration,
      (chartData) => onDataLoadSuccess(chartData, chartWrapperId),
      onDataLoadError
    );
  }

  function autoRefresh() {
    if (!apiRequestRunning) {
      refreshChart("stoves-chart-url", "stoves-chart");
    }
  }



  // Manual trigger on form submit
  $("#main-form").on("submit", function (e) {
    e.preventDefault();
    autoRefresh();
  });


  // Auto-refresh on page load
  // autoRefresh();

  // Optional: auto-refresh every X seconds
  // setInterval(autoRefresh, 30000); // uncomment to auto-refresh every 30s
});
