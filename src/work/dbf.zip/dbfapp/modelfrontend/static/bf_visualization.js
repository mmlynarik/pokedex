$(document).ready(function () {
    const timeoutDuration = 30000; // in milliseconds (= 30 seconds)
    var apiRequestRunning = false;

    function setDefaultDateTime() {
        var now = moment();
        var fourHoursAgo = now.clone().subtract(4, "hours");
        var formattedNow = now.format("YYYY-MM-DDTHH:mm");
        var formattedfourHoursAgo = fourHoursAgo.format("YYYY-MM-DDTHH:mm");

        $("#start-date").val(formattedfourHoursAgo);
        $("#end-date").val(formattedNow);
    }

    function onDataLoadSuccess(chartData, chartWrapperId) {
        var data = chartData.data || [];
        var layout = chartData.layout || {};
        var config = chartData.config || { displayModeBar: false };
        Plotly.react(chartWrapperId, { data: data, layout: layout, frames: chartData.frames }, config);
        $("#loader").attr("hidden", "true");
    }

    function onDataLoadError(jqxhr, textStatus) {
        if (textStatus == "abort") {
            alert("The request timed out. Please try again.");
        } else {
            alert("An error occurred while fetching the data.")
        }
        $("#loader").attr("hidden", "true");
    }

    function loadDataWithTimeout(url, timeoutDuration, onSuccessCallback, onFailCallback) {
        var timeout = undefined;
        apiRequestRunning = true;

        const xhr = $.getJSON(url)
            .done(function (data) {
                apiRequestRunning = false;
                if (timeout !== undefined) {
                    clearTimeout(timeout);
                }
                onSuccessCallback(data);
            })
            .fail(onFailCallback);

        timeout = setTimeout(function () {
            if (xhr.readyState !== 4) {
                xhr.abort();
                apiRequestRunning = false;
            }
        }, timeoutDuration);
    }

    function refreshVisualization(dataUrlPathId, chartWrapperId) {
        var jsonSrc = $(`#${dataUrlPathId}`).text();
        if (jsonSrc.length !== 0) {
            var chartUrl = JSON.parse(jsonSrc);
            var startDate = new Date($("#start-date").val());
            var startDateEpoch = startDate.getTime() / 1000;
            var endDate = new Date($("#end-date").val());
            var endDateEpoch = endDate.getTime() / 1000;

            var urlStr =
                chartUrl +
                "/" +
                startDateEpoch +
                "/" +
                endDateEpoch;

            $("#loader").removeAttr("hidden");
            loadDataWithTimeout(
                urlStr,
                timeoutDuration,
                function (chartData) { onDataLoadSuccess(chartData, chartWrapperId) },
                onDataLoadError
            )
        }
    }

    function autoRefresh() {
        refreshVisualization("bf-visualization-url", "bf-visualization");
    }

    setDefaultDateTime();
    $("#main-form").on("submit", autoRefresh);
});