$(document).ready(function () {
    function setDefaultDateTime() {
        var now = moment();
        var oneDayAgo = now.clone().subtract(1, "days");
        var formattedNow = now.format("YYYY-MM-DDTHH:mm");
        var formattedOneDayAgo = oneDayAgo.format("YYYY-MM-DDTHH:mm");

        $("#start-date").val(formattedOneDayAgo);
        $("#end-date").val(formattedNow);
    }

    setDefaultDateTime();

    $("#export-form").submit(function (event) {
        event.preventDefault();

        var startDate = $("#start-date").val();
        var startTimestamp = moment(startDate).unix();
        var endDate = $("#end-date").val();
        var endTimestamp = moment(endDate).unix();
        var jsonSrc = $("#export-url").text();
        var exportUrl = JSON.parse(jsonSrc);
        var urlStr = exportUrl + "/" + startTimestamp + "/" + endTimestamp;

        $(this).attr("action", urlStr);
        this.submit();
    });
});
