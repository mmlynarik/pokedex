const notificationStyles = {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "10px 20px",
    backgroundColor: "#333",
    color: "#fff",
    borderRadius: "5px",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    zIndex: "1000",
};

document.addEventListener("notification", (e) => {
    const message = e.detail.join(', ');

    const notificationElem = document.createElement("div");
    notificationElem.textContent = message;
    Object.assign(notificationElem.style, notificationStyles);

    document.body.appendChild(notificationElem);

    setTimeout(() => {
        notificationElem.remove();
    }, 5000);
});