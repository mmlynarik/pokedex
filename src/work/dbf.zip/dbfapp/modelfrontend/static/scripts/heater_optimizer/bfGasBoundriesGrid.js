import { getValidatorsGetter, isGreaterEqThan, isNotEmpty } from "../validators.js";

/* Validators */
const greaterEqThanZero = isGreaterEqThan(0);

const VALIDATORS = {
    min: [
        [isNotEmpty, "Minimum musí byť zadané!"],
        [greaterEqThanZero, "Minimum musí byť rovné alebo väčšie ako 0"],
    ],
    max: [
        [isNotEmpty, "Výhrevnosť musí byť zadaná!"],
        [greaterEqThanZero, "Výhrevnosť musí byť vyššia ako 0."],
    ],
}
const getValidators = getValidatorsGetter(VALIDATORS);


/* Row Height Management */
let minRowHeight = 25;
let currentRowHeight;

const updateRowHeight = (params) => {
    const bodyViewport = document.querySelector(".ag-body-viewport");
    if (!bodyViewport) return;

    const gridHeight = bodyViewport.clientHeight;
    const renderedRowCount = params.api.getDisplayedRowCount();

    if (renderedRowCount * minRowHeight >= gridHeight) {
        if (currentRowHeight !== minRowHeight) {
            currentRowHeight = minRowHeight;
            params.api.resetRowHeights();
        }
    } else {
        currentRowHeight = Math.floor(gridHeight / renderedRowCount);
        params.api.resetRowHeights();
    }
};


/* Input handler */
const handleDataEdit = (event) => {
    const changedColId = event.colDef.field;
    const validators = getValidators(changedColId);

    const warnings = [];
    validators.forEach(([validator, warningMsg]) => {
        const isValid = validator(event.value);

        if (!isValid) {
            event.node.setDataValue(changedColId, event.oldValue);
            warnings.push(warningMsg);
        }
    });

    if (warnings.length) {
        const event = new CustomEvent("notification", { detail: warnings });
        document.dispatchEvent(event);
    }
};

/* Grid Definiton */
const gridOptions = {
    defaultColDef: {
        width: 133.34,
        resizable: false,
        editable: true,
    },
    columnDefs: [
        {
            field: "gas",
            headerName: "Plyn",
            editable: false,
            headerClass: "bf-inputs-header"
        },
        {
            field: "min",
            headerName: "Min [Nm3/h]",
            headerClass: "bf-inputs-header",
            cellDataType: 'number',
        },
        {
            field: "max",
            headerName: "Max [Nm3/h]",
            headerClass: "bf-inputs-header",
            cellDataType: 'number',
        }
    ],
    domLayout: 'print',
    singleClickEdit: true,
    onCellValueChanged: handleDataEdit,
};

export { gridOptions };