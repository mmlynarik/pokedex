import { gridOptions as gasPropertiesGridOptions } from "./gasPropertiesGrid.js";
import { gridOptions as bfHeaterSettingsGridOptions } from "./bfHeaterSettingsGrid.js";
import { gridOptions as bfGasBoundriesGridOptions } from "./bfGasBoundriesGrid.js";
import { gridOptions as optimizationResultGridOptions } from "./bfOptimizationResult.js";

const CSRF_TOKEN = document.getElementsByName("csrfmiddlewaretoken")[0].value;

const HEATERS_COUNT = 4;
const BF_HEATER_GRID_WRAPPER_ID = 'bf-heater';
const BF_HEATER_SETTINGS_GRID_ID_POSTFIX = 'settings';
const BF_GAS_BOUNDRIES_GRID_ID_POSTFIX = 'gas-limits';
const BF_GAS_PROPERTIES_GRID_ID = 'gas-properties-grid';
const BF_OPTIMIZATION_RESULT_GRID_ID = 'optimization-result';

window.agGridApiMap = { "heaters": [] };

const getHeaterWrapperId = (heaterIdx) => `${BF_HEATER_GRID_WRAPPER_ID}-${heaterIdx}`;

const getBfSettingsContainerId = (parentContainerId) => `${parentContainerId}-${BF_HEATER_SETTINGS_GRID_ID_POSTFIX}`;

const getBfGasBoundriesContainerId = (parentContainerId) => `${parentContainerId}-${BF_GAS_BOUNDRIES_GRID_ID_POSTFIX}`;

const getBfOptimizationResultContainerId = (parentContainerId) => `${parentContainerId}-${BF_OPTIMIZATION_RESULT_GRID_ID}`;

const createGridContainers = (destElem, heaterIdx) => {
    const wrapperId = getHeaterWrapperId(heaterIdx);
    const bfHeaterGridsWrapper = document.createElement('div');
    bfHeaterGridsWrapper.id = wrapperId;

    const containerIdsToCreate = [
        getBfSettingsContainerId(wrapperId),
        getBfGasBoundriesContainerId(wrapperId),
        getBfOptimizationResultContainerId(wrapperId),
    ];

    const createdContainer = [];
    for (let newContainerId of containerIdsToCreate) {
        const newContainer = document.createElement('div');
        //newContainer.style.height = '100%';
        newContainer.id = newContainerId;

        createdContainer.push(newContainer);
        bfHeaterGridsWrapper.appendChild(newContainer);
    }

    destElem.appendChild(bfHeaterGridsWrapper);

    return createdContainer;
};

const HEATERS_NUMBERS = [11, 12, 13, 14];

const createBfOptimizationInputGrids = (destinationElemId, heaterIdx) => {
    const heaterNumber = HEATERS_NUMBERS[heaterIdx];
    const gridContainerElems = createGridContainers(destinationElemId, heaterIdx);
    const [bfSettingsGridElem, bfGasBoundriesGridElem, optimizationResultGridElem] = gridContainerElems;

    let bfHeaterSettingsGridApi;
    bfHeaterSettingsGridApi = agGrid.createGrid(bfSettingsGridElem, bfHeaterSettingsGridOptions(heaterNumber));

    let bfHeaterGasBoundriesGridApi;
    bfHeaterGasBoundriesGridApi = agGrid.createGrid(bfGasBoundriesGridElem, bfGasBoundriesGridOptions);

    let optimizationResultGridApi;
    optimizationResultGridApi = agGrid.createGrid(optimizationResultGridElem, optimizationResultGridOptions);

    window.agGridApiMap["heaters"] = [
        ...window.agGridApiMap["heaters"],
        {
            settings: bfHeaterSettingsGridApi,
            gasBoundries: bfHeaterGasBoundriesGridApi,
            optimizationResult: optimizationResultGridApi,
        }
    ];
};


function calculateMinHeatingValue(constant, temperature) {
    const result = (0.0081 * (constant + temperature) - 7.1257) * 1000;
    return parseFloat(result.toFixed(0))
}

window.calculateMinHeatingValue = calculateMinHeatingValue;

const initBfGridValues = (heaterIdx) => {
    const { settings, gasBoundries, optimizationResult } = window.agGridApiMap["heaters"][heaterIdx];

    let initialTemperatureAim = 1360;
    let initialConstantValue = 30;

    settings.setGridOption("rowData", [
        { setting: "Vykurovanie", aim: 1 },
        { setting: "Požadovaná teplota [°C]", aim: initialTemperatureAim },
        { setting: "Konštanta [°C]", aim: initialConstantValue },
        { setting: "Min. výhrevnosť [MJ/m3]", aim: calculateMinHeatingValue(initialConstantValue, initialTemperatureAim) },
    ]);

    gasBoundries.setGridOption("rowData", [
        { gas: "VPP + ZP", min: 30000, max: 45000 },
        { gas: "KP", min: 0, max: 2200 },
    ]);

    optimizationResult.setGridOption("rowData", [
        { item: "VPP [Nm3/h]", recommended: null },
        { item: "KP [Nm3/h]", recommended: null },
        { item: "ZP [Nm3/h]", recommended: null },
        { item: "Obohatenie [%]", recommended: null },
        { item: "Výhrevnosť [MJ/m3]", recommended: null },
        { item: "Cena [€ za Nm3/h]", recommended: null },
    ]);
}

const createBfGasPropertiesGrid = () => {
    let gasPropertiesGridApi;
    gasPropertiesGridApi = agGrid.createGrid(document.getElementById(BF_GAS_PROPERTIES_GRID_ID), gasPropertiesGridOptions);

    window.agGridApiMap["gasBoundries"] = gasPropertiesGridApi;
}

const initBfGasPropertiesGridValues = () => {
    const bfGasPropertiesGridApi = window.agGridApiMap["gasBoundries"];

    bfGasPropertiesGridApi.setGridOption("rowData", [
        { gas: "VPP", calorificValue: 3000, price: 5 },
        { gas: "KP", calorificValue: 9200, price: 50 },
        { gas: "ZP", calorificValue: 35700, price: 500 },
    ]);
}

function addTooltipToMinHeatingValue() {
    for (let heaterIdx = 0; heaterIdx < HEATERS_COUNT; heaterIdx++) {
        const gridElement = document.querySelector(`#bf-heater-${heaterIdx}-settings`);
        const rows = gridElement.querySelectorAll('.ag-row');

        rows.forEach(row => {
            const settingCell = row.querySelector('.ag-cell[col-id="setting"]');

            if (settingCell && settingCell.innerText === "Min. výhrevnosť [MJ/m3]") {
                let tooltip;

                row.addEventListener('mouseenter', () => {
                    if (!tooltip) {
                        tooltip = document.createElement('div');
                        tooltip.classList.add('tooltip');
                        tooltip.innerText = 'Minimálna výhrevnosť je vypočítaná na základe vzorca: (0.0081 * (konštanta + požadovaná teplota) - 7.1257) * 1000';
                        document.body.appendChild(tooltip);
                    }

                    tooltip.style.visibility = "hidden";
                    tooltip.style.display = "block";

                    const rect = settingCell.getBoundingClientRect();
                    const tooltipLeft = rect.left + window.scrollX + rect.width / 2 - tooltip.offsetWidth / 2 + 100;
                    const tooltipTop = rect.top + window.scrollY - tooltip.offsetHeight - 5;

                    tooltip.style.left = `${tooltipLeft}px`;
                    tooltip.style.top = `${tooltipTop}px`;
                    tooltip.style.visibility = "visible";
                    tooltip.classList.add('visible');
                });

                row.addEventListener('mouseleave', () => {
                    if (tooltip) {
                        tooltip.remove();
                        tooltip = null;
                    }
                });
            }
        });
    }
}

const viewInit = () => {
    const destinationElem = document.getElementById("bf-heater-deck");

    createBfGasPropertiesGrid();
    initBfGasPropertiesGridValues();

    for (let heaterIdx = 0; heaterIdx < HEATERS_COUNT; heaterIdx++) {
        createBfOptimizationInputGrids(destinationElem, heaterIdx);
        initBfGridValues(heaterIdx);
    }

    addTooltipToMinHeatingValue();
}

window.addEventListener("load", viewInit);

const startOptimization = () => {
    const loadingIndicator = document.getElementById("loading-indicator");
    loadingIndicator.classList.add("show");

    const messageContainer = document.getElementById('optimization-message-container');
    if (messageContainer) {
        messageContainer.classList.remove('show');
        messageContainer.innerHTML = '';
    }

    const totalPriceContainer = document.getElementById('price-container');
    if (totalPriceContainer) {
        totalPriceContainer.classList.remove('show');
        totalPriceContainer.innerHTML = '';
    }

    const gasProperties = {};
    const heaterProperties = [];

    const bfGasPropertiesGridApi = window.agGridApiMap["gasBoundries"];
    bfGasPropertiesGridApi.forEachNode(node => gasProperties[node.data.gas] = { calorific_value: node.data.calorificValue, price: node.data.price });

    for (let heaterGridApis of window.agGridApiMap["heaters"]) {
        const { settings: settingsGridApi, gasBoundries: gasBoundriesGridApi } = heaterGridApis;
        const settings = {};
        const mapKeys = {
            "Vykurovanie": "is_on",
            "Požadovaná teplota [°C]": "temperature_aim_celsius",
            "Konštanta [°C]": "mutable_constant",
            "Min. výhrevnosť [MJ/m3]": "min_heating_value"
        };
        settingsGridApi.forEachNode(r => {
            settings[mapKeys[r.data.setting]] = r.data.aim
        });

        const gasBoundries = {};
        gasBoundriesGridApi.forEachNode(r => {
            gasBoundries[r.data.gas] = { minimum: r.data.min, maximum: r.data.max }
        });

        heaterProperties.push({
            settings: settings,
            gas_boundries: gasBoundries,
        })
    }

    const requestBody = {
        gas_properties: gasProperties,
        heaters: heaterProperties,
    }

    fetch('bf_heater_optimizer/start_optimization', {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-CSRFToken': CSRF_TOKEN,
        },
        body: JSON.stringify(requestBody)
    }).then(response => {
        if (response.ok) {
            return response.json();
        }
        return response.json();
    }).then(responseBody => {
        let totalPrice = 0;
        let hasValidPrice = false;
        let optimizationNotAvailable = false;

        for (let heaterIdx in responseBody.heaters) {
            const heaterResult = responseBody.heaters[heaterIdx];

            let vppValue = null;
            let zpValue = null;

            const rowData = Object.entries(heaterResult).map(([itemType, recommendation]) => {
                if (recommendation === -1.0) {
                    optimizationNotAvailable = true;
                    return { item: itemType, recommended: null };
                }

                if (itemType === "VPP [Nm3/h]") vppValue = recommendation;
                if (itemType === "ZP [Nm3/h]") zpValue = recommendation;

                if (itemType === "Cena [€ za Nm3/h]" && recommendation !== null) {
                    totalPrice += recommendation;
                    hasValidPrice = true;
                    recommendation = parseFloat(recommendation.toFixed(2));
                } else if (recommendation !== null) {
                    recommendation = parseFloat(recommendation.toFixed(0));
                }

                return { item: itemType, recommended: recommendation };
            });

            let enrichmentValue = null;
            if (vppValue !== null && zpValue !== null) {
                enrichmentValue = parseFloat(((zpValue / (vppValue + zpValue)) * 100).toFixed(2));
            }
            if (vppValue === 0 && zpValue === 0) {
                enrichmentValue = 0.0;
            }
            if (vppValue === null && zpValue === null) {
                enrichmentValue = null;
            }
            rowData.splice(3, 0, { item: "Obohatenie [%]", recommended: enrichmentValue });

            const { optimizationResult: optimizationResultGridApi } = window.agGridApiMap["heaters"][heaterIdx];
            optimizationResultGridApi.setGridOption("rowData", rowData);
        }

        if (optimizationNotAvailable) {
            if (messageContainer) {
                messageContainer.innerHTML = 'Požadovanú výhrevnosť nie je možné dosiahnuť s danými obmedzeniami.';
                messageContainer.classList.add('show');
            }
        } else {
            if (messageContainer) {
                messageContainer.classList.remove('show');
                messageContainer.innerHTML = '';
            }
        }

        const totalPriceContainer = document.getElementById('price-container');
        if (hasValidPrice) {
            const validHeaterCount = responseBody.heaters.filter(h =>
                h["Cena [€ za Nm3/h]"] !== -1.0
                && h["Cena [€ za Nm3/h]"] !== null
                && h["Cena [€ za Nm3/h]"] !== 0.0
            ).length;
            const averagePrice = validHeaterCount > 0 ? totalPrice / validHeaterCount : null;

            const formattedTotalPrice = new Intl.NumberFormat('sk-SK', {
                style: 'decimal',
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(totalPrice);

            let priceText = `Celková cena: <span>${formattedTotalPrice} €</span>`;

            if (averagePrice !== null) {
                const formattedAvgPrice = new Intl.NumberFormat('sk-SK', {
                    style: 'decimal',
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }).format(averagePrice);

                priceText += ` | Priemerná cena: <span>${formattedAvgPrice} €</span>`;
            }

            totalPriceContainer.innerHTML = priceText;
            totalPriceContainer.classList.add('show');
        } else {
            totalPriceContainer.classList.remove('show');
            totalPriceContainer.innerHTML = '';
        }

    }).finally(() => {
        loadingIndicator.classList.remove("show");
    });
}

document.getElementById("run-optimization").addEventListener('click', startOptimization);