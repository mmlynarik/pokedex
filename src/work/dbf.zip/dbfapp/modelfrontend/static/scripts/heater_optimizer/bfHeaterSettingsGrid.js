import { getValidatorsGetter, isGreaterEqThan } from "../validators.js";

/* Validators */
const greaterEqThanZero = isGreaterEqThan(0);

const VALIDATORS = {
    aim: [
        [greaterEqThanZero, "Hodnota musí byť rovná alebo väčšia ako 0"],
    ],
}

const getValidators = getValidatorsGetter(VALIDATORS);

/* Input handler */
const handleDataEdit = (event) => {
    const changedColId = event.colDef.field;
    const validators = getValidators(changedColId);

    const warnings = [];
    validators.forEach(([validator, warningMsg]) => {
        const isValid = validator(event.value);

        if (!isValid) {
            event.node.setDataValue(changedColId, event.oldValue);
            warnings.push(warningMsg);
        }
    });

    if (warnings.length) {
        const event = new CustomEvent("notification", { detail: warnings });
        document.dispatchEvent(event);
    }
};

const handleCellClick = (params) => {
    /* First row with number wich representing bool value */
    console.log(params);
    if (params.rowIndex === 0 && params.colDef.field === 'aim') {
        params.node.setDataValue('aim', Math.abs(params.value - 1));
    }
};

const handleCellValueChanged = (params) => {
    handleDataEdit(params);

    if (params.data.setting === "Požadovaná teplota [°C]" || params.data.setting === "Konštanta [°C]") {
        const api = params.api;
        let temperatureNode, constantNode, minHeatingNode;
        api.forEachNode(node => {
            if (node.data.setting === "Požadovaná teplota [°C]") {
                temperatureNode = node;
            } else if (node.data.setting === "Konštanta [°C]") {
                constantNode = node;
            } else if (node.data.setting === "Min. výhrevnosť [MJ/m3]") {
                minHeatingNode = node;
            }
        });
        if (temperatureNode && constantNode && minHeatingNode) {
            const temperature = temperatureNode.data.aim;
            const constant = constantNode.data.aim;
            const newMinHeatingValue = window.calculateMinHeatingValue(constant, temperature);
            minHeatingNode.setDataValue("aim", newMinHeatingValue);
        }
    }
}

/* Grid Definiton */
const gridOptions = (heaterNumber) => ({
    defaultColDef: {
        width: 200,
        resizable: false,
    },
    columnDefs: [
        {
            field: "setting",
            headerName: `Ohrievač č. ${heaterNumber}`,
            headerClass: "bf-inputs-header",
            cellDataType: 'text',
        },
        {
            field: "aim",
            headerName: "Cieľ",
            headerClass: "bf-inputs-header",
            editable: (params) => {
                if (params.colDef.field === 'aim' && params.data.setting === "Min. výhrevnosť [MJ/m3]") {
                    return false;
                }
                return params.node.rowIndex !== 0;
            },
            valueFormatter: (params) => params.node.rowIndex !== 0 ? params.value : params.value ? '✔️' : '❌',
            valueParser: (params) => {
                return isNaN(params.newValue) ? 0 : Number(params.newValue);
            }
        }
    ],
    domLayout: 'print',
    singleClickEdit: true,
    onCellClicked: handleCellClick,
    onCellValueChanged: handleCellValueChanged,
});

export { gridOptions };