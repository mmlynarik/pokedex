import { getValidatorsGetter, isGreaterThan, isNotEmpty } from "../validators.js";

/* Validators */
const greaterThanZero = isGreaterThan(0);

const VALIDATORS = {
    price: [
        [isNotEmpty, "Cena musí byť zadaná!"],
        [greaterThanZero, "Cena musí byť vyššia ako 0!"],
    ],
    calorificValue: [
        [isNotEmpty, "Výhrevnosť musí byť zadaná!"],
        [greaterThanZero, "Výhrevnosť musí byť vyššia ako 0."],
    ],
}
const getValidators = getValidatorsGetter(VALIDATORS);


/* Input handler */
const handleDataEdit = (event) => {
    const changedColId = event.colDef.field;
    const validators = getValidators(changedColId);

    const warnings = [];
    validators.forEach(([validator, warningMsg]) => {
        const isValid = validator(event.value);

        if (!isValid) {
            event.node.setDataValue(changedColId, event.oldValue);
            warnings.push(warningMsg);
        }
    });

    if (warnings.length) {
        const event = new CustomEvent("notification", { detail: warnings });
        document.dispatchEvent(event);
    }
};

/* Grid Definiton */
const gridOptions = {
    defaultColDef: {
        width: 273.67,
        resizable: false,
    },
    columnDefs: [
        {
            field: "gas",
            headerName: "Plyn",
            headerClass: "bf-inputs-header"
        },
        {
            field: "calorificValue",
            headerName: "Výhrevnosť [MJ/m3]",
            headerClass: "bf-inputs-header",
            cellDataType: 'number',
            editable: true,
        },
        {
            field: "price",
            headerName: "Cena [€ za Nm3/h]",
            headerClass: "bf-inputs-header",
            cellDataType: 'number',
            editable: true,
        },
    ],
    domLayout: 'print',
    singleClickEdit: true,
    onCellValueChanged: handleDataEdit
};

export { gridOptions };