/* Grid Definiton */
const gridOptions = {
    defaultColDef: {
        width: 200,
        resizable: false,
    },
    columnDefs: [
        {
            field: "item",
            headerName: "Položka",
            headerClass: "bf-optimization-result-header",
        },
        {
            field: "recommended",
            headerName: "Odporúčanie",
            headerClass: "bf-optimization-result-header",
            cellDataType: 'number',
        },
    ],
    domLayout: 'print',
};

export { gridOptions };