import { gasTypes } from "./common.js";

const gasRegimesDefaultRow = {
  id: 0,
  delete: "",
  duration: 100,
  cog_flow: 0,
  cog_temp: 0,
  cog_comp: "Comp1",
  bfg_flow: 0,
  bfg_temp: 0,
  bfg_comp: "Comp1",
  ng_flow: 0,
  ng_temp: 0,
  ng_comp: "Comp1",
  air_flow: 0,
  air_temp: 0,
  air_comp: "Comp1",
};


const createAddGasRegimesDefaultRowHandler = (gridApi) => () => {
  const gasRegimesTableData = [];
  gridApi.forEachNode((node) => gasRegimesTableData.push(node.data));

  const newId =
    gasRegimesTableData.length === 0 ? 0 : Math.max(...gasRegimesTableData.map((row) => row.id)) + 1;
  const newRow = { ...gasRegimesDefaultRow, id: newId };

  gridApi.applyTransaction({
    add: [newRow],
  });
};


const cellClassRules = {
  "gas-regime-cog-col": cell => {
    return cell.colDef.field.split("_").at(0) === "cog"
  },
  "gas-regime-bfg-col": cell => {
    return cell.colDef.field.split("_").at(0) === "bfg"
  },
  "gas-regime-ng-col": cell => {
    return cell.colDef.field.split("_").at(0) === "ng"
  },
  "gas-regime-air-col": cell => {
    return cell.colDef.field.split("_").at(0) === "air"
  }
}


const gridOptions = {
  rowData: [],
  domLayout: "autoHeight",
  defaultColDef: {
    editable: true,
    resizable: false,
  },
  columnTypes: {
    flow: {
      headerName: "Flow",
      valueFormatter: (params) => `${params.value.toFixed(0)} m3/h`,
    },
    temperature: {
      headerName: "Temperature",
      valueFormatter: (params) => `${params.value.toFixed(0)} °C`,
    },
    composition: {
      headerName: "Composition",
      cellDataType: "text"
    },
  },
  // TODO make selector from gas composition table
  columnDefs: [
    {
      children: [{ field: "id", headerName: "", hide: true }],
    },
    {
      headerName: "",
      children: [
        {
          field: "delete",
          headerName: "",
          width: 60,
          valueFormatter: (_) => "❌",
          editable: false,
        },
      ],
    },
    {
      headerName: "",
      children: [{ field: "duration"}],
    },
    ...gasTypes.map((gas) => {
      return {
        headerName: gas.toUpperCase(),
        children: [
          { field: `${gas}_flow`, type: "flow", flex: 1, cellClassRules: cellClassRules},
          { field: `${gas}_temp`, type: "temperature", flex: 1, cellClassRules: cellClassRules },
          { field: `${gas}_comp`, type: "composition", flex: 1, cellClassRules: cellClassRules },
        ],
      };
    }),
  ],
  getRowId: (params) => String(params.data.id),
  onCellClicked: (cell) => {
    if (cell.column.colId === "delete") {
      cell.api.applyTransaction({
        remove: [{ id: cell.node.id }],
      });
    }
  },
};

export { createAddGasRegimesDefaultRowHandler, gridOptions };

