import { gasTypes } from "./common.js";

const gasCompositionDefaultRow = {
    id: 0,
    delete: "",
    name: "New",
    type: "cog",
    c2h2: 0.0,
    c2h4: 0.0,
    c2h6: 0.0,
    c3h8: 0.0,
    ch4: 0.0,
    co: 0.0,
    co2: 0.0,
    h2: 0.0,
    h2o: 0.0,
    n2: 1.0,
    o2: 0.0,
};


const createAddGasCompositionsDefaultRowHandler = (gridApi) => () => {
    const gasCompositionsTableData = [];
    gridApi.forEachNode((node) => gasCompositionsTableData.push(node.data));

    const newId =
        gasCompositionsTableData.length === 0 ? 0 : Math.max(...gasCompositionsTableData.map((row) => row.id)) + 1;
    const newRow = { ...gasCompositionDefaultRow, id: newId };

    gridApi.applyTransaction({
        add: [newRow],
    });
};



const gridOptions = {
    rowData: [],
    domLayout: "autoHeight",
    rowClassRules: {
        "cog-row": row => row.node.data.type === "cog",
        "bfg-row": row => row.node.data.type === "bfg",
        "ng-row": row => row.node.data.type === "ng",
        "air-row": row => row.node.data.type === "air"
    },
    defaultColDef: {
        editable: false,
        resizable: false,
    },
    columnTypes: {
        composition: {
            cellDataType: "number",
            width: 90,
            valueFormatter: (params) => `${(params.value * 100).toFixed(1)} %`,
        },
    },

    columnDefs: [
        {
            children: [{ field: "id", headerName: "", hide: true }],
        },
        {
            headerName: "",
            children: [
                {
                    field: "delete",
                    headerName: "",
                    width: 60,
                    valueFormatter: (_) => "❌",
                    editable: false,
                    hide: true
                },
            ],
        },
        {
            headerName: "",
            children: [{ field: "name", width: 140 }],
        },
        {
            headerName: "",
            children: [{
                field: "type",
                width: 140,
                cellEditorParams: { values: gasTypes },
                cellDataType: "text",
                cellEditor: "agSelectCellEditor",
            }],
        },
        {
            headerName: "Composition [mol %]",
            children: [
                { field: "c2h2", headerName: "C₂H₂", type: "composition" },
                { field: "c2h4", headerName: "C₂H₄", type: "composition" },
                { field: "c2h6", headerName: "C₂H₆", type: "composition" },
                { field: "c3h8", headerName: "C₃H₈", type: "composition" },
                { field: "ch4", headerName: "CH₄", type: "composition" },
                { field: "co", headerName: "CO", type: "composition" },
                { field: "co2", headerName: "CO₂", type: "composition" },
                { field: "h2", headerName: "H₂", type: "composition" },
                { field: "h2o", headerName: "H₂O", type: "composition" },
                { field: "n2", headerName: "N₂", type: "composition" },
                { field: "o2", headerName: "O₂", type: "composition" },
            ],
        },
    ],
    getRowId: (params) => String(params.data.id),
    onCellClicked: (cell) => {
        if (cell.column.colId === "delete") {
            cell.api.applyTransaction({
                remove: [{ id: cell.node.id }],
            });
        }
    },
};

export { createAddGasCompositionsDefaultRowHandler, gridOptions };

