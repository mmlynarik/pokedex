import { createAddGasCompositionsDefaultRowHandler, gridOptions as gasCompositionGridOptions } from "./gasChemGrid.js";
import { createAddGasRegimesDefaultRowHandler, gridOptions as gasRegimesGridOptions } from "./gasRegimesGrid.js";
import { gridOptions as initialDataGridOptions } from "./initialDataGrid.js";

const gasRegimesElem = document.getElementById("gas-regimes");
const initialDataElem = document.getElementById("gas-initial-data");
const addRegimeRowBtn = document.getElementById("gas-regimes-add-row");
const getPlotDataBtn = document.getElementById("get-plot-data");
const stoveChartElem = document.getElementById("stoves-chart");
const gasCompositionElem = document.getElementById("gas-compositions");
const addCompositionRowBtn = document.getElementById("gas-compositions-add-row");


const gridInitialDataApi = agGrid.createGrid(initialDataElem, initialDataGridOptions);
const gridGasRegimesDataApi = agGrid.createGrid(gasRegimesElem, gasRegimesGridOptions);
const gridGasCompositionDataApi = agGrid.createGrid(gasCompositionElem, gasCompositionGridOptions);

addRegimeRowBtn.onclick = createAddGasRegimesDefaultRowHandler(gridGasRegimesDataApi)
addCompositionRowBtn.onclick = createAddGasCompositionsDefaultRowHandler(gridGasCompositionDataApi)

const updateChart = (chartData) => {
  const data = chartData.data || [];
  const layout = chartData.layout || {};
  const config = chartData.config || { displayModeBar: false };
  Plotly.react(stoveChartElem, data, layout, config);
};

getPlotDataBtn.onclick = () => {
  const initialData = [];
  gridInitialDataApi.forEachNode((node) => initialData.push(node.data));

  const gasRegimesTableData = [];
  gridGasRegimesDataApi.forEachNode((node) => gasRegimesTableData.push(node.data));

  const gasCompositionsTableData = [];
  gridGasCompositionDataApi.forEachNode((node) => gasCompositionsTableData.push(node.data));

  const data = {
    initial_data: initialData.at(0),
    regimes: gasRegimesTableData,
    compositions: gasCompositionsTableData
  };

  const jsonString = JSON.stringify(data);
  const base64Str = btoa(jsonString);
  const base64Safe = encodeURIComponent(base64Str);

  fetch(`json/${base64Safe}`)
    .then((response) => {
      return response.json();
    })
    .then(
      body => updateChart(body)
    );
};

function fillTable(dataId) {
  const jsonSrc = $(`#${dataId}`).text();
  if (jsonSrc.length === 0) return;

  const base64EncodedTableData = JSON.parse(jsonSrc);

  console.log(base64EncodedTableData)

  const tableData = JSON.parse(atob(base64EncodedTableData))

  // TODO refactor - make initial data as separate level 
  gridInitialDataApi.applyTransaction({ add: [tableData["initial_data"]] });
  gridGasRegimesDataApi.applyTransaction({ add: tableData["regimes"] })
  gridGasCompositionDataApi.applyTransaction({ add: tableData["compositions"] })
}

fillTable("base64-encoded-table-data");

export { gridGasCompositionDataApi, gridGasRegimesDataApi, gridInitialDataApi };

