const gridOptions = {
  rowData: [],
  defaultColDef: {
    editable: true,
    resizable: false,
  },
  columnDefs: [
    { field: "stove_id", headerName: "ID", flex: 1, minWidth: 120, maxWidth: 200},
    { 
        field: "dome_temp",
        headerName: "Teplota kopule",
        flex: 1, minWidth: 120, maxWidth: 200,
        valueFormatter: (params) => `${params.value.toFixed(0)} °C`
    },
    { 
        field: "stack_temp",
        headerName: "Teplota šachty",
        flex: 1,
        minWidth: 120,
        maxWidth: 200,
        valueFormatter: (params) => `${params.value.toFixed(0)} °C`
    },
    { 
        field: "wastegas_temp",
        headerName: "Teplota v odťahu",
        flex: 1,
        minWidth: 120,
        maxWidth: 200,
        valueFormatter: (params) => `${params.value.toFixed(0)} °C`
    },
  ],
  domLayout: "autoHeight",
};

export { gridOptions };

