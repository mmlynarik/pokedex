
const gasTypes = ["cog", "bfg", "ng", "air"];

export { gasTypes };

