const dummyValidator = _ => true;

const isNotEmpty = (val) => {
    return val !== '' && val != null;
}

const isLowerThan = (upperBound) => {
    return val => val < upperBound;
}

const isLowerEqThan = (upperBound) => {
    return val => val <= upperBound;
}

const isGreaterThan = (lowerBound) => {
    return val => val > lowerBound;
}

const isGreaterEqThan = (lowerBound) => {
    return val => val >= lowerBound;
}

const isEqual = (exacValue) => {
    return val => val === exacValue;
}

const getValidatorsGetter = (validators) => {
    return (key) => validators[key] ?? [dummyValidator];
}


export { isEqual, isGreaterThan, isGreaterEqThan, isLowerThan, isLowerEqThan, isNotEmpty, getValidatorsGetter };