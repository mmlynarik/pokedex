$(document).ready(function () {
    function doRefresh() {
      if ($("#autoreload-on").is(":checked")) {
        var nowString = moment().format("YYYY-MM-DDTHH:mm");
        if (nowString !== $("#model-now").val()) {
          $("#model-now").val(nowString).trigger("auto-change");
        }
      }
    }
  
    function turnAutoreloadOff() {
      $("#autoreload-on").prop("checked", false);
    }
  
    function refreshChart(dataUrlPathId, chartWrapperId) {
      var jsonSrc = $(`#${dataUrlPathId}`).text();
      if (jsonSrc.length !== 0) {
        var chartUrl = JSON.parse(jsonSrc);
        var chartNow = new Date($("#model-now").val());
        var chartNowEpoch = chartNow.getTime() / 1000;
        var lookbackSeconds = $("#lookback-window").val();
        var forecastSeconds = $("#forecast-window").val();
        var urlStr = chartUrl + "/" + chartNowEpoch + "/" + lookbackSeconds + "/" + forecastSeconds;
  
        $("#loader").removeAttr("hidden");
        $.getJSON(urlStr, function (chartData) {
          var data = chartData.data || [];
          var layout = chartData.layout || {};
          var config = chartData.config || { displayModeBar: false };
          Plotly.react(chartWrapperId, data, layout, config);
          $("#loader").attr("hidden", "true");
        });
      }
    }
  
    function autoRefresh() {
      refreshChart("pci-chart-url", "pci-chart");
      
    }
  
    function manualRefresh() {
      turnAutoreloadOff();
      autoRefresh();
    }
  
    $("#main-form").on("submit", manualRefresh);
    $("#model-now").on("auto-change", autoRefresh);
    $("#model-now").on("change", turnAutoreloadOff);
    $("#autoreload-on").on("change", function () {
      if ($("#autoreload-on").is(":checked")) {
        autoRefresh();
      }
    });
  
    doRefresh();
    setInterval(doRefresh, 1000);
  });
  