from contextlib import contextmanager

from django.db import connections


class QueriesDisabledError(Exception):
    pass


def _raise_exception(execute, sql, params, many, context):
    raise QueriesDisabledError(sql)


def _disable_queries():
    for connection in connections.all():
        connection.execute_wrappers.append(_raise_exception)


def _enable_queries():
    for connection in connections.all():
        connection.execute_wrappers.pop()


def _are_queries_disabled():
    for connection in connections.all():
        return _raise_exception in connection.execute_wrappers


@contextmanager
def queries_disabled():
    queries_already_disabled = _are_queries_disabled()
    if not queries_already_disabled:
        _disable_queries()
    try:
        yield
    finally:
        if not queries_already_disabled:
            _enable_queries()
