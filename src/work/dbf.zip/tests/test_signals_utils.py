import unittest

import pandas as pd

from dbfcore.dataset.signals.utils import generate_ids


class TestAssignTappingIds(unittest.TestCase):
    def setUp(self):
        self.input_df = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 2, 26, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 3, 5, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 5, 55, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 6, 10, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 7, 34, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 9, 13, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 9, 27, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 10, 7, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002],
                [pd.Timestamp(2023, 1, 1, 13, 52, 0), 10002],
                [pd.Timestamp(2023, 1, 1, 13, 56, 0), 10002],
                [pd.Timestamp(2023, 1, 1, 15, 18, 0), 10003],
                [pd.Timestamp(2023, 1, 1, 15, 58, 0), 10003],
                [pd.Timestamp(2023, 1, 1, 16, 30, 0), 10003],
            ],
            columns=["date", "tapping_number"],
        )

    def test_smoke_default(self):
        actual_df = generate_ids(self.input_df, "tapping_number", "date")

        expected_df = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 2, 26, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 3, 5, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 5, 55, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 6, 10, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 7, 34, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 9, 13, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 9, 27, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 10, 7, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 52, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 56, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 15, 18, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 15, 58, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 16, 30, 0), 10003, 100032023],
            ],
            columns=["date", "tapping_number", "id"],
        )

        pd.testing.assert_frame_equal(expected_df, actual_df)

    def test_smoke_with_output_id_col(self):
        actual_df = generate_ids(self.input_df, "tapping_number", "date", "final_id")

        expected_df = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 2, 26, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 3, 5, 0), 12509, 125092023],
                [pd.Timestamp(2023, 1, 1, 5, 55, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 6, 10, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 7, 34, 0), 12510, 125102023],
                [pd.Timestamp(2023, 1, 1, 9, 13, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 9, 27, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 10, 7, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 52, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 56, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 15, 18, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 15, 58, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 16, 30, 0), 10003, 100032023],
            ],
            columns=["date", "tapping_number", "final_id"],
        )

        pd.testing.assert_frame_equal(expected_df, actual_df)

    def test_smoke_with_output_id_col_and_correct_years(self):
        actual_df = generate_ids(self.input_df, "tapping_number", "date", "final_id", True)

        expected_df = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509, 125092022],
                [pd.Timestamp(2023, 1, 1, 2, 26, 0), 12509, 125092022],
                [pd.Timestamp(2023, 1, 1, 3, 5, 0), 12509, 125092022],
                [pd.Timestamp(2023, 1, 1, 5, 55, 0), 12510, 125102022],
                [pd.Timestamp(2023, 1, 1, 6, 10, 0), 12510, 125102022],
                [pd.Timestamp(2023, 1, 1, 7, 34, 0), 12510, 125102022],
                [pd.Timestamp(2023, 1, 1, 9, 13, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 9, 27, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 10, 7, 0), 10001, 100012023],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 52, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 13, 56, 0), 10002, 100022023],
                [pd.Timestamp(2023, 1, 1, 15, 18, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 15, 58, 0), 10003, 100032023],
                [pd.Timestamp(2023, 1, 1, 16, 30, 0), 10003, 100032023],
            ],
            columns=["date", "tapping_number", "final_id"],
        )

        pd.testing.assert_frame_equal(expected_df, actual_df)

    def test_year_correction(self):
        input = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 6, 10, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 10, 7, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002],
            ],
            columns=["date", "tapping_number"],
        )
        output = generate_ids(input, "tapping_number", "date", correct_years=True)

        expected_tapping_ids = [125092022, 125102022, 100012023, 100022023]

        self.assertListEqual(expected_tapping_ids, output.id.to_list())

    def test_no_correction(self):
        input = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 9, 13, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002],
                [pd.Timestamp(2023, 1, 1, 15, 18, 0), 10003],
            ],
            columns=["date", "tapping_number"],
        )
        output = generate_ids(input, "tapping_number", "date")

        expected_tapping_ids = [100012023, 100022023, 100032023]

        self.assertListEqual(expected_tapping_ids, output.id.to_list())

    def test_shuffled_semi_ids_wo_year_correction(self):
        input = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 6, 7, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 8, 10, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002],
            ],
            columns=["date", "tapping_number"],
        )
        output = generate_ids(input, "tapping_number", "date")

        expected_tapping_ids = [125092023, 100012023, 125102023, 100022023]

        self.assertListEqual(expected_tapping_ids, output.id.to_list())

    def test_shuffled_semi_ids_with_year_correction(self):
        input = pd.DataFrame(
            data=[
                [pd.Timestamp(2023, 1, 1, 1, 59, 0), 12509],
                [pd.Timestamp(2023, 1, 1, 6, 7, 0), 10001],
                [pd.Timestamp(2023, 1, 1, 8, 10, 0), 12510],
                [pd.Timestamp(2023, 1, 1, 12, 53, 0), 10002],
            ],
            columns=["date", "tapping_number"],
        )
        output = generate_ids(input, "tapping_number", "date", correct_years=True)

        expected_tapping_ids = [125092022, 100012023, 125102022, 100022023]

        self.assertListEqual(expected_tapping_ids, output.id.to_list())
