import unittest

import torch

from dbfcore.model.utils import FixedInputNormalizer

TOLERANCE = 1e-6


class TestFixedInputNormalizer(unittest.TestCase):

    def test_2D(self):
        data = torch.Tensor([[1.0, 2.0], [3.0, 4.0]])
        mean = torch.Tensor([1.0, 3.0])
        std = torch.Tensor([1.0, 1.0])
        normalizer = FixedInputNormalizer(mean, std)

        result = normalizer(data)

        expected_result = torch.Tensor([[0.0, -1.0], [2.0, 1.0]])
        self.assertTrue(((result - expected_result).abs() < TOLERANCE).all())

        denormalized = normalizer.denormalize(result)

        self.assertTrue(((denormalized - data).abs() < TOLERANCE).all())

    def test_3D(self):
        data = torch.Tensor([[[1.0, 2.0], [1.0, 2.0]], [[3.0, 4.0], [3.0, 4.0]]])
        mean = torch.Tensor([1.0, 3.0])
        std = torch.Tensor([1.0, 1.0])
        normalizer = FixedInputNormalizer(mean, std)

        result = normalizer(data)

        expected_result = torch.Tensor([[[0.0, -1.0], [0.0, -1.0]], [[2.0, 1.0], [2.0, 1.0]]])
        self.assertTrue(((result - expected_result).abs() < TOLERANCE).all())

        denormalized = normalizer.denormalize(result)

        self.assertTrue(((denormalized - data).abs() < TOLERANCE).all())

    def test_std_zero(self):
        mean = torch.Tensor([1.0, 3.0])
        std = torch.Tensor([0.0, 0.0])

        self.assertRaises(ValueError, lambda: FixedInputNormalizer(mean, std))

    def test_random_values(self):
        data = torch.rand(100, 100)
        mean = torch.rand(100)
        std = torch.rand(100)
        normalizer = FixedInputNormalizer(mean, std)

        result = normalizer(data)
        denormalized = normalizer.denormalize(result)

        self.assertTrue(((denormalized - data).abs() < TOLERANCE).all())
