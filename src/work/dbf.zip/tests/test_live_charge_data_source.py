import unittest
import unittest.mock
from datetime import datetime
from pathlib import Path

import pandas as pd

from dbfcore.dataset.hooks import get_datasources_configured_with_env
from dbfcore.dataset.preprocessed_dataset.autoencoder_flows_preprocessing import FLOWS_SAMPLING_FREQ
from dbfcore.dataset.signals.charge_flows import (
    calculate_mineral_weight_of_all_raw_materials,
    calculate_total_mineral_weight,
    fill_missing_values,
    filter_flow_columns_and_index,
    get_charge_flows_time_series_for_multiple_columns,
    get_column_names_from_signal_names,
    get_extended_raw_material_charge_period_dates,
    get_max_num_raw_materials,
    get_minerals_from_signal_names,
    get_relevant_charge_data_in_wide_format,
    load_charge_and_analyses_data_from_data_sources,
    utcify_date_columns,
    validate_start_end_datetimes,
)
from dbfcore.settings import TZ_LOCAL, TZ_UTC


class TestLiveChargeDataSource(unittest.TestCase):
    signal_name = "bf1_chargefe2o3_flow_kgh"
    mineral = "fe2o3"
    start = datetime(2023, 4, 23, 0, 10, tzinfo=TZ_UTC)
    end = datetime(2023, 4, 23, 7, 57, tzinfo=TZ_UTC)
    furnace_id = 1
    datadir = "./tests/test_data"

    # Utility method to generate/refresh stored data in csv files necessary for running tests.
    def prepare_data(self):
        ds = get_datasources_configured_with_env()
        vp_hook = ds.get_vp_hook(self.end, pd.Timestamp.utcnow())
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = (
            load_charge_and_analyses_data_from_data_sources(self.start, self.end, self.furnace_id, vp_hook)
        )
        raw_material_charge.to_csv(Path(self.datadir, "raw_material_charge.csv"))
        raw_material_analysis.to_csv(Path(self.datadir, "raw_material_analysis.csv"))
        sinter_analysis.to_csv(Path(self.datadir, "sinter_analysis.csv"))
        charge_summary.to_csv(Path(self.datadir, "charge_summary.csv"))

    def load_csv_data(self) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        raw_material_analysis = pd.read_csv(
            Path(self.datadir, "raw_material_analysis.csv"),
            parse_dates=["raw_material_analysis_date"],
            index_col=0,
        )
        sinter_analysis = pd.read_csv(
            Path(self.datadir, "sinter_analysis.csv"),
            parse_dates=["sinter_analysis_date"],
            index_col=0,
        )
        raw_material_charge = pd.read_csv(
            Path(self.datadir, "raw_material_charge.csv"),
            parse_dates=["charge_date"],
            index_col=0,
        )
        charge_summary = pd.read_csv(
            Path(self.datadir, "charge_summary.csv"),
            parse_dates=["charge_date"],
            index_col=0,
        )
        return raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary

    def test_validate_datetimes(self):
        with self.assertRaises(ValueError):
            validate_start_end_datetimes(self.start, self.end.replace(tzinfo=None))
        with self.assertRaises(ValueError):
            validate_start_end_datetimes(self.start.replace(tzinfo=TZ_LOCAL), self.end)

    def test_mineral_from_signal_name(self):
        actuals = get_minerals_from_signal_names([self.signal_name])
        expected = [self.mineral]
        self.assertEqual(actuals, expected)

    def test_utcify_date_columns(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()

        rawmat_analysis_first_date = raw_material_analysis["raw_material_analysis_date"][0]
        sinter_analysis_first_date = sinter_analysis["sinter_analysis_date"][0]
        rawmat_charge_first_date = raw_material_charge["charge_date"][0]
        charge_summary_first_date = charge_summary["charge_date"][0]

        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )

        rawmat_analysis_first_date_utc = raw_material_analysis["raw_material_analysis_date"][0]
        sinter_analysis_first_date_utc = sinter_analysis["sinter_analysis_date"][0]
        rawmat_charge_first_date_utc = raw_material_charge["charge_date"][0]
        charge_summary_first_date_utc = charge_summary["charge_date"][0]

        self.assertEqual(rawmat_analysis_first_date.hour - rawmat_analysis_first_date_utc.hour, 1)
        self.assertEqual(sinter_analysis_first_date.hour - sinter_analysis_first_date_utc.hour, 2)
        self.assertEqual(rawmat_charge_first_date.hour - rawmat_charge_first_date_utc.hour, 2)
        self.assertEqual(charge_summary_first_date.hour - charge_summary_first_date_utc.hour, 2)

    def test_get_max_num_raw_materials(self):
        df = pd.DataFrame({"raw_material_weight_8": [100, 200], "raw_material_weight_22": [200, 300]})
        self.assertEqual(get_max_num_raw_materials(df), 22)

    def test_join_raw_material_weights_with_analyses(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )
        charges = get_relevant_charge_data_in_wide_format(
            raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary  # , [self.mineral]
        )
        actual_max_num_raw_materials = get_max_num_raw_materials(charges)
        expected_max_num_raw_materials = 5
        expected_num_charges = 63
        expected_weights_first_charge = [8888, 8930, 10013, 15053, 1002]

        self.assertEqual(len(charges), expected_num_charges)
        self.assertEqual(actual_max_num_raw_materials, expected_max_num_raw_materials)
        for i in range(1, expected_max_num_raw_materials + 1):
            self.assertEqual(charges[f"raw_material_analysis_date_{i}"].isna().sum(), 0)
        for i in range(1, expected_max_num_raw_materials + 1):
            self.assertEqual(charges.loc[0][f"raw_material_weight_{i}"], expected_weights_first_charge[i - 1])

    def test_calculate_mineral_weight_of_all_raw_materials(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )
        merged = get_relevant_charge_data_in_wide_format(
            raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary
        )
        num_raw_materials = get_max_num_raw_materials(merged)

        weights = calculate_mineral_weight_of_all_raw_materials(merged, [self.mineral], num_raw_materials)
        expected_first_charge_fe2o3_weight_1 = 5066.557040
        expected_first_charge_fe2o3_weight_2 = 84.3156248597
        expected_first_charge_fe2o3_weight_3 = 9219.862459
        expected_first_charge_fe2o3_weight_4 = 14049.434528
        expected_first_charge_fe2o3_weight_5 = 876.1051176
        self.assertAlmostEqual(
            weights["raw_material_fe2o3_weight_1"].loc[0], expected_first_charge_fe2o3_weight_1, 5
        )
        self.assertAlmostEqual(
            weights["raw_material_fe2o3_weight_2"].loc[0], expected_first_charge_fe2o3_weight_2, 5
        )
        self.assertAlmostEqual(
            weights["raw_material_fe2o3_weight_3"].loc[0], expected_first_charge_fe2o3_weight_3, 5
        )
        self.assertAlmostEqual(
            weights["raw_material_fe2o3_weight_4"].loc[0], expected_first_charge_fe2o3_weight_4, 5
        )
        self.assertAlmostEqual(
            weights["raw_material_fe2o3_weight_5"].loc[0], expected_first_charge_fe2o3_weight_5, 5
        )

    def test_calculate_total_mineral_weight(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )
        merged = get_relevant_charge_data_in_wide_format(
            raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary
        )
        num_raw_materials = get_max_num_raw_materials(merged)

        weights = calculate_mineral_weight_of_all_raw_materials(merged, [self.mineral], num_raw_materials)
        total_weights = calculate_total_mineral_weight(weights, [self.mineral], num_raw_materials)
        self.assertAlmostEqual(total_weights[f"{self.mineral}_weight"].loc[0], 29296.2747704, 5)

    def test_charge_flows(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )
        merged = get_relevant_charge_data_in_wide_format(
            raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary
        )
        num_raw_materials = get_max_num_raw_materials(merged)

        weights = calculate_mineral_weight_of_all_raw_materials(merged, num_raw_materials=num_raw_materials)
        total_weights = calculate_total_mineral_weight(weights, [self.mineral], num_raw_materials)
        flows = get_charge_flows_time_series_for_multiple_columns(
            total_weights,
            [f"{self.mineral}_weight"],
            "charge_date",
            FLOWS_SAMPLING_FREQ,
        )
        column_names = get_column_names_from_signal_names([self.signal_name])
        self.assertAlmostEqual(flows[column_names[0]].loc[0], 203158.1198145, 5)

    def test_final_cleaned_data(self):
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = self.load_csv_data()
        raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary = utcify_date_columns(
            raw_material_analysis, sinter_analysis, raw_material_charge, charge_summary
        )
        merged = get_relevant_charge_data_in_wide_format(
            raw_material_charge, raw_material_analysis, sinter_analysis, charge_summary
        )
        num_raw_materials = get_max_num_raw_materials(merged)

        weights = calculate_mineral_weight_of_all_raw_materials(merged, [self.mineral], num_raw_materials)
        total_weights = calculate_total_mineral_weight(weights, [self.mineral], num_raw_materials)
        flows = get_charge_flows_time_series_for_multiple_columns(
            total_weights,
            [f"{self.mineral}_weight"],
            "charge_date",
            FLOWS_SAMPLING_FREQ,
        )
        column_names = get_column_names_from_signal_names([self.signal_name])
        data = filter_flow_columns_and_index(flows, [self.signal_name])
        data = data.dropna().sort_index()
        data = data[~data.index.duplicated()].sort_index()

        self.assertAlmostEqual(data[column_names[0]].sum(), 54649113.6381226, 5)
        self.assertEqual(len(data), 236)
        self.assertEqual(data.columns.tolist(), [column_names[0]])
        self.assertEqual(data.index.name, "Timestamp")

    def test_fill_missing_values_with_added_rows(self):
        data = {
            "chargefeo_flow_kgh": {
                pd.Timestamp("2024-06-13 10:02:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:04:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:06:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:08:00+0000", tz="UTC"): 7697.513665631641,
                pd.Timestamp("2024-06-13 10:10:00+0000", tz="UTC"): 8831.22654028436,
            }
        }
        df_data = pd.DataFrame(data)
        end = datetime(2024, 6, 13, 10, 20, tzinfo=TZ_UTC)

        calculated_output_df = fill_missing_values(df_data, end, FLOWS_SAMPLING_FREQ)
        calculated_output = calculated_output_df.to_dict()
        expected_output = {
            "chargefeo_flow_kgh": {
                pd.Timestamp("2024-06-13 10:02:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:04:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:06:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:08:00+0000", tz="UTC"): 7697.513665631641,
                pd.Timestamp("2024-06-13 10:10:00+0000", tz="UTC"): 8831.22654028436,
                pd.Timestamp("2024-06-13 10:12:00+0000", tz="UTC"): 8831.22654028436,
                pd.Timestamp("2024-06-13 10:14:00+0000", tz="UTC"): 8831.22654028436,
                pd.Timestamp("2024-06-13 10:16:00+0000", tz="UTC"): 8831.22654028436,
                pd.Timestamp("2024-06-13 10:18:00+0000", tz="UTC"): 8831.22654028436,
                pd.Timestamp("2024-06-13 10:20:00+0000", tz="UTC"): 8831.22654028436,
            }
        }
        expected_output_len = len(expected_output["chargefeo_flow_kgh"])

        self.assertEqual(expected_output_len, len(calculated_output_df))
        self.assertEqual(expected_output, calculated_output)

    def test_fill_missing_values_without_added_rows(self):
        data = {
            "chargefeo_flow_kgh": {
                pd.Timestamp("2024-06-13 10:02:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:04:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:06:00+0000", tz="UTC"): 7109.13103448276,
            }
        }
        df_data = pd.DataFrame(data)
        end = datetime(2024, 6, 13, 10, 6, tzinfo=TZ_UTC)

        calculated_output_df = fill_missing_values(df_data, end, FLOWS_SAMPLING_FREQ)
        calculated_output = calculated_output_df.to_dict()
        expected_output = {
            "chargefeo_flow_kgh": {
                pd.Timestamp("2024-06-13 10:02:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:04:00+0000", tz="UTC"): 7109.13103448276,
                pd.Timestamp("2024-06-13 10:06:00+0000", tz="UTC"): 7109.13103448276,
            }
        }
        expected_output_len = len(expected_output["chargefeo_flow_kgh"])

        self.assertEqual(expected_output_len, len(calculated_output_df))
        self.assertEqual(expected_output, calculated_output)

    def test_extended_raw_material_charge_period_dates(self):
        start = datetime(2024, 6, 15, 13, tzinfo=TZ_UTC)
        end = datetime(2024, 6, 15, 15, tzinfo=TZ_UTC)
        mocked_extended_start = datetime(2024, 6, 15, 12, 50, tzinfo=TZ_UTC)
        mocked_extended_end = datetime(2024, 6, 15, 15, 10, tzinfo=TZ_UTC)

        with unittest.mock.patch("dbfcore.dataset.hooks.PZVPHook") as mock_pzvp_hook:
            mock_pzvp_hook.get_raw_material_charge_extended_start_date.return_value = mocked_extended_start
            mock_pzvp_hook.get_raw_material_charge_extended_end_date.return_value = mocked_extended_end
            extended_start, extended_end = get_extended_raw_material_charge_period_dates(
                start, end, 1, mock_pzvp_hook
            )
            self.assertEqual(extended_start, datetime(2024, 6, 15, 12, 50, tzinfo=TZ_UTC))
            self.assertEqual(extended_end, datetime(2024, 6, 15, 15, 10, tzinfo=TZ_UTC))

    def test_extended_raw_material_charge_period_start_only(self):
        start = datetime(2024, 6, 15, 13, tzinfo=TZ_UTC)
        end = datetime(2024, 6, 15, 15, tzinfo=TZ_UTC)
        mocked_extended_start = datetime(2024, 6, 15, 12, 50, tzinfo=TZ_UTC)
        mocked_extended_end = None

        with unittest.mock.patch("dbfcore.dataset.hooks.PZVPHook") as mock_pzvp_hook:
            mock_pzvp_hook.get_raw_material_charge_extended_start_date.return_value = mocked_extended_start
            mock_pzvp_hook.get_raw_material_charge_extended_end_date.return_value = mocked_extended_end
            extended_start, extended_end = get_extended_raw_material_charge_period_dates(
                start, end, 1, mock_pzvp_hook
            )
            self.assertEqual(extended_start, datetime(2024, 6, 15, 12, 50, tzinfo=TZ_UTC))
            self.assertEqual(extended_end, datetime(2024, 6, 15, 15, tzinfo=TZ_UTC))

    def test_get_raw_material_charge_is_called_with_extended_dates(self):
        start = datetime(2024, 6, 15, 13, tzinfo=TZ_UTC)
        end = datetime(2024, 6, 15, 15, tzinfo=TZ_UTC)
        mocked_extended_start = datetime(2024, 6, 15, 12, 50, tzinfo=TZ_UTC)
        mocked_extended_end = datetime(2024, 6, 15, 15, 10, tzinfo=TZ_UTC)
        mocked_raw_material_charge = pd.DataFrame({"raw_material_number": [1, 3]})  # only numbers are needed

        with unittest.mock.patch("dbfcore.dataset.hooks.PZVPHook") as mock_pzvp_hook:
            mock_pzvp_hook.get_raw_material_charge_extended_start_date.return_value = mocked_extended_start
            mock_pzvp_hook.get_raw_material_charge_extended_end_date.return_value = mocked_extended_end
            mock_pzvp_hook.get_raw_material_charge.return_value = mocked_raw_material_charge
            load_charge_and_analyses_data_from_data_sources(start, end, 1, mock_pzvp_hook)
            mock_pzvp_hook.get_raw_material_charge.assert_called_with(
                mocked_extended_start, mocked_extended_end, 1
            )
            mock_pzvp_hook.get_raw_material_analysis.assert_called_with(
                mocked_extended_start, mocked_extended_end, {3}
            )
            mock_pzvp_hook.get_sinter_analysis.assert_called_with(mocked_extended_start, mocked_extended_end)


if __name__ == "__main__":
    unittest.main()
