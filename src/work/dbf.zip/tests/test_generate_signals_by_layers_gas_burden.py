import unittest
from pathlib import Path
from typing import Optional
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytz

from dbfcore.dataset.hooks import DataSources
from dbfcore.scripts.generate_signals_by_layers_gas_burden import (
    add_charge_temp_signal,
    add_h2o_signal,
    add_nitrogen_n2_signal,
    generate_signal_as_dataframe,
    get_close_interval_from_dataframe,
    get_filename_dir,
    get_only_output_columns,
    get_resample_signal,
    load_signal_by_layers,
    load_signal_by_layers_one_batch,
    recalc_gas_composition,
    shift_frame_back_in_time,
)
from dbfcore.settings import DATAMODULE_CACHE


class FakeAZVPHook:
    def __init__(self):
        pass


class FakePZVPHook:
    pass


class FakeOkoClient:
    def __init__(self):
        pass


class FakeScadaClient:
    pass


class FakePvisClient:
    pass


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Top.Uptake1.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 93.747450, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:06.702011100+00:00", "Value": 94.094666, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:27.671005200+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:03:10.718002300+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:03:42.702011100+00:00", "Value": 92.705820, "Good": True},
                    {"Timestamp": "2025-01-01 00:05:14.201110540+00:00", "Value": 97.255820, "Good": True},
                    {"Timestamp": "2025-01-01 00:12:12.255646600+00:00", "Value": 94.125620, "Good": True},
                    {"Timestamp": "2025-01-01 00:17:25.456366600+00:00", "Value": 93.654820, "Good": True},
                    {"Timestamp": "2025-01-01 00:22:25.455366600+00:00", "Value": 94.212820, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake2.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:50.702011100+00:00", "Value": 111.108093, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:51.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:02.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:03:03.670013400+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:03:08.702011100+00:00", "Value": 107.635963, "Good": True},
                    {"Timestamp": "2025-01-01 00:27:08.456411100+00:00", "Value": 107.635963, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake3.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:01:30.702011100+00:00", "Value": 123.607758, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:20.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:03:05.670013400+00:00", "Value": 122.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:04:08.702011100+00:00", "Value": 122.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:34:28.455221100+00:00", "Value": 121.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:45:28.156221100+00:00", "Value": 123.314900, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake4.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 107.983177, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 107.635963, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:11.671005200+00:00", "Value": 106.247116, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:16.702011100+00:00", "Value": 105.552689, "Good": True},
                    {"Timestamp": "2025-01-01 00:38:12.221441100+00:00", "Value": 115.552689, "Good": True},
                    {"Timestamp": "2025-01-01 00:42:15.245441100+00:00", "Value": 115.552689, "Good": True},
                    {"Timestamp": "2025-01-01 00:51:14.224411004+00:00", "Value": 115.552689, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.CO.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:01.9910125Z", "Value": 24.4322071, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:58.9930114Z", "Value": 24.270174, "Good": True},
                    {"Timestamp": "2025-01-01T00:12:12.2556466Z", "Value": 24.125620, "Good": True},
                    {"Timestamp": "2025-01-01T00:22:15.4553666Z", "Value": 24.212820, "Good": True},
                    {"Timestamp": "2025-01-01T00:27:18.4564111Z", "Value": 29.635963, "Good": True},
                    {"Timestamp": "2025-01-01T00:34:18.4552211Z", "Value": 28.218900, "Good": True},
                    {"Timestamp": "2025-01-01T00:38:22.2214411Z", "Value": 27.552689, "Good": True},
                    {"Timestamp": "2025-01-01T00:42:25.2454411Z", "Value": 26.552689, "Good": True},
                    {"Timestamp": "2025-01-01T00:51:24.2244110Z", "Value": 25.552689, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.CO2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:34.9920043Z", "Value": 20.5202751, "Good": True},
                    {"Timestamp": "2025-01-01T00:01:09.9930114Z", "Value": 20.3640289, "Good": True},
                    {"Timestamp": "2025-01-01T00:12:12.2556466Z", "Value": 21.635620, "Good": True},
                    {"Timestamp": "2025-01-01T00:17:25.4563666Z", "Value": 22.122820, "Good": True},
                    {"Timestamp": "2025-01-01T00:22:15.4553666Z", "Value": 23.541820, "Good": True},
                    {"Timestamp": "2025-01-01T00:34:18.4552211Z", "Value": 27.212900, "Good": True},
                    {"Timestamp": "2025-01-01T00:38:22.2214411Z", "Value": 28.122689, "Good": True},
                    {"Timestamp": "2025-01-01T00:42:25.2454411Z", "Value": 29.212689, "Good": True},
                    {"Timestamp": "2025-01-01T00:51:24.2244110Z", "Value": 21.122689, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.H2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:05.9910125Z", "Value": 3.1596365, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:50.9930114Z", "Value": 3.33902979, "Good": True},
                    {"Timestamp": "2025-01-01T00:12:12.2556466Z", "Value": 25.215620, "Good": True},
                    {"Timestamp": "2025-01-01T00:17:25.4563666Z", "Value": 29.124820, "Good": True},
                    {"Timestamp": "2025-01-01T00:22:15.4553666Z", "Value": 28.545420, "Good": True},
                    {"Timestamp": "2025-01-01T00:27:18.4564111Z", "Value": 27.122263, "Good": True},
                    {"Timestamp": "2025-01-01T00:34:18.4552211Z", "Value": 26.122100, "Good": True},
                    {"Timestamp": "2025-01-01T00:38:22.2214411Z", "Value": 25.545829, "Good": True},
                    {"Timestamp": "2025-01-01T00:51:24.2244110Z", "Value": 24.545469, "Good": True},
                ]
            }
        elif "SK1.Top.Pressure1.Pres.kPa" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:05.9910125Z", "Value": 122.46, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:50.9930114Z", "Value": 144.7, "Good": True},
                    {"Timestamp": "2025-01-01T00:01:20.9930114Z", "Value": 128.8, "Good": True},
                    {"Timestamp": "2025-01-01T00:05:13.2556466Z", "Value": 125.21, "Good": True},
                ]
            }
        elif "SK1.Top.Pressure2.Pres.kPa" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:05.9910125Z", "Value": 136.1, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:50.9930114Z", "Value": 157.32, "Good": True},
                    {"Timestamp": "2025-01-01T00:01:20.9930114Z", "Value": 152.98, "Good": True},
                ]
            }
        elif "SK1.Furnace.UpperDeltaP.Pres.kPa" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:05.9910125Z", "Value": 120.2, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:50.9930114Z", "Value": 130.3, "Good": True},
                    {"Timestamp": "2025-01-01T00:01:20.9930114Z", "Value": 140.4, "Good": True},
                ]
            }
        elif "SK1.Furnace.LowerDeltaP.Pres.kPa" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01T00:00:05.9910125Z", "Value": 150.5, "Good": True},
                    {"Timestamp": "2025-01-01T00:00:50.9930114Z", "Value": 160.6, "Good": True},
                    {"Timestamp": "2025-01-01T00:01:20.9930114Z", "Value": 170.7, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestGenerateSignalAsDataframe(unittest.TestCase):
    def test_generate_signal_as_dataframe_uptake(self):
        expected = pd.DataFrame(
            {
                "bf1_uptake_temp_C": [
                    100.604905,
                    111.108093,
                    116.837105,
                    110.066452,
                    108.330390,
                    92.705820,
                    122.218900,
                    97.255820,
                    94.125620,
                    93.654820,
                    94.212820,
                    107.635963,
                    121.218900,
                    115.552689,
                    115.552689,
                    123.314900,
                    115.552689,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:00:30+00:00",
                    "2025-01-01 00:01:00+00:00",
                    "2025-01-01 00:02:00+00:00",
                    "2025-01-01 00:02:30+00:00",
                    "2025-01-01 00:03:30+00:00",
                    "2025-01-01 00:04:00+00:00",
                    "2025-01-01 00:04:30+00:00",
                    "2025-01-01 00:05:30+00:00",
                    "2025-01-01 00:12:30+00:00",
                    "2025-01-01 00:17:30+00:00",
                    "2025-01-01 00:22:30+00:00",
                    "2025-01-01 00:27:30+00:00",
                    "2025-01-01 00:34:30+00:00",
                    "2025-01-01 00:38:30+00:00",
                    "2025-01-01 00:42:30+00:00",
                    "2025-01-01 00:45:30+00:00",
                    "2025-01-01 00:51:30+00:00",
                ],
                format="mixed",
            ),
        )
        expected.index.name = "Timestamp"
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        result = generate_signal_as_dataframe(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            signal_group_name="bf1_uptake",
            datasources=datasources,
        )
        pd.testing.assert_frame_equal(result, expected)

    def test_generate_signal_as_dataframe_topgas(self):
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [
                    24.432207,
                    np.nan,
                    np.nan,
                    np.nan,
                    24.270174,
                    np.nan,
                    24.125620,
                    np.nan,
                    24.212820,
                    29.635963,
                    28.218900,
                    27.552689,
                    26.552689,
                    25.552689,
                ],
                "bf1_topgasco2_chem_pct": [
                    np.nan,
                    np.nan,
                    20.520275,
                    np.nan,
                    np.nan,
                    20.364029,
                    21.635620,
                    22.122820,
                    23.541820,
                    np.nan,
                    27.212900,
                    28.122689,
                    29.212689,
                    21.122689,
                ],
                "bf1_topgash2_chem_pct": [
                    np.nan,
                    3.159636,
                    np.nan,
                    3.339030,
                    np.nan,
                    np.nan,
                    25.215620,
                    29.124820,
                    28.545420,
                    27.122263,
                    26.122100,
                    25.545829,
                    np.nan,
                    24.545469,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:00:01.991012500+00:00",
                    "2025-01-01 00:00:05.991012500+00:00",
                    "2025-01-01 00:00:34.992004300+00:00",
                    "2025-01-01 00:00:50.993011400+00:00",
                    "2025-01-01 00:00:58.993011400+00:00",
                    "2025-01-01 00:01:09.993011400+00:00",
                    "2025-01-01 00:12:12.255646600+00:00",
                    "2025-01-01 00:17:25.456366600+00:00",
                    "2025-01-01 00:22:15.455366600+00:00",
                    "2025-01-01 00:27:18.456411100+00:00",
                    "2025-01-01 00:34:18.455221100+00:00",
                    "2025-01-01 00:38:22.221441100+00:00",
                    "2025-01-01 00:42:25.245441100+00:00",
                    "2025-01-01 00:51:24.224411+00:00",
                ],
                format="mixed",
            ),
        )
        expected.index.name = "Timestamp"
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        result = generate_signal_as_dataframe(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            signal_group_name="bf1_topgas",
            datasources=datasources,
        )
        pd.testing.assert_frame_equal(result, expected)

    def test_generate_signal_as_dataframe_pressure(self):
        resample_rule = "30s"
        expected = pd.DataFrame(
            {
                "bf1_top_pressure_kPa": [
                    129.28,
                    151.01,
                    140.89,
                    140.665625,
                    140.441250,
                    140.216875,
                    139.992500,
                    139.768125,
                    139.543750,
                    139.319375,
                    139.095000,
                ],
                "bf1_mid_pressure_kPa": [
                    249.48,
                    281.31,
                    281.29,
                    281.065625,
                    280.841250,
                    280.616875,
                    280.392500,
                    280.168125,
                    279.943750,
                    279.719375,
                    279.495000,
                ],
                "bf1_bottom_pressure_kPa": [
                    399.98,
                    441.91,
                    451.99,
                    451.765625,
                    451.541250,
                    451.316875,
                    451.092500,
                    450.868125,
                    450.643750,
                    450.419375,
                    450.195000,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:00:00+00:00",
                    "2025-01-01 00:00:30+00:00",
                    "2025-01-01 00:01:00+00:00",
                    "2025-01-01 00:01:30+00:00",
                    "2025-01-01 00:02:00+00:00",
                    "2025-01-01 00:02:30+00:00",
                    "2025-01-01 00:03:00+00:00",
                    "2025-01-01 00:03:30+00:00",
                    "2025-01-01 00:04:00+00:00",
                    "2025-01-01 00:04:30+00:00",
                    "2025-01-01 00:05:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq(resample_rule)
        expected.index.name = "Timestamp"
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        result = generate_signal_as_dataframe(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            signal_group_name="bf1_pressure",
            datasources=datasources,
        )
        pd.testing.assert_frame_equal(result, expected)


class TestGetOnlyOutputColumns(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf2_uptake_temp_C": [95.160, 88.525, 95.459, 93.934],
                "bf2_uptake_temp_C_bad_col": [95.160, 88.525, 95.459, 93.934],
                "bf2_top_pressure_kPa": [95.160, 88.525, 95.459, 93.934],
            },
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 00:55:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_get_only_output_columns(self):
        expected = pd.DataFrame(
            {
                "bf2_uptake_temp_C": [95.160, 88.525, 95.459, 93.934],
                "bf2_top_pressure_kPa": [95.160, 88.525, 95.459, 93.934],
            },
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 00:55:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                ],
                format="mixed",
            ),
        )
        output_gas_columns = [
            "bf2_uptake_temp_C",
            "bf2_top_pressure_kPa",
            "bf2_topgasco_chem_pct",
            "bf2_topgasco2_chem_pct",
            "bf2_topgash2_chem_pct",
        ]
        result = get_only_output_columns(self.df, output_gas_columns)
        pd.testing.assert_frame_equal(result, expected)

    def test_get_only_output_columns_empty(self):
        output_gas_columns = [
            "bf2_uptake_temp_C",
            "bf2_top_pressure_kPa",
            "bf2_topgasco_chem_pct",
            "bf2_topgasco2_chem_pct",
            "bf2_topgash2_chem_pct",
        ]
        expected = pd.DataFrame()
        result = get_only_output_columns(self.df_empty, output_gas_columns)
        pd.testing.assert_frame_equal(result, expected)


class TestGetResampleSignal(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf2_uptake_temp_C": [
                    95.160,
                    88.525,
                    95.459,
                    93.934,
                    98.256,
                    87.865,
                    np.nan,
                    87.258,
                    98.478,
                    97.897,
                    98.478,
                    101.256,
                    89.659,
                    np.nan,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-02 00:00:00+00:00",
                    "2025-01-02 00:01:00+00:00",
                    "2025-01-02 00:02:00+00:00",
                    "2025-01-02 00:03:00+00:00",
                    "2025-01-02 00:04:00+00:00",
                    "2025-01-02 00:05:00+00:00",
                    "2025-01-02 00:06:00+00:00",
                    "2025-01-02 00:06:30+00:00",
                    "2025-01-02 00:07:00+00:00",
                    "2025-01-02 00:08:00+00:00",
                    "2025-01-02 00:09:00+00:00",
                    "2025-01-02 00:16:00+00:00",
                    "2025-01-02 00:17:00+00:00",
                    "2025-01-02 00:22:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_get_resample_signal_as_mean(self):
        resample_rule = "300s"
        expected = pd.DataFrame(
            {"bf2_uptake_temp_C": [95.1600, 92.8078, 95.52775, np.nan, 95.4575, np.nan]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:00:00+00:00",
                    "2025-01-02 00:05:00+00:00",
                    "2025-01-02 00:10:00+00:00",
                    "2025-01-02 00:15:00+00:00",
                    "2025-01-02 00:20:00+00:00",
                    "2025-01-02 00:25:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq(resample_rule)
        result = get_resample_signal(self.df, "mean", resample_rule)
        pd.testing.assert_frame_equal(result, expected)

    def test_get_resample_signal_as_mean_empty(self):
        resample_rule = "300s"
        expected = pd.DataFrame()
        result = get_resample_signal(self.df_empty, "mean", resample_rule)
        pd.testing.assert_frame_equal(result, expected)

    def test_get_resample_signal_as_sum(self):
        resample_rule = "300s"
        expected = pd.DataFrame(
            {"bf2_uptake_temp_C": [95.1600, 464.039, 382.111, np.nan, 190.915, np.nan]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:00:00+00:00",
                    "2025-01-02 00:05:00+00:00",
                    "2025-01-02 00:10:00+00:00",
                    "2025-01-02 00:15:00+00:00",
                    "2025-01-02 00:20:00+00:00",
                    "2025-01-02 00:25:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq(resample_rule)
        result = get_resample_signal(self.df, "sum", resample_rule)
        pd.testing.assert_frame_equal(result, expected)

    def test_get_resample_signal_as_sum_empty(self):
        resample_rule = "300s"
        expected = pd.DataFrame()
        result = get_resample_signal(self.df_empty, "sum", resample_rule)
        pd.testing.assert_frame_equal(result, expected)


class TestShiftFrameBackInTime(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:20:00+00:00",
                    "2025-01-01 00:25:00+00:00",
                    "2025-01-01 00:30:00+00:00",
                    "2025-01-01 00:35:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_shift_frame_back_in_time(self):
        time_shift_of_gases_in_sec = 420
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:13:00+00:00",
                    "2025-01-01 00:18:00+00:00",
                    "2025-01-01 00:23:00+00:00",
                    "2025-01-01 00:28:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = shift_frame_back_in_time(self.df, time_shift_of_gases_in_sec)
        pd.testing.assert_frame_equal(result, expected)

    def test_shift_frame_back_in_time_empty(self):
        time_shift_of_gases_in_sec = 420
        expected = pd.DataFrame()
        result = shift_frame_back_in_time(self.df_empty, time_shift_of_gases_in_sec)
        pd.testing.assert_frame_equal(result, expected)


class TestAddNitrogenN2Signal(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_add_nitrogen_n2_signal(self):
        new_signal_name = "bf1_topgasn2_chem_pct"
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
                new_signal_name: [57.180, 56.927, 58.401, 57.088],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = add_nitrogen_n2_signal(self.df, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)

    def test_add_nitrogen_n2_signal_empty(self):
        new_signal_name = "bf1_topgasn2_chem_pct"
        expected = pd.DataFrame()
        result = add_nitrogen_n2_signal(self.df_empty, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)


class TestAddH2oSignal(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
                "bf1_topgasn2_chem_pct": [57.180, 56.927, 58.401, 57.088],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_add_h2o_signal(self):
        new_signal_name = "bf1_topgash2o_chem_pct"
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
                "bf1_topgasn2_chem_pct": [57.180, 56.927, 58.401, 57.088],
                new_signal_name: [4.0, 4.0, 4.0, 4.0],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = add_h2o_signal(self.df, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)

    def test_add_h2o_signal_empty(self):
        new_signal_name = "bf1_topgash2o_chem_pct"
        expected = pd.DataFrame(columns=[new_signal_name], dtype="float64")
        result = add_h2o_signal(self.df_empty, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)


class TestRecalcGasComposition(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.160, 21.525, 20.459, 20.934],
                "bf1_topgasco2_chem_pct": [21.060, 20.123, 19.595, 20.344],
                "bf1_topgash2_chem_pct": [1.600, 1.425, 1.545, 1.634],
                "bf1_topgasn2_chem_pct": [57.180, 56.927, 58.401, 57.088],
                "bf1_topgash2o_chem_pct": [4.0, 4.0, 4.0, 4.0],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_recalc_gas_composition(self):
        new_signal_name = "bf1_topgash2o_chem_pct"
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [19.35360, 20.66400, 19.64064, 20.09664],
                "bf1_topgasco2_chem_pct": [20.21760, 19.31808, 18.81120, 19.53024],
                "bf1_topgash2_chem_pct": [1.53600, 1.36800, 1.48320, 1.56864],
                "bf1_topgasn2_chem_pct": [54.89280, 54.64992, 56.06496, 54.80448],
                new_signal_name: [4.0, 4.0, 4.0, 4.0],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = recalc_gas_composition(self.df, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)

    def test_recalc_gas_composition_empty(self):
        new_signal_name = "bf1_topgash2o_chem_pct"
        expected = pd.DataFrame()
        result = recalc_gas_composition(self.df_empty, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)


class TestAddChargeTempSignal(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_charge_layer1_al2o3_weight": [520.160, 521.525, 520.459, 520.934],
                "bf1_charge_layer1_ars_weight": [521.060, 520.123, 519.595, 520.344],
                "bf1_charge_layer1_c_weight": [557.180, 556.927, 558.401, 557.088],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_add_charge_temp_signal(self):
        new_signal_name = "bf1_charge_temp_C"
        expected = pd.DataFrame(
            {
                new_signal_name: [25.0, 25.0, 25.0, 25.0],
                "bf1_charge_layer1_al2o3_weight": [520.160, 521.525, 520.459, 520.934],
                "bf1_charge_layer1_ars_weight": [521.060, 520.123, 519.595, 520.344],
                "bf1_charge_layer1_c_weight": [557.180, 556.927, 558.401, 557.088],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = add_charge_temp_signal(self.df, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)

    def test_add_charge_temp_signal_empty(self):
        new_signal_name = "bf1_charge_temp_C"
        expected = pd.DataFrame(columns=[new_signal_name], dtype="float64")
        result = add_charge_temp_signal(self.df_empty, new_signal_name)
        pd.testing.assert_frame_equal(result, expected)


class TestGetCloseIntervalFromDataframe(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [19.35360, 20.66400, 19.64064, 20.09664, 18.5152],
                "bf1_topgasco2_chem_pct": [20.21760, 19.31808, 18.81120, 19.53024, 17.45655],
                "bf1_topgash2_chem_pct": [1.53600, 1.36800, 1.48320, 1.56864, 1.455],
                "bf1_topgasn2_chem_pct": [54.89280, 54.64992, 56.06496, 54.80448, 54.25],
                "bf1_charge_layer1_al2o3_weight": [520.160, 521.525, 520.459, 520.934, 511.25],
                "bf1_charge_layer1_ars_weight": [521.060, 520.123, 519.595, 520.344, 517.65],
                "bf1_charge_layer1_c_weight": [557.180, 556.927, 558.401, 557.088, 560.256],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                    "2025-01-01 00:25:00+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_empty = pd.DataFrame()

    def test_get_close_interval_from_dataframe(self):
        start = pd.to_datetime("2025-01-01 00:10:00+00:00")
        end = pd.to_datetime("2025-01-01 00:20:00+00:00")
        expected = pd.DataFrame(
            {
                "bf1_topgasco_chem_pct": [20.66400, 19.64064, 20.09664],
                "bf1_topgasco2_chem_pct": [19.31808, 18.81120, 19.53024],
                "bf1_topgash2_chem_pct": [1.36800, 1.48320, 1.56864],
                "bf1_topgasn2_chem_pct": [54.64992, 56.06496, 54.80448],
                "bf1_charge_layer1_al2o3_weight": [521.525, 520.459, 520.934],
                "bf1_charge_layer1_ars_weight": [520.123, 519.595, 520.344],
                "bf1_charge_layer1_c_weight": [556.927, 558.401, 557.088],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_close_interval_from_dataframe(self.df, start, end)
        pd.testing.assert_frame_equal(result, expected)

    def test_get_close_interval_from_dataframe_empty(self):
        start = pd.to_datetime("2025-01-01 00:10:00+00:00")
        end = pd.to_datetime("2025-01-01 00:20:00+00:00")
        expected = pd.DataFrame()
        result = get_close_interval_from_dataframe(self.df_empty, start, end)
        pd.testing.assert_frame_equal(result, expected)


def fake_conditional_generate_signal_as_dataframe(start, end, signal_group_name, datasources):
    expected_name = "bf1_chargelayers_chems"
    df = pd.DataFrame(
        {
            "bf1_charge_layer1_al2o3_weight": [698.159, 704.212, 731.586, 697.456, 704.454, 658.456],
            "bf1_charge_layer1_ars_weight": [0.312, 0.325, 0.365, 0.368, 0.309, 0.398],
            "bf1_charge_layer1_c_weight": [10135.92, 10145.58, 10098.89, 10145.89, 10099.45, 10156.89],
        },
        index=pd.to_datetime(
            [
                "2025-01-01 00:00:01.991012500+00:00",
                "2025-01-01 00:04:05.991012500+00:00",
                "2025-01-01 00:10:34.992004300+00:00",
                "2025-01-01 00:25:50.993011400+00:00",
                "2025-01-01 00:30:58.993011400+00:00",
                "2025-01-01 00:45:09.993011400+00:00",
            ],
            format="mixed",
        ),
    )
    if signal_group_name == expected_name:
        return df
    return generate_signal_as_dataframe(start, end, signal_group_name, datasources)


def fake_generate_signal_as_dataframe_empty(start, end, signal_group_name, datasources):
    return pd.DataFrame()


class TestLoadSignalByLayersOneBatch(unittest.TestCase):
    def test_load_signal_by_layers_one_batch(self):
        resample_rule = "300s"
        expected = pd.DataFrame(
            {
                "bf1_uptake_temp_C": [
                    np.nan,
                    108.838809,
                    97.255820,
                    94.125620,
                    93.654820,
                    94.212820,
                    107.635963,
                    121.218900,
                    115.552689,
                    115.552689,
                    123.314900,
                    115.552689,
                ],
                "bf1_top_pressure_kPa": [
                    129.28000,
                    141.09425,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                ],
                "bf1_topgasco_chem_pct": [
                    23.377143,
                    np.nan,
                    23.160595,
                    np.nan,
                    23.244307,
                    28.450524,
                    27.090144,
                    26.450581,
                    25.490581,
                    np.nan,
                    24.530581,
                    np.nan,
                ],
                "bf1_topgasco2_chem_pct": [
                    19.624466,
                    np.nan,
                    20.770195,
                    21.237907,
                    22.600147,
                    np.nan,
                    26.124384,
                    26.997781,
                    28.044181,
                    np.nan,
                    20.277781,
                    np.nan,
                ],
                "bf1_topgash2_chem_pct": [
                    3.119360,
                    np.nan,
                    24.206995,
                    27.959827,
                    27.403603,
                    26.037372,
                    25.077216,
                    24.523996,
                    np.nan,
                    np.nan,
                    23.563650,
                    np.nan,
                ],
                "bf1_topgasn2_chem_pct": [
                    49.879031,
                    np.nan,
                    27.862214,
                    np.nan,
                    22.751942,
                    np.nan,
                    17.708256,
                    18.027641,
                    np.nan,
                    np.nan,
                    27.627987,
                    np.nan,
                ],
                "bf1_topgash2o_chem_pct": [
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    np.nan,
                ],
                "bf1_charge_temp_C": [
                    np.nan,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    np.nan,
                ],
                "bf1_charge_layer1_al2o3_weight": [
                    np.nan,
                    1402.371,
                    np.nan,
                    731.586,
                    np.nan,
                    np.nan,
                    697.456,
                    704.454,
                    np.nan,
                    np.nan,
                    658.456,
                    np.nan,
                ],
                "bf1_charge_layer1_ars_weight": [
                    np.nan,
                    0.637,
                    np.nan,
                    0.365,
                    np.nan,
                    np.nan,
                    0.368,
                    0.309,
                    np.nan,
                    np.nan,
                    0.398,
                    np.nan,
                ],
                "bf1_charge_layer1_c_weight": [
                    np.nan,
                    20281.50,
                    np.nan,
                    10098.89,
                    np.nan,
                    np.nan,
                    10145.89,
                    10099.45,
                    np.nan,
                    np.nan,
                    10156.89,
                    np.nan,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:00:00+00:00",
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                    "2025-01-01 00:25:00+00:00",
                    "2025-01-01 00:30:00+00:00",
                    "2025-01-01 00:35:00+00:00",
                    "2025-01-01 00:40:00+00:00",
                    "2025-01-01 00:45:00+00:00",
                    "2025-01-01 00:50:00+00:00",
                    "2025-01-01 00:55:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq(resample_rule)
        expected.index.name = "Timestamp"
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        with patch(
            "dbfcore.scripts.generate_signals_by_layers_gas_burden.generate_signal_as_dataframe",
            side_effect=fake_conditional_generate_signal_as_dataframe,
        ):
            result = load_signal_by_layers_one_batch(
                pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
                pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
                1,
                datasources,
                300,
            )
        pd.testing.assert_frame_equal(result, expected)

    def test_load_signal_by_layers_one_batch_empty(self):
        expected = pd.DataFrame(
            {
                "bf1_topgash2o_chem_pct": pd.Series(dtype="float64"),
                "bf1_charge_temp_C": pd.Series(dtype="float64"),
            }
        )
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        with patch(
            "dbfcore.scripts.generate_signals_by_layers_gas_burden.generate_signal_as_dataframe",
            side_effect=fake_generate_signal_as_dataframe_empty,
        ):
            result = load_signal_by_layers_one_batch(
                pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
                pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
                1,
                datasources,
                300,
            )
        pd.testing.assert_frame_equal(result, expected)


class TestLoadSignalByLayers(unittest.TestCase):
    def test_load_signal_by_layers(self):
        resample_rule = "300s"
        expected = pd.DataFrame(
            {
                "bf1_uptake_temp_C": [
                    108.838809,
                    97.255820,
                    94.125620,
                    93.654820,
                    94.212820,
                    107.635963,
                    121.218900,
                    115.552689,
                    115.552689,
                    123.314900,
                    115.552689,
                ],
                "bf1_top_pressure_kPa": [
                    141.09425,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                    np.nan,
                ],
                "bf1_topgasco_chem_pct": [
                    np.nan,
                    23.160595,
                    np.nan,
                    23.244307,
                    28.450524,
                    27.090144,
                    26.450581,
                    25.490581,
                    np.nan,
                    24.530581,
                    np.nan,
                ],
                "bf1_topgasco2_chem_pct": [
                    np.nan,
                    20.770195,
                    21.237907,
                    22.600147,
                    np.nan,
                    26.124384,
                    26.997781,
                    28.044181,
                    np.nan,
                    20.277781,
                    np.nan,
                ],
                "bf1_topgash2_chem_pct": [
                    np.nan,
                    24.206995,
                    27.959827,
                    27.403603,
                    26.037372,
                    25.077216,
                    24.523996,
                    np.nan,
                    np.nan,
                    23.563650,
                    np.nan,
                ],
                "bf1_topgasn2_chem_pct": [
                    np.nan,
                    27.862214,
                    np.nan,
                    22.751942,
                    np.nan,
                    17.708256,
                    18.027641,
                    np.nan,
                    np.nan,
                    27.627987,
                    np.nan,
                ],
                "bf1_topgash2o_chem_pct": [
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    4.0,
                    np.nan,
                ],
                "bf1_charge_temp_C": [
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    25.0,
                    np.nan,
                ],
                "bf1_charge_layer1_al2o3_weight": [
                    1402.371,
                    np.nan,
                    731.586,
                    np.nan,
                    np.nan,
                    697.456,
                    704.454,
                    np.nan,
                    np.nan,
                    658.456,
                    np.nan,
                ],
                "bf1_charge_layer1_ars_weight": [
                    0.637,
                    np.nan,
                    0.365,
                    np.nan,
                    np.nan,
                    0.368,
                    0.309,
                    np.nan,
                    np.nan,
                    0.398,
                    np.nan,
                ],
                "bf1_charge_layer1_c_weight": [
                    20281.50,
                    np.nan,
                    10098.89,
                    np.nan,
                    np.nan,
                    10145.89,
                    10099.45,
                    np.nan,
                    np.nan,
                    10156.89,
                    np.nan,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-01-01 00:05:00+00:00",
                    "2025-01-01 00:10:00+00:00",
                    "2025-01-01 00:15:00+00:00",
                    "2025-01-01 00:20:00+00:00",
                    "2025-01-01 00:25:00+00:00",
                    "2025-01-01 00:30:00+00:00",
                    "2025-01-01 00:35:00+00:00",
                    "2025-01-01 00:40:00+00:00",
                    "2025-01-01 00:45:00+00:00",
                    "2025-01-01 00:50:00+00:00",
                    "2025-01-01 00:55:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq(resample_rule)
        expected.index.name = "Timestamp"
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        with patch(
            "dbfcore.scripts.generate_signals_by_layers_gas_burden.generate_signal_as_dataframe",
            side_effect=fake_conditional_generate_signal_as_dataframe,
        ):
            result = load_signal_by_layers(
                pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
                pd.Timestamp(2025, 1, 1, 1, 0, 0, tzinfo=pytz.UTC),
                1,
                datasources,
                300,
                0.5,
            )
        pd.testing.assert_frame_equal(result, expected)

    def test_load_signal_by_layers_empty(self):
        expected = pd.DataFrame(
            {
                "bf1_topgash2o_chem_pct": pd.Series(dtype="float64"),
                "bf1_charge_temp_C": pd.Series(dtype="float64"),
            }
        )
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        with patch(
            "dbfcore.scripts.generate_signals_by_layers_gas_burden.generate_signal_as_dataframe",
            side_effect=fake_generate_signal_as_dataframe_empty,
        ):
            result = load_signal_by_layers(
                pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
                pd.Timestamp(2025, 1, 1, 1, 0, 0, tzinfo=pytz.UTC),
                1,
                datasources,
                300,
                0.5,
            )
        pd.testing.assert_frame_equal(result, expected)


class TestGetFilenameDir(unittest.TestCase):
    def test_get_filename_dir(self):
        expected = Path(DATAMODULE_CACHE, "bf2_signals_by_layers_from_20250101T0030_to_20250101T0200.parquet")
        result = get_filename_dir(
            DATAMODULE_CACHE,
            2,
            pd.to_datetime("2025-01-01 00:30:00+00:00"),
            pd.to_datetime("2025-01-01 02:00:00+00:00"),
        )
        self.assertEqual(str(expected), str(result))


if __name__ == "__main__":
    unittest.main()
