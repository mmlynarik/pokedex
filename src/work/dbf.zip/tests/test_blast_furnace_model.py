import unittest

import pandas as pd

from dbfcore.predictionmodel.inference import (
    DataDefinition,
    DummyBlastFurnaceModel,
    DummyBlastFurnaceModelResult,
    SignalGroupData,
    get_minmax_data_definition,
)
from dbfcore.settings import TZ_UTC


def get_signal_group_data(data_definition: DataDefinition) -> SignalGroupData:
    return {
        "bf1_charge_flows": pd.DataFrame(
            {"bf1_chargecao_flow_kgh": [100.0, 200.0, 300.0], "bf1_chargec_flow_kgh": [250, 300, 400]},
            index=[
                pd.Timestamp("2023-09-01 12:00:00"),
                pd.Timestamp("2023-09-01 12:02:00"),
                pd.Timestamp("2023-09-01 12:04:00"),
            ],
        ),
        "bf1_tappings": pd.DataFrame(
            {"bf1_hotmetalc_chem_pct": [0.04, 0.05, 0.06], "bf1_hotmetalfe_chem_pct": [95.2, 94.3, 96.4]},
            index=[
                pd.Timestamp("2023-09-01 12:00:00"),
                pd.Timestamp("2023-09-01 14:02:00"),
                pd.Timestamp("2023-09-01 16:04:00"),
            ],
        ),
    }


class TestBlastFurnaceModel(unittest.TestCase):
    def test_dummy_model_class(self):
        calc_times = [
            pd.Timestamp("2024-09-01 19:00:00", tzinfo=TZ_UTC),
            pd.Timestamp("2024-09-01 20:00:00", tzinfo=TZ_UTC),
        ]
        target_signal_name = "bf3_hotmetalsi_chem_pct"
        model = DummyBlastFurnaceModel(target_signal_name)
        data_defs = [model.get_data_definition(calc_time) for calc_time in calc_times]
        data_def = get_minmax_data_definition(data_defs)
        signal_group_data = get_signal_group_data(data_def)

        actual = model.calculate_batch(signal_group_data, calc_times)
        expected = [
            DummyBlastFurnaceModelResult(
                {
                    pd.Timestamp("2024-09-01 19:00:00+0000", tz=TZ_UTC).timestamp(): 10,
                },
                pd.Timestamp("2024-09-01 19:00:00+0000", tz=TZ_UTC),
                target_signal_name,
            ),
            DummyBlastFurnaceModelResult(
                {
                    pd.Timestamp("2024-09-01 20:00:00+0000", tz=TZ_UTC).timestamp(): 20,
                },
                pd.Timestamp("2024-09-01 20:00:00+0000", tz=TZ_UTC),
                "bf3_hotmetalsi_chem_pct",
            ),
        ]
        self.assertEqual(actual, expected)

    def test_minmax_data_definition(self):
        calc_times = [
            pd.Timestamp("2024-09-01 19:00:00", tzinfo=TZ_UTC),
            pd.Timestamp("2024-09-01 20:00:00", tzinfo=TZ_UTC),
            pd.Timestamp("2024-09-01 21:00:00", tzinfo=TZ_UTC),
        ]
        data_defs = [
            {
                "bf1_charge_flows": (calc_times[0] - pd.Timedelta("4h"), calc_times[0]),
                "bf1_tappings": (calc_times[0] - pd.Timedelta("8h"), calc_times[0]),
            },
            {
                "bf1_charge_flows": (calc_times[1] - pd.Timedelta("4h"), calc_times[1]),
                "bf1_hotblast": (calc_times[1] - pd.Timedelta("6h"), calc_times[1]),
            },
            {
                "bf1_tappings": (calc_times[2] - pd.Timedelta("8h"), calc_times[2]),
                "bf1_hotblast": (calc_times[2] - pd.Timedelta("6h"), calc_times[2]),
            },
        ]
        data_def = get_minmax_data_definition(data_defs)
        self.assertEqual(
            data_def,
            {
                "bf1_charge_flows": (
                    pd.Timestamp("2024-09-01 15:00:00+0000", tz="UTC"),
                    pd.Timestamp("2024-09-01 20:00:00+0000", tz="UTC"),
                ),
                "bf1_tappings": (
                    pd.Timestamp("2024-09-01 11:00:00+0000", tz="UTC"),
                    pd.Timestamp("2024-09-01 21:00:00+0000", tz="UTC"),
                ),
                "bf1_hotblast": (
                    pd.Timestamp("2024-09-01 14:00:00+0000", tz="UTC"),
                    pd.Timestamp("2024-09-01 21:00:00+0000", tz="UTC"),
                ),
            },
        )


if __name__ == "__main__":
    unittest.main()
