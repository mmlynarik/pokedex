import unittest
from pathlib import Path

import pandas as pd
from pandas.testing import assert_frame_equal

from dbfcore.dataset.signals.utils import calculate_charge_layers_attribute


class TestChargeLayersAttribute(unittest.TestCase):
    data_dir = "./tests/test_data"

    def test_calculate_layer_id(self):
        input_data = pd.read_csv(Path(self.data_dir, "test_charge_layers_attr_input.csv"))
        expected_output = pd.read_csv(
            Path(self.data_dir, "test_charge_layers_attr_output.csv"), index_col="charge_date"
        )
        signal_names = ["layer1_id", "layer2_id", "layer3_id", "layer4_id"]
        actual_output = calculate_charge_layers_attribute(input_data, "layer_id", signal_names, 4)
        assert_frame_equal(actual_output, expected_output)


if __name__ == "__main__":
    unittest.main()
