import unittest

import torch

from dbfcore.model.utils import PerSignalStatsBuffer, index_split


class TestIndexSplit(unittest.TestCase):
    def test_smoke(self):
        values = torch.Tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        indices = torch.Tensor([0, 1, 2]).long()
        all_indices = torch.Tensor([[0], [1], [2]])

        result = index_split(values, indices, all_indices)

        self.assertEqual(len(result), 3)
        self.assertTrue((result[0] == values[0:1]).all())
        self.assertTrue((result[1] == values[1:2]).all())
        self.assertTrue((result[2] == values[2:3]).all())

    def test_index_not_present(self):
        values = torch.Tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        indices = torch.Tensor([0, 1, 2]).long()
        all_indices = torch.Tensor([[0], [1], [2], [3]])

        result = index_split(values, indices, all_indices)

        self.assertEqual(len(result), 4)
        self.assertTrue((result[0] == values[0:1]).all())
        self.assertTrue((result[1] == values[1:2]).all())
        self.assertTrue((result[2] == values[2:3]).all())
        self.assertEqual(result[3].size(), torch.Size((0, 3)))

    def test_only_one_index(self):
        values = torch.Tensor([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        indices = torch.Tensor([1, 1, 1]).long()
        all_indices = torch.Tensor([[0], [1], [2], [3]])

        result = index_split(values, indices, all_indices)

        self.assertEqual(len(result), 4)
        self.assertEqual(result[0].size(), torch.Size((0, 3)))
        self.assertTrue((result[1] == values).all())
        self.assertEqual(result[2].size(), torch.Size((0, 3)))
        self.assertEqual(result[3].size(), torch.Size((0, 3)))

    def test_random_indices(self):
        values = torch.arange(12).reshape(12, 1)
        indices = torch.Tensor([0, 1, 2, 2, 2, 1, 1, 0, 0, 0, 2, 2]).long()
        all_indices = torch.Tensor([[0], [1], [2]])

        result = index_split(values, indices, all_indices)

        self.assertEqual(len(result), 3)
        self.assertTrue((result[0] == torch.Tensor([[0], [7], [8], [9]])).all())
        self.assertTrue((result[1] == torch.Tensor([[1], [5], [6]])).all())
        self.assertTrue((result[2] == torch.Tensor([[2], [3], [4], [10], [11]])).all())


class TestStatsBuffer(unittest.TestCase):
    def test_basic_operation(self):
        buffer = PerSignalStatsBuffer(2, 4, 1)

        self.assertTrue((buffer.per_signal_abs_mean() == torch.zeros(2)).all())
        self.assertTrue((buffer.per_signal_mean() == torch.zeros(2)).all())
        self.assertTrue((buffer.per_signal_abs_quantiles(torch.Tensor([0.99])) == torch.zeros(1, 2)).all())

        ################################

        buffer.push_all_signals(torch.Tensor([[0.5], [-0.5], [0.8]]), torch.Tensor([0, 1, 1]).long())
        # After previous push we should have
        # for signal 0 values [0.0, 0.0,  0.0, 0.5] -> mean therefore should be 0.5 / 4 same as abs mean
        # for signal 1 values [0.0, 0.0, -0.5, 0.8] -> mean therefore should be 0.3 / 4 abs mean 1.3 / 4
        abs_mean = buffer.per_signal_abs_mean()
        self.assertAlmostEqual(abs_mean[0].item(), 0.5 / 4)
        self.assertAlmostEqual(abs_mean[1].item(), 1.3 / 4)

        mean = buffer.per_signal_mean()
        self.assertAlmostEqual(mean[0].item(), 0.5 / 4)
        self.assertAlmostEqual(mean[1].item(), 0.3 / 4)

        quantiles = buffer.per_signal_abs_quantiles(torch.Tensor([0.0, 0.5, 1.0]))

        mins = quantiles[0]
        self.assertAlmostEqual(mins[0].item(), 0.0)
        self.assertAlmostEqual(mins[1].item(), 0.0)

        medians = quantiles[1]
        self.assertAlmostEqual(medians[0].item(), 0.0)
        self.assertAlmostEqual(medians[1].item(), 0.0)

        maxes = quantiles[2]
        self.assertAlmostEqual(maxes[0].item(), 0.5)
        self.assertAlmostEqual(maxes[1].item(), 0.8)

        ##############################

        buffer.push_all_signals(
            torch.Tensor([[0.5], [-0.5], [0.8], [0.9]]), torch.Tensor([0, 0, 0, 0]).long()
        )
        buffer.push_all_signals(
            torch.Tensor([[0.5], [-0.5], [0.8], [0.9], [1.0]]), torch.Tensor([1, 1, 1, 1, 1]).long()
        )
        # After previous pushes we should have
        # for signal 0 values [0.5, -0.5,  0.8, 0.9] -> mean therefore should be 1.7 / 4 abs mean 2.7 / 4
        # for signal 1 values [-0.5,  0.8, 0.9, 1.0] -> mean therefore should be 2.2 / 4 abs mean 3.2 / 4

        abs_mean = buffer.per_signal_abs_mean()
        self.assertAlmostEqual(abs_mean[0].item(), 2.7 / 4)
        self.assertAlmostEqual(abs_mean[1].item(), 3.2 / 4)

        mean = buffer.per_signal_mean()
        self.assertAlmostEqual(mean[0].item(), 1.7 / 4)
        self.assertAlmostEqual(mean[1].item(), 2.2 / 4)

        quantiles = buffer.per_signal_abs_quantiles(torch.Tensor([0.0, 0.5, 1.0]))

        mins = quantiles[0]
        self.assertAlmostEqual(mins[0].item(), 0.5)
        self.assertAlmostEqual(mins[1].item(), 0.5)

        medians = quantiles[1]
        self.assertAlmostEqual(medians[0].item(), 0.5)
        self.assertAlmostEqual(medians[1].item(), 0.8)

        maxes = quantiles[2]
        self.assertAlmostEqual(maxes[0].item(), 0.9)
        self.assertAlmostEqual(maxes[1].item(), 1.0)


if __name__ == "__main__":
    unittest.main()
