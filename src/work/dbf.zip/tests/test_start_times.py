import unittest

import pandas as pd

from dbfcore.model.datamodule.pisignal import CalculatedStartTimesDataset


class TestCalculatedStartTimesDataset(unittest.TestCase):
    def test_basic(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=-1)

        self.assertEqual(len(dataset), 5)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 60)
        self.assertEqual(dataset[2], start.timestamp() + 120)
        self.assertEqual(dataset[3], start.timestamp() + 180)
        self.assertEqual(dataset[4], start.timestamp() + 240)

    def test_larger_window_size(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("2min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=-1)

        self.assertEqual(len(dataset), 4)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 60)
        self.assertEqual(dataset[2], start.timestamp() + 120)
        self.assertEqual(dataset[3], start.timestamp() + 180)

    def test_larger_step(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("2min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=-1)

        self.assertEqual(len(dataset), 3)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 120)
        self.assertEqual(dataset[2], start.timestamp() + 240)

    def test_limit_1(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=1)

        self.assertEqual(len(dataset), 1)
        self.assertEqual(dataset[0], start.timestamp())

    def test_limit_2(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=2)

        self.assertEqual(len(dataset), 2)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 120)

    def test_limit_3(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=3)

        self.assertEqual(len(dataset), 3)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 60)
        self.assertEqual(dataset[2], start.timestamp() + 180)

    def test_limit_4(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=4)

        self.assertEqual(len(dataset), 4)
        self.assertEqual(dataset[0], start.timestamp())
        self.assertEqual(dataset[1], start.timestamp() + 60)
        self.assertEqual(dataset[2], start.timestamp() + 120)
        self.assertEqual(dataset[3], start.timestamp() + 180)

    def test_limit_5_and_more(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        for limit in range(5, 10, 1):
            dataset = CalculatedStartTimesDataset(start, end, step, window_size, limit=limit)

            self.assertEqual(len(dataset), 5)
            self.assertEqual(dataset[0], start.timestamp())
            self.assertEqual(dataset[1], start.timestamp() + 60)
            self.assertEqual(dataset[2], start.timestamp() + 120)
            self.assertEqual(dataset[3], start.timestamp() + 180)
            self.assertEqual(dataset[4], start.timestamp() + 240)

    def test_invalid_time(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("1min")

        self.assertRaises(
            ValueError, lambda: CalculatedStartTimesDataset(end, start, step, window_size, limit=-1)
        )

    def test_invalid_step(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("8min")
        window_size = pd.Timedelta("1min")

        self.assertRaises(
            ValueError, lambda: CalculatedStartTimesDataset(end, start, step, window_size, limit=-1)
        )

    def test_invalid_window_size(self):
        start = pd.Timestamp("2024-01-01T00:00:00")
        end = pd.Timestamp("2024-01-01T00:05:30")
        step = pd.Timedelta("1min")
        window_size = pd.Timedelta("8min")

        self.assertRaises(
            ValueError, lambda: CalculatedStartTimesDataset(end, start, step, window_size, limit=-1)
        )


if __name__ == "__main__":
    unittest.main()
