import unittest
from datetime import datetime

import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals.pulverized_coal import load_pulverized_coal


class FakePZVPHook:
    def __init__(self):
        pass

    def get_pulverized_coal_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        return pd.read_csv(
            "./tests/test_data/pc_analysis.csv",
            parse_dates=["pc_analysis_date"],
        )

    def get_pulverized_coal_ash_monthly_analysis(self, start: datetime, end: datetime) -> pd.DataFrame:
        return pd.read_csv(
            "./tests/test_data/pc_ash_monthly_analysis.csv",
            parse_dates=["pc_ash_monthly_analysis_date"],
        )


class FakeAZVPHook:
    pass


class FakePiClient:
    pass


class FakeOkoClient:
    pass


class FakeScadaClient:
    pass


class FakePvisClient:
    pass


class TestPulverizedCoalDataLoading(unittest.TestCase):
    def test_data_loading(self):
        start = pd.Timestamp(2023, 2, 25, tz="UTC")
        end = pd.Timestamp(2023, 4, 4, tz="UTC")
        datasources = DataSources(  # type: ignore
            azvp=FakeAZVPHook(),  # type: ignore
            pzvp=FakePZVPHook(),  # type: ignore
            pi=FakePiClient(),  # type: ignore
            scada=FakeScadaClient(),  # type: ignore
            oko=FakeOkoClient(),  # type: ignore
            pvis=FakePvisClient(),  # type: ignore
        )
        pulverized_coal_df = load_pulverized_coal(start, end, datasources)

        self.assertListEqual(
            pulverized_coal_df.columns.tolist(),
            [
                "pc_h2o_pct",
                "pc_h2o_an_pct",
                "pc_ash_pct",
                "pc_volatile_matter_pct",
                "pc_s_pct",
                "pc_heat_value_MJkg",
                "pc_fe2o3_ash_pct",
                "pc_sio2_ash_pct",
                "pc_cao_ash_pct",
                "pc_mgo_ash_pct",
                "pc_al2o3_ash_pct",
                "pc_mn_ash_pct",
                "pc_p_ash_pct",
                "pc_nao_ash_pct",
                "pc_k2o_ash_pct",
                "pc_tio2_ash_pct",
                "pc_pb_ash_pct",
                "pc_zn_ash_pct",
                "pc_cu_ash_pct",
            ],
        )
        self.assertIsInstance(pulverized_coal_df.index, pd.DatetimeIndex)
        self.assertTrue(pulverized_coal_df.index.is_unique)
        pd.testing.assert_index_equal(pulverized_coal_df.index, pulverized_coal_df.index.sort_values())
