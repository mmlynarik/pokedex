import unittest
import warnings
from tempfile import TemporaryDirectory

from dbfcore.model.vicregdecoder import VicRegDecoder
from tests.fixtures.common import get_checkpoint_path
from tests.fixtures.vicreg_config import get_test_vicreg_config_as_dict
from tests.fixtures.vicreg_decoder_config import get_test_vicreg_decoder_config_as_dict
from tests.fixtures.vicreg_decoder_training import train_vicreg_decoder_for_tests
from tests.fixtures.vicreg_training import train_vicreg_for_tests


class TestVicRegDecoderTraining(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore")

    def test_fast_training(self):
        with TemporaryDirectory() as tempdict:
            encoder_config = get_test_vicreg_config_as_dict(tempdict)
            encoder_model_path = get_checkpoint_path(tempdict, "vicreg_model")
            train_vicreg_for_tests(encoder_config, encoder_model_path)

            decoder_config = get_test_vicreg_decoder_config_as_dict(tempdict)
            decoder_model_path = get_checkpoint_path(tempdict, "vicreg_decoder_model")
            train_vicreg_decoder_for_tests(decoder_config, decoder_model_path)
            VicRegDecoder.load_from_checkpoint(decoder_model_path)


if __name__ == "__main__":
    unittest.main()
