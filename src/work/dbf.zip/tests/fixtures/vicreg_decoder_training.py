from pathlib import Path

from lightning import Trainer

from dbfcore.model.vicregdecoder import VicRegDecoder
from tests.fixtures.signalvaesimple_training import get_test_svaes_datamodule


def get_test_vicreg_decoder(config: dict) -> VicRegDecoder:
    return VicRegDecoder(**config["model"])


def train_vicreg_decoder_for_tests(config: dict, model_path: Path):
    # Vicreg decoder datamodule has the same initialization as SVAES datamodule therefore we use SVAES
    decoder_datamodule = get_test_svaes_datamodule(config)
    decoder_model = get_test_vicreg_decoder(config)
    decoder_trainer = Trainer(**config["trainer"])
    decoder_trainer.fit(model=decoder_model, datamodule=decoder_datamodule)
    decoder_trainer.save_checkpoint(model_path)
