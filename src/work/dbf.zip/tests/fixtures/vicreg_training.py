from pathlib import Path

from lightning import Trainer

from dbfcore.model.datamodule.pisignal import VicRegDataModule, VicRegSignal
from dbfcore.model.vicregtraining import RealVicReg
from tests.fixtures.common import get_random_data


def get_test_vicreg_model(config: dict) -> RealVicReg:
    return RealVicReg(**config["model"])


def get_test_vicreg_datamodule(config: dict) -> VicRegDataModule:
    data_path = config["data"]["signals"][0]["data_path"]

    random_data = get_random_data("2023", "2024", 1000, "TestSignal1")
    random_data.to_parquet(data_path)

    signals = [VicRegSignal(**signal) for signal in config["data"]["signals"]]
    return VicRegDataModule(signals, num_workers=0, sequence_length=64)


def train_vicreg_for_tests(config: dict, model_path: Path, train: bool = True):
    datamodule = get_test_vicreg_datamodule(config)
    model = get_test_vicreg_model(config)

    trainer = Trainer(**config["trainer"])
    if train:
        trainer.fit(model=model, datamodule=datamodule)
    else:
        trainer.strategy._lightning_module = model
    trainer.save_checkpoint(model_path)
