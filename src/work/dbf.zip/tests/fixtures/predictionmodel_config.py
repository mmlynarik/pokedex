from pathlib import Path


def get_test_predictionmodel_config_as_dict(directory_path: str, use_last_value: bool = False) -> dict:
    path_to_embeddings = Path(directory_path) / "signal1.embeddings"
    target_data_path = Path(directory_path) / "target1.parquet"

    return {
        "data": {
            "input_signals": [
                {
                    "path_to_embeddings": str(path_to_embeddings),
                    "name": "TestSignal1",
                    "start_time_offset_sec": -14400,
                }
            ],
            "future_signals": [
                {
                    "path_to_embeddings": str(path_to_embeddings),
                    "name": "TestSignal1",
                    "start_time_offset_sec": 0,
                }
            ],
            "target_signal": {
                "name": "TestTarget1",
                "data_path": str(target_data_path),
                "value_minimum": 0.1,
                "value_maximum": 1.9,
                "total_minimum": 0.0,
                "total_maximum": 2.0,
                "max_abs_gradient": 0.00005,
                "val_uncertainity_perc": 3.0,
                "time_uncertainity_sec": 300.0,
            },
            "train_val_split": {
                "train_start": "2023-01-01",
                "train_end": "2023-01-02",
                "val_start": "2023-01-02",
                "val_end": "2023-01-03",
            },
        },
        "model": {
            "bf_state_size": 10,
            "bf_action_size": 10,
            "hidden_size": [10, 10, 10],
            "output_rep_size": 10,
            "max_time_sec": 1440,
            "cdf_loss_weight": 0.01,
            "possibility_loss_weight": 1.0,
            "calibration_loss_weight": 1.0,
            "mse_loss_weight": 1.0,
            "focal_loss_weight": 1.0,
            "lip_loss_weight": 1.0,
            "log_images_every_n_steps": 100,
            "warmup_steps": 1000,
            "value_resolution": 51,
            "use_last_value": use_last_value,
        },
        "trainer": {
            "accelerator": "cpu",
            "fast_dev_run": 1,
            "enable_progress_bar": False,
            "enable_model_summary": False,
            "enable_checkpointing": False,
            "default_root_dir": directory_path,
        },
    }
