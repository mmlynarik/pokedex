from pathlib import Path


def get_test_svaes_config_as_dict(directory_path: str) -> dict:
    filename = Path(directory_path) / "signal1.parquet"

    return {
        "data": {
            "signals": [
                {
                    "name": "TestSignal1",
                    "data_path": filename,
                    "mean": 0.5,
                    "std": 0.3,
                    "train_val_split": {
                        "train_start": "2023-01-01",
                        "train_end": "2023-10-01",
                        "val_start": "2023-10-01",
                        "val_end": "2024-01-01",
                        "step": "4h",
                    },
                }
            ]
        },
        "model": {
            "window_size": "1h",
            "input_features": 2,
            "track_size": 4,
            "latent_dim": 4,
            "decoder_hidden_sizes": [10, 10],
            "output_rep_size": 4,
            "max_seq_len": 64,
            "signal_normalizers_params": [{"signal_name": "TestSignal1", "mean": 0.5, "std": 0.3}],
            "kldiv_loss_weight": 0.0,
            "log_images_every_n_train_steps": 100,
            "log_images_every_n_val_steps": 100,
        },
        "trainer": {
            "accelerator": "cpu",
            "fast_dev_run": 1,
            "enable_progress_bar": False,
            "enable_model_summary": False,
            "enable_checkpointing": False,
            "default_root_dir": directory_path,
        },
    }
