from pathlib import Path


def get_test_vicreg_config_as_dict(directory_path: str) -> dict:
    filename = Path(directory_path) / "signal1.parquet"

    return {
        "data": {
            "signals": [
                {
                    "name": "TestSignal1",
                    "data_path": filename,
                    "mean": 0.5,
                    "std": 0.3,
                    "start": "2023-01-01",
                    "end": "2024-01-01",
                    "step": "1min",
                    "size_limit": -1,
                }
            ]
        },
        "model": {
            "window_size": "1h",
            "input_features": 2,
            "track_size": 4,
            "latent_dim": 4,
            "projector_sizes": [512, 512, 512],
            "seq_len": 64,
            "signal_normalizers_params": [{"signal_name": "TestSignal", "mean": 0.5, "std": 0.3}],
            "invariance_loss_weight": 0.0,
            "variance_loss_weight": 0.0,
            "covariance_loss_weight": 0.0,
        },
        "trainer": {
            "accelerator": "cpu",
            "fast_dev_run": 1,
            "enable_progress_bar": False,
            "enable_model_summary": False,
            "enable_checkpointing": False,
            "default_root_dir": directory_path,
        },
    }
