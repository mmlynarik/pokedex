from pathlib import Path

import numpy as np
import pandas as pd
import yaml


def save_config_dict_to_yaml(config: dict, file_path: Path) -> None:
    with open(file_path, "w") as file:
        yaml.dump(config, file, default_flow_style=False)


def get_random_data(timefrom: str, timeto: str, sample_count: int, name: str) -> pd.DataFrame:
    timestamp_from = pd.Timestamp(timefrom, tz="UTC")
    timestamp_to = pd.Timestamp(timeto, tz="UTC")

    diff = timestamp_to.timestamp() - timestamp_from.timestamp()
    times = pd.to_datetime(
        pd.Series((np.random.rand(sample_count) * diff) + timestamp_from.timestamp()).astype(int),
        unit="s",
        utc=True,
    )
    values = np.random.rand(sample_count)

    return pd.DataFrame(zip(times, values), columns=["Timestamp", name]).set_index("Timestamp").sort_index()


def get_checkpoint_path(directory_name: str, checkpoint_name: str) -> Path:
    return Path(directory_name) / "checkpoints" / f"{checkpoint_name}.ckpt"
