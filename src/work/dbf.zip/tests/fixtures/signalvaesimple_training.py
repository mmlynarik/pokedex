from pathlib import Path

from lightning import Trainer

from dbfcore.model.datamodule.pisignal import Signal2, SignalsDataModule2, TrainValIntervals
from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from tests.fixtures.common import get_random_data


def get_test_svaes_model(config: dict) -> SignalVAESimple2:
    return SignalVAESimple2(**config["model"])


def get_test_svaes_datamodule(config: dict) -> SignalsDataModule2:
    data_path = config["data"]["signals"][0]["data_path"]

    random_data = get_random_data("2023", "2024", 1000, "TestSignal1")
    random_data.to_parquet(data_path)

    signals = []
    for signal in config["data"]["signals"]:
        train_val_split = TrainValIntervals(**signal["train_val_split"])
        signals.append(
            Signal2(
                signal["name"],
                signal["data_path"],
                signal["mean"],
                signal["std"],
                train_val_split,
            )
        )

    return SignalsDataModule2(signals, num_workers=0, sequence_length=64)


def train_signalvaesimple_for_tests(config: dict, model_path: Path):
    datamodule = get_test_svaes_datamodule(config)
    model = get_test_svaes_model(config)

    trainer = Trainer(**config["trainer"])
    trainer.fit(model=model, datamodule=datamodule)
    trainer.save_checkpoint(model_path)
