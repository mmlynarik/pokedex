from pathlib import Path
from tempfile import NamedTemporaryFile

import numpy as np
import pandas as pd
import torch
from lightning import Trainer

from dbfcore.model.datamodule.pisignal import TrainValIntervals
from dbfcore.predictionmodel.datamodule import InputSignalDefinition, PredictionModelDataModule, TargetSignal
from dbfcore.predictionmodel.model import PredictionModel
from tests.fixtures.common import get_random_data


def get_random_embeddings(
    start: str, end: str, sample_count: int, embedding_dim: int, signal_name: str
) -> dict:
    timestamp_from = pd.Timestamp.timestamp(pd.Timestamp(start))
    timestamp_to = pd.Timestamp.timestamp(pd.Timestamp(end))

    diff = timestamp_to - timestamp_from
    times = pd.to_datetime(
        pd.Series((np.random.rand(sample_count) * diff) + timestamp_from).astype(int), unit="s"
    )

    random_embeddings = torch.randn(sample_count, embedding_dim)
    random_masks = torch.randint(0, 2, (sample_count,))

    return {
        "embeddings": random_embeddings,
        "masks": random_masks,
        "start_times": times,
        "signal_normalizers_params": [{"signal_name": signal_name}],
        "indices": np.zeros(sample_count),
    }


def get_test_predictionmodel_model(config: dict) -> PredictionModel:
    return PredictionModel(**config["model"])


def get_test_predictionmodel_datamodule(config: dict) -> PredictionModelDataModule:
    path_to_embeddings = config["data"]["input_signals"][0]["path_to_embeddings"]
    target_data_path = config["data"]["target_signal"]["data_path"]

    train_start = config["data"]["train_val_split"]["train_start"]
    val_end = config["data"]["train_val_split"]["val_end"]

    random_embedding_data = get_random_embeddings(train_start, val_end, 1000, 10, "TestSignal1")
    torch.save(random_embedding_data, path_to_embeddings)

    random_target_data = get_random_data(train_start, val_end, 1000, "TestTarget1")
    random_target_data.to_parquet(target_data_path)

    input_signals = [
        InputSignalDefinition(**input_signal_config)
        for input_signal_config in config["data"]["input_signals"]
    ]
    future_signals = [
        InputSignalDefinition(**future_signal_config)
        for future_signal_config in config["data"]["future_signals"]
    ]
    target_signal = TargetSignal(**config["data"]["target_signal"])
    train_val_split = TrainValIntervals(**config["data"]["train_val_split"])

    temp_db = NamedTemporaryFile(suffix=".sqlite", delete=False)
    sqlite_database_path = temp_db.name
    temp_db.close()

    return PredictionModelDataModule(
        tuple(input_signals),
        tuple(future_signals),
        target_signal,
        "4h",
        train_val_split,
        sqlite_database_path,
        batch_size=2,
    )


def train_prediction_model_for_tests(config: dict, model_path: Path, train: bool = True):
    datamodule = get_test_predictionmodel_datamodule(config)
    model = get_test_predictionmodel_model(config)

    trainer = Trainer(**config["trainer"])
    if train:
        trainer.fit(model=model, datamodule=datamodule)
    else:
        trainer.strategy._lightning_module = model
    trainer.save_checkpoint(model_path)
