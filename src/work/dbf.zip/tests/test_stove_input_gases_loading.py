import unittest
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import pytz
from pandas.testing import assert_frame_equal, assert_index_equal

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals.stove_input_gases import (
    calc_topgas_n2_chem_pct_from_topgas_data,
    calculate_bfg_flow_per_stove_and_total_bfg_flow,
    calculate_ng_flow_per_stove_based_on_bfg_flow,
    calculate_stove_air_chem_composition,
    calculate_stove_bfg_chem_composition,
    calculate_stove_cog_chem_composition,
    calculate_stove_natural_gas_chem_composition,
    clean_stove_data,
    fill_missing_values_in_stove_data,
    get_cog_data,
    get_natural_gas_signal_name,
    get_stoves_natural_gas_data,
    get_topgas_data,
    get_waste_gas_aso_data,
    load_stoves_input_gases,
    preprocess_stove_data,
    preprocess_stove_data_based_on_airflow,
)


class FakePZVPHook:
    pass


class FakeAZVPHook:
    pass


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Top.Gas.CO.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:17.0620117Z", "Value": 24.0738823, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:17.0620117Z", "Value": 24.0849934, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:04.0550079Z", "Value": 24.1544361, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:51.0730133Z", "Value": 24.0618458, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:34.027008Z", "Value": 23.8998146, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:28.0450134Z", "Value": 23.9229622, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:42.0450134Z", "Value": 23.4789025, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.CO2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:44.050003Z", "Value": 20.2223606, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:44.050003Z", "Value": 20.4334717, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:02.0220031Z", "Value": 20.5463161, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:58.0570068Z", "Value": 20.416111, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:03.0310058Z", "Value": 20.3293076, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:59.0510101Z", "Value": 20.416111, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:12.0450673Z", "Value": 20.2769023, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.H2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:57.5580139Z", "Value": 2.701362, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:57.5580139Z", "Value": 2.702473, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:01.1280059Z", "Value": 2.64460421, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:32.1150054Z", "Value": 2.59541559, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:39.0510101Z", "Value": 2.59252214, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:40.0200042Z", "Value": 2.664858, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:25.0450673Z", "Value": 2.5899025, "Good": True},
                ]
            }
        elif "SK1.Stove.11.COGGas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:21.0360913Z", "Value": 1123.7845, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:17.0550079Z", "Value": 1151.6272, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:18.0390014Z", "Value": 1321.97107, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:19.024002Z", "Value": 1385.73364, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:44.0260009Z", "Value": 1439.63257, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:46.0420074Z", "Value": 1197.19189, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:42.0590057Z", "Value": 1226.641, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:52.0620117Z", "Value": 1190.33923, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:43.0620117Z", "Value": 1213.5617, "Good": True},
                ]
            }
        elif "SK1.Stove11.Blend Gas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:05:00.0520019Z", "Value": 32286.7988, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:01.0210113Z", "Value": 32274.81, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:02.1460113Z", "Value": 32739.0684, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:03.0210113Z", "Value": 32657.9531, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:04.0680084Z", "Value": 32830.98, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:05.0370025Z", "Value": 32668.707, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:06.0680084Z", "Value": 32537.01, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:07.0370025Z", "Value": 32427.873, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:08.0680084Z", "Value": 33160.1641, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:09.0370025Z", "Value": 33291.7344, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:31.0370025Z", "Value": 33258.9851, "Good": True},
                ]
            }
        elif "SK1.Stove11.CombustionAir.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:05:00.0520019Z", "Value": 39104.2773, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:01.0210113Z", "Value": 39152.5, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:02.1460113Z", "Value": 38971.83, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:03.0210113Z", "Value": 38757.8164, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:04.0680084Z", "Value": 38926.6367, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:05.0370025Z", "Value": 39191.9375, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:06.0680084Z", "Value": 39478.27, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:07.0370025Z", "Value": 39478.27, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:08.0680084Z", "Value": 39074.4063, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:09.0370025Z", "Value": 38881.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:11:52.0370025Z", "Value": 39268.32, "Good": True},
                ]
            }
        elif "SK1.Stove.12.COGGas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:42:05.0690002Z", "Value": 3128.879, "Good": True},
                    {"Timestamp": "2025-03-06T00:42:07.1000061Z", "Value": 3188.90039, "Good": True},
                    {"Timestamp": "2025-03-06T00:42:25.0850067Z", "Value": 3209.76123, "Good": True},
                    {"Timestamp": "2025-03-06T02:45:05.0690002Z", "Value": 3128.879, "Good": True},
                    {"Timestamp": "2025-03-06T02:45:07.1000061Z", "Value": 3188.90039, "Good": True},
                    {"Timestamp": "2025-03-06T02:45:25.0850067Z", "Value": 3209.76123, "Good": True},
                ]
            }
        elif "SK1.Stove12.Blend Gas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:54:52.0640106Z", "Value": 37477.9648, "Good": True},
                    {"Timestamp": "2025-03-06T00:54:53.0330047Z", "Value": 38614.0234, "Good": True},
                    {"Timestamp": "2025-03-06T00:54:54.0490112Z", "Value": 37683.77, "Good": True},
                    {"Timestamp": "2025-03-06T02:57:52.0640106Z", "Value": 37477.9648, "Good": True},
                    {"Timestamp": "2025-03-06T02:57:53.0330047Z", "Value": 38614.0234, "Good": True},
                    {"Timestamp": "2025-03-06T02:57:54.0490112Z", "Value": 37683.77, "Good": True},
                ]
            }
        elif "SK1.Stove12.CombustionAir.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:50:39.0700073Z", "Value": 38959.83, "Good": True},
                    {"Timestamp": "2025-03-06T00:50:40.0550079Z", "Value": 39851.67, "Good": True},
                    {"Timestamp": "2025-03-06T00:50:41.0550079Z", "Value": 41770.12, "Good": True},
                    {"Timestamp": "2025-03-06T02:53:39.0700073Z", "Value": 38959.83, "Good": True},
                    {"Timestamp": "2025-03-06T02:53:40.0550079Z", "Value": 39851.67, "Good": True},
                    {"Timestamp": "2025-03-06T02:53:41.0550079Z", "Value": 41770.12, "Good": True},
                ]
            }
        elif "SK1.Stove.13.COGGas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:54:30.0610046Z", "Value": 3920.88354, "Good": True},
                    {"Timestamp": "2025-03-06T00:54:34.0610046Z", "Value": 3918.324, "Good": True},
                    {"Timestamp": "2025-03-06T00:54:35.0460052Z", "Value": 3968.83569, "Good": True},
                    {"Timestamp": "2025-03-06T02:56:30.0610046Z", "Value": 3920.88354, "Good": True},
                    {"Timestamp": "2025-03-06T02:56:34.0610046Z", "Value": 3918.324, "Good": True},
                    {"Timestamp": "2025-03-06T02:56:35.0460052Z", "Value": 3968.83569, "Good": True},
                ]
            }
        elif "SK1.Stove13.Blend Gas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:42:23.0690002Z", "Value": 35337.42, "Good": True},
                    {"Timestamp": "2025-03-06T00:42:24.0540008Z", "Value": 36016.73, "Good": True},
                    {"Timestamp": "2025-03-06T00:42:25.0850067Z", "Value": 36813.55, "Good": True},
                    {"Timestamp": "2025-03-06T02:48:23.0690002Z", "Value": 35337.42, "Good": True},
                    {"Timestamp": "2025-03-06T02:48:24.0540008Z", "Value": 36016.73, "Good": True},
                    {"Timestamp": "2025-03-06T02:48:25.0850067Z", "Value": 36813.55, "Good": True},
                ]
            }
        elif "SK1.Stove13.CombustionAir.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:40:15.0650024Z", "Value": 46581.72, "Good": True},
                    {"Timestamp": "2025-03-06T00:40:16.0650024Z", "Value": 46692.4141, "Good": True},
                    {"Timestamp": "2025-03-06T00:40:17.0650024Z", "Value": 46735.9336, "Good": True},
                    {"Timestamp": "2025-03-06T02:51:15.0650024Z", "Value": 46581.72, "Good": True},
                    {"Timestamp": "2025-03-06T02:51:16.0650024Z", "Value": 46692.4141, "Good": True},
                    {"Timestamp": "2025-03-06T02:51:17.0650024Z", "Value": 46735.9336, "Good": True},
                ]
            }
        elif "SK1.Stove.14.COGGas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T00:29:34.0579986Z", "Value": 2184.5166, "Good": True},
                    {"Timestamp": "2025-03-06T00:29:45.0590057Z", "Value": 2221.41382, "Good": True},
                    {"Timestamp": "2025-03-06T00:29:58.0900115Z", "Value": 2179.75464, "Good": True},
                    {"Timestamp": "2025-03-06T02:31:34.0579986Z", "Value": 2184.5166, "Good": True},
                    {"Timestamp": "2025-03-06T02:31:45.0590057Z", "Value": 2221.41382, "Good": True},
                    {"Timestamp": "2025-03-06T02:31:58.0900115Z", "Value": 2179.75464, "Good": True},
                ]
            }
        elif "SK1.Stove14.Blend Gas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:32.0429992Z", "Value": 36879.1367, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:07.0429992Z", "Value": 36862.9922, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:08.0429992Z", "Value": 36853.92, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:09.0429992Z", "Value": 36850.9063, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:10.0429992Z", "Value": 36509.7266, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:11.0429992Z", "Value": 37101.1367, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:12.0429992Z", "Value": 36559.86, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:13.0429992Z", "Value": 36549.1563, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:14.0590057Z", "Value": 36835.7852, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:15.0429992Z", "Value": 37662.3828, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:16.0429992Z", "Value": 36098.69, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:21.0429992Z", "Value": 36081.45, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:35.0429992Z", "Value": 36087.28, "Good": True},
                ]
            }
        elif "SK1.Stove14.CombustionAir.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:32.0559997Z", "Value": 28006.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:46.0559997Z", "Value": 28027.4414, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:47.0400085Z", "Value": 28316.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:48.0559997Z", "Value": 28435.26, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:49.0250091Z", "Value": 28474.5762, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:50.0709991Z", "Value": 28542.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:51.0559997Z", "Value": 28566.5449, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:52.0250091Z", "Value": 28542.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:53.0559997Z", "Value": 28568.7852, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:54.0559997Z", "Value": 28617.002, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:55.0559997Z", "Value": 28117.3184, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:25.0559997Z", "Value": 28075.5472, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:28.0559997Z", "Value": 28103.2961, "Good": True},
                ]
            }
        elif "SK1.NaturalGas.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:07:50.0709991Z", "Value": 1860.2, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:52.0559997Z", "Value": 1870.4, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:48.0559997Z", "Value": 1790.0, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:52.0559997Z", "Value": 1750.8, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:02.0559997Z", "Value": 1740.8, "Good": True},
                ]
            }
        elif "SK1.Preheating.CombAir.Output.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:31.03700250Z", "Value": 165.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:46.0559997Z", "Value": 170.4414, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:47.0400085Z", "Value": 171.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:48.0559997Z", "Value": 170.26, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:49.0250091Z", "Value": 168.5762, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:50.0709991Z", "Value": 167.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:51.0559997Z", "Value": 167.5449, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:52.0250091Z", "Value": 169.44, "Good": True},
                ]
            }
        elif "SK1.Preheating.BFGas.Output.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:51.03700250Z", "Value": 166.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:56.0559997Z", "Value": 166.4414, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:57.0400085Z", "Value": 167.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:38.0559997Z", "Value": 166.26, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:59.0250091Z", "Value": 167.5762, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:40.0709991Z", "Value": 166.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:41.0559997Z", "Value": 166.5449, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:32.0250091Z", "Value": 167.44, "Good": True},
                ]
            }
        elif "SK3.Air.Exterior.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:30.03700250Z", "Value": 5.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:00.0559997Z", "Value": 6.4414, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:30.0400085Z", "Value": 7.8828, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:00.0559997Z", "Value": 6.26, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:30.0250091Z", "Value": 7.5762, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:30.0709991Z", "Value": 6.44, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:00.0559997Z", "Value": 6.5449, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:30.0250091Z", "Value": 7.44, "Good": True},
                ]
            }
        elif "SK1.AtmosphericMoisture" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:05:01.0210113Z", "Value": 65.27601, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:01.0390014Z", "Value": 64.55265, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:00.0559997Z", "Value": 64.20544, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:03.027008Z", "Value": 64.23437, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:00.076004Z", "Value": 63.9160919, "Good": True},
                ]
            }
        elif "SK1.Preheating.BFGas.Input.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:10.076004Z", "Value": 31.1074059, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:10.076004Z", "Value": 32.2564825, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:10.076004Z", "Value": 32.2564789, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:10.076004Z", "Value": 33.0214587, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:10.076004Z", "Value": 33.6547889, "Good": True},
                ]
            }
        elif "SK1.Preheating.BFGas.Input.Pres.Pa" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:20.0620117Z", "Value": 5.879474, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:37.0470123Z", "Value": 6.018355, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:37.0470123Z", "Value": 5.254785, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:37.0470123Z", "Value": 5.012458, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:37.0470123Z", "Value": 6.568795, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:37.0470123Z", "Value": 6.214578, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:37.0470123Z", "Value": 6.789554, "Good": True},
                ]
            }
        elif "SK1.Stove11.WasteGas.O2.Comtent.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:15.0620117Z", "Value": 1.466974, "Good": True},
                    {"Timestamp": "2025-03-06T01:04:16.0620117Z", "Value": 2.45074368, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:17.0620117Z", "Value": 2.45074368, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:18.0550079Z", "Value": 3.12202168, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:19.0730133Z", "Value": 3.12202168, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:20.027008Z", "Value": 3.27248049, "Good": True},
                    {"Timestamp": "2025-03-06T01:07:21.0450134Z", "Value": 3.27248049, "Good": True},
                    {"Timestamp": "2025-03-06T01:08:22.0450134Z", "Value": 3.590759, "Good": True},
                    {"Timestamp": "2025-03-06T01:09:23.0450134Z", "Value": 3.590759, "Good": True},
                    {"Timestamp": "2025-03-06T01:10:24.0450134Z", "Value": 3.88878322, "Good": True},
                ]
            }
        elif "SK1.Stove12.WasteGas.O2.Comtent.%" in url:
            return {"Items": []}
        elif "SK1.Stove13.WasteGas.O2.Comtent.%" in url:
            return {"Items": []}
        elif "SK1.Stove14.WasteGas.O2.Comtent.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-03-06T01:04:04.0620117Z", "Value": 9.93549891, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:15.0620117Z", "Value": 9.993941, "Good": True},
                    {"Timestamp": "2025-03-06T01:05:16.0620117Z", "Value": 10.0286627, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:18.0620117Z", "Value": 9.965007, "Good": True},
                    {"Timestamp": "2025-03-06T01:06:22.0550079Z", "Value": 9.944753, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class FakeOkoClient:
    pass


class FakeScadaClient:
    pass


class FakePvisClient:
    def __init__(self):
        pass

    def get_cog_chem_composition(self, start: datetime, end: datetime) -> pd.DataFrame:
        return pd.DataFrame(
            index=[
                0,
                1,
            ],
            data=[
                [
                    pd.Timestamp("2025-03-05 12:21:49"),
                    21.374,
                    60.913,
                    0.491,
                    6.966,
                    1.763,
                    1.570,
                    0.457,
                    0.070,
                    5.962,
                ],
                [
                    pd.Timestamp("2025-03-05 17:07:26"),
                    21.774,
                    56.842,
                    0.621,
                    10.141,
                    1.966,
                    1.703,
                    0.520,
                    0.071,
                    5.900,
                ],
            ],
            columns=[
                "last_update",
                "ch4_pct",
                "h2_pct",
                "o2_pct",
                "n2_pct",
                "co2_pct",
                "c2h4_pct",
                "c2h6_pct",
                "c2h2_pct",
                "co_pct",
            ],
        )


class TestStovesInputGasesDataLoading(unittest.TestCase):
    data_dir = "./tests/test_data"

    def test_data_loading(self):

        result_df = load_stoves_input_gases(
            start=pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC"),
            end=pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC"),
            furnace_id=1,
            datasources=DataSources(  # type: ignore
                azvp=FakeAZVPHook(),  # type: ignore
                pzvp=FakePZVPHook(),  # type: ignore
                pi=FakePiClient(),  # type: ignore
                scada=FakeScadaClient(),  # type: ignore
                oko=FakeOkoClient(),  # type: ignore
                pvis=FakePvisClient(),  # type: ignore
            ),
        )
        expected_df = pd.read_csv(
            Path(self.data_dir, "stove_data.csv"),
            parse_dates=["Timestamp"],
            index_col="Timestamp",
            dtype={
                "bf1_stove12_wastegas_aso_pct": "object",  # empty column
                "bf1_stove13_wastegas_aso_pct": "object",  # empty column
            },
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))
        # Convert all integer columns to float - due to columns where all values are filled with zero.
        expected_df = expected_df.astype({col: "float64" for col in expected_df.select_dtypes("int").columns})

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_clean_stove_data(self):
        signal_name = "bf1_stove11_bfg_flow_m3h"
        stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2024, 1, 1, 12, 41, 29, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 30, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 31, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 32, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 33, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 34, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 35, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 35, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                0,
                -520.81,
                5962.63,
                10452.41,
                13713.04,
                16998.14,
                19208.95,
                21585.4,
            ],
            columns=[signal_name],
        )

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2024, 1, 1, 12, 41, 29, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 30, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 31, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 32, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 33, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 34, tzinfo=pytz.UTC),
                    pd.Timestamp(2024, 1, 1, 12, 41, 35, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            # random data
            data=[
                0,
                0,
                5962.63,
                10452.41,
                13713.04,
                16998.14,
                19208.95,
            ],
            columns=[signal_name],
        )

        result_df = clean_stove_data(stove_data, signal_name)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)
        self.assertFalse((result_df < 0).any().any())

    def test_fill_missing_values_in_stove_data(self):
        stove_data = pd.read_csv(
            Path(self.data_dir, "stove_data_with_missing_values.csv"),
            parse_dates=["Timestamp"],
            index_col="Timestamp",
        )

        expected_df = pd.read_csv(
            Path(self.data_dir, "stove_data_filled.csv"), parse_dates=["Timestamp"], index_col="Timestamp"
        )

        signal_name = "bf1_stove11_cog_flow_m3h"
        result_df = fill_missing_values_in_stove_data(stove_data, signal_name)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_get_cog_data(self):
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
                [
                    21.87506279,
                    57.10582893,
                    0.623882336,
                    10.18806888,
                    1.975125078,
                    1.710904378,
                    0.522413551,
                    0.071329542,
                    5.927384516,
                ],
            ],
            columns=[
                "ch4_pct",
                "h2_pct",
                "o2_pct",
                "n2_pct",
                "co2_pct",
                "c2h4_pct",
                "c2h6_pct",
                "c2h2_pct",
                "co_pct",
            ],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        start = pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC")
        end = pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC")
        datasources = DataSources(  # type: ignore
            azvp=FakeAZVPHook(),  # type: ignore
            pzvp=FakePZVPHook(),  # type: ignore
            pi=FakePiClient(),  # type: ignore
            scada=FakeScadaClient(),  # type: ignore
            oko=FakeOkoClient(),  # type: ignore
            pvis=FakePvisClient(),  # type: ignore
        )
        result_df = get_cog_data(start, end, datasources)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)
        self.assertTrue(np.allclose(result_df[result_df.columns].sum(axis=1), 100))

    def test_calc_topgas_n2_chem_pct_from_topgas_data(self):
        topgas_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 11, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [24.0849934, 20.4334717, 2.702473],
                [24.1544361, 20.5463161, 2.64460421],
                [24.0618458, 20.416111, 2.59541559],
                [23.8998146, 20.3293076, 2.59252214],
                [23.9229622, 20.416111, 2.664858],
                [23.70093235, 20.34650665, 2.62738025],
                [23.4789025, 20.2769023, 2.5899025],
            ],
            columns=["bf1_topgasco_chem_pct", "bf1_topgasco2_chem_pct", "bf1_topgash2_chem_pct"],
        )
        furnace_id = 1

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 11, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [24.0849934, 20.4334717, 2.702473, 52.7790619],
                [24.1544361, 20.5463161, 2.64460421, 52.65464359],
                [24.0618458, 20.416111, 2.59541559, 52.92662761],
                [23.8998146, 20.3293076, 2.59252214, 53.17835566],
                [23.9229622, 20.416111, 2.664858, 52.9960688],
                [23.70093235, 20.34650665, 2.62738025, 53.32518075],
                [23.4789025, 20.2769023, 2.5899025, 53.6542927],
            ],
            columns=[
                "bf1_topgasco_chem_pct",
                "bf1_topgasco2_chem_pct",
                "bf1_topgash2_chem_pct",
                "bf1_topgasn2_chem_pct",
            ],
        )

        result_df = calc_topgas_n2_chem_pct_from_topgas_data(topgas_data, furnace_id)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)
        self.assertTrue((result_df.sum(axis=1) == 100).all())

    def test_get_topgas_data(self):
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 11, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [24.07786378, 20.25050875, 2.701389775, 52.9702377],
                [24.10786896, 20.39220643, 2.700533737, 52.79939087],
                [24.13127057, 20.51420286, 2.628658449, 52.72586812],
                [24.07740793, 20.44616668, 2.599591783, 52.87683361],
                [23.93755462, 20.35079144, 2.597620945, 53.11403299],
                [23.89109952, 20.39474005, 2.646943644, 53.06721679],
                [23.7158448, 20.35604149, 2.628807974, 53.29930573],
            ],
            columns=[
                "bf1_topgasco_chem_pct",
                "bf1_topgasco2_chem_pct",
                "bf1_topgash2_chem_pct",
                "bf1_topgasn2_chem_pct",
            ],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        start = pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC")
        end = pd.Timestamp(2025, 3, 6, 1, 11, 0, tz="UTC")
        furnace_id = 1
        datasources = DataSources(  # type: ignore
            azvp=FakeAZVPHook(),  # type: ignore
            pzvp=FakePZVPHook(),  # type: ignore
            pi=FakePiClient(),  # type: ignore
            scada=FakeScadaClient(),  # type: ignore
            oko=FakeOkoClient(),  # type: ignore
            pvis=FakePvisClient(),  # type: ignore
        )
        result_df = get_topgas_data(start, end, furnace_id, datasources)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_calculate_stove_cog_chem_composition(self):
        start = pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC")
        end = pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC")
        datasources = DataSources(  # type: ignore
            azvp=FakeAZVPHook(),  # type: ignore
            pzvp=FakePZVPHook(),  # type: ignore
            pi=FakePiClient(),  # type: ignore
            scada=FakeScadaClient(),  # type: ignore
            oko=FakeOkoClient(),  # type: ignore
            pvis=FakePvisClient(),  # type: ignore
        )
        furnace_id = 1
        stove_number = 11
        cog_data = get_cog_data(start, end, datasources)

        stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                1212.398992,
                1286.44397,
                1318.41223,
                1226.641,
                1190.33923,
                1168.995785,
            ],
            columns=["bf1_stove11_cog_flow_m3h"],
        )

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    390.3670552,
                    128.058743,
                    22.20566536,
                    317.4718798,
                    96.68839927,
                    53.38986185,
                    17.47375041,
                    2.065928695,
                    184.6777084,
                ],
                [
                    414.2079857,
                    135.8796888,
                    23.56183442,
                    336.8608751,
                    102.5934606,
                    56.6505468,
                    18.54092671,
                    2.192101387,
                    195.9565506,
                ],
                [
                    424.5010951,
                    139.2563125,
                    24.14734834,
                    345.2319012,
                    105.1429182,
                    58.05831849,
                    19.00167057,
                    2.246575323,
                    200.8260902,
                ],
                [
                    394.9526832,
                    129.5630445,
                    22.46651452,
                    321.2012107,
                    97.82419447,
                    54.01703066,
                    17.67901394,
                    2.090197086,
                    186.8471109,
                ],
                [
                    383.2642744,
                    125.728697,
                    21.80163031,
                    311.6954364,
                    94.9291409,
                    52.41842616,
                    17.15581319,
                    2.028338846,
                    181.3174728,
                ],
                [
                    376.3921326,
                    123.4743115,
                    21.41071494,
                    306.1065637,
                    93.22700856,
                    51.4785346,
                    16.84819991,
                    1.991969601,
                    178.0663496,
                ],
            ],
            columns=[
                "bf1_stove11_cog_ch4_flow_m3h",
                "bf1_stove11_cog_h2_flow_m3h",
                "bf1_stove11_cog_o2_flow_m3h",
                "bf1_stove11_cog_n2_flow_m3h",
                "bf1_stove11_cog_co2_flow_m3h",
                "bf1_stove11_cog_c2h4_flow_m3h",
                "bf1_stove11_cog_c2h6_flow_m3h",
                "bf1_stove11_cog_c2h2_flow_m3h",
                "bf1_stove11_cog_co_flow_m3h",
            ],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        result_df = calculate_stove_cog_chem_composition(cog_data, stove_data, furnace_id, stove_number)

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_calculate_stove_bfg_chem_composition(self):
        start = pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC")
        end = pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC")
        furnace_id = 1
        datasources = DataSources(  # type: ignore
            azvp=FakeAZVPHook(),  # type: ignore
            pzvp=FakePZVPHook(),  # type: ignore
            pi=FakePiClient(),  # type: ignore
            scada=FakeScadaClient(),  # type: ignore
            oko=FakeOkoClient(),  # type: ignore
            pvis=FakePvisClient(),  # type: ignore
        )
        stove_number = 11
        topgas_data = get_topgas_data(start, end, furnace_id, datasources)

        stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                33673.86235,
                33477.7769,
                34798.71971,
                33265.01728,
                34211.91957,
                33958.70998,
            ],
            columns=["bf1_stove11_bfg_flow_m3h"],
        )
        bfg_properties_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[[25, 6]] * 6,
            columns=["bfg_temperature", "bfg_pressure"],
        )

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [7214.4129, 9533.390251, 58.25694575, 15873.65652, 994.1457315],
                [7175.965122, 9537.05105, 57.8560158, 15718.54797, 988.3567456],
                [7457.032881, 9960.219427, 58.46520112, 16295.64756, 1027.354638],
                [7113.236394, 9490.690247, 55.27644258, 15623.7387, 982.075492],
                [7276.728007, 9719.995296, 56.83417445, 16148.33142, 1010.030672],
                [7210.219098, 9670.721806, 57.49557723, 16017.71828, 1002.555223],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove11_bfg_h2o_flow_m3h",
            ],
        )

        result_df = calculate_stove_bfg_chem_composition(
            topgas_data, stove_data, bfg_properties_data, furnace_id, stove_number
        )

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_calculate_stove_air_chem_composition(self):
        stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                39307.73304,
                38963.25354,
                40464.6536,
                38564.5948,
                39462.70932,
                39435.79271,
            ],
            columns=["bf1_stove11_air_flow_m3h"],
        )
        air_properties_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[[0.5, 25]] * 6,
            columns=["air_relative_humidity", "air_temperature"],
        )
        furnace_id = 1
        stove_number = 11

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2025, 3, 6, 1, 5, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 6, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 7, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 8, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 9, 0, tzinfo=pytz.UTC),
                    pd.Timestamp(2025, 3, 6, 1, 10, 0, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                [8125.558874, 30567.578622, 614.595543],
                [8054.349261, 30299.694840, 609.209439],
                [8364.713498, 31467.255542, 632.684560],
                [7971.939903, 29989.678682, 602.976215],
                [8157.595036, 30688.095611, 617.018673],
                [8152.030927, 30667.163964, 616.597819],
            ],
            columns=[
                "bf1_stove11_air_o2_flow_m3h",
                "bf1_stove11_air_n2_flow_m3h",
                "bf1_stove11_air_h2o_flow_m3h",
            ],
        )

        result_df = calculate_stove_air_chem_composition(
            stove_data, air_properties_data, furnace_id, stove_number
        )

        assert_frame_equal(expected_df, result_df)
        assert_index_equal(result_df.index, result_df.index.sort_values())
        self.assertTrue(result_df.index.is_unique)

    def test_preprocess_stove_data(self):
        # Check if the preprocessed stove data are regular time series data.
        # Verify that the time intervals between consecutive timestamps are consistent.
        signal_name = "bf1_stove11_cog_flow_m3h"
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:05:00+00:00"),
                    pd.Timestamp("2025-03-06 01:05:01+00:00"),
                    pd.Timestamp("2025-03-06 01:05:02+00:00"),
                    pd.Timestamp("2025-03-06 01:05:03+00:00"),
                    pd.Timestamp("2025-03-06 01:05:04+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05+00:00"),
                    pd.Timestamp("2025-03-06 01:05:06+00:00"),
                    pd.Timestamp("2025-03-06 01:05:07+00:00"),
                    pd.Timestamp("2025-03-06 01:05:08+00:00"),
                    pd.Timestamp("2025-03-06 01:05:09+00:00"),
                    pd.Timestamp("2025-03-06 01:05:10+00:00"),
                    pd.Timestamp("2025-03-06 01:05:11+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                1150.0,
                1184.0,
                1218.0,
                1252.0,
                1286.0,
                1320.0,
                1330.0,
                1340.0,
                1350.0,
                1360.0,
                1370.0,
                1380.0,
                1390.0,
            ],
            columns=[signal_name],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        irregular_stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:05:00.062011700+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05.050003+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12.558013900+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                1150,
                1320,
                1390,
            ],
            columns=[signal_name],
        )

        result_df = preprocess_stove_data(irregular_stove_data, signal_name)
        time_diffs = result_df.index.to_series().diff().dropna()

        assert_frame_equal(expected_df, result_df)
        # Check if the resulting DataFrame has a regular time interval
        self.assertEqual(time_diffs.nunique(), 1)

    def test_preprocess_stove_data_with_air_flow_stove_data(self):
        # Check if the preprocessed air flow stove data are regular time series data.
        # Verify that the time intervals between consecutive timestamps are consistent.
        # Check that the values are bigger than 550 m3/h or 0 m3/h.
        signal_name = "bf1_stove11_air_flow_m3h"
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:04:59+00:00"),
                    pd.Timestamp("2025-03-06 01:05:00+00:00"),
                    pd.Timestamp("2025-03-06 01:05:01+00:00"),
                    pd.Timestamp("2025-03-06 01:05:02+00:00"),
                    pd.Timestamp("2025-03-06 01:05:03+00:00"),
                    pd.Timestamp("2025-03-06 01:05:04+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05+00:00"),
                    pd.Timestamp("2025-03-06 01:05:06+00:00"),
                    pd.Timestamp("2025-03-06 01:05:07+00:00"),
                    pd.Timestamp("2025-03-06 01:05:08+00:00"),
                    pd.Timestamp("2025-03-06 01:05:09+00:00"),
                    pd.Timestamp("2025-03-06 01:05:10+00:00"),
                    pd.Timestamp("2025-03-06 01:05:11+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                0.0,
                41150.0,
                41184.0,
                41218.0,
                41252.0,
                41286.0,
                41320.0,
                41330.0,
                41340.0,
                41350.0,
                41360.0,
                41370.0,
                41380.0,
                41390.0,
            ],
            columns=[signal_name],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        irregular_stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:04:59.80139+00:00"),
                    pd.Timestamp("2025-03-06 01:05:00.062011700+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05.050003+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12.558013900+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                125,
                41150,
                41320,
                41390,
            ],
            columns=[signal_name],
        )

        result_df = preprocess_stove_data(irregular_stove_data, signal_name)
        time_diffs = result_df.index.to_series().diff().dropna()

        assert_frame_equal(expected_df, result_df)
        # Check if the resulting DataFrame has a regular time interval
        self.assertEqual(time_diffs.nunique(), 1)

        # Check that all values are bigger than 550 or equal 0.
        self.assertTrue(((result_df[signal_name] >= 550).any() | (result_df[signal_name] == 0).any()))

    def test_get_stoves_natural_gas_data(self):
        result_df = get_stoves_natural_gas_data(
            start=pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC"),
            end=pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC"),
            furnace_id=1,
            datasources=DataSources(  # type: ignore
                azvp=FakeAZVPHook(),  # type: ignore
                pzvp=FakePZVPHook(),  # type: ignore
                pi=FakePiClient(),  # type: ignore
                scada=FakeScadaClient(),  # type: ignore
                oko=FakeOkoClient(),  # type: ignore
                pvis=FakePvisClient(),  # type: ignore
            ),
        )

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                    pd.Timestamp("2025-03-06 01:09:00+00:00"),
                    pd.Timestamp("2025-03-06 01:10:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[1864.31039, 1809.531429, 1741.3],
            columns=[get_natural_gas_signal_name(furnace_id=1)],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))
        assert_frame_equal(expected_df, result_df)

        time_diffs = result_df.index.to_series().diff().dropna()
        # Check if the resulting DataFrame has a regular time interval
        self.assertEqual(time_diffs.nunique(), 1)

    def test_calculate_bfg_flow_per_stove_and_total_bfg_flow(self):
        stoves_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [  # bfg chem composition per stove
                    7700,
                    6500,
                    800,
                    17000,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    8800,
                    7500,
                    960,
                    19600,
                ],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
            ],
        )
        furnace_id = 1
        result_df = calculate_bfg_flow_per_stove_and_total_bfg_flow(stoves_data, furnace_id)
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    # bfg chem composition per stove
                    7700,
                    6500,
                    800,
                    17000,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    8800,
                    7500,
                    960,
                    19600,
                    # bfg flow per stove
                    32000,
                    0,
                    0,
                    36860,
                    # total bfg flow
                    68860,
                ],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
                "bf1_stove11_bfg_flow_m3h",
                "bf1_stove12_bfg_flow_m3h",
                "bf1_stove13_bfg_flow_m3h",
                "bf1_stove14_bfg_flow_m3h",
                "bf1_total_bfg_flow_m3h",
            ],
        )
        assert_frame_equal(expected_df, result_df)

    def test_calculate_ng_flow_per_stove_based_on_bfg_flow(self):
        stoves_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    # bfg chem composition per stove
                    7700,
                    6500,
                    800,
                    17000,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    8800,
                    7500,
                    960,
                    19600,
                    # bfg flow per stove
                    32000,
                    0,
                    0,
                    36860,
                    # total bfg flow
                    68860,
                    # total ng flow
                    1800,
                ],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
                "bf1_stove11_bfg_flow_m3h",
                "bf1_stove12_bfg_flow_m3h",
                "bf1_stove13_bfg_flow_m3h",
                "bf1_stove14_bfg_flow_m3h",
                "bf1_total_bfg_flow_m3h",
                "bf1_stoves_natural_gas_flow_m3h",
            ],
        )
        furnace_id = 1

        result_df = calculate_ng_flow_per_stove_based_on_bfg_flow(stoves_data, furnace_id)
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    # bfg chem composition per stove
                    7700,
                    6500,
                    800,
                    17000,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    8800,
                    7500,
                    960,
                    19600,
                    # bfg flow per stove
                    32000,
                    0,
                    0,
                    36860,
                    # total bfg flow
                    68860,
                    # total ng flow
                    1800,
                    # ng flow per stove
                    836.4798141,
                    0.0,
                    0.0,
                    963.5201859,
                ],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
                "bf1_stove11_bfg_flow_m3h",
                "bf1_stove12_bfg_flow_m3h",
                "bf1_stove13_bfg_flow_m3h",
                "bf1_stove14_bfg_flow_m3h",
                "bf1_total_bfg_flow_m3h",
                "bf1_stoves_natural_gas_flow_m3h",
                "bf1_stove11_ng_flow_m3h",
                "bf1_stove12_ng_flow_m3h",
                "bf1_stove13_ng_flow_m3h",
                "bf1_stove14_ng_flow_m3h",
            ],
        )
        assert_frame_equal(expected_df, result_df)

    def test_calculate_stove_natural_gas_chem_composition(self):
        stoves_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    # bfg chem composition per stove
                    7700.0,
                    6500.0,
                    800.0,
                    17000.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    8800.0,
                    7500.0,
                    960.0,
                    19600.0,
                    # total ng flow
                    1800.0,
                ],
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
                "bf1_stoves_natural_gas_flow_m3h",
            ],
        )
        furnace_id = 1
        result_df = calculate_stove_natural_gas_chem_composition(stoves_data, furnace_id)
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                [
                    # bfg chem composition per stove
                    7700.0,
                    6500.0,
                    800.0,
                    17000.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    8800.0,
                    7500.0,
                    960.0,
                    19600.0,
                    # total ng flow
                    1800.0,
                    # bfg flow per stove
                    32000.0,
                    0.0,
                    0.0,
                    36860.0,
                    # total bfg flow
                    68860.0,
                    # ng flow per stove
                    836.4798141,
                    0.0,
                    0.0,
                    963.5201859,
                    # ng chem composition per stove
                    783.4829625,  # stove11 - ch4 -> 93.6643%
                    30.54155097,  # stove11 - c2h6 -> 3.6512%
                    13.43721173,  # stove11 - c3h8 -> 1.6064%
                    4.760406622,  # stove11 - co2 -> 0.5691%
                    5.923113564,  # stove11 - n2 -> 0.7081%
                    0.005855359,  # stove11 - h2 -> 0.0007%
                    0.002509439,  # stove11 - o2 -> 0.0003%
                    0.0,  # stove12 - ch4 -> 93.6643%
                    0.0,  # stove12 - c2h6 -> 3.6512%
                    0.0,  # stove12 - c3h8 -> 1.6064%
                    0.0,  # stove12 - co2 -> 0.5691%
                    0.0,  # stove12 - n2 -> 0.7081%
                    0.0,  # stove12 - h2 -> 0.0007%
                    0.0,  # stove12 - o2 -> 0.0003%
                    0.0,  # stove13 - ch4 -> 93.6643%
                    0.0,  # stove13 - c2h6 -> 3.6512%
                    0.0,  # stove13 - c3h8 -> 1.6064%
                    0.0,  # stove13 - co2 -> 0.5691%
                    0.0,  # stove13 - n2 -> 0.7081%
                    0.0,  # stove13 - h2 -> 0.0007%
                    0.0,  # stove13 - o2 -> 0.0003%
                    902.4744375,  # stove14 - ch4 -> 93.6643%
                    35.18004903,  # stove14 - c2h6 -> 3.6512%
                    15.47798827,  # stove14 - c3h8 -> 1.6064%
                    5.483393378,  # stove14 - co2 -> 0.5691%
                    6.822686436,  # stove14 - n2 -> 0.7081%
                    0.006744641,  # stove14 - h2 -> 0.0007%
                    0.002890561,  # stove14 - o2 -> 0.0003%
                ]
            ],
            columns=[
                "bf1_stove11_bfg_co_flow_m3h",
                "bf1_stove11_bfg_co2_flow_m3h",
                "bf1_stove11_bfg_h2_flow_m3h",
                "bf1_stove11_bfg_n2_flow_m3h",
                "bf1_stove12_bfg_co_flow_m3h",
                "bf1_stove12_bfg_co2_flow_m3h",
                "bf1_stove12_bfg_h2_flow_m3h",
                "bf1_stove12_bfg_n2_flow_m3h",
                "bf1_stove13_bfg_co_flow_m3h",
                "bf1_stove13_bfg_co2_flow_m3h",
                "bf1_stove13_bfg_h2_flow_m3h",
                "bf1_stove13_bfg_n2_flow_m3h",
                "bf1_stove14_bfg_co_flow_m3h",
                "bf1_stove14_bfg_co2_flow_m3h",
                "bf1_stove14_bfg_h2_flow_m3h",
                "bf1_stove14_bfg_n2_flow_m3h",
                "bf1_stoves_natural_gas_flow_m3h",
                "bf1_stove11_bfg_flow_m3h",
                "bf1_stove12_bfg_flow_m3h",
                "bf1_stove13_bfg_flow_m3h",
                "bf1_stove14_bfg_flow_m3h",
                "bf1_total_bfg_flow_m3h",
                "bf1_stove11_ng_flow_m3h",
                "bf1_stove12_ng_flow_m3h",
                "bf1_stove13_ng_flow_m3h",
                "bf1_stove14_ng_flow_m3h",
                "bf1_stove11_ng_ch4_flow_m3h",
                "bf1_stove11_ng_c2h6_flow_m3h",
                "bf1_stove11_ng_c3h8_flow_m3h",
                "bf1_stove11_ng_co2_flow_m3h",
                "bf1_stove11_ng_n2_flow_m3h",
                "bf1_stove11_ng_h2_flow_m3h",
                "bf1_stove11_ng_o2_flow_m3h",
                "bf1_stove12_ng_ch4_flow_m3h",
                "bf1_stove12_ng_c2h6_flow_m3h",
                "bf1_stove12_ng_c3h8_flow_m3h",
                "bf1_stove12_ng_co2_flow_m3h",
                "bf1_stove12_ng_n2_flow_m3h",
                "bf1_stove12_ng_h2_flow_m3h",
                "bf1_stove12_ng_o2_flow_m3h",
                "bf1_stove13_ng_ch4_flow_m3h",
                "bf1_stove13_ng_c2h6_flow_m3h",
                "bf1_stove13_ng_c3h8_flow_m3h",
                "bf1_stove13_ng_co2_flow_m3h",
                "bf1_stove13_ng_n2_flow_m3h",
                "bf1_stove13_ng_h2_flow_m3h",
                "bf1_stove13_ng_o2_flow_m3h",
                "bf1_stove14_ng_ch4_flow_m3h",
                "bf1_stove14_ng_c2h6_flow_m3h",
                "bf1_stove14_ng_c3h8_flow_m3h",
                "bf1_stove14_ng_co2_flow_m3h",
                "bf1_stove14_ng_n2_flow_m3h",
                "bf1_stove14_ng_h2_flow_m3h",
                "bf1_stove14_ng_o2_flow_m3h",
            ],
        )
        assert_frame_equal(expected_df, result_df)

    def test_get_waste_gas_aso_data(self):
        air_signal_name = "bf1_stove11_air_flow_m3h"
        air_stove_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:05:00+00:00"),
                    pd.Timestamp("2025-03-06 01:06:00+00:00"),
                    pd.Timestamp("2025-03-06 01:07:00+00:00"),
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                    pd.Timestamp("2025-03-06 01:09:00+00:00"),
                    pd.Timestamp("2025-03-06 01:10:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                0.0,
                41150.0,
                41184.0,
                41218.0,
                41252.0,
                41286.0,
            ],
            columns=[air_signal_name],
        )
        result_df = get_waste_gas_aso_data(
            start=pd.Timestamp(2025, 3, 6, 1, 5, 0, tz="UTC"),
            end=pd.Timestamp(2025, 3, 6, 1, 10, 0, tz="UTC"),
            furnace_id=1,
            datasources=DataSources(  # type: ignore
                azvp=FakeAZVPHook(),  # type: ignore
                pzvp=FakePZVPHook(),  # type: ignore
                pi=FakePiClient(),  # type: ignore
                scada=FakeScadaClient(),  # type: ignore
                oko=FakeOkoClient(),  # type: ignore
                pvis=FakePvisClient(),  # type: ignore
            ),
            air_signal_name=air_signal_name,
            air_stove_data=air_stove_data,
        )

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:06:00+00:00"),
                    pd.Timestamp("2025-03-06 01:07:00+00:00"),
                    pd.Timestamp("2025-03-06 01:08:00+00:00"),
                    pd.Timestamp("2025-03-06 01:09:00+00:00"),
                    pd.Timestamp("2025-03-06 01:10:00+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                # np.nan,
                2.967221065,
                3.264669787,
                3.340310336,
                3.57067093,
                3.64800245,
            ],
            columns=["bf1_stove11_wastegas_aso_pct"],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        assert_frame_equal(expected_df, result_df)


def test_preprocess_stoves_data_based_on_airflow(self):
    stoves_data_before_preprocessing = pd.read_csv(
        Path(self.data_dir, "stoves_data_before_preprocessing.csv"),
        parse_dates=["Timestamp"],
        index_col="Timestamp",
    )
    result_df = preprocess_stove_data_based_on_airflow(stoves_data=stoves_data_before_preprocessing)

    expected_df = pd.read_csv(
        Path(self.data_dir, "stoves_data_after_preprocessing.csv"),
        parse_dates=["Timestamp"],
        index_col="Timestamp",
    )

    assert_frame_equal(expected_df, result_df)
