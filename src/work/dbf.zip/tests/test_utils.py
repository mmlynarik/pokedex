import unittest
from datetime import datetime, timedelta, timezone

import pytz
import torch
from pandas import Timestamp

from dbfcore.utils import flat_tensor_to_float32_bytes, float32_bytes_to_flat_tensor, is_utc


class TestGetWindowStarts(unittest.TestCase):
    def test_random_flat_tensor(self):
        random_tensor = torch.rand(torch.randint(1, 100, (1,))[0], dtype=torch.float32)  # type: ignore
        after_save_and_load = float32_bytes_to_flat_tensor(flat_tensor_to_float32_bytes(random_tensor))
        self.assertTrue((random_tensor == after_save_and_load).all())

    def test_empty_tensor(self):
        empty_tensor = torch.Tensor()
        after_save_and_load = float32_bytes_to_flat_tensor(flat_tensor_to_float32_bytes(empty_tensor))
        self.assertTrue((empty_tensor == after_save_and_load).all())

    def test_raises_on_not_flat_tensor(self):
        self.assertRaises(ValueError, lambda: flat_tensor_to_float32_bytes(torch.rand([2, 2])))


class TestIsUtc(unittest.TestCase):
    def test_random_pandas_utc(self):
        self.assertTrue(is_utc(Timestamp.utcnow()))

    def test_random_pandas_not_utc(self):
        self.assertFalse(is_utc(Timestamp.now(tz="cet")))

    def test_naive_pandas_datetime(self):
        self.assertFalse(is_utc(Timestamp.now()))

    def test_naive_datetime(self):
        self.assertFalse(is_utc(datetime.now()))

    def test_random_utc_datetime(self):
        self.assertTrue(is_utc(pytz.utc.localize(datetime.now())))

    def test_random_not_utc_datetime(self):
        self.assertFalse(is_utc(pytz.timezone("Europe/Amsterdam").localize(datetime.now())))

    def test_random_utc_datetime_2(self):
        self.assertTrue(is_utc(datetime.now(tz=pytz.timezone("UTC"))))

    def test_random_not_utc_datetime_2(self):
        self.assertFalse(is_utc(datetime.now(tz=pytz.timezone("CET"))))

    def test_random_utc_datetime_3(self):
        self.assertTrue(is_utc(datetime(2018, 1, 1, 0, 0, tzinfo=pytz.timezone("UTC"))))

    def test_random_not_utc_datetime_3(self):
        self.assertFalse(is_utc(datetime(2018, 1, 1, 0, 0, tzinfo=pytz.timezone("CET"))))

    def test_random_utc_datetime_4(self):
        self.assertTrue(is_utc(datetime.now(tz=timezone(timedelta(0)))))

    def test_random_not_utc_datetime_4(self):
        self.assertFalse(is_utc(datetime.now(tz=timezone(timedelta(seconds=-100)))))

    def test_random_utc_datetime_5(self):
        self.assertTrue(is_utc(datetime.now(tz=timezone.utc)))
