import unittest

import torch

from dbfcore.model.signalvaesimple2 import SignalVAESimple2


def setup_autoencoder(signal_normalizer_params):
    window_size = "1h"
    input_features = 2
    track_size = 10
    latent_dim = 10
    decoder_hidden_sizes = (100, 100)
    output_rep_size = 100
    max_seq_len = 3
    kldiv_loss_weight = 0.0
    log_images_every_n_train_steps = 1000
    log_images_every_n_val_steps = 1000

    return SignalVAESimple2(
        window_size,
        input_features,
        track_size,
        latent_dim,
        decoder_hidden_sizes,
        output_rep_size,
        max_seq_len,
        signal_normalizer_params,
        kldiv_loss_weight,
        log_images_every_n_train_steps,
        log_images_every_n_val_steps,
    )


class TestNormalizer(unittest.TestCase):
    def setUp(self):
        signal_names = ["topgasco_chem_pct", "vp2_topgasco_chem_pct", "vp3_topgasco_chem_pct"]
        means = [1, 10, 100]
        stds = [0.1, 1, 10]
        signal_normalizers_params = tuple(
            {"signal_name": signal_name, "mean": mean, "std": std}
            for signal_name, mean, std in zip(signal_names, means, stds)
        )

        self.autoencoder = setup_autoencoder(signal_normalizers_params)
        self.inputs = torch.tensor(
            [
                [[0, 1800, 3600], [2, 3, 4]],
                [[0, 1800, 3600], [11, 12, 13]],
                [[0, 1800, 3600], [101, 102, 103]],
                [[0, 1800, 3600], [2, 3, 4]],
            ]
        ).transpose(1, 2)
        self.indices = [0, 1, 2, 0]

    def test_normalized_denormalized_cycle(self):
        normalizer = self.autoencoder.input_normalizer
        self.assertTrue(
            normalizer.denormalize(normalizer(self.inputs, self.indices), self.indices).equal(self.inputs)
        )

    def test_correct_params_used_for_normalize(self):
        normalized = self.autoencoder.input_normalizer(self.inputs, self.indices)
        expected = torch.tensor(
            [
                [[-1, 0, 1], [10, 20, 30]],
                [[-1, 0, 1], [1, 2, 3]],
                [[-1, 0, 1], [0.1, 0.2, 0.3]],
                [[-1, 0, 1], [10, 20, 30]],
            ]
        ).transpose(1, 2)
        self.assertTrue(normalized.equal(expected))


class TestAutoencoderOutputShapes(unittest.TestCase):
    def setUp(self):
        signal_names = ["topgasco_chem_pct", "vp2_topgasco_chem_pct", "vp3_topgasco_chem_pct"]
        means = [1, 10, 100]
        stds = [0.1, 1, 10]
        signal_normalizers_params = tuple(
            {"signal_name": signal_name, "mean": mean, "std": std}
            for signal_name, mean, std in zip(signal_names, means, stds)
        )
        self.autoencoder = setup_autoencoder(signal_normalizers_params)
        self.inputs = torch.tensor(
            [
                [[0, 1800, 3600], [2, 3, 4]],
                [[0, 1800, 3600], [11, 12, 13]],
                [[0, 1800, 3600], [101, 102, 103]],
                [[0, 1800, 3600], [2, 3, 4]],
            ]
        ).transpose(1, 2)
        self.indices = [0, 1, 2, 0]
        self.batch = (self.inputs, self.indices)
        self.test_values = torch.tensor([0, 1000, 2000]).unsqueeze(0)
        self.latent_dim = self.autoencoder.latent_dim

    def test_encode_output_shape(self):
        encoded = self.autoencoder.encode(self.batch)
        self.assertEqual(encoded.size(), torch.Size([self.inputs.size(0), self.latent_dim]))

    def test_encode_one_output_shape(self):
        encoded = self.autoencoder.encode_one(self.inputs[0], torch.tensor(self.indices[0]))
        self.assertEqual(encoded.size(), torch.Size([self.latent_dim]))

    def test_decode_output_shape(self):
        embeddings = torch.tensor(
            [0.2521, -0.5049, -0.4534, -1.0300, -0.9845, 0.3715, 0.7495, -1.6775, -0.2336, 1.4075]
        ).unsqueeze(0)
        decoded = self.autoencoder.decode(embeddings, self.test_values, torch.tensor(self.indices[0]))
        self.assertEqual(decoded.size(), torch.Size([1, 3]))

    def test_forward_output_shape(self):
        decoded = self.autoencoder.forward(self.batch, self.test_values.repeat(self.inputs.size(0), 1))
        self.assertEqual(decoded.size(), torch.Size([self.inputs.size(0), 3]))


if __name__ == "__main__":
    unittest.main()
