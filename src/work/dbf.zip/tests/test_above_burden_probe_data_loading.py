import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.above_burden_probe import get_only_positive_values, load_above_burden_probe_phase


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if any(
            substr in url
            for substr in [
                "SK1.AboveBurdenProbe.1-1.Temp.C",
                "SK1.AboveBurdenProbe.1-2.Temp.C",
                "SK1.AboveBurdenProbe.1-3.Temp.C" "SK1.AboveBurdenProbe.1-4.Temp.C",
                "SK1.AboveBurdenProbe.1-5.Temp.C",
                "SK1.AboveBurdenProbe.1-6.Temp.C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 93.747450, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:06.702011100+00:00", "Value": 94.094666, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:07.671005200+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:12.702011100+00:00", "Value": 92.705820, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK1.AboveBurdenProbe.2-1.Temp.C",
                "SK1.AboveBurdenProbe.2-2.Temp.C",
                "SK1.AboveBurdenProbe.2-3.Temp.C",
                "SK1.AboveBurdenProbe.2-4.Temp.C",
                "SK1.AboveBurdenProbe.2-5.Temp.C",
                "SK1.AboveBurdenProbe.2-6.Temp.C",
                "SK1.AboveBurdenProbe.2-7.Temp.C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 111.108093, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:02.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:03.670013400+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 107.635963, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK2.AboveBurdenProbe.TNS11.Temp.C",
                "SK2.AboveBurdenProbe.TNS12.Temp.C",
                "SK2.AboveBurdenProbe.TNS13.Temp.C",
                "SK2.AboveBurdenProbe.TNS14.Temp.C",
                "SK2.AboveBurdenProbe.TNS15.Temp.C",
                "SK2.AboveBurdenProbe.TNS16.Temp.C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 123.607758, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 122.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 122.218900, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK2.AboveBurdenProbe.TNS21.Temp.C",
                "SK2.AboveBurdenProbe.TNS22.Temp.C",
                "SK2.AboveBurdenProbe.TNS23.Temp.C",
                "SK2.AboveBurdenProbe.TNS24.Temp.C",
                "SK2.AboveBurdenProbe.TNS25.Temp.C",
                "SK2.AboveBurdenProbe.TNS26.Temp.C",
                "SK2.AboveBurdenProbe.TNS27.Temp.C",
                "SK2.AboveBurdenProbe.TNS28.Temp.C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 107.983177, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 107.635963, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:11.671005200+00:00", "Value": 106.247116, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:16.702011100+00:00", "Value": 105.552689, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK3.AboveBurdenProbe11.Temp.°C",
                "SK3.AboveBurdenProbe12.Temp.°C",
                "SK3.AboveBurdenProbe13.Temp.°C",
                "SK3.AboveBurdenProbe14.Temp.°C",
                "SK3.AboveBurdenProbe15.Temp.°C",
                "SK3.AboveBurdenProbe16.Temp.°C",
                "SK3.AboveBurdenProbe17.Temp.°C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 111.108093, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:02.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:03.670013400+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 107.635963, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK3.AboveBurdenProbe21.Temp.°C",
                "SK3.AboveBurdenProbe22.Temp.°C",
                "SK3.AboveBurdenProbe23.Temp.°C",
                "SK3.AboveBurdenProbe24.Temp.°C",
                "SK3.AboveBurdenProbe25.Temp.°C",
                "SK3.AboveBurdenProbe26.Temp.°C",
                "SK3.AboveBurdenProbe27.Temp.°C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 111.108093, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:02.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:03.670013400+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 107.635963, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK3.AboveBurdenProbe31.Temp.°C",
                "SK3.AboveBurdenProbe32.Temp.°C",
                "SK3.AboveBurdenProbe33.Temp.°C",
                "SK3.AboveBurdenProbe34.Temp.°C",
                "SK3.AboveBurdenProbe35.Temp.°C",
                "SK3.AboveBurdenProbe36.Temp.°C",
                "SK3.AboveBurdenProbe37.Temp.°C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 123.607758, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 122.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 122.218900, "Good": True},
                ]
            }
        elif any(
            substr in url
            for substr in [
                "SK3.AboveBurdenProbe41.Temp.°C",
                "SK3.AboveBurdenProbe42.Temp.°C",
                "SK3.AboveBurdenProbe43.Temp.°C",
                "SK3.AboveBurdenProbe44.Temp.°C",
                "SK3.AboveBurdenProbe45.Temp.°C",
                "SK3.AboveBurdenProbe46.Temp.°C",
                "SK3.AboveBurdenProbe47.Temp.°C",
            ]
        ):
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 107.983177, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 107.635963, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:11.671005200+00:00", "Value": 106.247116, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:16.702011100+00:00", "Value": 105.552689, "Good": True},
                ]
            }

        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestAboveBurdenProbeDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df_bf1 = load_above_burden_probe_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        actual_df_bf2 = load_above_burden_probe_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=2,
            pi_client=fake_pi_client,  # type: ignore
        )

        actual_df_bf3 = load_above_burden_probe_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=3,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df_bf1.columns.tolist(),
            [
                "bf1_aboveburdenprobe_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf1.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf1.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf1.index, actual_df_bf1.index.sort_values())

        self.assertListEqual(
            actual_df_bf2.columns.tolist(),
            [
                "bf2_aboveburdenprobe_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf2.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf2.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf2.index, actual_df_bf3.index.sort_values())

        self.assertListEqual(
            actual_df_bf3.columns.tolist(),
            [
                "bf3_aboveburdenprobe_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf3.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf3.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf3.index, actual_df_bf3.index.sort_values())


class TestGetOnlyPositiveValues(unittest.TestCase):
    def setUp(self):
        self.df = pd.DataFrame(
            {"bf3_aboveburdenprobe44_temp_C": [95.160, 0, 95.459, -235]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 00:55:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                ],
                format="mixed",
            ),
        )

    def test_get_only_positive_values(self):
        expected = pd.DataFrame(
            {"bf3_aboveburdenprobe44_temp_C": [95.160, 95.459]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_only_positive_values(self.df)
        pd.testing.assert_frame_equal(result, expected)
