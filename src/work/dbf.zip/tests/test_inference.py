import unittest

import pandas as pd
from pandas.testing import assert_frame_equal

from dbfcore.predictionmodel.inference import generate_synthetic_future_data


class TestGenerateSyntheticFutureData(unittest.TestCase):
    def setUp(self):
        self.data = pd.DataFrame(
            index=pd.date_range("2023-01-01", periods=5, freq="30s", name="Timestamp"),
            data=[1, 2, 3, 4, 5],
            columns=["synthetic_signal"],
        )
        self.signal_name = "synthetic_signal"
        self.start = pd.Timestamp("2024-01-01 00:03:00")
        self.end = pd.Timestamp("2024-01-01 00:05:00")

    def test_smoke_test(self):
        expected_data = pd.DataFrame(
            index=pd.date_range(self.start, self.end, freq="30s", name="Timestamp", inclusive="right"),
            data=3.0,
            columns=[self.signal_name],
        )
        result = generate_synthetic_future_data(self.data, self.start, self.end)

        assert_frame_equal(result, expected_data)

    def test_dataset_with_two_occurencies(self):
        test_data = self.data.iloc[-2:]
        expected_data = pd.DataFrame(
            index=pd.date_range(self.start, self.end, freq="30s", name="Timestamp", inclusive="right"),
            data=4.5,
            columns=[self.signal_name],
        )
        result = generate_synthetic_future_data(test_data, self.start, self.end)

        assert_frame_equal(result, expected_data)

    def test_short_dataset(self):
        test_data = self.data.iloc[-1:]
        self.assertTrue(generate_synthetic_future_data(test_data, self.start, self.end).empty)


if __name__ == "__main__":
    unittest.main()
