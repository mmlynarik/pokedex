import unittest
from datetime import datetime

import pandas as pd

from dbfcore.dataset.preprocessed_dataset.transformations.charge_flows import (
    get_charge_flows_time_series_for_multiple_columns,
)
from dbfcore.settings import TZ_UTC


class TestChargeFlowsDataset(unittest.TestCase):
    def test_charge_flow_15_secs(self):
        input, output = "raw_material_weight_1", "chargeraw_material_1_flow_kgh"
        data = [
            {"charge_date": pd.Timestamp("2018-01-01 00:02:02"), "raw_material_weight_1": 6988.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:10:14"), "raw_material_weight_1": 6991.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:20:20"), "raw_material_weight_1": 6985.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:24:34"), "raw_material_weight_1": 6931.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:40:44"), "raw_material_weight_1": 6906.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:52:02"), "raw_material_weight_1": 6930.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:02:26"), "raw_material_weight_1": 6839.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:09:16"), "raw_material_weight_1": 6882.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:13:41"), "raw_material_weight_1": 6894.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:20:01"), "raw_material_weight_1": 6193.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:28:07"), "raw_material_weight_1": 6540.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:34:26"), "raw_material_weight_1": 6561.0},
        ]
        df = pd.DataFrame(data)
        sampling_freq = pd.Timedelta("15s")
        df = pd.read_csv("./tests/test_data/test_charge_flow_15_dataframe.csv", parse_dates=["charge_date"])
        df["charge_date"] = df["charge_date"].dt.tz_localize("UTC")
        test_flows = get_charge_flows_time_series_for_multiple_columns(
            df,
            [input],
            "charge_date",
            sampling_freq,
        )

        expected_first_flow_start = pd.Timestamp("2018-01-01 00:02:15", tz="UTC")
        expected_last_flow_end = pd.Timestamp("2018-01-01 01:34:00", tz="UTC")
        # Boundary weights are fractions of boundary charge weights calculated from charge duration in seconds
        # and charge weight of given charge. Interior weights are charge weights taken in full.
        interior_flown_weight = 6985 + 6931 + 6906 + 6930 + 6839 + 6882 + 6894 + 6193 + 6540
        boundary_flown_weight = (492 - 13) / 492 * 6991 + (379 - 26) / 379 * 6561
        expected_flown_weight_kg = interior_flown_weight + boundary_flown_weight
        calculated_flown_weight_kg = pd.Series(
            test_flows[output] * sampling_freq.total_seconds() / 3600
        ).sum()
        self.assertAlmostEqual(expected_flown_weight_kg, calculated_flown_weight_kg, places=2)
        self.assertEqual(test_flows["flow_start_time"][0], expected_first_flow_start)
        self.assertEqual(test_flows["flow_end_time"].iloc[-1], expected_last_flow_end)

    def test_charge_flow_600_secs(self):
        input, output = "raw_material_weight_1", "chargeraw_material_1_flow_kgh"
        data = [
            {"charge_date": pd.Timestamp("2018-01-01 00:02:02"), "raw_material_weight_1": 6988.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:10:14"), "raw_material_weight_1": 6991.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:20:20"), "raw_material_weight_1": 6985.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:24:34"), "raw_material_weight_1": 6931.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:40:44"), "raw_material_weight_1": 6906.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:52:02"), "raw_material_weight_1": 6930.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:02:26"), "raw_material_weight_1": 6839.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:09:16"), "raw_material_weight_1": 6882.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:13:41"), "raw_material_weight_1": 6894.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:20:01"), "raw_material_weight_1": 6193.0},
        ]
        df = pd.DataFrame(data)
        sampling_freq = pd.Timedelta("10min")
        df = pd.read_csv("./tests/test_data/test_charge_flow_600_dataframe.csv", parse_dates=["charge_date"])
        df["charge_date"] = df["charge_date"].dt.tz_localize("UTC")
        test_flows = get_charge_flows_time_series_for_multiple_columns(
            df,
            [input],
            "charge_date",
            sampling_freq,
        )

        expected_first_flow_start = pd.Timestamp("2018-01-01 00:12:00", tz="UTC")
        expected_last_flow_end = pd.Timestamp("2018-01-01 01:12:00", tz="UTC")
        # Boundary weights are fractions of boundary charge weights calculated from charge duration in seconds
        # and charge weight of given charge. Interior weights are charge weights taken in full.
        interior_flown_weight = 6931 + 6906 + 6930 + 6839 + 6882
        boundary_flown_weight = (606 - 106) / 606 * 6985 + (265 - 101) / 265 * 6894
        expected_flown_weight_kg = interior_flown_weight + boundary_flown_weight
        calculated_flown_weight_kg = pd.Series(
            test_flows[output] * sampling_freq.total_seconds() / 3600
        ).sum()
        self.assertAlmostEqual(expected_flown_weight_kg, calculated_flown_weight_kg, places=2)
        self.assertEqual(test_flows["flow_start_time"][0], expected_first_flow_start)
        self.assertEqual(test_flows["flow_end_time"].iloc[-1], expected_last_flow_end)

    def test_charge_flow_600_secs_live_pred(self):
        input, output = "raw_material_weight_1", "chargeraw_material_1_flow_kgh"
        sampling_freq = pd.Timedelta("10min")
        start = datetime(2018, 1, 1, 0, 10, tzinfo=TZ_UTC)
        end = datetime(2018, 1, 1, 1, 20, tzinfo=TZ_UTC)
        data = [
            {"charge_date": pd.Timestamp("2018-01-01 00:02:02"), "raw_material_weight_1": 6988.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:10:14"), "raw_material_weight_1": 6991.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:20:20"), "raw_material_weight_1": 6985.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:24:34"), "raw_material_weight_1": 6931.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:40:44"), "raw_material_weight_1": 6906.0},
            {"charge_date": pd.Timestamp("2018-01-01 00:52:02"), "raw_material_weight_1": 6930.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:02:26"), "raw_material_weight_1": 6839.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:09:16"), "raw_material_weight_1": 6882.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:13:41"), "raw_material_weight_1": 6894.0},
            {"charge_date": pd.Timestamp("2018-01-01 01:20:01"), "raw_material_weight_1": 6193.0},
        ]
        df = pd.DataFrame(data)
        df["charge_date"] = df["charge_date"].dt.tz_localize("UTC")
        test_flows = get_charge_flows_time_series_for_multiple_columns(
            df,
            [input],
            "charge_date",
            sampling_freq,
            start,
            end,
        )
        expected_first_flow_start = pd.Timestamp(start)
        expected_last_flow_end = pd.Timestamp(end)
        # Boundary weights are fractions of boundary charge weights calculated from charge duration in seconds
        # and charge weight of given charge. Interior weights are charge weights taken in full.
        interior_flown_weight = 6985 + 6931 + 6906 + 6930 + 6839 + 6882 + 6894
        boundary_flown_weight = 14 / 492 * 6991 + (380 - 1) / 380 * 6193
        expected_flown_weight_kg = interior_flown_weight + boundary_flown_weight
        calculated_flown_weight_kg = pd.Series(
            test_flows[output] * sampling_freq.total_seconds() / 3600
        ).sum()
        self.assertAlmostEqual(expected_flown_weight_kg, calculated_flown_weight_kg, places=2)
        self.assertEqual(test_flows["flow_start_time"][0], expected_first_flow_start)
        self.assertEqual(test_flows["flow_end_time"].iloc[-1], expected_last_flow_end)


if __name__ == "__main__":
    unittest.main()
