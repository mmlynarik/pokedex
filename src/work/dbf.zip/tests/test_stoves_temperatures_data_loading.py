import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.stoves_temperatures import load_stoves_temperatures


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Stove.11N.Dome.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:00.359008Z", "Value": 1299.90686, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:19.390014Z", "Value": 1300.31189, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:24.359008Z", "Value": 1300.31189, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:25.390014Z", "Value": 1299.09668, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:26.390014Z", "Value": 1300.31189, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:30.359008Z", "Value": 1300.717, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:31.359008Z", "Value": 1299.90686, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:37.390014Z", "Value": 1300.31189, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:42.359008Z", "Value": 1299.90686, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:43.375000Z", "Value": 1300.717, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:38.328002Z", "Value": 1311.24915, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:39.343002Z", "Value": 1311.24915, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:40.343002Z", "Value": 1312.86951, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:44.375000Z", "Value": 1312.46436, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:45.375000Z", "Value": 1313.27454, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:49.343002Z", "Value": 1312.46436, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:53.375000Z", "Value": 1312.46436, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:55.375000Z", "Value": 1313.27454, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:56.375000Z", "Value": 1311.24915, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:58.343002Z", "Value": 1312.46436, "Good": True},
                ]
            }
        elif "SK1.Stove11.Stack.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:11:18.375000Z", "Value": 842.825656, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:43.406005Z", "Value": 845.810364, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:31.359008Z", "Value": 846.155666, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:51.359008Z", "Value": 844.156565, "Good": True},
                ]
            }
        elif "SK1.Stove11.WasteGas.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:34.375000Z", "Value": 299.065979, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:25.390014Z", "Value": 299.1817, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:01.375000Z", "Value": 299.413177, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:31.390014Z", "Value": 301.0335, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:32.375000Z", "Value": 301.49646, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:59.359008Z", "Value": 303.1168, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:23.359008Z", "Value": 304.852844, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:19.406005Z", "Value": 306.820374, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:16.406005Z", "Value": 309.482361, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:10.375000Z", "Value": 310.986938, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:37.375000Z", "Value": 312.028564, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:02.375000Z", "Value": 312.723, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:33.375000Z", "Value": 313.764648, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:21.343002Z", "Value": 314.2276, "Good": True},
                ]
            }
        elif "SK1.Stove.12.Dome.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:17.390014Z", "Value": 1210.40015, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:26.390014Z", "Value": 1209.24268, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:49.359008Z", "Value": 1210.40015, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:16.390014Z", "Value": 1222.89978, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:45.375000Z", "Value": 1235.168, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:17.375000Z", "Value": 1241.64929, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:01.359008Z", "Value": 1265.72266, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:55.359008Z", "Value": 1274.98169, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:58.375000Z", "Value": 1283.08325, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:33.375000Z", "Value": 1286.55542, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:37.328002Z", "Value": 1290.02759, "Good": True},
                ]
            }
        elif "SK1.Stove12.Stack.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:03.359008Z", "Value": 1132.62451, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:19.390014Z", "Value": 1128.22644, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:29.359008Z", "Value": 1126.60608, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:47.359008Z", "Value": 1127.06909, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:19.375000Z", "Value": 1132.856, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:02.375000Z", "Value": 1141.42053, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:21.375000Z", "Value": 1144.19824, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:26.375000Z", "Value": 1145.35559, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:30.359008Z", "Value": 1152.2998, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:11.406005Z", "Value": 1157.16089, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:13.390014Z", "Value": 1166.4198, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:50.359008Z", "Value": 1173.13257, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:34.375000Z", "Value": 1178.91943, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:10.375000Z", "Value": 1182.3916, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:06.389999Z", "Value": 1185.86377, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:24.406005Z", "Value": 1186.55811, "Good": True},
                ]
            }
        elif "SK1.Stove12.WasteGas.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:16.359008Z", "Value": 196.030548, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:59.375000Z", "Value": 194.149811, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:06.375000Z", "Value": 192.7031, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:23.359008Z", "Value": 193.426453, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:36.375000Z", "Value": 195.596527, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:47.359008Z", "Value": 197.477264, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:00.343002Z", "Value": 200.9494, "Good": True},
                ]
            }
        elif "SK1.Stove.13.Dome.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:11:19.375000Z", "Value": 1279.14819, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:43.390014Z", "Value": 1277.065, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:45.390014Z", "Value": 1276.37061, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:06.375000Z", "Value": 1276.13916, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:55.375000Z", "Value": 1275.21313, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:56.389999Z", "Value": 1275.90759, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:06.389999Z", "Value": 1275.21313, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:47.343002Z", "Value": 1274.05579, "Good": True},
                ]
            }
        elif "SK1.Stove13.Stack.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:12.359008Z", "Value": 1179.59766, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:13.359008Z", "Value": 1180.40784, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:15.375000Z", "Value": 1180.40784, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:17.390014Z", "Value": 1179.59766, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:18.390014Z", "Value": 1180.40784, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:53.375000Z", "Value": 1181.2179, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:05.375000Z", "Value": 1181.623, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:06.375000Z", "Value": 1182.43323, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:07.390014Z", "Value": 1181.623, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:08.375000Z", "Value": 1182.43323, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:16.390014Z", "Value": 1231.23291, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:17.390014Z", "Value": 1229.844, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:38.375000Z", "Value": 1230.07544, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:37.359008Z", "Value": 1228.91821, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:15.359008Z", "Value": 1227.76074, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:39.359008Z", "Value": 1227.5293, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:58.375000Z", "Value": 1226.60339, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:29.389999Z", "Value": 1226.37183, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:59.343002Z", "Value": 1225.446, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:07.359008Z", "Value": 1225.446, "Good": True},
                ]
            }
        elif "SK1.Stove13.WasteGas.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:20.390014Z", "Value": 232.487885, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:22.390014Z", "Value": 232.487885, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:29.375000Z", "Value": 230.751831, "Good": True},
                    {"Timestamp": "2024-01-05T09:11:46.375000Z", "Value": 230.607147, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:26.375000Z", "Value": 229.3051, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:55.390014Z", "Value": 228.726425, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:12.406005Z", "Value": 228.147736, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:16.390014Z", "Value": 228.437073, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:17.390014Z", "Value": 228.003052, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:48.406005Z", "Value": 227.424377, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:11.359008Z", "Value": 222.650192, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:12.359008Z", "Value": 222.216187, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:40.359008Z", "Value": 221.926834, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:27.389999Z", "Value": 220.624786, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:39.375000Z", "Value": 220.624786, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:42.375000Z", "Value": 220.190765, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:57.375000Z", "Value": 220.0461, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:11.328002Z", "Value": 219.4674, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:19.328002Z", "Value": 219.4674, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:47.343002Z", "Value": 218.744049, "Good": True},
                ]
            }
        elif "SK1.Stove.14.Dome.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:02.359008Z", "Value": 1309.87793, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:03.359008Z", "Value": 1310.4856, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:04.375000Z", "Value": 1309.5741, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:06.359008Z", "Value": 1311.397, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:12.359008Z", "Value": 1310.78931, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:13.359008Z", "Value": 1309.87793, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:15.375000Z", "Value": 1311.397, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:19.390014Z", "Value": 1310.78931, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:28.390014Z", "Value": 1308.35889, "Good": True},
                    {"Timestamp": "2024-01-05T09:10:30.359008Z", "Value": 1309.27026, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:41.406005Z", "Value": 1292.56067, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:43.406005Z", "Value": 1292.8645, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:45.375000Z", "Value": 1295.59875, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:47.375000Z", "Value": 1295.29492, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:50.390014Z", "Value": 1294.68738, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:54.390014Z", "Value": 1295.59875, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:55.390014Z", "Value": 1294.68738, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:14.375000Z", "Value": 1293.16821, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:43.375000Z", "Value": 1288.63867, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:28.390014Z", "Value": 1290.02759, "Good": True},
                ]
            }
        elif "SK1.Stove14.Stack.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:13:00.359008Z", "Value": 1424.51465, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:01.359008Z", "Value": 1127.06909, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:10.390014Z", "Value": 1123.134, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:22.359008Z", "Value": 1119.66187, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:36.375000Z", "Value": 1117.81, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:55.390014Z", "Value": 1118.50439, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:06.406005Z", "Value": 1120.12476, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:07.375000Z", "Value": 1178.688, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:08.375000Z", "Value": 1269.19482, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:09.406005Z", "Value": 1418.26489, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:46.359008Z", "Value": 1133.55029, "Good": True},
                    {"Timestamp": "2024-01-05T09:15:47.359008Z", "Value": 0.0, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:03.390014Z", "Value": 0.0, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:04.359008Z", "Value": 1138.17993, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:11.359008Z", "Value": 1139.10571, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:00.359008Z", "Value": 1153.45728, "Good": True},
                    {"Timestamp": "2024-01-05T09:17:30.359008Z", "Value": 1160.40149, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:20.375000Z", "Value": 1168.50317, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:52.375000Z", "Value": 1171.97522, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:46.375000Z", "Value": 1176.60474, "Good": True},
                ]
            }
        elif "SK1.Stove14.WasteGas.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2024-01-05T09:10:14.359008Z", "Value": 293.105469, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:14.390014Z", "Value": 293.684143, "Good": True},
                    {"Timestamp": "2024-01-05T09:12:41.375000Z", "Value": 292.092743, "Good": True},
                    {"Timestamp": "2024-01-05T09:13:35.375000Z", "Value": 287.1739, "Good": True},
                    {"Timestamp": "2024-01-05T09:14:45.359008Z", "Value": 282.83374, "Good": True},
                    {"Timestamp": "2024-01-05T09:16:16.406005Z", "Value": 278.4936, "Good": True},
                    {"Timestamp": "2024-01-05T09:18:34.359008Z", "Value": 272.996033, "Good": True},
                    {"Timestamp": "2024-01-05T09:19:47.343002Z", "Value": 218.744049, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestStovesTemperaturestDataLoading(unittest.TestCase):
    def test_load_stoves_temperatures(self):
        expected = pd.DataFrame(
            {
                "bf1_stove11_dome_temp_C": [
                    1299.906860,
                    1300.375616,
                    1301.652097,
                    1302.833273,
                    1304.014449,
                    1305.195625,
                    1306.376800,
                    1307.557976,
                    1308.739152,
                    1309.920327,
                    1311.450535,
                ],
                "bf1_stove11_stack_temp_C": [
                    None,
                    None,
                    843.062180,
                    843.642227,
                    844.318010,
                    844.993793,
                    845.649008,
                    845.962233,
                    846.027363,
                    845.306048,
                    844.513547,
                ],
                "bf1_stove11_wastegas_temp_C": [
                    None,
                    299.095477,
                    299.237869,
                    301.244971,
                    304.959490,
                    307.046732,
                    308.447144,
                    309.896589,
                    311.736153,
                    313.529814,
                    314.131152,
                ],
                "bf1_stove12_dome_temp_C": [
                    None,
                    1210.194763,
                    1216.362617,
                    1224.886877,
                    1233.298635,
                    1244.839783,
                    1258.662681,
                    1270.770117,
                    1279.545385,
                    1286.024209,
                    1289.051042,
                ],
                "bf1_stove12_stack_temp_C": [
                    None,
                    1128.314625,
                    1135.198766,
                    1145.475364,
                    1152.432016,
                    1160.101176,
                    1169.590727,
                    1178.253950,
                    1183.636828,
                    1186.099861,
                    None,
                ],
                "bf1_stove12_wastegas_temp_C": [
                    None,
                    195.068803,
                    193.469641,
                    192.839177,
                    193.149256,
                    193.595362,
                    194.527806,
                    195.557652,
                    197.072154,
                    199.546277,
                    None,
                ],
                "bf1_stove13_dome_temp_C": [
                    None,
                    None,
                    1278.986427,
                    1278.583993,
                    1278.110540,
                    1277.637088,
                    1276.987086,
                    1276.240598,
                    1275.723157,
                    1274.946886,
                    1274.319343,
                ],
                "bf1_stove13_stack_temp_C": [
                    None,
                    1180.799091,
                    1191.102565,
                    1213.886149,
                    1229.551912,
                    1229.736029,
                    1229.348131,
                    1228.849856,
                    1227.499268,
                    1226.167772,
                    1225.446000,
                ],
                "bf1_stove13_wastegas_temp_C": [
                    None,
                    232.019586,
                    230.814737,
                    229.280017,
                    227.790513,
                    226.424856,
                    225.013766,
                    223.602677,
                    222.053974,
                    220.611520,
                    219.292610,
                ],
                "bf1_stove14_dome_temp_C": [
                    None,
                    1309.059667,
                    1303.977432,
                    1298.728346,
                    1294.424946,
                    1290.952428,
                    1289.610914,
                    None,
                    None,
                    None,
                    None,
                ],
                "bf1_stove14_stack_temp_C": [
                    None,
                    None,
                    None,
                    None,
                    1119.262950,
                    1124.408814,
                    1131.911778,
                    1144.951803,
                    1159.979066,
                    1169.459256,
                    1174.675773,
                ],
                "bf1_stove14_wastegas_temp_C": [
                    None,
                    293.216382,
                    293.474374,
                    292.513109,
                    287.741360,
                    283.761390,
                    280.663670,
                    277.931670,
                    275.525711,
                    269.020923,
                    235.837140,
                ],
            },
            index=pd.to_datetime(
                [
                    "2024-01-05 09:10:00+00:00",
                    "2024-01-05 09:11:00+00:00",
                    "2024-01-05 09:12:00+00:00",
                    "2024-01-05 09:13:00+00:00",
                    "2024-01-05 09:14:00+00:00",
                    "2024-01-05 09:15:00+00:00",
                    "2024-01-05 09:16:00+00:00",
                    "2024-01-05 09:17:00+00:00",
                    "2024-01-05 09:18:00+00:00",
                    "2024-01-05 09:19:00+00:00",
                    "2024-01-05 09:20:00+00:00",
                ],
                format="mixed",
            ),
        ).asfreq("1min")
        expected.index.name = "Timestamp"

        fake_pi_client = FakePiClient()

        result = load_stoves_temperatures(
            start=pd.Timestamp(2024, 1, 5, 9, 10, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2024, 1, 5, 9, 20, 5, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        pd.testing.assert_frame_equal(result, expected)
