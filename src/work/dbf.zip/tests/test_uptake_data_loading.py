import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.uptake import load_uptake_phase


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Top.Uptake1.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 93.747450, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:06.702011100+00:00", "Value": 94.094666, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:07.671005200+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 93.400240, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:12.702011100+00:00", "Value": 92.705820, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake2.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 111.108093, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:02.702011100+00:00", "Value": 110.066452, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:03.670013400+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 107.635963, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake3.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00.702011100+00:00", "Value": 123.607758, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:01.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 122.913330, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 122.218900, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:08.702011100+00:00", "Value": 122.218900, "Good": True},
                ]
            }
        elif "SK1.Top.Uptake4.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:04.702011100+00:00", "Value": 109.024818, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:05.670013400+00:00", "Value": 107.983177, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:10.718002300+00:00", "Value": 107.635963, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:11.671005200+00:00", "Value": 106.247116, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:16.702011100+00:00", "Value": 105.552689, "Good": True},
                ]
            }
        elif "SK2.Top.Uptake1.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 228.506, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 231.111, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 233.680, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 236.284, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 238.940, "Good": True},
                ]
            }
        elif "SK2.Top.Uptake2.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 242.638, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 246.579, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 250.138, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 253.628, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 257.135, "Good": True},
                ]
            }
        elif "SK2.Top.Uptake3.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 211.840, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 214.201, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 216.319, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 218.315, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 219.913, "Good": True},
                ]
            }
        elif "SK2.Top.Uptake4.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 231.249, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 234.131, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 238.125, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 242.604, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 247.083, "Good": True},
                ]
            }
        elif "SK3.Top.Uptake1.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 92.791, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 92.908, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 92.717, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 92.952, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 92.937, "Good": True},
                ]
            }
        elif "SK3.Top.Uptake2.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 92.586, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 92.630, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 92.468, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 92.805, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 92.688, "Good": True},
                ]
            }
        elif "SK3.Top.Uptake3.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 73.494, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 73.553, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 73.509, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 73.465, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 73.479, "Good": True},
                ]
            }
        elif "SK3.Top.Uptake4.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2025-01-01 00:00:00+00:00", "Value": 73.611, "Good": True},
                    {"Timestamp": "2025-01-01 00:00:30+00:00", "Value": 73.523, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:00+00:00", "Value": 73.567, "Good": True},
                    {"Timestamp": "2025-01-01 00:01:30+00:00", "Value": 73.597, "Good": True},
                    {"Timestamp": "2025-01-01 00:02:00+00:00", "Value": 73.465, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestUptakeDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df_bf1 = load_uptake_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        actual_df_bf2 = load_uptake_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=2,
            pi_client=fake_pi_client,  # type: ignore
        )

        actual_df_bf3 = load_uptake_phase(
            start=pd.Timestamp(2025, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2025, 1, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=3,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df_bf1.columns.tolist(),
            [
                "bf1_uptake_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf1.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf1.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf1.index, actual_df_bf1.index.sort_values())

        self.assertListEqual(
            actual_df_bf2.columns.tolist(),
            [
                "bf2_uptake_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf2.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf2.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf2.index, actual_df_bf3.index.sort_values())

        self.assertListEqual(
            actual_df_bf3.columns.tolist(),
            [
                "bf3_uptake_temp_C",
            ],
        )
        self.assertIsInstance(actual_df_bf3.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf3.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf3.index, actual_df_bf3.index.sort_values())
