import tempfile
import unittest
from pathlib import Path

import pandas as pd

from dbfcore.scripts.merge_signal_dataframe import merge_dataframes_in_memory, merge_files_on_disk


class TestMergeDataframesInMemory(unittest.TestCase):
    def setUp(self):
        self.df1 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [95.160, 88.525, 95.459, 93.934]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                ],
                format="mixed",
            ),
        )
        self.df2 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [13.349, 55.416]},
            index=pd.to_datetime(
                [
                    "2025-01-04 05:12:34+00:00",
                    "2025-01-04 06:54:39.500000+00:00",
                ],
                format="mixed",
            ),
        )
        self.df3 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [95.459, 93.934, 81.834, 81.834]},
            index=pd.to_datetime(
                [
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                    "2025-01-03 01:01:01+00:00",
                    "2025-01-03 02:02:02+00:00",
                ],
                format="mixed",
            ),
        )

    def test_merge(self):
        expected = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [95.160, 95.459, 93.934, 81.834, 81.834, 13.349, 55.416]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 21:21:46.250000+00:00",
                    "2025-01-02 22:09:34+00:00",
                    "2025-01-03 01:01:01+00:00",
                    "2025-01-03 02:02:02+00:00",
                    "2025-01-04 05:12:34+00:00",
                    "2025-01-04 06:54:39.500000+00:00",
                ],
                format="mixed",
            ),
        )
        dataframes = [self.df1, self.df2, self.df3]
        result = merge_dataframes_in_memory(dataframes)
        pd.testing.assert_frame_equal(result, expected)


class TestMergeFilesOnDisk(unittest.TestCase):
    def setUp(self):
        self.tempdict = tempfile.TemporaryDirectory()
        self.temp_path = Path(self.tempdict.name)

        self.input_files = []

        file1_name = "test_20250102_20250103.parquet"
        df1 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [95.160, 95.459, 93.934, 94.174]},
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 02:20:01+00:00",
                    "2025-01-02 22:09:34+00:00",
                    "2025-01-02 23:45:24+00:00",
                ],
                format="mixed",
            ),
        )
        file1_path = self.temp_path / file1_name
        df1.to_parquet(file1_path)
        self.input_files.append(file1_path)

        file2_name = "test_20250116.parquet"
        df2 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [93.781, 93.426, 94.333, 94.507]},
            index=pd.to_datetime(
                [
                    "2025-01-15 00:36:28+00:00",
                    "2025-01-15 01:48:29+00:00",
                    "2025-01-15 21:21:46.250000+00:00",
                    "2025-01-15 23:21:32+00:00",
                ],
                format="mixed",
            ),
        )
        file2_path = self.temp_path / file2_name
        df2.to_parquet(file2_path)
        self.input_files.append(file2_path)

        file3_name = "test_20250116_20250117.parquet"
        df3 = pd.DataFrame(
            {"bf2_hotmetalfe_chem_pct": [94.424, 94.554, 93.828, 94.119]},
            index=pd.to_datetime(
                [
                    "2025-01-16 00:45:39.500000+00:00",
                    "2025-01-16 02:23:56+00:00",
                    "2025-01-16 21:35:44+00:00",
                    "2025-01-16 22:42:41+00:00",
                ],
                format="mixed",
            ),
        )
        file3_path = self.temp_path / file3_name
        df3.to_parquet(file3_path)
        self.input_files.append(file3_path)

        self.output_file_parquet = self.temp_path / "test_output.parquet"

    def test_merge_files_on_disk(self):
        expected_parquet_df = pd.DataFrame(
            {
                "bf2_hotmetalfe_chem_pct": [
                    95.160,
                    95.459,
                    93.934,
                    94.174,
                    93.781,
                    93.426,
                    94.333,
                    94.507,
                    94.424,
                    94.554,
                    93.828,
                    94.119,
                ]
            },
            index=pd.to_datetime(
                [
                    "2025-01-02 00:54:59+00:00",
                    "2025-01-02 02:20:01+00:00",
                    "2025-01-02 22:09:34+00:00",
                    "2025-01-02 23:45:24+00:00",
                    "2025-01-15 00:36:28+00:00",
                    "2025-01-15 01:48:29+00:00",
                    "2025-01-15 21:21:46.250000+00:00",
                    "2025-01-15 23:21:32+00:00",
                    "2025-01-16 00:45:39.500000+00:00",
                    "2025-01-16 02:23:56+00:00",
                    "2025-01-16 21:35:44+00:00",
                    "2025-01-16 22:42:41+00:00",
                ],
                format="mixed",
            ),
        )
        expected_parquet_df.index.name = "Timestamp"

        merge_files_on_disk(self.input_files, self.output_file_parquet)

        result_df = pd.read_parquet(self.output_file_parquet)
        result_df.index.name = "Timestamp"

        pd.testing.assert_frame_equal(result_df, expected_parquet_df)

    def tearDown(self):
        self.tempdict.cleanup()


if __name__ == "__main__":
    unittest.main()
