import unittest
from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression  # type: ignore
from sklearn.preprocessing import PolynomialFeatures  # type: ignore

import dbfcore.stoves.stove_model as sm
from dbfcore.stoves.protocol import (
    Gas,
    GasComposition,
    StoveGasRegime,
    StoveInitialState,
    StoveTemperaturePrediction,
)
from dbfcore.stoves.stove_model import PolyStoveModel, prepare_stove_model_features


class TestPolyStoveModel(unittest.TestCase):
    def setUp(self):
        # Dome model parameters
        intercept_dome = 456.10079405402837
        coefs_dome = np.array(
            [
                0.00000000e00,
                -1.01700875e-01,
                -1.39968813e-01,
                1.76760512e02,
                3.07490226e-01,
                4.13350964e-07,
                1.25355871e-03,
                2.23526651e-02,
                5.57764559e-05,
                2.54946216e-06,
                -9.79536938e-01,
                -1.80516860e-04,
                -2.21665906e01,
                -1.12316922e-01,
                2.63134854e-04,
            ]
        )
        lr_dome = LinearRegression()
        lr_dome.intercept_ = intercept_dome
        lr_dome.coef_ = coefs_dome
        poly_dome = PolynomialFeatures(degree=2)

        # Wastegas model parameters
        intercept_wg = 363.3287390168739
        coefs_wg = np.array(
            [
                0.00000000e00,
                2.54878218e-01,
                -3.46728435e-02,
                -2.02289956e02,
                -2.37121317e-01,
                -9.74727031e-01,
                1.11658829e-05,
                4.27997873e-03,
                -7.43502180e-02,
                -1.24641137e-04,
                -1.13692388e-04,
                1.36647219e-06,
                -4.21438233e00,
                -6.42210227e-04,
                -1.00507756e-03,
                5.49416341e01,
                6.37798174e-02,
                3.48254090e-01,
                2.00507837e-05,
                1.07508494e-03,
                4.81957207e-04,
            ]
        )
        lr_wg = LinearRegression()
        lr_wg.intercept_ = intercept_wg
        lr_wg.coef_ = coefs_wg
        poly_wg = PolynomialFeatures(degree=2)

        self.model = PolyStoveModel(
            fitted_poly_dome=lr_dome,
            poly_features_dome=poly_dome,
            fitted_poly_wg=lr_wg,
            poly_features_wg=poly_wg,
        )

    def test_predict_dome_at_zero(self):
        # With all inputs zero, only intercept contributes
        result = self.model.predict_dome(0.0, 0.0, 0.0, 0.0)
        expected = self.model.fitted_poly_dome.intercept_
        self.assertAlmostEqual(result, expected, places=7)

    def test_predict_wg_at_zero(self):
        result = self.model.predict_wg(0.0, 0.0, 0.0, 0.0, 0.0)
        expected = self.model.fitted_poly_wg.intercept_
        self.assertAlmostEqual(result, expected, places=7)

    def test_predict_dome_arbitrary(self):
        x = [541.530314, 5.165003, 0.342464, 1320.088040]
        X_poly = self.model.poly_features_dome.fit_transform([x])[0]
        expected = self.model.fitted_poly_dome.intercept_ + np.dot(self.model.fitted_poly_dome.coef_, X_poly)
        result = self.model.predict_dome(*x)
        self.assertAlmostEqual(result, expected, places=7)

    def test_predict_wg_arbitrary(self):
        x = [541.530314, 5.165003, 0.342464, 1320.088040, 140.403305]
        X_poly = self.model.poly_features_wg.fit_transform([x])[0]
        expected = self.model.fitted_poly_wg.intercept_ + np.dot(self.model.fitted_poly_wg.coef_, X_poly)
        result = self.model.predict_wg(*x)
        self.assertAlmostEqual(result, expected, places=7)


class TestPrepareStoveModel(unittest.TestCase):
    def test_prepare_stove_model_features_structure(self):
        # Create a GasComposition with unit fractions for all molecules
        comp = GasComposition(
            ch4=9.121743,
            h2=3.020339,
            o2=0.664231,
            n2=8.375811,
            co2=2.379482,
            c2h4=1.252185,
            c2h6=0.374205,
            c2h2=0.056202,
            co=4.429888,
            h2o=4.25,
            c3h8=0.452,
        )
        gas = Gas(flow=10.0, temperature=720.0, composition=comp)
        regime = StoveGasRegime(duration=1, cog=gas, bfg=gas, ng=gas, air=gas)
        result = prepare_stove_model_features(200.0, regime)
        self.assertIsInstance(result, dict)
        expected_keys = {"adiabatic_flame_temperature_K", "cv_real_MJ_m3_fuel", "cv_real_MJ_m3_mixture"}
        self.assertTrue(expected_keys.issubset(result.keys()))

        for val in result.values():
            self.assertIsInstance(val, float)


class TestTemperaturePrediction(unittest.TestCase):
    def setUp(self):
        sm.prepare_stove_model_features = lambda waste_gas_temp, gas_regime: {
            "adiabatic_flame_temperature_K": 0.0,
            "cv_real_MJ_m3_fuel": 0.0,
            "cv_real_MJ_m3_mixture": 0.0,
        }
        intercept_dome = 456.10079405402837
        coefs_dome = np.array(
            [
                0.00000000e00,
                -1.01700875e-01,
                -1.39968813e-01,
                1.76760512e02,
                3.07490226e-01,
                4.13350964e-07,
                1.25355871e-03,
                2.23526651e-02,
                5.57764559e-05,
                2.54946216e-06,
                -9.79536938e-01,
                -1.80516860e-04,
                -2.21665906e01,
                -1.12316922e-01,
                2.63134854e-04,
            ]
        )
        lr_dome = LinearRegression()
        lr_dome.intercept_ = intercept_dome
        lr_dome.coef_ = coefs_dome
        poly_dome = PolynomialFeatures(degree=2)

        # Wastegas model parameters
        intercept_wg = 363.3287390168739
        coefs_wg = np.array(
            [
                0.00000000e00,
                2.54878218e-01,
                -3.46728435e-02,
                -2.02289956e02,
                -2.37121317e-01,
                -9.74727031e-01,
                1.11658829e-05,
                4.27997873e-03,
                -7.43502180e-02,
                -1.24641137e-04,
                -1.13692388e-04,
                1.36647219e-06,
                -4.21438233e00,
                -6.42210227e-04,
                -1.00507756e-03,
                5.49416341e01,
                6.37798174e-02,
                3.48254090e-01,
                2.00507837e-05,
                1.07508494e-03,
                4.81957207e-04,
            ]
        )
        lr_wg = LinearRegression()
        lr_wg.intercept_ = intercept_wg
        lr_wg.coef_ = coefs_wg
        poly_wg = PolynomialFeatures(degree=2)

        self.model = PolyStoveModel(
            fitted_poly_dome=lr_dome,
            poly_features_dome=poly_dome,
            fitted_poly_wg=lr_wg,
            poly_features_wg=poly_wg,
        )

    def test_temperature_prediction_steps(self):
        initial_state = StoveInitialState(
            dome_temperature=1311.762263, stack_temperature=1225.134330, wastegas_temperature=140.403305
        )
        comp1 = GasComposition(
            ch4=9.121743,
            h2=3.020339,
            o2=0.664231,
            n2=8.375811,
            co2=2.379482,
            c2h4=1.252185,
            c2h6=0.374205,
            c2h2=0.056202,
            co=4.429888,
            h2o=4.25,
            c3h8=0.452,
        )
        comp2 = GasComposition(
            ch4=9.056643,
            h2=3.520339,
            o2=0.564231,
            n2=8.275811,
            co2=2.179482,
            c2h4=1.352185,
            c2h6=0.274205,
            c2h2=0.066202,
            co=4.529888,
            h2o=4.15,
            c3h8=0.545,
        )
        gas1 = Gas(flow=10.0, temperature=720.0, composition=comp1)
        gas2 = Gas(flow=10.0, temperature=820.0, composition=comp2)
        reg1 = StoveGasRegime(duration=2, cog=gas1, bfg=gas1, ng=gas1, air=gas1)
        reg2 = StoveGasRegime(duration=3, cog=gas2, bfg=gas2, ng=gas2, air=gas2)

        regimes: Sequence[StoveGasRegime] = [reg1, reg2]

        results = self.model.temperature_prediction(initial_state, regimes)

        first = results[pd.Timedelta(0)]
        self.assertIsInstance(first, StoveTemperaturePrediction)
        self.assertEqual(first.dome_temperature, 1311.762263)
        self.assertEqual(first.wastegas_temperature, 140.403305)

        self.assertEqual(len(results), 6)

        prev = pd.Timedelta(-1)
        for dt, pred in list(results.items())[0:]:
            # ensure timestamps are strictly increasing
            self.assertTrue(dt > prev, f"Timestamp {dt} is not after previous timestamp {prev}")
            # ensure predicted temperatures are real numbers
            self.assertIsInstance(pred.dome_temperature, float)
            self.assertIsInstance(pred.wastegas_temperature, float)
            prev = dt


if __name__ == "__main__":
    unittest.main()
