import unittest

import numpy as np
import pandas as pd

from dbfcore.model.datamodule.pisignal import (
    CalculatedStartTimesDataset,
    InMemoryDatasource,
    InMemoryStartTimesDataset,
    SignalDataset,
    SignalDatasetWithoutEmptySeqences,
    SignalDatasetWithoutEmptySequencesWithReplacement,
    transform_timestamps,
)


def get_data_with_linear_times(timefrom: str, timeto: str, sample_count: int, name: str) -> pd.DataFrame:
    times = pd.date_range(timefrom, timeto, periods=sample_count)
    values = np.random.rand(sample_count)

    return pd.DataFrame(zip(times, values), columns=["Timestamp", name]).set_index("Timestamp").sort_index()


class TestSignalDatasetWithoutEmptySequences(unittest.TestCase):
    def test_without_holes_in_data(self):
        data = get_data_with_linear_times("2024-01-01", "2024-01-02", 24, "test")
        datasource = InMemoryDatasource(transform_timestamps(data))
        dataset = SignalDataset(
            datasource,
            pd.Timedelta("4h"),
            4,
            CalculatedStartTimesDataset(
                pd.Timestamp("2024-01-01"),
                pd.Timestamp("2024-01-02"),
                pd.Timedelta("30min"),
                pd.Timedelta("4h"),
            ),
            0,
            "live",
        )

        # Just check that we have no zeros in data
        for i in range(len(dataset)):
            self.assertGreater(dataset[i][0].sum().item(), 0.0)

        # If there are no zeros in data all should be the same
        without_empty = SignalDatasetWithoutEmptySeqences(dataset)
        final_index = 0
        for i, data in enumerate(without_empty):
            final_index = i
            self.assertTrue((data[0] == dataset[i][0]).all())
            self.assertEqual(data[1], dataset[i][1])
        self.assertEqual(final_index, len(dataset) - 1)

        without_empty_with_replacement = SignalDatasetWithoutEmptySequencesWithReplacement(dataset)
        self.assertEqual(len(without_empty_with_replacement), len(dataset))
        for i in range(len(dataset)):
            self.assertTrue((without_empty_with_replacement[i][0] == dataset[i][0]).all())
            self.assertEqual(without_empty_with_replacement[i][1], dataset[i][1])

    def test_only_holes_in_data(self):
        data = get_data_with_linear_times("2024-01-01", "2024-01-02", 4, "test")
        # data looks like this:
        # Timestamp
        # 2024-01-01 00:00:00  0.769761
        # 2024-01-01 08:00:00  0.691417
        # 2024-01-01 16:00:00  0.209693
        # 2024-01-02 00:00:00  0.006774
        datasource = InMemoryDatasource(transform_timestamps(data))
        dataset = SignalDataset(
            datasource,
            pd.Timedelta("4h"),
            4,
            InMemoryStartTimesDataset(
                [
                    pd.Timestamp("2024-01-01T01:00").timestamp(),
                    pd.Timestamp("2024-01-01T02:00").timestamp(),
                    pd.Timestamp("2024-01-01T09:00").timestamp(),
                    pd.Timestamp("2024-01-02T10:00").timestamp(),
                ]
            ),
            0,
            "live",
        )

        # Just check that we have all zeros in data
        for i in range(len(dataset)):
            self.assertEqual(dataset[i][0].sum().item(), 0.0)

        # If there are all zeros in data we should not get any data
        without_empty = SignalDatasetWithoutEmptySeqences(dataset)
        final_index = -1
        for i, data in enumerate(without_empty):
            final_index = i
        self.assertEqual(final_index, -1)

        # Cannot create dataset with replacement with only empty data
        self.assertRaises(
            ValueError,
            lambda: SignalDatasetWithoutEmptySequencesWithReplacement(dataset).test_nonempty_exists(),
        )

    def test_some_holes_in_data(self):
        data = get_data_with_linear_times("2024-01-01", "2024-01-02", 4, "test")
        # data looks like this:
        # Timestamp
        # 2024-01-01 00:00:00  0.769761
        # 2024-01-01 08:00:00  0.691417
        # 2024-01-01 16:00:00  0.209693
        # 2024-01-02 00:00:00  0.006774
        datasource = InMemoryDatasource(transform_timestamps(data))
        dataset = SignalDataset(
            datasource,
            pd.Timedelta("4h"),
            4,
            InMemoryStartTimesDataset(
                [
                    pd.Timestamp("2024-01-01T01:00").timestamp(),
                    pd.Timestamp("2024-01-01T02:00").timestamp(),
                    pd.Timestamp("2024-01-01T07:00").timestamp(),
                    pd.Timestamp("2024-01-01T09:00").timestamp(),
                    pd.Timestamp("2024-01-01T10:00").timestamp(),
                ]
            ),
            0,
            "live",
        )

        self.assertEqual(len(dataset), 5)

        # Only valid data are on index 2
        without_empty = SignalDatasetWithoutEmptySeqences(dataset)
        final_index = -1
        for i, data in enumerate(without_empty):
            self.assertTrue((data[0] == dataset[2][0]).all())
            self.assertEqual(data[1], dataset[2][1])
            final_index = i
        self.assertEqual(final_index, 0)

        without_empty_with_replacement = SignalDatasetWithoutEmptySequencesWithReplacement(dataset)
        self.assertEqual(len(without_empty_with_replacement), len(dataset))
        for i in range(len(dataset)):
            self.assertTrue((without_empty_with_replacement[i][0] == dataset[2][0]).all())
            self.assertEqual(without_empty_with_replacement[i][1], dataset[2][1])

    def test_alternating_replacements(self):
        data = get_data_with_linear_times("2024-01-01", "2024-01-02", 4, "test")
        # data looks like this:
        # Timestamp
        # 2024-01-01 00:00:00  0.769761
        # 2024-01-01 08:00:00  0.691417
        # 2024-01-01 16:00:00  0.209693
        # 2024-01-02 00:00:00  0.006774
        datasource = InMemoryDatasource(transform_timestamps(data))
        dataset = SignalDataset(
            datasource,
            pd.Timedelta("4h"),
            4,
            InMemoryStartTimesDataset(
                [
                    pd.Timestamp("2024-01-01T01:00").timestamp(),
                    pd.Timestamp("2024-01-01T02:00").timestamp(),
                    pd.Timestamp("2024-01-01T07:00").timestamp(),
                    pd.Timestamp("2024-01-01T15:00").timestamp(),
                    pd.Timestamp("2024-01-01T09:00").timestamp(),
                    pd.Timestamp("2024-01-01T10:00").timestamp(),
                ]
            ),
            0,
            "live",
        )

        self.assertEqual(len(dataset), 6)

        # Only valid data are on index 2
        without_empty = SignalDatasetWithoutEmptySeqences(dataset)
        final_index = -1
        for i, data in enumerate(without_empty):
            if i == 0:
                self.assertTrue((data[0] == dataset[2][0]).all())
                self.assertEqual(data[1], dataset[2][1])
            if i == 1:
                self.assertTrue((data[0] == dataset[3][0]).all())
                self.assertEqual(data[1], dataset[3][1])
            final_index = i
        self.assertEqual(final_index, 1)

        without_empty_with_replacement = SignalDatasetWithoutEmptySequencesWithReplacement(dataset)
        self.assertEqual(len(without_empty_with_replacement), len(dataset))
        for i in range(len(dataset)):
            without_replacement = without_empty_with_replacement[i]
            if i == 0:
                self.assertTrue((without_replacement[0] == dataset[2][0]).all())
                self.assertEqual(without_replacement[1], dataset[2][1])
            if i == 1:
                self.assertTrue((without_replacement[0] == dataset[3][0]).all())
                self.assertEqual(without_replacement[1], dataset[3][1])
            if i == 2:
                self.assertTrue((without_replacement[0] == dataset[2][0]).all())
                self.assertEqual(without_replacement[1], dataset[2][1])
            if i == 3:
                self.assertTrue((without_replacement[0] == dataset[3][0]).all())
                self.assertEqual(without_replacement[1], dataset[3][1])
            if i == 4:
                self.assertTrue((without_replacement[0] == dataset[2][0]).all())
                self.assertEqual(without_replacement[1], dataset[2][1])
            if i == 5:
                self.assertTrue((without_replacement[0] == dataset[3][0]).all())
                self.assertEqual(without_replacement[1], dataset[3][1])


if __name__ == "__main__":
    unittest.main()
