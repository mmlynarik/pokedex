import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.topgas import load_topgas


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Top.Gas.CO.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 24.4322071, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:58.9930114Z", "Value": 24.270174, "Good": True},
                    {"Timestamp": "2018-01-01T00:02:21.9960021Z", "Value": 24.328043, "Good": True},
                    {"Timestamp": "2018-01-01T00:03:05.9670104Z", "Value": 24.270174, "Good": True},
                    {"Timestamp": "2018-01-01T00:04:06.9690093Z", "Value": 23.9808311, "Good": True},
                    {"Timestamp": "2018-01-01T00:04:25.9700012Z", "Value": 24.0387, "Good": True},
                    {"Timestamp": "2018-01-01T00:05:08.0019989Z", "Value": 24.35119, "Good": True},
                    {"Timestamp": "2018-01-01T00:06:16.0050048Z", "Value": 24.6173878, "Good": True},
                    {"Timestamp": "2018-01-01T00:06:50.9750061Z", "Value": 24.7794189, "Good": True},
                    {"Timestamp": "2018-01-01T00:07:32.977005Z", "Value": 24.9298782, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.CO2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:34.9920043Z", "Value": 20.5202751, "Good": True},
                    {"Timestamp": "2018-01-01T00:01:09.9930114Z", "Value": 20.3640289, "Good": True},
                    {"Timestamp": "2018-01-01T00:03:10.998001Z", "Value": 20.2859058, "Good": True},
                    {"Timestamp": "2018-01-01T00:04:35.9700012Z", "Value": 20.3293076, "Good": True},
                    {"Timestamp": "2018-01-01T00:05:08.0019989Z", "Value": 20.3032665, "Good": True},
                    {"Timestamp": "2018-01-01T00:05:31.9720001Z", "Value": 20.1904221, "Good": True},
                    {"Timestamp": "2018-01-01T00:06:13.0050048Z", "Value": 20.2425041, "Good": True},
                    {"Timestamp": "2018-01-01T00:07:36.0080108Z", "Value": 20.5636768, "Good": True},
                ]
            }
        elif "SK1.Top.Gas.H2.%" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:05.9910125Z", "Value": 3.1596365, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:50.9930114Z", "Value": 3.33902979, "Good": True},
                    {"Timestamp": "2018-01-01T00:01:50.9950103Z", "Value": 3.33034945, "Good": True},
                    {"Timestamp": "2018-01-01T00:02:42.9660034Z", "Value": 3.203038, "Good": True},
                    {"Timestamp": "2018-01-01T00:03:34.9990081Z", "Value": 3.12780857, "Good": True},
                    {"Timestamp": "2018-01-01T00:04:31.9700012Z", "Value": 3.1596365, "Good": True},
                    {"Timestamp": "2018-01-01T00:05:17.0030059Z", "Value": 3.20882487, "Good": True},
                    {"Timestamp": "2018-01-01T00:06:19.0050048Z", "Value": 3.18278384, "Good": True},
                    {"Timestamp": "2018-01-01T00:07:38.0080108Z", "Value": 3.18567729, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestTopgasDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df = load_topgas(
            start=pd.Timestamp(2018, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2018, 1, 1, 0, 8, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df.columns.tolist(),
            ["bf1_topgasco_chem_pct", "bf1_topgasco2_chem_pct", "bf1_topgash2_chem_pct"],
        )
        self.assertIsInstance(actual_df.index, pd.DatetimeIndex)
        self.assertTrue(actual_df.index.is_unique)
        pd.testing.assert_index_equal(actual_df.index, actual_df.index.sort_values())
