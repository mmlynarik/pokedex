import unittest

import pandas as pd
import pytz
from pandas.testing import assert_frame_equal

from dbfcore.dataset.burden_drop_preprocessing import (
    clean_burden_drop_data,
    count_gradient,
    preprocess_burden_drop_data,
)


class TestBurdenDropPreprocessing(unittest.TestCase):
    def test_burden_drop_data_cleaning(self):
        input_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2018, 1, 1, 0, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 4, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 4, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            # random data
            data=[
                0.96976,
                0.54845,
                0.54845,
                0.01139,
                0.24287,
                0.47434,
                0.24287,
                0.8215561,
            ],
            columns=["gradient"],
        )
        actual_df = clean_burden_drop_data(input_df, pd.Timedelta(seconds=100))

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2018, 1, 1, 0, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 3, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                0.54845,
                0.54845,
                0.47434,
                0.24287,
            ],
            columns=["gradient"],
        )

        assert_frame_equal(expected_df, actual_df)

    def test_burden_drop_preprocessing(self):
        input_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2018, 1, 1, 0, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 4, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 4, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            # random data
            data=[
                0.96976,
                -1.54845,
                0.54845,
                0.01139,
                0.24287,
                0.47434,
                0.24287,
                0.8215561,
            ],
            columns=["gradient"],
        )
        actual_df = preprocess_burden_drop_data(input_df)

        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2018, 1, 1, 0, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 3, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[
                0.54845,
                0.47434,
                0.24287,
            ],
            columns=["gradient"],
        )

        assert_frame_equal(expected_df, actual_df)

    def test_count_gradient(self):
        input_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp(2018, 1, 1, 0, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 0, 0, 4, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 1, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 2, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 3, tzinfo=pytz.UTC),
                    pd.Timestamp(2018, 1, 1, 1, 0, 4, tzinfo=pytz.UTC),
                ],
                name="Timestamp",
            ),
            data=[1, 1, 1, 1, 1, 2, 3, 4],
            columns=["bf1_stockrod1_distance_m"],
        )
        actual_df = count_gradient(input_df, "bf1_stockrod1_distance_m")

        self.assertEqual(len(actual_df), 8)
        self.assertAlmostEqual(actual_df.iloc[1]["gradient"], 0)
        self.assertAlmostEqual(actual_df.iloc[2]["gradient"], 0)
        self.assertAlmostEqual(actual_df.iloc[5]["gradient"], 1)
        self.assertAlmostEqual(actual_df.iloc[6]["gradient"], 1)
        self.assertListEqual(actual_df.columns.tolist(), ["gradient"])
        self.assertIsInstance(actual_df.index, pd.DatetimeIndex)
        self.assertEqual(actual_df.index[0], pd.Timestamp(2018, 1, 1, 0, 0, 1, tzinfo=pytz.UTC))
        self.assertEqual(actual_df.index[4], pd.Timestamp(2018, 1, 1, 1, 0, 1, tzinfo=pytz.UTC))
