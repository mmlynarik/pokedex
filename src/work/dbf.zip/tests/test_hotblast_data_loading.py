import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.hotblast import load_hotblast


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.HotBlast.Flow.Nm3/hr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 171426.1, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 171765.266, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 171513.219, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 171989.063, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 171324.188, "Good": True},
                ]
            }
        elif "SK1.HotBlast.Temperature1.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 1094.53052, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 1094.53052, "Good": True},
                ]
            }
        elif "SK1.HotBlast.Moisture.Flow.g/Nm3" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 0.0469190069, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 0.399248958, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 1.4611485, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 1.4611485, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 2.56828475, "Good": True},
                ]
            }
        elif "SK1.NaturalGas.Tuyeres.Vol.m3/h" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 1987.16992, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 2001.77, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 2016.44, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 1945.09985, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 1935.68, "Good": True},
                ]
            }
        elif "SK1.HotBlast.O2.Flow.Nm3/hr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 13343.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 13424.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 13392.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 13360.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 13303.0, "Good": True},
                ]
            }
        elif "SK1.HotBlast.PCI.Flow.kghr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 24837.29, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 24640.5352, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 24547.9453, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 24339.6172, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 24200.7324, "Good": True},
                ]
            }

        elif "SK2.HotBlast.Flow.Nm3hr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 171426.1, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 171765.266, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 171513.219, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 171989.063, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 171324.188, "Good": True},
                ]
            }
        elif "SK2.HotBlast.Temperature.Temp.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 1094.53052, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 1095.3407, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 1094.53052, "Good": True},
                ]
            }
        elif "SK2.HotBlast.Moisture.Flow.gNm3" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 0.0469190069, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 0.399248958, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 1.4611485, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 1.4611485, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 2.56828475, "Good": True},
                ]
            }
        elif "SK2.HotBlast.O2.Flow.Nm3hr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 13343.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 13424.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 13392.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 13360.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 13303.0, "Good": True},
                ]
            }
        elif "SK2.HotBlast.PCI.Flow.kghr" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:00.9910125Z", "Value": 24837.29, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:01.9910125Z", "Value": 24640.5352, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:02.9910125Z", "Value": 24547.9453, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 24339.6172, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:04.9910125Z", "Value": 24200.7324, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestHotblastDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df_bf1 = load_hotblast(
            start=pd.Timestamp(2018, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2018, 1, 1, 0, 0, 5, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        actual_df_bf2 = load_hotblast(
            start=pd.Timestamp(2018, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2018, 1, 1, 0, 0, 5, tzinfo=pytz.UTC),
            furnace_id=2,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df_bf1.columns.tolist(),
            [
                "bf1_hotblast_flow_Nm3h",
                "bf1_hotblast_temp_C",
                "bf1_hotblastmoisture_flow_gNm3",
                "bf1_hotblastng_flow_m3h",
                "bf1_hotblasto2_flow_Nm3h",
                "bf1_hotblastpci_flow_kgh",
            ],
        )
        self.assertIsInstance(actual_df_bf1.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf1.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf1.index, actual_df_bf1.index.sort_values())

        self.assertListEqual(
            actual_df_bf2.columns.tolist(),
            [
                "bf2_hotblast_flow_Nm3h",
                "bf2_hotblast_temp_C",
                "bf2_hotblastmoisture_flow_gNm3",
                "bf2_hotblasto2_flow_Nm3h",
                "bf2_hotblastpci_flow_kgh",
            ],
        )
        self.assertIsInstance(actual_df_bf2.index, pd.DatetimeIndex)
        self.assertTrue(actual_df_bf2.index.is_unique)
        pd.testing.assert_index_equal(actual_df_bf2.index, actual_df_bf2.index.sort_values())
