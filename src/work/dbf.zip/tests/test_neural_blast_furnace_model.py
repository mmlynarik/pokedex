import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

import pandas as pd

import dbfcore.dataset.signals as s
from dbfcore.predictionmodel.inference import NeuralBlastFurnaceModel
from tests.fixtures.common import save_config_dict_to_yaml
from tests.fixtures.predictionmodel_config import get_test_predictionmodel_config_as_dict
from tests.fixtures.predictionmodel_training import train_prediction_model_for_tests
from tests.fixtures.vicreg_config import get_test_vicreg_config_as_dict
from tests.fixtures.vicreg_training import train_vicreg_for_tests


class TestGetDataDefinition(unittest.TestCase):
    def setUp(self):
        s.SIGNAL_GROUP_TO_SIGNAL_MAIN_GROUP_MAP.update({"TestSignal": "TEST"})
        s.SIGNAL_TO_SIGNAL_GROUP_MAP.update({"TestSignal1": "TestSignal"})

        self.tempdict = TemporaryDirectory()
        self.vicreg_model_path = Path(self.tempdict.name, "vicreg.ckpt")
        self.prediction_model_config_path = Path(self.tempdict.name, "prediction_model.yaml")
        self.prediction_model_path = Path(self.tempdict.name, "prediction_model.ckpt")

        vicreg_config = get_test_vicreg_config_as_dict(self.tempdict.name)
        train_vicreg_for_tests(vicreg_config, self.vicreg_model_path, train=False)

        prediction_model_config = get_test_predictionmodel_config_as_dict(self.tempdict.name)
        save_config_dict_to_yaml(prediction_model_config, self.prediction_model_config_path)
        train_prediction_model_for_tests(prediction_model_config, self.prediction_model_path, train=False)

    def tearDown(self):
        self.tempdict.cleanup()

    def test_eval_false(self):
        model = NeuralBlastFurnaceModel(
            value_resolution=200,
            time_resolution=240,
            config_path=self.prediction_model_config_path,
            prediction_model_path=self.prediction_model_path,
            embedding_model_paths={
                "TEST": self.vicreg_model_path,
            },
            eval_mode=False,
        )

        expected = {
            "TestSignal": (
                pd.Timestamp("2024-09-01 15:00:00+0000", tz="UTC"),
                pd.Timestamp("2024-09-01 19:00:00+0000", tz="UTC"),
            )
        }

        calc_time = pd.Timestamp("2024-09-01 19:00:00+0000", tz="UTC")
        actual = model.get_data_definition(calc_time)

        self.assertEqual(expected, actual)

    def test_eval_true(self):
        model = NeuralBlastFurnaceModel(
            value_resolution=200,
            time_resolution=240,
            config_path=self.prediction_model_config_path,
            prediction_model_path=self.prediction_model_path,
            embedding_model_paths={
                "TEST": self.vicreg_model_path,
            },
            eval_mode=True,
        )

        expected = {
            "TestSignal": (
                pd.Timestamp("2024-09-01 15:00:00+0000", tz="UTC"),
                pd.Timestamp("2024-09-01 20:00:00+0000", tz="UTC"),
            ),
        }

        calc_time = pd.Timestamp("2024-09-01 19:00:00+0000", tz="UTC")
        actual = model.get_data_definition(calc_time)

        self.assertEqual(expected, actual)


if __name__ == "__main__":
    unittest.main()
