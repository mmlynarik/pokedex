import unittest
import warnings
from tempfile import TemporaryDirectory

import lightning as L
import torch
import torch.utils
import torch.utils.data
from lightning import Trainer
from lightning.pytorch.callbacks.callback import Callback

from dbfcore.model.regularizationschemacallback import (
    RegularizationRegime,
    RegularizationSchema,
    RegularizationsWeights,
)


class TestDataset(torch.utils.data.Dataset):
    def __init__(self, size: int):
        self.size = size

    def __len__(self):
        return self.size

    def __getitem__(self, idx: int) -> torch.Tensor:
        return torch.zeros(10)


class TestModel(L.LightningModule):
    def __init__(self, loss_sequence):
        super().__init__()
        self.model = torch.nn.Linear(10, 1)
        self.kldiv_loss_weight = 0.0
        self.lip_decoder_loss_weight = 0.0
        self.lip_trunk_loss_weight = 0.0
        self.variance_loss_weight = 0.0
        self.covariance_loss_weight = 0.0
        self.negative_value_loss_weight = 0.0
        self.loss_sequence = loss_sequence

    def training_step(self, batch: torch.Tensor, batch_idx: int):
        self.model(batch)
        loss = torch.tensor(
            self.loss_sequence[self.global_step], requires_grad=True, device=self.model.weight.device
        )
        self.log("train/reconstruction_loss", loss)
        self.log("train/kldiv_loss", loss)
        self.log("train/lip_decoder_loss", loss)
        self.log("train/lip_trunk_loss", loss)
        self.log("train/variance_loss", loss)
        self.log("train/covariance_loss", loss)
        self.log("train/negative_value_loss", loss)
        return loss

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=1e-3)

    def set_regularization_loss_weight(self, name: str, value: float):
        setattr(self, name, value)


class TestingCallback(Callback):
    def __init__(self, expected_loss_callback):
        self.expected_loss_callback = expected_loss_callback

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        self.expected_loss_callback(pl_module.global_step - 1, pl_module.kldiv_loss_weight)


class TestRegularizationSchema(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore")

    def test_smoke(self):
        with TemporaryDirectory() as tempdict:
            datamodule = L.LightningDataModule.from_datasets(TestDataset(10), batch_size=2)
            model = TestModel(
                [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.1, 0.1, 0.1] + [0.1] * 1000
            )

            schema = RegularizationSchema(
                min_delta=-0.001,
                regularization_regimes=[
                    RegularizationRegime(RegularizationsWeights(1, 1, 1, 1, 1, 1), 0.1),
                    RegularizationRegime(RegularizationsWeights(2, 2, 2, 2, 2, 2), 0.2),
                ],
                check_every_n_steps=1,
                cooldown_period_n_steps=4,
            )

            # Loss is not improving after step 12
            # so we want to increase regularization step every 4 training steps
            def check_loss_weight(step, loss_weight):
                if step < 12:
                    self.assertAlmostEqual(loss_weight, 0.0, places=6)
                elif step < 16:
                    # (Main loss * regime.strength * relative strength) / current_loss
                    self.assertAlmostEqual(loss_weight, ((0.1 * 0.1) / 6) / 0.1, places=6)
                else:
                    self.assertAlmostEqual(loss_weight, ((0.1 * 0.2) / 6) / 0.1, places=6)

            testing_callback = TestingCallback(check_loss_weight)

            trainer = Trainer(
                accelerator="cpu",
                max_epochs=5,
                enable_progress_bar=False,
                enable_model_summary=False,
                enable_checkpointing=False,
                callbacks=[schema, testing_callback],
                log_every_n_steps=10,
                default_root_dir=tempdict,
            )
            trainer.fit(model=model, datamodule=datamodule)


if __name__ == "__main__":
    unittest.main()
