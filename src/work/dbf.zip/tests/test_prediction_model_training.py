import unittest
import warnings
from tempfile import TemporaryDirectory

from dbfcore.predictionmodel.model import PredictionModel
from tests.fixtures.common import get_checkpoint_path
from tests.fixtures.predictionmodel_config import get_test_predictionmodel_config_as_dict
from tests.fixtures.predictionmodel_training import train_prediction_model_for_tests


class TestPredictionModelTraining(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore")

    def test_fast_training(self):
        with TemporaryDirectory() as tempdict:
            config = get_test_predictionmodel_config_as_dict(tempdict, False)
            model_path = get_checkpoint_path(tempdict, "prediction_model")
            train_prediction_model_for_tests(config, model_path)
            PredictionModel.load_from_checkpoint(model_path)

    def test_fast_training_with_last_value(self):
        with TemporaryDirectory() as tempdict:
            config = get_test_predictionmodel_config_as_dict(tempdict, True)
            model_path = get_checkpoint_path(tempdict, "prediction_model")
            train_prediction_model_for_tests(config, model_path)
            PredictionModel.load_from_checkpoint(model_path)


if __name__ == "__main__":
    unittest.main()
