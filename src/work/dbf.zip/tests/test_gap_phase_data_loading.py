import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.gap_phase import load_gap_phase


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Gap.Phase" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:33Z", "Value": 2.0, "Good": True},
                    {"Timestamp": "2018-01-01T00:30:50Z", "Value": 0.0, "Good": True},
                    {"Timestamp": "2018-01-01T01:44:01Z", "Value": 1.0, "Good": True},
                    {"Timestamp": "2018-01-01T03:05:02Z", "Value": 2.0, "Good": True},
                    {"Timestamp": "2018-01-01T03:35:35Z", "Value": 0.0, "Good": True},
                    {"Timestamp": "2018-01-01T04:43:11Z", "Value": 1.0, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestGapPhaseDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df = load_gap_phase(
            start=pd.Timestamp(2018, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2018, 1, 1, 5, 0, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df.columns.tolist(),
            ["bf1_gap_phase_enum"],
        )
        self.assertIsInstance(actual_df.index, pd.DatetimeIndex)
        self.assertTrue(actual_df.index.is_unique)
        pd.testing.assert_index_equal(actual_df.index, actual_df.index.sort_values())
