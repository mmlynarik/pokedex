import unittest
from datetime import datetime
from typing import Optional

import pandas as pd

from dbfcore.dataset.hooks import DataSources
from dbfcore.dataset.signals.hotmetal_chems import (  # get_cacheable_flag_from_tapping_times,; process_tapping_start_end_df,
    assign_tapping_ids,
    calc_est_dt_all_dts_available,
    calc_est_dt_slag_start_dt_not_available,
    calc_est_dt_tapping_and_slag_start_dt_available,
    calc_est_dt_tapping_start_dt_available,
    calculate_fe_pct,
    get_estimated_sample_collection_dt,
    get_estimated_sample_collection_dts,
    load_hotmetal_chems,
    merge_tapping_start_slag_end_dfs,
    pick_defined_signals,
)
from dbfcore.settings import TZ_UTC


class FakeAZVPHook:
    def __init__(self):
        pass

    def get_pig_iron_analysis(self, start: datetime, end: datetime, furnace_id: int) -> pd.DataFrame:
        return pd.read_csv(
            "./tests/test_data/pig_iron_analysis.csv",
            parse_dates=["pig_iron_analysis_date"],
            date_format="ISO8601",
        )


class FakePZVPHook:
    pass


class FakeOkoClient:
    def __init__(self):
        pass


class FakeScadaClient:
    pass


class FakePvisClient:
    pass


class FakePiClient:
    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.CastingStart" in url:
            return {
                "Items": [
                    {"Timestamp": "2022-12-31T17:34:57Z", "Value": 12507.0, "Good": True},
                    {"Timestamp": "2022-12-31T20:57:32Z", "Value": 12508.0, "Good": True},
                    {"Timestamp": "2022-12-31T23:20:06Z", "Value": 12509.0, "Good": True},
                    {"Timestamp": "2023-01-01T02:55:41Z", "Value": 12510.0, "Good": True},
                    {"Timestamp": "2023-01-01T06:26:17Z", "Value": 10001.0, "Good": True},
                    {"Timestamp": "2023-01-01T09:45:52Z", "Value": 10002.0, "Good": True},
                    {"Timestamp": "2023-01-01T13:33:33Z", "Value": 10003.0, "Good": True},
                    {"Timestamp": "2023-01-01T16:25:44Z", "Value": 10004.0, "Good": True},
                    {"Timestamp": "2023-01-01T18:41:19Z", "Value": 10005.0, "Good": True},
                    {"Timestamp": "2023-01-01T21:38:17Z", "Value": 10006.0, "Good": True},
                ]
            }
        elif "SK1.SlagStart" in url:
            return {
                "Items": [
                    {"Timestamp": "2022-12-31T19:41:13Z", "Value": 12507.0, "Good": True},
                    {"Timestamp": "2022-12-31T21:32:39Z", "Value": 12508.0, "Good": True},
                    {"Timestamp": "2023-01-01T00:38:14Z", "Value": 12509.0, "Good": True},
                    {"Timestamp": "2023-01-01T04:17:16Z", "Value": 12510.0, "Good": True},
                    {"Timestamp": "2023-01-01T07:58:17Z", "Value": 10001.0, "Good": True},
                    {"Timestamp": "2023-01-01T12:20:02Z", "Value": 10002.0, "Good": True},
                    {"Timestamp": "2023-01-01T14:10:00Z", "Value": 10003.0, "Good": True},
                    {"Timestamp": "2023-01-01T17:26:51Z", "Value": 10004.0, "Good": True},
                    {"Timestamp": "2023-01-01T19:43:44Z", "Value": 10005.0, "Good": True},
                    {"Timestamp": "2023-01-01T23:07:03Z", "Value": 10006.0, "Good": True},
                ]
            }
        elif "SK1.EndOfCast" in url:
            return {
                "Items": [
                    {"Timestamp": "2022-12-31T16:43:28Z", "Value": 12506.0, "Good": True},
                    {"Timestamp": "2022-12-31T20:10:15Z", "Value": 12507.0, "Good": True},
                    {"Timestamp": "2022-12-31T22:25:28Z", "Value": 12508.0, "Good": True},
                    {"Timestamp": "2023-01-01T01:51:12Z", "Value": 12509.0, "Good": True},
                    {"Timestamp": "2023-01-01T05:35:07Z", "Value": 12510.0, "Good": True},
                    {"Timestamp": "2023-01-01T08:55:58Z", "Value": 10001.0, "Good": True},
                    {"Timestamp": "2023-01-01T12:35:57Z", "Value": 10002.0, "Good": True},
                    {"Timestamp": "2023-01-01T15:30:22Z", "Value": 10003.0, "Good": True},
                    {"Timestamp": "2023-01-01T17:50:13Z", "Value": 10004.0, "Good": True},
                    {"Timestamp": "2023-01-01T20:45:17Z", "Value": 10005.0, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestMergeTappingStartSlagEndDfs(unittest.TestCase):
    def setUp(self):
        self.tapping_start = pd.DataFrame(
            index=[
                pd.Timestamp("2025-01-01 08:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 14:00:00", tz=TZ_UTC),
            ],
            data=[30001, 30002, 30003],
            columns=["tapping_number"],
        )
        self.slag_start = pd.DataFrame(
            index=[
                pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 15:00:00", tz=TZ_UTC),
            ],
            data=[30001, 30002, 30003],
            columns=["tapping_number"],
        )
        self.tapping_end = pd.DataFrame(
            index=[
                pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                pd.Timestamp("2025-01-01 16:00:00", tz=TZ_UTC),
            ],
            data=[30001, 30002, 30003],
            columns=["tapping_number"],
        )

    def test_no_duplicates(self):
        expected = pd.DataFrame(
            index=pd.Series([300012025, 300022025, 300032025], name="tapping_id"),
            data=[
                [
                    pd.Timestamp("2025-01-01 08:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    30001,
                ],
                [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                    30002,
                ],
                [
                    pd.Timestamp("2025-01-01 14:00:00", tz=TZ_UTC),
                    30003,
                    pd.Timestamp("2025-01-01 15:00:00", tz=TZ_UTC),
                    30003,
                    pd.Timestamp("2025-01-01 16:00:00", tz=TZ_UTC),
                    30003,
                ],
            ],
            columns=["starts", "tapping_number", "slags", "tapping_number", "ends", "tapping_number"],
        )
        result = merge_tapping_start_slag_end_dfs(self.tapping_start, self.slag_start, self.tapping_end)

        pd.testing.assert_frame_equal(expected, result)

    def test_duplicated_timestamps(self):
        # Duplicate tapping 30003 in all input DFs
        self.tapping_start = pd.concat([self.tapping_start, self.tapping_start.tail(1)])
        self.tapping_start = pd.concat([self.tapping_start, self.tapping_start.tail(1)])
        self.tapping_start = pd.concat([self.tapping_start, self.tapping_start.tail(1)])

        expected = pd.DataFrame(
            index=pd.Series([300012025, 300022025, 300032025], name="tapping_id"),
            data=[
                [
                    pd.Timestamp("2025-01-01 08:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    30001,
                ],
                [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                    30002,
                ],
                [
                    pd.Timestamp("2025-01-01 14:00:00", tz=TZ_UTC),
                    30003,
                    pd.Timestamp("2025-01-01 15:00:00", tz=TZ_UTC),
                    30003,
                    pd.Timestamp("2025-01-01 16:00:00", tz=TZ_UTC),
                    30003,
                ],
            ],
            columns=["starts", "tapping_number", "slags", "tapping_number", "ends", "tapping_number"],
        )

        result = merge_tapping_start_slag_end_dfs(self.tapping_start, self.slag_start, self.tapping_end)

        pd.testing.assert_frame_equal(expected, result)

    def test_duplicated_tapping_numbers_with_different_timestamps(self):
        # Duplicate tapping 30003 with different timestamps in all input DFs
        self.tapping_start = pd.concat(
            [
                self.tapping_start,
                pd.DataFrame(
                    index=[pd.Timestamp("2025-01-01 14:30:00", tz=TZ_UTC)],
                    data=[30003],
                    columns=["tapping_number"],
                ),
            ]
        )
        self.slag_start = pd.concat(
            [
                self.slag_start,
                pd.DataFrame(
                    index=[pd.Timestamp("2025-01-01 15:30:00", tz=TZ_UTC)],
                    data=[30003],
                    columns=["tapping_number"],
                ),
            ]
        )
        self.tapping_end = pd.concat(
            [
                self.tapping_end,
                pd.DataFrame(
                    index=[pd.Timestamp("2025-01-01 16:30:00", tz=TZ_UTC)],
                    data=[30003],
                    columns=["tapping_number"],
                ),
            ]
        )

        expected = pd.DataFrame(
            index=pd.Series([300012025, 300022025], name="tapping_id"),
            data=[
                [
                    pd.Timestamp("2025-01-01 08:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    30001,
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    30001,
                ],
                [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    30002,
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                    30002,
                ],
            ],
            columns=["starts", "tapping_number", "slags", "tapping_number", "ends", "tapping_number"],
        )

        result = merge_tapping_start_slag_end_dfs(self.tapping_start, self.slag_start, self.tapping_end)

        pd.testing.assert_frame_equal(expected, result)


class TestCalculateFePct(unittest.TestCase):
    def test_smoke_test(self):
        input = pd.DataFrame(
            {
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "tapping_number": [30001, 30001, 30001],
                "pig_iron_sample_number": [1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001],
                "c_pct": [4.11, 4.28, 4.22],
                "mn_pct": [0.39, 0.31, 0.36],
                "p_pct": [0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001],
                "s_pct": [0.018, 0.046, 0.022],
                "si_pct": [0.9, 0.82, 0.85],
                "ti_pct": [0.028, 0.025, 0.027],
                "zn_pct": [0.005, 0.003, 0.004],
            }
        )
        expected = pd.DataFrame(
            {
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "tapping_number": [30001, 30001, 30001],
                "pig_iron_sample_number": [1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001],
                "c_pct": [4.11, 4.28, 4.22],
                "mn_pct": [0.39, 0.31, 0.36],
                "p_pct": [0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001],
                "s_pct": [0.018, 0.046, 0.022],
                "si_pct": [0.9, 0.82, 0.85],
                "ti_pct": [0.028, 0.025, 0.027],
                "zn_pct": [0.005, 0.003, 0.004],
                "fe_pct": [94.489, 94.454, 94.457],
            }
        )
        result = calculate_fe_pct(input)

        pd.testing.assert_frame_equal(expected, result)


class TestAssignTappingIds(unittest.TestCase):
    def test_smoke_test(self):
        input = pd.DataFrame(
            {
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "tapping_number": [30001, 30001, 30001],
                "pig_iron_sample_number": [1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001],
                "c_pct": [4.11, 4.28, 4.22],
                "mn_pct": [0.39, 0.31, 0.36],
                "p_pct": [0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001],
                "s_pct": [0.018, 0.046, 0.022],
                "si_pct": [0.9, 0.82, 0.85],
                "ti_pct": [0.028, 0.025, 0.027],
                "zn_pct": [0.005, 0.003, 0.004],
            }
        )
        expected = pd.DataFrame(
            {
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "tapping_number": [30001, 30001, 30001],
                "pig_iron_sample_number": [1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001],
                "c_pct": [4.11, 4.28, 4.22],
                "mn_pct": [0.39, 0.31, 0.36],
                "p_pct": [0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001],
                "s_pct": [0.018, 0.046, 0.022],
                "si_pct": [0.9, 0.82, 0.85],
                "ti_pct": [0.028, 0.025, 0.027],
                "zn_pct": [0.005, 0.003, 0.004],
                "tapping_id": [300012025, 300012025, 300012025],
            }
        )
        result = assign_tapping_ids(input)

        pd.testing.assert_frame_equal(expected, result)


class TestCalcEstDtTappingStartDtAvailable(unittest.TestCase):
    def test_tapping_start_dt_only_and_prev_empty_quarter_dt_lt_est_dt(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and no previous estimated sample colection dates, and quarter_dt < est_dt."""
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        est_dt = pd.Timestamp("2025-01-01 10:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:22:30")
        result = calc_est_dt_tapping_start_dt_available(
            tapping_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_prev_empty_quarter_dt_gt_est_dt(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and no previous estimated sample colection dates, and quarter_dt > est_dt."""
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        est_dt = pd.Timestamp("2025-01-01 09:20:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:20:00")
        result = calc_est_dt_tapping_start_dt_available(
            tapping_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_one_prev_est_dt_gt_last_prev(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and one previous estimated sample colection dates are provided, and est_dt > last previous
        estimated sample collection date."""
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        est_dt = pd.Timestamp("2025-01-01 10:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 10:20:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 10:30:00")
        result = calc_est_dt_tapping_start_dt_available(
            tapping_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_one_prev_est_dt_le_last_prev(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and one previous estimated sample colection dates are provided, and est_dt < last previous
        estimated sample collection date."""
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        est_dt = pd.Timestamp("2025-01-01 10:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 10:40:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 10:45:00")
        result = calc_est_dt_tapping_start_dt_available(
            tapping_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)


class TestCalcEstDtTappingAndSlagStartDtAvailable(unittest.TestCase):
    def test_tapping_end_dt_and_prev_empty_est_dt_lt_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt are provided (no tapping_end_dt) and
        no previous estimated sample colection dates, and est_dt < slag_start_dt.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:45:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_and_prev_empty_est_dt_ge_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt are provided (no tapping_end_dt) and
        no previous estimated sample colection dates, and est_dt >= slag_start_dt.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:15:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_one_prev_est_dt_gt_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        one previous estimated sample colection date are provided, and est_dt > slag_start_dt.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:25:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:20:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_one_prev_est_dt_le_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        one previous estimated sample colection date are provided, and est_dt <= slag_start_dt.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:35:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:20:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:40:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_two_prev_est_dt_gt_last_prev(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        two previous estimated sample colection dates are provided, and est_dt > last previous
        estimated sample collection date.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:10:00"),
            pd.Timestamp("2025-01-01 09:20:00"),
        ]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_two_prev_est_dt_le_last_prev(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        two previous estimated sample colection dates are provided, and est_dt <= last previous
        estimated sample collection date.
        """
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:10:00"),
            pd.Timestamp("2025-01-01 09:35:00"),
        ]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:40:00")
        result = calc_est_dt_tapping_and_slag_start_dt_available(
            slag_start_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)


class TestCalcEstDtAllDtsAvailable(unittest.TestCase):
    def test_tapping_start_slag_end_no_prev_quarter_dt_lt_slag(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        no previous estimated sample collection dates, and quarter_dt < slag_start_dt.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 08:22:30")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_no_prev_quarter_dt_ge_slag(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        no previous estimated sample collection dates, and quarter_dt >= slag_start_dt.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 08:15:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:00:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        est_dt = pd.Timestamp("2025-01-01 09:40:00")
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 08:15:00")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_one_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > slag_start_dt) is true.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:15:00")]
        est_dt = pd.Timestamp("2025-01-01 10:15:00")
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_one_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        one previous estimated sample collection date, but the condition
        (est_dt < tapping_end_dt and est_dt > slag_start_dt) is false.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:00:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:15:00")]
        est_dt = pd.Timestamp("2025-01-01 10:15:00")
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:25:00")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_two_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:15:00"),
            pd.Timestamp("2025-01-01 10:00:00"),
        ]
        est_dt = pd.Timestamp("2025-01-01 10:15:00")
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_two_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:15:00"),
            pd.Timestamp("2025-01-01 10:00:00"),
        ]
        est_dt = pd.Timestamp("2025-01-01 10:25:00")
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = calc_est_dt_all_dts_available(
            tapping_start_dt, slag_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)


class TestCalcEstDtSlagStartDtNotAvailable(unittest.TestCase):
    def test_slag_start_dt_not_available_and_prev_empty(self):
        """Test case when tapping_start_dt and tapping_end_dt are provided (no slag)
        and no previous estimated sample colection dates."""
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 08:22:30")
        result = calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_one_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:10:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 09:05:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:10:00")
        result = calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_one_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:10:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 09:15:00")]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:20:00")
        result = calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_two_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:10:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [
            pd.Timestamp("2025-01-01 09:00:00"),
            pd.Timestamp("2025-01-01 09:05:00"),
        ]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:10:00")
        result = calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_two_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        est_dt = pd.Timestamp("2025-01-01 09:10:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [
            pd.Timestamp("2025-01-01 09:05:00"),
            pd.Timestamp("2025-01-01 09:15:00"),
        ]
        tolerance = pd.Timedelta(minutes=5)

        expected = pd.Timestamp("2025-01-01 09:25:00")
        result = calc_est_dt_slag_start_dt_not_available(
            tapping_start_dt, tapping_end_dt, est_dt, prev_est_sample_collection_dts, tolerance
        )
        self.assertEqual(result, expected)


class TestGetEstimatedSampleCollectionDt(unittest.TestCase):
    def test_tapping_start_dt_only_and_prev_empty_quarter_dt_lt_est_dt(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and no previous estimated sample colection dates, and quarter_dt < est_dt."""
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = None
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 09:22:30")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_prev_empty_quarter_dt_gt_est_dt(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and no previous estimated sample colection dates, and quarter_dt > est_dt."""
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 09:50:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = None
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 09:20:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_one_prev_est_dt_gt_last_prev(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and one previous estimated sample colection dates are provided, and est_dt > last previous
        estimated sample collection date."""
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 11:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = None
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 10:20:00")]

        expected = pd.Timestamp("2025-01-01 10:30:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_dt_only_and_one_prev_est_dt_le_last_prev(self):
        """Test case when only tapping_start_dt is provided (no slag or tapping_end)
        and one previous estimated sample colection dates are provided, and est_dt < last previous
        estimated sample collection date."""
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 11:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = None
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 10:40:00")]

        expected = pd.Timestamp("2025-01-01 10:45:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_and_prev_empty_est_dt_lt_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt are provided (no tapping_end_dt) and
        no previous estimated sample colection dates, and est_dt < slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:45:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_and_prev_empty_est_dt_ge_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt are provided (no tapping_end_dt) and
        no previous estimated sample colection dates, and est_dt >= slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 09:15:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_one_prev_est_dt_gt_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        one previous estimated sample colection date are provided, and est_dt > slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:25:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:20:00")]

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_one_prev_est_dt_le_slag(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        one previous estimated sample colection date are provided, and est_dt <= slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:35:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:20:00")]

        expected = pd.Timestamp("2025-01-01 09:40:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_two_prev_est_dt_gt_last_prev(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        two previous estimated sample colection dates are provided, and est_dt > last previous
        estimated sample collection date.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:10:00"),
            pd.Timestamp("2025-01-01 09:20:00"),
        ]

        expected = pd.Timestamp("2025-01-01 09:30:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_end_dt_empty_two_prev_est_dt_le_last_prev(self):
        """
        Test case when tapping_start_dt and slag_start_dt (no tapping_end_dt) and
        two previous estimated sample colection dates are provided, and est_dt <= last previous
        estimated sample collection date.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:15:00")
        tapping_end_dt = None
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:10:00"),
            pd.Timestamp("2025-01-01 09:35:00"),
        ]

        expected = pd.Timestamp("2025-01-01 09:40:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_no_prev_quarter_dt_lt_slag(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        no previous estimated sample collection dates, and quarter_dt < slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 08:22:30")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_no_prev_quarter_dt_ge_slag(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        no previous estimated sample collection dates, and quarter_dt >= slag_start_dt.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:10:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 08:15:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:00:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 08:15:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_one_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > slag_start_dt) is true.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:45:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:15:00")]

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_one_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        one previous estimated sample collection date, but the condition
        (est_dt < tapping_end_dt and est_dt > slag_start_dt) is false.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:45:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:00:00")
        prev_est_sample_collection_dts = [pd.Timestamp("2025-01-01 09:15:00")]

        expected = pd.Timestamp("2025-01-01 09:25:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_two_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:45:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:15:00"),
            pd.Timestamp("2025-01-01 10:00:00"),
        ]

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_tapping_start_slag_end_two_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt, slag_start_dt, and tapping_end_dt are provided with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:55:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 09:00:00")
        slag_start_dt = pd.Timestamp("2025-01-01 09:20:00")
        tapping_end_dt = pd.Timestamp("2025-01-01 10:20:00")
        prev_est_sample_collection_dts = [
            pd.Timestamp("2025-01-01 09:15:00"),
            pd.Timestamp("2025-01-01 10:00:00"),
        ]

        expected = pd.Timestamp("2025-01-01 10:15:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_prev_empty(self):
        """Test case when tapping_start_dt and tapping_end_dt are provided (no slag)
        and no previous estimated sample colection dates."""
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 10:00:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = None
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = []

        expected = pd.Timestamp("2025-01-01 08:22:30")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_one_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 09:40:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = None
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 09:05:00")]

        expected = pd.Timestamp("2025-01-01 09:10:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_one_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        one previous estimated sample collection date, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 09:40:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = None
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [pd.Timestamp("2025-01-01 09:15:00")]

        expected = pd.Timestamp("2025-01-01 09:20:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_two_prev_est_dt_condition_true(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is true.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 09:40:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = None
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [
            pd.Timestamp("2025-01-01 09:00:00"),
            pd.Timestamp("2025-01-01 09:05:00"),
        ]

        expected = pd.Timestamp("2025-01-01 09:10:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)

    def test_slag_start_dt_not_available_and_two_prev_est_dt_condition_false(self):
        """
        Test case when tapping_start_dt and tapping_end_dt are provided (no slag) with
        two previous estimated sample collection dates, and the condition
        (est_dt < tapping_end_dt and est_dt > prev_est_sample_collection_dts[-1]) is false.
        """
        pig_iron_analysis_date = pd.Timestamp("2025-01-01 09:40:00")
        tapping_start_dt = pd.Timestamp("2025-01-01 08:00:00")
        slag_start_dt = None
        tapping_end_dt = pd.Timestamp("2025-01-01 09:30:00")
        prev_est_sample_collection_dts: list[pd.Timestamp] = [
            pd.Timestamp("2025-01-01 09:05:00"),
            pd.Timestamp("2025-01-01 09:15:00"),
        ]

        expected = pd.Timestamp("2025-01-01 09:25:00")
        result = get_estimated_sample_collection_dt(
            pig_iron_analysis_date,
            tapping_start_dt,
            slag_start_dt,
            tapping_end_dt,
            prev_est_sample_collection_dts,
        )
        self.assertEqual(result, expected)


class TestGetEstimatedSampleCollectionDts(unittest.TestCase):
    def test_tapping_dts_with_no_start_and_no_end(self):
        """
        Test case when tapping_datetimes contains tapping_id with missing start date (NaT)
        and also contains tapping_id with missing f.e. end date (NaT).
        """
        tapping_datetimes = pd.DataFrame(
            index=pd.Series(
                [100012023, 100022023, 100032023],
                name="tapping_id",
            ),
            data={
                "starts": [
                    pd.NaT,
                    pd.Timestamp("2023-01-01 10:00:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:00:00", tz=TZ_UTC),
                ],
                "slags": [
                    pd.Timestamp("2023-01-01 10:00:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 12:00:00", tz=TZ_UTC),
                ],
                "ends": [
                    pd.Timestamp("2023-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 12:00:00", tz=TZ_UTC),
                    pd.NaT,
                ],
            },
        )

        analyses = pd.DataFrame(
            {
                "pig_iron_analysis_date": [
                    pd.Timestamp("2023-01-01 09:45:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 10:15:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 10:45:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:15:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:45:00", tz=TZ_UTC),
                ],
                "tapping_number": [10001, 10001, 10002, 10002, 10003],
                "pig_iron_sample_number": [1, 2, 1, 2, 1],
                "as_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "c_pct": [3.48, 3.92, 3.73, 3.72, 3.78],
                "mn_pct": [0.28, 0.3, 0.28, 0.31, 0.34],
                "p_pct": [0.041, 0.042, 0.038, 0.039, 0.04],
                "pb_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "s_pct": [0.053, 0.046, 0.048, 0.028, 0.043],
                "si_pct": [0.83, 1.26, 0.98, 0.91, 1.16],
                "ti_pct": [0.025, 0.046, 0.034, 0.031, 0.049],
                "zn_pct": [0.005, 0.004, 0.001, 0.001, 0.003],
                "fe_pct": [95.284, 94.38, 94.887, 94.959, 94.583],
                "tapping_id": [100012023, 100012023, 100022023, 100022023, 100032023],
            }
        )

        expected = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2023-01-01 10:15:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:05:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:15:00", tz=TZ_UTC),
                ],
                name="Timestamp",
            ),
            data={
                "pig_iron_analysis_date": [
                    pd.Timestamp("2023-01-01 10:45:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:15:00", tz=TZ_UTC),
                    pd.Timestamp("2023-01-01 11:45:00", tz=TZ_UTC),
                ],
                "tapping_number": [10002, 10002, 10003],
                "pig_iron_sample_number": [1, 2, 1],
                "as_pct": [0.001, 0.001, 0.001],
                "c_pct": [3.73, 3.72, 3.78],
                "mn_pct": [0.28, 0.31, 0.34],
                "p_pct": [0.038, 0.039, 0.04],
                "pb_pct": [0.001, 0.001, 0.001],
                "s_pct": [0.048, 0.028, 0.043],
                "si_pct": [0.98, 0.91, 1.16],
                "ti_pct": [0.034, 0.031, 0.049],
                "zn_pct": [0.001, 0.001, 0.003],
                "fe_pct": [94.887, 94.959, 94.583],
                "tapping_id": [100022023, 100022023, 100032023],
            },
        )

        result = get_estimated_sample_collection_dts(tapping_datetimes, analyses)
        pd.testing.assert_frame_equal(expected, result)


class TestPickDefinedSignals(unittest.TestCase):
    def setUp(self):
        self.tapping_number = 3

    def test_no_signal_name_defined(self):
        input = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
                name="Timestamp",
            ),
            data={
                "first_sample_dt": [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                ],
                "second_sample_dt": [
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                ],
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "pig_iron_sample_number": [1, 2, 1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "c_pct": [4.01, 4.21, 4.11, 4.28, 4.22],
                "mn_pct": [0.37, 0.36, 0.39, 0.31, 0.36],
                "p_pct": [0.055, 0.056, 0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "s_pct": [0.022, 0.02, 0.018, 0.046, 0.022],
                "si_pct": [0.76, 0.83, 0.9, 0.82, 0.85],
                "ti_pct": [0.023, 0.026, 0.028, 0.025, 0.027],
                "zn_pct": [0.003, 0.001, 0.005, 0.003, 0.004],
                "fe_pct": [94.755, 94.495, 94.489, 94.454, 94.457],
                "num_samples": [2, 2, 3, 3, 3],
                "third_sample_dt": [
                    None,
                    None,
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
            },
        )
        expected = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
                name="Timestamp",
            ),
            data={
                "bf3_pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "bf3_hotmetalas_chem_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "bf3_hotmetalc_chem_pct": [4.01, 4.21, 4.11, 4.28, 4.22],
                "bf3_hotmetalfe_chem_pct": [94.755, 94.495, 94.489, 94.454, 94.457],
                "bf3_hotmetalmn_chem_pct": [0.37, 0.36, 0.39, 0.31, 0.36],
                "bf3_hotmetalp_chem_pct": [0.055, 0.056, 0.058, 0.06, 0.058],
                "bf3_hotmetalpb_chem_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "bf3_hotmetals_chem_pct": [0.022, 0.02, 0.018, 0.046, 0.022],
                "bf3_hotmetalsi_chem_pct": [0.76, 0.83, 0.9, 0.82, 0.85],
                "bf3_hotmetalti_chem_pct": [0.023, 0.026, 0.028, 0.025, 0.027],
                "bf3_hotmetalzn_chem_pct": [0.003, 0.001, 0.005, 0.003, 0.004],
            },
        )
        result = pick_defined_signals(input, self.tapping_number)

        pd.testing.assert_frame_equal(expected, result)

    def test_with_defined_signal_name(self):
        signal_name = f"bf{self.tapping_number}_hotmetalfe_chem_pct"
        input = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
                name="Timestamp",
            ),
            data={
                "first_sample_dt": [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                ],
                "second_sample_dt": [
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                ],
                "pig_iron_analysis_date": [
                    pd.Timestamp("2025-01-01 09:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 10:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:00:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 13:00:00", tz=TZ_UTC),
                ],
                "pig_iron_sample_number": [1, 2, 1, 2, 3],
                "as_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "c_pct": [4.01, 4.21, 4.11, 4.28, 4.22],
                "mn_pct": [0.37, 0.36, 0.39, 0.31, 0.36],
                "p_pct": [0.055, 0.056, 0.058, 0.06, 0.058],
                "pb_pct": [0.001, 0.001, 0.001, 0.001, 0.001],
                "s_pct": [0.022, 0.02, 0.018, 0.046, 0.022],
                "si_pct": [0.76, 0.83, 0.9, 0.82, 0.85],
                "ti_pct": [0.023, 0.026, 0.028, 0.025, 0.027],
                "zn_pct": [0.003, 0.001, 0.005, 0.003, 0.004],
                "fe_pct": [94.755, 94.495, 94.489, 94.454, 94.457],
                "num_samples": [2, 2, 3, 3, 3],
                "third_sample_dt": [
                    None,
                    None,
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
            },
        )
        expected = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-01-01 08:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 09:55:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 11:30:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:05:00", tz=TZ_UTC),
                    pd.Timestamp("2025-01-01 12:55:00", tz=TZ_UTC),
                ],
                name="Timestamp",
            ),
            data={"bf3_hotmetalfe_chem_pct": [94.755, 94.495, 94.489, 94.454, 94.457]},
        )
        result = pick_defined_signals(input, self.tapping_number, signal_name)

        pd.testing.assert_frame_equal(expected, result)


class TestHotmetalChemsLoader(unittest.TestCase):
    # def test_cacheable_flag_negative(self):
    #     tappingstart_input_df = pd.DataFrame(
    #         index=pd.Series(
    #             [
    #                 pd.Timestamp(2024, 1, 1, 2, 25, 50, tzinfo=pytz.UTC),
    #                 pd.Timestamp(2024, 1, 1, 7, 11, 41, tzinfo=pytz.UTC),
    #             ],
    #             name="Timestamp",
    #         ),
    #         data=[13187.0, 13188.0],
    #         columns=["tapping_number"],
    #     )
    #     tappingend_input_df = pd.DataFrame(
    #         index=pd.Series(
    #             [
    #                 pd.Timestamp(2024, 1, 1, 1, 14, 13, tzinfo=pytz.UTC),
    #                 pd.Timestamp(2024, 1, 1, 4, 34, 29, tzinfo=pytz.UTC),
    #             ],
    #             name="Timestamp",
    #         ),
    #         data=[13186.0, 13187.0],
    #         columns=["tapping_number"],
    #     )
    #     tapping_times = process_tapping_start_end_df(tappingstart_input_df, tappingend_input_df)
    #     cacheability = get_cacheable_flag_from_tapping_times(tapping_times)
    #     self.assertFalse(cacheability)

    # def test_cacheable_flag_positive(self):
    #     tappingstart_input_df = pd.DataFrame(
    #         index=pd.Series(
    #             [
    #                 pd.Timestamp(2024, 1, 1, 2, 25, 50, tzinfo=pytz.UTC),
    #                 pd.Timestamp(2024, 1, 1, 5, 11, 41, tzinfo=pytz.UTC),
    #             ],
    #             name="Timestamp",
    #         ),
    #         data=[13187.0, 13188.0],
    #         columns=["tapping_number"],
    #     )
    #     tappingend_input_df = pd.DataFrame(
    #         index=pd.Series(
    #             [
    #                 pd.Timestamp(2024, 1, 1, 4, 14, 13, tzinfo=pytz.UTC),
    #                 pd.Timestamp(2024, 1, 1, 6, 34, 29, tzinfo=pytz.UTC),
    #             ],
    #             name="Timestamp",
    #         ),
    #         data=[13187.0, 13188.0],
    #         columns=["tapping_number"],
    #     )
    #     tapping_times = process_tapping_start_end_df(tappingstart_input_df, tappingend_input_df)
    #     cacheability = get_cacheable_flag_from_tapping_times(tapping_times)
    #     self.assertTrue(cacheability)

    def test_load_tappings_output_format(self):
        start = pd.Timestamp("2023-01-01", tzinfo=TZ_UTC)
        end = pd.Timestamp("2023-01-02", tzinfo=TZ_UTC)
        furnace_id = 1
        datasources = DataSources(
            FakeAZVPHook(), FakePZVPHook(), FakePiClient(), FakeScadaClient(), FakeOkoClient(), FakePvisClient()  # type: ignore
        )
        data = load_hotmetal_chems(start, end, furnace_id, datasources)
        self.assertEqual(
            list(data.columns),
            [
                "bf1_pig_iron_analysis_date",
                "bf1_hotmetalas_chem_pct",
                "bf1_hotmetalc_chem_pct",
                "bf1_hotmetalfe_chem_pct",
                "bf1_hotmetalmn_chem_pct",
                "bf1_hotmetalp_chem_pct",
                "bf1_hotmetalpb_chem_pct",
                "bf1_hotmetals_chem_pct",
                "bf1_hotmetalsi_chem_pct",
                "bf1_hotmetalti_chem_pct",
                "bf1_hotmetalzn_chem_pct",
            ],
        )
        self.assertEqual(type(data.index), pd.DatetimeIndex)
        self.assertTrue(data.index.is_unique)
        self.assertTrue(data.index.is_monotonic_increasing)


if __name__ == "__main__":
    unittest.main()
