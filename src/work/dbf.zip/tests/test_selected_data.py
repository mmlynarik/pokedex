import unittest
from pathlib import Path

import pandas as pd

from dbfcore.predictionmodel.inference import get_embedding_model_inputs_func, signal_requires_future


class TestSelectedDataForEmbeddingModel(unittest.TestCase):
    signal_name = "bf3_hotblast_flow_Nm3h"
    signal_group = "bf3_hotblast"
    datadir = "./tests/test_data"

    def load_signal_group_data(self) -> pd.DataFrame:
        df = pd.read_csv(
            Path(self.datadir, "test_selected_data.csv"), parse_dates=["Timestamp"], index_col="Timestamp"
        )
        return {"bf3_hotblast": df}

    def test_history_only_eval_false(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("-3h")
        window_size = pd.Timedelta("1h")
        eval_mode = False

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_history_only_signal")

    def test_history_and_future_eval_false(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("-3h")
        window_size = pd.Timedelta("4h")
        eval_mode = False

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_signal_with_future")

    def test_future_only_eval_false(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("0")
        window_size = pd.Timedelta("4h")
        eval_mode = False

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_signal_with_future")

    def test_history_only_eval_true(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("-3h")
        window_size = pd.Timedelta("1h")
        eval_mode = True

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_history_only_signal")

    def test_history_and_future_eval_true(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("-3h")
        window_size = pd.Timedelta("4h")
        eval_mode = True

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_history_only_signal")

    def test_future_only_eval_true(self):
        data = self.load_signal_group_data()
        offset = pd.Timedelta("0")
        window_size = pd.Timedelta("4h")
        eval_mode = True

        requires_future = signal_requires_future(window_size, offset, eval_mode)
        signal_data = data[self.signal_group][[self.signal_name]]

        _, func = get_embedding_model_inputs_func(requires_future, signal_data, 64)
        self.assertEqual(func.__name__, "get_embedding_model_inputs_for_history_only_signal")


if __name__ == "__main__":
    unittest.main()
