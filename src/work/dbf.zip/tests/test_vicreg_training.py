import unittest
import warnings
from tempfile import TemporaryDirectory

from dbfcore.model.vicregtraining import RealVicReg
from tests.fixtures.common import get_checkpoint_path
from tests.fixtures.vicreg_config import get_test_vicreg_config_as_dict
from tests.fixtures.vicreg_training import train_vicreg_for_tests


class TestVicRegTraining(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore")

    def test_fast_training(self):
        with TemporaryDirectory() as tempdict:
            config = get_test_vicreg_config_as_dict(tempdict)
            model_path = get_checkpoint_path(tempdict, "vicreg_model")
            train_vicreg_for_tests(config, model_path)
            RealVicReg.load_from_checkpoint(model_path)


if __name__ == "__main__":
    unittest.main()
