import unittest
from collections import Counter

import numpy as np

from dbfcore.model.datamodule.pisignal import sample_2D_array


class TestSample2DArray(unittest.TestCase):
    input_array = np.array(
        [
            [1.67254174e09, 12510],
            [1.67255438e09, 10001],
            [1.67256635e09, 10002],
            [1.67258001e09, 10003],
            [1.67259034e09, 10004],
            [1.67259848e09, 10005],
            [1.67260910e09, 10006],
        ]
    )

    def test_output_type(self):
        expected_type = np.ndarray
        actual_type_train = type(sample_2D_array(self.input_array, 2, "stratified_train"))
        actual_type_live = type(sample_2D_array(self.input_array, 2, "live"))

        self.assertEqual(expected_type, actual_type_train)
        self.assertEqual(expected_type, actual_type_live)

    def test_sample_size_smaller_than_array_length(self):
        np.random.seed(42)
        expected_output_train = np.array(
            [
                [1.67254174e09, 12510.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67260910e09, 10006.0],
            ]
        )
        expected_output_live = np.array(
            [
                [1.67255438e09, 10001.0],
                [1.67258001e09, 10003.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
            ]
        )
        actual_output_train = sample_2D_array(self.input_array, 4, "stratified_train")
        actual_output_live = sample_2D_array(self.input_array, 4, "live")

        np.testing.assert_array_equal(expected_output_train, actual_output_train)
        np.testing.assert_array_equal(expected_output_live, actual_output_live)

    def test_sample_size_equal_to_array_length(self):
        np.random.seed(42)
        expected_output = np.array(
            [
                [1.67254174e09, 12510.0],
                [1.67255438e09, 10001.0],
                [1.67256635e09, 10002.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
            ]
        )
        actual_output_train = sample_2D_array(self.input_array, 7, "stratified_train")
        actual_output_live = sample_2D_array(self.input_array, 7, "live")

        np.testing.assert_array_equal(expected_output, actual_output_train)
        np.testing.assert_array_equal(expected_output, actual_output_live)

        # Each tapping number should occur in the output array exactly once
        expected_number_of_12510s = 1
        actual_number_of_12510s = Counter(np.concatenate(actual_output_train))[12510]
        expected_number_of_10001s = 1
        actual_number_of_10001s = Counter(np.concatenate(actual_output_train))[10001]
        expected_number_of_10002s = 1
        actual_number_of_10002s = Counter(np.concatenate(actual_output_train))[10002]
        expected_number_of_10003s = 1
        actual_number_of_10003s = Counter(np.concatenate(actual_output_live))[10003]
        expected_number_of_10004s = 1
        actual_number_of_10004s = Counter(np.concatenate(actual_output_live))[10004]
        expected_number_of_10005s = 1
        actual_number_of_10005s = Counter(np.concatenate(actual_output_live))[10005]
        expected_number_of_10006s = 1
        actual_number_of_10006s = Counter(np.concatenate(actual_output_live))[10006]

        self.assertEqual(expected_number_of_12510s, actual_number_of_12510s)
        self.assertEqual(expected_number_of_10001s, actual_number_of_10001s)
        self.assertEqual(expected_number_of_10002s, actual_number_of_10002s)
        self.assertEqual(expected_number_of_10003s, actual_number_of_10003s)
        self.assertEqual(expected_number_of_10004s, actual_number_of_10004s)
        self.assertEqual(expected_number_of_10005s, actual_number_of_10005s)
        self.assertEqual(expected_number_of_10006s, actual_number_of_10006s)

    def test_sample_size_one_and_half_times_greater_than_array_length(self):
        np.random.seed(42)
        expected_output_train = np.array(
            [
                [1.67254174e09, 12510.0],
                [1.67255438e09, 10001.0],
                [1.67256635e09, 10002.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
                [1.67254174e09, 12510.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67260910e09, 10006.0],
            ]
        )
        expected_output_live = np.array(
            [
                [1.67254174e09, 12510.0],
                [1.67255438e09, 10001.0],
                [1.67256635e09, 10002.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
                [1.67255438e09, 10001.0],
                [1.67258001e09, 10003.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
            ]
        )
        actual_output_train = sample_2D_array(self.input_array, 11, "stratified_train")
        actual_output_live = sample_2D_array(self.input_array, 11, "live")

        np.testing.assert_array_equal(expected_output_train, actual_output_train)
        np.testing.assert_array_equal(expected_output_live, actual_output_live)

    def test_sample_size_two_times_greater_than_array_length(self):
        np.random.seed(42)
        expected_output = np.array(
            [
                [1.67254174e09, 12510.0],
                [1.67255438e09, 10001.0],
                [1.67256635e09, 10002.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
                [1.67254174e09, 12510.0],
                [1.67255438e09, 10001.0],
                [1.67256635e09, 10002.0],
                [1.67258001e09, 10003.0],
                [1.67259034e09, 10004.0],
                [1.67259848e09, 10005.0],
                [1.67260910e09, 10006.0],
            ]
        )
        actual_output_train = sample_2D_array(self.input_array, 14, "stratified_train")
        actual_output_live = sample_2D_array(self.input_array, 14, "live")

        np.testing.assert_array_equal(expected_output, actual_output_train)
        np.testing.assert_array_equal(expected_output, actual_output_live)

        # Each tapping number should occur in the output array exactly twice
        expected_number_of_12510s = 2
        actual_number_of_12510s = Counter(np.concatenate(actual_output_train))[12510]
        expected_number_of_10001s = 2
        actual_number_of_10001s = Counter(np.concatenate(actual_output_train))[10001]
        expected_number_of_10002s = 2
        actual_number_of_10002s = Counter(np.concatenate(actual_output_train))[10002]
        expected_number_of_10003s = 2
        actual_number_of_10003s = Counter(np.concatenate(actual_output_train))[10003]
        expected_number_of_10004s = 2
        actual_number_of_10004s = Counter(np.concatenate(actual_output_live))[10004]
        expected_number_of_10005s = 2
        actual_number_of_10005s = Counter(np.concatenate(actual_output_live))[10005]
        expected_number_of_10006s = 2
        actual_number_of_10006s = Counter(np.concatenate(actual_output_live))[10006]

        self.assertEqual(expected_number_of_12510s, actual_number_of_12510s)
        self.assertEqual(expected_number_of_10001s, actual_number_of_10001s)
        self.assertEqual(expected_number_of_10002s, actual_number_of_10002s)
        self.assertEqual(expected_number_of_10003s, actual_number_of_10003s)
        self.assertEqual(expected_number_of_10004s, actual_number_of_10004s)
        self.assertEqual(expected_number_of_10005s, actual_number_of_10005s)
        self.assertEqual(expected_number_of_10006s, actual_number_of_10006s)

    def test_sample_size_is_zero(self):
        with self.assertRaises(Exception):
            sample_2D_array(self.input_array, 0, "live")
            sample_2D_array(self.input_array, 0, "stratified_train")

    def test_empty_input_array(self):
        input_array = np.array([])
        with self.assertRaises(ZeroDivisionError):
            sample_2D_array(input_array, 5, "stratified_train")
            sample_2D_array(input_array, 5, "live")

    def test_invalid_mode(self):
        with self.assertRaises(Exception):
            sample_2D_array(self.input_array, 3, "invalid_mode")
            sample_2D_array(self.input_array, 7, "invalid_mode")
            sample_2D_array(self.input_array, 12, "invalid_mode")
