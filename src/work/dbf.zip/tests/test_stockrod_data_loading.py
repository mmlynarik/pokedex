import unittest
from typing import Optional

import pandas as pd
import pytz

from dbfcore.dataset.signals.stockrod import load_stockrod


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Top.StockRod1.Distance.m" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 90.96976, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:05.9910125Z", "Value": 91.54845, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:09.9910125Z", "Value": 91.54845, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:40.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:16.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:18.9910125Z", "Value": 92.47434, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:20.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:22.9920043Z", "Value": 92.8215561, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:22.9920043Z", "Value": 92.8215561, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:32.0230102Z", "Value": 93.8632, "Good": True},
                ]
            }
        elif "SK1.Top.StockRod2.Distance.m" in url:
            return {
                "Items": [
                    {"Timestamp": "2018-01-01T00:00:03.9910125Z", "Value": 90.96976, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:05.9910125Z", "Value": 91.54845, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:09.9910125Z", "Value": 91.54845, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:40.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:16.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:18.9910125Z", "Value": 92.47434, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:20.9910125Z", "Value": 92.24287, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:22.9920043Z", "Value": 92.8215561, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:22.9920043Z", "Value": 92.8215561, "Good": True},
                    {"Timestamp": "2018-01-01T00:00:32.0230102Z", "Value": 93.8632, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestStockrodDataLoading(unittest.TestCase):
    def test_data_loading(self):

        fake_pi_client = FakePiClient()

        actual_df = load_stockrod(
            start=pd.Timestamp(2018, 1, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2018, 1, 1, 0, 10, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )

        self.assertListEqual(
            actual_df.columns.tolist(),
            [
                "bf1_stockrod1_distance_m",
                "bf1_burdendrop1_speed_cms",
                "bf1_stockrod2_distance_m",
                "bf1_burdendrop2_speed_cms",
            ],
        )
        self.assertIsInstance(actual_df.index, pd.DatetimeIndex)
        self.assertTrue(actual_df.index.is_unique)
        pd.testing.assert_index_equal(actual_df.index, actual_df.index.sort_values())
