import unittest
import warnings
from tempfile import TemporaryDirectory

from dbfcore.model.signalvaesimple2 import SignalVAESimple2
from tests.fixtures.common import get_checkpoint_path
from tests.fixtures.signalvaesimple_config import get_test_svaes_config_as_dict
from tests.fixtures.signalvaesimple_training import train_signalvaesimple_for_tests


class TestSignalVAESimpleTraining(unittest.TestCase):
    def setUp(self):
        warnings.simplefilter("ignore")

    def test_fast_training(self):
        with TemporaryDirectory() as tempdict:
            config = get_test_svaes_config_as_dict(tempdict)
            model_path = get_checkpoint_path(tempdict, "svaes_model")
            train_signalvaesimple_for_tests(config, model_path)
            SignalVAESimple2.load_from_checkpoint(model_path)

    # TODO: Skontrolovat ci potrebujeme (vid http://vdevops.sk.uss.com/AADT/DBF/_workitems/edit/1771)
    # def test_with_regularization_schema_callback(self):
    #     with TemporaryDirectory() as tempdict:
    #         datamodule = get_test_datamodule(tempdict)
    #         model = get_test_model()

    #         schema = RegularizationSchema(
    #             min_delta=0.01,
    #             regularization_regimes=[
    #                 RegularizationRegime(RegularizationsWeights(1, 1, 1, 1, 1, 1), 0.1),
    #                 RegularizationRegime(RegularizationsWeights(2, 1, 1, 1, 1, 1), 0.2),
    #             ],
    #             check_every_n_steps=1,
    #             cooldown_period_n_steps=2,
    #         )

    #         trainer = Trainer(
    #             accelerator="cpu",
    #             max_epochs=2,
    #             enable_progress_bar=False,
    #             enable_model_summary=False,
    #             enable_checkpointing=False,
    #             callbacks=[schema],
    #             log_every_n_steps=10,
    #             default_root_dir=tempdict,
    #         )
    #         trainer.fit(model=model, datamodule=datamodule)


if __name__ == "__main__":
    unittest.main()
