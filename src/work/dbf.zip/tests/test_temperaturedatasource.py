import unittest
from typing import Optional

import numpy as np
import pandas as pd
import pytz
from pandas.testing import assert_frame_equal

from dbfcore.dataset.signals.hotmetal_temperatures import (
    load_hotmetal_temps,
    merge_gap_phase_and_temperatures,
    process_tappings_temperatures,
    process_temperature_raw_df,
)


class TestProcessTemperatureRawDf(unittest.TestCase):
    def test_smoke_test(self):
        test_df = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 09:00", tz="UTC"), pd.Timestamp("2022-02-02 10:00", tz="UTC")],
            data={"bf1_hotmetal_temp_C": [1455, 1501]},
        )
        expected_df = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 09:00", tz="UTC"), pd.Timestamp("2022-02-02 10:00", tz="UTC")],
            data={"temperature": [1455, 1501]},
        )

        result = process_temperature_raw_df(test_df)
        assert_frame_equal(result, expected_df)


class TestMergeTappingTimesAndTemperatures(unittest.TestCase):
    def test_no_overlapping_indexes(self):
        tapping_times = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={
                "tapping_id": [100012022, 100012022],
                "start_end": ["tapping_start_date", "tapping_end_date"],
            },
        )
        temperatures = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:45", tz="UTC"), pd.Timestamp("2022-02-02 11:30", tz="UTC")],
            data={"temperature": [1445, 1500]},
        )

        expected_df = pd.DataFrame(
            index=[
                pd.Timestamp("2022-02-02 10:00", tz="UTC"),
                pd.Timestamp("2022-02-02 10:45", tz="UTC"),
                pd.Timestamp("2022-02-02 11:30", tz="UTC"),
                pd.Timestamp("2022-02-02 12:00", tz="UTC"),
            ],
            data={
                "tapping_id": [100012022, np.nan, np.nan, 100012022],
                "start_end": ["tapping_start_date", np.nan, np.nan, "tapping_end_date"],
                "temperature": [np.nan, 1445, 1500, np.nan],
            },
        )

        result = merge_gap_phase_and_temperatures(tapping_times, temperatures)
        assert_frame_equal(result, expected_df)

    def test_overlapping_indexes(self):
        tapping_times = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={
                "tapping_id": [100012022, 100012022],
                "start_end": ["tapping_start_date", "tapping_end_date"],
            },
        )
        temperatures = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={"temperature": [1445, 1500]},
        )

        expected_df = pd.DataFrame(
            index=[
                pd.Timestamp("2022-02-02 10:00", tz="UTC"),
                pd.Timestamp("2022-02-02 10:00", tz="UTC"),
                pd.Timestamp("2022-02-02 12:00", tz="UTC"),
                pd.Timestamp("2022-02-02 12:00", tz="UTC"),
            ],
            data={
                "tapping_id": [100012022, np.nan, 100012022, np.nan],
                "start_end": ["tapping_start_date", np.nan, "tapping_end_date", np.nan],
                "temperature": [np.nan, 1445, np.nan, 1500],
            },
        )

        result = merge_gap_phase_and_temperatures(tapping_times, temperatures)
        assert_frame_equal(result, expected_df)

    def test_tapping_times_empty_dataframe(self):
        tapping_times = pd.DataFrame(
            {"tapping_id": pd.Series(dtype=float), "start_end": pd.Series(dtype=float)}
        )
        temperatures = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={"temperature": [1445, 1500]},
        )

        expected_df = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={
                "tapping_id": [np.nan, np.nan],
                "start_end": [np.nan, np.nan],
                "temperature": [1445.0, 1500.0],
            },
        )

        result = merge_gap_phase_and_temperatures(tapping_times, temperatures)
        assert_frame_equal(result, expected_df)

    def test_temperatures_empty_dataframe(self):
        tapping_times = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={
                "tapping_id": [100012022, 100012022],
                "start_end": ["tapping_start_date", "tapping_end_date"],
            },
        )
        temperatures = pd.DataFrame(columns=["temperature"], dtype=float)

        expected_df = pd.DataFrame(
            index=[pd.Timestamp("2022-02-02 10:00", tz="UTC"), pd.Timestamp("2022-02-02 12:00", tz="UTC")],
            data={
                "tapping_id": [100012022.0, 100012022.0],
                "start_end": ["tapping_start_date", "tapping_end_date"],
                "temperature": [np.nan, np.nan],
            },
        )

        result = merge_gap_phase_and_temperatures(tapping_times, temperatures)
        assert_frame_equal(result, expected_df)

    def test_both_empty_dataframes(self):
        tapping_times = pd.DataFrame(columns=["tapping_id", "start_end"]).set_index(pd.to_datetime([]))
        temperatures = pd.DataFrame(columns=["temperature"]).set_index(pd.to_datetime([]))

        expected_df = pd.DataFrame(columns=["tapping_id", "start_end", "temperature"]).set_index(
            pd.to_datetime([])
        )

        result = merge_gap_phase_and_temperatures(tapping_times, temperatures)
        assert_frame_equal(result, expected_df)


class TestProcessTappingsTemperatures(unittest.TestCase):
    test_df = pd.DataFrame(
        index=[
            pd.Timestamp("2022-02-02 10:00", tz="UTC"),
            pd.Timestamp("2022-02-02 10:50", tz="UTC"),
            pd.Timestamp("2022-02-02 11:15", tz="UTC"),
            pd.Timestamp("2022-02-02 11:30", tz="UTC"),
            pd.Timestamp("2022-02-02 12:00", tz="UTC"),
            pd.Timestamp("2022-02-02 12:40", tz="UTC"),
            pd.Timestamp("2022-02-02 13:05", tz="UTC"),
            pd.Timestamp("2022-02-02 13:25", tz="UTC"),
            pd.Timestamp("2022-02-02 13:40", tz="UTC"),
            pd.Timestamp("2022-02-02 13:50", tz="UTC"),
        ],
        data={
            "phase": [
                1,
                np.nan,
                np.nan,
                2,
                0,
                1,
                np.nan,
                np.nan,
                np.nan,
                2,
            ],
            "temperature": [np.nan, 1459, 1554, np.nan, np.nan, np.nan, 1435, 1442, 1450, np.nan],
        },
    )
    expected_df = pd.DataFrame(
        index=[
            pd.Timestamp("2022-02-02 10:50", tz="UTC"),
            pd.Timestamp("2022-02-02 11:15", tz="UTC"),
            pd.Timestamp("2022-02-02 13:05", tz="UTC"),
            pd.Timestamp("2022-02-02 13:25", tz="UTC"),
            pd.Timestamp("2022-02-02 13:40", tz="UTC"),
        ],
        data={
            "phase": [1.0, 1.0, 1.0, 1.0, 1.0],
            "temperature": [1459.0, 1554.0, 1435.0, 1442.0, 1450.0],
        },
    )

    def test_temperatures_within_range(self):
        result = process_tappings_temperatures(self.test_df)
        assert_frame_equal(result, self.expected_df)

    def test_temperatures_outside_range(self):
        self.test_df.loc[pd.Timestamp("2022-02-02 10:20", tz="UTC"), "temperature"] = 1050
        self.test_df.loc[pd.Timestamp("2022-02-02 11:25", tz="UTC"), "temperature"] = 1650

        result = process_tappings_temperatures(self.test_df)
        assert_frame_equal(result, self.expected_df)

    def test_edge_case_boundary_temperatures(self):
        self.test_df.loc[pd.Timestamp("2022-02-02 10:20", tz="UTC"), "temperature"] = 1100
        self.test_df.loc[pd.Timestamp("2022-02-02 11:25", tz="UTC"), "temperature"] = 1600
        self.test_df = self.test_df.sort_index()

        expected_df = pd.concat(
            [
                self.expected_df,
                pd.DataFrame(
                    index=[
                        pd.Timestamp("2022-02-02 10:20", tz="UTC"),
                        pd.Timestamp("2022-02-02 11:25", tz="UTC"),
                    ],
                    data={
                        "phase": [1.0, 1.0],
                        "temperature": [1100.0, 1600.0],
                    },
                ),
            ]
        ).sort_index()

        result = process_tappings_temperatures(self.test_df)
        assert_frame_equal(result, expected_df)

    def test_nan_temperatures(self):
        self.test_df = self.test_df.assign(temperature=np.nan)

        result = process_tappings_temperatures(self.test_df)
        self.assertTrue(result.empty)
        self.assertListEqual(result.columns.tolist(), ["phase", "temperature"])

    def test_empty_dataframe(self):
        test_df = pd.DataFrame(columns=["phase", "temperature"])

        result = process_tappings_temperatures(test_df)
        self.assertTrue(result.empty)
        self.assertListEqual(result.columns.tolist(), ["phase", "temperature"])


class FakePiClient:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Gap.Phase" in url:
            return {
                "Items": [
                    {"Timestamp": "2022-10-01T01:25:45Z", "Value": 1, "Good": True},
                    {"Timestamp": "2022-10-01T02:03:38Z", "Value": 2, "Good": True},
                    {"Timestamp": "2022-10-01T05:01:06Z", "Value": 0, "Good": True},
                    {"Timestamp": "2022-10-01T05:27:18Z", "Value": 1, "Good": True},
                    {"Timestamp": "2022-10-01T06:03:25Z", "Value": 2, "Good": True},
                    {"Timestamp": "2022-10-01T07:11:32Z", "Value": 0, "Good": True},
                    {"Timestamp": "2022-10-01T08:06:51Z", "Value": 1, "Good": True},
                ]
            }
        if "SK1.HotMetal.Temp.MeasDevice.C" in url:
            return {
                "Items": [
                    {"Timestamp": "2022-10-01T01:30:24Z", "Value": 1454.0, "Good": True},
                    {"Timestamp": "2022-10-01T01:51:28Z", "Value": 1444.0, "Good": True},
                    {"Timestamp": "2022-10-01T04:52:56Z", "Value": 1382.0, "Good": True},
                    {"Timestamp": "2022-10-01T05:11:08Z", "Value": 1408.0, "Good": True},
                    {"Timestamp": "2022-10-01T05:36:25Z", "Value": 1418.0, "Good": True},
                    {"Timestamp": "2022-10-01T08:24:32Z", "Value": 1442.0, "Good": True},
                    {"Timestamp": "2022-10-01T08:46:51Z", "Value": 1455.0, "Good": True},
                ]
            }
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestHotmetalTemperatureDataLoading(unittest.TestCase):
    def test_data_loading(self):
        fake_pi_client = FakePiClient()

        actual_df = load_hotmetal_temps(
            start=pd.Timestamp(2022, 10, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2022, 10, 1, 9, 0, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )
        self.assertListEqual(
            actual_df.columns.tolist(),
            [
                "bf1_hotmetal_temp_C",
                "bf1_hotmetalcorrected_temp_C",
                "bf1_hotmetalafterslag_temp_C",
            ],
        )
        self.assertIsInstance(actual_df.index, pd.DatetimeIndex)
        self.assertTrue(actual_df.index.is_unique)
        pd.testing.assert_index_equal(actual_df.index, actual_df.index.sort_values())


class FakePiClientEmpty:
    def __init__(self):
        pass

    def get_request(self, url: str, params: Optional[dict] = None) -> dict:
        if "SK1.Gap.Phase" in url:
            return {"Items": []}
        if "SK1.HotMetal.Temp.MeasDevice.C" in url:
            return {"Items": [{"Timestamp": "2022-10-01T01:30:24Z", "Value": 1454.0, "Good": True}]}
        return {"Items": []}

    def webid_by_path(self, name: str) -> str:
        return name


class TestHotmetalTemperatureDataLoadingWithEmptyClient(unittest.TestCase):
    def test_data_loading_with_empty_client(self):
        fake_pi_client = FakePiClientEmpty()

        actual_df = load_hotmetal_temps(
            start=pd.Timestamp(2022, 10, 1, 0, 0, 0, tzinfo=pytz.UTC),
            end=pd.Timestamp(2022, 10, 1, 2, 0, 0, tzinfo=pytz.UTC),
            furnace_id=1,
            pi_client=fake_pi_client,  # type: ignore
        )
        self.assertListEqual(
            actual_df.columns.tolist(),
            [
                "bf1_hotmetal_temp_C",
                "bf1_hotmetalcorrected_temp_C",
                "bf1_hotmetalafterslag_temp_C",
            ],
        )
        self.assertTrue(actual_df.bf1_hotmetalafterslag_temp_C.isnull().all())


if __name__ == "__main__":
    unittest.main()
