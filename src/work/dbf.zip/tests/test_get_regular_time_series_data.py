import unittest

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal, assert_series_equal

from dbfcore.dataset.signals.utils import (
    get_conditional_interpolate_df,
    get_conditional_interpolate_series,
    get_regular_time_series_data,
)


class TestGetRegularTimeSeriesData(unittest.TestCase):
    def test_get_regular_time_series_data(self):
        expected_df = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:05:00+00:00"),
                    pd.Timestamp("2025-03-06 01:05:01+00:00"),
                    pd.Timestamp("2025-03-06 01:05:02+00:00"),
                    pd.Timestamp("2025-03-06 01:05:03+00:00"),
                    pd.Timestamp("2025-03-06 01:05:04+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05+00:00"),
                    pd.Timestamp("2025-03-06 01:05:06+00:00"),
                    pd.Timestamp("2025-03-06 01:05:07+00:00"),
                    pd.Timestamp("2025-03-06 01:05:08+00:00"),
                    pd.Timestamp("2025-03-06 01:05:09+00:00"),
                    pd.Timestamp("2025-03-06 01:05:10+00:00"),
                    pd.Timestamp("2025-03-06 01:05:11+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                1150.0,
                1184.0,
                1218.0,
                1252.0,
                1286.0,
                1320.0,
                1330.0,
                1340.0,
                1350.0,
                1360.0,
                1370.0,
                1380.0,
                1390.0,
            ],
            columns=["value"],
        )
        # Infer the frequency of the index from the data.
        expected_df = expected_df.asfreq(pd.infer_freq(expected_df.index))

        irregular_time_series_data = pd.DataFrame(
            index=pd.Series(
                [
                    pd.Timestamp("2025-03-06 01:05:00.062011700+00:00"),
                    pd.Timestamp("2025-03-06 01:05:05.050003+00:00"),
                    pd.Timestamp("2025-03-06 01:05:12.558013900+00:00"),
                ],
                name="Timestamp",
            ),
            data=[
                1150,
                1320,
                1390,
            ],
            columns=["value"],
        )

        result_df = get_regular_time_series_data(irregular_time_series_data)
        time_diffs = result_df.index.to_series().diff().dropna()

        # Check if the DataFrame matches the expected output
        assert_frame_equal(expected_df, result_df)

        # Check if the resulting DataFrame has a regular time interval
        self.assertEqual(time_diffs.nunique(), 1)

        # Check if the value differences match expectations
        value_diffs = result_df.iloc[:, 0].diff().dropna()
        expected_value_diffs = pd.Series(
            [34.0] * 5 + [10.0] * 7,  # 34 per step for first segment, 10 per step for second segment
            index=result_df.index[1:],
            name=result_df.columns[0],
        )

        assert_series_equal(value_diffs, expected_value_diffs)


class TestGetConditionalInterpolateSeries(unittest.TestCase):
    def setUp(self):
        self.df_sec = pd.DataFrame(
            {
                "column_A": [
                    1150.0,
                    np.NaN,
                    1218.0,
                    np.NaN,
                    np.NaN,
                    1320.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    1380.0,
                    1390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:05:01+00:00",
                    "2025-03-06 01:05:02+00:00",
                    "2025-03-06 01:05:03+00:00",
                    "2025-03-06 01:05:04+00:00",
                    "2025-03-06 01:05:05+00:00",
                    "2025-03-06 01:05:06+00:00",
                    "2025-03-06 01:05:07+00:00",
                    "2025-03-06 01:05:08+00:00",
                    "2025-03-06 01:05:09+00:00",
                    "2025-03-06 01:05:10+00:00",
                    "2025-03-06 01:05:11+00:00",
                    "2025-03-06 01:05:12+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_min = pd.DataFrame(
            {
                "column_A": [
                    150.0,
                    np.NaN,
                    218.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    330.0,
                    340.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:06:00+00:00",
                    "2025-03-06 01:07:00+00:00",
                    "2025-03-06 01:08:00+00:00",
                    "2025-03-06 01:09:00+00:00",
                    "2025-03-06 01:10:00+00:00",
                    "2025-03-06 01:11:00+00:00",
                    "2025-03-06 01:12:00+00:00",
                    "2025-03-06 01:13:00+00:00",
                    "2025-03-06 01:14:00+00:00",
                    "2025-03-06 01:15:00+00:00",
                    "2025-03-06 01:16:00+00:00",
                    "2025-03-06 01:17:00+00:00",
                ],
                format="mixed",
            ),
        )

    def test_get_conditional_interpolate_series_4sec(self):
        expected = pd.DataFrame(
            {
                "column_A": [
                    1150.0,
                    1184.0,
                    1218.0,
                    1252.0,
                    1286.0,
                    1320.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    1380.0,
                    1390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:05:01+00:00",
                    "2025-03-06 01:05:02+00:00",
                    "2025-03-06 01:05:03+00:00",
                    "2025-03-06 01:05:04+00:00",
                    "2025-03-06 01:05:05+00:00",
                    "2025-03-06 01:05:06+00:00",
                    "2025-03-06 01:05:07+00:00",
                    "2025-03-06 01:05:08+00:00",
                    "2025-03-06 01:05:09+00:00",
                    "2025-03-06 01:05:10+00:00",
                    "2025-03-06 01:05:11+00:00",
                    "2025-03-06 01:05:12+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_conditional_interpolate_series(
            self.df_sec[self.df_sec.columns[0]], "linear", pd.Timedelta("4s")
        ).to_frame(name="column_A")
        pd.testing.assert_frame_equal(result, expected)

    def test_get_conditional_interpolate_series_3min(self):
        expected = pd.DataFrame(
            {
                "column_A": [
                    150.0,
                    184.0,
                    218.0,
                    246.0,
                    274.0,
                    302.0,
                    330.0,
                    340.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:06:00+00:00",
                    "2025-03-06 01:07:00+00:00",
                    "2025-03-06 01:08:00+00:00",
                    "2025-03-06 01:09:00+00:00",
                    "2025-03-06 01:10:00+00:00",
                    "2025-03-06 01:11:00+00:00",
                    "2025-03-06 01:12:00+00:00",
                    "2025-03-06 01:13:00+00:00",
                    "2025-03-06 01:14:00+00:00",
                    "2025-03-06 01:15:00+00:00",
                    "2025-03-06 01:16:00+00:00",
                    "2025-03-06 01:17:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_conditional_interpolate_series(
            self.df_min[self.df_min.columns[0]], "linear", pd.Timedelta("3min")
        ).to_frame(name="column_A")
        pd.testing.assert_frame_equal(result, expected)


class TestGetConditionalInterpolateDf(unittest.TestCase):
    def setUp(self):
        self.df_sec = pd.DataFrame(
            {
                "column_A": [
                    1150.0,
                    1184.0,
                    1218.0,
                    1252.0,
                    1286.0,
                    1320.0,
                    1330.0,
                    1340.0,
                    1350.0,
                    1360.0,
                    1370.0,
                    1380.0,
                    1390.0,
                ],
                "column_B": [
                    1150.0,
                    np.NaN,
                    1218.0,
                    np.NaN,
                    np.NaN,
                    1320.0,
                    1330.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    1370.0,
                    1380.0,
                    1390.0,
                ],
                "column_C": [
                    1150.0,
                    np.NaN,
                    1218.0,
                    np.NaN,
                    np.NaN,
                    1320.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    1380.0,
                    1390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:05:01+00:00",
                    "2025-03-06 01:05:02+00:00",
                    "2025-03-06 01:05:03+00:00",
                    "2025-03-06 01:05:04+00:00",
                    "2025-03-06 01:05:05+00:00",
                    "2025-03-06 01:05:06+00:00",
                    "2025-03-06 01:05:07+00:00",
                    "2025-03-06 01:05:08+00:00",
                    "2025-03-06 01:05:09+00:00",
                    "2025-03-06 01:05:10+00:00",
                    "2025-03-06 01:05:11+00:00",
                    "2025-03-06 01:05:12+00:00",
                ],
                format="mixed",
            ),
        )
        self.df_min = pd.DataFrame(
            {
                "column_A": [
                    150.0,
                    184.0,
                    218.0,
                    252.0,
                    286.0,
                    320.0,
                    330.0,
                    340.0,
                    350.0,
                    360.0,
                    370.0,
                    380.0,
                    390.0,
                ],
                "column_B": [
                    150.0,
                    np.NaN,
                    218.0,
                    np.NaN,
                    np.NaN,
                    320.0,
                    330.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    370.0,
                    380.0,
                    390.0,
                ],
                "column_C": [
                    150.0,
                    np.NaN,
                    218.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    330.0,
                    340.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:06:00+00:00",
                    "2025-03-06 01:07:00+00:00",
                    "2025-03-06 01:08:00+00:00",
                    "2025-03-06 01:09:00+00:00",
                    "2025-03-06 01:10:00+00:00",
                    "2025-03-06 01:11:00+00:00",
                    "2025-03-06 01:12:00+00:00",
                    "2025-03-06 01:13:00+00:00",
                    "2025-03-06 01:14:00+00:00",
                    "2025-03-06 01:15:00+00:00",
                    "2025-03-06 01:16:00+00:00",
                    "2025-03-06 01:17:00+00:00",
                ],
                format="mixed",
            ),
        )

    def test_get_conditional_interpolate_df_4sec(self):
        expected = pd.DataFrame(
            {
                "column_A": [
                    1150.0,
                    1184.0,
                    1218.0,
                    1252.0,
                    1286.0,
                    1320.0,
                    1330.0,
                    1340.0,
                    1350.0,
                    1360.0,
                    1370.0,
                    1380.0,
                    1390.0,
                ],
                "column_B": [
                    1150.0,
                    1184.0,
                    1218.0,
                    1252.0,
                    1286.0,
                    1320.0,
                    1330.0,
                    1340.0,
                    1350.0,
                    1360.0,
                    1370.0,
                    1380.0,
                    1390.0,
                ],
                "column_C": [
                    1150.0,
                    1184.0,
                    1218.0,
                    1252.0,
                    1286.0,
                    1320.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    1380.0,
                    1390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:05:01+00:00",
                    "2025-03-06 01:05:02+00:00",
                    "2025-03-06 01:05:03+00:00",
                    "2025-03-06 01:05:04+00:00",
                    "2025-03-06 01:05:05+00:00",
                    "2025-03-06 01:05:06+00:00",
                    "2025-03-06 01:05:07+00:00",
                    "2025-03-06 01:05:08+00:00",
                    "2025-03-06 01:05:09+00:00",
                    "2025-03-06 01:05:10+00:00",
                    "2025-03-06 01:05:11+00:00",
                    "2025-03-06 01:05:12+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_conditional_interpolate_df(self.df_sec, "linear", pd.Timedelta("4s"))
        pd.testing.assert_frame_equal(result, expected)

    def test_get_conditional_interpolate_df_3min(self):
        expected = pd.DataFrame(
            {
                "column_A": [
                    150.0,
                    184.0,
                    218.0,
                    252.0,
                    286.0,
                    320.0,
                    330.0,
                    340.0,
                    350.0,
                    360.0,
                    370.0,
                    380.0,
                    390.0,
                ],
                "column_B": [
                    150.0,
                    184.0,
                    218.0,
                    252.0,
                    286.0,
                    320.0,
                    330.0,
                    340.0,
                    350.0,
                    360.0,
                    370.0,
                    380.0,
                    390.0,
                ],
                "column_C": [
                    150.0,
                    184.0,
                    218.0,
                    246.0,
                    274.0,
                    302.0,
                    330.0,
                    340.0,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    np.NaN,
                    390.0,
                ],
            },
            index=pd.to_datetime(
                [
                    "2025-03-06 01:05:00+00:00",
                    "2025-03-06 01:06:00+00:00",
                    "2025-03-06 01:07:00+00:00",
                    "2025-03-06 01:08:00+00:00",
                    "2025-03-06 01:09:00+00:00",
                    "2025-03-06 01:10:00+00:00",
                    "2025-03-06 01:11:00+00:00",
                    "2025-03-06 01:12:00+00:00",
                    "2025-03-06 01:13:00+00:00",
                    "2025-03-06 01:14:00+00:00",
                    "2025-03-06 01:15:00+00:00",
                    "2025-03-06 01:16:00+00:00",
                    "2025-03-06 01:17:00+00:00",
                ],
                format="mixed",
            ),
        )
        result = get_conditional_interpolate_df(self.df_min, "linear", pd.Timedelta("3min"))
        pd.testing.assert_frame_equal(result, expected)
