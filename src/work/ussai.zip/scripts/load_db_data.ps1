# TODO select date, at the moment, script uses the latest file available

# usage load_db_data.ps1 test/prod
$env_type = $args[0]

# this script is intended to be used with local sqlite db only
$env:USE_DB="local"
$path7z = "C:\Program Files\7-Zip\7z.exe"
$backup_dir = "\\vbofkd\VIU\DB"
$project_dir = Split-Path -Path $pwd.Path
$tmp_dir = Join-Path $project_dir "tmp_scrap_load_data_dir"
$frontend_dir = Join-Path $project_dir "frontend"
$target_db = Join-Path $frontend_dir "db.sqlite3"

if ($env_type -eq "test") {
    $db_archive = Get-ChildItem "${backup_dir}\*" -Include *test* | Sort-Object -Descending -Property LastWriteTime | Select -First 1
} else {
    $db_archive = Get-ChildItem "${backup_dir}\*" -Exclude *test* | Sort-Object -Descending -Property LastWriteTime | Select -First 1
}

$db_archive_name = $db_archive.Name
$db_archive_path = Join-Path $backup_dir $db_archive_name

New-Item -Path $tmp_dir -ItemType Directory | Out-Null
Write-Output "Temporary directory ${tmp_dir} created"

Copy-Item -Path $db_archive_path -Destination $tmp_dir
Write-Output "File ${db_archive_name} copied to temporary directory"

&$path7z x (Join-Path $tmp_dir $db_archive_name) "-o$tmp_dir" -y

$db_json_path = Get-ChildItem -Path $tmp_dir -Force -Recurse -File | Select-Object -First 1

# remove .test extension if needed
Copy-Item -Path (Join-Path $tmp_dir $db_json_path.name) -Destination (Join-Path $tmp_dir "db_backup.json")
$db_json_path = Join-Path $tmp_dir "db_backup.json"

if (Test-Path $target_db) {
# TODO archive instead of remove
  Remove-Item $target_db
  Write-Output "${target_db} removed"
}

$manage_path = Join-Path $frontend_dir "manage.py"

Invoke-Expression "conda activate viu_win"
Write-Output "Environment viu_win activated"

Write-Output "Migrating database ..."
Invoke-Expression "python ${manage_path} migrate"

Write-Output "Flushing database ..."
Invoke-Expression "python ${manage_path} flush --noinput"

Write-Output "Loading data ..."
Invoke-Expression "python ${manage_path} loaddata ${db_json_path}"

Invoke-Expression "conda deactivate"
Write-Output "Environment viu_win deactivated"

rm -R $tmp_dir
Write-Output "Temporary directory ${tmp_dir} removed"
