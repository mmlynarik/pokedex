conda run -n viu python manage.py migrate --fake scrap zero
echo "Fake-rollback of all migrations successful"

rm -r /source/scrap/migrations/*
echo "All migrations deleted"

# recreate __init__.py file
touch /source/scrap/migrations/__init__.py

conda run -n viu python manage.py makemigrations scrap
echo "New migration created"

conda run -n viu python manage.py migrate --fake-initial
echo "New migration fake-applied"
