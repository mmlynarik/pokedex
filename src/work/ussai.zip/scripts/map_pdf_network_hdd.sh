#!/bin/bash

# Mounting script to map windows share folder to local folder. Script is checking input
# variables and sets PDF_SHARED_MOUNT_SUCCESSFUL env variable with result of the operation
# launch script as: source map_pdf_network_hdd.sh && python app.py to make env variable
# available in python script

WINDOWS_SHARE_URL=$WIN_PDF_SHARED_FOLDER
MOUNT_POINT=$PDF_UPLOAD_FOLDER
USERNAME=$OKO_DB_USER
PASSWORD=$OKO_DB_PASSWORD

if [ -z "$WINDOWS_SHARE_URL" ] || [ -z "$MOUNT_POINT" ] || [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]
then
        echo Windows share folder will not be mounted due to missing data. Check provided data and password:
        echo WINDOWS_SHARE_URL: $WINDOWS_SHARE_URL
        echo MOUNT_POINT: $MOUNT_POINT
        echo USERNAME: $USERNAME
        export PDF_SHARED_MOUNT_SUCCESSFUL=0
        return
fi

# strip SK domain from AD account, mount command will not accept domain in account
if [[ "${USERNAME^^}" == "SK\\"* ]]
then
        USERNAME=$(echo $USERNAME | cut -d '\' -f2)
fi

if [ ! -d "$MOUNT_POINT" ]
then
        echo Mount point folder does not exist, creating path $MOUNT_POINT
        mkdir -p $MOUNT_POINT
fi

echo Mounting $WINDOWS_SHARE_URL to $MOUNT_POINT with $USERNAME account...

if mount -t cifs $WINDOWS_SHARE_URL $MOUNT_POINT -o user=$USERNAME,password=$PASSWORD,dir_mode=0777,file_mode=0777;
then
        echo Mount successful
        export PDF_SHARED_MOUNT_SUCCESSFUL=1
else
        echo Mount failed
        export PDF_SHARED_MOUNT_SUCCESSFUL=0
fi
