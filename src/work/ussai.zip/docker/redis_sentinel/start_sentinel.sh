#!/bin/bash

sed -i "s/\$REDIS_PASSWORD/$REDIS_PASSWORD/g" /redis/sentinel.conf
sed -i "s/\$REDIS_MASTER_HOST/$REDIS_MASTER_HOST/g" /redis/sentinel.conf
sed -i "s/\$REDIS_MASTER_PORT/$REDIS_MASTER_PORT/g" /redis/sentinel.conf
sed -i "s/\$SENTINEL_ANNOUNCE_IP/$SENTINEL_ANNOUNCE_IP/g" /redis/sentinel.conf

redis-server /redis/sentinel.conf --sentinel