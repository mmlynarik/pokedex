#!/bin/bash

sed -i "s/\$REDIS_PASSWORD/$REDIS_PASSWORD/g" /redis/redis.conf

docker-entrypoint.sh /redis/redis.conf --slaveof $REDIS_MASTER_HOST $REDIS_MASTER_PORT