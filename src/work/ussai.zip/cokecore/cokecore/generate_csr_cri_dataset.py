import argparse
import os.path
from datetime import date, datetime, timedelta
from typing import Tuple

import jsonlines
from tqdm.auto import tqdm

from .datamodel.model import coke_converter
from .datamodel.vis_hook import VisCokeHook, VIS_COKE_CONFIG

# Coal samples for CSR/CRI analysis were taken as follows
# dt < DT_A | DT_A <= dt < DT_B | DT_B <= dt
# every day | every workday     | on Wednesday and Friday only
DT_A = date(2006, 2, 5)
DT_B = date(2019, 9, 11)


def parse_args():
    parser = argparse.ArgumentParser(description="Generate blendmodel training data")
    parser.add_argument(
        "-s",
        "--start_date",
        help="The Start Date - format YYYY-MM-DD",
        required=True,
        type=lambda s: datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-e",
        "--end_date",
        help="The End Date format YYYY-MM-DD",
        required=True,
        type=lambda s: datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-p",
        "--password",
        help="Password for database connection",
        required=True,
        type=str,
    )

    return parser.parse_args()


# TODO add ability to recover from script interruption
def dump_coal_and_coke_data(dt_from: date, dt_to: date, vis_password: str) -> Tuple[str, str]:
    vis_hook = VisCokeHook({**VIS_COKE_CONFIG, "pass": vis_password})
    output_path = f"./csr_cri_dataset_{dt_from:%Y_%m_%d}_{dt_to:%Y_%m_%d}.jsonl"
    error_path = f"./csr_cri_errors_{dt_from:%Y_%m_%d}_{dt_to:%Y_%m_%d}.jsonl"

    coke_analyses = vis_hook.get_coke_analyses(dt_from, dt_to)

    with jsonlines.open(output_path, mode="w") as output, jsonlines.open(error_path, mode="w") as errors:
        for analysis in tqdm(sorted(coke_analyses, key=lambda item: item.shift.date)):
            try:
                # TODO redirect invalid analysis to errors file as in `generate_blendmodel_training_data` script
                if analysis.shift.code != 0:
                    print(f"Analyses from shift different from 0 are not supported yet - {analysis}")
                    continue

                if analysis.shift.date < DT_A:
                    # Before 2006-02-05 regular samples were evaluated every day
                    # from samples taken a day before (TODO check that this assumption is correct)
                    coal_data_1 = vis_hook.get_battery_status(
                        analysis.shift.date - timedelta(days=1), charge_shift=1, battery=analysis.battery
                    )
                    coal_data_2 = None

                elif analysis.shift.date < DT_B:
                    # Before 2019-09-11 regular samples were evaluated every workday
                    # from samples taken a day before (TODO check that this assumption is correct)
                    if analysis.shift.date.weekday() > 4:
                        print(f"Weekend analyses between {DT_A} and {DT_B} are not supported - {analysis}")
                        continue

                    coal_data_1 = vis_hook.get_battery_status(
                        analysis.shift.date - timedelta(days=1), charge_shift=1, battery=analysis.battery
                    )
                    coal_data_2 = None

                else:
                    # Since 2019-09-11 samples have been evaluated on Wednesday and Friday only
                    # from samples taken 1 and 2 days before
                    if analysis.shift.date.weekday() not in {2, 4}:
                        print(
                            f"After {DT_B} only analyses from Wednesday or Friday are supported - {analysis}"
                        )
                        continue

                    coal_data_1 = vis_hook.get_battery_status(
                        analysis.shift.date - timedelta(days=1), charge_shift=1, battery=analysis.battery
                    )
                    coal_data_2 = vis_hook.get_battery_status(
                        analysis.shift.date - timedelta(days=2), charge_shift=1, battery=analysis.battery
                    )
                output.write(
                    {
                        "analysis": coke_converter.unstructure(analysis),
                        "coal_data_1": coke_converter.unstructure(coal_data_1),  # yesterday sample
                        "coal_data_2": coke_converter.unstructure(
                            coal_data_2
                        ),  # the day before yesterday sample
                    }
                )
            except Exception as e:  # pylint:disable=broad-except
                errors.write(
                    {
                        "analysis": coke_converter.unstructure(analysis),
                        "error": str(e),
                    }
                )

    return output_path, error_path


def main():
    args = parse_args()
    output_path, error_path = dump_coal_and_coke_data(args.start_date, args.end_date, args.password)
    print(f"CSR CRI dataset dumped to file {os.path.abspath(output_path)}")
    print(f"CSR CRI errors dumped to file {os.path.abspath(error_path)}")


if __name__ == "__main__":
    main()
