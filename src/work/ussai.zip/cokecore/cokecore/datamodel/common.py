# Everything in this file should be extracted to some common package
# All code here is copied from scrap core package
# List of copied stuff
# from scrap_core.datamodel.generic_hook import OracleHook
# from scrap_core import positive_finite, between
# from scrap_core.datamodel.model import float_or_nan

from math import isfinite
from typing import Any, Optional

import cx_Oracle
from sqlalchemy.engine import create_engine, URL
import numpy as np


class OracleHook:
    def __init__(self, conf):
        self.__url = URL.create(**conf)
        self.engine = create_engine(self.__url)

    @property
    def host(self):
        return self.__url["host"]  # type: ignore

    @property
    def port(self):
        return self.__url["port"]  # type: ignore


def float_or_nan(val: Optional[float]) -> float:
    return float(val) if val is not None else np.nan


def between(minimum: Any, maximum: Any):
    def validator(full_instance, attribute_type, value):
        if np.isnan(value):
            raise ValueError(f"{full_instance.__class__.__name__}.{attribute_type.name} is missing")
        if value < minimum:
            raise ValueError(
                f"{full_instance.__class__.__name__}.{attribute_type.name} is {value} "
                f"but it must be larger or equal than {minimum}"
            )
        if value > maximum:
            raise ValueError(
                f"{full_instance.__class__.__name__}.{attribute_type.name} is {value} "
                f"but it must be smaller or equal than {maximum}"
            )

    return validator


def positive_finite(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    if np.isnan(value):
        raise ValueError(f"{full_instance.__class__.__name__}.{attribute_type.name} is missing")
    if not isfinite(value):
        raise ValueError(f"{full_instance.__class__.__name__}.{attribute_type.name} is not finite")
    if value < 0.0:
        raise ValueError(f"{full_instance.__class__.__name__}.{attribute_type.name} is negative")


def positive_finite_or_nan(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    if np.isnan(value):
        return

    positive_finite(full_instance, attribute_type, value)
