from datetime import date
from enum import Enum
from typing import Any, Optional, Tuple

import attr
import cattr

from .common import between, float_or_nan, positive_finite, positive_finite_or_nan

BATTERY_NAMES = {1: "VKB1", 3: "VKB3"}
BATTERY_CODES = {"VKB1": 1, "VKB3": 3}

coke_converter = cattr.Converter()


def to_isoformat(date: date) -> str:
    return date.isoformat()


def from_isoformat(dt_string: str, _: Any) -> date:
    return date.fromisoformat(dt_string)


coke_converter.register_unstructure_hook(date, to_isoformat)
coke_converter.register_structure_hook(date, from_isoformat)


class CoalKind(Enum):
    TECHCOKE = "techcoke"
    TECHRICH = "techrich"
    TECHGAS = "techgas"
    TECHMIX = "techmix"
    ADDITIVE = "additive"
    BF = "bf"
    ENERGY = "energy"


def coal_kind_parser(general_type: str, tech_type: str) -> CoalKind:
    if general_type == "TG":
        if tech_type == "UK":
            return CoalKind.TECHCOKE
        if tech_type == "UZ":
            return CoalKind.TECHRICH
        if tech_type == "UP":
            return CoalKind.TECHGAS
        if tech_type == "UM":
            return CoalKind.TECHMIX
        if tech_type == "PM":
            return CoalKind.ADDITIVE
    if general_type == "EU":
        return CoalKind.ENERGY
    if general_type == "VP":
        return CoalKind.BF
    raise Exception(f"Invalid coal types - {general_type}, {tech_type}")


@attr.s(slots=True, frozen=True)
class CoalType:
    coal_id: str = attr.ib()
    coal_kind: CoalKind = attr.ib()
    mine_id: str = attr.ib()
    name: str = attr.ib()


@attr.s(slots=True, frozen=True)
class CoalAnalysis:
    total_h2o: float = attr.ib(converter=float_or_nan)
    ash: float = attr.ib(converter=float_or_nan)
    volatile_matter: float = attr.ib(converter=float_or_nan)
    sulphur: float = attr.ib(converter=float_or_nan)
    phosphorus: float = attr.ib(converter=float_or_nan)
    swelling_index: float = attr.ib(converter=float_or_nan)
    dilatation: float = attr.ib(converter=float_or_nan)
    contraction: float = attr.ib(converter=float_or_nan)
    t1_temp: float = attr.ib(converter=float_or_nan)
    t3_temp: float = attr.ib(converter=float_or_nan)


@attr.s(slots=True, frozen=True)
class CoalAshLabAnalysis:
    ordinal_test_date: int = attr.ib()
    Fe2O3: float = attr.ib(converter=float_or_nan)
    SiO2: float = attr.ib(converter=float_or_nan)
    CaO: float = attr.ib(converter=float_or_nan)
    MgO: float = attr.ib(converter=float_or_nan)
    Na2O: float = attr.ib(converter=float_or_nan)
    K20: float = attr.ib(converter=float_or_nan)
    Mn: float = attr.ib(converter=float_or_nan)
    P: float = attr.ib(converter=float_or_nan)
    Pb: float = attr.ib(converter=float_or_nan)
    Zn: float = attr.ib(converter=float_or_nan)
    TiO2: float = attr.ib(converter=float_or_nan)

    @property
    def test_date(self):
        return date.fromordinal(self.ordinal_test_date)


@attr.s(slots=True, frozen=True)
class Coal:
    coal_type: CoalType = attr.ib()
    ordinal_expedition_date: int = attr.ib()
    chem_analyses: Tuple[CoalAnalysis, ...] = attr.ib()
    ash_lab_analysis: Optional[CoalAshLabAnalysis] = attr.ib()

    @property
    def expedition_date(self):
        return date.fromordinal(self.ordinal_expedition_date)


@attr.s(slots=True, frozen=True)
class CoalWeight:
    coal: Coal = attr.ib()
    weight: float = attr.ib(converter=float, validator=[positive_finite])


# Percentages -> sum should be 100
@attr.s(slots=True, frozen=True)
class MaceralAnalysis:
    inertinite: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    vitrinite: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    liptinite: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])


# Percentages -> sum should be 100
@attr.s(slots=True, frozen=True)
class CoalTypeAnalysis:
    flame: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    gas: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    rich: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    coke_rich: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    coke_a: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    coke_b: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    semi_anthracite: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])
    stone: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])


@attr.s(slots=True, frozen=True)
class PlasticityAnalysis:
    pt1_temp: float = attr.ib(converter=float_or_nan, validator=[positive_finite_or_nan])
    pt3_temp: float = attr.ib(converter=float_or_nan, validator=[positive_finite_or_nan])
    max_plasticity_temp: float = attr.ib(converter=float_or_nan, validator=[positive_finite_or_nan])
    max_plasticity_rpm: float = attr.ib(converter=float_or_nan, validator=[positive_finite_or_nan])


@attr.s(slots=True, frozen=True)
class CoalHeap:
    heap_id: int = attr.ib()
    maceral_analysis: MaceralAnalysis = attr.ib()
    coal_type_analysis: CoalTypeAnalysis = attr.ib()
    plasticity_analysis: PlasticityAnalysis = attr.ib()
    reflectance_index: float = attr.ib(converter=float_or_nan, validator=[positive_finite])
    coals: Tuple[CoalWeight, ...] = attr.ib(default=())

    @property
    def total_weight(self):
        return sum([x.weight for x in self.coals])


@attr.s(slots=True, frozen=True)
class HeapRatio:
    heap: CoalHeap = attr.ib()
    ratio: float = attr.ib(converter=float_or_nan, validator=[between(0, 1)])


@attr.s(slots=True, frozen=True)
class CoalCharge:
    heaps: Tuple[HeapRatio, ...] = attr.ib(converter=tuple)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class CokeShift:
    date: date
    code: int


@attr.s(slots=True, frozen=True)
class BlockTemperature:
    min_temp: float = attr.ib(converter=float_or_nan)
    max_temp: float = attr.ib(converter=float_or_nan)
    mean_temp_block_a_machine_side: float = attr.ib(converter=float_or_nan)
    mean_temp_block_a_machine_side_control: float = attr.ib(converter=float_or_nan)
    mean_temp_block_a_coke_side: float = attr.ib(converter=float_or_nan)
    mean_temp_block_a_coke_side_control: float = attr.ib(converter=float_or_nan)
    mean_temp_block_b_machine_side: float = attr.ib(converter=float_or_nan)
    mean_temp_block_b_machine_side_control: float = attr.ib(converter=float_or_nan)
    mean_temp_block_b_coke_side: float = attr.ib(converter=float_or_nan)
    mean_temp_block_b_coke_side_control: float = attr.ib(converter=float_or_nan)
    uniformity_coef: float = attr.ib(converter=float_or_nan)
    uniformity_coef_control: float = attr.ib(converter=float_or_nan)


# TODO think about separate module for coke data
@attr.s(auto_attribs=True, slots=True, frozen=True)
class CokeAnalysis:
    battery: int
    shift: CokeShift
    sample_num: int
    csr: float
    cri: float


@attr.s(slots=True, frozen=True)
class CokingTime:
    mean: float = attr.ib(converter=float_or_nan)
    min: float = attr.ib(converter=float_or_nan)
    max: float = attr.ib(converter=float_or_nan)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class BatteryStatus:
    battery: int
    shift: CokeShift
    charge: CoalCharge
    temperature: BlockTemperature
    coking_time: CokingTime
