import re
from datetime import date, timedelta
from typing import Tuple, Set, Optional

import pandas as pd
from methodtools import lru_cache

from .common import OracleHook
from .model import (
    BATTERY_CODES,
    BATTERY_NAMES,
    Coal,
    CoalAnalysis,
    CoalAshLabAnalysis,
    CoalCharge,
    CoalHeap,
    CoalType,
    CoalTypeAnalysis,
    CoalWeight,
    CokeAnalysis,
    HeapRatio,
    MaceralAnalysis,
    PlasticityAnalysis,
    coal_kind_parser,
    CokeAnalysis,
    CokeShift,
    BlockTemperature,
    BatteryStatus,
    CokingTime,
)


# TODO this should probably be decorator used on every function that create sql query
# TODO or maybe we should use some lib that does this sql query sanitation better
def check_input(input_param):
    if ";" in f"{input_param}":
        raise Exception("Input param to sql query cannot contain ;")


VIS_COKE_CONFIG = {
    "host": "pvis-t.dbs.usske.sk",
    "port": 1521,
    "sid": "PVIS",
    "user": "prenos_digidata",
    "pass": "************",
}


# TODO improve parameter handling - e.g. see `__read_data` and `get_coke_analyses` methods below
class VisCokeHook(OracleHook):
    def __read_data(self, query: str, params: dict) -> pd.DataFrame:
        with self.engine.begin() as conn:
            df_data = pd.read_sql(query, conn, params=params)
        return df_data

    def get_all_coal_ids(self) -> Set[str]:
        query = """
        SELECT DISTINCT
            UHLIE_ID
        FROM
            VIS.UHLIA
        """
        df_data = self.__read_data(query, params={})
        return set(df_data["UHLIE_ID"].to_list())

    @lru_cache()
    def get_coal_ash_lab_analysis(
        self, coal_id: str, expedition_date: date, days_after_limit: int = 30, days_before_limit: int = 30
    ) -> Optional[CoalAshLabAnalysis]:
        # VZORKA_ID is split on whitespace or number to obtain coal_id from the first string.
        # Sometimes the coal_id of type VIRn is composed of strings split by whitespace and requires merging
        # For coal_id of type VIRn, there are cases where roman numerals are used and require conversion
        coal_ids = self.get_all_coal_ids()
        roman_nums = {"II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7, "VIII": 8}
        roman_normalizer = {"VIR" + k: "VIR" + str(v) for k, v in roman_nums.items()}
        normalizer = {**roman_normalizer, **{coal_id: coal_id for coal_id in coal_ids}}

        def extract_coal_id(sample_id):
            return re.split(r"(\d|\s)", sample_id)[0]

        def merge_coal_id(sample_id):
            splits = re.split(r"(\d|\s)", sample_id)
            if splits[0] == "VIR" and splits[2] in roman_nums:
                return splits[0] + splits[2]
            return sample_id

        query_after = """
        SELECT
            v.TEST_DAT, v.POPIS, pl.*
        FROM
            VIS.UKT_VZORKY v
        JOIN
            VIS.UKT_POP_LACH pl
        ON
            v.VZORKA_ID = pl.VZORKA_ID
        AND
            v.ODBER_MIESTO = 'UHL'
        AND
            pl.STANOVENIE_DRUH = 'UHL'
        WHERE
            v.TEST_DAT
        BETWEEN
            :expedition_date
        AND
            :date_after_limit
        """
        df_data_a = self.__read_data(
            query_after,
            params={
                "expedition_date": expedition_date,
                "date_after_limit": expedition_date + timedelta(days=days_after_limit),
            },
        )
        df_data_a["COAL_ID"] = df_data_a["VZORKA_ID"].map(merge_coal_id).map(extract_coal_id).map(normalizer)
        df_ash_a = df_data_a[df_data_a["COAL_ID"] == coal_id]

        if not df_ash_a.empty:
            row = df_ash_a.sort_values("TEST_DAT").iloc[0]
            return CoalAshLabAnalysis(
                row["TEST_DAT"].date().toordinal(),
                row["FE2O3"],
                row["SIO2"],
                row["CAO"],
                row["MGO"],
                row["NA2O"],
                row["K2O"],
                row["MN"],
                row["P"],
                row["PB"],
                row["ZN"],
                row["TIO2"],
            )

        query_before = """
        SELECT
            v.TEST_DAT, v.POPIS, pl.*
        FROM
            VIS.UKT_VZORKY v
        JOIN
            VIS.UKT_POP_LACH pl
        ON
            v.VZORKA_ID = pl.VZORKA_ID
        AND
            v.ODBER_MIESTO = 'UHL'
        AND
            pl.STANOVENIE_DRUH = 'UHL'
        WHERE
            v.TEST_DAT
        BETWEEN
            :date_before_limit
        AND
            :expedition_date
        """
        df_data_b = self.__read_data(
            query_before,
            params={
                "expedition_date": expedition_date,
                "date_before_limit": expedition_date - timedelta(days=days_before_limit),
            },
        )
        df_data_b["COAL_ID"] = df_data_b["VZORKA_ID"].map(merge_coal_id).map(extract_coal_id).map(normalizer)
        df_ash_b = df_data_b[df_data_b["COAL_ID"] == coal_id]

        if not df_ash_b.empty:
            row = df_ash_b.sort_values("TEST_DAT", ascending=False).iloc[0]
            return CoalAshLabAnalysis(
                row["TEST_DAT"].date().toordinal(),
                row["FE2O3"],
                row["SIO2"],
                row["CAO"],
                row["MGO"],
                row["NA2O"],
                row["K2O"],
                row["MN"],
                row["P"],
                row["PB"],
                row["ZN"],
                row["TIO2"],
            )
        else:
            return None

    def load_coal_weights_on_heap(self, heap_id: int) -> Tuple[CoalWeight, ...]:
        query = """
        SELECT
            UHLIE_ID, DATUM_EXPED, MNOZSTVO
        FROM
            vis.UHL_ZAKLADANIE
        WHERE
            HROMADA_ID = :heap_id
        """

        df_data = self.__read_data(query, {"heap_id": heap_id})
        grouped = df_data.groupby(["UHLIE_ID", "DATUM_EXPED"]).sum()
        return tuple(
            CoalWeight(
                coal=Coal(
                    self.get_coal_type_by_id(coal_id),
                    expedition_date.date().toordinal(),
                    self.get_coal_chem_analyses(coal_id, expedition_date.date()),
                    self.get_coal_ash_lab_analysis(coal_id, expedition_date.date()),
                ),
                weight=values["MNOZSTVO"],
            )
            for (coal_id, expedition_date), values in grouped.iterrows()
        )

    @lru_cache()
    def get_coal_heap_by_id(self, heap_id: int) -> CoalHeap:
        query = """
        SELECT
            *
        FROM
            vis.UVS_MACER
        WHERE
            HROMADA_ID = :heap_id
        """

        df_data = self.__read_data(query, {"heap_id": heap_id})
        if len(df_data) == 1:
            row = df_data.iloc[0]
            maceral = MaceralAnalysis(row["INERTINIT"] / 100, row["VITRINIT"] / 100, row["LIPTINIT"] / 100)
            coal_types = CoalTypeAnalysis(
                row["PALAVE"] / 100,
                row["PLYNOVE"] / 100,
                row["ZIRNE"] / 100,
                row["KOKSOVO_ZIRNE"] / 100,
                row["KOKSOVE_A"] / 100,
                row["KOKSOVE_B"] / 100,
                row["ANTRACITOVE"] / 100,
                row["ANTRACIT"] / 100,
            )
            plasticity = PlasticityAnalysis(
                row["TEPLOTA_PT1"],
                row["TEPLOTA_PT3"],
                row["MAX_PLASTICITA_TEPLOTA"],
                row["MAX_PLASTICITA_OTACKY"],
            )
            reflectance = row["INDEX_ODRAZ"]
            return CoalHeap(
                heap_id, maceral, coal_types, plasticity, reflectance, self.load_coal_weights_on_heap(heap_id)
            )
        else:
            # TODO better processing
            raise Exception(f"Cannot load data for coal heap with id: {heap_id}")

    @lru_cache()
    def get_coal_type_by_id(self, coal_id: str) -> CoalType:
        check_input(coal_id)
        query = f"""
        SELECT
            UHLIE_ID, DRUH_ZAV, DRUH_TECH, BANA_ID, NAZOV
        FROM
            vis.UHLIA
        WHERE
            UHLIE_ID='{coal_id}'
        """

        with self.engine.begin() as conn:
            df_data = pd.read_sql(query, conn)

        if len(df_data) == 0:
            raise Exception(f"Unknown coal id {coal_id}")
        if len(df_data) > 1:
            raise Exception(f"Ambigous coal id {coal_id}")
        row = df_data.iloc[0]
        return CoalType(
            row["UHLIE_ID"], coal_kind_parser(row["DRUH_ZAV"], row["DRUH_TECH"]), row["BANA_ID"], row["NAZOV"]
        )

    @lru_cache()
    def get_coal_chem_analyses(self, coal_id: str, expedition_date: date) -> Tuple[CoalAnalysis, ...]:
        check_input(coal_id)
        check_input(expedition_date)
        query = f"""
        SELECT
            *
        FROM
            vis.UHL_LACH
        WHERE
            UHLIE_ID='{coal_id}' AND DATUM_EXPED=TO_DATE('{expedition_date:%Y-%m-%d}', 'yyyy-mm-dd')
        """

        with self.engine.begin() as conn:
            df_data = pd.read_sql(query, conn)

        return tuple(
            CoalAnalysis(
                v["VODA_CELKOVA"],
                v["POPOL"],
                v["PRCH_LATKY"],
                v["SIRA"],
                v["FOSFOR"],
                v["INDEX_PUCHNUTIA"],
                v["DILATACIA"],
                v["KONTRAKCIA"],
                v["TEPLOTA_T1"],
                v["TEPLOTA_T3"],
            )
            for _, v in df_data.iterrows()
        )

    @lru_cache()
    def get_battery_status(self, charge_date: date, charge_shift: int, battery: int) -> BatteryStatus:
        check_input(charge_date)
        check_input(charge_shift)
        check_input(battery)

        battery_name = BATTERY_NAMES[battery]
        query = f"""
        SELECT
            HROMADA_ID, MNOZSTVO
        FROM
            vis.UHL_SPOTREBA
        WHERE
            DATUM=TO_DATE('{charge_date:%Y-%m-%d}', 'yyyy-mm-dd') AND
            ZMENA={charge_shift} AND
            PREVADZKA='{battery_name}'
        """

        with self.engine.begin() as conn:
            df_data = pd.read_sql(query, conn)
            df_data = df_data.groupby("HROMADA_ID").sum()
            df_data["RATIO"] = df_data["MNOZSTVO"] / df_data["MNOZSTVO"].sum()

        shift = CokeShift(date=charge_date, code=charge_shift)

        return BatteryStatus(
            battery=battery,
            shift=shift,
            charge=CoalCharge(
                heaps=[
                    HeapRatio(self.get_coal_heap_by_id(heap_id), row["RATIO"])  # type: ignore
                    for heap_id, row in df_data.iterrows()
                ],
            ),
            temperature=self.get_battery_temperature(battery, shift),
            coking_time=self.get_coking_time(battery, shift),
        )

    def get_coke_analyses(self, dt_from: date, dt_to: date) -> Tuple[CokeAnalysis, ...]:
        query = """
        SELECT
            DATUM,
            PREVADZKA,
            KOKS_FRAKCIA,
            VZORKA_CIS,
            ZMENA,
            CSR,
            CRI
        FROM
            vis.KOKS_CSRI
        WHERE
            datum BETWEEN :dt_from AND :dt_to
        """
        df_data = self.__read_data(query, params={"dt_from": dt_from, "dt_to": dt_to})
        return tuple(
            CokeAnalysis(
                sample_num=record["VZORKA_CIS"],
                battery=BATTERY_CODES[record["PREVADZKA"].upper()],
                shift=CokeShift(date=record["DATUM"].date(), code=record["ZMENA"]),
                csr=record["CSR"],
                cri=record["CRI"],
            )
            for __, record in df_data.iterrows()
        )

    def get_coking_time(self, battery: int, shift: CokeShift) -> CokingTime:
        query = """
        SELECT
            DATUM,
            ZMENA,
            KD_PRM,
            KD_MAX,
            KD_MIN
        FROM
            vis.{battery}_ZMN
        WHERE
            DATUM = :dt
        AND
            ZMENA = :shift
        """
        df_data = self.__read_data(
            query.format(battery=BATTERY_NAMES[battery]),
            params={"dt": shift.date, "shift": shift.code},
        )

        first_record = df_data.iloc[0]

        return CokingTime(
            mean=first_record["KD_PRM"],
            min=first_record["KD_MIN"],
            max=first_record["KD_MAX"],
        )

    def get_battery_temperature(self, battery: int, shift: CokeShift) -> BlockTemperature:
        query = """
        SELECT
            DATUM,
            ZMENA,
            PRT_ASS,
            PRT_AKS,
            PRT_BSS,
            PRT_BKS,
            PRT_ASS_K,
            PRT_AKS_K,
            PRT_BSS_K,
            PRT_BKS_K,
            KV,
            KV_K,
            TEPL_MIN,
            TEPL_MAX
        FROM
            vis.{battery}_ZMN
        WHERE
            DATUM = :dt
        AND
            ZMENA = :shift
        """
        df_block_temp = self.__read_data(
            query.format(battery=BATTERY_NAMES[battery]),
            params={"dt": shift.date, "shift": shift.code},
        )

        first_record = df_block_temp.iloc[0]

        return BlockTemperature(
            min_temp=first_record["TEPL_MIN"],
            max_temp=first_record["TEPL_MAX"],
            mean_temp_block_a_machine_side=first_record["PRT_ASS"],
            mean_temp_block_a_machine_side_control=first_record["PRT_ASS_K"],
            mean_temp_block_a_coke_side=first_record["PRT_AKS"],
            mean_temp_block_a_coke_side_control=first_record["PRT_AKS_K"],
            mean_temp_block_b_machine_side=first_record["PRT_BSS"],
            mean_temp_block_b_machine_side_control=first_record["PRT_BSS_K"],
            mean_temp_block_b_coke_side=first_record["PRT_BKS"],
            mean_temp_block_b_coke_side_control=first_record["PRT_BKS_K"],
            uniformity_coef=first_record["KV"],
            uniformity_coef_control=first_record["KV_K"],
        )
