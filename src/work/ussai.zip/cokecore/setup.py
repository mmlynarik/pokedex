"""A setuptools based setup module.

See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

from os import path

# Always prefer setuptools over distutils
from setuptools import setup

here = path.abspath(path.dirname(__file__))

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="cokecore",
    version="0.0.1",
    package_data={"cokecore": ["py.typed"], "cokecore.datamodel": ["py.typed"]},
    packages=[
        "cokecore",
        "cokecore.datamodel",
    ],
    description="Calculations for coke model",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "attrs==22.2.0",
        "cattrs>=22.1.0",
        "cx_oracle==7.2.3",
        "jsonlines==1.2.0",
        "methodtools==0.4.5",
        "numpy==1.22.1",
        "pandas==1.4.*",
        "tqdm==4.48.2",
    ],
    zip_safe=False,
    entry_points={"console_scripts": ["generate_csr_cri_dataset=cokecore.generate_csr_cri_dataset:main"]},
)
