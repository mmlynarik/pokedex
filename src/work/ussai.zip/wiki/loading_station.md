# Loading station

1. [Introduction](#intro)
2. [Scrap loading](#scrap-loading)
3. [Blend model explainer](#blend-model-explainer)
4. [Appendix - Domain model concepts](#appendix---domain-model-concepts)
    - [Scrap exclusive groups](#scrap-exclusive-groups)
    - [Relaxers](#relaxers)
    - [Worst mode vs best mode](#worst-mode-vs-best-mode)


## Introduction
From the business perspective, loading station refers to the location within a steelshop where scrap is loaded into baskets before being loaded into basic oxygen furnace (BOF) along with pig iron and other components. From the application perspective, the loading stations are represented as follows:

1. As a [webpage (test environment)](http://viu.sk.uss.com:8080/scrap/scrap_loading) aggregating all loading stations, where each loading station instance has the following functionality accessible to users:
    - Scrap loading (Scrap Charge Optimization)
    - Blend model explainer
    - Loaded charges (MS Excel)
    - Loaded baskets
2. As a database table `SCRAP_LOADINGSTATION` in Django BACKEND_DB, where all necessary data related to loading stations are stored. This database table is mirrored in `LoadingStation` Django model class. The relevant field of the model class which contains the actual loading station data is `current_data_v2` of type `LoadingStationDisplayDataV2`. The loading station data effectively consist of two data types - `AvailableScraps` and `ScrapChargeDisplayDataV2`.


## Scrap loading
The webpage of the test environment scrap loading functionality for OC1 is available [here](http://viu.sk.uss.com:8080/scrap/scrap_loading/station/61/v2). As stated above, the two main sections of the webpage are available scraps and scrap charges. The scrap charge optimization functionality is available after entering values into mandatory fields - `basket numbers`, `grade`, `scrap weight` and `pig iron weight`. When the button `Vypočítať vsádzku` (Dash element `CALCULATE_OUTPUT_BUTTON_ID`) is hit, the following sequence of steps is run:

1. Dash input callback function [start_optimization_for_selected_charge](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Ffrontend%2Fscrap%2Fdash%2Fscrap_loading_station_2.py&version=GBmaster&line=1031&lineEnd=1078&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - It's an entrypoint to the scrap charge optimization functionality
    - As all input callbacks operating on application context data, the function receives `data` input parameter of type `ScrapLoadingStationViewModelV2`.
    - The first charge info validation occurs here
    - Relaxable limits and model settings are fetched from loading station Django model. Available scraps and selected scrap charge data are fetched from `data` object

2. The top level function responsible for generating new optimization [optimize_multiple_heats](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Ffrontend%2Fscrap%2Fdash%2Fcomponents%2Fone_heat_optimizer_v2.py&version=GBmaster&line=316&lineEnd=351&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Second level of charge info validation
    - Input data of type `MultipleHeatsOptimizationInput` is generated here
    - Optimization result of type `MultipleHeatsOptimizationResult` is initialized here with input data only and saved into database
    - Primary key of stored optimization result is sent into actor function `multiple_heats_scrap_optimization`

3. Dramatiq actor function [multiple_heats_scrap_optimization](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Ffrontend%2Fscrap%2Ftasks.py&version=GBmaster&line=171&lineEnd=175&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Optimization result is fetched from database
    - The optimization is delegated to function `optimize_multiple_heats_in_current_worker`

4. Progress callback injecting function [optimize_multiple_heats_in_current_worker](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Ffrontend%2Fscrap%2Ftasks.py&version=GBmaster&line=137&lineEnd=144&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Optimization is delegated to function `optimize_multiple_heats` using input data and injected callback

5. First backend function in the call stack [optimize_multiple_heats](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1501&lineEnd=1512&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Active original scrap exclusive groups are fetched here
    - Optimization is delegated to either `optimize_multiple_heats_once` or `optimize_multiple_heats_many` depending on the availability of [active original scrap exclusive groups](#scrap-exclusive-groups)

6. Relaxers initialization function [optimize_multiple_heats_once](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1467&lineEnd=1499&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Final round of scrap charge validation is performed here
    - A sequence of [relaxers](#relaxers) is initialized here - **one-heat**, **relaxable-limits** and **best-mode**
    - Optimization is delegated to function `optimize_with_relaxation` using input data and defined sequence of relaxers
    - Upon return from the `optimize_with_relaxation` function, optimization output is generated using final optimization state. The most important step here is [post-processing](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=708&lineEnd=740&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents), in which the best approximate (i.e. rounded to the predefined `precision_step`) scrap charge is selected that meets the selected quality criteria.

7. Outer layer of optimization loop: until all relaxers are exhausted or valid result is found with [optimize_with_relaxation](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1204&lineEnd=1221&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - First, initial optimization state is fetched using function [get_initial_optimization_state](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1033&lineEnd=1046&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents).
    - Input data and initial optimization state are sent to function `iterative_optimization`

8. Inner layer of optimization loop: until final state is reached with [iterative_optimization](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1098&lineEnd=1122&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents):
    - Final state is reached if chem weight limit values for all chems are not changing too much or number of optimization steps exceeded 100 or best mode is run with one optimization step (best mode uses only one linprog optimization run without iterative optimization with modified chem weight limit values).
    - The next iteration continues with modified optimization state, depending on how the linear `core optimization` has ended - either new better result was found, or a new result was found, but not better than before or no result was found.

9. The linear [core optimization](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1056&lineEnd=1079&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) function:
    - The scipy linprog optimization is performed using
      - worst-mode or best-mode objective function depending on which relaxer has been reached
      - equality constraints representing total scrap weight requirements
      - inequality constraints representing availability, user and summing scrap limits requirements
      - inequality constraints representing chem weight limits determined by the current limits obtained from the optimization state

## Blend model explainer
The webpage of the test environment blend model explainer functionality for OC1 is available [here](http://viu.sk.uss.com:8080/scrap/calculate/61).


## Appendix - Domain model concepts
The followins section describes domain model objects relevant to the description of loading station functionality.
### Scrap exclusive groups
[Scrap exclusive groups](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Fdatamodel.py&version=GBmaster&line=126&lineEnd=173&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents)
are meant to restrict the scrap charge optimization algorithm so that if two or more scrap types are defined as exclusive (being included in an exclusive group), at most one of them can be selected as part
of the scrap charge optimization result. Additionally, in case a specific available scrap mix is forced by the user during optimization, only the scrap type from the exclusive group that is contained
in that forced scrap mix is permitted in the optimization result. This also requires that each available composite scrap mix contains at most one member of the exclusive group. If there is at least one
available composite scrap mix which has at least two members of the exclusive group as its components, this exclusive group is ignored during the optimization run.

There are two logical types of scrap exclusive groups - original and derived. Original exclusive groups are defined by the authorized users in the Django admin or [app settings](http://viu.sk.uss.com:8080/scrap/scrap_loading/station/settings). **Only single scrap mixes (equivalent to scrap types, such as HS, HST, 1PIT, etc.) can be used to define original scrap exclusive groups.** Derived exclusive groups on the other hand are calculated from the original exclusive groups in [get_active_derived_scrap_exclusive_groups()](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1305&lineEnd=1331&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) function and can contain composite scrap mixes.

For each scrap charge optimization run, only so-called active exclusive groups are relevant. Conditions governing the status of the exclusive group are described in the [is_active()](http://vdevops.sk.uss.com/Esten/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Fdatamodel.py&version=GBmaster&line=140&lineEnd=144&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) method.


### Relaxers
[Relaxer](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flimitrelaxation.py&version=GBmaster&line=12&lineEnd=14&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) is a function type defined as `Callable[[MultipleHeatsOptimizationInput], MultipleHeatsOptimizationInput]`, meaning it's purpose is to take optimization input and return it slightly modified so that optimization can proceed further with less strict constraints. During each scrap charge optimization run, we distinguish between three distinct types of relaxers in the following order of application:
- [one_heat_worst_mode_relaxer](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1123&lineEnd=1134&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) -
This relaxer transforms input data to keep only the first heat in the optimization input, meaning all heats in the so-called heat plan loaded from ISPV DB are discarded. **This relaxation is aimed to help optimization algorithm focus on the most important heat in the input data when no valid result could be found for the original input.**

- [relaxable_limits_relaxers](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flimitrelaxation.py&version=GBmaster&line=118&lineEnd=128&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) -
If the first relaxer did not yield the valid result, the next relaxation is applied to relaxable limits, i.e. [risk](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Frelaxable_limits.py&version=GBmaster&line=214&lineEnd=246&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) and [summing limits](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Frelaxable_limits.py&version=GBmaster&line=248&lineEnd=399&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents). Relaxable limits are defined as having `n_steps` (maximum number of permitted relaxations) and `step` (current state) attributes and at least one attribute of type `RelaxableValue`. Relaxable value has two attributes `aim` and `allowed`, which represent targetted and worst permitted value of given limit, respectively. The relaxation of relaxable limit effectively means incrementing value of its attribute `step` by one. The new `step` value affects `relaxation_ratio`, which in turn affects how relaxed value is calculated using `get_relaxed_value()` method. **Relaxation of relaxable limits is aimed to allow the optimization algorithm to use less strict constraints representing weight and risk limits.** The relaxable limits relaxers are implemented as a sequence of relaxers, where either risk or summing limits (or both) are relaxed using a so-called `relaxation_schedule`.

- [best_mode_relaxer](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBmaster&line=1136&lineEnd=1146&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) -
If neither of the two previous types of relaxers yielded valid result, the **"relaxer of last resort"** is applied, which sets the `optimization_mode` to `Best`, which changes optimization objective function to focus on the best possible scrap available rather than the worst as was the case before this relaxer was invoked. The differences between `Worst` and `Best` mode are described [here](#worst-mode-vs-best-mode).


### Worst mode vs best mode
Each optimization run starts with so-called `Worst` mode, which denotes the specific version of the **optimization objective function that prefers so-called worse scrap**, where worse is meant in terms of chemical elements content (higher chem content => more prefered scrap). Additionally, the scrap is prefered in relation to grade chem maximum limit (higher grade chem limit => more prefered scrap). The worst-mode objective function can be found [here](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBfeature%2Fadd-project-docs&line=247&lineEnd=277&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents|). The actual calculation utilizes coefficient matrix of chemical constraints, which contains unit chem weights for each scrap and chemical element. Since these unit chem weights are going to be summed into one number per each scrap, normalized (minmax scaled) version of unit chem weights is used here. In order to encourage selection of scrap with higher grade chem maximum limit, we multiply the coeff matrix by chem limits defined per grade. These chem limits per grade are also applied normalized.

In case the optimization will be relaxed using the last `best_mode_relaxer`, the `Worst` mode will change to `Best` mode, which means that the objective function will be calculated in such a way that prefers best scrap rather than worst. This is achieved by utilizing unit chem weights multiplied by the grade chem maximum limits, normalized versus base chem (`Cr`). The best-mode objective function can be found [here](http://vdevops.sk.uss.com/Esten/UssAi/_git/UssAi?path=%2Fscrap_core%2Fscrap_core%2Foptimization%2Flinprog_optimizer.py&version=GBfeature%2Fadd-project-docs&line=185&lineEnd=194&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents).
