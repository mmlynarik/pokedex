# SCADA Database Overview

## Table of contents

- [SCADA Database Overview](#scada-database-overview)
	- [Table of contents](#table-of-contents)
	- [General Oracle DB notes](#general-oracle-db-notes)
		- [Tips & Tricks](#tips--tricks)
			- [Restrict number of results](#restrict-number-of-results)
			- [List available tables](#list-available-tables)
			- [List available views  (with DDLs)](#list-available-views--with-ddls)
			- [List all columns in given table](#list-all-columns-in-given-table)
	- [SCADA database](#scada-database)
		- [Interpretation of values stored in table `T_HEAT_APX` and column `O2_DOFUK_KOD`](#interpretation-of-values-stored-in-table-t_heat_apx-and-column-o2_dofuk_kod)
	- [TODO](#todo)

## General Oracle DB notes

### Tips & Tricks

#### Restrict number of results

```oracle-sql
SELECT * FROM {table_name}
FETCH FIRST 5 ROWS ONLY;
```

#### List available tables

```oracle-sql
SELECT owner, table_name FROM ALL_ALL_TABLES
-- WHERE LOWER(table_name) LIKE '%heat%'
ORDER BY table_name;
```

#### List available views  (with DDLs)

```oracle-sql
SELECT OWNER, view_name, text, text_vc  FROM ALL_VIEWS
-- WHERE lower(view_name) LIKE '%heat%'
ORDER BY view_name;
```

#### List all columns in given table

```oracle-sql
SELECT table_name, column_name, data_type, data_length
FROM ALL_TAB_COLUMNS
WHERE table_name = 'table_name'
```

## SCADA database

### Interpretation of values stored in table `T_HEAT_APX` and column `O2_DOFUK_KOD`

|O2_DOFUK_KOD|Abbreviation|Reason|
|------------|------------|------|
|1 |S| Sulphur|
|2 |P| Phosphorus|
|3 |C| Carbon|
|4 |Mn| Manganese|
|5 |T| Temperature|
|6 |T| Temperature|
|7 |Tech|?|
|8 |Cr| Chromium|
|9 |-|-|
|10|-|-|
|11|-|-|

## TODO
