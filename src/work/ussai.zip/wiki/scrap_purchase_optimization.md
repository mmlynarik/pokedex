# Scrap Purchase Optimization

## Table of Contents

- [Scrap Purchase Optimization](#scrap-purchase-optimization)
  - [Table of Contents](#table-of-contents)
  - [Inputs](#inputs)
    - [Available Scrap of Various Categories](#available-scrap-of-various-categories)
    - [Production Plan](#production-plan)
    - [Other Inputs](#other-inputs)
  - [Estimate Needed Scrap](#estimate-needed-scrap)
    - [Price/Utility Vector](#priceutility-vector)
    - [Constraints](#constraints)
      - [Scrap Weight Constraint](#scrap-weight-constraint)
      - [Scrap Meltablity](#scrap-meltablity)
      - [Chem Constraints](#chem-constraints)
      - [Weight Bounds](#weight-bounds)
    - [Result](#result)
  - [Calculate Recommendations](#calculate-recommendations)
  - [Appendix: Remarks on Steelshop Scrap Charge Optimization](#appendix-remarks-on-steelshop-scrap-charge-optimization)

## Inputs

### Available Scrap of Various Categories
---------------------------------------------------------------------

Table of available scrap is derived from following data:

- scrap supplies - scrap already available at USS KE's scrapyards
- scrap on the way - scrap that is being transported to USS KE and is expected to arrive in few days
- expected production of home scrap

| category (of availability) | scrap type | weight (t) | price (EUR/t) |
|----------------------------|------------|------------|---------------|
| scrap supplies             | MCE        | 1500       | 0             |
| on the way                 | MCE        | 500        | 0             |
| expected home scrap        | HS         | 25500      | 0             |
| realized offer             | MCE        | 1500       | 0             |
| available offer            | 1IB        | 1500       | 450           |
| available offer            | TBC        | 500        | 300           |
| ...                        | ...        | ...        | ...           |

**Remark:** All scrap categories except for _available offer_ have $0$ price, as such scrap is already purchased and hence there is no need to pay for it. Moreover, scrap with lower price is preffered (see price/utility vector definition below).

### Production Plan
---------------------------------------------------------------------

Simplified production plan is derived from following data: 

- plan of orders - list of records of the form (steel grade, weight)
- expected steel production - total weight in tons
- scrap stock objective - desired total weight of scrap stored in scrapyards after purchase period (in tons)

The aggregated result may look like this:

| steel grade | weight (t) |
|-------------|------------|
| 684         | 150000     |
| 096         | 75000      |
| 005         | 110000     |
| ...         | ...        |

**Remark**: _Plan of orders_ specifies sortiment of steel grades, _expected steel production_ together with _scrap stock objective_ are used to scale the production plan such that total weight of steel in production plan roughly equals expected steel production + steel produced using so much scrap as defined by scrap stock objective.

### Other Inputs

- mean scrap weight per heat

## Estimate Needed Scrap

Estimation is formulated as standard linear optimization problem

 $$
 c \cdot x \to min \\
 A x \le b 
 $$

where $c$ is utility vector and $A|b$ is system of constraints (see below).

### Price/Utility Vector
---------------------------------------------------------------------

Available scrap (see the first table above) is grouped by _scrap type_ and _price_. Each price is divided by expected scrap yield and the result is the utility vector $c$.

| scrap type | price | yield | c      |
|------------|-------|-------|--------|
| MCE        | 0     | 0.92  | 0      |
| MCE        | 370   | 0.92  | 402.17 |
| 1IB        | 450   | 0.96  | 468.75 |
| ...        | ...   | ...   | ...    |

### Constraints
---------------------------------------------------------------------

In this section operator * is used as dot product, if both arguments are vectors, and as multiplication by scalar (real number), if one argument is vector and the other is float. 

#### Scrap Weight Constraint

Expected steel in scrap ($yield \cdot x$) must be at least total weight of steel contained in scrap that is needed to produce so much steel as defined in production plan. This bound can be derived from total steel weight in production plan, mean heat yield and mean scrap weight per heat

```
expected_scrap_yield * x >= total weight of steel from scrap
```

#### Scrap Meltablity

Ratio of light/heavy scrap in estimated scrap must be within specified bounds.

```
min_light_ratio * sum(x) <= light_scrap_indicator * x <= max_light_ratio * sum(x)

min_heavy_ratio * sum(x) <= heavy_scrap_indicator * x <= max_heavy_ratio * sum(x)
```

#### Chem Constraints

For each element in (Cr, Cu, Mo, Ni, S, Sn) following inequality must be fulfilled:

```
expected element content in scrap * x <= expected total element content in steel (in production plan) - expected total element content in corresponding pig iron
```

where expected element content in steel is derived from grades` specifications, expected element content in pig iron is either value prescribed for grades by desulf table (S), or mean element content in pig iron (Cr, CU, Mo, Ni, Sn) extracted from historical measurements. Expected element content in scrap is estimated using blend model. By element content we mean absolute amount (not ratio) of given element in scrap/steel/pig iron.

#### Weight Bounds

Estimated scrap $x$ must be non-negative and within bounds defined by scrap availability.

```
0 <= x <= availability
```

### Result
---------------------------------------------------------------------

Estimated vector $x$ may look like weights in the following table:

| scrap type | weight (t) |
|------------|------------|
| MCE        | 3500       |
| MCE        | 1500       |
| 1IB        | 0          |
| HS         | 25000      |
| ...        | ...        |

## Calculate Recommendations

Now suppose that we have estimation of needed scrap $x$. First, we subtract already owned/purchased scrap from $x$, so we get the list of tuples (scrap type, weight) we still need to buy. Then for each item (scrap_type, weight) we just recommend the cheapest offers of given scrap type such that sum of their weights is equal to needed weight.

## Appendix: Remarks on Steelshop Scrap Charge Optimization 

Scrap purchase optimization has a lot in common with steelshop scrap charge optimization, however there are some differences, too. In particular, utility vectors are different and set of constraints in case of scrap purchase optimization is simplified/altered a bit.

Utility vector in case of steelshop scrap charge optimization roughly consists of aggregated and normalized relative element content in scrap, so we prefer low quality scrap if possible. However, quality of scrap and its price are correlated, hence effect of both utility vectors is similar.

Steelshop scrap charge optimization uses multiple constraints that are not needed during scrap purchase optimization. For example, each scrap has so called "loadability" bound, i.e. how much of this scrap you can fit in the basket. These constraints are meaningless for scrap purchase optimization due scrap availability, e.g. we can use at most 10t of MCE scrap per charge and we usually have about 2000 charges per month, thus we get upper bound for MCE scrap 20000t, what is far more than is available. 

There are also some specific constraints related to specific categories of grades that are somewhat redundant (or sometimes more strict) when considered together with chem constraints described above. For example, usage of worst scrap types (DSI) is forbidden for some high quality grades, but chem constraints restrict usage of such scrap, too. Therefore these constraints are omitted as well.
