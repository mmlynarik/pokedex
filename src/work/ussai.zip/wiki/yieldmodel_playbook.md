# Model výťažkov (YieldModel)
Tento model slúži na výpočet štatistík vyťaženosti šrotu pri danom časovom období.

## Horná lišta
- Veľkosť okna - jedná sa o veľkosť okna v mesiacoch
- Dátum od
- Dátum po
- Po zadaní týchto údajov je potrebné stlačiť tlačidlo *Načítať*

## Tlačidlo detail

Po stlačení tohto tlačidla budete presmerovaný ku grafom k načítaným dátam.  Grafom je možné hýbať, priblížiť ho, oddialiť či stiahnuť. Po ukázaní na graf myškou sa v pravo hore zobrazí menu. Pre automatické nastavenie a zobrazenie celého grafu je potrebné do grafu 2 krát kliknúť ľavým tlačidlom. V prípade že pri výpočte vznikli nejaké varovania, budú zobrazené pod tretím grafom.
Detail obsahuje 3 grafy a to:
- Výťažky jednotlivých šrotov spolu s ich horným a dolným odhadom
- Výťažky jednotlivých šrotov pre každé okno s ich horným a dolným odhadom. Daný typ šrotu je možné si zobraziť kliknutím na legendu v pravo.
- Vážený priemer výťažkov šrotov pre každé okno spolu s horným a dolným obsahom, taktiež rozdelené na *OC1* a *OC2*

## Tlačidlo export

Po stlačení tohto tlačidla sa stiahnu a uložia načítané dáta vo formáte *xslx*. Názov súboru pozostáva z časového rozpätia, veľkosti okna a verzie tohto modelu. Súbor obsahuje 3 tabuľky a to:
- Výťažky jednotlivých šrotov spolu s ich horným a dolným odhadom a počtom tavieb v ktorých boli použité
- Vážený priemer výťažkov šrotov pre každé okno spolu s horným a dolným obsahom, taktiež rozdelené na *OC1* a *OC2*
- Výťažky jednotlivých šrotov pre každé okno s ich horným a dolným odhadom a počtom tavieb v ktorých boli použité