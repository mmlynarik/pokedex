# Testing Playbook

## Table of contents

- [Testing Playbook](#testing-playbook)
  - [Table of contents](#table-of-contents)
  - [Test Cases](#test-cases)
    - [Loading Station](#loading-station)
      - [Scrap Loading](#scrap-loading)
        - [Select loading station](#select-loading-station)
        - [Common layout](#common-layout)
        - [OC1 layout](#oc1-layout)
        - [OC2 layout](#oc2-layout)
        - [Request control](#request-control)
        - [Add available scrap](#add-available-scrap)
        - [Update available scrap](#update-available-scrap)
        - [Create new heat](#create-new-heat)
        - [Optimize (new) heat](#optimize-new-heat)
        - [(Re)optimize heat](#reoptimize-heat)
        - [Optimize multiple heats](#optimize-multiple-heats)
        - [Remove heat](#remove-heat)
        - [Close heat](#close-heat)
        - [Optimize with limits](#optimize-with-limits)
        - [Optimize with outdoor scrap (OC1 only)](#optimize-with-outdoor-scrap-oc1-only)
        - [Switched baskets (OC2 only)](#switched-baskets-oc2-only)
        - [Input validation](#input-validation)
      - [Blend Model](#blend-model)
      - [Closed Heat Evaluation Report](#closed-heat-evaluation-report)
    - [Blast Furnace](#blast-furnace)
    - [Yield Model](#yield-model)
    - [Scrap Purchase](#scrap-purchase)
  - [Overview Table](#overview-table)
  - [Versions](#versions)
  - [TODO](#todo)

## Test Cases

### Loading Station

#### Scrap Loading

##### Select loading station

- steps:
  - Navigate to page `/scrap/scrap_loading`.
  - Select loading station (OC1 or OC2) by clicking on button "Nakladka koryta".
- expected result:
  - Page for selected loading station is loaded.

##### Common layout

- steps:
  - Navigate to OC1 and OC2 loading station page.
- expected result (user in control):
  - Table with available scrap is displayed.
  - Add new scrap component is displayed.
  - Update scrap weight component is displayed.
  - Table heats being loaded is displayed.
  - New heat button is displayed.
  - New heat component is displayed (if not, click the new heat button).
- expected result (read only):
  - Table with available scrap is displayed.
  - Table heats being loaded is displayed.
  - New heat component is displayed (if available).
  
##### OC1 layout

- steps:
  - Navigate to OC1 loading station page.
- expected result (user in control):
  - Scrap location is displayed.
  - Transfer capacity component is displayed.
  - Field switched basket is not displayed.
- expected result (read only):
  - Scrap location is displayed.
  - Transfer capacity component is not displayed.
  - Field switched basket is not displayed.

##### OC2 layout

- steps:
  - Navigate to OC2 loading station page.
- expected result (user in control):
  - Scrap location is not displayed.
  - Transfer capacity component is not displayed.
  - Field switched basket is displayed.

##### Request control

- authorized user:
  - steps:
    - Navigate to page `/scrap/scrap_loading/station/<loading_station_id>/v2`
    - If you are already user in control, log in as different (authorized) user and go to previous step.
    - Click on the button "Prevzatie kontroly od <user_id>".
  - expected result:
    - Window with text "Prevzatie kontroly prebehlo uspesne" is displayed.
    - After few seconds page is automatically refreshed.
    - Control is granted.
- read-only user:
  - steps:
    - Navigate to page `/scrap/scrap_loading/station/<loading_station_id>/v2`
  - expected result:
    - Button "Prevzatie kontroly od <user_id>" is not displayed.

##### Add available scrap

##### Update available scrap

##### Create new heat

##### Optimize (new) heat

##### (Re)optimize heat

##### Optimize multiple heats

- expected result:
  - recommended scrap is automatically subtracted from available scrap

##### Remove heat

##### Close heat

- expected result:
  - used scrap is automatically subtracted from available scrap

##### Optimize with limits

##### Optimize with outdoor scrap (OC1 only)

##### Switched baskets (OC2 only)

##### Input validation

#### Blend Model

#### Closed Heat Evaluation Report

### Blast Furnace

### Yield Model

### Scrap Purchase

## Overview Table

| Component       | Test Case                                                                      | 2022/07/21 | 2022/08/05                                                   | next test date |
|-----------------|--------------------------------------------------------------------------------|------------|--------------------------------------------------------------|----------------|
| Loading Station | [Select loading station](#select-loading-station)                              | n/a        | pass                                                         |
|                 | [Common layout](#common-layout)                                                |            | pass                                                         |
|                 | [OC1 layout](#oc1-layout)                                                      |            | pass                                                         |
|                 | [OC2 layout](#oc2-layout)                                                      |            | pass                                                         |
|                 | [Request control](#request-control)                                            | pass       | pass                                                         |
|                 | [Add available scrap](#add-available-scrap)                                    |            | pass                                                         |
|                 | [Update available scrap](#update-available-scrap)                              |            | pass                                                         |
|                 | [Create new heat](#create-new-heat)                                            |            | pass                                                         |
|                 | [Optimize (new) heat](#optimize-new-heat)                                      |            | pass                                                         |
|                 | [(Re)optimize heat](#reoptimize-heat)                                          |            | pass                                                         |
|                 | [Optimize multiple heats](#optimize-multiple-heats)                            |            | fail (in total, recommended more HS scrap than available)    |
|                 | [Optimize with limits](#optimize-with-limits)                                  |            | pass                                                         |
|                 | [Remove heat](#remove-heat)                                                    |            | pass                                                         |
|                 | [Close heat](#close-heat)                                                      |            | pass                                                         |
|                 | [Optimize with outdoor scrap (OC1 only](#optimize-with-outdoor-scrap-oc1-only) |            | fail (outdoor scrap recommended despite 0 transfer capacity) |
|                 | [Switched baskets (OC2 only)](#switched-baskets-oc2-only)                      |            | pass                                                         |
|                 | [Input validation](#input-validation)                                          |            | n/a                                                          |
| Blast Furnace   | TBD                                                                            | fail       ||
| Yield Model     | TBD                                                                            |            |
| Scrap Purchase  | TBD                                                                            |            |

## Versions

| Version | Date       | Change Description |
|---------|------------|--------------------|
| 0.0.1   | 2022-07-19 | TBD                |

## TODO

- [ ] 123
- [ ] 456
