# Set up Oracle database in Docker container

## Table of Contents

<!-- TOC -->
* [Set up Oracle database in Docker container](#set-up-oracle-database-in-docker-container)
  * [Table of Contents](#table-of-contents)
  * [How-to](#how-to)
    * [Standard Edition](#standard-edition)
      * [Prerequisites](#prerequisites)
      * [Build a docker image](#build-a-docker-image)
      * [Add initializing scripts](#add-initializing-scripts)
      * [Run the container](#run-the-container)
      * [Connect to your database](#connect-to-your-database)
  * [Troubleshooting](#troubleshooting)
    * [Database initialization error](#database-initialization-error)
    * [Can't connect to db using plain service name (`sqlplus`)](#cant-connect-to-db-using-plain-service-name-sqlplus)
    * [Space quota exceeded error](#space-quota-exceeded-error)
  * [Appendix](#appendix)
    * [Update `docker-compose` file to connect to your local Oracle db](#update-docker-compose-file-to-connect-to-your-local-oracle-db)
    * [Skynet (for users without `docker`)](#skynet-for-users-without-docker)
    * [Use Express Edition (XE) instead](#use-express-edition-xe-instead)
      * [Build a docker image](#build-a-docker-image-1)
      * [Run the container](#run-the-container-1)
  * [TODO](#todo)
  * [Resources](#resources)
<!-- TOC -->

## How-to

**Important**: Django 4 supports Oracle 19c or higher !!! (see [release notes](https://docs.djangoproject.com/en/5.0/releases/4.0/))

Theoretically, you can use any of dockerfiles that can be found on GitHub [here](https://github.com/oracle/docker-images/tree/main/OracleDatabase/SingleInstance), however, we have tested version 21.3.0 Express Edition (XE) and 19.3.0 Standard Edition (SE2), only. 

There are multiple reasons to prefer SE2 version instead of XE version. In particular, our production Oracle server has the same version (19c, but enterprise edition) and what is more, XE version has limit 12 GB, what is insufficient for production data snapshot. To create a SE2 container follow steps below. If for whatever reason you want to use XE edition, see the appendix at the end of this guide. From now on, we assume the SE2 version only.

### Standard Edition

#### Prerequisites

At first download binary file `LINUX.X64_193000_db_home.zip` (or different version if needed) from [Oracle webpage](https://www.oracle.com/database/technologies/oracle-database-software-downloads.html#db_free). An Oracle account is required. Afterwards, move/copy this file to directory `oracle-docker-images\OracleDatabase\SingleInstance\dockerfiles\19.3.0`.

**Pro tip**: You may find a copy this binary file on Skynet (PC190386) in the folder `D:\INSTALACKY`, if it hasn't been removed, yet.

#### Build a docker image

To build (SE2) Oracle db image `cd` to `oracle-docker-images\OracleDatabase\SingleInstance\dockerfiles\19.3.0` directory and run:

```commandline
docker login

docker build -t oracle/database:19.3.0-se -f .\Dockerfile --build-arg DB_EDITION=SE2 .

# or inside VPN

docker build -t oracle/database:19.3.0-se -f .\Dockerfile --build-arg HTTPS_PROXY=$Env:HTTPS_PROXY --build-arg HTTP_PROXY=$Env:HTTP_PROXY --build-arg https_proxy=$Env:HTTPS_PROXY --build-arg http_proxy=$Env:HTTP_PROXY --build-arg DB_EDITION=SE2 .
```

#### Add initializing scripts

Create 2 directories (in the following text we expect these directories to be stored in your `HOME` directory. If you decide to store them somewhere else, you will need to update some of the following commands accordingly.)

```commandline
mkdir -p ~/oracle-data/data    # directory to store your data (to persist changes after container restart)
mkdir -p ~/oracle-data/sql     # directory with scripts to correctly initalize new database when container is created
```

Add 2 new scripts `01_users.sql` and `02_permissions.sql` to `~/oracle-data/sql` directory:

```sql
-- ~/oracle-data/sql/01_users.sql

ALTER SESSION SET CONTAINER = VIUPDB;

CREATE USER viu_user IDENTIFIED BY "viu_pass";
```

```sql
-- ~/oracle-data/sql/02_permissions.sql

ALTER SESSION SET CONTAINER = VIUPDB;

GRANT CONNECT TO viu_user CONTAINER=CURRENT;
GRANT CREATE SESSION TO viu_user CONTAINER=CURRENT;
GRANT RESOURCE TO viu_user CONTAINER=CURRENT;

ALTER USER viu_user QUOTA 16384M ON USERS;
```

#### Run the container

Run docker container (initialization usually takes about 10+ minutes). Container will be called `oracle_db_dev`.

```commandline
docker run --name oracle_db_dev -p 1521:1521 -p 5500:5500 -p 2484:2484 --ulimit nofile=1024:65536 --ulimit nproc=2047:16384 --ulimit stack=10485760:33554432 --ulimit memlock=3221225472 -e ORACLE_SID=VIU -e ORACLE_PDB=VIUPDB -e ORACLE_PWD=oracle_pass -e ORACLE_EDITION=standard -e ENABLE_ARCHIVELOG=true -e ENABLE_TCPS=true -v ${HOME}/oracle-data/data:/opt/oracle/oradata -v ${HOME}/oracle-data/sql:/docker-entrypoint-initdb.d/setup oracle/database:19.3.0-se
```

The same command, but with one setting per line.

```commandline
docker run --name oracle_db_dev \
-p 1521:1521 -p 5500:5500 -p 2484:2484 \
--ulimit nofile=1024:65536 --ulimit nproc=2047:16384 --ulimit stack=10485760:33554432 --ulimit memlock=3221225472 \
-e ORACLE_SID=VIU \
-e ORACLE_PDB=VIUPDB \
-e ORACLE_PWD=oracle_pass \
-e ORACLE_EDITION=standard \
-e ENABLE_ARCHIVELOG=true \
-e ENABLE_TCPS=true \
-v ${HOME}/oracle-data/data:/opt/oracle/oradata \
-v ${HOME}/oracle-data/sql:/docker-entrypoint-initdb.d/setup \
oracle/database:19.3.0-se
```

**Remark:** You may need to add `HOME` environment variable, or just update the `docker run` command above as needed.

#### Connect to your database

To be able to connect to your new database you need to set up expected environment variables as follows (e.g. update `config.env` file and run `setupenv.ps1` script).

```commandline
BACKEND_DB_HOST=
BACKEND_DB_PORT=
BACKEND_DB_SID=localhost:1521/VIUPDB
BACKEND_DB_USER=viu_user
BACKEND_DB_PASSWORD=viu_pass
```

Since our database is so-called "pluggable database", we need to connect using service name instead of SID. Therefore, `HOST` and `PORT` must be kept empty or undefined. For more details see [official documentation](https://docs.djangoproject.com/en/3.2/ref/databases/#oracle-notes).

## Troubleshooting

### Database initialization error

In case of database initialization failure due to permission error on `/opt/oracle/oradata` folder inside the running container, run the following commands in the second terminal:

```bash
docker exec -it <running-container-name> bash
chown oracle:dba /opt/oracle/oradata
```

After the restart of the container, database should be initialized correctly.

### Can't connect to db using plain service name (`sqlplus`)

You may encounter the error `ORA-12504: TNS:listener was not given the SERVICE_NAME in CONNECT_DATA`, when connecting to db using

```commandline
sqlplus sys@localhost:1521/VIUPDB as sysdba
```

If this is the case, then update file `<instantclientdir>/network/admin/tnsnames.ora` with following lines

```
viu_local_oracle= 
 (DESCRIPTION= 
   (ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521))
   (CONNECT_DATA=(SERVICE_NAME=VIUPDB))) 
```

and try to connect with new identifier instead:

```commandline
sqlplus sys@viu_local_oracle as sysdba
```

### Space quota exceeded error

You may encounter the error `ORA-01536: space quota exceeded for tablespace 'USERS'`. In such a case, you can alter/fix your database with steps provided within this section. Otherwise, you must recreate your database from scratch with updated script `02_permissions.sql` (see the section [Add initializing scripts](#add-initializing-scripts)).

Assuming you have used default names and passwords during setup, login as sysadmin

```commandline
sqlplus sys@localhost:1521/VIUPDB as sysdba
```

Use password _oracle_pass_ as specified in `docker run` command [here](#run-the-container), `sqlplus` is usually already installed together with oracle client runtime.

Afterwards, you may check the current state as follows

```oraclesqlplus
select (bytes)/1024/1024 as mb_used, MAX_BYTES/1024/1024 as mb_max from dba_ts_quotas where lower(username)='viu_user';
```

Finally, alter quota as needed

```oraclesqlplus
alter user viu_user quota 32768m on users;
-- or unlimited
alter user viu_user quota unlimited on users;
```

and optionally, you may check as above if the new settings has been applied.

## Appendix

### Update `docker-compose` file to connect to your local Oracle db

At first create docker network and add `oracle_db_dev` container to it:

```commandline
docker network create viuNetwork
docker network connect viuNetwork oracle_db_dev
```

Afterwards add `viuNetwork` to `docker-compose.dev.yml` file as follows

```docker-compose
networks:
  default:
    external: true
    name: viuNetwork
```

Finally, update `config.env` using container name instead of `localhost`

```commandline
BACKEND_DB_HOST=
BACKEND_DB_PORT=
BACKEND_DB_SID=oracle_db_dev:1521/VIUPDB
BACKEND_DB_USER=viu_user
BACKEND_DB_PASSWORD=viu_pass
```

### Skynet (for users without `docker`)

Usually, there is a running container called `oracle_db_dev` on Skynet with some copy of production/test database. To connect to this container just set

```commandline
BACKEND_DB_HOST=
BACKEND_DB_PORT=
BACKEND_DB_SID=PC190386:1521/VIUPDB
BACKEND_DB_USER=viu_user
BACKEND_DB_PASSWORD=viu_pass
```

In case that above settings doesn't working, modify BACKEND_DB_SETTING in vsadzka/settings.py to full conection string:

1. remove HOST and PORT keys.
2. in key NAME replace SID with oracle full connection string.

```commandline
BACKEND_DB_SETTINGS = {
    "ENGINE": "django.db.backends.oracle",
    "NAME": "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=PC190386)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=VIUPDB)))",
    "USER": "viu_user",
    "PASSWORD": "viu_pass",
}
```

Oracle full connection string contains equals sign which is not posible to store in environment variable with setupenv script. If you want to get
full connection string from environment variable you must assign connection string to BACKEND_DB_SID variable in terminal by $env: command.

```commandline
$env:BACKEND_DB_SID="(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=PC190386)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=VIUPDB)))"
```

In case the container is not running feel free to start it with

```commandline
docker start oracle_db_dev
```

In case there is no such container, you can recreate it following the steps provided in this guide.

### Use Express Edition (XE) instead

XE version does not require to download any Oracle binaries. Hence, it may be considered as the simplest choice. However, there are few drawbacks. 
First and foremost, it is the 12 GB size limit. Another drawback is default name of plugable database `XEPDB1`. As of writing of this guide, 
I don't know how change this name (`ORACLE_PDB` does not work as in case of SE2 version). 

**IMPORTANT**: If you insist on using XE version of Oracle db, you have to change `VIUPDB` to `XEPDB1` in all necessary steps / files / env vars above to make it work as expected. In particular, see the section [Add initializing scripts](#add-initializing-scripts) for more info about `oracle-data` directory used in [Run the container](#run-the-container-1) step below.

#### Build a docker image

To build (XE) Oracle db image `cd` to `oracle-docker-images\OracleDatabase\SingleInstance\dockerfiles\21.3.0` directory and run:

```commandline
docker login

docker build -t oracle/database:21.3.0-xe -f .\Dockerfile.xe .

# or inside VPN

docker build -t oracle/database:21.3.0-xe -f .\Dockerfile.xe --build-arg HTTPS_PROXY=$Env:HTTPS_PROXY --build-arg HTTP_PROXY=$Env:HTTP_PROXY --build-arg https_proxy=$Env:HTTPS_PROXY --build-arg http_proxy=$Env:HTTP_PROXY .
```

#### Run the container

Run docker container (initialization usually takes about 10+ minutes). Container will be called `oracle_db_dev`.

```commandline
docker run -d --name oracle_db_dev -p 1521:1521 -p 5500:5500 -e ORACLE_PWD=oracle_pass -v ${HOME}/oracle-data/data:/opt/oracle/oradata -v ${HOME}/oracle-data/sql:/docker-entrypoint-initdb.d/setup --shm-size=10g oracle/database:21.3.0-xe
```

## TODO

- [ ] Add section describing how to add container with Oracle db to `docker-compose.dev.yml` file

## Resources

1. https://marschall.github.io/2020/04/12/oracle-docker-container.html
2. https://github.com/oracle/docker-images/tree/main/OracleDatabase/SingleInstance
3. https://docs.djangoproject.com/en/3.2/ref/databases/#oracle-notes
4. https://smarttechways.com/2019/09/23/ora-01536-space-quota-exceeded-for-tablespace-users/
