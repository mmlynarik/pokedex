from os import path

from setuptools import setup

here = path.abspath(path.dirname(__file__))

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="scalecore",
    version="0.3.0",
    package_data={
        "scalecore": ["py.typed"],
    },
    packages=[
        "scalecore",
    ],
    description="Core of the weighting on the steelshop scales.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "attrs>=23.1.0",
        "cattrs>=23.2.0",
    ],
    zip_safe=False,
)
