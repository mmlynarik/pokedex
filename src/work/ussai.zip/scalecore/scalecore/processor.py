import logging
from datetime import datetime
from typing import (
    Any,
    Callable,
    Dict,
    NoReturn,
    Optional,
    Protocol,
    Self,
    Tuple,
    Type,
    Union,
)

import attr
import cattr
from zoneinfo import ZoneInfo

converter = cattr.Converter()

converter.register_unstructure_hook(datetime, lambda dt: int(dt.timestamp() * 1000))
converter.register_structure_hook(
    dict, lambda serialized, _: datetime.fromtimestamp(serialized / 1000, tz=ZoneInfo("UTC"))
)

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


### Actions ###


@attr.frozen
class StartAction:
    scrap_type: str = attr.ib()
    scrap_charge_id: int = attr.ib()


@attr.frozen
class UpdateAction: ...


@attr.frozen
class StopAction:
    weighting_id: int = attr.ib(converter=int)


@attr.frozen
class StopStartAction:
    stop_action: StopAction
    start_action: StartAction


@attr.frozen
class TareAction: ...


AnyAction = Union[StartAction, UpdateAction, StopAction, StopStartAction, TareAction]

### Weighting states ###


@attr.frozen
class StoppedWeightingState:
    weighting_id: Optional[int] = attr.ib(default=None)
    last_measured_weight: Optional[int] = attr.ib(default=None)

    def to_message(self) -> Dict[str, Any]:
        return converter.unstructure(self)


@attr.frozen
class StartingWeightingState:
    scrap_type: str = attr.ib()
    start_time: datetime = attr.ib()
    scrap_charge_id: int = attr.ib()

    def to_message(self) -> Dict[str, Any]:
        return converter.unstructure(self)


@attr.frozen
class WeightingState:
    weighting_id: int = attr.ib()
    weight: Optional[int] = attr.ib(default=None)

    def to_message(self) -> Dict[str, Any]:
        return converter.unstructure(self)


@attr.frozen
class StoppingWeightingState:
    weighting_id: int = attr.ib()
    stop_time: datetime = attr.ib()

    def to_message(self) -> Dict[str, Any]:
        return converter.unstructure(self)


AnyState = Union[StoppedWeightingState, StartingWeightingState, WeightingState, StoppingWeightingState]
AnyStates = Tuple[
    Union[StoppedWeightingState, StartingWeightingState, WeightingState, StoppingWeightingState], ...
]


class ScaleLock(Protocol):
    def __enter__(self) -> Self: ...

    def __exit__(self, exc_type, exc_value, exc_tb): ...

    def get_current_state(self) -> AnyState: ...

    def update_current_state(self, new_state: AnyState): ...


class WeightingBackend(Protocol):
    scale_id: str

    def lock(self) -> ScaleLock: ...

    def get_current_datetime(self) -> datetime: ...

    def request_weighting_start(
        self, start_action: StartAction, start_at: datetime
    ) -> StartingWeightingState: ...

    def start_weighting(self, current_state: StartingWeightingState) -> WeightingState: ...

    def weight_update(self, current_state: WeightingState) -> WeightingState: ...

    def request_weighting_stop(
        self, stop_action: StopAction, stop_at: datetime
    ) -> StoppingWeightingState: ...

    def stop_weighting(self, current_state: StoppingWeightingState) -> StoppedWeightingState: ...

    def tare(self, current_state: AnyState) -> AnyState: ...


class MessageProcessor(Protocol):
    def send_updated_state(self, new_state: Tuple[AnyState, ...], scale_id: str) -> None: ...

    def send_error_state(self, exception: Exception, action: AnyAction, scale_id: str) -> None: ...


### Processor functions ###

StateProcessor = Callable[[WeightingBackend, AnyState, AnyAction], Tuple[AnyState, ...]]


#### Stopped state processors ####


def stopped_start(
    backend: WeightingBackend, _: StoppedWeightingState, action: StartAction
) -> Tuple[StartingWeightingState]:
    return (backend.request_weighting_start(action, backend.get_current_datetime()),)


def stopped_update(
    _: WeightingBackend, current_state: StoppedWeightingState, __: UpdateAction
) -> Tuple[StoppedWeightingState]:
    return (current_state,)


def stopped_tare(
    backend: WeightingBackend, current_state: StoppedWeightingState, _: TareAction
) -> Tuple[StoppedWeightingState]:
    return (backend.tare(current_state),)


#### Starting state processors ####


def starting_update(
    backend: WeightingBackend, current_state: StartingWeightingState, _: UpdateAction
) -> Tuple[WeightingState]:
    return (backend.start_weighting(current_state),)


def starting_stop(
    backend: WeightingBackend, current_state: StartingWeightingState, action: StopAction
) -> Tuple[StoppingWeightingState]:
    backend.start_weighting(current_state)
    return (backend.request_weighting_stop(action, backend.get_current_datetime()),)


def starting_tare(
    backend: WeightingBackend, current_state: StartingWeightingState, _: TareAction
) -> Tuple[StartingWeightingState]:
    return (backend.tare(current_state),)


#### Weighting state processors ####


def weighting_update_weight(
    backend: WeightingBackend, current_state: WeightingState, _: UpdateAction
) -> Tuple[WeightingState]:
    return (backend.weight_update(current_state),)


def weighting_update_scrap(
    backend: WeightingBackend, _: WeightingState, actions: StopStartAction
) -> Tuple[StoppingWeightingState, StoppedWeightingState, StartingWeightingState, WeightingState]:
    now = backend.get_current_datetime()
    stop_action = actions.stop_action

    stop_request_state: StoppingWeightingState = backend.request_weighting_stop(stop_action, now)
    stop_state: StoppedWeightingState = backend.stop_weighting(stop_request_state)

    start_action = actions.start_action

    start_request_state: StartingWeightingState = backend.request_weighting_start(start_action, now)
    weighting_state: WeightingState = backend.start_weighting(start_request_state)

    return (stop_request_state, stop_state, start_request_state, weighting_state)


def weighting_stop(
    backend: WeightingBackend, _: WeightingState, action: StopAction
) -> Tuple[StoppingWeightingState]:
    return (backend.request_weighting_stop(action, backend.get_current_datetime()),)


def weighting_tare(
    backend: WeightingBackend, current_state: WeightingState, _: TareAction
) -> Tuple[StoppingWeightingState, StoppedWeightingState]:
    now = backend.get_current_datetime()
    stop_action = StopAction(current_state.weighting_id)

    stop_request_state: StoppingWeightingState = backend.request_weighting_stop(stop_action, now)
    stop_state: StoppedWeightingState = backend.stop_weighting(stop_request_state)
    stop_state = backend.tare(stop_state)
    return (stop_request_state, stop_state)


#### Stopping state processors ####


def stopping_update(
    backend: WeightingBackend, current_state: StoppingWeightingState, _: UpdateAction
) -> Tuple[StoppedWeightingState]:
    return (backend.stop_weighting(current_state),)


def stopping_tare(
    backend: WeightingBackend, current_state: StoppingWeightingState, _: TareAction
) -> Tuple[StoppingWeightingState]:
    return (backend.tare(current_state),)


#### Inconsistent state ####


class UnappliableActionError(Exception): ...


def inconsistent_state(_: WeightingBackend, current_state: AnyState, action: AnyAction) -> NoReturn:
    raise UnappliableActionError(f"Unappliable action {action} to current state {current_state}")


PROCESSORS: Dict[Type, Dict[Type, StateProcessor]] = {
    StoppedWeightingState: {
        StartAction: stopped_start,
        UpdateAction: stopped_update,
        StopAction: inconsistent_state,
        StopStartAction: inconsistent_state,
        TareAction: stopped_tare,
    },
    StartingWeightingState: {
        StartAction: inconsistent_state,
        UpdateAction: starting_update,
        StopAction: starting_stop,
        StopStartAction: inconsistent_state,
        TareAction: starting_tare,
    },
    WeightingState: {
        StartAction: inconsistent_state,
        UpdateAction: weighting_update_weight,
        StopAction: weighting_stop,
        StopStartAction: weighting_update_scrap,
        TareAction: weighting_tare,
    },
    StoppingWeightingState: {
        StartAction: inconsistent_state,
        UpdateAction: stopping_update,
        StopAction: inconsistent_state,
        StopStartAction: inconsistent_state,
        TareAction: stopping_tare,
    },
}


def get_processor(
    current_state: AnyState, action: AnyAction
) -> Callable[[WeightingBackend, AnyState, AnyAction], AnyStates]:
    return PROCESSORS[type(current_state)][type(action)]
