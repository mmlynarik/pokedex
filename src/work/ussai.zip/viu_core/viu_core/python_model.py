# pylint: disable=too-many-lines,invalid-name,too-many-arguments,too-many-return-statements,too-many-branches
import itertools
import numpy as np
from functools import lru_cache
from immutables import Map
from typing import Dict, FrozenSet, Iterable, Mapping

from .common_constants import ASH_BURN_COMPONENTS, MET_FE_GROUP
from .datamodel.model import (
    AglomeracnyTyp,
    BazickyTyp,
    ChemickaLatka,
    ChemickeZlozenie,
    Prisada,
    TypPaliva,
    TypPrisady,
    VsadzkaInput,
    VsadzkaOutput,
    ZlozkaAglomeratu,
    ZlozkaVsadzky,
)


def percento_recyklatov(korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput) -> float:
    return (
        suma_recyklatov(korigovane_hmotnosti, input_data)
        / hmotnost_aglomeracnej_vsadzky(korigovane_hmotnosti, input_data)
        * 100
    )


def suma_recyklatov(korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput) -> float:
    return sum(
        [
            korigovane_hmotnosti[prisada.nazov]
            for prisada in input_data.prisady_do_aglomeratu
            if prisada.is_recyclable()
        ]
    )


def vplyv_na_palivo(korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput) -> float:
    return sum(
        vazeny_priemer_podielu_pod_5mm_prisada(
            prisada, podiel_suroviny_v_celkovej_vsadzke(prisada, korigovane_hmotnosti, input_data)
        )
        for prisada in input_data.vsetky_prisady
    ) + vazeny_priemer_podielu_pod_5mm_aglomerat(korigovane_hmotnosti, input_data)


def vazeny_priemer_podielu_pod_5mm_aglomerat(
    korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput
) -> float:
    return (
        input_data.posditny_podiel_pod_5mm_aglomerat
        * 2
        * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, korigovane_hmotnosti)
        / celkova_hmotnost_vsadzky(input_data, korigovane_hmotnosti)
    )


def vazeny_priemer_podielu_pod_5mm_prisada(prisada: Prisada, podiel_suroviny_vo_vsadzke: float) -> float:
    if prisada.typ_prisady in [TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP]:
        return prisada.rozsev_pod_5mm * 2 * podiel_suroviny_vo_vsadzke
    return 0


def podiel_suroviny_v_celkovej_vsadzke(
    prisada: Prisada, korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput
) -> float:
    if prisada.typ_prisady in [TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP]:
        return korigovane_hmotnosti[prisada.nazov] / celkova_hmotnost_vsadzky(
            input_data, korigovane_hmotnosti
        )
    return 0


def hmotnost_aglomeracnej_vsadzky(
    korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput
) -> float:
    prisady_aglomeracnej_vsadzky = [
        TypPrisady.AGLORUDA,
        TypPrisady.KONCENTRAT,
        TypPrisady.PRISADA_DO_AGLOMERATU,
    ]
    vaha = sum(
        [
            suma_vah_pre_prisadu(korigovane_hmotnosti, input_data, typ_prisady)
            for typ_prisady in prisady_aglomeracnej_vsadzky
        ]
    )
    popol = hmotnost_popola_z_aglomeracneho_koksu(input_data, korigovane_hmotnosti)
    return vaha + popol


def suma_vah_pre_prisadu(
    korigovane_hmotnosti: Mapping[str, float], input_data: VsadzkaInput, typ_prisady: TypPrisady
) -> float:
    if typ_prisady == TypPrisady.AGLORUDA:
        return sum(
            korigovane_hmotnosti[prisada.nazov] for prisada in input_data.aglorudy
        ) + vaha_podsitnych_peliet(input_data, korigovane_hmotnosti)
    if typ_prisady == TypPrisady.PELETY:
        return sum(korigovane_hmotnosti[prisada.nazov] for prisada in input_data.pelety)
    if typ_prisady == TypPrisady.PRISADY_DO_VP:
        return sum(korigovane_hmotnosti[prisada.nazov] for prisada in input_data.prisady_do_vp)
    if typ_prisady == TypPrisady.PRISADA_DO_AGLOMERATU:
        return sum(korigovane_hmotnosti[prisada.nazov] for prisada in input_data.prisady_do_aglomeratu)
    if typ_prisady == TypPrisady.KONCENTRAT:
        return sum(korigovane_hmotnosti[prisada.nazov] for prisada in input_data.koncentraty)
    raise Exception(f"Unprocessed typ prisady: {typ_prisady}")


def vazeny_priemer_ceny(
    prisady: FrozenSet[Prisada], hmotnosti: Mapping[str, float], korigovane_hmotnosti: Mapping[str, float]
) -> float:
    return sum(hmotnosti[prisada.nazov] * prisada.cena_za_tonu for prisada in prisady) / sum(
        korigovane_hmotnosti[prisada.nazov] for prisada in prisady
    )


def cena_aglomeracneho_paliva(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        palivo_potrebne_na_skut_vyrobu_aglomeratu(input_data, hmotnosti)
        / 1000
        * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti)
        * input_data.cena_aglom_paliva
    )


@lru_cache()
def cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return (
        (
            (
                sum(
                    hmotnosti[prisada.nazov] * prisada.cena_za_tonu
                    for prisada in itertools.chain.from_iterable(
                        [input_data.aglorudy, input_data.koncentraty, input_data.prisady_do_aglomeratu]
                    )
                )
                + (
                    vaha_podsitnych_peliet(input_data, hmotnosti)
                    * cena_podsitnych_peliet(input_data, hmotnosti)
                )
                + cena_aglomeracneho_paliva(input_data, hmotnosti)
            )
            / hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti)  # ok
        )
        + input_data.spracovacie_naklady_na_tonu_aglomeratu
        + (mnozstvo_co2_na_t_fe_z_aglomeratu(input_data, hmotnosti) * input_data.cena_tony_co2)  # ok
    )


@lru_cache()
def celkova_hmotnost_vsadzky(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return sum(hmotnost_vo_vsadzke(input_data, zlozka, hmotnosti) for zlozka in ZlozkaVsadzky)


@lru_cache()
def percentualny_podiel_paliva(input_data: VsadzkaInput, typ_paliva: TypPaliva) -> float:
    if typ_paliva == TypPaliva.UHLIE:
        return input_data.celkove_palivo_uhlie / input_data.msp * 100
    if typ_paliva == TypPaliva.KOKS_ORECH:
        return input_data.celkove_palivo_koks_orech / input_data.msp * 100
    if typ_paliva == TypPaliva.VP_METALURG:
        return (
            (input_data.msp - input_data.celkove_palivo_uhlie - input_data.celkove_palivo_koks_orech)
            / input_data.msp
            * 100
        )
    raise Exception(f"Unprocessed typ paliva: {typ_paliva}")


def co2_z_tony_paliva(input_data: VsadzkaInput, typ_paliva: TypPaliva) -> float:
    if typ_paliva == TypPaliva.UHLIE:
        return input_data.co2_z_uhlia
    if typ_paliva == TypPaliva.KOKS_ORECH:
        return input_data.co2_z_koks_orech
    if typ_paliva == TypPaliva.VP_METALURG:
        return input_data.co2_z_vp_metalurg
    raise Exception(f"Unprocessed typ paliva: {typ_paliva}")


@lru_cache()
def cena_co2_v_tonach_na_1_tsz_zo_suroviny(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        (obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.C, hmotnosti) / 100 * 3.664)
        * obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        / 100
        * input_data.cena_tony_co2
    )


@lru_cache()
def cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    return (
        (
            pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.C, hmotnosti)
            / 100
            * 3.664
        )
        * pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti)
        / 100
        * input_data.cena_tony_co2
    )


@lru_cache()
def mnozstvo_co2_na_t_fe_z_aglomeratu(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (palivo_na_aglomeracii(input_data, hmotnosti) / 1000) * input_data.co2_z_koks_prach


@lru_cache()
def fe_surove_zelezo_s_bvs(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]):
    return obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti) * (
        (
            100
            + input_data.C_v_sur_fe_minuly_mesiac
            + input_data.Si_v_sur_fe_minuly_mesiac
            + input_data.Mn_v_sur_fe_minuly_mesiac
        )
        / 100
    )


# Super divne ze je to ine ako pre prisady
@lru_cache()
def celkovy_vyskyt_trosky(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return vypocet_vyskytu_trosky(
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.SiO2, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.CaO, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.MgO, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Al2O3, hmotnosti),
        fe_surove_zelezo_s_bvs(input_data, hmotnosti),
        0.0,
    )


@lru_cache()
def celkovy_vytazok_fe(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        fe_surove_zelezo_s_bvs(input_data, hmotnosti) / 100 * celkova_hmotnost_vsadzky(input_data, hmotnosti)
    )


@lru_cache()
def celkova_spotreba_vapenca(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.VAPENEC, hmotnosti)
        * 1000
        / celkovy_vytazok_fe(input_data, hmotnosti)
    )


@lru_cache()
def celkova_spotreba_vapenca_so_stratami(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.VAPENEC, hmotnosti)
        * 1000
        / celkovy_vytazok_fe_so_stratami(input_data, hmotnosti)
    )


# Zase velmi divne tu sa zapocitava aj Fe aj Mn ale vo vypocte alkalii to je prenasobene 1.05
@lru_cache()
def celkove_alkalie(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return vypocet_alkalii(
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Na2O, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.K2O, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Mn, hmotnosti),
    )


@lru_cache()
def celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return palivova_rovnica(
        celkovy_vyskyt_trosky(input_data, hmotnosti),  # okay
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti) * input_data.koef_na_bvs,
        celkova_spotreba_vapenca(input_data, hmotnosti) / 100.0,  # okay
        input_data.popol_kb1.percento_popola,
        input_data.percento_Si,
        input_data.hbt,
        input_data.eta_co,
        celkove_alkalie(input_data, hmotnosti),  # okay
        input_data.msp,
        0.0,
        0.0,
        vplyv_na_palivo(hmotnosti, input_data),  # okay
    ) + pridavok_paliva_na_odparenie_vlhkosti(
        input_data, hmotnosti
    )  # okay


@lru_cache()
def mnozstvo_paliva_na_aglomerat(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        (
            (
                input_data.realne_palivo_pri_p2_z_minuleho_mesiaca / 1000 * 1.3
                - input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu / 1000 * 0.1 * 1.3
            )
            * 1000
        )
        + (
            hmotnost_vapenca_2(input_data, hmotnosti)
            * 0.1
            / (
                hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU, hmotnosti)
                + hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.KONCENTRAT, hmotnosti)
                + hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.AGLORUDA, hmotnosti)
                - hmotnost_vapenca_2(input_data, hmotnosti)
            )
            * 1000
        )
    ) / 1.3


# Divny vypocet - skontrolovat
@lru_cache()
def palivo_na_aglomeracii_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if not prisada.typ_prisady in {
        TypPrisady.PRISADA_DO_AGLOMERATU,
        TypPrisady.KONCENTRAT,
        TypPrisady.AGLORUDA,
        TypPrisady.VAPENEC,  # Vapenec tu je len pre kompatibilitu s excelom
    }:
        return 0.0
    if prisada.bazicky_typ != BazickyTyp.ZIADEN:
        return (
            mnozstvo_paliva_na_aglomerat(input_data, hmotnosti)
            / (
                pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti)
                + pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti)
            )
            * 100
        )
    return (
        input_data.realne_palivo_pri_p2_z_minuleho_mesiaca
        / (
            pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe)
            + pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Mn)
        )
        * 100
    )


@lru_cache()
def palivo_na_aglomeracii(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        mnozstvo_paliva_na_aglomerat(input_data, hmotnosti)
        / fe_susina_aglomerat(input_data, hmotnosti)
        / 1.05
    ) * 100


@lru_cache()
def hmotnost_v_aglomerate(
    input_data: VsadzkaInput, zlozka_aglomeratu: ZlozkaAglomeratu, hmotnosti: Mapping[str, float]
) -> float:
    if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
        return suma_hmotnosti(input_data.aglorudy, hmotnosti) + vaha_podsitnych_peliet(input_data, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
        return suma_hmotnosti(input_data.koncentraty, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
        return suma_hmotnosti(input_data.prisady_do_aglomeratu, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
        return hmotnost_popola_z_aglomeracneho_koksu(input_data, hmotnosti)
    raise Exception("Unprocessed zlozka aglomeratu: {zlozka_aglomeratu}")


def hmotnost_podsitnych_peliet_do_vsadzky(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    podsitne_pelety = prisada_podsitnych_peliet(input_data, hmotnosti)
    return (
        percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(podsitne_pelety)
        / 100
        * vaha_podsitnych_peliet(input_data, hmotnosti)
    )


def hmotnost_v_aglomerate_do_vsadzky_pre_prisady(
    prisady: FrozenSet[Prisada], hmotnosti: Mapping[str, float]
) -> float:
    return sum(
        percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(prisada)
        / 100
        * hmotnosti[prisada.nazov]
        for prisada in prisady
    )


@lru_cache()
def hmotnost_v_aglomerate_do_vsadzky(
    input_data: VsadzkaInput,
    zlozka_aglomeratu: ZlozkaAglomeratu,
    hmotnosti: Mapping[str, float],
) -> float:
    if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
        return hmotnost_v_aglomerate_do_vsadzky_pre_prisady(
            input_data.aglorudy, hmotnosti
        ) + hmotnost_podsitnych_peliet_do_vsadzky(input_data, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
        return hmotnost_v_aglomerate_do_vsadzky_pre_prisady(input_data.koncentraty, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
        return hmotnost_v_aglomerate_do_vsadzky_pre_prisady(input_data.prisady_do_aglomeratu, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
        return hmotnost_popola_z_aglomeracneho_koksu(input_data, hmotnosti)
    raise Exception(f"Unprocessed zlozka aglomeratu: {zlozka_aglomeratu}")


# Divny ad hoc vypocet
@lru_cache()
def hmotnost_vapenca_2(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return suma_hmotnosti(
        [
            x
            for x in input_data.vsetky_prisady
            if x.bazicky_typ in {BazickyTyp.AGLO_VAPENEC, BazickyTyp.AGLO_DOLOMIT}
        ],
        hmotnosti,
    )


@lru_cache()
def palivo_potrebne_na_skut_vyrobu_aglomeratu(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    hmotnost_vapenca = hmotnost_vapenca_2(input_data, hmotnosti)
    if hmotnost_vapenca == 0.0:
        palivo = 0.0
    else:
        palivo = (
            hmotnost_vapenca
            * 0.1
            / (
                hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU, hmotnosti)
                + hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.KONCENTRAT, hmotnosti)
                + hmotnost_v_aglomerate(input_data, ZlozkaAglomeratu.AGLORUDA, hmotnosti)
                - hmotnost_vapenca
            )
            * 1000
        )
    return (
        (
            (
                input_data.realne_palivo_pri_p2_z_minuleho_mesiaca / 1000 * 1.3
                - input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu / 1000 * 0.1 * 1.3
            )
            * 1000
        )
        + palivo
    ) / 1.3


@lru_cache()
def hmotnost_popola_z_aglomeracneho_koksu(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        palivo_potrebne_na_skut_vyrobu_aglomeratu(input_data, hmotnosti)
        / 1000
        * (
            hmotnost_v_aglomerate_do_vsadzky(input_data, ZlozkaAglomeratu.AGLORUDA, hmotnosti)
            + hmotnost_v_aglomerate_do_vsadzky(input_data, ZlozkaAglomeratu.KONCENTRAT, hmotnosti)
            + hmotnost_v_aglomerate_do_vsadzky(input_data, ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU, hmotnosti)
        )
        * input_data.popol_koks_prach.percento_popola
        / 100
    ) + (
        input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu
        * 7.35
        / 100
        * input_data.popol_koks_prach.percento_popola
        / 100
    )


def palivova_rovnica(
    vyskyt_trosky: float,
    fe: float,
    celkovy_pridavok_vapenca: float,
    percento_popola: float,
    percento_si: float,
    hbt: float,
    eta_co: float,
    alkalie: float,
    msp: float,
    koeficient_na_spotrebu_vapenca: float,
    koeficient_na_metalicke_zelezo: float,
    vplyv_frakcie_pod_5mm: float,
) -> float:
    return (
        (((0.2 * vyskyt_trosky - 60) + (-7.5 * fe + 435)) / 2)
        + (0.1 * celkovy_pridavok_vapenca * 100)
        + (5 * percento_popola - 52.5)
        + (50 * percento_si - 25)
        + (-0.1 * hbt + 110)
        + (-7.5 * eta_co + 367.5)
        + ((25 * alkalie - 62.5) * 1 / 10)
        + msp
        + koeficient_na_spotrebu_vapenca
        + koeficient_na_metalicke_zelezo
        + vplyv_frakcie_pod_5mm
    )


def vypocet_vyskytu_trosky(sio2: float, cao: float, mgo: float, al2o3: float, fe: float, mn: float) -> float:
    return (((sio2 + cao + mgo + al2o3) / 100) * 1000) / (
        (fe + mn) / 100
    ) - fe / 100 * 0.5 * 2.14 * 1000 / 100


# divne ze to vychadza zaporne
@lru_cache()
def vyskyt_trosky_aglomerat(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        -percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Fe, hmotnosti)
        / 100
        * 0.5
        * 2.14
        * 1000
        / 100
    )


# divne ze tu neni pouzita obratena bohatost suroveho zeleza (95 / 100 = 1.052....)
def vypocet_alkalii(na2o: float, k2o: float, fe: float, mn: float) -> float:
    return (na2o + k2o) / (fe + mn) / 1.05 * 1000


@lru_cache()
def alkalie_aglomerat(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return vypocet_alkalii(
        percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Na2O, hmotnosti),
        percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.K2O, hmotnosti),
        percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Fe, hmotnosti),
        percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Mn, hmotnosti),
    )


def suma_hmotnosti(prisady: Iterable[Prisada], hmotnosti: Mapping[str, float]) -> float:
    return sum(hmotnosti[prisada.nazov] for prisada in prisady)


@lru_cache()
def percentualny_podiel_hmotnosti(
    prisada: Prisada, prisady: FrozenSet[Prisada], hmotnosti: Mapping[str, float]
) -> float:
    suma = suma_hmotnosti(prisady, hmotnosti)
    if suma == 0.0:
        return 0.0
    return hmotnosti[prisada.nazov] / suma * 100


def fe_susina_pre_prisady(prisady: FrozenSet[Prisada], hmotnosti: Mapping[str, float]) -> float:
    return sum(
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe)
        / 100
        * percentualny_podiel_hmotnosti(prisada, prisady, hmotnosti)
        for prisada in prisady
    )


def prepocitaj_oxidy(chemicke_zlozenie: ChemickeZlozenie) -> float:
    return (
        chemicke_zlozenie[ChemickaLatka.SiO2]
        + chemicke_zlozenie[ChemickaLatka.Al2O3]
        - chemicke_zlozenie[ChemickaLatka.CaO]
        - chemicke_zlozenie[ChemickaLatka.MgO]
    )


def popol_t_z_500kg_koksu_na_t_suroviny(input_data: VsadzkaInput, fe: float) -> float:
    return fe / 100 * input_data.popol_kb1.percento_popola / 100 * 0.5


# Toto je superdivne
@lru_cache()
def popol_t_z_500kg_koksu_na_t_suroviny_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.bazicky_typ != BazickyTyp.ZIADEN:
        return pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe_MET) / (
            pridavok_vapenca_prisada(input_data, prisada, hmotnosti) + 1
        )
    return popol_t_z_500kg_koksu_na_t_suroviny(
        input_data, pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe)
    ) + (
        palivo_na_aglomeracii_prisada(input_data, prisada, hmotnosti)
        * input_data.popol_koks_prach.percento_popola
        / 100
        / 1000
    )


def korekcia_sio2(sio2: float) -> float:
    # REV 6 change -> add / 100
    return sio2 - 0.5 * 30 / 14 / 100


@lru_cache(maxsize=100000)
def pomer_prvku_v_prisade_s_pridanim_vapenca(
    input_data: VsadzkaInput, prisada: Prisada, latka: ChemickaLatka, hmotnosti: Mapping[str, float]
) -> float:
    vapenec = pridavok_vapenca_prisada(input_data, prisada, hmotnosti)
    if latka == ChemickaLatka.Fe2O3:
        suma = (
            pomer_prvku_v_prisade_susina(prisada, latka)
            + vapenec * input_data.vapenec.chemicke_zlozenie[ChemickaLatka.Fe]
        )
    elif latka in {
        ChemickaLatka.Fe,
        ChemickaLatka.As,
        ChemickaLatka.C,
        ChemickaLatka.Cl,
        ChemickaLatka.H2O,
    }:
        suma = (
            pomer_prvku_v_prisade_susina(prisada, latka)
            + vapenec * input_data.vapenec.chemicke_zlozenie[latka]
        )
    else:
        suma = (
            pomer_prvku_v_prisade_susina(prisada, latka)
            + vapenec * input_data.vapenec.chemicke_zlozenie[latka]
            + popol_t_z_500kg_koksu_na_t_suroviny_prisada(input_data, prisada, hmotnosti)
            * input_data.popol_kb1.chemicke_zlozenie[latka]
        )

    pomer = suma / (1 + vapenec + popol_t_z_500kg_koksu_na_t_suroviny_prisada(input_data, prisada, hmotnosti))

    if latka in {ChemickaLatka.SiO2}:
        return korekcia_sio2(pomer)
    return pomer


def pridavok_vapenca(
    input_data: VsadzkaInput,
    sio2: float,
    al2o3: float,
    cao: float,
    mgo: float,
    s: float,
    popol_v_t_na_500_kg_tzs_koksu_plus_popol_z_aglom_paliva: float,
    typ_prisady: TypPrisady,
) -> float:
    if typ_prisady in [TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP]:
        upravene_s = 7.0901 * s
    else:
        upravene_s = 0
    return (
        (korekcia_sio2(sio2) + al2o3 - cao - mgo + upravene_s)
        + prepocitaj_oxidy(input_data.popol_kb1.chemicke_zlozenie)
        * popol_v_t_na_500_kg_tzs_koksu_plus_popol_z_aglom_paliva
    ) / (-prepocitaj_oxidy(input_data.vapenec.chemicke_zlozenie))


@lru_cache()
def pridavok_vapenca_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.bazicky_typ != BazickyTyp.ZIADEN:
        return 0.0
    return pridavok_vapenca(
        input_data,
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.SiO2),
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Al2O3),
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.CaO),
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.MgO),
        pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.S),
        popol_t_z_500kg_koksu_na_t_suroviny_prisada(input_data, prisada, hmotnosti),
        prisada.typ_prisady,
    )


def pridavok_vapenca_algo_koks_popol(input_data: VsadzkaInput, prisada: TypPrisady) -> float:
    return pridavok_vapenca(
        input_data,
        input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.SiO2],
        input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Al2O3],
        input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.CaO],
        input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.MgO],
        input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.S],
        popol_t_z_500kg_koksu_na_t_suroviny(
            input_data, input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe]
        ),
        prisada,
    )


def vypocet_pridavku_paliva_na_odparenie_vlhkosti(
    input_data: VsadzkaInput, h2o: float, fe: float, popol_h2o: float
) -> float:
    return ((h2o / fe * 1000) + (500 * popol_h2o / 100)) * (
        input_data.energia_na_odparenie_h2o / input_data.kaloriticka_hodnota_koks
    )


@lru_cache(maxsize=100000)
def pridavok_paliva_na_odparenie_vlhkosti_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.typ_prisady in {
        TypPrisady.AGLORUDA,
        TypPrisady.KONCENTRAT,
        TypPrisady.PRISADA_DO_AGLOMERATU,
        TypPrisady.VAPENEC,
    }:
        return 0.0

    return vypocet_pridavku_paliva_na_odparenie_vlhkosti(
        input_data,
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.H2O, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),
        input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.H2O],
    )


@lru_cache()
def pridavok_paliva_na_odparenie_vlhkosti(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        vypocet_pridavku_paliva_na_odparenie_vlhkosti(
            input_data,
            obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.H2O, hmotnosti),
            obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti),
            input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.H2O],
        )
        * input_data.koef_ucinnosti_zariadenia_vp
    )


def fe_susina_pre_aglorudy(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    pomer_prvku_v_prisade_susina_dict = {
        prisada.nazov: pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe)
        for prisada in input_data.aglorudy
    }
    pomer_prvku_v_prisade_susina_dict["podsitne_pelety"] = pomer_prvku_v_prisade_susina(
        prisada_podsitnych_peliet(input_data, hmotnosti), ChemickaLatka.Fe
    )
    celkova_hmotnost = suma_hmotnosti(input_data.aglorudy, hmotnosti) + vaha_podsitnych_peliet(
        input_data, hmotnosti
    )
    result = 0.0
    for k, v in pomer_prvku_v_prisade_susina_dict.items():
        if k in hmotnosti:
            result += v / 100 * (hmotnosti[k] / celkova_hmotnost * 100)
        else:
            result += v / 100 * (vaha_podsitnych_peliet(input_data, hmotnosti) / celkova_hmotnost * 100)
    return result


def fe_susina_v_zlozke_aglomeratu(
    input_data: VsadzkaInput, zlozka_aglomeratu: ZlozkaAglomeratu, hmotnosti: Mapping[str, float]
) -> float:
    if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
        return fe_susina_pre_aglorudy(input_data, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
        return fe_susina_pre_prisady(input_data.koncentraty, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
        return fe_susina_pre_prisady(input_data.prisady_do_aglomeratu, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
        return input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe] / (
            1 + pridavok_vapenca_algo_koks_popol(input_data, TypPrisady.VAPENEC)
        )
    raise Exception(f"Unprocessed zlozka aglomeratu: {zlozka_aglomeratu}")


# Super divne - raz sa pouziva hmotnost do vsadzky raz sa pouziva celkova hmotnost
def fe_susina_aglomerat(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        sum(
            fe_susina_v_zlozke_aglomeratu(input_data, zlozka_aglomeratu, hmotnosti)
            * hmotnost_v_aglomerate(input_data, zlozka_aglomeratu, hmotnosti)
            / 100
            for zlozka_aglomeratu in ZlozkaAglomeratu
        )
        / hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti)
        * 100
    )


# Super divne z manganom
@lru_cache()
def vyskyt_trosky_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    return vypocet_vyskytu_trosky(
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.SiO2, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.CaO, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.MgO, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Al2O3, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),
        (
            0.0
            if prisada.typ_prisady == TypPrisady.PRISADA_DO_AGLOMERATU
            else pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti)
        ),
    )


@lru_cache()
def alkalie_prisada(input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]) -> float:
    return vypocet_alkalii(
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Na2O, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.K2O, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti),
    )


@lru_cache()
def koeficient_na_spotrebu_vapenca_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    return (pridavok_vapenca_prisada(input_data, prisada, hmotnosti) * 1000 / 10) / (
        (
            pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti)
            + pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti)
        )
        / 100
    )


@lru_cache()
def fe_met_pri_jednotkovom_p2(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    return pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe_MET) / (
        pridavok_vapenca_prisada(input_data, prisada, hmotnosti) + 1
    )


# Super divny vypocet
@lru_cache()
def koeficient_na_metalicke_zelezo_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    # REV 6 change -> added Briketa - K
    if prisada.nazov in MET_FE_GROUP:
        base = -popol_t_z_500kg_koksu_na_t_suroviny_prisada(input_data, prisada, hmotnosti)
    else:
        base = -fe_met_pri_jednotkovom_p2(input_data, prisada, hmotnosti)
    return (
        base
        / pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti)
        / 100
        * 1000
        * 30
    )


@lru_cache()
def palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.typ_prisady == TypPrisady.PELETY:
        return palivova_rovnica(
            vyskyt_trosky_prisada(input_data, prisada, hmotnosti),  # spravne
            pomer_prvku_v_prisade_s_pridanim_vapenca(
                input_data, prisada, ChemickaLatka.Fe, hmotnosti
            ),  # spravne
            pridavok_vapenca_prisada(input_data, prisada, hmotnosti),  # okay
            input_data.popol_kb1.percento_popola,
            input_data.percento_Si,
            input_data.hbt,
            input_data.eta_co,
            alkalie_prisada(input_data, prisada, hmotnosti),  # okay
            input_data.msp,
            koeficient_na_spotrebu_vapenca_prisada(input_data, prisada, hmotnosti),  # okay
            koeficient_na_metalicke_zelezo_prisada(input_data, prisada, hmotnosti),  # okay
            prisada.rozsev_pod_5mm * 2,
        )
    return palivova_rovnica(
        vyskyt_trosky_prisada(input_data, prisada, hmotnosti),  # spravne
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),  # spravne
        pridavok_vapenca_prisada(input_data, prisada, hmotnosti),  # okay
        input_data.popol_kb1.percento_popola,
        input_data.percento_Si,
        input_data.hbt,
        input_data.eta_co,
        alkalie_prisada(input_data, prisada, hmotnosti),  # okay
        input_data.msp,
        koeficient_na_spotrebu_vapenca_prisada(input_data, prisada, hmotnosti),  # okay
        koeficient_na_metalicke_zelezo_prisada(input_data, prisada, hmotnosti),  # okay
        0,
    )


@lru_cache()
def palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return palivova_rovnica(
        vyskyt_trosky_aglomerat(input_data, hmotnosti),  # okay
        percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Fe, hmotnosti),  # okay
        0.0,
        input_data.popol_kb1.percento_popola,
        input_data.percento_Si,
        input_data.hbt,
        input_data.eta_co,
        alkalie_aglomerat(input_data, hmotnosti),  # okay
        input_data.msp,
        0.0,
        0.0,
        0.0,
    )


def mnozstvo_koksu(hmotnost: float, celkove_palivo: float, fe_susina: float) -> float:
    return hmotnost * celkove_palivo / 1000 * fe_susina / 100


@lru_cache(maxsize=10000)
def pomer_prvku_v_prisade_susina(prisada: Prisada, latka: ChemickaLatka) -> float:
    if latka == ChemickaLatka.H2O:
        return prisada.chemicke_zlozenie[ChemickaLatka.H2O]
    return (100 - prisada.chemicke_zlozenie[ChemickaLatka.H2O]) / 100 * prisada.chemicke_zlozenie[latka]


@lru_cache(maxsize=10000)
def inverzia_pomer_prvku_v_prisade_susina(chemia: float, h20: float) -> float:
    if chemia == h20:
        return chemia
    return 100 * chemia / (100 - h20)


@lru_cache()
def mnozstvo_koksu_na_prisadu(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.typ_prisady in {TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP}:
        return mnozstvo_koksu(
            hmotnosti[prisada.nazov],
            palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, prisada, hmotnosti),  # nespravne
            pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.Fe),
        )
    return 0.0


@lru_cache()
def mnozstvo_koksu_na_zlozku_vsadzky(
    input_data: VsadzkaInput, zlozka_vsadzky: ZlozkaVsadzky, hmotnosti: Mapping[str, float]
) -> float:
    if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
        return mnozstvo_koksu(
            hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti),
            palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky(input_data, hmotnosti),
            percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Fe, hmotnosti),
        )
    if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
        return sum(mnozstvo_koksu_na_prisadu(input_data, peleta, hmotnosti) for peleta in input_data.pelety)
    if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
        return sum(
            mnozstvo_koksu_na_prisadu(input_data, prisada, hmotnosti) for prisada in input_data.prisady_do_vp
        )
    if zlozka_vsadzky == ZlozkaVsadzky.VAPENEC:
        return 0.0
    if zlozka_vsadzky == ZlozkaVsadzky.POPOL_Z_PALIVA:
        return 0.0
    raise Exception("Neznama zlozka vsadzky")


@lru_cache()
def celkove_mnozstvo_paliva_do_VP(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return sum(
        mnozstvo_koksu_na_zlozku_vsadzky(input_data, zlozka_vsadzky, hmotnosti)
        for zlozka_vsadzky in ZlozkaVsadzky
    )


@lru_cache()
def hmotnost_vo_vsadzke(
    input_data: VsadzkaInput, zlozka_vsadzky: ZlozkaVsadzky, hmotnosti: Mapping[str, float]
) -> float:
    if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
        return (
            sum(
                [
                    hmotnost_v_aglomerate_do_vsadzky(input_data, zlozka, hmotnosti)
                    for zlozka in ZlozkaAglomeratu
                ]
            )
            * input_data.koeficient_vyroby_aglomeratu
        )
    if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
        return suma_hmotnosti(input_data.pelety, hmotnosti)
    if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
        return suma_hmotnosti(input_data.prisady_do_vp, hmotnosti)
    if zlozka_vsadzky == ZlozkaVsadzky.VAPENEC:
        return hmotnosti[input_data.vapenec.nazov]
    if zlozka_vsadzky == ZlozkaVsadzky.POPOL_Z_PALIVA:
        return (
            celkove_mnozstvo_paliva_do_VP(input_data, hmotnosti) * input_data.popol_kb1.percento_popola / 100
        )
    raise Exception("Neznama zlozka vsadzky")


def percentualny_obsah(
    prisady: FrozenSet[Prisada], latka: ChemickaLatka, hmotnosti: Mapping[str, float]
) -> float:
    celkova_hmotnost_prisad = suma_hmotnosti(prisady, hmotnosti)
    if celkova_hmotnost_prisad == 0.0:
        return 0.0
    return sum(
        (pomer_prvku_v_prisade_susina(prisada, latka) / 100)
        * (hmotnosti[prisada.nazov] * 100)
        / celkova_hmotnost_prisad
        for prisada in prisady
    )


def percentualny_obsah_pre_prisadu(
    prisada: Prisada,
    latka: ChemickaLatka,
    celkova_hmotnost_prisad: float,
    hmotnosti: Mapping[str, float],
    hmotnost_podsitnych_peliet: float = 0,
) -> float:
    # if hmotnost_podsitnych_peliet != 0:
    #     return (
    #         (pomer_prvku_v_prisade_susina(prisada, latka) / 100)
    #         * (hmotnost_podsitnych_peliet * 100)
    #         / celkova_hmotnost_prisad
    #     )
    if prisada.nazov == "Podsitne_pelety":
        return (
            (pomer_prvku_v_prisade_susina(prisada, latka) / 100)
            * (hmotnost_podsitnych_peliet * 100)
            / celkova_hmotnost_prisad
        )
    return (
        (pomer_prvku_v_prisade_susina(prisada, latka) / 100)
        * (hmotnosti[prisada.nazov] * 100)
        / celkova_hmotnost_prisad
    )


def percentualny_obsah_aglorudy(
    input_data: VsadzkaInput, latka: ChemickaLatka, hmotnosti: Mapping[str, float]
) -> float:
    celkova_hmotnost_prisad = suma_hmotnosti(input_data.aglorudy, hmotnosti) + vaha_podsitnych_peliet(
        input_data, hmotnosti
    )
    if celkova_hmotnost_prisad == 0.0:
        return 0.0
    suma_bez_peliet = sum(
        percentualny_obsah_pre_prisadu(prisada, latka, celkova_hmotnost_prisad, hmotnosti)
        for prisada in input_data.aglorudy
    )
    return suma_bez_peliet + percentualny_obsah_pre_prisadu(
        prisada_podsitnych_peliet(input_data, hmotnosti),
        latka,
        celkova_hmotnost_prisad,
        hmotnosti,
        vaha_podsitnych_peliet(input_data, hmotnosti),
    )


# Ten if je tam len kvoli kompatibilite s excelom
@lru_cache(maxsize=len(ChemickaLatka) * len(ZlozkaAglomeratu))
def percentualny_obsah_v_zlozke_aglomeratu(
    input_data: VsadzkaInput,
    latka: ChemickaLatka,
    zlozka_aglomeratu: ZlozkaAglomeratu,
    hmotnosti: Mapping[str, float],
) -> float:
    if latka == ChemickaLatka.Fe_MET:
        return 0.0
    if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
        return percentualny_obsah_aglorudy(input_data, latka, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
        return percentualny_obsah(input_data.koncentraty, latka, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
        return percentualny_obsah(input_data.prisady_do_aglomeratu, latka, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
        return input_data.popol_kb1.chemicke_zlozenie[latka]
    raise Exception("Neznama zlozka aglomeratu")


def percentualny_obsah_latky_v_aglomerate_susina(
    input_data: VsadzkaInput, latka: ChemickaLatka, hmotnosti: Mapping[str, float]
) -> float:
    if latka in {ChemickaLatka.H2O, ChemickaLatka.Fe_MET}:
        return 0.0
    if latka == ChemickaLatka.Fe:
        return fe_susina_aglomerat(input_data, hmotnosti)
    if latka == ChemickaLatka.FeO:
        return 7.0  # Priemer z mesacnej analyzy
    if latka == ChemickaLatka.Fe2O3:
        return (
            percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.Fe, hmotnosti)
            - percentualny_obsah_latky_v_aglomerate_susina(input_data, ChemickaLatka.FeO, hmotnosti) * 0.7778
        ) / 0.7
    if latka == ChemickaLatka.C:
        return 0.1  # Priemer z mesacnej analyzy
    return (
        sum(
            percentualny_obsah_v_zlozke_aglomeratu(input_data, latka, zlozka, hmotnosti)
            * hmotnost_v_aglomerate(input_data, zlozka, hmotnosti)
            / 100
            for zlozka in ZlozkaAglomeratu
        )
        / sum(hmotnost_v_aglomerate_do_vsadzky(input_data, zlozka, hmotnosti) for zlozka in ZlozkaAglomeratu)
        * 100
    )


@lru_cache(maxsize=len(ChemickaLatka) * len(ZlozkaVsadzky))
def percentualny_obsah_v_zlozke_vsadzky(
    input_data: VsadzkaInput,
    latka: ChemickaLatka,
    zlozka_vsadzky: ZlozkaVsadzky,
    hmotnosti: Mapping[str, float],
) -> float:
    if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
        return percentualny_obsah_latky_v_aglomerate_susina(input_data, latka, hmotnosti)
    if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
        return percentualny_obsah(input_data.pelety, latka, hmotnosti)
    if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
        return percentualny_obsah(input_data.prisady_do_vp, latka, hmotnosti)
    if zlozka_vsadzky == ZlozkaVsadzky.VAPENEC:
        return pomer_prvku_v_prisade_susina(input_data.vapenec, latka)
    if zlozka_vsadzky == ZlozkaVsadzky.POPOL_Z_PALIVA:
        return input_data.popol_kb1.chemicke_zlozenie[latka]
    raise Exception("Neznama zlozka vsadzky")


@lru_cache()
def pomer_zlozky_vsadzky_vo_vsadzke(
    input_data: VsadzkaInput, zlozka_vsadzky: ZlozkaVsadzky, hmotnosti: Mapping[str, float]
) -> float:
    return (
        hmotnost_vo_vsadzke(input_data, zlozka_vsadzky, hmotnosti)
        / celkova_hmotnost_vsadzky(input_data, hmotnosti)
        * 100
    )


@lru_cache()
def obsah_chemickej_latky_vo_vsadzke(
    input_data: VsadzkaInput, latka: ChemickaLatka, hmotnosti: Mapping[str, float]
) -> float:
    # REV 6 change H20 added to this if
    if latka in ASH_BURN_COMPONENTS:  # Nepocita sa z popola lebo vyhori
        zlozky = [x for x in ZlozkaVsadzky if x != ZlozkaVsadzky.POPOL_Z_PALIVA]
    else:
        zlozky = list(ZlozkaVsadzky)
    obsahy = {
        zlozka: (
            percentualny_obsah_v_zlozke_vsadzky(input_data, latka, zlozka, hmotnosti)  # okay
            / 100
            * pomer_zlozky_vsadzky_vo_vsadzke(input_data, zlozka, hmotnosti)
        )
        for zlozka in zlozky
    }
    if latka == ChemickaLatka.SiO2:  # Zistit preco tam je korekcia len pre SiO2
        sio2_popol_korekcia = (
            -0.5 * obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti) / 100 * 60 / 28
        )
        return sum(obsahy.values()) + sio2_popol_korekcia
    if latka == ChemickaLatka.CaO:
        return sum(obsahy.values()) - prepocet_cao_na_vapenec(input_data, hmotnosti)
    return sum(obsahy.values())


def cao_na_odsirenie(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return (
        vstup_s_spolu(input_data, korigovane_hmotnosti)
        * hmotnost_vyroby_suroveho_fe(input_data, korigovane_hmotnosti)
        / 32
        * 56
        / 1000
    )


def prepocet_cao_na_vapenec(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return (
        cao_na_odsirenie(input_data, korigovane_hmotnosti)
        / celkova_hmotnost_vsadzky(input_data, korigovane_hmotnosti)
        * 100
    )


def vstup_s_spolu(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return vstupna_s_z_paliva_na_t_fe_rudna_vsadzka(
        input_data, korigovane_hmotnosti
    ) + vstupna_s_z_paliva_na_t_fe_palivo(input_data, korigovane_hmotnosti)


def vstupna_s_z_paliva_na_t_fe_rudna_vsadzka(
    input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]
) -> float:
    return (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.S, korigovane_hmotnosti)
        / 100
        * hmotnost_rudnej_vsadzky(input_data, korigovane_hmotnosti)
        * 1000
        / hmotnost_vyroby_suroveho_fe(input_data, korigovane_hmotnosti)
    )


def hmotnost_rudnej_vsadzky(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return sum(
        hmotnost_vo_vsadzke(input_data, zlozka, korigovane_hmotnosti)
        for zlozka in ZlozkaVsadzky
        if zlozka != ZlozkaVsadzky.POPOL_Z_PALIVA
    )


def hmotnost_koks(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return hmotnost_vyroby_suroveho_fe(input_data, korigovane_hmotnosti) * hmotnost_msp_msk(input_data) / 1000


def hmotnost_pu(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return hmotnost_vyroby_suroveho_fe(input_data, korigovane_hmotnosti) * input_data.hmotnost_mspu / 1000


def vstupna_s_z_paliva_na_t_fe_palivo(
    input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]
) -> float:
    i207 = (
        hmotnost_koks(input_data, korigovane_hmotnosti)
        * np.mean(
            [
                input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.S],
                input_data.popol_kb3.chemicke_zlozenie[ChemickaLatka.S],
            ]
        )
        / 100
    )
    i208 = (
        hmotnost_pu(input_data, korigovane_hmotnosti)
        * input_data.popol_pu.chemicke_zlozenie[ChemickaLatka.S]
        / 100
    )
    return float((i207 + i208) * 1000 / hmotnost_vyroby_suroveho_fe(input_data, korigovane_hmotnosti))


def hmotnost_vyroby_suroveho_fe(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return celkovy_vytazok_fe(input_data, korigovane_hmotnosti) - strata_vyhodzu_kalu(
        input_data, korigovane_hmotnosti
    )


def strata_vyhodzu_kalu(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    r183 = input_data.percento_fe_kal / 100 * 13 / 1000 * celkovy_vytazok_fe(input_data, korigovane_hmotnosti)
    r184 = (
        input_data.percento_fe_vyhoz / 100 * 7 / 1000 * celkovy_vytazok_fe(input_data, korigovane_hmotnosti)
    )
    return r183 + r184


def hmotnost_msp_msk(input_data: VsadzkaInput) -> float:
    return 500 - input_data.planovane_mnozstvo_zp - input_data.planovane_mnozstvo_pu


def penalta(
    penalizovana_latka: float,
    priemerne_percento: float,
    penalizacna_konstanta: float,
    fe: float,
    mn: float,
) -> float:
    return ((penalizovana_latka - priemerne_percento) / 0.01 * penalizacna_konstanta) / (fe + mn) * 100


def suma_vahy_peliet_do_aglomeracie(
    korigovane_hmotnosti: Mapping[str, float], hmotnosti: Mapping[str, float], pellets_dict: Dict
) -> float:
    suma_vahy = 0.0
    for k, v in korigovane_hmotnosti.items():
        if k in pellets_dict:
            suma_vahy += hmotnosti[k] - v
    return suma_vahy


def vaha_podsitnych_peliet(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    prisady_peliet = {x.nazov: x for x in input_data.vsetky_prisady if x.typ_prisady == TypPrisady.PELETY}
    hmotnosti = inverzna_korekcia_hmotnosti(input_data, korigovane_hmotnosti)
    suma_vahy = sum(
        [v * prisady_peliet[k].rozsev_pod_5mm / 100 for k, v in hmotnosti.items() if k in prisady_peliet]
    )
    return (
        suma_vahy / input_data.koef_odtriedenia_peliet * (1 - input_data.koef_odtriedenia_peliet)
        if input_data.koef_odtriedenia_peliet != 1
        else 0
    )


def celkova_vaha_peliet(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return sum(
        [
            (-hmotnosti[prisada.nazov] * input_data.koef_odtriedenia_peliet * prisada.rozsev_pod_5mm / 100)
            + hmotnosti[prisada.nazov]
            for prisada in input_data.pelety
        ]
    )


def pomer_vahy_pelety(
    input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float], prisada: Prisada
) -> float:
    hmotnosti = inverzna_korekcia_hmotnosti(input_data, korigovane_hmotnosti)
    return 100 / celkova_vaha_peliet(input_data, hmotnosti) * korigovane_hmotnosti[prisada.nazov]


def cena_podsitnych_peliet(input_data: VsadzkaInput, korigovane_hmotnosti: Mapping[str, float]) -> float:
    return sum(
        [
            peleta.cena_za_tonu / 100 * pomer_vahy_pelety(input_data, korigovane_hmotnosti, peleta)
            for peleta in input_data.pelety
        ]
    )


def chemicke_zlozenie_pre_zlozku(
    input_data: VsadzkaInput, zlozka_vsadzky: ZlozkaVsadzky, hmotnosti: Mapping[str, float]
) -> ChemickeZlozenie:
    return tuple(
        percentualny_obsah_v_zlozke_vsadzky(input_data, latka, zlozka_vsadzky, hmotnosti)
        for latka in ChemickaLatka
    )


def prisada_podsitnych_peliet(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> Prisada:
    chem_zlozenie = chemicke_zlozenie_pre_zlozku(input_data, ZlozkaVsadzky.PELETY, hmotnosti)
    return Prisada(
        nazov="Podsitne_pelety",
        cena_za_tonu=cena_podsitnych_peliet(input_data, hmotnosti),
        chemicke_zlozenie=tuple(
            inverzia_pomer_prvku_v_prisade_susina(chemia, chem_zlozenie[1]) for chemia in chem_zlozenie
        ),
        typ_prisady=TypPrisady.AGLORUDA,
        bazicky_typ=BazickyTyp.ZIADEN,
        aglomeracny_typ=AglomeracnyTyp.AGLORUDA,
    )


@lru_cache()
def penalta_na_P(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return penalta(
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.P, hmotnosti),
        input_data.priemerne_percento_P,
        1.07,
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Mn, hmotnosti),
    )


@lru_cache()
def penalta_na_S(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return penalta(
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.S, hmotnosti),
        input_data.priemerne_percento_S,
        0.71,
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti),
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Mn, hmotnosti),
    )


# Super divny vypocet
@lru_cache(maxsize=128)
def percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(prisada: Prisada) -> float:
    if prisada.typ_prisady == TypPrisady.PELETY:
        vynechane_latky = {ChemickaLatka.Fe, ChemickaLatka.H2O, ChemickaLatka.Fe_MET}
    elif prisada.typ_prisady == TypPrisady.PRISADY_DO_VP:
        if prisada.nazov == "SB-KUS":
            vynechane_latky = {ChemickaLatka.Fe, ChemickaLatka.H2O, ChemickaLatka.C}
        else:
            vynechane_latky = {ChemickaLatka.Fe, ChemickaLatka.H2O}
    else:
        vynechane_latky = {ChemickaLatka.Fe, ChemickaLatka.H2O, ChemickaLatka.C}
    return sum(
        pomer_prvku_v_prisade_susina(prisada, latka)
        for latka in ChemickaLatka
        if latka not in vynechane_latky
    )


@lru_cache()
def percentualny_podiel_prvkov_v_surovine_v_dodanom_stave(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return sum(
        obsah_chemickej_latky_vo_vsadzke(input_data, latka, hmotnosti)
        for latka in ChemickaLatka
        if latka not in {ChemickaLatka.Fe, ChemickaLatka.H2O, ChemickaLatka.C}
    )


def cena_paliva_do_vp(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, hmotnosti)
        / 1000
        * input_data.popol_kb1.percento_popola
        / 100
        * input_data.cena_vp_koksu
    )


@lru_cache()
def prepoctova_cena(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float], korigovane_hmotnosti: Mapping[str, float]
) -> float:
    cena_vsadzky = (
        (
            cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(input_data, korigovane_hmotnosti)  # spravne
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, korigovane_hmotnosti)
        )
        + (
            vazeny_priemer_ceny(input_data.pelety, hmotnosti, korigovane_hmotnosti)
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.PELETY, korigovane_hmotnosti)
        )
        + (
            vazeny_priemer_ceny(input_data.prisady_do_vp, hmotnosti, korigovane_hmotnosti)
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.PRISADY_DO_VP, korigovane_hmotnosti)
        )
        + (
            input_data.vapenec.cena_za_tonu
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.VAPENEC, korigovane_hmotnosti)
        )
    ) / celkova_hmotnost_vsadzky(input_data, korigovane_hmotnosti)
    # REV 6 change cena_paliva_do_vp(input_data, hmotnosti) removed from sum
    return cena_vsadzky


@lru_cache()
def cena_suroviny_na_tonu_fe(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float], nekorigovane_hmotnosti
) -> float:
    return (
        100
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * (
            sum(
                nekorigovane_hmotnosti[prisada.nazov] * prisada.cena_za_tonu
                for prisada in input_data.vsetky_prisady
            )
            / celkova_hmotnost_vsadzky(input_data, hmotnosti)
        )
    )


@lru_cache()
def cena_paliva_na_tonu_fe_z_bvs_bez_penalt(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return (
        celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, hmotnosti)
        / 1000
        * input_data.cena_vp_koksu
    )


@lru_cache()
def cena_paliva_na_tonu_fe_z_bvs(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        (vp_metalurg(input_data, hmotnosti) / 1000 * input_data.cena_vp_koksu)
        + (input_data.planovane_mnozstvo_zp * input_data.cena_zp)
        + (input_data.planovane_mnozstvo_pu / 1000 * input_data.cena_pu)
        + penalta_na_P(input_data, hmotnosti)
        + penalta_na_S(input_data, hmotnosti)
    )


def vp_metalurg(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        vypocet_paliva(input_data, hmotnosti)
        - input_data.celkove_palivo_uhlie
        - input_data.celkove_palivo_koks_orech
    )


def cena_co2_na_vysokej_peci(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, hmotnosti)
        / 1000
        * sum(
            percentualny_podiel_paliva(input_data, typ_paliva)
            / 100
            * co2_z_tony_paliva(input_data, typ_paliva)
            for typ_paliva in TypPaliva
        )
        * input_data.cena_tony_co2
    )


@lru_cache()
def cena_co2(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return cena_co2_na_vysokej_peci(input_data, hmotnosti) + cena_co2_v_tonach_na_1_tsz_zo_suroviny(
        input_data, hmotnosti
    )


@lru_cache()
def spracovacie_naklady_na_tonu_fe_na_vp(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        percentualny_podiel_prvkov_v_surovine_v_dodanom_stave(input_data, hmotnosti)
        / 100
        * input_data.bvs_minuly_mesiac
        / 100
        * input_data.spracovacie_naklady_na_tonu_suroveho_zeleza
    )


# def celkova_cena_za_tonu_zeleza(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
#     return (
#         (
#             100
#             / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
#             * prepoctova_cena(input_data, hmotnosti)
#         )
#         + cena_paliva_na_tonu_fe_z_bvs(input_data, hmotnosti)
#         + cena_co2(input_data, hmotnosti)
#         + spracovacie_naklady_na_tonu_fe_na_vp(input_data, hmotnosti)
#     )


@lru_cache()
def cena_paliva_do_vp_na_tonu_fe(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        100
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * cena_paliva_do_vp(input_data, hmotnosti)
    )


@lru_cache()
def spracovacie_naklady_na_tonu_fe_na_aglomeracii(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float]
) -> float:
    return (
        100
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * (
            input_data.spracovacie_naklady_na_tonu_aglomeratu
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti)
            / celkova_hmotnost_vsadzky(input_data, hmotnosti)
        )
    )


@lru_cache()
def cena_co2_na_tonu_fe_na_aglomeracii(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        100
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * (
            (mnozstvo_co2_na_t_fe_z_aglomeratu(input_data, hmotnosti) * input_data.cena_tony_co2)
            * hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti)
            / celkova_hmotnost_vsadzky(input_data, hmotnosti)
        )
    )


@lru_cache()
def cena_paliva_na_aglomeracii(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        100
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * (cena_aglomeracneho_paliva(input_data, hmotnosti) / celkova_hmotnost_vsadzky(input_data, hmotnosti))
    )


def celkova_cena_za_tonu_zeleza(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float], korigovane_hmotnosti: Mapping[str, float]
) -> float:
    # REV 6 change
    # =IF(C180=0;"";(100/AD180*AB180)+BP180+BQ180+BB180)
    prepocet_ceny = prepoctova_cena(input_data, hmotnosti, korigovane_hmotnosti)
    if prepocet_ceny == 0:
        return 0
    return (
        (
            100
            / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, korigovane_hmotnosti)
            * prepoctova_cena(input_data, hmotnosti, korigovane_hmotnosti)
        )
        + cena_paliva_na_tonu_fe_z_bvs(input_data, korigovane_hmotnosti)
        + cena_co2(input_data, korigovane_hmotnosti)
        + spracovacie_naklady_na_tonu_fe_na_vp(input_data, korigovane_hmotnosti)
    )


def celkovy_koeficient_na_met_fe(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        -obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe_MET, hmotnosti)
        / obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
        * 1.05
        / 100
        * 1000
        * 30
    )


# super divne ze to neni rovnake ako celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky
def vypocet_paliva(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    # REV 6 change pridane pridavok paliva a celkova bazicita

    return (
        (
            palivova_rovnica(
                celkovy_vyskyt_trosky(input_data, hmotnosti),
                obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Fe, hmotnosti)
                * input_data.koef_na_bvs,
                celkova_spotreba_vapenca_so_stratami(input_data, hmotnosti) / 100.0,
                input_data.popol_kb1.percento_popola,
                input_data.percento_Si,
                input_data.hbt,
                input_data.eta_co,
                celkova_hmotnost_alkalii(input_data, hmotnosti),
                input_data.msp,
                0.0,
                celkovy_koeficient_na_met_fe(input_data, hmotnosti),
                0.0,
            )
            + pridavok_paliva_na_odparenie_vlhkosti(input_data, hmotnosti)
            + (celkova_bazicita(input_data, hmotnosti) * 100 - 100)
            - input_data.msp
        )
        * 5
        / 6
    ) + input_data.msp


def stratova_konstata_kal(input_data: VsadzkaInput) -> float:
    return input_data.percento_fe_kal / 100 * 13 / 1000


def stratova_konstanta_vyhoz(input_data: VsadzkaInput) -> float:
    return input_data.percento_fe_vyhoz / 100 * 7 / 1000


def fe_kal(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return stratova_konstata_kal(input_data) * celkovy_vytazok_fe(input_data, hmotnosti)


def vyhoz(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return stratova_konstanta_vyhoz(input_data) * celkovy_vytazok_fe(input_data, hmotnosti)


def straty_fe(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return fe_kal(input_data, hmotnosti) + vyhoz(input_data, hmotnosti)


def celkovy_vytazok_fe_so_stratami(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return celkovy_vytazok_fe(input_data, hmotnosti) - straty_fe(input_data, hmotnosti)


def celkova_bazicita(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.CaO, hmotnosti)
        + obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.MgO, hmotnosti)
    ) / (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.SiO2, hmotnosti)
        + obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Al2O3, hmotnosti)
    )


def celkovy_zn(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Zn, hmotnosti)
        * celkova_hmotnost_vsadzky(input_data, hmotnosti)
        / 100
        * 1000
        * 1000
        / celkovy_vytazok_fe(input_data, hmotnosti)
    )


def celkova_hmotnost_alkalii(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        (
            obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Na2O, hmotnosti)
            + obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.K2O, hmotnosti)
        )
        * celkova_hmotnost_vsadzky(input_data, hmotnosti)
        / celkovy_vytazok_fe(input_data, hmotnosti)
        / 100
        * 1000
    )


def percento_P(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.P, hmotnosti)
        * celkova_hmotnost_vsadzky(input_data, hmotnosti)
        / celkovy_vytazok_fe(input_data, hmotnosti)
    )


def percento_Mn(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.Mn, hmotnosti)
        * celkova_hmotnost_vsadzky(input_data, hmotnosti)
        / celkovy_vytazok_fe(input_data, hmotnosti)
        * 0.8
    )


# divny vypocet
def pomer_kc_ar(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return suma_hmotnosti(
        [
            prisada
            for prisada in input_data.vsetky_prisady
            if prisada.aglomeracny_typ == AglomeracnyTyp.KONCENTRAT
        ],
        hmotnosti,
    ) / (
        suma_hmotnosti(
            [
                prisada
                for prisada in input_data.vsetky_prisady
                if prisada.aglomeracny_typ == AglomeracnyTyp.AGLORUDA
            ],
            hmotnosti,
        )
        + vaha_podsitnych_peliet(input_data, hmotnosti)
    )


def q_spalin(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return input_data.korekcny_koeficient_pre_S_do_aglomeratu * hmotnost_vo_vsadzke(
        input_data, ZlozkaVsadzky.AGLOMERAT, hmotnosti
    )


# TODO solve better
def s_po_zihani_prisada(prisada: Prisada) -> float:
    if prisada.nazov == "MIK-VAP":
        multiplier = (100 - pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.C)) / 100
    else:
        multiplier = 1.0
    return pomer_prvku_v_prisade_susina(prisada, ChemickaLatka.S) * prisada.pomer_prechodu_s * multiplier


def vazeny_sucet_s_po_zihani(prisady: FrozenSet[Prisada], hmotnosti: Mapping[str, float]) -> float:
    return sum(
        (s_po_zihani_prisada(prisada)) * hmotnosti[prisada.nazov] for prisada in prisady
    ) / suma_hmotnosti(prisady, hmotnosti)


def korekcia_hmotnosti_vazeny_sucet_po_zihani(
    input_data: VsadzkaInput, hmotnosti: Mapping[str, float], vazeny_sucet: float
) -> float:
    suma_hmotnosti_bez_podsitnych_peliet = suma_hmotnosti(input_data.aglorudy, hmotnosti)
    return (
        vazeny_sucet
        * suma_hmotnosti_bez_podsitnych_peliet
        / (suma_hmotnosti_bez_podsitnych_peliet + vaha_podsitnych_peliet(input_data, hmotnosti))
    )


def s_po_zihani_v_aglomerate(
    input_data: VsadzkaInput, zlozka_aglomeratu: ZlozkaAglomeratu, hmotnosti: Mapping[str, float]
) -> float:
    if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
        return korekcia_hmotnosti_vazeny_sucet_po_zihani(
            input_data, hmotnosti, vazeny_sucet_s_po_zihani(input_data.aglorudy, hmotnosti)
        )
    if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
        return vazeny_sucet_s_po_zihani(input_data.koncentraty, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
        return vazeny_sucet_s_po_zihani(input_data.prisady_do_aglomeratu, hmotnosti)
    if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
        return input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.S]
    raise Exception("Neznama zlozka aglomeratu")


# 0.67 by asi tiez mal byt vstup
def s_po_zihani_prechadza_do_aglomeratu(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        sum(
            hmotnost_v_aglomerate(input_data, zlozka_aglomeratu, hmotnosti)
            * s_po_zihani_v_aglomerate(input_data, zlozka_aglomeratu, hmotnosti)
            / 100
            for zlozka_aglomeratu in ZlozkaAglomeratu
        )
        * 0.67
    )


def s_zo_vsadzky(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return sum(
        percentualny_obsah_v_zlozke_aglomeratu(input_data, ChemickaLatka.S, zlozka_aglomeratu, hmotnosti)
        * hmotnost_v_aglomerate(input_data, zlozka_aglomeratu, hmotnosti)
        / 100
        for zlozka_aglomeratu in ZlozkaAglomeratu
    )


def celkove_so2(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        (s_zo_vsadzky(input_data, hmotnosti) - s_po_zihani_prechadza_do_aglomeratu(input_data, hmotnosti))
        * 1000000000
        / q_spalin(input_data, hmotnosti)
        * 2
    )


def mgo_v_troske(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    mgo = obsah_chemickej_latky_vo_vsadzke(input_data, ChemickaLatka.MgO, hmotnosti)
    hmotnost_vsadzky = celkova_hmotnost_vsadzky(input_data, hmotnosti)
    vyskyt_trosky = celkovy_vyskyt_trosky(input_data, hmotnosti)
    vytazok_fe = celkovy_vytazok_fe_so_stratami(input_data, hmotnosti)
    return (mgo / 100 * hmotnost_vsadzky) / (vyskyt_trosky / 1000 * vytazok_fe) * 100


def bazicita_aglomeratu(input_data: VsadzkaInput, hmotnosti: Mapping[str, float]) -> float:
    return (
        percentualny_obsah_v_zlozke_vsadzky(input_data, ChemickaLatka.CaO, ZlozkaVsadzky.AGLOMERAT, hmotnosti)
        + percentualny_obsah_v_zlozke_vsadzky(
            input_data, ChemickaLatka.MgO, ZlozkaVsadzky.AGLOMERAT, hmotnosti
        )
    ) / (
        percentualny_obsah_v_zlozke_vsadzky(
            input_data, ChemickaLatka.SiO2, ZlozkaVsadzky.AGLOMERAT, hmotnosti
        )
        + percentualny_obsah_v_zlozke_vsadzky(
            input_data, ChemickaLatka.Al2O3, ZlozkaVsadzky.AGLOMERAT, hmotnosti
        )
    )


def spracovacie_naklady_na_tonu_fe_na_vp_prisada(input_data: VsadzkaInput, prisada: Prisada) -> float:
    return (
        (percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(prisada) / 100)
        * (input_data.bvs_minuly_mesiac / 100)
        * input_data.spracovacie_naklady_na_tonu_suroveho_zeleza
    )


def cena_co2_prisada(input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]) -> float:
    return (
        palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, prisada, hmotnosti)
        / 1000
        * sum(
            percentualny_podiel_paliva(input_data, typ_paliva)
            / 100
            * co2_z_tony_paliva(input_data, typ_paliva)
            for typ_paliva in TypPaliva
        )
        * input_data.cena_tony_co2
    ) + cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada(input_data, prisada, hmotnosti)


def penalta_na_P_prisada(input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]):
    return penalta(
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.P, hmotnosti),
        input_data.priemerne_percento_P,
        1.07,
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti),
    )


def penalta_na_S_prisada(input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]):
    return penalta(
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.S, hmotnosti),
        input_data.priemerne_percento_S,
        0.71,
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti),
        pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Mn, hmotnosti),
    )


def cena_paliva_na_tonu_fe_z_bvs_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if prisada.bazicky_typ != BazickyTyp.ZIADEN:
        return 0.0
    return (
        (
            palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(input_data, prisada, hmotnosti)
            / 1000
            * input_data.cena_vp_koksu
        )
        + penalta_na_P_prisada(input_data, prisada, hmotnosti)
        + penalta_na_S_prisada(input_data, prisada, hmotnosti)
    )


def cena_prepoctova_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    # REV 6 change - prisada.cena_za_tonu -> (prisada.cena_za_tonu * (1 - pridavok))
    pridavok = pridavok_vapenca_prisada(input_data, prisada, hmotnosti)
    return (
        (prisada.cena_za_tonu * (1 - pridavok))
        + ((prisada.cena_za_tonu * prisada.rozsev_pod_5mm / 100) * (1 - input_data.koef_odtriedenia_peliet))
        + (pridavok * input_data.vapenec.cena_za_tonu)
    )


def mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    if not prisada.typ_prisady in {
        TypPrisady.PRISADA_DO_AGLOMERATU,
        TypPrisady.KONCENTRAT,
        TypPrisady.AGLORUDA,
        TypPrisady.VAPENEC,  # Vapenec tu je len pre kompatibilitu s excelom
    }:
        return 0.0
    if prisada.nazov in {"VYHOZ VP1"}:  # Pre kompatibilitu s excelom - vyhodit
        return 0.0
    x1 = (
        palivo_na_aglomeracii_prisada(input_data, prisada, hmotnosti)
        / 1000
        * input_data.co2_z_koks_prach
        * input_data.cena_tony_co2
    )
    x2 = cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada(input_data, prisada, hmotnosti)
    if prisada.nazov in {"AR-KB57"}:  # Pre kompatibilitu s excelom - vyhodit
        return x1
    return x1 + x2


def celkova_cena_za_tonu_fe_prisada(
    input_data: VsadzkaInput, prisada: Prisada, hmotnosti: Mapping[str, float]
) -> float:
    try:
        cena = cena_prepoctova_prisada(input_data, prisada, hmotnosti)
        if cena == 0.0:
            return float("inf")
        fe = pomer_prvku_v_prisade_s_pridanim_vapenca(input_data, prisada, ChemickaLatka.Fe, hmotnosti)
        if fe == 0.0:
            return float("inf")
        return (
            ((100 / fe) * cena)
            + cena_paliva_na_tonu_fe_z_bvs_prisada(input_data, prisada, hmotnosti)
            + cena_co2_prisada(input_data, prisada, hmotnosti)
            + spracovacie_naklady_na_tonu_fe_na_vp_prisada(input_data, prisada)
            + mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada(input_data, prisada, hmotnosti)
        )
    except ZeroDivisionError:
        return float("inf")


def korigovana_hmotnost(orig_hmotnost: float, prisada: Prisada, koef_odtriedenia_peliet: float) -> float:
    if prisada.typ_prisady == TypPrisady.PELETY:
        return ((-orig_hmotnost) * koef_odtriedenia_peliet * (prisada.rozsev_pod_5mm / 100)) + orig_hmotnost
    return orig_hmotnost


def inverzna_korigovana_hmotnost(hmotnost: float, prisada: Prisada, koef_odtriedenia_peliet: float) -> float:
    if prisada.typ_prisady == TypPrisady.PELETY:
        return hmotnost / (1 - koef_odtriedenia_peliet * prisada.rozsev_pod_5mm / 100)
    return hmotnost


def korekcia_hmotnosti(
    input_data: VsadzkaInput, hmotnosti_prisad: Mapping[str, float]
) -> Mapping[str, float]:
    prisady = {x.nazov: x for x in input_data.vsetky_prisady}
    return Map(
        {
            k: korigovana_hmotnost(v, prisady[k], input_data.koef_odtriedenia_peliet)
            for k, v in hmotnosti_prisad.items()
        }
    )


def inverzna_korekcia_hmotnosti(
    input_data: VsadzkaInput, hmotnosti_prisad: Mapping[str, float]
) -> Mapping[str, float]:
    prisady = {x.nazov: x for x in input_data.vsetky_prisady}
    return Map(
        {
            k: inverzna_korigovana_hmotnost(v, prisady[k], input_data.koef_odtriedenia_peliet)
            for k, v in hmotnosti_prisad.items()
        }
    )


def model_vsadzky(input_data: VsadzkaInput, hmotnosti_prisad: Mapping[str, float]) -> VsadzkaOutput:
    korigovane_hmotnosti = korekcia_hmotnosti(input_data, hmotnosti_prisad)
    return VsadzkaOutput(
        celkova_cena_za_tonu_zeleza=celkova_cena_za_tonu_zeleza(
            input_data, hmotnosti_prisad, korigovane_hmotnosti
        ),
        vypocet_paliva=vypocet_paliva(input_data, korigovane_hmotnosti),
        vytazok_fe=celkovy_vytazok_fe_so_stratami(input_data, korigovane_hmotnosti),
        vyskyt_trosky=celkovy_vyskyt_trosky(input_data, korigovane_hmotnosti),
        bazicita=celkova_bazicita(input_data, korigovane_hmotnosti),
        BVS=fe_surove_zelezo_s_bvs(input_data, korigovane_hmotnosti),
        hmotnost_vsadzky=celkova_hmotnost_vsadzky(input_data, korigovane_hmotnosti),
        zn=celkovy_zn(input_data, korigovane_hmotnosti),
        alkalie=celkova_hmotnost_alkalii(input_data, korigovane_hmotnosti),
        p=percento_P(input_data, korigovane_hmotnosti),
        mn=percento_Mn(input_data, korigovane_hmotnosti),
        pomer_kc_ar=pomer_kc_ar(input_data, korigovane_hmotnosti),
        celkove_so2=celkove_so2(input_data, korigovane_hmotnosti),
        mgo_v_troske=mgo_v_troske(input_data, korigovane_hmotnosti),
        hmotnost_aglomeratu=hmotnost_vo_vsadzke(input_data, ZlozkaVsadzky.AGLOMERAT, korigovane_hmotnosti),
        cena_surovin=cena_suroviny_na_tonu_fe(input_data, korigovane_hmotnosti, hmotnosti_prisad),
        cena_paliva_vp=cena_paliva_na_tonu_fe_z_bvs_bez_penalt(input_data, korigovane_hmotnosti),
        cena_paliva_suroviny=0.0,
        cena_paliva_aglomeracia=cena_paliva_na_aglomeracii(input_data, korigovane_hmotnosti),
        cena_co2_vp=cena_co2_na_vysokej_peci(input_data, korigovane_hmotnosti),
        cena_co2_suroviny=cena_co2_v_tonach_na_1_tsz_zo_suroviny(input_data, korigovane_hmotnosti),
        cena_co2_aglomeracia=cena_co2_na_tonu_fe_na_aglomeracii(input_data, korigovane_hmotnosti),
        spracovacie_naklady_vp=spracovacie_naklady_na_tonu_fe_na_vp(input_data, korigovane_hmotnosti),
        spracovacie_naklady_aglomeracia=spracovacie_naklady_na_tonu_fe_na_aglomeracii(
            input_data, korigovane_hmotnosti
        ),
        penalta_P=penalta_na_P(input_data, korigovane_hmotnosti),
        penalta_S=penalta_na_S(input_data, korigovane_hmotnosti),
        bazicita_aglomeratu=bazicita_aglomeratu(input_data, korigovane_hmotnosti),
        q_spalin=q_spalin(input_data, korigovane_hmotnosti),
        cena_paliva_na_tonu_fe_z_bvs=cena_paliva_na_tonu_fe_z_bvs(input_data, korigovane_hmotnosti),
        cena_tony_aglomeratu=cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(
            input_data, korigovane_hmotnosti
        ),
    )
