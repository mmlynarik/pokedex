# pylint: disable=too-many-public-methods,invalid-name,no-self-use,too-many-branches
# pylint: disable=too-many-return-statements,too-many-arguments,too-few-public-methods
# pylint: disable=too-many-lines
import re

from typing import Dict, FrozenSet, List, Tuple, Mapping

from immutables import Map
from pycel import ExcelCompiler

from .datamodel.model import (
    AglomeracnyTyp,
    BazickyTyp,
    ChemickaLatka,
    ChemickeZlozenie,
    Limit,
    OptimizationLimits,
    Popol,
    Prisada,
    TypPaliva,
    TypPrisady,
    VsadzkaInput,
    ZlozkaAglomeratu,
    ZlozkaVsadzky,
)


class ExcelCellMapping:
    def __init__(self, excel: ExcelCompiler):
        self._dry_sheet_template = lambda cell_name: f"analýza suchý stav!{cell_name}"
        self._wet_sheet_template = lambda cell_name: f" mokrý stav!{cell_name}"
        self.component_names = {i: excel.evaluate(self._wet_sheet_template(f"D{i}")) for i in range(1, 200)}

    @property
    def min_aglomerat_cell(self) -> str:
        return self._dry_sheet_template("AO5")

    @property
    def max_aglomerat_cell(self) -> str:
        return self._dry_sheet_template("AP5")

    @property
    def min_vytazok_fe_cell(self) -> str:
        return self._dry_sheet_template("BD11")

    @property
    def max_vytazok_fe_cell(self) -> str:
        return self._dry_sheet_template("BE11")

    @property
    def min_bazicita_cell(self) -> str:
        return self._dry_sheet_template("BD13")

    @property
    def max_bazicita_cell(self) -> str:
        return self._dry_sheet_template("BE13")

    @property
    def min_zn_cell(self) -> str:
        return self._dry_sheet_template("BD16")

    @property
    def max_zn_cell(self) -> str:
        return self._dry_sheet_template("BE16")

    @property
    def min_alkalie_cell(self) -> str:
        return self._dry_sheet_template("BD17")

    @property
    def max_alkalie_cell(self) -> str:
        return self._dry_sheet_template("BE17")

    @property
    def min_p_cell(self) -> str:
        return self._dry_sheet_template("BD18")

    @property
    def max_p_cell(self) -> str:
        return self._dry_sheet_template("BE18")

    @property
    def min_mn_cell(self) -> str:
        return self._dry_sheet_template("BD19")

    @property
    def max_mn_cell(self) -> str:
        return self._dry_sheet_template("BE19")

    @property
    def min_pomer_kc_ar_cell(self) -> str:
        return self._dry_sheet_template("BD20")

    @property
    def max_pomer_kc_ar_cell(self) -> str:
        return self._dry_sheet_template("BE20")

    @property
    def min_mgo_do_trosky_cell(self) -> str:
        return self._dry_sheet_template("BD15")

    @property
    def max_mgo_do_trosky_cell(self) -> str:
        return self._dry_sheet_template("BE15")

    @property
    def min_vapenec_cell(self) -> str:
        return self._dry_sheet_template("BC33")

    @property
    def max_vapenec_cell(self) -> str:
        return self._dry_sheet_template("BD33")

    @property
    def eta_co_cell(self) -> str:
        return self._dry_sheet_template("AH39")

    @property
    def cena_za_tonu_cell(self) -> str:
        return self._dry_sheet_template("BA22")

    @property
    def vypocet_paliva_cell(self) -> str:
        return self._dry_sheet_template("BB10")

    @property
    def vytazok_fe_cell(self) -> str:
        return self._dry_sheet_template("BB11")

    @property
    def vyskyt_trosky_cell(self) -> str:
        return self._dry_sheet_template("BB12")

    @property
    def bazicita_cell(self) -> str:
        return self._dry_sheet_template("BB13")

    @property
    def BVS_cell(self) -> str:
        return self._dry_sheet_template("BB14")

    @property
    def hmotnost_vsadzky_cell(self) -> str:
        return self._dry_sheet_template("BB21")

    @property
    def mgo_v_troske_cell(self) -> str:
        return self._dry_sheet_template("BB15")

    @property
    def zn_cell(self) -> str:
        return self._dry_sheet_template("BB16")

    @property
    def alkalie_cell(self) -> str:
        return self._dry_sheet_template("BB17")

    @property
    def p_cell(self) -> str:
        return self._dry_sheet_template("BB18")

    @property
    def mn_cell(self) -> str:
        return self._dry_sheet_template("BB19")

    @property
    def pomer_kc_ar_cell(self) -> str:
        return self._dry_sheet_template("BB20")

    @property
    def celkove_so2_cell(self) -> str:
        return self._dry_sheet_template("BF8")

    @property
    def s_zo_vsadzky_cell(self) -> str:
        return self._wet_sheet_template("O79")

    @property
    def spracovacie_naklady_na_tonu_fe_na_vp_cell(self) -> str:
        return self._wet_sheet_template("BB180")

    @property
    def cena_aglom_suroviny_plus_palivo_na_tonu_suroviny_cell(self) -> str:
        return self._dry_sheet_template("AS58")

    @property
    def cena_aglomeracneho_paliva_cell(self) -> str:
        return self._dry_sheet_template("AR60")

    @property
    def celkova_cena_co2_cell(self) -> str:
        return self._wet_sheet_template("BQ180")

    @property
    def celkova_cena_paliva_na_tonu_fe_z_bvs_cell(self) -> str:
        return self._wet_sheet_template("BP180")

    @property
    def prepoctova_cena_cell(self) -> str:
        return self._wet_sheet_template("AB180")

    @property
    def mnozstvo_co2_na_t_fe_z_aglomeratu_cell(self) -> str:
        return self._wet_sheet_template("BF78")

    @property
    def co2_koks_prach_cell(self) -> str:
        return self._wet_sheet_template("BV23")

    @property
    def penalta_na_S_cell(self) -> str:
        return self._wet_sheet_template("BH180")

    @property
    def penalta_na_P_cell(self) -> str:
        return self._wet_sheet_template("BG180")

    @property
    def percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_cell(self) -> str:
        return self._wet_sheet_template("BV180")

    @property
    def msp_cell(self) -> str:
        return self._dry_sheet_template("AH31")

    @property
    def hbt_cell(self) -> str:
        return self._dry_sheet_template("AH38")

    @property
    def percento_Si_cell(self) -> str:
        return self._dry_sheet_template("AH37")

    @property
    def priemerne_percento_S_cell(self) -> str:
        return self._wet_sheet_template("BH24")

    @property
    def priemerne_percento_P_cell(self) -> str:
        return self._wet_sheet_template("BG24")

    @property
    def hmotnost_aglomeratu_cell(self) -> str:
        return self._dry_sheet_template("AN5")

    @property
    def bazicita_aglomeratu_cell(self) -> str:
        return self._dry_sheet_template("AV5")

    @property
    def q_spalin_cell(self) -> str:
        return self._dry_sheet_template("BG8")

    @property
    def spracovacie_naklady_na_t_sur_fe_cell(self) -> str:
        return self._dry_sheet_template("AH20")

    @property
    def bvs_minuly_mesiac_cell(self) -> str:
        return self._dry_sheet_template("AH15")

    @property
    def cena_co2_cell(self) -> str:
        return self._dry_sheet_template("AH17")

    @property
    def cena_vp_koksu_cell(self) -> str:
        return self._dry_sheet_template("AH8")

    @property
    def koef_odtriedenia_peliet(self) -> str:
        return self._dry_sheet_template("AH6")

    @property
    def cena_peliet(self) -> str:
        return self._wet_sheet_template("C94")

    @property
    def percentualny_podiel_prvkov_v_surovine_v_dod_stave_podsitne_pelety(self) -> str:
        return self._wet_sheet_template("BV94")

    @property
    def hmotnost_podsitnych_peliet_do_vsadzky(self) -> str:
        return self._wet_sheet_template("BW94")

    @property
    def vaha_podsitnych_peliet(self) -> str:
        return self._dry_sheet_template("AN20")

    @property
    def popol_koks_prach_row(self) -> int:
        return 79

    @property
    def popol_kb1_row(self) -> int:
        return 76

    @property
    def popol_kb3_row(self) -> int:
        return 77

    @property
    def popol_pu_row(self) -> int:
        return 78

    def percento_popola_cell_for_row(self, row: int) -> str:
        return self._dry_sheet_template(f"S{row}")

    def column_for_latka(self, latka: ChemickaLatka) -> str:
        return chr(ord("C") + latka)

    def column_for_latka_susina(self, latka: ChemickaLatka) -> str:
        return chr(ord("E") + latka)

    def column_for_latka_with_vapenec(self, latka: ChemickaLatka) -> str:
        return "A" + chr(ord("D") + latka)

    def dry_cell(self, row: int, column: str) -> str:
        return self._dry_sheet_template(f"{column}{row}")

    def cell_for_latka(self, row: int, latka: ChemickaLatka) -> str:
        return self._dry_sheet_template(f"{self.column_for_latka(latka)}{row}")

    @property
    def aglorudy(self) -> Tuple[List[Tuple[int, int]], str, str]:
        return list(zip(range(10, 21), range(24, 35))), "AL", "AK"
        # 10-21 AL nazvy
        # 10-21 AK ceny - nacitam len to, kde cena nieje 0
        # 24-35 su riadky pre chemiu tychto aglorud - stlpce <C;U>

    @property
    def aglorudy_weight_column(self) -> str:
        return "AN"

    @property
    def koncentraty(self) -> Tuple[List[Tuple[int, int]], str, str]:
        return list(zip(range(25, 34), range(36, 45))), "AL", "AK"

    @property
    def koncentraty_weight_column(self) -> str:
        return "AN"

    @property
    def prisady_do_aglomeratu(self) -> Tuple[List[Tuple[int, int]], str, str]:
        return list(zip(range(38, 55), range(50, 67))), "AL", "AK"

    @property
    def prisady_do_aglomeratu_weight_column(self) -> str:
        return "AN"

    @property
    def pelety(self) -> Tuple[List[Tuple[int, int]], str, str]:
        return list(zip(range(10, 21), range(5, 16))), "AT", "AS"

    @property
    def pelety_weight_column(self) -> str:
        return "AV"

    @property
    def prisady_do_vp(self) -> Tuple[List[Tuple[int, int]], str, str]:
        return list(zip(range(25, 30), range(18, 23))), "AT", "AS"

    @property
    def prisady_do_vp_weight_column(self) -> str:
        return "AV"

    @property
    def aglorudy_limits(self) -> Tuple[List[int], str, str, str, str]:
        return list(range(10, 21)), "AL", "AK", "AO", "AP"

    @property
    def koncentraty_limits(self) -> Tuple[List[int], str, str, str, str]:
        return list(range(25, 34)), "AL", "AK", "AO", "AP"

    @property
    def prisady_do_aglomeratu_limits(self) -> Tuple[List[int], str, str, str, str]:
        return list(range(38, 55)), "AL", "AK", "AO", "AP"

    @property
    def pelety_limits(self) -> Tuple[List[int], str, str, str, str]:
        return list(range(10, 21)), "AT", "AS", "AW", "AX"

    @property
    def prisady_do_vp_limits(self) -> Tuple[List[int], str, str, str, str]:
        return list(range(25, 30)), "AT", "AS", "AW", "AX"

    def wet_sheet_prisada_row(self, component_name: str) -> int:
        all_rows = [i for i, name in self.component_names.items() if name == component_name]
        rows_found = len(all_rows)
        if rows_found == 0:
            raise Exception(f"Component not found in wet sheet: {component_name}")
        if rows_found > 1:
            raise Exception(f"Component on more rows {all_rows} in wet sheet: {component_name}")
        return all_rows[0]

    @property
    def suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu_cell(self) -> str:
        return self._dry_sheet_template("AH16")

    @property
    def vapenec_name_cell(self) -> str:
        return self._dry_sheet_template("AS32")

    @property
    def cena_aglom_paliva_cell(self) -> str:
        return self._dry_sheet_template("AH18")

    @property
    def co2_z_uhlia_cell(self) -> str:
        return self._wet_sheet_template("BS23")

    @property
    def co2_z_koks_orech_cell(self) -> str:
        return self._wet_sheet_template("BS24")

    @property
    def co2_z_vp_metalurg_cell(self) -> str:
        return self._wet_sheet_template("BS25")

    @property
    def celkove_palivo_uhlie_cell(self) -> str:
        return self._wet_sheet_template("BT23")

    @property
    def celkove_palivo_koks_orech_cell(self) -> str:
        return self._wet_sheet_template("BT24")

    @property
    def celkove_palivo_cell(self) -> str:
        return self._wet_sheet_template("BT1")

    @property
    def percento_fe_kal_cell(self) -> str:
        return self._wet_sheet_template("P183")

    @property
    def percento_fe_vyhoz_cell(self) -> str:
        return self._wet_sheet_template("P184")

    @property
    def alkalie_aglomerat(self) -> str:
        return self._wet_sheet_template("BI78")

    @property
    def vyskyt_trosky_aglomerat(self) -> str:
        return self._wet_sheet_template("AY78")

    @property
    def fe_susina_aglomerat(self) -> str:
        return self._wet_sheet_template("E78")

    @property
    def fe_susina_v_zlozke_aglomeratu(self) -> str:
        return self._wet_sheet_template("E102")

    def percentualny_podiel_paliva_cell(self, typ_paliva: TypPaliva) -> str:
        if typ_paliva == TypPaliva.UHLIE:
            return self._wet_sheet_template("BU23")
        if typ_paliva == TypPaliva.KOKS_ORECH:
            return self._wet_sheet_template("BU24")
        if typ_paliva == TypPaliva.VP_METALURG:
            return self._wet_sheet_template("BU25")
        raise Exception(f"Unprocessed typ paliva: {typ_paliva}")

    def suma_vah_pre_prisadu_cell(self, typ_prisady: TypPrisady) -> str:
        if typ_prisady == TypPrisady.PELETY:
            return self._wet_sheet_template("BU43")
        if typ_prisady == TypPrisady.PRISADY_DO_VP:
            return self._wet_sheet_template("BU62")
        if typ_prisady == TypPrisady.AGLORUDA:
            return self._wet_sheet_template("BU99")
        if typ_prisady == TypPrisady.KONCENTRAT:
            return self._wet_sheet_template("BU120")
        if typ_prisady == TypPrisady.PRISADA_DO_AGLOMERATU:
            return self._wet_sheet_template("BU151")
        raise Exception(f"Unprocessed typ prisady: {typ_prisady}")

    @property
    def spracovacie_naklady_na_t_aglomeratu_cell(self) -> str:
        return self._dry_sheet_template("AH5")

    @property
    def celkovy_vyskyt_trosky_cell(self) -> str:
        return self._wet_sheet_template("AY180")

    @property
    def celkove_alkalie_cell(self) -> str:
        return self._wet_sheet_template("BI180")

    @property
    def celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky_cell(self) -> str:
        return self._wet_sheet_template("BM180")

    @property
    def pridavok_paliva_na_odparenie_vlhkosti_cell(self) -> str:
        return self._wet_sheet_template("BK180")

    @property
    def vapenec_price_cell(self) -> str:
        return self._dry_sheet_template("AT33")

    @property
    def vapenec_weight_cell(self) -> str:
        return self._dry_sheet_template("AS33")

    @property
    def realne_palivo_pri_p2_z_minuleho_mesiaca_cell(self) -> str:
        return self._dry_sheet_template("AH12")

    @property
    def palivo_na_aglomeracii_cell(self) -> str:
        return self._wet_sheet_template("BE78")

    @property
    def bohatost_suroveho_zeleza_cell(self) -> str:
        return self._dry_sheet_template("AH21")

    @property
    def celkovy_vytazok_fe_cell(self) -> str:
        return self._wet_sheet_template("E183")

    @property
    def celkova_spotreba_vapenca_cell(self) -> str:
        return self._wet_sheet_template("F192")

    @property
    def celkova_hmotnost_vsadzky(self) -> str:
        return self._wet_sheet_template("R176")

    @property
    def vapenec_chem_row(self) -> int:
        return 67

    def s_po_zihani_v_aglomerate_cell(self, zlozka_aglomeratu: ZlozkaAglomeratu) -> str:
        if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
            return self._wet_sheet_template("Y102")
        if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
            return self._wet_sheet_template("Y121")
        if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
            return self._wet_sheet_template("Y153")
        if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
            return self._wet_sheet_template("Y81")
        raise Exception("Unprocessed zlozka aglomeratu")

    def hmotnost_v_aglomerate_do_vsadzky_cell(self, zlozka_aglomeratu: ZlozkaAglomeratu) -> str:
        if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
            return self._wet_sheet_template("BW98")
        if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
            return self._wet_sheet_template("BW119")
        if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
            return self._wet_sheet_template("BW150")
        if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
            return self._wet_sheet_template("E82")
        raise Exception("Unprocessed zlozka aglomeratu")

    def hmotnost_vo_vsadzke_cell(self, zlozka_vsadzky: ZlozkaVsadzky) -> str:
        if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
            return self._wet_sheet_template("F176")
        if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
            return self._wet_sheet_template("G176")
        if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
            return self._wet_sheet_template("H176")
        if zlozka_vsadzky == ZlozkaVsadzky.VAPENEC:
            return self._wet_sheet_template("I176")
        if zlozka_vsadzky == ZlozkaVsadzky.POPOL_Z_PALIVA:
            return self._wet_sheet_template("J176")
        raise Exception("Unprocessed zlozka vsadzky")

    def pomer_zlozky_vsadzky_vo_vsadzke_cell(self, zlozka_vsadzky: ZlozkaVsadzky) -> str:
        if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
            return self._wet_sheet_template("F177")
        if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
            return self._wet_sheet_template("G177")
        if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
            return self._wet_sheet_template("H177")
        if zlozka_vsadzky == ZlozkaVsadzky.VAPENEC:
            return self._wet_sheet_template("I177")
        if zlozka_vsadzky == ZlozkaVsadzky.POPOL_Z_PALIVA:
            return self._wet_sheet_template("J177")
        raise Exception("Unprocessed zlozka vsadzky")

    def mnozstvo_koksu_na_zlozku_vsadzky_cell(self, zlozka_vsadzky: ZlozkaVsadzky) -> str:
        if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
            return self._wet_sheet_template("BZ78")
        if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
            return self._wet_sheet_template("BZ42")
        if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
            return self._wet_sheet_template("BZ61")
        raise Exception("Unprocessed zlozka vsadzky")

    @property
    def palivo_potrebne_na_skut_vyrobu_aglomeratu_cell(self) -> str:
        return self._wet_sheet_template("BD78")

    @property
    def celkove_mnozstvo_paliva_do_VP_cell(self) -> str:
        return self._wet_sheet_template("BZ75")

    def row_for_zlozka_vsadzky(self, zlozka_vsadzky: ZlozkaVsadzky) -> int:
        if zlozka_vsadzky == ZlozkaVsadzky.AGLOMERAT:
            return 78
        if zlozka_vsadzky == ZlozkaVsadzky.PELETY:
            return 45
        if zlozka_vsadzky == ZlozkaVsadzky.PRISADY_DO_VP:
            return 65
        raise Exception(f"Unprocessed zlozka vsadzky {zlozka_vsadzky}")

    def row_for_zlozka_aglomeratu(self, zlozka_aglomeratu: ZlozkaAglomeratu) -> int:
        if zlozka_aglomeratu == ZlozkaAglomeratu.AGLORUDA:
            return 102
        if zlozka_aglomeratu == ZlozkaAglomeratu.KONCENTRAT:
            return 121
        if zlozka_aglomeratu == ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU:
            return 153
        raise Exception("Unprocessed zlozka aglomeratu")

    def latka_v_popole_cell(self, latka: ChemickaLatka) -> str:
        if latka == ChemickaLatka.SiO2:
            return self._wet_sheet_template("F71")
        if latka == ChemickaLatka.CaO:
            return self._wet_sheet_template("H71")
        if latka == ChemickaLatka.MgO:
            return self._wet_sheet_template("I71")
        if latka == ChemickaLatka.Al2O3:
            return self._wet_sheet_template("M71")
        if latka == ChemickaLatka.Fe2O3:
            return self._wet_sheet_template("G71")
        if latka == ChemickaLatka.Mn:
            return self._wet_sheet_template("J71")
        if latka == ChemickaLatka.TiO2:
            return self._wet_sheet_template("K71")
        if latka == ChemickaLatka.P:
            return self._wet_sheet_template("L71")
        if latka == ChemickaLatka.S:
            return self._wet_sheet_template("N71")
        if latka == ChemickaLatka.Na2O:
            return self._wet_sheet_template("O71")
        if latka == ChemickaLatka.K2O:
            return self._wet_sheet_template("P71")
        if latka == ChemickaLatka.Pb:
            return self._wet_sheet_template("R71")
        if latka == ChemickaLatka.Zn:
            return self._wet_sheet_template("S71")
        if latka == ChemickaLatka.H2O:
            return self._dry_sheet_template("D76")
        return self._wet_sheet_template("T71")

    def percentualny_obsah_v_zlozke_vsadzky_cell(
        self, latka: ChemickaLatka, zlozka_vsadzky: ZlozkaVsadzky
    ) -> str:
        if zlozka_vsadzky == zlozka_vsadzky.VAPENEC:
            if latka == ChemickaLatka.H2O:
                return self._wet_sheet_template("F49")
            if latka == ChemickaLatka.SiO2:
                return self._wet_sheet_template("G49")
            if latka == ChemickaLatka.CaO:
                return self._wet_sheet_template("H49")
            if latka == ChemickaLatka.MgO:
                return self._wet_sheet_template("I49")
            if latka == ChemickaLatka.Al2O3:
                return self._wet_sheet_template("J49")
            if latka == ChemickaLatka.C:
                return self._wet_sheet_template("K49")
            if latka == ChemickaLatka.Fe:
                return self._wet_sheet_template("L49")
            return self._wet_sheet_template("M49")
        if zlozka_vsadzky == zlozka_vsadzky.POPOL_Z_PALIVA:
            return self.latka_v_popole_cell(latka)
        return self._wet_sheet_template(
            f"{self.column_for_latka_susina(latka)}{self.row_for_zlozka_vsadzky(zlozka_vsadzky)}"
        )

    def percentualny_obsah_v_zlozke_aglomeratu_cell(
        self, latka: ChemickaLatka, zlozka_aglomeratu: ZlozkaAglomeratu
    ) -> str:
        if zlozka_aglomeratu == ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU:
            return self.latka_v_popole_cell(latka)
        return self._wet_sheet_template(
            f"{self.column_for_latka_susina(latka)}{self.row_for_zlozka_aglomeratu(zlozka_aglomeratu)}"
        )

    def obsah_chemickej_latky_vo_vsadzke_cell(self, latka: ChemickaLatka) -> str:
        return self._wet_sheet_template(f"{self.column_for_latka_susina(latka)}180")

    def obsah_chemickej_latky_v_podsitnych_peletach_cell(self, latka: ChemickaLatka) -> str:
        return self._wet_sheet_template(f"{self.column_for_latka_susina(latka)}45")

    def palivo_na_surovinu_z_bvs_plus_vyskyt_trosky_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BM{self.wet_sheet_prisada_row(prisada.nazov)}")

    def vazeny_priemer_podielu_pod_5mm(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"CF{self.wet_sheet_prisada_row(prisada.nazov)}")

    def podiel_suroviny_v_celkovej_vsadzke(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"CE{self.wet_sheet_prisada_row(prisada.nazov)}")

    def pridavok_paliva_na_odparenie_vlhkosti_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BK{self.wet_sheet_prisada_row(prisada.nazov)}")

    def vyskyt_trosky_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"AY{self.wet_sheet_prisada_row(prisada.nazov)}")

    def pomer_prvku_v_prisade_s_pridanim_vapenca_cell(self, prisada: Prisada, latka: ChemickaLatka) -> str:
        return self._wet_sheet_template(
            f"{self.column_for_latka_with_vapenec(latka)}{self.wet_sheet_prisada_row(prisada.nazov)}"
        )

    def pomer_prvku_v_prisade_susina_cell(self, prisada: Prisada, latka: ChemickaLatka) -> str:
        return self._wet_sheet_template(
            f"{self.column_for_latka_susina(latka)}{self.wet_sheet_prisada_row(prisada.nazov)}"
        )

    def percentualny_obsah_latky_v_aglomerate_susina(self, latka: ChemickaLatka) -> str:
        return self._wet_sheet_template(f"{self.column_for_latka_susina(latka)}78")

    def pridavok_vapenca_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"AA{self.wet_sheet_prisada_row(prisada.nazov)}")

    def popol_t_z_500kg_koksu_na_t_suroviny_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"AW{self.wet_sheet_prisada_row(prisada.nazov)}")

    def palivo_na_aglomeracii_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BE{self.wet_sheet_prisada_row(prisada.nazov)}")

    def celkova_cena_za_tonu_fe_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BS{self.wet_sheet_prisada_row(prisada.nazov)}")

    def spracovacie_naklady_na_tonu_fe_na_vp_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BB{self.wet_sheet_prisada_row(prisada.nazov)}")

    def cena_co2_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BQ{self.wet_sheet_prisada_row(prisada.nazov)}")

    def penalta_na_P_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BG{self.wet_sheet_prisada_row(prisada.nazov)}")

    def penalta_na_S_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BH{self.wet_sheet_prisada_row(prisada.nazov)}")

    def pomer_prechodu_s_prisada_cell(self, component_name: str) -> str:
        return self._wet_sheet_template(f"Z{self.wet_sheet_prisada_row(component_name)}")

    def rozsev_pod_5mm_cell(self, component_row: int) -> str:
        return self._dry_sheet_template(f"Z{component_row}")

    @property
    def mnozstvo_paliva_na_aglomerat_cell(self) -> str:
        return self._wet_sheet_template("BD78")

    @property
    def palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky_cell(self) -> str:
        return self._wet_sheet_template("BM78")

    @property
    def hmotnost_vapenca_2_cell(self) -> str:
        return self._wet_sheet_template("X149")

    def alkalie_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BI{self.wet_sheet_prisada_row(prisada.nazov)}")

    def koeficient_na_spotrebu_vapenca_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BC{self.wet_sheet_prisada_row(prisada.nazov)}")

    def koeficient_na_metalicke_zelezo_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BJ{self.wet_sheet_prisada_row(prisada.nazov)}")

    def fe_met_pri_jednotkovom_p2_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BL{self.wet_sheet_prisada_row(prisada.nazov)}")

    def podiel_prvkov_v_surovine_v_dodanom_stave_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BV{self.wet_sheet_prisada_row(prisada.nazov)}")

    def s_po_zihani_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"Y{self.wet_sheet_prisada_row(prisada.nazov)}")

    def mnozstvo_koksu_na_prisadu_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BZ{self.wet_sheet_prisada_row(prisada.nazov)}")

    def cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BN{self.wet_sheet_prisada_row(prisada.nazov)}")

    def cena_paliva_na_tonu_fe_z_bvs_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BP{self.wet_sheet_prisada_row(prisada.nazov)}")

    def cena_prepoctova_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"AB{self.wet_sheet_prisada_row(prisada.nazov)}")

    def mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada_cell(self, prisada: Prisada) -> str:
        return self._wet_sheet_template(f"BF{self.wet_sheet_prisada_row(prisada.nazov)}")

    @property
    def C_v_sur_fe_minuly_mesiac_cell(self) -> str:
        return self._dry_sheet_template("AH9")

    @property
    def Si_v_sur_fe_minuly_mesiac_cell(self) -> str:
        return self._dry_sheet_template("AH10")

    @property
    def Mn_v_sur_fe_minuly_mesiac_cell(self) -> str:
        return self._dry_sheet_template("AH11")

    @property
    def korekcny_koeficient_s_do_aglo_cell(self) -> str:
        return self._dry_sheet_template("AH22")

    @property
    def energia_na_odparenie_h2o_cell(self) -> str:
        return self._wet_sheet_template("BK181")

    @property
    def kaloriticka_hodnota_koks_cell(self) -> str:
        return self._wet_sheet_template("BK182")

    @property
    def podsitny_podiel_pod_5mm(self) -> str:
        return self._dry_sheet_template("AE31")

    @property
    def planovane_mnozstvo_zp(self) -> str:
        return self._dry_sheet_template("AH13")

    @property
    def cena_zp(self) -> str:
        return self._dry_sheet_template("AH7")

    @property
    def cena_pu(self) -> str:
        return self._dry_sheet_template("AH19")

    @property
    def planovane_mnozstvo_pu(self) -> str:
        return self._dry_sheet_template("AH14")

    @property
    def hmotnost_mspu(self) -> str:
        return self._dry_sheet_template("BB25")


def load_prvok(
    latka: ChemickaLatka,
    row: int,
    zeros: List[ChemickaLatka],
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
) -> float:
    if latka in zeros:
        return 0.0
    value_from_excel = excel.evaluate(cell_mapping.cell_for_latka(row, latka))
    if isinstance(value_from_excel, float):
        return value_from_excel

    try:
        return float(value_from_excel)
    except Exception:  # pylint: disable=broad-except
        return 0.0
    return 0.0


def load_koef_na_bvs(excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> float:
    return (
        100
        + excel.evaluate(cell_mapping._dry_sheet_template("AH9"))
        + excel.evaluate(cell_mapping._dry_sheet_template("AH10"))
        + excel.evaluate(cell_mapping._dry_sheet_template("AH11"))
    ) / 100


def load_chemicke_zlozenie(
    row: int, zeros: List[ChemickaLatka], excel: ExcelCompiler, cell_mapping: ExcelCellMapping
) -> ChemickeZlozenie:
    return tuple(load_prvok(latka, row, zeros, excel, cell_mapping) for latka in ChemickaLatka)


def load_dust_settings(dust_row: int, excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> Popol:
    return Popol(
        percento_popola=excel.evaluate(cell_mapping.percento_popola_cell_for_row(dust_row)),
        chemicke_zlozenie=load_chemicke_zlozenie(dust_row, [ChemickaLatka.As], excel, cell_mapping),
    )


def aglomeracny_typ_podla_typu_a_nazvu(typ_prisady: TypPrisady, nazov: str) -> AglomeracnyTyp:
    if typ_prisady == TypPrisady.KONCENTRAT:
        if nazov in {"KC-DRI-68", "KC-NORDKAP", "KC-Juz65,5"}:
            return AglomeracnyTyp.AGLORUDA
        return AglomeracnyTyp.KONCENTRAT
    if typ_prisady == TypPrisady.AGLORUDA:
        return AglomeracnyTyp.AGLORUDA
    if typ_prisady == TypPrisady.PRISADA_DO_AGLOMERATU:
        if nazov in {"KC-BULG", "KRA-VAP", "OKU-KYS", "OKU-VAL", "VYHOZ VP1", "Eramet 44% (Mn Gabon)"}:
            return AglomeracnyTyp.KONCENTRAT
        if nazov in {"MIK-VAP"}:
            return AglomeracnyTyp.AGLORUDA
    return AglomeracnyTyp.ZIADEN


def bazicky_typ_podla_nazvu(nazov: str) -> BazickyTyp:
    if nazov in {"A-VAP-TU", "AG-VAP-P", "AGL-VAP"}:
        return BazickyTyp.AGLO_VAPENEC
    if nazov in {"DOL-TU-P", "DOLOM-P"}:
        return BazickyTyp.AGLO_DOLOMIT
    if nazov in {"VA-K", "VA-VARIN"}:
        return BazickyTyp.AGLO_VAPNO
    if nazov in {"VP-VAP"}:
        return BazickyTyp.VP_VAPENEC
    return BazickyTyp.ZIADEN


def load_material_internal(
    typ_prisady: TypPrisady,
    name_cell: str,
    price_cell: str,
    component_chem_row: int,
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
) -> Prisada:
    nazov = excel.evaluate(name_cell)
    optional_fields = {}
    pomer_prechodu_s = excel.evaluate(cell_mapping.pomer_prechodu_s_prisada_cell(nazov))
    rozsev_pod_5mm = excel.evaluate(cell_mapping.rozsev_pod_5mm_cell(component_chem_row))
    if (
        pomer_prechodu_s is not None
        and isinstance(pomer_prechodu_s, float)
        and 0.0 <= pomer_prechodu_s <= 1.0
    ):
        optional_fields["pomer_prechodu_s"] = pomer_prechodu_s
    if typ_prisady in [TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP]:
        if rozsev_pod_5mm is not None:
            optional_fields["rozsev_pod_5mm"] = rozsev_pod_5mm
        else:
            optional_fields["rozsev_pod_5mm"] = 0.0

        return Prisada(
            nazov=nazov,
            cena_za_tonu=excel.evaluate(price_cell),
            chemicke_zlozenie=load_chemicke_zlozenie(component_chem_row, [], excel, cell_mapping),
            typ_prisady=typ_prisady,
            bazicky_typ=bazicky_typ_podla_nazvu(nazov),
            aglomeracny_typ=aglomeracny_typ_podla_typu_a_nazvu(typ_prisady, nazov),
            **optional_fields,
        )
    return Prisada(
        nazov=nazov,
        cena_za_tonu=excel.evaluate(price_cell),
        chemicke_zlozenie=load_chemicke_zlozenie(component_chem_row, [], excel, cell_mapping),
        typ_prisady=typ_prisady,
        bazicky_typ=bazicky_typ_podla_nazvu(nazov),
        aglomeracny_typ=aglomeracny_typ_podla_typu_a_nazvu(typ_prisady, nazov),
        **optional_fields,
    )


def load_material(
    typ_prisady: TypPrisady,
    component_row: int,
    component_chem_row: int,
    name_column: str,
    price_column: str,
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
) -> Prisada:
    return load_material_internal(
        typ_prisady,
        cell_mapping.dry_cell(component_row, name_column),
        cell_mapping.dry_cell(component_row, price_column),
        component_chem_row,
        excel,
        cell_mapping,
    )


def load_vapenec(excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> Prisada:
    return load_material_internal(
        TypPrisady.VAPENEC,
        cell_mapping.vapenec_name_cell,
        cell_mapping.vapenec_price_cell,
        cell_mapping.vapenec_chem_row,
        excel,
        cell_mapping,
    )


def is_valid_component_row(
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
    name_column: str,
    price_column: str,
    component_row: int,
) -> bool:
    name = excel.evaluate(cell_mapping.dry_cell(component_row, name_column))
    if name is None or (not isinstance(name, str)) or len(name) < 2:
        return False
    if re.match("(?i)(Podsitn(?:e|é) pelety)", name):
        return False
    price = excel.evaluate(cell_mapping.dry_cell(component_row, price_column))
    if price is None or price == 0.0:
        return False
    return True


def load_component_settings(
    rows: List[Tuple[int, int]],
    name_column: str,
    price_column: str,
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
    material_type: TypPrisady,
) -> FrozenSet[Prisada]:
    return frozenset(
        load_material(
            material_type,
            component_row,
            component_chem_row,
            name_column,
            price_column,
            excel,
            cell_mapping,
        )
        for component_row, component_chem_row in rows
        if is_valid_component_row(excel, cell_mapping, name_column, price_column, component_row)
    )


def load_component_weights(
    rows: List[Tuple[int, int]],
    name_column: str,
    price_column: str,
    weight_column: str,
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
) -> Dict[str, float]:
    return {
        excel.evaluate(cell_mapping.dry_cell(component_row, name_column)): excel.evaluate(
            cell_mapping.dry_cell(component_row, weight_column)
        )
        for component_row, _ in rows
        if is_valid_component_row(excel, cell_mapping, name_column, price_column, component_row)
    }


def load_hmotnosti_prisad(excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> Mapping[str, float]:
    return Map(
        **load_component_weights(
            *cell_mapping.aglorudy, cell_mapping.aglorudy_weight_column, excel, cell_mapping
        ),
        **load_component_weights(
            *cell_mapping.koncentraty, cell_mapping.koncentraty_weight_column, excel, cell_mapping
        ),
        **load_component_weights(
            *cell_mapping.pelety, cell_mapping.pelety_weight_column, excel, cell_mapping
        ),
        **load_component_weights(
            *cell_mapping.prisady_do_vp, cell_mapping.prisady_do_vp_weight_column, excel, cell_mapping
        ),
        **load_component_weights(
            *cell_mapping.prisady_do_aglomeratu,
            cell_mapping.prisady_do_aglomeratu_weight_column,
            excel,
            cell_mapping,
        ),
        **{excel.evaluate(cell_mapping.vapenec_name_cell): excel.evaluate(cell_mapping.vapenec_weight_cell)},
    )


def generate_input_from_excel(excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> VsadzkaInput:
    return VsadzkaInput(
        cena_vp_koksu=excel.evaluate(cell_mapping.cena_vp_koksu_cell),
        cena_tony_co2=excel.evaluate(cell_mapping.cena_co2_cell),
        bvs_minuly_mesiac=excel.evaluate(cell_mapping.bvs_minuly_mesiac_cell),
        spracovacie_naklady_na_tonu_suroveho_zeleza=excel.evaluate(
            cell_mapping.spracovacie_naklady_na_t_sur_fe_cell
        ),
        spracovacie_naklady_na_tonu_aglomeratu=excel.evaluate(
            cell_mapping.spracovacie_naklady_na_t_aglomeratu_cell
        ),
        priemerne_percento_P=excel.evaluate(cell_mapping.priemerne_percento_P_cell),
        priemerne_percento_S=excel.evaluate(cell_mapping.priemerne_percento_S_cell),
        percento_Si=excel.evaluate(cell_mapping.percento_Si_cell),
        hbt=excel.evaluate(cell_mapping.hbt_cell),
        eta_co=excel.evaluate(cell_mapping.eta_co_cell),
        msp=excel.evaluate(cell_mapping.msp_cell),
        suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu=excel.evaluate(
            cell_mapping.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu_cell
        ),
        realne_palivo_pri_p2_z_minuleho_mesiaca=excel.evaluate(
            cell_mapping.realne_palivo_pri_p2_z_minuleho_mesiaca_cell
        ),
        cena_aglom_paliva=excel.evaluate(cell_mapping.cena_aglom_paliva_cell),
        bohatost_suroveho_zeleza=excel.evaluate(cell_mapping.bohatost_suroveho_zeleza_cell),
        co2_z_uhlia=excel.evaluate(cell_mapping.co2_z_uhlia_cell),
        co2_z_koks_orech=excel.evaluate(cell_mapping.co2_z_koks_orech_cell),
        co2_z_vp_metalurg=excel.evaluate(cell_mapping.co2_z_vp_metalurg_cell),
        co2_z_koks_prach=excel.evaluate(cell_mapping.co2_koks_prach_cell),
        celkove_palivo_uhlie=excel.evaluate(cell_mapping.celkove_palivo_uhlie_cell),
        celkove_palivo_koks_orech=excel.evaluate(cell_mapping.celkove_palivo_koks_orech_cell),
        percento_fe_kal=excel.evaluate(cell_mapping.percento_fe_kal_cell),
        percento_fe_vyhoz=excel.evaluate(cell_mapping.percento_fe_vyhoz_cell),
        C_v_sur_fe_minuly_mesiac=excel.evaluate(cell_mapping.C_v_sur_fe_minuly_mesiac_cell),
        Si_v_sur_fe_minuly_mesiac=excel.evaluate(cell_mapping.Si_v_sur_fe_minuly_mesiac_cell),
        Mn_v_sur_fe_minuly_mesiac=excel.evaluate(cell_mapping.Mn_v_sur_fe_minuly_mesiac_cell),
        korekcny_koeficient_pre_S_do_aglomeratu=excel.evaluate(
            cell_mapping.korekcny_koeficient_s_do_aglo_cell
        ),
        energia_na_odparenie_h2o=excel.evaluate(cell_mapping.energia_na_odparenie_h2o_cell),
        kaloriticka_hodnota_koks=excel.evaluate(cell_mapping.kaloriticka_hodnota_koks_cell),
        popol_koks_prach=load_dust_settings(cell_mapping.popol_koks_prach_row, excel, cell_mapping),
        popol_kb1=load_dust_settings(cell_mapping.popol_kb1_row, excel, cell_mapping),
        popol_kb3=load_dust_settings(cell_mapping.popol_kb3_row, excel, cell_mapping),
        popol_pu=load_dust_settings(cell_mapping.popol_pu_row, excel, cell_mapping),
        aglorudy=load_component_settings(*cell_mapping.aglorudy, excel, cell_mapping, TypPrisady.AGLORUDA),
        koncentraty=load_component_settings(
            *cell_mapping.koncentraty, excel, cell_mapping, TypPrisady.KONCENTRAT
        ),
        pelety=load_component_settings(*cell_mapping.pelety, excel, cell_mapping, TypPrisady.PELETY),
        prisady_do_vp=load_component_settings(
            *cell_mapping.prisady_do_vp, excel, cell_mapping, TypPrisady.PRISADY_DO_VP
        ),
        prisady_do_aglomeratu=load_component_settings(
            *cell_mapping.prisady_do_aglomeratu, excel, cell_mapping, TypPrisady.PRISADA_DO_AGLOMERATU
        ),
        vapenec=load_vapenec(excel, cell_mapping),
        koef_odtriedenia_peliet=excel.evaluate(cell_mapping.koef_odtriedenia_peliet),
        posditny_podiel_pod_5mm_aglomerat=excel.evaluate(cell_mapping.podsitny_podiel_pod_5mm),
        koef_na_bvs=load_koef_na_bvs(excel, cell_mapping),
        planovane_mnozstvo_zp=excel.evaluate(cell_mapping.planovane_mnozstvo_zp),
        cena_zp=excel.evaluate(cell_mapping.cena_zp),
        cena_pu=excel.evaluate(cell_mapping.cena_pu),
        planovane_mnozstvo_pu=excel.evaluate(cell_mapping.planovane_mnozstvo_pu),
        hmotnost_mspu=excel.evaluate(cell_mapping.hmotnost_mspu) * 1.111,
    )


def load_limit(excel: ExcelCompiler, min_cell: str, max_cell: str, name: str = "") -> Limit:
    return Limit(nazov=name, min=excel.evaluate(min_cell), max=excel.evaluate(max_cell))


def load_component_limits(
    rows: List[int],
    name_column: str,
    price_column: str,
    min_column: str,
    max_column: str,
    excel: ExcelCompiler,
    cell_mapping: ExcelCellMapping,
) -> FrozenSet[Limit]:
    return frozenset(
        load_limit(
            excel,
            cell_mapping.dry_cell(component_row, min_column),
            cell_mapping.dry_cell(component_row, max_column),
            excel.evaluate(cell_mapping.dry_cell(component_row, name_column)),
        )
        for component_row in rows
        if is_valid_component_row(excel, cell_mapping, name_column, price_column, component_row)
    )


def generate_limits_from_excel(excel: ExcelCompiler, cell_mapping: ExcelCellMapping) -> OptimizationLimits:
    return OptimizationLimits(
        aglomerat=load_limit(excel, cell_mapping.min_aglomerat_cell, cell_mapping.max_aglomerat_cell),
        vytazok_fe=load_limit(excel, cell_mapping.min_vytazok_fe_cell, cell_mapping.max_vytazok_fe_cell),
        bazicita=load_limit(excel, cell_mapping.min_bazicita_cell, cell_mapping.max_bazicita_cell),
        zn=load_limit(excel, cell_mapping.min_zn_cell, cell_mapping.max_zn_cell),
        alkalie=load_limit(excel, cell_mapping.min_alkalie_cell, cell_mapping.max_alkalie_cell),
        p=load_limit(excel, cell_mapping.min_p_cell, cell_mapping.max_p_cell),
        mn=load_limit(excel, cell_mapping.min_mn_cell, cell_mapping.max_mn_cell),
        pomer_kc_ar=load_limit(
            excel,
            cell_mapping.min_pomer_kc_ar_cell,
            cell_mapping.max_pomer_kc_ar_cell,
        ),
        mgo_do_trosky=load_limit(
            excel,
            cell_mapping.min_mgo_do_trosky_cell,
            cell_mapping.max_mgo_do_trosky_cell,
        ),
        aglorudy=load_component_limits(*cell_mapping.aglorudy_limits, excel, cell_mapping),
        koncentraty=load_component_limits(*cell_mapping.koncentraty_limits, excel, cell_mapping),
        pelety=load_component_limits(*cell_mapping.pelety_limits, excel, cell_mapping),
        prisady_do_vp=load_component_limits(*cell_mapping.prisady_do_vp_limits, excel, cell_mapping),
        prisady_do_aglomeratu=load_component_limits(
            *cell_mapping.prisady_do_aglomeratu_limits, excel, cell_mapping
        ),
        vapenec=load_limit(excel, cell_mapping.min_vapenec_cell, cell_mapping.max_vapenec_cell, "VP-VAP"),
    )
