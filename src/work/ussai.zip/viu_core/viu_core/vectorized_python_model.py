# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
# pylint: disable=too-many-lines,invalid-name,too-many-arguments,too-many-instance-attributes,too-many-locals
# pylint: disable=too-many-statements,too-many-public-methods
from typing import Callable, Mapping, Optional, TypeVar

import numpy as np
from immutables import Map
from viu_core.python_model import (
    percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu,
    pomer_prvku_v_prisade_susina,
    inverzia_pomer_prvku_v_prisade_susina,
)

from .common_constants import ASH_BURN_COMPONENTS, MET_FE_GROUP
from .datamodel.model import (
    AglomeracnyTyp,
    BazickyTyp,
    ChemickaLatka,
    Prisada,
    TypPrisady,
    VsadzkaInput,
    VsadzkaOutput,
    MN_RECYCLABLE_LOWER,
    MN_RECYCLABLE_UPPER,
)


def hmotnost_podsitnych_peliet_do_vsadzky_vectorized(
    vaha_podsitnych_peliet: float, prisada_podsitne_pelety: Prisada
) -> float:
    return (
        percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(prisada_podsitne_pelety)
        / 100
        * vaha_podsitnych_peliet
    )


def get_vectorization_mapping(input_data: VsadzkaInput) -> Mapping[str, int]:
    mapping = [(prisada.nazov, i) for i, prisada in enumerate(input_data.vsetky_prisady)]
    dict_mapping = dict(mapping)
    # This is solvable by renaming but for now just throw exception
    if len(mapping) != len(dict_mapping):
        raise Exception("Cannot vectorize -> duplicate component names")
    return Map(**dict_mapping)


def vectorize_weights(weights: Mapping[str, float], vectorization_mapping: Mapping[str, int]) -> np.ndarray:
    weights_vector = np.empty(len(vectorization_mapping))
    for name in vectorization_mapping:
        weights_vector[vectorization_mapping[name]] = weights.get(name, 0.0)
    return weights_vector


def get_chemical_composition_matrix(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    chem_matrix = np.empty([len(vectorization_mapping), len(ChemickaLatka)])
    for component_name in vectorization_mapping:
        for component in input_data.vsetky_prisady:
            if component.nazov == component_name:
                chem_matrix[vectorization_mapping[component.nazov]] = component.chemicke_zlozenie
    return chem_matrix


def calculate_dry_chemical_composition(chemical_composition: np.ndarray) -> np.ndarray:
    multiplier = (100 - chemical_composition[:, ChemickaLatka.H2O]) / 100
    dry = np.apply_along_axis(lambda compound_vector: compound_vector * multiplier, 0, chemical_composition)
    dry[:, ChemickaLatka.H2O] = chemical_composition[:, ChemickaLatka.H2O]
    return dry


def calculate_fe_richness_constant(
    C_in_pig_iron: float, Si_in_pig_iron: float, Mn_in_pig_iron: float
) -> float:
    return (100 + C_in_pig_iron + Si_in_pig_iron + Mn_in_pig_iron) / 100


def calculate_fe_with_raw_fe_richness(fe_richness_constant: float, fe_composition: np.ndarray) -> np.ndarray:
    return fe_composition * (fe_richness_constant) / 100


def calculate_fe_loss_multiplier(input_data: VsadzkaInput) -> float:
    return 1 - (input_data.percento_fe_kal * 13 / 100000) - (input_data.percento_fe_vyhoz * 7 / 100000)


def calculate_fe_with_losses(fe_composition: np.ndarray, input_data: VsadzkaInput) -> np.ndarray:
    return fe_composition * calculate_fe_loss_multiplier(input_data)


def calculate_fe_with_losses_wo_input_data(
    fe_composition: np.ndarray, fe_loss_multiplier: float
) -> np.ndarray:
    return fe_composition * fe_loss_multiplier


def calculate_feature_vector(
    func: Callable[[Prisada], float], input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    vector = np.empty(len(vectorization_mapping))
    for component_name in vectorization_mapping:
        for component in input_data.vsetky_prisady:
            if component.nazov == component_name:
                vector[vectorization_mapping[component.nazov]] = func(component)
    return vector


def calculate_limestone_group_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.bazicky_typ != BazickyTyp.ZIADEN), input_data, vectorization_mapping
    )


def calculate_limestone_group_2_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.bazicky_typ in {BazickyTyp.AGLO_VAPENEC, BazickyTyp.AGLO_DOLOMIT}),
        input_data,
        vectorization_mapping,
    )


def calculate_limestone_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.nazov == input_data.vapenec.nazov),
        input_data,
        vectorization_mapping,
    )


def calculate_is_pelet_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.typ_prisady == TypPrisady.PELETY), input_data, vectorization_mapping
    )


def calculate_agglomerate_type_vector(
    agglomerate_type: AglomeracnyTyp, input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.aglomeracny_typ == agglomerate_type),
        input_data,
        vectorization_mapping,
    )


def get_price_vector(input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: component.cena_za_tonu,
        input_data,
        vectorization_mapping,
    )


def get_mik_vap_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int], dry_c_vector: np.ndarray
) -> np.ndarray:
    return (
        calculate_feature_vector(
            lambda component: float(component.nazov == "MIK-VAP"),
            input_data,
            vectorization_mapping,
        )
        * (100 - dry_c_vector)
        / 100
    ) + calculate_feature_vector(
        lambda component: float(component.nazov != "MIK-VAP"),
        input_data,
        vectorization_mapping,
    )


def get_s_after_annealing_multiplier_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int], dry_c_vector: np.ndarray
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: component.pomer_prechodu_s,
        input_data,
        vectorization_mapping,
    ) * get_mik_vap_vector(input_data, vectorization_mapping, dry_c_vector)


def calculate_is_not_input_to_bf_or_sb_kus_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(
            (component.typ_prisady not in {TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP})
            or component.nazov == "SB-KUS"
        ),
        input_data,
        vectorization_mapping,
    )


def calculate_ingredient_type_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int], typ_prisady: TypPrisady
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.typ_prisady == typ_prisady),
        input_data,
        vectorization_mapping,
    )


def calculate_recyclable_vector(mn_chem_matrix: np.ndarray) -> np.ndarray:
    return ((mn_chem_matrix < MN_RECYCLABLE_UPPER) & (mn_chem_matrix > MN_RECYCLABLE_LOWER)) * 1


def calculate_agglomerate_input_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(
            component.typ_prisady
            in {
                TypPrisady.PRISADA_DO_AGLOMERATU,
                TypPrisady.KONCENTRAT,
                TypPrisady.AGLORUDA,
            }
        ),
        input_data,
        vectorization_mapping,
    )


def calculate_blast_furnance_input_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.typ_prisady in {TypPrisady.PELETY, TypPrisady.PRISADY_DO_VP}),
        input_data,
        vectorization_mapping,
    )


def calculate_pellets_input_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.typ_prisady in {TypPrisady.PELETY}),
        input_data,
        vectorization_mapping,
    )


def calculate_under_5mm_vector(
    input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]
) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.rozsev_pod_5mm),
        input_data,
        vectorization_mapping,
    )


def calculate_met_fe_group(input_data: VsadzkaInput, vectorization_mapping: Mapping[str, int]) -> np.ndarray:
    return calculate_feature_vector(
        lambda component: float(component.nazov in MET_FE_GROUP),
        input_data,
        vectorization_mapping,
    )


def fe_mn(chem: np.ndarray) -> np.ndarray:
    return chem[:, ChemickaLatka.Fe] + chem[:, ChemickaLatka.Mn]


def calculate_agglomeration_fuel(
    agglomerate_input: np.ndarray, fe_mn_dry: np.ndarray, real_fuel_last_month: float
) -> np.ndarray:
    return 100 * agglomerate_input * real_fuel_last_month / fe_mn_dry


def ash_weight_from_500kg_coke(
    limestone_group: np.ndarray,
    dry_fe: np.ndarray,
    dry_fe_met: np.ndarray,
    agglomeration_fuel: np.ndarray,
    kb1_ash_multiplier: float,
    coke_ash_multiplier: float,
) -> np.ndarray:
    return (limestone_group * dry_fe_met) + (
        (1.0 - limestone_group)
        * ((dry_fe / 10000 * kb1_ash_multiplier * 0.5) + (agglomeration_fuel * coke_ash_multiplier / 100000))
    )


def sio2_correction(sio2: np.ndarray) -> np.ndarray:
    return sio2 - 0.5 * 30 / 14 / 100


def oxid_calculation(sio2: np.ndarray, al2o3: np.ndarray, cao: np.ndarray, mgo: np.ndarray) -> np.ndarray:
    return sio2 + al2o3 - cao - mgo


def agglomerate_fuel_ash_limestone_addition(
    sio2: float,
    al2o3: float,
    cao: float,
    mgo: float,
    ash_weight: float,
    kb1_ash_oxid: float,
    limestone_oxid: float,
) -> float:
    return (oxid_calculation(sio2_correction(sio2), al2o3, cao, mgo) + kb1_ash_oxid * ash_weight) / (
        -limestone_oxid
    )


def calculate_chem_composition_with_limestone(
    dry_chem: np.ndarray,
    limestone_addition: np.ndarray,
    limestone_chem: np.ndarray,
    ash_chem: np.ndarray,
    ash_weight: np.ndarray,
) -> np.ndarray:
    all_compounds = np.zeros_like(dry_chem)
    for compound in ChemickaLatka:
        dry = dry_chem[:, compound]
        limestone = limestone_chem[compound]
        if compound == ChemickaLatka.Fe2O3:
            nominator = dry + limestone_addition * limestone_chem[ChemickaLatka.Fe]
        elif compound in {
            ChemickaLatka.Fe,
            ChemickaLatka.As,
            ChemickaLatka.C,
            ChemickaLatka.Cl,
            ChemickaLatka.H2O,
        }:
            nominator = dry + limestone_addition * limestone
        else:
            nominator = dry + limestone_addition * limestone + ash_weight * ash_chem[compound]

        value = nominator / (1.0 + limestone_addition + ash_weight)
        if compound == ChemickaLatka.SiO2:
            value = sio2_correction(value)
        all_compounds[:, compound] = value
    return all_compounds


def calculate_slag(
    sio2: np.ndarray,
    cao: np.ndarray,
    mgo: np.ndarray,
    al2o3: np.ndarray,
    fe: np.ndarray,
    mn: np.ndarray,
    agglomerate_addition: np.ndarray,
) -> np.ndarray:
    return (((sio2 + cao + mgo + al2o3) / 100) * 1000) / (
        (fe + (mn * (1.0 - agglomerate_addition))) / 100
    ) - fe / 100 * 0.5 * 2.14 * 1000 / 100


def calculate_alkali(na2o: np.ndarray, k2o: np.ndarray, fe: np.ndarray, mn: np.ndarray) -> np.ndarray:
    return (na2o + k2o) / (fe + mn) / 1.05 * 1000


def calculate_limestone_usage_coeficient(
    limestone_addition: np.ndarray, fe: np.ndarray, mn: np.ndarray
) -> np.ndarray:
    return (limestone_addition * 100) / ((fe + mn) / 100)


def calculate_met_fe_coeficient(
    met_fe_group: np.ndarray,
    ash_weight: np.ndarray,
    limestone_addition: np.ndarray,
    fe_met: np.ndarray,
    fe: np.ndarray,
) -> np.ndarray:
    return (
        (
            (met_fe_group * -1.0 * ash_weight)
            + ((1.0 - met_fe_group) * -1.0 * (fe_met / (limestone_addition + 1.0)))
        )
        / fe
        * 300
    )


def calculate_fuel_constant(
    ash_percentage: float, si_percentage: float, hbt: float, eta_co: float, msp: float
) -> float:
    return (
        (5 * ash_percentage - 52.5)
        + (50 * si_percentage - 25)
        + (-0.1 * hbt + 110)
        + (-7.5 * eta_co + 367.5)
        + msp
    )


def calculate_coke_weight(use_fuel: np.ndarray, fuel: np.ndarray, fe: np.ndarray) -> np.ndarray:
    return use_fuel * fuel / 1000 * fe / 100


def calculate_agglomerate_fuel_coeficient(
    real_fuel_last_month: float, limestone_weight_on_ton_agglomerate: float
) -> float:
    return real_fuel_last_month - limestone_weight_on_ton_agglomerate * 0.1


def calculate_agglomerate_chem(agglomerate_input_vector: np.ndarray, dry_chem: np.ndarray) -> np.ndarray:
    return agglomerate_input_vector * dry_chem


def calculate_chem_percentage_in_original_state(
    dry_chem: np.ndarray, is_pelet: np.ndarray, is_not_input_to_bf_or_sb_kus: np.ndarray
) -> np.ndarray:
    return (
        dry_chem.sum(axis=1)
        - dry_chem[:, ChemickaLatka.Fe]
        - dry_chem[:, ChemickaLatka.H2O]
        - is_pelet * dry_chem[:, ChemickaLatka.Fe_MET]
        - is_not_input_to_bf_or_sb_kus * dry_chem[:, ChemickaLatka.C]
    )


def penalty(
    all_chem: np.ndarray, chem: ChemickaLatka, average_percentage: float, penalization_constant: float
) -> float:
    return (
        ((all_chem[chem] - average_percentage) / 0.01 * penalization_constant)
        / (all_chem[ChemickaLatka.Fe] + all_chem[ChemickaLatka.Mn])
        * 100
    )


def calculate_co2_constant(input_data: VsadzkaInput) -> float:
    return (
        (
            (input_data.celkove_palivo_uhlie / input_data.msp * input_data.co2_z_uhlia)
            + (input_data.celkove_palivo_koks_orech / input_data.msp * input_data.co2_z_koks_orech)
            + (
                (input_data.msp - input_data.celkove_palivo_uhlie - input_data.celkove_palivo_koks_orech)
                / input_data.msp
                * input_data.co2_z_vp_metalurg
            )
        )
        * input_data.cena_tony_co2
        / 1000
    )


def co2_price_components(c: float, fe: float, co2_component_price_constant: float) -> float:
    return c * fe * co2_component_price_constant


def co2_price_fuel(total_fuel: float, co2_constant: float) -> float:
    return total_fuel * co2_constant


def get_ash_burn_compounds() -> np.ndarray:
    return np.array([(0.0 if compound in ASH_BURN_COMPONENTS else 1.0) for compound in ChemickaLatka])


def alkali_from_chem(chem: np.ndarray) -> float:
    return calculate_alkali(
        chem[ChemickaLatka.Na2O], chem[ChemickaLatka.K2O], chem[ChemickaLatka.Fe], chem[ChemickaLatka.Mn]
    )


def calculate_total_limestone_usage(limestone_weight: float, fe_production: float) -> float:
    return limestone_weight * 1000 / fe_production


def calculate_slag_agglomerate(agglomerate_dry_fe: float) -> float:
    # return -fe / 100 * 0.5 * 2.14 * 1000 / 100
    return agglomerate_dry_fe * -0.107


def calculate_full_aglomerate_weight_to_blast_furnance_input(
    agglomerate_weight_to_blast_furnance_input: float, ash_weight_from_aglomerate_coke: np.ndarray
) -> float:
    return agglomerate_weight_to_blast_furnance_input + ash_weight_from_aglomerate_coke


def calculate_total_agglomerate_weight(original_aglo_weight: float, aglo_coefficient: float) -> float:
    return original_aglo_weight * aglo_coefficient


# TODO replace unnecessary number operations
def calculate_mgo_in_slag(mgo: float, total_weight: float, total_slag: float, fe_production: float) -> float:
    return (mgo / 100 * total_weight) / (total_slag / 1000 * fe_production) * 100


T = TypeVar("T", np.ndarray, float)


def calculate_fuel_addition_for_water_evaporation(
    h2o_evaporation_energy: float,
    coke_calorific_value: float,
    h2o: T,
    fe: T,
    ash_h2o: float,
    bf_input_flag: T,
) -> T:
    return bf_input_flag * (
        ((h2o / fe * 1000) + (5 * ash_h2o)) * (h2o_evaporation_energy / coke_calorific_value)
    )


def calculate_recalculation_price(
    bf_only_total_price: float, aglo_total_price: float, total_weight: float
) -> float:
    return (bf_only_total_price + aglo_total_price) / total_weight


def total_so2(s_from_inputs: float, s_after_annealing: float, smoke_volume: float) -> float:
    return (s_from_inputs - s_after_annealing) * 1000000000 / smoke_volume * 2


def total_sinter_s(sinter_s: float, sinter_weight: float) -> float:
    return sinter_s * sinter_weight / 100


def calculate_limestone_addition(
    limestone_group: np.ndarray,
    sio2: np.ndarray,
    al2o3: np.ndarray,
    cao: np.ndarray,
    mgo: np.ndarray,
    s: np.ndarray,
    ash_weight: np.ndarray,
    kb1_ash_oxid: float,
    limestone_oxid: float,
    pellets_and_additives_vector: np.ndarray,
) -> np.ndarray:
    corrected_s = s * pellets_and_additives_vector * 7.0901
    return (
        (1.0 - limestone_group)
        * (oxid_calculation(sio2_correction(sio2), al2o3, cao, mgo) + corrected_s + kb1_ash_oxid * ash_weight)
        / (-limestone_oxid)
    )


def _price_per_ton_fe(
    chem: np.ndarray, total_fuel: float, recalculation_price: float, co2_price: float, processing_cost: float
) -> float:
    return (100 / chem[ChemickaLatka.Fe] * recalculation_price) + total_fuel + co2_price + processing_cost


def calculate_fuel(
    slag: np.ndarray,
    fe: np.ndarray,
    limestone_addition: np.ndarray,
    fuel_constant: float,
    alkali: np.ndarray,
    limestone_usage_coeficient: np.ndarray,
    met_fe_coeficient: np.ndarray,
) -> np.ndarray:
    return (
        ((0.2 * slag - 60) + (-7.5 * fe + 435)) / 2
        + (0.1 * limestone_addition * 100)
        + ((25 * alkali - 62.5) * 1 / 10)
        + fuel_constant
        + limestone_usage_coeficient
        + met_fe_coeficient
    )


class Vectorized_VIU:
    def __init__(self, input_data: VsadzkaInput, mapping: Optional[Mapping[str, int]] = None):
        self.original_input = input_data
        if mapping is None:
            self.mapping = get_vectorization_mapping(input_data)
        else:
            self.mapping = mapping
        self.price_vector = get_price_vector(input_data, self.mapping)
        self.chem_matrix = get_chemical_composition_matrix(input_data, self.mapping)
        self.dry_chem_matrix = calculate_dry_chemical_composition(self.chem_matrix)
        self.fe_richness_constant = calculate_fe_richness_constant(
            input_data.C_v_sur_fe_minuly_mesiac,
            input_data.Si_v_sur_fe_minuly_mesiac,
            input_data.Mn_v_sur_fe_minuly_mesiac,
        )
        self.fe_with_raw_fe_richness = calculate_fe_with_raw_fe_richness(
            self.fe_richness_constant, self.dry_chem_matrix[:, ChemickaLatka.Fe]
        )
        self.fe_with_raw_fe_richness_and_losses = calculate_fe_with_losses(
            self.fe_with_raw_fe_richness, input_data
        )
        self.fe_loss_multiplier = calculate_fe_loss_multiplier(input_data)
        self.dry_fe_mn = fe_mn(self.dry_chem_matrix)
        self.recyclable_vector = calculate_recyclable_vector(self.dry_chem_matrix[:, ChemickaLatka.Mn])
        self.agglomerate_input_vector = calculate_agglomerate_input_vector(input_data, self.mapping)
        self.pellets_input_vector = calculate_pellets_input_vector(input_data, self.mapping)
        self.agglomerate_addition_vector = calculate_ingredient_type_vector(
            input_data, self.mapping, TypPrisady.PRISADA_DO_AGLOMERATU
        )
        self.additives_vector = calculate_ingredient_type_vector(
            input_data, self.mapping, TypPrisady.PRISADY_DO_VP
        )
        self.concentrate_vector = calculate_ingredient_type_vector(
            input_data, self.mapping, TypPrisady.KONCENTRAT
        )
        self.agglomerate_vector = calculate_ingredient_type_vector(
            input_data, self.mapping, TypPrisady.AGLORUDA
        )
        self.agglomeration_fuel_vector = calculate_agglomeration_fuel(
            self.agglomerate_input_vector,
            self.dry_fe_mn,
            input_data.realne_palivo_pri_p2_z_minuleho_mesiaca,
        )
        self.limestone_group_vector = calculate_limestone_group_vector(input_data, self.mapping)
        self.ash_weight_from_500kg_coke_vector = ash_weight_from_500kg_coke(
            self.limestone_group_vector,
            self.dry_chem_matrix[:, ChemickaLatka.Fe],
            self.dry_chem_matrix[:, ChemickaLatka.Fe_MET],
            self.agglomeration_fuel_vector,
            input_data.popol_kb1.percento_popola,
            input_data.popol_koks_prach.percento_popola,
        )
        self.kb1_ash_oxid = oxid_calculation(
            input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.SiO2],
            input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.Al2O3],
            input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.CaO],
            input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.MgO],
        )
        self.limestone_oxid = oxid_calculation(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.SiO2],
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.Al2O3],
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.CaO],
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.MgO],
        )

        self.limestone_addition_vector = calculate_limestone_addition(
            self.limestone_group_vector,
            self.dry_chem_matrix[:, ChemickaLatka.SiO2],
            self.dry_chem_matrix[:, ChemickaLatka.Al2O3],
            self.dry_chem_matrix[:, ChemickaLatka.CaO],
            self.dry_chem_matrix[:, ChemickaLatka.MgO],
            self.dry_chem_matrix[:, ChemickaLatka.S],
            self.ash_weight_from_500kg_coke_vector,
            self.kb1_ash_oxid,
            self.limestone_oxid,
            self.pellets_input_vector + self.additives_vector,
        )

        self.chem_composition_with_limestone_matrix = calculate_chem_composition_with_limestone(
            self.dry_chem_matrix,  # okay
            self.limestone_addition_vector,
            input_data.vapenec.chemicke_zlozenie,
            input_data.popol_kb1.chemicke_zlozenie,
            self.ash_weight_from_500kg_coke_vector,
        )
        self.ash_h2o = input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.H2O]
        self.s_in_kb1_ash = input_data.popol_kb1.chemicke_zlozenie[ChemickaLatka.S]
        self.s_in_kb3_ash = input_data.popol_kb3.chemicke_zlozenie[ChemickaLatka.S]
        self.s_in_pu_ash = input_data.popol_pu.chemicke_zlozenie[ChemickaLatka.S]
        self.water_evaporation_energy = input_data.energia_na_odparenie_h2o
        self.coke_calorific_value = input_data.kaloriticka_hodnota_koks
        self.blast_furnance_input_vector = calculate_blast_furnance_input_vector(input_data, self.mapping)

        self.under_5mm_vector = calculate_under_5mm_vector(input_data, self.mapping)
        self.fuel_addition_for_water_evaporation = calculate_fuel_addition_for_water_evaporation(
            self.water_evaporation_energy,
            self.coke_calorific_value,
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.H2O],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
            self.ash_h2o,
            self.blast_furnance_input_vector,
        )
        self.slag = calculate_slag(
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.SiO2],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.CaO],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.MgO],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Al2O3],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Mn],
            self.agglomerate_addition_vector,
        )
        self.alkali = calculate_alkali(
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Na2O],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.K2O],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Mn],
        )
        self.limestone_usage_coeficient_vector = calculate_limestone_usage_coeficient(
            self.limestone_addition_vector,
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Mn],
        )
        self.met_fe_group = calculate_met_fe_group(input_data, self.mapping)
        self.met_fe_coeficient = calculate_met_fe_coeficient(
            self.met_fe_group,
            self.ash_weight_from_500kg_coke_vector,
            self.limestone_addition_vector,
            self.dry_chem_matrix[:, ChemickaLatka.Fe_MET],
            self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
        )
        self.fuel_constant = calculate_fuel_constant(
            input_data.popol_kb1.percento_popola,
            input_data.percento_Si,
            input_data.hbt,
            input_data.eta_co,
            input_data.msp,
        )
        self.blast_furnance_fuel = (
            calculate_fuel(
                self.slag,
                self.chem_composition_with_limestone_matrix[:, ChemickaLatka.Fe],
                self.limestone_addition_vector,
                self.fuel_constant,
                self.alkali,
                self.limestone_usage_coeficient_vector,
                self.met_fe_coeficient,
            )
            + self.pellets_input_vector * self.under_5mm_vector * 2
        )

        self.blast_furnance_coke_weight_coeficient = calculate_coke_weight(
            self.blast_furnance_input_vector,
            self.blast_furnance_fuel,
            self.dry_chem_matrix[:, ChemickaLatka.Fe],
        )
        self.agglomerate_fuel_coeficient = calculate_agglomerate_fuel_coeficient(
            input_data.realne_palivo_pri_p2_z_minuleho_mesiaca,
            input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu,
        )
        self.limestone_group_2_vector = calculate_limestone_group_2_vector(input_data, self.mapping)
        self.is_pelet_vector = calculate_is_pelet_vector(input_data, self.mapping)
        self.is_not_input_to_bf_or_sb_kus_vector = calculate_is_not_input_to_bf_or_sb_kus_vector(
            input_data, self.mapping
        )
        self.chem_percentage_in_original_state = calculate_chem_percentage_in_original_state(
            self.dry_chem_matrix, self.is_pelet_vector, self.is_not_input_to_bf_or_sb_kus_vector
        )
        self.chem_percentage_in_original_state_for_agglomerate = (
            self.chem_percentage_in_original_state * self.agglomerate_input_vector / 100
        )
        self.coke_ash_percentage_div_100000 = input_data.popol_koks_prach.percento_popola / 100000
        self.ash_weight_from_aglomerate_coke_constant = (
            input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu
            * 7.35
            / 10000
            * input_data.popol_koks_prach.percento_popola
        )
        self.agglomerate_fuel_ash_limestone_addition = agglomerate_fuel_ash_limestone_addition(
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.SiO2],
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Al2O3],
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.CaO],
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.MgO],
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe]
            / 10000
            * input_data.popol_kb1.percento_popola
            * 0.5,
            self.kb1_ash_oxid,
            self.limestone_oxid,
        )
        self.aglomerate_fuel_ash_fe_percentage = input_data.popol_koks_prach.chemicke_zlozenie[
            ChemickaLatka.Fe
        ] / (1 + self.agglomerate_fuel_ash_limestone_addition)
        self.ash_chem = np.array(input_data.popol_kb1.chemicke_zlozenie)
        self.ash_richness = input_data.popol_kb1.percento_popola / 100
        self.ash_burn_compounds = get_ash_burn_compounds()
        self.ash_chem_for_total_chem_calc = (
            np.array(input_data.popol_kb1.chemicke_zlozenie) * self.ash_burn_compounds
        )
        self.kc_vector = calculate_agglomerate_type_vector(
            AglomeracnyTyp.KONCENTRAT, input_data, self.mapping
        )
        self.ar_vector = calculate_agglomerate_type_vector(AglomeracnyTyp.AGLORUDA, input_data, self.mapping)
        self.aglo_fuel_price_constant = input_data.cena_aglom_paliva / 1000
        self.bf_fuel_price_constant = input_data.popol_kb1.percento_popola / 100000 * input_data.cena_vp_koksu
        self.bf_fuel_price_constant_2 = input_data.cena_vp_koksu / 1000
        self.bf_coke_price = input_data.cena_vp_koksu
        self.limestone_vector = calculate_limestone_vector(input_data, self.mapping)
        self.average_P_percentage = input_data.priemerne_percento_P
        self.penalization_constant_P = 1.07
        self.average_S_percentage = input_data.priemerne_percento_S
        self.penalization_constant_S = 0.71
        self.co2_fuel_price_constant = calculate_co2_constant(input_data)
        self.co2_component_price_constant = input_data.cena_tony_co2 * 3.664 / 10000
        self.processing_cost_constant = (
            input_data.bvs_minuly_mesiac * input_data.spracovacie_naklady_na_tonu_suroveho_zeleza / 10000
        )
        self.agglomerate_co2_cost_constant = (
            input_data.co2_z_koks_prach * input_data.cena_tony_co2 / 10 / 1.05
        )
        self.agglomerate_processing_cost_constant = input_data.spracovacie_naklady_na_tonu_aglomeratu
        self.aglo_coefficient = input_data.koeficient_vyroby_aglomeratu
        self.S_correction_coef = input_data.korekcny_koeficient_pre_S_do_aglomeratu
        self.s_after_annealing_multiplier = get_s_after_annealing_multiplier_vector(
            input_data, self.mapping, self.dry_chem_matrix[:, ChemickaLatka.C]
        )
        self.pellets_price_vector = self.price_vector * self.pellets_input_vector
        self.vp_device_efficiency_koef = input_data.koef_ucinnosti_zariadenia_vp
        self.pellet_separation_coef = input_data.koef_odtriedenia_peliet
        self.vp_coke_price = input_data.cena_vp_koksu
        self.bvs_coef = input_data.koef_na_bvs
        self.under_5mm_agglomerate = input_data.posditny_podiel_pod_5mm_aglomerat
        self.msp_msk_weight = 500 - input_data.planovane_mnozstvo_zp - input_data.planovane_mnozstvo_pu
        self.fe_kal_percent = input_data.percento_fe_kal
        self.fe_vyhoz_percent = input_data.percento_fe_vyhoz
        self.mspu_weight = input_data.hmotnost_mspu
        self.kb1_ash_percentage = input_data.popol_kb1.percento_popola
        self.si_percentage = input_data.percento_Si
        self.hbt = input_data.hbt
        self.eta_co = input_data.eta_co
        self.msp = input_data.msp
        self.total_fuel_coal = input_data.celkove_palivo_uhlie
        self.total_fuel_coke = input_data.celkove_palivo_koks_orech
        self.planned_zp_amount = input_data.planovane_mnozstvo_zp
        self.planned_pu_amount = input_data.planovane_mnozstvo_pu
        self.zp_price = input_data.cena_zp
        self.pu_price = input_data.cena_pu

    def total_met_fe(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        return -chem[ChemickaLatka.Fe_MET] / chem[ChemickaLatka.Fe] * 1.05 / 100 * 1000 * 30

    def cao_to_limestone(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.desulf_cao(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / self.total_bf_input_weight(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * 100
        )

    def desulf_cao(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.total_input_s(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.raw_fe_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            / 32
            * 56
            / 1000
        )

    def total_input_s(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self.input_s_from_fuel_for_t_fe_fuel(
            corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
        ) + self.input_s_from_fuel_for_t_bf_input_ore(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

    def input_s_from_fuel_for_t_bf_input_ore(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.blast_furnance_input_s_chem(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / 100
            * self.bf_input_ore_weight(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * 1000
            / self.raw_fe_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
        )

    def bf_input_ore_weight(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self.total_bf_input_weight(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        ) - (
            self.blast_furnance_coke_weight(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.ash_richness
        )

    def input_s_from_fuel_for_t_fe_fuel(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        i207 = (
            self.coke_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * np.mean([self.s_in_kb1_ash, self.s_in_kb3_ash])
            / 100
        )
        i208 = (
            self.pu_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * self.s_in_pu_ash
            / 100
        )
        return (
            (i207 + i208)
            * 1000
            / self.raw_fe_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
        )

    def coke_weight(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        return (
            self.raw_fe_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * self.msp_msk_weight
            / 1000
        )

    def pu_weight(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        return (
            self.raw_fe_weight(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * self.mspu_weight
            / 1000
        )

    def raw_fe_weight(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        return self.fe_production(
            corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
        ) - self.vyhoz_kal_loss(corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)

    def vyhoz_kal_loss(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        fe_production = self.fe_production(
            corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
        )
        return (self.fe_kal_percent / 100 * 13 / 1000 * fe_production) + (
            self.fe_vyhoz_percent / 100 * 7 / 1000 * fe_production
        )

    def impact_on_fuel(
        self,
        corrected_weights_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return self.weighted_average_under_5mm(
            corrected_weights_vector, podsitne_pelety_vsadzka, prisada_podsitne_pelety, vaha_podsitnych_peliet
        ).sum() + self.weighted_average_under_5mm_agglomerate(
            corrected_weights_vector, podsitne_pelety_vsadzka, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )

    def weighted_average_under_5mm_agglomerate(
        self,
        corrected_weights_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.under_5mm_agglomerate
            * 2
            * self.total_agglomerate_weight(
                corrected_weights_vector, podsitne_pelety_vsadzka, vaha_podsitnych_peliet
            )
            / self.total_bf_input_weight(
                corrected_weights_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def weighted_average_under_5mm(
        self,
        corrected_weights_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return (
            (self.additives_vector + self.pellets_input_vector)
            * self.under_5mm_vector
            * 2
            * self.bf_input_share(
                corrected_weights_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def bf_input_share(
        self,
        corrected_weights_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return (
            (self.additives_vector + self.pellets_input_vector)
            * corrected_weights_vector
            / self.total_bf_input_weight(
                corrected_weights_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def vaha_podsitnych_peliet_vectorized(self, weight_vector: np.ndarray) -> float:
        return (
            sum(
                weight_vector
                * self.pellets_input_vector
                * self.under_5mm_vector
                / 100
                / self.pellet_separation_coef
                * (1 - self.pellet_separation_coef)
            )
            if self.pellet_separation_coef != 1
            else 0
        )

    def celkova_vaha_peliet_vectorized(self, weights_vector: np.ndarray) -> float:
        pellets_weight = self.pellets_input_vector * weights_vector
        pellets_under_5mm = self.pellets_input_vector * self.under_5mm_vector
        return sum((-pellets_weight * self.pellet_separation_coef * pellets_under_5mm / 100) + pellets_weight)

    def pomer_vahy_pelety_vectorized(
        self, weights_vector: np.ndarray, corrected_weights_vector: np.ndarray
    ) -> float:
        return 100 / self.celkova_vaha_peliet_vectorized(weights_vector) * corrected_weights_vector

    def cena_podsitnych_peliet_vectorized(
        self, weights_vector: np.ndarray, corrected_weights_vector: np.ndarray
    ) -> float:
        return sum(
            self.pellets_price_vector
            / 100
            * self.pomer_vahy_pelety_vectorized(weights_vector, corrected_weights_vector)
        )

    def prisada_podsitnych_peliet_vectorized(
        self,
        chemistry_vector: np.ndarray,
        corrected_weights_vector: np.ndarray,
        weights_vector: np.ndarray,
    ) -> Prisada:
        return Prisada(
            nazov="Podsitne_pelety",
            cena_za_tonu=self.cena_podsitnych_peliet_vectorized(weights_vector, corrected_weights_vector),
            chemicke_zlozenie=tuple(
                inverzia_pomer_prvku_v_prisade_susina(chemia, chemistry_vector[1])
                for chemia in chemistry_vector
            ),
            typ_prisady=TypPrisady.AGLORUDA,
            bazicky_typ=BazickyTyp.ZIADEN,
            aglomeracny_typ=AglomeracnyTyp.AGLORUDA,
        )

    def processing_cost_for_ton_fe_vp(
        self,
        corrected_weight_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            corrected_weight_vector, podsitne_pelety_vsadzka, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        total_chem = chem.sum() - chem[ChemickaLatka.Fe] - chem[ChemickaLatka.C] - chem[ChemickaLatka.H2O]
        return total_chem * self.processing_cost_constant

    def total_alkali_weight(
        self,
        corrected_weight_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            corrected_weight_vector, podsitne_pelety_vsadzka, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return (
            (chem[ChemickaLatka.Na2O] + chem[ChemickaLatka.K2O])
            * self.total_bf_input_weight(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / self.fe_production(corrected_weight_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            / 100
            * 1000
        )

    def _vypocet_paliva_vectorized(
        self,
        troska: float,
        fe: float,
        spotreba_vapenca: float,
        hmotnost_alkalii: float,
        met_fe: float,
        palivo_na_odparenie: float,
        bazicita: float,
    ) -> float:
        return (
            (((0.2 * troska - 60) + (-7.5 * fe + 435)) / 2)
            + (0.1 * spotreba_vapenca * 100)
            + (5 * self.kb1_ash_percentage - 52.5)
            + (50 * self.si_percentage - 25)
            + (-0.1 * self.hbt + 110)
            + (-7.5 * self.eta_co + 367.5)
            + ((25 * hmotnost_alkalii - 62.5) * 1 / 10)
            + met_fe
            + palivo_na_odparenie
            + (bazicita * 100 - 100)
        ) * 5 / 6 + self.msp

    def vypocet_paliva_vectorized(
        self,
        corrected_weight_vector: np.ndarray,
        podsitne_pelety_vsadzka: float,
        vaha_podsitnych_peliet: float,
        prisada_podsitne_pelety: Prisada,
    ) -> float:
        return self._vypocet_paliva_vectorized(
            self.total_slag(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.blast_furnance_input_chem(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )[ChemickaLatka.Fe]
            * self.bvs_coef,
            self.total_limestone_usage(
                corrected_weight_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
            )
            / 100,
            self.total_alkali_weight(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                vaha_podsitnych_peliet,
                prisada_podsitne_pelety,
            ),
            self.total_met_fe(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.fuel_addition_to_water_evaporation(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.total_basicity(
                corrected_weight_vector,
                podsitne_pelety_vsadzka,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )

    def percento_recyklatov_vectorized(
        self,
        corrected_weight_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        podsitne_pelety_vsadzka: float,
    ) -> float:
        return (
            self.suma_recyklatov_vectorized(corrected_weight_vector)
            / self.hmotnost_aglomeracnej_vsadzky_vectorized(
                corrected_weight_vector, vaha_podsitnych_peliet, podsitne_pelety_vsadzka
            )
            * 100
        )

    def suma_vah_pre_prisadu_vectorized(
        self, corrected_weights_vector: np.ndarray, vector: np.ndarray, vaha_podsitnych_peliet: float = 0
    ) -> float:
        if (vector == self.agglomerate_vector).all():
            return (corrected_weights_vector * vector).sum() + vaha_podsitnych_peliet
        return (vector * corrected_weights_vector).sum()

    def hmotnost_aglomeracnej_vsadzky_vectorized(
        self,
        corrected_weight_vector: np.ndarray,
        vaha_podsitnych_peliet: float,
        podsitne_pelety_vsadzka: float,
    ) -> float:
        vaha = (corrected_weight_vector * self.agglomerate_input_vector).sum() + vaha_podsitnych_peliet
        popol = self.ash_weight_from_aglomerate_coke(
            corrected_weight_vector, podsitne_pelety_vsadzka, vaha_podsitnych_peliet
        )
        return vaha + popol

    def suma_recyklatov_vectorized(self, corrected_weight_vector: np.ndarray) -> float:
        return (corrected_weight_vector * self.agglomerate_addition_vector * self.recyclable_vector).sum()

    def fe_production(
        self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float, prisada_podsitne_pelety: Prisada
    ) -> float:
        return (self.fe_with_raw_fe_richness * weights_vector).sum() + (
            (
                pomer_prvku_v_prisade_susina(prisada_podsitne_pelety, ChemickaLatka.Fe)
                * self.fe_richness_constant
            )
            / 100
            * vaha_podsitnych_peliet
        )

    def fe_production_with_losses(
        self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float, prisada_podsitne_pelety: Prisada
    ) -> float:
        return (
            self.fe_with_raw_fe_richness_and_losses * weights_vector
        ).sum() + calculate_fe_with_losses_wo_input_data(
            (
                pomer_prvku_v_prisade_susina(prisada_podsitne_pelety, ChemickaLatka.Fe)
                * self.fe_richness_constant
            )
            / 100
            * vaha_podsitnych_peliet,
            self.fe_loss_multiplier,
        )

    def _blast_furnance_coke_weight(
        self,
        weights_vector: np.ndarray,
        total_agglomerate_weight: float,
        agglomerate_fuel: float,
        agglomerate_dry_fe: float,
    ) -> float:
        return (self.blast_furnance_coke_weight_coeficient * weights_vector).sum() + (
            (total_agglomerate_weight * agglomerate_fuel * agglomerate_dry_fe) / 100000
        )

    def blast_furnance_coke_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._blast_furnance_coke_weight(
            weights_vector,
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            self.agglomerate_fuel(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.agglomerate_dry_fe(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )

    def limestone_weight_2(self, weights_vector: np.ndarray) -> float:
        return (self.limestone_group_2_vector * weights_vector).sum()

    def agglomerate_weight_without_ash(
        self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float
    ) -> float:
        return (self.agglomerate_input_vector * weights_vector).sum() + vaha_podsitnych_peliet

    def sinter_s_after_annealing(self, weights_vector: np.ndarray, sinter_ash_weight: float) -> float:
        return (
            (
                self.dry_chem_matrix[:, ChemickaLatka.S] * self.s_after_annealing_multiplier * weights_vector
            ).sum()
            + (sinter_ash_weight * self.ash_chem[ChemickaLatka.S])
        ) * 0.0067

    def _agglomerate_dry_fe(
        self,
        weights_vector: np.ndarray,
        ash_weight_from_aglomerate_coke: float,
        total_agglomerate_weight: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet,
    ) -> float:
        return (
            (self.dry_chem_matrix[:, ChemickaLatka.Fe] * weights_vector * self.agglomerate_input_vector).sum()
            + (
                pomer_prvku_v_prisade_susina(prisada_podsitne_pelety, ChemickaLatka.Fe)
                * vaha_podsitnych_peliet
            )
            + (self.aglomerate_fuel_ash_fe_percentage * ash_weight_from_aglomerate_coke)
        ) / total_agglomerate_weight

    def agglomerate_dry_fe(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._agglomerate_dry_fe(
            weights_vector,
            self.ash_weight_from_aglomerate_coke(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

    def full_aglomerate_weight_to_blast_furnance_input(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return calculate_full_aglomerate_weight_to_blast_furnance_input(
            self.agglomerate_weight_to_blast_furnance_input(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky
            ),
            self.ash_weight_from_aglomerate_coke(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
        )

    def total_agglomerate_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return calculate_total_agglomerate_weight(
            self.full_aglomerate_weight_to_blast_furnance_input(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            self.aglo_coefficient,
        )

    def _fuel_to_produce_agglomerate(
        self, limestone_weight_2: float, agglomerate_weight_without_ash: float
    ) -> float:
        fuel_denominator = agglomerate_weight_without_ash - limestone_weight_2
        # This is technically not good and we should mark this weights as invalid
        if fuel_denominator == 0.0:
            return self.agglomerate_fuel_coeficient
        fuel = limestone_weight_2 / (agglomerate_weight_without_ash - limestone_weight_2)
        return self.agglomerate_fuel_coeficient + fuel * 100 / 1.3

    def fuel_to_produce_agglomerate(self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float) -> float:
        return self._fuel_to_produce_agglomerate(
            self.limestone_weight_2(weights_vector),
            self.agglomerate_weight_without_ash(weights_vector, vaha_podsitnych_peliet),
        )

    def agglomerate_weight_to_blast_furnance_input(
        self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float
    ) -> float:
        return (
            self.chem_percentage_in_original_state_for_agglomerate * weights_vector
        ).sum() + vaha_podsitnych_peliet

    def _ash_weight_from_aglomerate_coke(
        self,
        fuel_to_produce_agglomerate: float,
        agglomerate_weight_to_blast_furnance_input: float,
    ) -> float:
        return (
            fuel_to_produce_agglomerate
            * agglomerate_weight_to_blast_furnance_input  # spravne
            * self.coke_ash_percentage_div_100000  # spravne
        ) + self.ash_weight_from_aglomerate_coke_constant  # spravne

    def ash_weight_from_aglomerate_coke(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._ash_weight_from_aglomerate_coke(
            self.fuel_to_produce_agglomerate(weights_vector, vaha_podsitnych_peliet),
            self.agglomerate_weight_to_blast_furnance_input(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky
            ),
        )

    def _agglomerate_fuel(self, agglomerate_chem: np.ndarray) -> float:
        fe = agglomerate_chem[ChemickaLatka.Fe]
        return calculate_fuel(
            calculate_slag_agglomerate(fe),
            fe,
            0.0,
            self.fuel_constant,
            alkali_from_chem(agglomerate_chem),
            0.0,
            0.0,
        )

    def agglomerate_fuel(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._agglomerate_fuel(
            self.agglomerate_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def slag_agglomerate(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return calculate_slag_agglomerate(
            self.agglomerate_dry_fe(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def _agglomerate_chem(
        self,
        weights_vector: np.ndarray,
        ash_weight_from_agglomerate_coke: float,
        agglomerate_dry_fe: float,
        full_aglomerate_weight_to_blast_furnance_input: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        chem = np.zeros(len(ChemickaLatka))
        chem[ChemickaLatka.Fe] = agglomerate_dry_fe
        chem[ChemickaLatka.FeO] = 7.0
        chem[ChemickaLatka.Fe2O3] = (chem[ChemickaLatka.Fe] - chem[ChemickaLatka.FeO] * 0.7778) / 0.7
        chem[ChemickaLatka.C] = 0.1
        for compound in ChemickaLatka:
            if compound not in {
                ChemickaLatka.H2O,
                ChemickaLatka.Fe_MET,
                ChemickaLatka.Fe,
                ChemickaLatka.FeO,
                ChemickaLatka.Fe2O3,
                ChemickaLatka.C,
            }:
                chem[compound] = (
                    (self.dry_chem_matrix[:, compound] * weights_vector * self.agglomerate_input_vector).sum()
                    + (
                        pomer_prvku_v_prisade_susina(prisada_podsitne_pelety, compound)
                        * vaha_podsitnych_peliet
                    )
                    + (self.ash_chem[compound] * ash_weight_from_agglomerate_coke)
                ) / full_aglomerate_weight_to_blast_furnance_input

        return chem

    def agglomerate_chem(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return self._agglomerate_chem(
            weights_vector,
            self.ash_weight_from_aglomerate_coke(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            self.agglomerate_dry_fe(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.full_aglomerate_weight_to_blast_furnance_input(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

    def calculate_chem(self, weights_vector: np.ndarray) -> np.ndarray:
        chem = np.zeros(len(ChemickaLatka))
        total_weight = weights_vector.sum()
        if total_weight == 0.0:
            return chem
        for compound in ChemickaLatka:
            chem[compound] = (weights_vector * self.dry_chem_matrix[:, compound]).sum() / total_weight
        return chem

    def blast_furnance_input_chem_without_agglomerate(self, weights_vector: np.ndarray) -> np.ndarray:
        return self.calculate_chem(weights_vector * (1 - self.agglomerate_input_vector))

    def bf_input_chem_for_limestone(self, weights_vector: np.ndarray) -> np.ndarray:
        return self.calculate_chem(weights_vector * self.limestone_vector)

    def bf_input_chem_for_pellets_and_bf_additions(self, weights_vector: np.ndarray) -> np.ndarray:
        return self.calculate_chem(weights_vector * self.blast_furnance_input_vector)

    def bf_input_chem_for_pellets(self, weights_vector: np.ndarray) -> np.ndarray:
        return self.calculate_chem(weights_vector * self.pellets_input_vector)

    def total_bf_input_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        aglo_weight = self.total_agglomerate_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
        )
        bf_weight = (weights_vector * (1 - self.agglomerate_input_vector)).sum()
        ash_weight = (
            self.blast_furnance_coke_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.ash_richness
        )
        return aglo_weight + bf_weight + ash_weight

    def _blast_furnance_input_chem(
        self,
        agglomerate_chem: np.ndarray,
        bf_only_chem: np.ndarray,
        limestone_chem: np.ndarray,
        aglo_weight: float,
        bf_weight: float,
        limestone_weight: float,
        ash_weight: float,
        cao_correction: float,
    ) -> np.ndarray:
        chem = np.zeros(len(ChemickaLatka))
        total_weight = aglo_weight + bf_weight + limestone_weight + ash_weight
        if total_weight == 0.0:
            return chem
        ash_total = self.ash_chem_for_total_chem_calc * ash_weight
        limestone_total = limestone_chem * limestone_weight
        total_chem = agglomerate_chem * aglo_weight + bf_only_chem * bf_weight + limestone_total + ash_total

        # ash_sio2_correction = -0.5 * total_chem[ChemickaLatka.Fe] / 100 * 60 / 28
        ash_sio2_correction = -0.3 / 28.0 * total_chem[ChemickaLatka.Fe]

        total_chem[ChemickaLatka.SiO2] = total_chem[ChemickaLatka.SiO2] + ash_sio2_correction
        result_chem = total_chem / total_weight
        result_chem[ChemickaLatka.CaO] = result_chem[ChemickaLatka.CaO] - cao_correction
        return result_chem

    def blast_furnance_input_chem(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return self._blast_furnance_input_chem(
            self.agglomerate_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.bf_input_chem_for_pellets_and_bf_additions(weights_vector),
            self.bf_input_chem_for_limestone(weights_vector),
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            (weights_vector * self.blast_furnance_input_vector).sum(),
            (weights_vector * self.limestone_vector).sum(),
            self.blast_furnance_coke_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.ash_richness,
            self.cao_to_limestone(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )

    def _blast_furnance_input_s_chem(
        self,
        agglomerate_chem: np.ndarray,
        bf_only_chem: np.ndarray,
        limestone_chem: np.ndarray,
        aglo_weight: float,
        bf_weight: float,
        limestone_weight: float,
        ash_weight: float,
    ) -> float:
        total_weight = aglo_weight + bf_weight + limestone_weight + ash_weight
        if total_weight == 0.0:
            return 0.0
        ash_total = self.ash_chem_for_total_chem_calc * ash_weight
        limestone_total = limestone_chem * limestone_weight
        total_chem = agglomerate_chem * aglo_weight + bf_only_chem * bf_weight + limestone_total + ash_total
        return total_chem[ChemickaLatka.S] / total_weight

    def blast_furnance_input_s_chem(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> np.ndarray:
        return self._blast_furnance_input_s_chem(
            self.agglomerate_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.bf_input_chem_for_pellets_and_bf_additions(weights_vector),
            self.bf_input_chem_for_limestone(weights_vector),
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            (weights_vector * self.blast_furnance_input_vector).sum(),
            (weights_vector * self.limestone_vector).sum(),
            self.blast_furnance_coke_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.ash_richness,
        )

    def alkali_agglomerate(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return alkali_from_chem(
            self.agglomerate_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def zn_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.blast_furnance_input_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )[
                ChemickaLatka.Zn
            ]  # spravne
            * self.total_bf_input_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )  # spravne
            * 10000
            / self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)  # nespravne
        )

    def kc_ar_ratio(self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float) -> float:
        ar = (self.ar_vector * weights_vector).sum()
        if ar == 0.0:
            return float("inf")
        return (self.kc_vector * weights_vector).sum() / (ar + vaha_podsitnych_peliet)

    def _total_slag(self, chem: np.ndarray) -> float:
        return calculate_slag(
            chem[ChemickaLatka.SiO2],
            chem[ChemickaLatka.CaO],
            chem[ChemickaLatka.MgO],
            chem[ChemickaLatka.Al2O3],
            chem[ChemickaLatka.Fe] * self.fe_richness_constant,
            0.0,
            0.0,
        )

    def total_slag(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return self._total_slag(chem)

    def _total_limestone_weight(self, weights_vector: np.ndarray) -> float:
        return (weights_vector * self.limestone_vector).sum()

    def total_limestone_usage(
        self, weights_vector: np.ndarray, vaha_podsitnych_peliet: float, prisada_podsitne_pelety: Prisada
    ) -> float:
        return calculate_total_limestone_usage(
            self._total_limestone_weight(weights_vector),
            self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety),
        )

    def total_alkali(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return alkali_from_chem(
            self.blast_furnance_input_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def _total_fuel(
        self,
        total_slag: float,
        limestone_weight: float,
        chem: np.ndarray,
        fe_production: float,
        fuel_addition_for_water_evaporation: float,
    ) -> float:
        return (
            calculate_fuel(
                total_slag,
                chem[ChemickaLatka.Fe] * self.bvs_coef,
                calculate_total_limestone_usage(limestone_weight, fe_production) / 100,
                self.fuel_constant,
                alkali_from_chem(chem),
                0.0,
                0.0,
            )
            + fuel_addition_for_water_evaporation
        )

    def _fuel_addition_to_water_evaporation(self, chem: np.ndarray) -> float:
        return calculate_fuel_addition_for_water_evaporation(
            self.water_evaporation_energy,
            self.coke_calorific_value,
            chem[ChemickaLatka.H2O],
            chem[ChemickaLatka.Fe],
            self.ash_h2o,
            1.0,
        )

    def fuel_addition_to_water_evaporation(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self._fuel_addition_to_water_evaporation(
                self.blast_furnance_input_chem(
                    weights_vector,
                    vaha_podsitnych_peliet_do_vsadzky,
                    prisada_podsitne_pelety,
                    vaha_podsitnych_peliet,
                )
            )
            * self.vp_device_efficiency_koef
        )

    def total_fuel(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )  # okay
        return self._total_fuel(
            self.total_slag(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self._total_limestone_weight(weights_vector),
            chem,
            self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety),  # okay
            self._fuel_addition_to_water_evaporation(chem) * self.vp_device_efficiency_koef,  # okay
        ) + self.impact_on_fuel(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )  # okay

    def _cost_vector(self, weights_vector: np.ndarray) -> np.ndarray:
        return self.price_vector * weights_vector

    def _agglomerate_total_price(
        self,
        cost_vector: np.ndarray,
        total_agglomerate_weight: float,
        fuel_to_produce_agglomerate: float,
        agglomerate_processing_cost: float,
        agglomerate_co2_cost: float,
    ) -> float:
        return (
            ((cost_vector * self.agglomerate_input_vector).sum())
            + (total_agglomerate_weight * fuel_to_produce_agglomerate * self.aglo_fuel_price_constant)
            + agglomerate_processing_cost
            + agglomerate_co2_cost
        )

    def agglomerate_total_price(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._agglomerate_total_price(
            self._cost_vector(weights_vector),
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadky, vaha_podsitnych_peliet
            ),
            self.fuel_to_produce_agglomerate(weights_vector, vaha_podsitnych_peliet),
            self.agglomerate_processing_cost(
                weights_vector, vaha_podsitnych_peliet_do_vsadky, vaha_podsitnych_peliet
            ),
            self.agglomerate_co2_cost(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        ) + (vaha_podsitnych_peliet * prisada_podsitne_pelety.cena_za_tonu)

    def _agglomerate_processing_cost(self, total_agglomerate_weight: float) -> float:
        return total_agglomerate_weight * self.agglomerate_processing_cost_constant

    def agglomerate_processing_cost(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadky: float,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._agglomerate_processing_cost(
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadky, vaha_podsitnych_peliet
            )
        )

    def bf_only_total_price(self, cost_vector: np.ndarray) -> float:
        return (cost_vector * (1 - self.agglomerate_input_vector)).sum()

    def _agglomerate_co2_cost(
        self, total_agglomerate_weight: float, agglomerate_fuel: float, agglomerate_fe_dry: float
    ) -> float:
        return (
            total_agglomerate_weight
            * agglomerate_fuel
            * self.agglomerate_co2_cost_constant
            / agglomerate_fe_dry
        )

    def agglomerate_co2_cost(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._agglomerate_co2_cost(
            self.total_agglomerate_weight(
                weights_vector, vaha_podsitnych_peliet_do_vsadzky, vaha_podsitnych_peliet
            ),
            self.fuel_to_produce_agglomerate(weights_vector, vaha_podsitnych_peliet),
            self.agglomerate_dry_fe(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )

    def recalculation_price(
        self,
        corrected_weights_vector: np.ndarray,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return calculate_recalculation_price(
            self.bf_only_total_price(self._cost_vector(weights_vector)),
            self.agglomerate_total_price(  # spravne
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.total_bf_input_weight(  # spravne
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )

    def _penalty_P(self, chem: np.ndarray) -> float:
        return penalty(chem, ChemickaLatka.P, self.average_P_percentage, self.penalization_constant_P)

    def _penalty_S(self, chem: np.ndarray) -> float:
        return penalty(chem, ChemickaLatka.S, self.average_S_percentage, self.penalization_constant_S)

    def penalty_P(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._penalty_P(
            self.blast_furnance_input_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def penalty_S(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self._penalty_S(
            self.blast_furnance_input_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
        )

    def co2_vp_price(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ):
        return (
            self.total_fuel(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            * self.co2_fuel_price_constant
        )

    def cena_co2_v_tonach_na_1_tsz_zo_suroviny_vectorized(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ):
        chem = self.blast_furnance_input_chem(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        return self.co2_component_price_constant * chem[ChemickaLatka.Fe] * chem[ChemickaLatka.C]

    def total_co2_price(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self.co2_vp_price(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        ) + self.cena_co2_v_tonach_na_1_tsz_zo_suroviny_vectorized(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

    def price_per_ton_fe(
        self,
        corrected_weights_vector: np.ndarray,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        return _price_per_ton_fe(
            chem,
            self.total_fuel_price_per_tone_fe_bvs(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.recalculation_price(
                corrected_weights_vector,
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.total_co2_price(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.processing_cost_for_ton_fe_vp(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                vaha_podsitnych_peliet,
                prisada_podsitne_pelety,
            ),
        )

    def total_basicity(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return (chem[ChemickaLatka.CaO] + chem[ChemickaLatka.MgO]) / (
            chem[ChemickaLatka.SiO2] + chem[ChemickaLatka.Al2O3]
        )

    def mn_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return chem[ChemickaLatka.Mn] * self.total_bf_input_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )

    def fe_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return chem[ChemickaLatka.Fe]

    def mn_percentage(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.mn_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * 0.8
        )

    def p_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return chem[ChemickaLatka.P] * self.total_bf_input_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )

    def p_percentage(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return self.p_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        ) / self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)

    def zn_weight_for_limit(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return chem[ChemickaLatka.Zn] * self.total_bf_input_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )

    def total_zn(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.zn_weight_for_limit(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * 10000
        )

    def alkali_weight(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        chem = self.blast_furnance_input_chem(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )
        return (chem[ChemickaLatka.Na2O] + chem[ChemickaLatka.K2O]) * self.total_bf_input_weight(
            weights_vector, vaha_podsitnych_peliet_do_vsadzky, prisada_podsitne_pelety, vaha_podsitnych_peliet
        )

    def total_alkali_for_limit(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.alkali_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )
            / self.fe_production(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety)
            * 10
        )

    def mgo_in_slag(
        self,
        weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return calculate_mgo_in_slag(
            self.blast_furnance_input_chem(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            )[ChemickaLatka.MgO],
            self.total_bf_input_weight(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.total_slag(
                weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
            self.fe_production_with_losses(weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety),
        )

    def _smoke_volume(self, sinter_weight: float) -> float:
        return self.S_correction_coef * sinter_weight

    def weight_vector_correction_vectorized(self, weight_vector: np.ndarray) -> np.ndarray:
        return weight_vector - (
            weight_vector
            * self.pellets_input_vector
            * self.pellet_separation_coef
            * (self.under_5mm_vector / 100)
        )

    def vp_metalurg_vectorized(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        return (
            self.vypocet_paliva_vectorized(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                vaha_podsitnych_peliet,
                prisada_podsitne_pelety,
            )
            - self.total_fuel_coal
            - self.total_fuel_coke
        )

    def total_fuel_price_per_tone_fe_bvs(
        self,
        corrected_weights_vector: np.ndarray,
        vaha_podsitnych_peliet_do_vsadzky: float,
        prisada_podsitne_pelety: Prisada,
        vaha_podsitnych_peliet: float,
    ) -> float:
        vp = self.vp_metalurg_vectorized(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        penalty_s = self.penalty_S(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        penalty_p = self.penalty_P(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        return (
            (vp / 1000 * self.vp_coke_price)
            + (self.zp_price * self.planned_zp_amount)
            + (self.pu_price * self.planned_pu_amount / 1000)
            + penalty_s
            + penalty_p
        )

    def solve(self, weights_vector) -> VsadzkaOutput:
        corrected_weights_vector = self.weight_vector_correction_vectorized(weights_vector)
        prisada_podsitne_pelety = self.prisada_podsitnych_peliet_vectorized(
            self.bf_input_chem_for_pellets(corrected_weights_vector),
            corrected_weights_vector * self.pellets_input_vector,
            weights_vector * self.pellets_input_vector,
        )
        vaha_podsitnych_peliet = self.vaha_podsitnych_peliet_vectorized(weights_vector)
        vaha_podsitnych_peliet_do_vsadzky = hmotnost_podsitnych_peliet_do_vsadzky_vectorized(
            vaha_podsitnych_peliet, prisada_podsitne_pelety
        )
        cost_vector = self._cost_vector(weights_vector)
        agglomerate_weight_to_blast_furnance_input = self.agglomerate_weight_to_blast_furnance_input(
            corrected_weights_vector, vaha_podsitnych_peliet_do_vsadzky
        )

        limestone_weight_2 = self.limestone_weight_2(corrected_weights_vector)
        agglomerate_weight_without_ash = self.agglomerate_weight_without_ash(
            corrected_weights_vector, vaha_podsitnych_peliet
        )
        fuel_to_produce_agglomerate = self._fuel_to_produce_agglomerate(
            limestone_weight_2,
            agglomerate_weight_without_ash,
        )

        ash_weight_from_agglomerate_coke = self._ash_weight_from_aglomerate_coke(
            fuel_to_produce_agglomerate, agglomerate_weight_to_blast_furnance_input
        )

        original_agglomerate_weight = calculate_full_aglomerate_weight_to_blast_furnance_input(
            agglomerate_weight_to_blast_furnance_input, ash_weight_from_agglomerate_coke
        )

        total_agglomerate_weight = calculate_total_agglomerate_weight(
            original_agglomerate_weight, self.aglo_coefficient
        )

        agglomerate_dry_fe = self._agglomerate_dry_fe(
            corrected_weights_vector,
            ash_weight_from_agglomerate_coke,
            total_agglomerate_weight,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

        sinter_chem = self._agglomerate_chem(
            corrected_weights_vector,
            ash_weight_from_agglomerate_coke,
            agglomerate_dry_fe,
            original_agglomerate_weight,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )

        agglomerate_fuel = self._agglomerate_fuel(sinter_chem)
        bf_coke_weight = self._blast_furnance_coke_weight(
            corrected_weights_vector, total_agglomerate_weight, agglomerate_fuel, agglomerate_dry_fe
        )

        bf_only_weights = corrected_weights_vector * (1 - self.agglomerate_input_vector)
        bf_only_weight = bf_only_weights.sum()

        limestone_weights = corrected_weights_vector * self.limestone_vector
        limestone_chem = self.calculate_chem(limestone_weights)
        limestone_weight = limestone_weights.sum()

        pellets_plus_bf_additives_weights = corrected_weights_vector * self.blast_furnance_input_vector
        pellets_plus_bf_additives_chem = self.calculate_chem(pellets_plus_bf_additives_weights)
        pellets_plus_bf_additives_weight = pellets_plus_bf_additives_weights.sum()

        bf_coke_ash_weight = bf_coke_weight * self.ash_richness

        total_bf_input_weight = total_agglomerate_weight + bf_only_weight + bf_coke_ash_weight

        chem = self._blast_furnance_input_chem(
            sinter_chem,
            pellets_plus_bf_additives_chem,
            limestone_chem,
            total_agglomerate_weight,
            pellets_plus_bf_additives_weight,
            limestone_weight,
            bf_coke_ash_weight,
            self.cao_to_limestone(
                corrected_weights_vector,
                vaha_podsitnych_peliet_do_vsadzky,
                prisada_podsitne_pelety,
                vaha_podsitnych_peliet,
            ),
        )
        total_slag = self._total_slag(chem)

        fe_production = self.fe_production(
            corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
        )
        total_fuel = self.total_fuel(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        total_chem = chem.sum() - chem[ChemickaLatka.Fe] - chem[ChemickaLatka.C] - chem[ChemickaLatka.H2O]

        fe_production_with_losses = self.fe_production_with_losses(
            corrected_weights_vector, vaha_podsitnych_peliet, prisada_podsitne_pelety
        )

        agglomerate_processing_cost_value = self._agglomerate_processing_cost(total_agglomerate_weight)
        agglomerate_co2_cost_value = self._agglomerate_co2_cost(
            total_agglomerate_weight, fuel_to_produce_agglomerate, agglomerate_dry_fe
        )

        chem_weights = chem * total_bf_input_weight
        chem_percentage = chem_weights / fe_production

        # mn_weight = chem_weights[ChemickaLatka.Mn]
        mn_percentage = chem_percentage[ChemickaLatka.Mn] * 0.8

        # p_weight = chem_weights[ChemickaLatka.P]
        p_percentage = chem_percentage[ChemickaLatka.P]

        # zn_weight = chem_weights[ChemickaLatka.Zn]
        zn_percentage = chem_percentage[ChemickaLatka.Zn] * 10000

        # alkali_weight = chem_weights[ChemickaLatka.Na2O] + chem_weights[ChemickaLatka.K2O]
        alkali_percentage = (chem_percentage[ChemickaLatka.Na2O] + chem_percentage[ChemickaLatka.K2O]) * 10

        kc_ar_ratio = self.kc_ar_ratio(corrected_weights_vector, vaha_podsitnych_peliet)

        mgo = chem[ChemickaLatka.MgO]
        basicity = (chem[ChemickaLatka.CaO] + mgo) / (chem[ChemickaLatka.SiO2] + chem[ChemickaLatka.Al2O3])

        mgo_in_slag = calculate_mgo_in_slag(mgo, total_bf_input_weight, total_slag, fe_production_with_losses)

        fe = 100 / chem[ChemickaLatka.Fe]
        total_component_cost_per_ton_fe = fe * ((cost_vector.sum()) / total_bf_input_weight)
        # total_fuel_cost_per_ton_fe_bf = fe * (total_fuel * self.bf_fuel_price_constant)
        total_fuel_cost_per_ton_fe_bf = total_fuel / 1000 * self.vp_coke_price
        total_fuel_cost_per_ton_fe_agglomerate = (
            fe
            * (total_agglomerate_weight * fuel_to_produce_agglomerate * self.aglo_fuel_price_constant)
            / total_bf_input_weight
        )
        total_co2_cost_per_ton_fe_components = (
            self.co2_component_price_constant * chem[ChemickaLatka.Fe] * chem[ChemickaLatka.C]
        )
        total_co2_cost_per_ton_fe_agglomerate = fe * (agglomerate_co2_cost_value / total_bf_input_weight)
        total_processing_cost_per_ton_fe_bf = total_chem * self.processing_cost_constant
        total_processing_cost_per_ton_fe_agglomerate = fe * (
            agglomerate_processing_cost_value / total_bf_input_weight
        )
        penalty_p = self._penalty_P(chem)
        penalty_s = self._penalty_S(chem)

        sinter_basicity = (sinter_chem[ChemickaLatka.CaO] + sinter_chem[ChemickaLatka.MgO]) / (
            sinter_chem[ChemickaLatka.SiO2] + sinter_chem[ChemickaLatka.Al2O3]
        )
        smoke_volume = self._smoke_volume(total_agglomerate_weight)
        total_so2_value = total_so2(
            total_sinter_s(sinter_chem[ChemickaLatka.S], original_agglomerate_weight),
            self.sinter_s_after_annealing(corrected_weights_vector, ash_weight_from_agglomerate_coke),
            smoke_volume,
        )
        total_fuel_cost_per_ton_fe_bvs = self.total_fuel_price_per_tone_fe_bvs(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        total_agglomearte_cost = self.agglomerate_total_price(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        total_cost_for_ton_fe = self.price_per_ton_fe(
            corrected_weights_vector,
            weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        co2_vp_price = self.co2_vp_price(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            prisada_podsitne_pelety,
            vaha_podsitnych_peliet,
        )
        fuel_calculation = self.vypocet_paliva_vectorized(
            corrected_weights_vector,
            vaha_podsitnych_peliet_do_vsadzky,
            vaha_podsitnych_peliet,
            prisada_podsitne_pelety,
        )

        return VsadzkaOutput(
            celkova_cena_za_tonu_zeleza=total_cost_for_ton_fe,
            vypocet_paliva=fuel_calculation,
            vytazok_fe=fe_production_with_losses,
            vyskyt_trosky=total_slag,
            bazicita=basicity,
            BVS=chem[ChemickaLatka.Fe] * self.fe_richness_constant,
            hmotnost_vsadzky=total_bf_input_weight,
            zn=zn_percentage,
            alkalie=alkali_percentage,
            p=p_percentage,
            mn=mn_percentage,
            pomer_kc_ar=kc_ar_ratio,
            celkove_so2=total_so2_value,
            mgo_v_troske=mgo_in_slag,
            hmotnost_aglomeratu=total_agglomerate_weight,
            cena_surovin=total_component_cost_per_ton_fe,
            cena_paliva_vp=total_fuel_cost_per_ton_fe_bf,
            cena_paliva_suroviny=0.0,
            cena_paliva_aglomeracia=total_fuel_cost_per_ton_fe_agglomerate,
            cena_co2_vp=co2_vp_price,
            cena_co2_suroviny=total_co2_cost_per_ton_fe_components,
            cena_co2_aglomeracia=total_co2_cost_per_ton_fe_agglomerate,
            spracovacie_naklady_vp=total_processing_cost_per_ton_fe_bf,
            spracovacie_naklady_aglomeracia=total_processing_cost_per_ton_fe_agglomerate,
            penalta_P=penalty_p,
            penalta_S=penalty_s,
            bazicita_aglomeratu=sinter_basicity,
            q_spalin=smoke_volume,
            cena_paliva_na_tonu_fe_z_bvs=total_fuel_cost_per_ton_fe_bvs,
            cena_tony_aglomeratu=total_agglomearte_cost / total_agglomerate_weight,
        )
