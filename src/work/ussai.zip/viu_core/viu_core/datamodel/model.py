# pylint: disable=too-few-public-methods,invalid-name
import itertools
import json
from enum import Enum, IntEnum, unique
from typing import Any, Callable, Collection, FrozenSet, Iterable, List, Tuple, Type, TypeVar

import attr
import cattr
from attr.validators import instance_of

MN_RECYCLABLE_LOWER = 0
MN_RECYCLABLE_UPPER = 1


@unique
class TypPrisady(Enum):
    AGLORUDA = 1
    KONCENTRAT = 2
    PRISADA_DO_AGLOMERATU = 3
    PELETY = 4
    PRISADY_DO_VP = 5
    VAPENEC = 6


@unique
class ZlozkaAglomeratu(Enum):
    AGLORUDA = 1
    KONCENTRAT = 2
    PRISADA_DO_AGLOMERATU = 3
    POPOL_Z_AGLOMERACNEHO_KOKSU = 4


@unique
class ZlozkaVsadzky(Enum):
    AGLOMERAT = 1
    PELETY = 2
    PRISADY_DO_VP = 3
    VAPENEC = 4
    POPOL_Z_PALIVA = 5


@unique
class TypPaliva(Enum):
    VP_METALURG = 1
    KOKS_ORECH = 2
    UHLIE = 3


@unique
class AglomeracnyTyp(Enum):
    ZIADEN = 1
    KONCENTRAT = 2
    AGLORUDA = 3


@unique
class BazickyTyp(Enum):
    ZIADEN = 1
    AGLO_VAPENEC = 2
    AGLO_DOLOMIT = 3
    AGLO_VAPNO = 4
    VP_VAPENEC = 5


@unique
class ChemickaLatka(IntEnum):
    Fe = 0
    H2O = 1
    FeO = 2
    Fe2O3 = 3
    SiO2 = 4
    CaO = 5
    MgO = 6
    Al2O3 = 7
    Mn = 8
    P = 9
    S = 10
    Na2O = 11
    K2O = 12
    TiO2 = 13
    Pb = 14
    Zn = 15
    As = 16
    C = 17
    Cl = 18
    Fe_MET = 19


# Indexes in tuple are from ChemickaLatka enum
ChemickeZlozenie = Tuple[float, ...]

CHEMICKE_ZLOZENIE_DEFAULT: ChemickeZlozenie = (0.0,) * 20


def annealing_s_ratio_default_by_component_type(component_type: TypPrisady) -> float:
    if component_type == TypPrisady.KONCENTRAT:
        return 0.2
    if component_type == TypPrisady.PRISADA_DO_AGLOMERATU:
        return 1.0
    return 0.0


@attr.s(slots=True, frozen=True, cache_hash=True)
class Prisada:
    nazov: str = attr.ib(converter=str)
    cena_za_tonu: float = attr.ib(converter=float)
    chemicke_zlozenie: ChemickeZlozenie = attr.ib(validator=instance_of(tuple))
    typ_prisady: TypPrisady = attr.ib(validator=instance_of(TypPrisady))
    bazicky_typ: BazickyTyp = attr.ib(validator=instance_of(BazickyTyp))
    aglomeracny_typ: AglomeracnyTyp = attr.ib(validator=instance_of(AglomeracnyTyp))
    pomer_prechodu_s: float = attr.ib(converter=float)
    rozsev_pod_5mm: float = attr.ib(converter=float, default=0)

    @pomer_prechodu_s.default
    def _default_pomer_prechodu_s(self):  # pylint: disable=too-many-return-statements,too-many-branches
        if self.nazov == "AR-KB57":
            return 0.5
        if self.nazov == "AR-KB61":
            return 0.43
        if self.nazov == "AR-SB60":
            return 0.5
        if self.nazov == "AR-SB57":
            return 0.5
        if self.nazov == "AR-ZAP":
            return 0.5
        if self.nazov == "AR-ZAP61":
            return 0.5
        if self.nazov == "KC-CEG68":
            return 0.1
        if self.nazov == "KRA-VAP":
            return 0.1
        if self.nazov == "KC-LEB":
            return 0.19
        if self.nazov == "KC-STOJ":
            return 0.35
        if self.nazov == "KC-BULG":
            return 0.9
        if self.nazov == "MIK-VAP":
            return 0.8
        if self.nazov in {"MN-Bosna", "Oter z peliet"}:
            return 1.2
        if self.nazov == "VYHOZ VP1":
            return 1 / 3
        return annealing_s_ratio_default_by_component_type(self.typ_prisady)

    def is_recyclable(self):
        return MN_RECYCLABLE_LOWER < self.chemicke_zlozenie[ChemickaLatka.Mn] < MN_RECYCLABLE_UPPER
        # recyklaty su prisady do aglomeratu ktorych hodnota mn je v intervale (0,1)


def identity(x):
    return x


def default_if_null_converter(default_value, original_converter):
    return {
        "default": default_value,
        "converter": lambda x: default_value if x is None else original_converter(x),
    }


@attr.s(slots=True, frozen=True, cache_hash=True)
class Popol:
    percento_popola: float = attr.ib(**default_if_null_converter(0.0, float))
    chemicke_zlozenie: ChemickeZlozenie = attr.ib(
        **default_if_null_converter(CHEMICKE_ZLOZENIE_DEFAULT, tuple)
    )


# FrozenDict would be better class to use instead of FrozenSet but unfortunately it is not yet
# first class citizen in python in time of writing this comment
@attr.s(slots=True, frozen=True, cache_hash=True)
class VsadzkaInput:
    cena_vp_koksu: float = attr.ib(**default_if_null_converter(200.0, float))
    cena_tony_co2: float = attr.ib(**default_if_null_converter(40.0, float))
    bvs_minuly_mesiac: float = attr.ib(**default_if_null_converter(59.0, float))
    spracovacie_naklady_na_tonu_suroveho_zeleza: float = attr.ib(**default_if_null_converter(35.0, float))
    spracovacie_naklady_na_tonu_aglomeratu: float = attr.ib(**default_if_null_converter(24.0, float))
    priemerne_percento_P: float = attr.ib(**default_if_null_converter(0.045, float))
    priemerne_percento_S: float = attr.ib(**default_if_null_converter(0.04, float))
    percento_Si: float = attr.ib(**default_if_null_converter(0.63, float))
    hbt: float = attr.ib(**default_if_null_converter(1100.0, float))
    eta_co: float = attr.ib(**default_if_null_converter(50.0, float))
    msp: float = attr.ib(**default_if_null_converter(500.0, float))
    suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu: float = attr.ib(
        **default_if_null_converter(262.0, float)
    )
    realne_palivo_pri_p2_z_minuleho_mesiaca: float = attr.ib(**default_if_null_converter(66.0, float))
    cena_aglom_paliva: float = attr.ib(**default_if_null_converter(85.0, float))
    bohatost_suroveho_zeleza: float = attr.ib(**default_if_null_converter(94.0, float))
    co2_z_uhlia: float = attr.ib(**default_if_null_converter(2.84, float))
    co2_z_koks_orech: float = attr.ib(**default_if_null_converter(2.848, float))
    co2_z_vp_metalurg: float = attr.ib(**default_if_null_converter(3.063, float))
    co2_z_koks_prach: float = attr.ib(**default_if_null_converter(2.591, float))
    celkove_palivo_uhlie: float = attr.ib(**default_if_null_converter(126.0, float))
    celkove_palivo_koks_orech: float = attr.ib(**default_if_null_converter(30.0, float))
    percento_fe_kal: float = attr.ib(**default_if_null_converter(58.3, float))
    percento_fe_vyhoz: float = attr.ib(**default_if_null_converter(43.3, float))
    koeficient_vyroby_aglomeratu: float = attr.ib(**default_if_null_converter(1.03, float))
    C_v_sur_fe_minuly_mesiac: float = attr.ib(**default_if_null_converter(4.357, float))
    Si_v_sur_fe_minuly_mesiac: float = attr.ib(**default_if_null_converter(0.721, float))
    Mn_v_sur_fe_minuly_mesiac: float = attr.ib(**default_if_null_converter(0.350, float))
    korekcny_koeficient_pre_S_do_aglomeratu: float = attr.ib(**default_if_null_converter(5200.0, float))
    energia_na_odparenie_h2o: float = attr.ib(**default_if_null_converter(2.257, float))  # MJ/kg
    kaloriticka_hodnota_koks: float = attr.ib(**default_if_null_converter(28.72, float))  # MJ/kg

    popol_koks_prach: Popol = attr.ib(**default_if_null_converter(Popol(), identity))
    popol_kb1: Popol = attr.ib(**default_if_null_converter(Popol(), identity))
    popol_kb3: Popol = attr.ib(**default_if_null_converter(Popol(), identity))
    popol_pu: Popol = attr.ib(**default_if_null_converter(Popol(), identity))
    aglorudy: FrozenSet[Prisada] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    koncentraty: FrozenSet[Prisada] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    pelety: FrozenSet[Prisada] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    prisady_do_vp: FrozenSet[Prisada] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    prisady_do_aglomeratu: FrozenSet[Prisada] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    vapenec: Prisada = attr.ib(
        **default_if_null_converter(
            Prisada(
                nazov="VP-VAP",
                cena_za_tonu=0.0,
                chemicke_zlozenie=CHEMICKE_ZLOZENIE_DEFAULT,
                typ_prisady=TypPrisady.VAPENEC,
                bazicky_typ=BazickyTyp.VP_VAPENEC,
                aglomeracny_typ=AglomeracnyTyp.ZIADEN,
            ),
            identity,
        )
    )
    koef_odtriedenia_peliet: float = attr.ib(converter=float, default=0.0)
    koef_ucinnosti_zariadenia_vp: float = attr.ib(converter=float, default=100 / 65)
    posditny_podiel_pod_5mm_aglomerat: float = attr.ib(**default_if_null_converter(0, float))
    koef_na_bvs: float = attr.ib(converter=float, default=0)
    planovane_mnozstvo_zp: float = attr.ib(**default_if_null_converter(0, float))
    cena_zp: float = attr.ib(**default_if_null_converter(0, float))
    cena_pu: float = attr.ib(**default_if_null_converter(0, float))
    planovane_mnozstvo_pu: float = attr.ib(**default_if_null_converter(0, float))
    hmotnost_mspu: float = attr.ib(**default_if_null_converter(0, float))

    @property
    def vsetky_prisady(self) -> Iterable[Prisada]:
        return itertools.chain.from_iterable(
            [
                self.prisady_do_vp,
                self.pelety,
                [self.vapenec],
                self.prisady_do_aglomeratu,
                self.koncentraty,
                self.aglorudy,
            ]
        )

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self))

    @classmethod
    def deserialize(cls, serialized: str) -> "VsadzkaInput":
        return converter.structure(json.loads(serialized), VsadzkaInput)

    def get_components_by_type(self, component_type: TypPrisady) -> Iterable[Prisada]:
        if component_type == TypPrisady.AGLORUDA:
            return self.aglorudy
        if component_type == TypPrisady.KONCENTRAT:
            return self.koncentraty
        if component_type == TypPrisady.PELETY:
            return self.pelety
        if component_type == TypPrisady.PRISADY_DO_VP:
            return self.prisady_do_vp
        if component_type == TypPrisady.PRISADA_DO_AGLOMERATU:
            return self.prisady_do_aglomeratu
        if component_type == TypPrisady.VAPENEC:
            return [self.vapenec]
        raise Exception(f"Unknown component type {component_type}")

    def with_components(
        self, new_components: FrozenSet[Prisada], component_type: TypPrisady
    ) -> "VsadzkaInput":
        if component_type == TypPrisady.AGLORUDA:
            return attr.evolve(self, aglorudy=new_components)
        if component_type == TypPrisady.KONCENTRAT:
            return attr.evolve(self, koncentraty=new_components)
        if component_type == TypPrisady.PELETY:
            return attr.evolve(self, pelety=new_components)
        if component_type == TypPrisady.PRISADY_DO_VP:
            return attr.evolve(self, prisady_do_vp=new_components)
        if component_type == TypPrisady.PRISADA_DO_AGLOMERATU:
            return attr.evolve(self, prisady_do_aglomeratu=new_components)
        if component_type == TypPrisady.VAPENEC:
            return attr.evolve(self, vapenec=list(new_components)[0])
        raise Exception(f"Unknown component type {component_type}")


@attr.s(slots=True, frozen=True, cache_hash=True)
class Limit:
    nazov: str = attr.ib(**default_if_null_converter("", str))
    min: float = attr.ib(**default_if_null_converter(0.0, float))
    max: float = attr.ib(**default_if_null_converter(0.0, float))


# FrozenDict would be better class to use instead of FrozenSet but unfortunately it is not yet
# first class citizen in python in time of writing this comment
@attr.s(slots=True, frozen=True, cache_hash=True)
class OptimizationLimits:
    aglomerat: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    vytazok_fe: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    bazicita: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    zn: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    alkalie: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    p: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    mn: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    pomer_kc_ar: Limit = attr.ib(**default_if_null_converter(Limit(), identity))
    mgo_do_trosky: Limit = attr.ib(**default_if_null_converter(Limit(), identity))

    aglorudy: FrozenSet[Limit] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    koncentraty: FrozenSet[Limit] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    pelety: FrozenSet[Limit] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    prisady_do_vp: FrozenSet[Limit] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    prisady_do_aglomeratu: FrozenSet[Limit] = attr.ib(**default_if_null_converter(frozenset(), frozenset))
    vapenec: Limit = attr.ib(**default_if_null_converter(Limit(nazov="VP-VAP"), identity))

    @property
    def all_limits(self) -> List[Limit]:
        return list(
            itertools.chain.from_iterable(
                [
                    self.prisady_do_vp,
                    self.pelety,
                    [self.vapenec],
                    self.prisady_do_aglomeratu,
                    self.koncentraty,
                    self.aglorudy,
                ]
            )
        )

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self))

    @classmethod
    def deserialize(cls, serialized: str) -> "OptimizationLimits":
        return converter.structure(json.loads(serialized), OptimizationLimits)

    def get_components_by_type(self, component_type: TypPrisady) -> Iterable[Limit]:
        if component_type == TypPrisady.AGLORUDA:
            return self.aglorudy
        if component_type == TypPrisady.KONCENTRAT:
            return self.koncentraty
        if component_type == TypPrisady.PELETY:
            return self.pelety
        if component_type == TypPrisady.PRISADY_DO_VP:
            return self.prisady_do_vp
        if component_type == TypPrisady.PRISADA_DO_AGLOMERATU:
            return self.prisady_do_aglomeratu
        if component_type == TypPrisady.VAPENEC:
            return [self.vapenec]
        raise Exception(f"Unknown component type {component_type}")

    def with_components(
        self, new_components: FrozenSet[Limit], component_type: TypPrisady
    ) -> "OptimizationLimits":
        if component_type == TypPrisady.AGLORUDA:
            return attr.evolve(self, aglorudy=new_components)
        if component_type == TypPrisady.KONCENTRAT:
            return attr.evolve(self, koncentraty=new_components)
        if component_type == TypPrisady.PELETY:
            return attr.evolve(self, pelety=new_components)
        if component_type == TypPrisady.PRISADY_DO_VP:
            return attr.evolve(self, prisady_do_vp=new_components)
        if component_type == TypPrisady.PRISADA_DO_AGLOMERATU:
            return attr.evolve(self, prisady_do_aglomeratu=new_components)
        if component_type == TypPrisady.VAPENEC:
            return attr.evolve(self, vapenec=list(new_components)[0])
        raise Exception(f"Unknown component type {component_type}")


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class VsadzkaOutput:
    # Najdolezitejsie
    celkova_cena_za_tonu_zeleza: float
    # Vystupne parametre fe
    vypocet_paliva: float
    vytazok_fe: float
    vyskyt_trosky: float
    bazicita: float
    BVS: float
    hmotnost_vsadzky: float
    zn: float
    alkalie: float
    p: float
    mn: float
    pomer_kc_ar: float
    celkove_so2: float
    mgo_v_troske: float
    hmotnost_aglomeratu: float
    # Rozklad ceny
    cena_surovin: float
    cena_paliva_vp: float
    cena_paliva_suroviny: float
    cena_paliva_aglomeracia: float
    cena_co2_vp: float
    cena_co2_suroviny: float
    cena_co2_aglomeracia: float
    spracovacie_naklady_vp: float
    spracovacie_naklady_aglomeracia: float
    penalta_P: float
    penalta_S: float
    cena_paliva_na_tonu_fe_z_bvs: float
    cena_tony_aglomeratu: float
    # Pridane neskor
    bazicita_aglomeratu: float = float("nan")
    q_spalin: float = float("nan")


# TODO Extract to commonn library
def convert_enum_to_choices(enum_class: Iterable) -> List[Tuple[int, str]]:
    return [(value.value, value.name) for value in enum_class]


class BreakEvenPriceMode(IntEnum):
    FIX_WEIGHT = 0
    FIX_PRICE = 1


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class RangeSettings:
    minimum: int
    maximum: int
    precise: int

    def get_range(self) -> range:
        minimum = self.minimum if self.minimum != 0 else self.precise
        return range(minimum, self.maximum + 1, self.precise)


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class BreakEvenPriceOptimalizationInput:
    input_data: VsadzkaInput
    limits: OptimizationLimits
    fix_range: RangeSettings
    search_range: RangeSettings
    ref_price: float
    focused_on_ingredient: str
    percentage_deviation: float

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "BreakEvenPriceOptimalizationInput":
        return converter.structure(json.loads(serialized), BreakEvenPriceOptimalizationInput)


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class BreakEvenPriceOptimalizationOutput:
    search_limit: int = attr.ib(default=0)
    fix_limit: int = attr.ib(default=0)
    final_price: float = attr.ib(default=0.0)
    is_limits_ok: bool = attr.ib(default=False, converter=bool)
    is_final_price_in_range: bool = attr.ib(default=False, converter=bool)
    error: str = attr.ib(default="")

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "BreakEvenPriceOptimalizationOutput":
        return converter.structure(json.loads(serialized), BreakEvenPriceOptimalizationOutput)


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class MaxResults:
    prices: Tuple[float, ...] = ()
    weights: Tuple[float, ...] = ()
    final_prices: Tuple[float, ...] = ()


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class BreakEvenPriceOptimalizationOutputs:
    calculation_mode: BreakEvenPriceMode
    ref_price: float = 0.0
    model_outputs: Tuple[Tuple[BreakEvenPriceOptimalizationOutput, ...], ...] = ()

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "BreakEvenPriceOptimalizationOutputs":
        return converter.structure(json.loads(serialized), BreakEvenPriceOptimalizationOutputs)

    def get_max_result_from_model_outputs(self) -> MaxResults:
        prices, weights, final_prices = ([], [], [])
        for outputs in self.model_outputs:
            for result in reversed(outputs):
                if result.is_final_price_in_range and result.is_limits_ok:
                    prices.append(
                        result.fix_limit
                        if self.calculation_mode == BreakEvenPriceMode.FIX_PRICE
                        else result.search_limit
                    )
                    weights.append(
                        result.search_limit
                        if self.calculation_mode == BreakEvenPriceMode.FIX_PRICE
                        else result.fix_limit
                    )
                    final_prices.append(round(result.final_price, 2))
                    break
        return MaxResults(tuple(prices), tuple(weights), tuple(final_prices))


converter = cattr.Converter(unstruct_collection_overrides={FrozenSet: list})
