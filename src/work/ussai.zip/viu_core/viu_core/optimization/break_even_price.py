# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
from typing import Tuple, Optional, Callable, List
import attr
from ..datamodel.model import (
    VsadzkaInput,
    VsadzkaOutput,
    BreakEvenPriceOptimalizationInput,
    BreakEvenPriceOptimalizationOutput,
    BreakEvenPriceOptimalizationOutputs,
    BreakEvenPriceMode,
)
from viu_core import (
    optimize_slsqp,
    Limit,
    OptimizationLimits,
    Vectorized_VIU,
    vectorize_weights,
)

SINGEL_LIMIT = [
    "aglomerat",
    "vytazok_fe",
    "bazicita",
    "zn",
    "alkalie",
    "p",
    "mn",
    "pomer_kc_ar",
    "mgo_do_trosky",
    "vapenec",
]

MULTIPLE_LIMITS = [
    "aglorudy",
    "koncentraty",
    "pelety",
    "prisady_do_vp",
    "prisady_do_aglomeratu",
]


### checking instance for limit is necessary due to testing function.
### In unittest is each limit type of dictionary.
def get_ingredient_type(limits: OptimizationLimits, for_ingredient: str) -> Optional[str]:
    for key, value in attr.asdict(limits).items():
        if key in MULTIPLE_LIMITS:
            for limit in list(value):
                if isinstance(limit, Limit):
                    if limit.nazov == for_ingredient:
                        return key
                if isinstance(limit, dict):
                    if limit["nazov"] == for_ingredient:
                        return key
    return None


def update_limit_fields(
    limits: OptimizationLimits, ingredient: str, min_limit: float, max_limit: float
) -> OptimizationLimits:
    ingredient_type = get_ingredient_type(limits, ingredient)
    if ingredient_type is None:
        return limits
    return attr.evolve(
        limits,
        **{
            ingredient_type: frozenset(
                [
                    (
                        limit
                        if limit.nazov != ingredient
                        else attr.evolve(
                            limit,
                            max=max_limit if max_limit > limit.min else limit.min,
                            min=min_limit if min_limit < limit.max else limit.max,
                        )
                    )
                    for limit in list(getattr(limits, ingredient_type))
                ]
            )
        },
    )


def update_price_per_tonnes_field(
    limits: OptimizationLimits, data: VsadzkaInput, ingredient: str, price_per_tonnes: float
) -> VsadzkaInput:
    ingredient_type = get_ingredient_type(limits, ingredient)
    if ingredient_type is None:
        return data
    return attr.evolve(
        data,
        **{
            ingredient_type: frozenset(
                [
                    (
                        input_
                        if input_.nazov != ingredient
                        else attr.evolve(input_, cena_za_tonu=price_per_tonnes)
                    )
                    for input_ in list(getattr(data, ingredient_type))
                ]
            )
        },
    )


def update_price_and_limits(
    model_input: BreakEvenPriceOptimalizationInput,
    calculation_mode: BreakEvenPriceMode,
    middle_value: int,
    fix_value: int,
) -> Tuple[VsadzkaInput, OptimizationLimits]:
    if calculation_mode == BreakEvenPriceMode.FIX_PRICE:
        new_limits = update_limit_fields(
            model_input.limits, model_input.focused_on_ingredient, middle_value, middle_value
        )
        new_input_data = update_price_per_tonnes_field(
            model_input.limits,
            model_input.input_data,
            model_input.focused_on_ingredient,
            fix_value,
        )
    else:
        new_limits = update_limit_fields(
            model_input.limits,
            model_input.focused_on_ingredient,
            fix_value,
            fix_value,
        )
        new_input_data = update_price_per_tonnes_field(
            model_input.limits, model_input.input_data, model_input.focused_on_ingredient, middle_value
        )
    return new_input_data, new_limits


def get_limit_for(limits: OptimizationLimits, ingredient_name: str) -> Optional[Limit]:
    if ingredient_name in SINGEL_LIMIT:
        return getattr(limits, ingredient_name)
    for limit in limits.all_limits:
        if limit.nazov == ingredient_name:
            return limit
    return None


def get_price_with_deviation(price: float, percentage_deviation: float) -> float:
    return price * (1 + (percentage_deviation / 100))


def check_limit(limit: Limit, value: float, digits: int) -> bool:
    rounded_value = round(value, digits)
    return limit.min <= rounded_value <= limit.max


def check_limits(
    limits: OptimizationLimits, optimize_result: dict, data_output: VsadzkaOutput
) -> Tuple[bool, str]:
    is_output_ok, output_error = check_vsadzka_output_limits(limits, data_output)
    is_limits_ok, limits_error = check_ingredient_limits(limits, optimize_result)
    return (is_output_ok and is_limits_ok, f"{output_error}, {limits_error}")


def check_vsadzka_output_limits(limits: OptimizationLimits, data_output: VsadzkaOutput) -> Tuple[bool, str]:
    is_ok = []
    error_msg = []
    for key, value in attr.asdict(data_output).items():
        try:
            limit = getattr(limits, key)
            round_digits = 2 if key != "vytazok_fe" else 0
            result = check_limit(limit, value, round_digits)
            is_ok.append(result)
            if not is_ok[-1]:
                error_msg.append(
                    f"Limit for {key} is {getattr(limits, key).min} - {getattr(limits, key).max}"
                    + f" and value was {round(value, round_digits)}"
                )
        except AttributeError:
            #  error_msg.append(f"Vsadzka output error {e}")
            pass
    return (all(is_ok) if len(is_ok) != 0 else False, ", ".join(error_msg))


def check_ingredient_limits(limits: OptimizationLimits, optimize_result: dict) -> Tuple[bool, str]:
    limits_is_ok = []
    error_msg = []
    for key, value in optimize_result.items():
        limit = get_limit_for(limits, key)
        if limit is None:
            error_msg.append(f"Limits for {key} was not found.")
            continue
        check_ = check_limit(limit, value, 2)
        limits_is_ok.append(check_)
        if not check_:
            error_msg.append(f"Limit for {key} is {limit.min} - {limit.max} and value was {round(value, 2)}")
    return (all(limits_is_ok) if len(limits_is_ok) != 0 else False, ", ".join(error_msg))


def slsqp_optimize(
    input_data: VsadzkaInput,
    limits: OptimizationLimits,
    optim_settings: dict,
    progress_callback: Callable[[float], None],
) -> Tuple[Tuple[dict, float], VsadzkaOutput]:
    opti_result = optimize_slsqp(input_data, limits, optim_settings, progress_callback)

    model = Vectorized_VIU(input_data)
    vsadzka_output = model.solve(vectorize_weights(opti_result[0][0], model.mapping))

    return (opti_result[0], vsadzka_output)


def is_price_in_range(price: float, ref_price: float, percentage_deviation: float) -> bool:
    return ref_price <= price <= get_price_with_deviation(ref_price, percentage_deviation)


def get_highest_value_from_output_list(
    outputs: List[BreakEvenPriceOptimalizationOutput],
) -> BreakEvenPriceOptimalizationOutput:
    for model_output in reversed(outputs):
        if model_output.is_limits_ok and model_output.is_final_price_in_range:
            return model_output
    return outputs[-1]


def calculate_break_even_price(  # pylint: disable=too-many-locals
    model_input: BreakEvenPriceOptimalizationInput,
    calculation_mode: BreakEvenPriceMode,
    progress_callback: Callable[[float], None],
) -> BreakEvenPriceOptimalizationOutputs:
    model_outputs = []
    itter_counter = 0

    def progress_callback_do_nothing(_: float) -> None:
        pass

    for fix_value in model_input.fix_range.get_range():
        if itter_counter == 0:
            progress_callback(1.0)
        else:
            percentage_done = itter_counter * (
                100 / ((model_input.fix_range.maximum - 1) / model_input.fix_range.precise)
            )
            progress_callback(percentage_done)
        model_outputs.append(
            search_highest_value(fix_value, model_input, calculation_mode, progress_callback_do_nothing)
        )
        itter_counter += 1

    return BreakEvenPriceOptimalizationOutputs(
        model_outputs=tuple(model_outputs), calculation_mode=calculation_mode, ref_price=model_input.ref_price
    )


def search_highest_value(  # pylint: disable=too-many-locals
    fix_value: int,
    model_input: BreakEvenPriceOptimalizationInput,
    calculation_mode: BreakEvenPriceMode,
    progress_callback: Callable[[float], None],
) -> Tuple[BreakEvenPriceOptimalizationOutput, ...]:
    model_outputs = []
    was_optimalized = []

    search_range = list(model_input.search_range.get_range())
    low, high = 0, len(search_range) - 1
    while low <= high:
        middle = (high + low) // 2
        if middle in was_optimalized or middle < 0 or middle > len(search_range):
            break

        new_input_data, new_limits = update_price_and_limits(
            model_input, calculation_mode, search_range[middle], fix_value
        )

        opti_result, vsadzka_output = slsqp_optimize(
            input_data=new_input_data,
            limits=new_limits,
            optim_settings={"maxiter": 1500, "ftol": 1e-10},
            progress_callback=progress_callback,
        )
        opti_result_weights, opti_result_final_price = opti_result

        is_limits_ok, err_msg = check_limits(new_limits, opti_result_weights, vsadzka_output)
        is_final_price_in_range = is_price_in_range(
            opti_result_final_price, model_input.ref_price, model_input.percentage_deviation
        )

        model_outputs.append(
            BreakEvenPriceOptimalizationOutput(
                search_range[middle],
                fix_value,
                opti_result_final_price,
                is_limits_ok,
                is_final_price_in_range,
                err_msg,
            )
        )
        was_optimalized.append(middle)
        if opti_result_final_price < get_price_with_deviation(
            model_input.ref_price, model_input.percentage_deviation
        ):
            low = middle + 1
        else:
            high = middle - 1

    return tuple(model_outputs)
