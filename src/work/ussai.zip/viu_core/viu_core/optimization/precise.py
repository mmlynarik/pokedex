# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
import random
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.cluster import AgglomerativeClustering
from sklearn.decomposition import PCA

from scipy import optimize
from scipy.optimize import OptimizeResult

from ..datamodel.model import OptimizationLimits, VsadzkaInput
from . import (
    CachedModel,
    generate_price_function,
    get_bounds,
    get_constant_components,
    get_constraints,
    get_model_with_constant_components,
    get_model_without_constant_zero_components,
    add_zero_components_to_result_dict,
    get_weight_vector,
)


# TODO refactor - class not needed - use dataclass or namedtuple
class MappedResult:  # pylint: disable=too-few-public-methods
    def __init__(self, result: OptimizeResult, mapping: Mapping[str, int], constants: Mapping[str, float]):
        self.fun: float = result.fun
        self.data: Dict[str, float] = {**constants}
        for name in mapping:
            if name not in self.data:
                self.data[name] = result.x[mapping[name]]


class HallOfFame:
    def __init__(self, max_distance_from_best_to_keep: float = 1.0):
        self.results: List[MappedResult] = []
        self.best: Optional[MappedResult] = None
        self.max_distance: float = max_distance_from_best_to_keep

    def add_result(self, result: MappedResult) -> None:
        if self.best is None:
            self.best = result
            self.results.append(result)
            return
        if result.fun < (self.best.fun + self.max_distance):
            self.results.append(result)
        if self.best.fun > result.fun:
            self.best = result
            self.results = [r for r in self.results if r.fun < (self.best.fun + self.max_distance)]

    def get_sorted_results(self) -> pd.DataFrame:
        data = pd.DataFrame([res.data for res in self.results])
        data["price"] = [res.fun for res in self.results]
        return data.sort_values("price")


def get_random_iters(options: Dict[str, Any]) -> int:
    default_random_iters = 20
    random_iters = options.get("random_iters", default_random_iters)
    return default_random_iters if random_iters < 1 else random_iters


def pca_denoising(data: np.ndarray) -> np.ndarray:
    pca = PCA()
    denoised = pca.fit_transform(data)
    number_of_components = (pca.explained_variance_ratio_ >= 0.01).sum()
    return denoised[:, :number_of_components]


def get_cluster_count(data: np.ndarray) -> int:
    sils = []
    min_cluster_count = 2
    for cluster_count in range(min_cluster_count, min(32, len(data) - 1)):
        gmm = AgglomerativeClustering(n_clusters=cluster_count, affinity="euclidean", linkage="ward")
        labels = gmm.fit_predict(data)
        sil = metrics.silhouette_score(data, labels, metric="euclidean")
        sils.append(sil)
    if not sils:
        return 1
    return np.array(sils).argmax() + min_cluster_count


def get_clustering(data: np.ndarray) -> np.ndarray:
    cluster_count = get_cluster_count(data)
    if cluster_count == 1:
        return np.zeros(len(data), dtype=int)
    gmm = AgglomerativeClustering(n_clusters=cluster_count, affinity="euclidean", linkage="ward")
    return gmm.fit_predict(data)


def get_variants(hof: HallOfFame) -> List[pd.Series]:
    data = hof.get_sorted_results()
    without_price = data.drop("price", axis=1)
    denoised = pca_denoising(np.array(without_price))
    clustering = get_clustering(denoised)
    representants = [data[clustering == i].iloc[0] for i in range(clustering.max() + 1)]
    return representants


def get_result_dict_from_variant(variant: pd.Series) -> Dict[str, float]:
    return {name: value for name, value in variant.iteritems() if name != "price"}


def get_progress(outer: int, inner: int, max_outer: int, max_inner: int, max_total: float = 99.0) -> float:
    one_outer = max_total / max_outer
    one_inner = one_outer / max_inner
    return (one_outer * outer) + (one_inner * inner)


# TODO refactor to be more readable
def precise_optimization(  # pylint: disable=too-many-locals
    input_data: VsadzkaInput,
    limits: OptimizationLimits,
    options: Dict[str, Any],
    progress_callback: Callable[[float], None],
) -> List[Tuple[Dict[str, float], float]]:
    hof = HallOfFame()
    random_iters = get_random_iters(options)
    all_limits = limits.all_limits
    without_zeros = get_model_without_constant_zero_components(input_data, all_limits)
    constant_components, constant_values = get_constant_components(all_limits)
    max_iterations = len(without_zeros.mapping) - len(constant_components)

    while True:
        vectorized_model = get_model_with_constant_components(
            input_data, without_zeros.mapping, constant_components
        )

        remaining_iterations = len(vectorized_model.mapping) - len(constant_components)
        if remaining_iterations == 0:
            break
        cached_model = CachedModel(vectorized_model, constant_values, 10000)
        price_f = generate_price_function(cached_model)
        constraints = get_constraints(cached_model, limits)
        bounds = get_bounds(cached_model.orig, all_limits, constant_components)

        optim_options = {k: v for k, v in options.items() if k != "random_iters"}

        def optimization_method(init_value):
            return optimize.minimize(
                price_f,
                init_value,
                constraints=constraints,
                bounds=bounds,
                options=optim_options,
                method="SLSQP",
            )

        for i in range(random_iters):
            hof.add_result(
                MappedResult(
                    optimization_method(
                        get_weight_vector(cached_model.orig, all_limits, constant_components, random.uniform)
                    ),
                    cached_model.orig.mapping,
                    dict(zip(constant_components, constant_values)),
                )
            )
            progress_callback(
                get_progress(max_iterations - remaining_iterations, i + 1, max_iterations, random_iters)
            )

        results = hof.get_sorted_results()

        for name, _ in results.std().sort_values().iteritems():
            if name not in constant_components and name != "price":
                constant_components.append(name)
                constant_values = np.concatenate([constant_values, np.array([results[name].iloc[0]])])
                break

    variants = get_variants(hof)
    progress_callback(100.0)
    return [
        (
            add_zero_components_to_result_dict(all_limits, get_result_dict_from_variant(variant)),
            variant["price"],
        )
        for variant in variants
    ]
