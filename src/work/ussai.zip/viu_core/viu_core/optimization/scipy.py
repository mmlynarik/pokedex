# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
from typing import Callable, Dict, List, Tuple

from scipy import optimize

from ..datamodel.model import OptimizationLimits, VsadzkaInput
from . import (
    CachedModel,
    add_zero_components_to_result_dict,
    generate_price_function,
    get_bounds,
    get_constant_components,
    get_constraints,
    get_model_with_constant_components,
    get_model_without_constant_zero_components,
    get_weight_vector,
    get_weights_dict,
)


def generate_show_progress_callback(max_iter: int, progress_callback: Callable[[float], None]):
    count = 0

    def show_progress_callback(*args, **kwargs):  # pylint: disable=unused-argument
        nonlocal count
        count += 1
        percentage = (count / max_iter) * 100
        progress_callback(percentage)

    return show_progress_callback


def optimize_slsqp(
    input_data: VsadzkaInput,
    limits: OptimizationLimits,
    options: dict,
    progress_callback: Callable[[float], None],
) -> List[Tuple[Dict[str, float], float]]:
    all_limits = limits.all_limits
    constant_components, constant_values = get_constant_components(all_limits)

    without_zeros = get_model_without_constant_zero_components(input_data, all_limits)
    vectorized_model = get_model_with_constant_components(
        input_data, without_zeros.mapping, constant_components
    )
    cached_model = CachedModel(vectorized_model, constant_values, 10000)

    price_f = generate_price_function(cached_model)
    constraints = get_constraints(cached_model, limits)
    weight_bounds = get_bounds(vectorized_model, all_limits, constant_components)
    result = optimize.minimize(
        price_f,
        get_weight_vector(vectorized_model, all_limits, constant_components, max),
        constraints=constraints,
        bounds=weight_bounds,
        options=options,
        method="SLSQP",
        callback=generate_show_progress_callback(options["maxiter"], progress_callback),
    )

    return [
        (
            add_zero_components_to_result_dict(
                all_limits,
                get_weights_dict(
                    vectorized_model.mapping, dict(zip(constant_components, constant_values)), result
                ),
            ),
            result.fun,
        )
    ]
