# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
from typing import Callable, Dict, List, Mapping, Tuple, Union

import numpy as np
from immutables import Map

from scipy.optimize import OptimizeResult

from ..datamodel.model import Limit, OptimizationLimits, VsadzkaInput, VsadzkaOutput
from ..vectorized_python_model import Vectorized_VIU


class CachedModel:  # pylint: disable=too-few-public-methods
    def __init__(self, orig_model: Vectorized_VIU, constant_components: List[str], max_cache_len: int):
        self.orig = orig_model
        self.constant_values = constant_components
        self.cache: Dict[bytes, VsadzkaOutput] = {}
        self.max_cache_len = max_cache_len

    def solve(self, weights: np.ndarray) -> VsadzkaOutput:
        key = weights.tostring()
        if key in self.cache:
            return self.cache[key]

        result = self.orig.solve(np.concatenate([weights, self.constant_values]))
        if len(self.cache) > self.max_cache_len:
            self.cache = {}
        self.cache[key] = result
        return result


def is_usable(limit: Limit) -> bool:
    return limit.max > 0


def is_constant(limit: Limit) -> bool:
    return limit.min == limit.max


def get_model_with_mapping(input_data: VsadzkaInput, mapping: List[Tuple[str, int]]) -> Vectorized_VIU:
    dict_mapping = dict(mapping)
    # This is solvable by renaming but for now just throw exception
    if len(mapping) != len(dict_mapping):
        raise Exception("Cannot vectorize -> duplicate component names")
    return Vectorized_VIU(input_data, Map(**dict_mapping))


def get_model_without_constant_zero_components(  # pylint: disable=invalid-name
    input_data: VsadzkaInput, all_weight_limits: List[Limit]
) -> Vectorized_VIU:
    all_usable_limits = [x for x in all_weight_limits if is_usable(x)]

    return get_model_with_mapping(input_data, [(c.nazov, i) for i, c in enumerate(all_usable_limits)])


def get_model_with_constant_components(  # pylint: disable=invalid-name
    input_data: VsadzkaInput, original_mapping: Mapping[str, int], constant_components: List[str]
) -> Vectorized_VIU:
    used_constant_names = []
    used_variable_names = []

    for name in original_mapping:
        if name in constant_components:
            used_constant_names.append(name)
        else:
            used_variable_names.append(name)

    if set(used_constant_names) != set(constant_components):
        raise Exception("All constant components must be used")

    return get_model_with_mapping(
        input_data, [(name, i) for i, name in enumerate(used_variable_names + constant_components)]
    )


def generate_price_function(model: Union[Vectorized_VIU, CachedModel]) -> Callable[[np.ndarray], float]:
    def func(weights_vector: np.ndarray) -> float:
        return model.solve(weights_vector).celkova_cena_za_tonu_zeleza

    return func


def get_lower_bound_ineq_constraint(
    model: Union[Vectorized_VIU, CachedModel], lower: float, value_getter: Callable[[VsadzkaOutput], float]
):
    def constraint_f(weights_vector: np.ndarray) -> float:
        return value_getter(model.solve(weights_vector)) - lower

    return constraint_f


def get_upper_bound_ineq_constraint(
    model: Union[Vectorized_VIU, CachedModel], upper: float, value_getter: Callable[[VsadzkaOutput], float]
):
    def constraint_f(weights_vector: np.ndarray) -> float:
        return upper - value_getter(model.solve(weights_vector))

    return constraint_f


def get_lower_bound_weight_ineq_constraint(lower: float, index: int):  # pylint: disable=invalid-name
    def constraint_f(weights_vector: np.ndarray) -> float:
        return weights_vector[index] - lower

    return constraint_f


def get_upper_bound_weight_ineq_constraint(upper: float, index: int):  # pylint: disable=invalid-name
    def constraint_f(weights_vector: np.ndarray) -> float:
        return upper - weights_vector[index]

    return constraint_f


def get_fe_production(output: VsadzkaOutput) -> float:
    return output.vytazok_fe


def get_agglomerate_weight(output: VsadzkaOutput) -> float:
    return output.hmotnost_aglomeratu


def get_mn(output: VsadzkaOutput) -> float:
    return output.mn


def get_p(output: VsadzkaOutput) -> float:
    return output.p


def get_zn(output: VsadzkaOutput) -> float:
    return output.zn


def get_alkali(output: VsadzkaOutput) -> float:
    return output.alkalie


def get_kc_ar_ratio(output: VsadzkaOutput) -> float:
    return output.pomer_kc_ar


def get_basicity(output: VsadzkaOutput) -> float:
    return output.bazicita


def get_mgo_in_slag(output: VsadzkaOutput) -> float:
    return output.mgo_v_troske


def get_constraints(model: Union[Vectorized_VIU, CachedModel], limits: OptimizationLimits) -> List[dict]:
    all_constraints = []

    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_lower_bound_ineq_constraint(model, limits.vytazok_fe.min, get_fe_production),
        }
    )
    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_upper_bound_ineq_constraint(model, limits.vytazok_fe.max, get_fe_production),
        }
    )

    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_lower_bound_ineq_constraint(model, limits.aglomerat.min, get_agglomerate_weight),
        }
    )
    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_upper_bound_ineq_constraint(model, limits.aglomerat.max, get_agglomerate_weight),
        }
    )

    all_constraints.append(
        {"type": "ineq", "fun": get_lower_bound_ineq_constraint(model, limits.mn.min, get_mn)}
    )
    all_constraints.append(
        {"type": "ineq", "fun": get_upper_bound_ineq_constraint(model, limits.mn.max, get_mn)}
    )

    all_constraints.append(
        {"type": "ineq", "fun": get_upper_bound_ineq_constraint(model, limits.p.max, get_p)}
    )

    all_constraints.append(
        {"type": "ineq", "fun": get_upper_bound_ineq_constraint(model, limits.zn.max, get_zn)}
    )

    all_constraints.append(
        {"type": "ineq", "fun": get_upper_bound_ineq_constraint(model, limits.alkalie.max, get_alkali)}
    )

    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_lower_bound_ineq_constraint(model, limits.pomer_kc_ar.min, get_kc_ar_ratio),
        }
    )
    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_upper_bound_ineq_constraint(model, limits.pomer_kc_ar.max, get_kc_ar_ratio),
        }
    )

    all_constraints.append(
        {"type": "ineq", "fun": get_lower_bound_ineq_constraint(model, limits.bazicita.min, get_basicity)}
    )
    all_constraints.append(
        {"type": "ineq", "fun": get_upper_bound_ineq_constraint(model, limits.bazicita.max, get_basicity)}
    )

    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_lower_bound_ineq_constraint(model, limits.mgo_do_trosky.min, get_mgo_in_slag),
        }
    )
    all_constraints.append(
        {
            "type": "ineq",
            "fun": get_upper_bound_ineq_constraint(model, limits.mgo_do_trosky.max, get_mgo_in_slag),
        }
    )

    return all_constraints


def get_bounds(
    model: Vectorized_VIU, all_weights_limits: List[Limit], constant_names: List[str]
) -> List[Tuple[float, float]]:
    bounds = []
    names_by_mapping = list(sorted(model.mapping, key=lambda name: model.mapping[name]))
    for name in names_by_mapping:
        if name not in constant_names:
            for limit in all_weights_limits:
                if name == limit.nazov:
                    bounds.append((limit.min, limit.max))
                    break
    return bounds


def get_weight_vector(
    model: Vectorized_VIU,
    all_weights_limits: List[Limit],
    constant_names: List[str],
    generating_func: Callable[[float, float], float],
) -> np.ndarray:
    weights = np.zeros(len(model.mapping) - len(constant_names))
    for name in model.mapping:
        if name not in constant_names:
            for limit in all_weights_limits:
                if name == limit.nazov:
                    weights[model.mapping[name]] = generating_func(limit.min, limit.max)
                    break
    return weights


def get_constant_components(all_weights_limits: List[Limit]) -> Tuple[List[str], np.ndarray]:
    return (
        [limit.nazov for limit in all_weights_limits if is_usable(limit) and is_constant(limit)],
        np.array([limit.min for limit in all_weights_limits if is_usable(limit) and is_constant(limit)]),
    )


def get_weights_dict(
    mapping: Mapping[str, int],
    constants: Dict[str, float],
    result: OptimizeResult,
) -> Dict[str, float]:
    names_by_mapping = list(sorted(mapping, key=lambda name: mapping[name]))
    return {**constants, **dict(zip(names_by_mapping, result.x))}


def add_zero_components_to_result_dict(  # pylint: disable=invalid-name
    all_weights_limits: List[Limit],
    weights: Dict[str, float],
) -> Dict[str, float]:
    optimized_weights = {**weights}
    for limit in all_weights_limits:
        if limit.nazov not in optimized_weights:
            optimized_weights[limit.nazov] = 0.0
    return optimized_weights
