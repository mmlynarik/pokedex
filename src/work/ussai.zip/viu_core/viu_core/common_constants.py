from .datamodel.model import ChemickaLatka

MET_FE_GROUP = {
    "SB-KUS",
    "Briketa - Kus",
    "CARAJAS",
    "Briketa - K",
    "Cegok 67.5%",
    "Lump Ore 65,5% Brazil",
    "PEL-Kostamuksa 65 (Karel)",
}
ASH_BURN_COMPONENTS = {ChemickaLatka.C, ChemickaLatka.H2O}
