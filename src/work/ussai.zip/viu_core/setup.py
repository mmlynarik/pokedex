"""A setuptools based setup module.

See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

from os import path

# Always prefer setuptools over distutils
from setuptools import setup

here = path.abspath(path.dirname(__file__))

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="viucore",
    version="0.0.1",
    package_data={
        "viu_core": ["py.typed"],
        "viu_core.datamodel": ["py.typed"],
        "viu_core.optimization": ["py.typed"],
    },
    packages=["viu_core", "viu_core.datamodel", "viu_core.optimization"],
    description="Value in use core calculations",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "pycel==1.0b30",
        "immutables==0.20",
        "pandas==2.0.*",
        "scipy>=1.7.3",
        "scikit-learn>=0.22.2",
    ],
    zip_safe=False,
)
