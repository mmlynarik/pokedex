import datetime
import unittest
from typing import List

import pandas as pd
from usskscadaocclient.scrap_data import Heat, ScrapWeights

from scrap_core.home_scrap_estimation import estimate_weekly_home_scrap_production


class FakeConnector:
    def get_heat_data(self, dt_from: datetime.date, dt_to: datetime.date) -> List[Heat]:
        random_heats = [
            Heat(
                heat_no=52203,
                heat_year=2021,
                heat_datetime=pd.Timestamp(2021, 12, 1, 1, 58, 9),
                steelshop=2,
                final_steel_w=175800.0,
                heat_yield=90.119915,
                planned_grade_id=195,
                final_grade_id=195,
                operator_id=101,
                basket_1=110,
                basket_2=None,
                scrap_weight=2500.0,
                scrap_weight_with_hsb_cool=2500.0,
                extra_o2=0.0,
                eob_s=0.0061,
                s_max=0.01,
                synt_slag=434.0,
                scrap_weights=ScrapWeights(
                    scrap_09=2500,
                ),
            ),
            Heat(
                heat_no=41133,
                heat_year=2021,
                heat_datetime=pd.Timestamp(2021, 12, 8, 6, 28, 1),
                steelshop=2,
                final_steel_w=173600.0,
                heat_yield=90.119915,
                planned_grade_id=195,
                final_grade_id=195,
                operator_id=101,
                basket_1=110,
                basket_2=None,
                scrap_weight=13400.0,
                scrap_weight_with_hsb_cool=13400.0,
                extra_o2=0.0,
                eob_s=0.0061,
                s_max=0.01,
                synt_slag=434.0,
                scrap_weights=ScrapWeights(
                    scrap_03=8000,
                    scrap_09=5400,
                ),
            ),
            Heat(
                heat_no=41134,
                heat_year=2021,
                heat_datetime=pd.Timestamp(2021, 12, 8, 7, 41, 44),
                steelshop=2,
                final_steel_w=166200.0,
                heat_yield=90.119915,
                planned_grade_id=195,
                final_grade_id=195,
                operator_id=101,
                basket_1=110,
                basket_2=None,
                scrap_weight=5000.0,
                scrap_weight_with_hsb_cool=5000.0,
                extra_o2=0.0,
                eob_s=0.0061,
                s_max=0.01,
                synt_slag=434.0,
                scrap_weights=ScrapWeights(
                    scrap_03=5000,
                ),
            ),
            Heat(
                heat_no=41145,
                heat_year=2021,
                heat_datetime=pd.Timestamp(2021, 12, 16, 19, 3, 1),
                steelshop=2,
                final_steel_w=174500.0,
                heat_yield=90.119915,
                planned_grade_id=195,
                final_grade_id=195,
                operator_id=101,
                basket_1=110,
                basket_2=None,
                scrap_weight=21500.0,
                scrap_weight_with_hsb_cool=21500.0,
                extra_o2=0.0,
                eob_s=0.0061,
                s_max=0.01,
                synt_slag=434.0,
                scrap_weights=ScrapWeights(
                    scrap_03=3200,
                    scrap_96=18300,
                ),
            ),
            Heat(
                heat_no=52211,
                heat_year=2021,
                heat_datetime=pd.Timestamp(2021, 12, 16, 10, 15, 43),
                steelshop=2,
                final_steel_w=173400.0,
                heat_yield=90.119915,
                planned_grade_id=195,
                final_grade_id=195,
                operator_id=101,
                basket_1=110,
                basket_2=None,
                scrap_weight=4100.0,
                scrap_weight_with_hsb_cool=4100.0,
                extra_o2=0.0,
                eob_s=0.0061,
                s_max=0.01,
                synt_slag=434.0,
                scrap_weights=ScrapWeights(
                    scrap_96=4100,
                ),
            ),
        ]
        return [heat for heat in random_heats if dt_from <= heat.heat_datetime.date() <= dt_to]


class TestScrapPurchaseHomeScrap(unittest.TestCase):
    def test_home_scrap_estimation(self):

        estimates = estimate_weekly_home_scrap_production(FakeConnector(), datetime.date(2021, 12, 31), 1000)
        for scrap_type, value in estimates.items():
            self.assertGreaterEqual(
                value, 0, msg=f"Estimated value of {scrap_type} must be non-negative, got {value}"
            )


if __name__ == "__main__":
    unittest.main()
