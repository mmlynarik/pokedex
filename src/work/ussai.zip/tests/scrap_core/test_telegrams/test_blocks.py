import unittest

from scrap_core.telegrams.blocks import ScrapWeight, ScrapCodes, Car


class TestScrapCodes(unittest.TestCase):
    def test_encoding_decoding(self):
        scrap_codes = ScrapCodes(6, 10, 110, 94, code_17=942)
        self.assertEqual(ScrapCodes.from_str(scrap_codes.to_str()), scrap_codes)

    def test_num_of_leaf_fields(self):
        self.assertEqual(ScrapCodes.get_num_of_leaf_fields(), 20)

    def test_to_level2_conversion(self):
        scrap_codes = ScrapCodes(1, 6, 10, 110, 94, code_17=942)
        self.assertEqual(scrap_codes.to_str(), "01;06;10;110;94;;;;;;;;;;;;94_2;;;")

    def test_from_level2_conversion(self):
        scrap_codes = ScrapCodes(6, 10, 110, 94, code_17=942)
        self.assertEqual(scrap_codes, ScrapCodes.from_str("06;10;110;94;;;;;;;;;;;;;94_2;;;"))


class TestScrapWeight(unittest.TestCase):
    def test_encoding_decoding(self):
        scrap_weight = ScrapWeight(1000, 2000, 3000, weight_17=17000)
        self.assertEqual(ScrapWeight.from_str(scrap_weight.to_str()), scrap_weight)

    def test_num_of_leaf_fields(self):
        self.assertEqual(ScrapWeight.get_num_of_leaf_fields(), 20)


class TestScrapCar(unittest.TestCase):
    def test_encoding_decoding(self):
        scrap_weight = ScrapWeight(1000, 2000, 3000, weight_17=17000)
        car = Car(car_no=123, order_no=10, scrap_weight=scrap_weight)
        self.assertEqual(Car.from_str(car.to_str()), car)

    def test_num_of_leaf_fields(self):
        self.assertEqual(Car.get_num_of_leaf_fields(), 26)


if __name__ == "__main__":
    unittest.main()
