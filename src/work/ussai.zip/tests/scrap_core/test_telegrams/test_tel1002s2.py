from datetime import datetime
import unittest

import pytz


from scrap_core.telegrams.tel1002s2 import TelegramHeaderS2, Telegram1002s2
from scrap_core.telegrams.blocks import ScrapWeight, ScrapCodes

from tests.scrap_core.test_telegrams.common import get_real_telegram


header = TelegramHeaderS2(operator_id=110, blend_id=3)

scrap_codes = ScrapCodes(code_1=15, code_2=6, code_3=96_2, code_10=10)

scrap_weight = ScrapWeight(1000, 2000, 3000, weight_10=12300)

telegram = Telegram1002s2(
    header=header,
    num_of_cars=2,
    is_wet_scrap=True,
    scrap_codes=scrap_codes,
    scrap_weight_1=scrap_weight,
    num_of_scraps=4,
    car_no_1=55,
    timestamp=datetime(2023, 1, 1, tzinfo=pytz.UTC),
    ordered_grade="KA09",
    selectivity=2,
    ordered_bundle=123,
    ordered_pit=123,
    scale_id=123,
)


class TestTelegram1002s2Synthetic(unittest.TestCase):
    def test_encoding_decoding(self):
        self.assertEqual(Telegram1002s2.from_bytes(telegram.to_bytes()), telegram)

    def test_num_of_leaf_fields(self):
        self.assertEqual(Telegram1002s2.get_num_of_leaf_fields(), 174)

    def test_telegram_len(self):
        data = telegram.to_bytes().decode("utf8")
        tel_len, remainder = data.split(";", 1)
        self.assertEqual(int(tel_len), len(data))


class TestTelegram1002s2Real(unittest.TestCase):
    def test_encoding(self):
        raw = get_real_telegram(2)
        tel = Telegram1002s2.from_bytes(raw)
        self.assertEqual(raw, tel.to_bytes())

    def test_decoding(self):
        raw = get_real_telegram(2)
        tel = Telegram1002s2.from_bytes(raw)
        self.assertEqual(tel.tel_no, 1002)


if __name__ == "__main__":
    unittest.main()
