import unittest

from scrap_core.telegrams.tel1002s1 import TelegramHeaderS1, Telegram1002s1
from scrap_core.telegrams.blocks import ScrapWeight, ScrapCodes, Car

from tests.scrap_core.test_telegrams.common import get_real_telegram


header = TelegramHeaderS1(operator_id=111, blend_id=3)

scrap_codes = ScrapCodes(code_1=15, code_2=6, code_3=96_2, code_10=10)

scrap_weight = ScrapWeight(1000, 2000, 3000, weight_10=12300)

car = Car(car_no=123, selectivity=5, scrap_weight=ScrapWeight(weight_10=12300))

telegram = Telegram1002s1(
    header=header,
    scale_id=123,
    num_of_cars=2,
    is_wet_scrap=True,
    scrap_codes=scrap_codes,
    scrap_weight=scrap_weight,
    num_of_scraps=4,
    car_1=car,
    car_2=car,
)


class TestTelegram1002s1Synthetic(unittest.TestCase):
    def test_encoding_decoding(self):
        self.assertEqual(Telegram1002s1.from_bytes(telegram.to_bytes()), telegram)

    def test_num_of_leaf_fields(self):
        self.assertEqual(Telegram1002s1.get_num_of_leaf_fields(), 159)

    def test_telegram_len(self):
        data = telegram.to_bytes()
        tel_len, remainder = data.decode("utf8").split(";", 1)
        self.assertEqual(int(tel_len), len(data))


class TestTelegram1002s1Real(unittest.TestCase):
    def test_encoding(self):
        raw = get_real_telegram(1)
        tel = Telegram1002s1.from_bytes(raw)
        self.assertEqual(raw, tel.to_bytes())

    def test_decoding(self):
        raw = get_real_telegram(1)
        tel = Telegram1002s1.from_bytes(raw)
        self.assertEqual(tel.tel_no, 1002)


if __name__ == "__main__":
    unittest.main()
