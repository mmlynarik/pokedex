import csv


def get_real_telegram(steelshop: int) -> bytes:
    with open(
        f"tests/scrap_core/test_telegrams/test_data/tel1002s{steelshop}.csv", encoding="utf8"
    ) as csvfile:
        reader = csv.DictReader(csvfile)
        data = ";".join(map(str, (row["Value"] for row in reader)))

    tel_len, remainder = data.split(";", 1)
    return f"{tel_len:>05};{remainder};\0".encode("utf8")
