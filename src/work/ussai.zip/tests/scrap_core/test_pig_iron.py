import unittest
from typing import List
from scrap_core.datamodel import load_heats_from_file, Heat
from scrap_core.pigironanalysis import (
    get_s_values_by_grade,
    get_best_predictor_for_chem,
    get_after_desulf_values_for_chem,
    get_time_window_starts,
)
from . import TEST_HEATS


class TestPigIron(unittest.TestCase):
    heats: List[Heat]

    @classmethod
    def setUpClass(cls):
        super(TestPigIron, cls).setUpClass()
        cls.heats = load_heats_from_file(str(TEST_HEATS))

    def test_pig_iron_s_with_valid_data(self):
        result = get_s_values_by_grade(self.heats)
        self.assertIsInstance(result, dict)
        self.assertNotEqual(0, len(result))

    def test_pig_iron_get_after_desulf_values_for_chem(self):
        expected_value = self.heats[0].after_desulf.P
        expected_timestamp = self.heats[0].heat_datetime
        result = get_after_desulf_values_for_chem(self.heats, "P")
        self.assertEqual(len(self.heats), len(result))
        self.assertEqual(result[0].value, expected_value)
        self.assertEqual(result[0].timestamp, expected_timestamp)

    def test_pig_iron_get_time_window_starts(self):
        data = get_after_desulf_values_for_chem(self.heats, "P")
        time_window_starts = get_time_window_starts(17280, data, 40)
        self.assertEqual(time_window_starts[0] + 17280, time_window_starts[1])
        self.assertIsInstance(time_window_starts, list)
        self.assertNotEqual(0, len(time_window_starts))

    @unittest.skip("Long running test")
    def test_pig_iron_with_valid_data(self):
        best_predictor, valid_predictors = get_best_predictor_for_chem(self.heats, "P", 1, 40)
        self.assertIsNotNone(best_predictor)
        self.assertIsNotNone(valid_predictors)
