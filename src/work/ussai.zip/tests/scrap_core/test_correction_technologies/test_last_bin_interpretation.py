import unittest

from hypothesis import given
from hypothesis.strategies import floats

from scrap_core.blendmodel import OrdinalRegressionChemEstimate


ESTIMATE = OrdinalRegressionChemEstimate((1, 2), (0.2, 0.3, 0.5))
LAST_BIN_LOW = float(ESTIMATE.full_binning[-2])
LAST_BIN_UPP = float(ESTIMATE.full_binning[-1])
# There are currently problems when changing float to tensor and back and we lose precision
LAST_BIN_UPP_2 = float(ESTIMATE.full_binning[-1]) - 0.00001
LAST_BIN_PROBABILITY = ESTIMATE.probas[-1]


class TestLastBinProbabilityInterpretation(unittest.TestCase):
    """Test that last bin is "equivalent" to its right endpoint"""

    @given(floats(LAST_BIN_LOW, LAST_BIN_UPP_2, exclude_max=True))
    def test_last_bin_cdf(self, value):
        """Test that P(X in [LAST_BIN_LOW, value]) == 0, for every value < LAST_BIN_UPP"""
        self.assertAlmostEqual(ESTIMATE.cdf(value) - ESTIMATE.cdf(LAST_BIN_LOW), 0, places=5)

    @given(floats(1 - LAST_BIN_PROBABILITY, 1, exclude_min=True))
    def test_last_bin_percentiles(self, value):
        self.assertAlmostEqual(ESTIMATE.percentile(value), LAST_BIN_UPP, places=5)


if __name__ == "__main__":
    unittest.main()
