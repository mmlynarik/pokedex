from typing import Tuple
import unittest

import attr
import numpy as np
from scrap_core import Chem

from scrap_core.blendmodel import ScrapBlendModelOutput
from scrap_core.correctiontechnologiesmodel.correction_technologies import (
    get_correction_technologies_for_grade,
)
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities import (
    extend_pmf,
    pmf_to_cdf_vectorized,
    cdf_to_pmf_vectorized,
    get_corr_tech_pmf_for_chem,
    get_corr_tech_probabilities,
)
from usskssgrades import Grade, ChemLimit
from scrap_core.blendmodel.datamodel import get_synthetic_chem_estimate

from .. import get_uniform_binning


class TestProbabilityUtilityFunctionsEssentials(unittest.TestCase):
    UNIFORM_BINNING = get_uniform_binning(0.005, 0.1, 0.005)

    MODEL_OUTPUT_1 = ScrapBlendModelOutput(
        S=get_synthetic_chem_estimate(UNIFORM_BINNING, 0.021),
        Si=get_synthetic_chem_estimate(UNIFORM_BINNING, 0),
        Cu=get_synthetic_chem_estimate(UNIFORM_BINNING, 0.01),
        Ni=get_synthetic_chem_estimate(UNIFORM_BINNING, 0),
        Cr=get_synthetic_chem_estimate(UNIFORM_BINNING, 0),
        Mo=get_synthetic_chem_estimate(UNIFORM_BINNING, 0.015),
        Sn=get_synthetic_chem_estimate(UNIFORM_BINNING, 0),
    )

    MODEL_OUTPUT_2 = attr.evolve(MODEL_OUTPUT_1, Ni=get_synthetic_chem_estimate(UNIFORM_BINNING, 0.031))

    GRADE = Grade(
        grade_id=0,
        display_name="test_grade",
        limits=(
            ChemLimit("P_blow", 0, 0.01),
            ChemLimit("S", 0, 0.02),
            ChemLimit("Si", 0, 0.03),
            ChemLimit("Cr", 0, 0.04),
        ),
        is_calmed=True,
        min_synt_slag=250,
    )
    PREDICTED_CHEMS: Tuple[Chem, ...] = ("Cr", "S")

    def assert_is_non_decreasing(self, f):
        self.assertListEqual(list(f), sorted(f))

    def assert_is_bounded(self, f, lower_bound, upper_bound):
        values = f.values() if isinstance(f, dict) else f

        min_val = min(values)
        max_val = max(values)

        self.assertLessEqual(lower_bound, min_val)
        self.assertLessEqual(max_val, upper_bound)

    def test_extend_pmf(self):
        pmf = {
            "a": 0.2,
            "b": 0.7,
            "c": 0.1,
        }
        domain = ["a", "x"]

        expected_result = {
            "a": 0.2,
            "b": 0.7,
            "c": 0.1,
            "x": 0,
        }

        result = extend_pmf(pmf, domain)

        self.assertDictEqual(result, expected_result)

    def test_pmf_to_cdf_vectorized(self):
        expected_cdfs = np.array([[0.1, 0.7, 1], [0.4, 0.4, 1]])
        pmfs = np.array([[0.1, 0.6, 0.3], [0.4, 0, 0.6]])

        cdfs = pmf_to_cdf_vectorized(pmfs, axis=1)

        # Check that there is no non-zero element in the difference of actual and expected cdfs,
        # i.e. they are (almost) the same.
        self.assertFalse(np.round(cdfs - expected_cdfs, decimals=10).any())

    def test_cdf_to_pmf_vectorized(self):
        cdfs = np.array([[0.1, 0.7, 1], [0.4, 0.4, 1]])
        expected_pmfs = np.array([[0.1, 0.6, 0.3], [0.4, 0, 0.6]])

        pmfs = cdf_to_pmf_vectorized(cdfs)

        # Check that there is no non-zero element in the difference of actual and expected pmfs,
        # i.e. they are (almost) the same.
        self.assertFalse(np.round(pmfs - expected_pmfs, decimals=10).any())

    def test_get_corr_tech_pmf_for_chem(self):

        corr_techs = get_correction_technologies_for_grade(self.GRADE)
        pmf = get_corr_tech_pmf_for_chem("S", self.MODEL_OUTPUT_1, corr_techs)

        self.assert_is_bounded(pmf, 0, 1)
        self.assertAlmostEqual(sum(pmf.values()), 1, places=10)

    def test_get_corr_tech_probabilities_wo_min_synt_slag(self):

        grade = attr.evolve(self.GRADE, min_synt_slag=0)
        pmfs = get_corr_tech_probabilities(
            [self.MODEL_OUTPUT_1, self.MODEL_OUTPUT_2], grade, self.PREDICTED_CHEMS
        )

        for pmf in pmfs:
            self.assert_is_bounded(pmf, 0, 1)
            self.assertAlmostEqual(sum(pmf.values()), 1, places=10)

    def test_get_corr_tech_probabilities_w_min_synt_slag(self):

        pmfs = get_corr_tech_probabilities(
            [self.MODEL_OUTPUT_1, self.MODEL_OUTPUT_2], self.GRADE, self.PREDICTED_CHEMS
        )

        for pmf in pmfs:
            self.assert_is_bounded(pmf, 0, 1)
            self.assertAlmostEqual(sum(pmf.values()), 1, places=10)


if __name__ == "__main__":
    unittest.main()
