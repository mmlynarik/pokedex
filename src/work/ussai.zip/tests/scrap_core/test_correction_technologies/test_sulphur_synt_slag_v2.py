"""
Relevant documents:
    - OPrP-AE-0037 - Doplnenie DTP pre Odsirenie a KK_v5_fin.pdf          (alias 0037)

Both synt slag weight - correction and speed - are defined here:

    doc. 0037, p. 17, section 6.11.2
"""

import unittest

from typing import Tuple

from scrap_core.blendmodel import ScrapBlendModelOutput

from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import get_corr_tech_probabilities
from usskssgrades import ChemLimit, Grade
from scrap_core.blendmodel.datamodel import get_synthetic_chem_estimate

from .. import get_uniform_binning
from . import NOT_SI_DOPED_LIMIT, SI_DOPED_LIMIT


class TestCalmedSteelSyntSlagWeight(unittest.TestCase):
    # Synthetic slag can be used for calmed steel only.
    IS_CALMED = True

    def _execute_experiment(
        self, s_real: float, s_max: float, is_si_doped: bool, expected_corr_tech: Tuple[Ctt, float]
    ) -> None:
        # create grade based on given grade limits
        s_limit = ChemLimit("S", 0, s_max)
        si_limit = SI_DOPED_LIMIT if is_si_doped else NOT_SI_DOPED_LIMIT

        grade = Grade(
            grade_id=0,
            display_name="test_grade",
            limits=(
                ChemLimit("P_blow", 0, 1),
                s_limit,
                si_limit,
            ),
            is_calmed=self.IS_CALMED,
            min_synt_slag=0,
        )

        # chem estimate with tiny standard deviation mimics exact value rather than random variable
        uniform_binning = get_uniform_binning(0.0005, 0.1, 0.0005)

        model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, s_real),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, 0),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(uniform_binning, 0),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        # execute
        probabilities = get_corr_tech_probabilities([model_output], grade, ("S",))[0]

        self.assertIn(expected_corr_tech, probabilities)

        self.assertAlmostEqual(
            probabilities[expected_corr_tech],
            1,
            places=5,
            msg=f"Expected correction technology is {expected_corr_tech}, got: {probabilities}",
        )

        # check that no other correction technology is used
        for corr_tech in probabilities.keys():
            if corr_tech != expected_corr_tech:
                self.assertAlmostEqual(
                    probabilities[corr_tech],
                    0,
                    places=5,
                    msg=f"Correction technology {corr_tech} should not be used, got: {probabilities}",
                )

    def test_si_doped_sulphur_0000(self):
        desulf_weight = 0
        for s_real, speed_weight in [(0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift s_max, so that s_real < s_max
            s_max = s_real + 0.0005

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=True, expected_corr_tech=expected_corr_tech
                )

    def test_si_doped_sulphur_0001(self):
        desulf_weight = 800
        for s_real, speed_weight in [(0.014, 0), (0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.001 %
            s_max = s_real - 0.0005

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=True, expected_corr_tech=expected_corr_tech
                )

    def test_si_doped_sulphur_0002(self):
        desulf_weight = 1300
        for s_real, speed_weight in [(0.014, 0), (0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.002 %
            s_max = s_real - 0.0015

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=True, expected_corr_tech=expected_corr_tech
                )

    def test_si_doped_sulphur_0003(self):
        desulf_weight = 1700
        for s_real, speed_weight in [
            (0.01499, 0),
            (0.016, 800),
            (0.0175, 1000),
            (0.019, 1800),
            (0.021, 2000),
        ]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.003 %
            s_max = s_real - 0.0025

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=True, expected_corr_tech=expected_corr_tech
                )

    def test_si_doped_sulphur_0004(self):
        desulf_weight = 2000
        for s_real, speed_weight in [(0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.004 %
            s_max = s_real - 0.0035

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=True, expected_corr_tech=expected_corr_tech
                )

    def test_not_si_doped_sulphur_0000(self):
        desulf_weight = 0
        for s_real, speed_weight in [(0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift s_max, so that s_real < s_max
            s_max = s_real + 0.0005

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=False, expected_corr_tech=expected_corr_tech
                )

    def test_not_si_doped_sulphur_0001(self):
        desulf_weight = 1000
        for s_real, speed_weight in [(0.014, 0), (0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.001 %
            s_max = s_real - 0.0005

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=False, expected_corr_tech=expected_corr_tech
                )

    def test_not_si_doped_sulphur_0002(self):
        desulf_weight = 1500
        for s_real, speed_weight in [(0.014, 0), (0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.002 %
            s_max = s_real - 0.0015

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=False, expected_corr_tech=expected_corr_tech
                )

    def test_not_si_doped_sulphur_0003(self):
        desulf_weight = 1800
        for s_real, speed_weight in [
            (0.01499, 0),
            (0.016, 800),
            (0.0175, 1000),
            (0.019, 1800),
            (0.021, 2000),
        ]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.003 %
            s_max = s_real - 0.0025

            expected_corr_tech = (Ctt.SYNT_SLAG, desulf_weight + speed_weight)
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=False, expected_corr_tech=expected_corr_tech
                )

    def test_not_si_doped_sulphur_0004(self):
        expected_corr_tech = (Ctt.REBLOW, 1)

        for s_real, _ in [(0.014, 0), (0.016, 800), (0.0175, 1000), (0.019, 1800), (0.021, 2000)]:
            # shift `s_max`, so that difference `s_real - s_max` fits under bound 0.004 %
            s_max = s_real - 0.0035
            with self.subTest(
                f"s_real = {s_real:.4f}, s_max = {s_max:.4f}, corr_tech = {expected_corr_tech}"
            ):
                self._execute_experiment(
                    s_real, s_max, is_si_doped=False, expected_corr_tech=expected_corr_tech
                )


if __name__ == "__main__":
    unittest.main()
