import unittest

import torch

from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import (
    generalized_hadamard_product,
    cdf_batch,
)
from scrap_core.correctiontechnologiesmodel.correction_technologies import (
    CorrectionTechnology as Ct,
    refine_synt_slag_corrections,
)
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt


class TestCorrectionUtilities(unittest.TestCase):
    def test_refine_synt_slag_corrections(self):
        corrs_conf = {(0, 5): 100, (2, 7): 200, (6, 8): 300}

        expected_corrections_conf = {(0, 2): 100, (2, 5): 300, (5, 6): 200, (6, 7): 500, (7, 8): 300}

        corrections = [
            Ct(reason="S", lower_limit=left, upper_limit=right, type=Ctt.SYNT_SLAG, value=value)
            for (left, right), value in corrs_conf.items()
        ]

        expected_corrections = [
            Ct(reason="S", lower_limit=left, upper_limit=right, type=Ctt.SYNT_SLAG, value=value)
            for (left, right), value in expected_corrections_conf.items()
        ]

        refinement = list(refine_synt_slag_corrections(corrections))

        self.assertListEqual(expected_corrections, refinement)

    def test_refine_synt_slag_corrections_with_upper_bound(self):
        corrs_conf = {(0, 5): 100, (2, 7): 200, (6, 9): 300}

        expected_corrections_conf = {
            (0, 2): 100,
            (2, 5): 300,
            (5, 6): 200,
            (6, 7): 500,
        }

        upper_bound = 8

        corrections = [
            Ct(reason="S", lower_limit=left, upper_limit=right, type=Ctt.SYNT_SLAG, value=value)
            for (left, right), value in corrs_conf.items()
        ]

        expected_corrections = [
            Ct(reason="S", lower_limit=left, upper_limit=right, type=Ctt.SYNT_SLAG, value=value)
            for (left, right), value in expected_corrections_conf.items()
        ]

        refinement = list(refine_synt_slag_corrections(corrections, upper_bound))

        self.assertListEqual(expected_corrections, refinement)


# pylint:disable=invalid-name
class TestGeneralizedHadamardProduct(unittest.TestCase):
    def test_trivial_case(self):
        a = torch.Tensor([[1, 2, 3]])
        b = torch.Tensor([[3, 4, 5]])

        expected_result = torch.Tensor([[3, 8, 15]])

        result = generalized_hadamard_product([a, b])

        self.assertTrue((result == expected_result).all())

    def test_simple_case(self):
        a = torch.Tensor([[1, 2, 3]])
        b = torch.Tensor([[3, 4, 5]])
        c = torch.Tensor([[6, 7, 8]])

        expected_result = torch.Tensor([[18, 56, 120]])
        result = generalized_hadamard_product([a, b, c])

        self.assertTrue((result == expected_result).all())

    # pylint: disable=no-member
    def test_batch(self):
        a = torch.Tensor([[1, 2, 3]])
        b = torch.Tensor([[3, 4, 5]])
        c = torch.Tensor([[6, 7, 8]])

        x = a * 10
        y = b * 11
        z = c * 12

        subresult_abc = generalized_hadamard_product([a, b, c])
        subresult_xyz = generalized_hadamard_product([x, y, z])

        result_batch = generalized_hadamard_product(
            [torch.stack([a, x]).squeeze(), torch.stack([b, y]).squeeze(), torch.stack([c, z]).squeeze()]
        )

        self.assertTrue((torch.stack([subresult_abc, subresult_xyz]).squeeze() == result_batch).all())


class TestBatchCDF(unittest.TestCase):
    def test_simple_case(self):
        probas_matrix = torch.Tensor([[0.1, 0.3, 0.3, 0.3, 0.0], [0.0, 0.2, 0.1, 0.4, 0.3]])
        binning_array = torch.Tensor([0, 1, 2, 3, 4, 100])

        self.assertAlmostEqual(
            float((cdf_batch(0, probas_matrix, binning_array) - torch.Tensor([0.0, 0.0])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(1, probas_matrix, binning_array) - torch.Tensor([0.1, 0.0])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(2, probas_matrix, binning_array) - torch.Tensor([0.4, 0.2])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(2.5, probas_matrix, binning_array) - torch.Tensor([0.55, 0.25])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(3, probas_matrix, binning_array) - torch.Tensor([0.7, 0.3])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(4, probas_matrix, binning_array) - torch.Tensor([1.0, 0.7])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(5, probas_matrix, binning_array) - torch.Tensor([1.0, 0.7])).sum()), 0, 5
        )
        self.assertAlmostEqual(
            float((cdf_batch(6, probas_matrix, binning_array) - torch.Tensor([1.0, 0.7])).sum()), 0, 5
        )


if __name__ == "__main__":
    unittest.main()
