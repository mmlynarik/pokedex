# pylint:disable=invalid-name,no-member
import unittest
import unittest.mock as mock

from hypothesis import given
from hypothesis.strategies import floats
from immutables import Map

from scrap_core.blendmodel import ScrapBlendModelOutput
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import get_corr_tech_probabilities
from scrap_core.correctiontechnologiesmodel.correction_technologies import (
    CorrectionTechnologies,
    CorrectionTechnology,
)
from usskssgrades import ChemLimit, Grade
from scrap_core.blendmodel.datamodel import get_synthetic_chem_estimate

from .. import get_uniform_binning
from . import NOT_SI_DOPED_LIMIT


class TestVariousInputCombinations(unittest.TestCase):
    BINNING_MAP = Map({"Cr": (1, 2, 3), "S": (1, 2, 3, 4)})

    CORR_TECHS = CorrectionTechnologies(
        S=(
            CorrectionTechnology(reason="S", lower_limit=0, upper_limit=1.5, type=Ctt.NO_CORRECTION, value=1),
            CorrectionTechnology(reason="S", lower_limit=1.5, upper_limit=3, type=Ctt.SYNT_SLAG, value=1000),
            CorrectionTechnology(reason="S", lower_limit=3, upper_limit=4, type=Ctt.REBLOW, value=1),
            CorrectionTechnology(
                reason="S", lower_limit=4, upper_limit=float("inf"), type=Ctt.RECLASSIFICATION, value=1
            ),
        ),
        Cu=(),
        Ni=(),
        Cr=(
            CorrectionTechnology(reason="Cr", lower_limit=0, upper_limit=1, type=Ctt.NO_CORRECTION, value=1),
            CorrectionTechnology(reason="Cr", lower_limit=1, upper_limit=2.5, type=Ctt.REBLOW, value=1),
            CorrectionTechnology(
                reason="Cr", lower_limit=2.5, upper_limit=float("inf"), type=Ctt.RECLASSIFICATION, value=1
            ),
        ),
        Mo=(),
        Si=(),
        Sn=(),
    )

    DUMMY_GRADE = Grade(grade_id=0, display_name="dummy_grade", limits=(), is_calmed=True, min_synt_slag=0)

    def test_chem_combination(self):
        """
        Test that combination of 2 chems picks the worst correction technology
        applicable to at least one them.
        """
        uniform_binning = get_uniform_binning(1, 1, 1)

        model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(self.BINNING_MAP["S"], 2),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, 0),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(self.BINNING_MAP["Cr"], 2),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        with mock.patch(
            "scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2"
            ".get_correction_technologies_for_grade",
            return_value=self.CORR_TECHS,
        ):
            probabilities_s = get_corr_tech_probabilities([model_output], self.DUMMY_GRADE, ("S",))[0]
            probabilities_cr = get_corr_tech_probabilities([model_output], self.DUMMY_GRADE, ("Cr",))[0]
            probabilities_s_cr = get_corr_tech_probabilities([model_output], self.DUMMY_GRADE, ("Cr", "S"))[0]

            self.assertEqual(probabilities_s[(Ctt.NO_CORRECTION, 1)], 0.5)
            self.assertEqual(probabilities_s[(Ctt.SYNT_SLAG, 1000)], 0.5)

            self.assertEqual(probabilities_cr[(Ctt.REBLOW, 1)], 1)

            self.assertEqual(probabilities_s_cr[(Ctt.REBLOW, 1)], 1)

    @given(floats(0, 0.1), floats(0, 0.1), floats(0, 0.1))
    def test_sum_of_probabilities(self, s_real, cu_real, cr_real):
        grade = Grade(
            grade_id=0,
            display_name="test_grade",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.022),
                ChemLimit("Cu", 0, 0.04),
                ChemLimit("Cr", 0, 0.009),
                NOT_SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        uniform_binning = get_uniform_binning(0.05, 0.4, 0.05)

        model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, s_real),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, cu_real),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(uniform_binning, cr_real),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        result = get_corr_tech_probabilities([model_output], grade, ("S", "Cu", "Cr"))[0]

        self.assertAlmostEqual(sum(result.values()), 1, 5)

    def test_multiple_model_outputs(self):
        grade = Grade(
            grade_id=0,
            display_name="test_grade",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.022),
                ChemLimit("Cu", 0, 0.04),
                ChemLimit("Cr", 0, 0.009),
                NOT_SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        uniform_binning = get_uniform_binning(0.05, 0.1, 0.05)

        model_output_1 = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, 0.02),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, 0.05),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(uniform_binning, 0.01),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        model_output_2 = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, 0.025),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, 0.02),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(uniform_binning, 0.005),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        result_1 = get_corr_tech_probabilities([model_output_1], grade, ("S", "Cu", "Cr"))
        result_2 = get_corr_tech_probabilities([model_output_2], grade, ("S", "Cu", "Cr"))

        result = get_corr_tech_probabilities([model_output_1, model_output_2], grade, ("S", "Cu", "Cr"))

        self.assertDictEqual(result_1[0], result[0])
        self.assertDictEqual(result_2[0], result[1])


if __name__ == "__main__":
    unittest.main()
