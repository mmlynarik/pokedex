from usskssgrades import ChemLimit


NOT_SI_DOPED_LIMIT = ChemLimit("Si", 0, 0.1)
SI_DOPED_LIMIT = ChemLimit("Si", 0.101, 1)
