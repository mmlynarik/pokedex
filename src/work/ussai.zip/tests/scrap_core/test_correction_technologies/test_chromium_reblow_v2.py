"""
Relevant documents:
    - OPrP-AE-0037 - Doplnenie DTP pre Odsirenie a KK_v5_fin.pdf          (alias 0037)
"""

import unittest

from scrap_core.blendmodel import ScrapBlendModelOutput
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import get_corr_tech_probabilities
from usskssgrades import ChemLimit, Grade
from scrap_core.blendmodel.datamodel import get_synthetic_chem_estimate

from .. import get_uniform_binning


class TestChromiumReblow(unittest.TestCase):
    def test_simple_cases(self):
        grade = Grade(
            grade_id=0,
            display_name="test_grade_with_chromium",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 1),
                ChemLimit("Si", 0, 1),
                ChemLimit("Cr", 0, 0.02),
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # According to "doc. 0037, p. 14, section 6.5", if cr_max - 0.005 < cr_real
        # then a reblow is needed.
        for cr_real, expected_corr_tech in [
            (0.014, (Ctt.NO_CORRECTION, 1)),
            (0.016, (Ctt.REBLOW, 1)),
        ]:
            with self.subTest(f"cr_real = {cr_real:.3f}, tech = {expected_corr_tech[0]}"):
                uniform_binning = get_uniform_binning(0.005, 0.1, 0.005)

                model_output = ScrapBlendModelOutput(
                    S=get_synthetic_chem_estimate(uniform_binning, 0),
                    Si=get_synthetic_chem_estimate(uniform_binning, 0),
                    Cu=get_synthetic_chem_estimate(uniform_binning, 0),
                    Ni=get_synthetic_chem_estimate(uniform_binning, 0),
                    Cr=get_synthetic_chem_estimate(uniform_binning, cr_real),
                    Mo=get_synthetic_chem_estimate(uniform_binning, 0),
                    Sn=get_synthetic_chem_estimate(uniform_binning, 0),
                )

                probabilities = get_corr_tech_probabilities([model_output], grade, ("Cr",))[0]

                self.assertIn(expected_corr_tech, probabilities)

                self.assertAlmostEqual(
                    probabilities[expected_corr_tech],
                    1,
                    places=5,
                    msg=f"Expected correction technology is {expected_corr_tech}, got: {probabilities}",
                )


if __name__ == "__main__":
    unittest.main()
