"""
Relevant documents:
    - DTP-AE-0048.pdf                                                     (alias 0048)
    - OPrP-AE-0037 - Doplnenie DTP pre Odsirenie a KK_v5_fin.pdf          (alias 0037)
"""

import unittest

from typing import Tuple

from scrap_core.blendmodel import ScrapBlendModelOutput

from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import get_corr_tech_probabilities
from usskssgrades import ChemLimit, Grade
from scrap_core.blendmodel.datamodel import get_synthetic_chem_estimate

from .. import get_uniform_binning
from . import NOT_SI_DOPED_LIMIT, SI_DOPED_LIMIT


class TestSulphurCorrections(unittest.TestCase):
    def _execute_experiment(self, grade: Grade, s_real: float, expected_corr_tech: Tuple[Ctt, float]) -> None:
        uniform_binning = get_uniform_binning(0.0005, 0.1, 0.0005)

        model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, s_real),
            Si=get_synthetic_chem_estimate(uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(uniform_binning, 0),
            Ni=get_synthetic_chem_estimate(uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(uniform_binning, 0),
            Mo=get_synthetic_chem_estimate(uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(uniform_binning, 0),
        )

        probabilities = get_corr_tech_probabilities([model_output], grade, ("S",))[0]

        self.assertIn(expected_corr_tech, probabilities)

        self.assertAlmostEqual(
            probabilities[expected_corr_tech],
            1,
            places=5,
            msg=f"Expected correction technology is {expected_corr_tech}, got: {probabilities}",
        )

    def test_calmed_not_si_doped_s_max_0064(self):
        grade = Grade(
            grade_id=0,
            display_name="0064_calmed_not_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0064),
                NOT_SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.006, (Ctt.NO_CORRECTION, 1)),
            (0.007, (Ctt.SYNT_SLAG, 1000)),
            (0.008, (Ctt.REBLOW, 1)),
            (0.010, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech[0]}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_calmed_si_doped_s_max_0064(self):
        grade = Grade(
            grade_id=0,
            display_name="0064_calmed_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0064),
                SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.006, (Ctt.NO_CORRECTION, 1)),
            (0.008, (Ctt.SYNT_SLAG, 1300)),
            (0.010, (Ctt.REBLOW, 1)),
            (0.012, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_calmed_not_si_doped_s_max_0124(self):
        grade = Grade(
            grade_id=0,
            display_name="0124_calmed_not_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0124),
                NOT_SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.012, (Ctt.NO_CORRECTION, 1)),
            (0.013, (Ctt.SYNT_SLAG, 1000)),
            (0.016, (Ctt.REBLOW, 1)),
            (0.017, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_calmed_si_doped_s_max_0124(self):
        grade = Grade(
            grade_id=0,
            display_name="0124_calmed_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0124),
                SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.012, (Ctt.NO_CORRECTION, 1)),
            (0.013, (Ctt.SYNT_SLAG, 800)),
            (0.016, (Ctt.REBLOW, 1)),
            (0.017, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_calmed_not_si_doped_s_max_0200(self):
        grade = Grade(
            grade_id=0,
            display_name="0200_calmed_not_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.02),
                NOT_SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.014, (Ctt.NO_CORRECTION, 1)),
            (0.019, (Ctt.SYNT_SLAG, 1800)),  # speed synt slag only
            (0.0215, (Ctt.SYNT_SLAG, 1500 + 2000)),  # speed and desulf slag
            (0.026, (Ctt.REBLOW, 1)),
            (0.028, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_calmed_si_doped_s_max_0200(self):
        grade = Grade(
            grade_id=0,
            display_name="0200_calmed_si_doped",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.02),
                SI_DOPED_LIMIT,
            ),
            is_calmed=True,
            min_synt_slag=0,
        )

        # doc. 0048, p. 71, section 408.03.01
        # doc. 0037, p. 17, section 6.11.2
        for s_real, expected_corr_tech in [
            (0.014, (Ctt.NO_CORRECTION, 1)),
            (0.019, (Ctt.SYNT_SLAG, 1800)),  # speed synt slag only
            (0.0235, (Ctt.SYNT_SLAG, 2000 + 2000)),  # speed and desulf synt slag
            (0.027, (Ctt.REBLOW, 1)),
            (0.029, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_not_calmed_s_max_0064(self):
        grade = Grade(
            grade_id=0,
            display_name="0064_not_calmed",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0064),
                ChemLimit("Si", 0, 1),
            ),
            is_calmed=False,
            min_synt_slag=0,
        )

        # doc. 0037, p. 18, section 6.11.3
        for s_real, expected_corr_tech in [
            (0.006, (Ctt.NO_CORRECTION, 1)),
            (0.007, (Ctt.REBLOW, 1)),
            (0.009, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_not_calmed_s_max_0124(self):
        grade = Grade(
            grade_id=0,
            display_name="0124_not_calmed",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.0124),
                ChemLimit("Si", 0, 1),
            ),
            is_calmed=False,
            min_synt_slag=0,
        )

        # doc. 0037, p. 18, section 6.11.3
        for s_real, expected_corr_tech in [
            (0.012, (Ctt.NO_CORRECTION, 1)),
            (0.015, (Ctt.REBLOW, 1)),
            (0.016, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)

    def test_not_calmed_s_max_0200(self):
        grade = Grade(
            grade_id=0,
            display_name="0200_not_calmed",
            limits=(
                ChemLimit("P_blow", 0, 1),
                ChemLimit("S", 0, 0.02),
                ChemLimit("Si", 0, 1),
            ),
            is_calmed=False,
            min_synt_slag=0,
        )

        # doc. 0037, p. 18, section 6.11.3
        for s_real, expected_corr_tech in [
            (0.019, (Ctt.NO_CORRECTION, 1)),
            (0.023, (Ctt.REBLOW, 1)),
            (0.025, (Ctt.RECLASSIFICATION, 1)),
        ]:
            with self.subTest(f"s_real = {s_real:.4f}, tech = {expected_corr_tech}"):
                self._execute_experiment(grade, s_real, expected_corr_tech)


if __name__ == "__main__":
    unittest.main()
