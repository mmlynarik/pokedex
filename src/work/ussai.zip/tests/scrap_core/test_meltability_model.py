import unittest
from scrap_core.meltabilitymodel.datamodel import convert_heat_to_scrap_meltability_model_input
from scrap_core.meltabilitymodel import get_meltability_model
from scrap_core.datamodel import load_heats_from_file
from . import TEST_HEATS


class TestMeltabilityModel(unittest.TestCase):
    MELTABILITY_MODEL_VERSION = 2

    def test_meltability_model_with_valid_data(self):
        heats = load_heats_from_file(str(TEST_HEATS))
        model_input = convert_heat_to_scrap_meltability_model_input(heats[0])
        model = get_meltability_model(self.MELTABILITY_MODEL_VERSION)
        output = model.calculate(model_input)
        self.assertEqual(output.easily_meltable_scrap, 8400.0)
        self.assertEqual(output.medium_meltable_scrap, 21600.0)
        self.assertEqual(output.hardly_meltable_scrap, 5200.0)
        self.assertEqual(output.easily_meltable_scrap_ratio(), 8400.0 / 35200.0)
        self.assertEqual(output.not_hardly_meltable_scrap_ratio(), 30000.0 / 35200.0)
        self.assertEqual(output.hardly_meltable_scrap_ratio(), 5200.0 / 35200.0)
