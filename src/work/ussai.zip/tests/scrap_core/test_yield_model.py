import unittest
from scrap_core.yieldmodel.datamodel import convert_heat_to_scrap_yield_model_input
from scrap_core.yieldmodel import get_yield_model
from scrap_core.datamodel import load_heats_from_file
from . import TEST_HEATS


class TestYieldModel(unittest.TestCase):
    YIELD_MODEL_VERSION = 2

    def test_yield_model_with_valid_data(self):
        heats = load_heats_from_file(str(TEST_HEATS))
        model_input = convert_heat_to_scrap_yield_model_input(heats[0])
        model = get_yield_model(self.YIELD_MODEL_VERSION)
        output = model.calculate(model_input)
        error = abs(output.final_steel_weight - heats[0].steel_weight_from_stand_without_slag)
        self.assertAlmostEqual(173463.741655, output.final_steel_weight, places=2)
        self.assertLessEqual(error, 10000.0)
