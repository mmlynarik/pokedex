import unittest
from typing import Dict

from hypothesis import given
from hypothesis.strategies import dictionaries, integers, lists, sampled_from
from immutables import Map

from scrap_core import (
    SUPPORTED_SCRAP_TYPES,
    ScrapOrder,
    ScrapType,
    reverse_vectorize,
    vectorize_scrap_weights,
    vectorize_values,
    vectorize_values_dynamic,
    vectorize_values_total,
)

TEST_SCRAP_ORDER: ScrapOrder = (
    "HSR",
    "HSR Cr",
    "HSZ",
    "HSB",
    "HDS",
    "HSK",
    "HSD",
    "HS",
    "PAS",
    "2HM",
    "1HM",
    "MCE",
    "1BC",
    "HST",
    "TBS",
    "ZBS",
    "SBS",
    "2BC",
    "1IB",
    "1DB",
    "1TB",
    "2DB",
    "1SH",
    "2SH",
    "1RR",
    "TBC",
    "1SR",
    "STS",
    "1BBC",
    "2BBC",
    "TBBC",
    "XXX",
    "HB",
    "1BS",
    "SHS",
    "DSI",
    "SRB",
    "PIG IRON",
    "1PIT",
    "BPIT",
    "2PIT",
    "TRM",
)


class TestScrapVectorization(unittest.TestCase):
    def test_vectorize_scrap_weights(self):
        data = Map(
            {
                "HSR": 1.0,
                "HSR Cr": 2.0,
                "HSZ": 3.0,
                "HSB": 4.0,
                "HDS": 5.0,
                "HSK": 6.0,
                "HSD": 7.0,
                "HS": 8.0,
                "PAS": 9.0,
                "2HM": 10.0,
                "1HM": 11.0,
                "MCE": 12.0,
                "1BC": 13.0,
                "HST": 14.0,
                "TBS": 15.0,
                "ZBS": 16.0,
                "SBS": 17.0,
                "2BC": 18.0,
                "1IB": 19.0,
                "1DB": 20.0,
                "1TB": 21.0,
                "2DB": 22.0,
                "1SH": 23.0,
                "2SH": 24.0,
                "1RR": 25.0,
                "TBC": 26.0,
                "1SR": 27.0,
                "STS": 28.0,
                "1BBC": 29.0,
                "2BBC": 30.0,
                "TBBC": 31.0,
                "XXX": 32.0,
                "HB": 33.0,
                "1BS": 34.0,
                "SHS": 35.0,
                "DSI": 36.0,
                "SRB": 37.0,
                "PIG IRON": 38.0,
                "1PIT": 39.0,
                "BPIT": 40.0,
                "2PIT": 41.0,
                "TRM": 42.0,
            }
        )

        vectorized = vectorize_scrap_weights(TEST_SCRAP_ORDER, data)
        for i, vectorized_value in enumerate(vectorized):
            self.assertEqual(vectorized_value, i + 1.0)

    def test_vectorize_scrap_weights_different_scrap_order(self):
        data = Map(
            {
                "HSZ": 1.0,
                "1HM": 2.0,
                "1SH": 3.0,
            }
        )
        vectorized = vectorize_scrap_weights(("HSZ", "1HM", "1SH"), data)
        for i, vectorized_value in enumerate(vectorized):
            self.assertEqual(vectorized_value, i + 1.0)

    def test_vectorize_scrap_weights_unknown_scrap(self):
        data = Map(
            {
                "UNKNOWN": 5.0,
                "2PIT": 41.0,
                "TRM": 42.0,
            }
        )

        self.assertRaises(ValueError, vectorize_scrap_weights, TEST_SCRAP_ORDER, data)

    def test_vectorize_scrap_weights_missing_weights(self):
        data = Map({"DSI": 50.0})
        vectorized = vectorize_scrap_weights(TEST_SCRAP_ORDER, data)
        expected_list = [0.0] * len(vectorized)
        expected_list[35] = 50.0
        self.assertListEqual(vectorized, expected_list)

    def test_vectorize_scrap_weights_no_weights(self):
        vectorized = vectorize_scrap_weights(TEST_SCRAP_ORDER, Map())
        expected_list = [0.0] * len(vectorized)
        self.assertListEqual(vectorized, expected_list)

    def test_vectorize_values(self):
        data: Dict[ScrapType, float] = {
            "HSR": 1.0,
            "HSR Cr": 2.0,
            "HSZ": 3.0,
            "HSB": 4.0,
            "HDS": 5.0,
            "HSK": 6.0,
            "HSD": 7.0,
            "HS": 8.0,
            "PAS": 9.0,
            "2HM": 10.0,
            "1HM": 11.0,
            "MCE": 12.0,
            "1BC": 13.0,
            "HST": 14.0,
            "TBS": 15.0,
            "ZBS": 16.0,
            "SBS": 17.0,
            "2BC": 18.0,
            "1IB": 19.0,
            "1DB": 20.0,
            "1TB": 21.0,
            "2DB": 22.0,
            "1SH": 23.0,
            "2SH": 24.0,
            "1RR": 25.0,
            "TBC": 26.0,
            "1SR": 27.0,
            "STS": 28.0,
            "1BBC": 29.0,
            "2BBC": 30.0,
            "TBBC": 31.0,
            "XXX": 32.0,
            "HB": 33.0,
            "1BS": 34.0,
            "SHS": 35.0,
            "DSI": 36.0,
            "SRB": 37.0,
            "PIG IRON": 38.0,
            "1PIT": 39.0,
            "BPIT": 40.0,
            "2PIT": 41.0,
            "TRM": 42.0,
        }

        vectorized = vectorize_values(TEST_SCRAP_ORDER, data, 999.0)
        for i, vectorized_value in enumerate(vectorized):
            self.assertEqual(vectorized_value, i + 1.0)

    def test_vectorize_values_missing_weights(self):
        test_scrap_order: ScrapOrder = ("DSI", "1HM", "TRM")
        vectorized = vectorize_values(test_scrap_order, {"DSI": 50.0}, 999.0)
        expected_list = [50.0, 999.0, 999.0]
        self.assertListEqual(vectorized, expected_list)

    def test_vectorize_values_no_weights(self):
        test_scrap_order: ScrapOrder = ("DSI", "1HM", "TRM")
        vectorized = vectorize_values(test_scrap_order, {}, 999.0)
        expected_list = [999.0, 999.0, 999.0]
        self.assertListEqual(vectorized, expected_list)

    def test_vectorize_values_total(self):
        data: Dict[ScrapType, float] = {
            "HSR": 1.0,
            "HSR Cr": 2.0,
            "HSZ": 3.0,
            "HSB": 4.0,
            "HDS": 5.0,
            "HSK": 6.0,
            "HSD": 7.0,
            "HS": 8.0,
            "PAS": 9.0,
            "2HM": 10.0,
            "1HM": 11.0,
            "MCE": 12.0,
            "1BC": 13.0,
            "HST": 14.0,
            "TBS": 15.0,
            "ZBS": 16.0,
            "SBS": 17.0,
            "2BC": 18.0,
            "1IB": 19.0,
            "1DB": 20.0,
            "1TB": 21.0,
            "2DB": 22.0,
            "1SH": 23.0,
            "2SH": 24.0,
            "1RR": 25.0,
            "TBC": 26.0,
            "1SR": 27.0,
            "STS": 28.0,
            "1BBC": 29.0,
            "2BBC": 30.0,
            "TBBC": 31.0,
            "XXX": 32.0,
            "HB": 33.0,
            "1BS": 34.0,
            "SHS": 35.0,
            "DSI": 36.0,
            "SRB": 37.0,
            "PIG IRON": 38.0,
            "1PIT": 39.0,
            "BPIT": 40.0,
            "2PIT": 41.0,
            "TRM": 42.0,
        }

        vectorized = vectorize_values_total(TEST_SCRAP_ORDER, data)
        for i, vectorized_value in enumerate(vectorized):
            self.assertEqual(vectorized_value, i + 1.0)

    def test_vectorize_values_total_missing_weights(self):
        self.assertRaises(KeyError, vectorize_values_total, TEST_SCRAP_ORDER, {"DSI": 50.0})

    def test_dynamic_vectorize(self):
        data = {
            "HSR": 1.0,
            "HSR Cr": 2.0,
            "HSZ": 3.0,
            "HSB": 4.0,
            "HDS": 5.0,
            "HSK": 6.0,
            "HSD": 7.0,
            "HS": 8.0,
            "PAS": 9.0,
            "2HM": 10.0,
            "1HM": 11.0,
            "MCE": 12.0,
            "1BC": 13.0,
            "HST": 14.0,
            "TBS": 15.0,
            "ZBS": 16.0,
            "SBS": 17.0,
            "2BC": 18.0,
            "1IB": 19.0,
            "1DB": 20.0,
            "1TB": 21.0,
            "2DB": 22.0,
            "1SH": 23.0,
            "2SH": 24.0,
            "1RR": 25.0,
            "TBC": 26.0,
            "1SR": 27.0,
            "STS": 28.0,
            "1BBC": 29.0,
            "2BBC": 30.0,
            "TBBC": 31.0,
            "XXX": 32.0,
            "HB": 33.0,
            "1BS": 34.0,
            "SHS": 35.0,
            "DSI": 36.0,
            "SRB": 37.0,
            "PIG IRON": 38.0,
            "1PIT": 39.0,
            "BPIT": 40.0,
            "2PIT": 41.0,
            "TRM": 42.0,
            "UNKNOWN": 100.0,
            "OTHER": 200.0,
            "BLA": 300.0,
        }

        vectorized = vectorize_values_dynamic(TEST_SCRAP_ORDER, lambda key: data.get(key, 999.0))
        for i, value in enumerate(vectorized):
            self.assertEqual(value, i + 1.0)

    def test_dynamic_vectorize_missing_weights(self):
        def value_getter(scrap_type: ScrapType):
            if scrap_type == "DSI":
                return 50.0
            return 999.0

        vectorized = vectorize_values_dynamic(TEST_SCRAP_ORDER, value_getter)
        expected_list = [999.0] * len(vectorized)
        expected_list[35] = 50.0
        self.assertListEqual(vectorized, expected_list)

    def test_dynamic_vectorize_no_weights(self):
        vectorized = vectorize_values_dynamic(TEST_SCRAP_ORDER, lambda _: 999.0)
        expected_list = [999.0] * len(vectorized)
        self.assertListEqual(vectorized, expected_list)

    def test_reverse_vectorize(self):
        data_vector = [x + 1.0 for x in range(42)]
        final_map = reverse_vectorize(TEST_SCRAP_ORDER, data_vector, 0.0)
        expected_dict = {
            "HSR": 1.0,
            "HSR Cr": 2.0,
            "HSZ": 3.0,
            "HSB": 4.0,
            "HDS": 5.0,
            "HSK": 6.0,
            "HSD": 7.0,
            "HS": 8.0,
            "PAS": 9.0,
            "2HM": 10.0,
            "1HM": 11.0,
            "MCE": 12.0,
            "1BC": 13.0,
            "HST": 14.0,
            "TBS": 15.0,
            "ZBS": 16.0,
            "SBS": 17.0,
            "2BC": 18.0,
            "1IB": 19.0,
            "1DB": 20.0,
            "1TB": 21.0,
            "2DB": 22.0,
            "1SH": 23.0,
            "2SH": 24.0,
            "1RR": 25.0,
            "TBC": 26.0,
            "1SR": 27.0,
            "STS": 28.0,
            "1BBC": 29.0,
            "2BBC": 30.0,
            "TBBC": 31.0,
            "XXX": 32.0,
            "HB": 33.0,
            "1BS": 34.0,
            "SHS": 35.0,
            "DSI": 36.0,
            "SRB": 37.0,
            "PIG IRON": 38.0,
            "1PIT": 39.0,
            "BPIT": 40.0,
            "2PIT": 41.0,
            "TRM": 42.0,
        }
        self.assertDictEqual(final_map, expected_dict)

    def test_reverse_vectorize_with_defaults(self):
        data_vector = [0.0] * 42
        data_vector[0] = 50.0
        final_map = reverse_vectorize(TEST_SCRAP_ORDER, data_vector, 0.0)
        expected_dict = {"HSR": 50.0}
        self.assertDictEqual(final_map, expected_dict)

    def test_reverse_vectorize_with_short_vector(self):
        data_vector = [0]
        self.assertRaises(ValueError, reverse_vectorize, TEST_SCRAP_ORDER, data_vector, 0.0)

    def test_reverse_vectorize_with_long_vector(self):
        data_vector = [0] * 100
        self.assertRaises(ValueError, reverse_vectorize, TEST_SCRAP_ORDER, data_vector, 0.0)

    @given(
        lists(integers(), min_size=len(SUPPORTED_SCRAP_TYPES), max_size=len(SUPPORTED_SCRAP_TYPES)),
        integers(),
    )
    def test_reverse_vectorize_inverse(self, data_vector, default_value):
        scrap_map = reverse_vectorize(SUPPORTED_SCRAP_TYPES, data_vector, default_value)
        transformed_data_vector = vectorize_values(SUPPORTED_SCRAP_TYPES, scrap_map, default_value)
        self.assertListEqual(data_vector, transformed_data_vector)

    @given(
        dictionaries(sampled_from(SUPPORTED_SCRAP_TYPES), integers(), max_size=len(SUPPORTED_SCRAP_TYPES)),
        integers(),
    )
    def test_vectorize_without_other_inverse(self, test_data, default_value):
        data_vector = vectorize_values(SUPPORTED_SCRAP_TYPES, test_data, default_value)
        expected_mapping = {k: v for k, v in test_data.items() if v != default_value}
        transformed_mapping = reverse_vectorize(SUPPORTED_SCRAP_TYPES, data_vector, default_value)
        self.assertDictEqual(expected_mapping, transformed_mapping)
