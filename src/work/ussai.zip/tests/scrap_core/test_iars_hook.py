from datetime import datetime

import unittest
import unittest.mock as mock

import pandas as pd

from scrap_core.datamodel.iars_hook import IarsHook


class TestIspvDbHook(unittest.TestCase):
    DUMMY_DB_CONF = {
        "dsn": "some_dsn",
        "username": "some_uid",
        "password": "some_pwd",
    }

    def test_get_next_planned_heats(self):
        df_zpo_table = pd.DataFrame(
            [
                [datetime(2020, 1, 1, 1), "002", 123456, 4],
                [datetime(2020, 1, 2, 1), "024", 123456, 5],
                [datetime(2020, 1, 3, 5), "808", 123456, 6],
                [datetime(2020, 1, 3, 6), "857", 123456, 7],
            ],
            columns=["p_dat", "p_akost", "hmot_tavby", "id_vyroby"],
        )

        iars_db = IarsHook(self.DUMMY_DB_CONF)

        with mock.patch("scrap_core.datamodel.iars_hook.IarsHook.url"), mock.patch(
            "scrap_core.datamodel.iars_hook.IarsHook.engine"
        ), mock.patch("pandas.read_sql", return_value=df_zpo_table):
            # parameters `steelshop` and `num_of_heats` are "dummy", as the dataframe returned
            # by `pandas.read_sql` function is mocked
            planned_heats = iars_db.get_next_planned_heats(steelshop=2, num_of_heats=4)

        # check that result is sorted with respect to `zpo_timestamp`
        self.assertListEqual(list(planned_heats), sorted(planned_heats, key=lambda x: x.zpo_timestamp))

        # check that result contains as many heats as read from db
        self.assertEqual(len(planned_heats), len(df_zpo_table))


if __name__ == "__main__":
    unittest.main()
