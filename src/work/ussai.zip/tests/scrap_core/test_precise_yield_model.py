import unittest
import math

from immutables import Map

from scrap_core import ScrapType, SUPPORTED_SCRAP_TYPES
from scrap_core.datamodel import load_heats_from_file
from scrap_core.yieldmodel.yield_model_precise import (
    YieldEstimate,
    get_scrap_usages,
    get_weighted_average_estimates,
    get_weighted_mean_std,
    get_yield_estimates,
    heat_to_precise_scrap_yield_model_input,
    train_precise_scrap_yield_model_from_heats,
)

from . import TEST_HEATS


class TestPreciseYieldModel(unittest.TestCase):
    def test_precise_yield_model_training_and_run(self):
        heats = load_heats_from_file(str(TEST_HEATS))
        model, results = train_precise_scrap_yield_model_from_heats(SUPPORTED_SCRAP_TYPES, heats)
        self.assertIsNotNone(model)
        self.assertIsNotNone(results)
        for heat in heats:
            model_input = heat_to_precise_scrap_yield_model_input(heat)
            model_output = model.calculate(model_input)
            self.assertGreaterEqual(model_output.final_steel_weight, 0.0)

    def test_get_scrap_usages(self):
        scraps_1: Map[ScrapType, float] = Map({"HS": 1000.0, "SHS": 0.0, "PAS": 2000.0})  # type: ignore
        scraps_2: Map[ScrapType, float] = Map({"HS": 2000.0, "PAS": 8000.0})  # type: ignore
        scraps_3: Map[ScrapType, float] = Map({"HS": 5000.0})  # type: ignore
        scraps_4: Map[ScrapType, float] = Map()

        scrap_usages = get_scrap_usages(("HS", "SHS", "PAS", "DSI"), [scraps_1, scraps_2, scraps_3, scraps_4])

        self.assertIsNotNone(scrap_usages)
        self.assertEqual(len(scrap_usages), 4)
        self.assertEqual(8000.0, scrap_usages[0])
        self.assertEqual(0.0, scrap_usages[1])
        self.assertEqual(10000.0, scrap_usages[2])
        self.assertEqual(0.0, scrap_usages[3])

    def test_get_weighted_average(self):
        heats = load_heats_from_file(str(TEST_HEATS))
        test_heats = [heats[0], heats[10], heats[100]]
        mean, std = get_weighted_average_estimates(test_heats, get_yield_estimates(test_heats))
        self.assertIsNotNone(mean)
        self.assertIsNotNone(std)
        self.assertAlmostEqual(mean, 0.92, 1)
        self.assertAlmostEqual(std, 48.4511, 1)

    def test_get_weighted_mean_std(self):
        estimates = [
            (YieldEstimate(yield_mean=0.75, yield_std=0.1), 1000.0),
            (YieldEstimate(yield_mean=0.5, yield_std=0.2), 2000.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 0.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 7000.0),
        ]

        mean, std = get_weighted_mean_std(estimates)
        self.assertAlmostEqual(0.595, mean, places=9)
        self.assertAlmostEqual(0.04182104733, std, places=9)

    def test_get_weighted_mean_std_zeros(self):
        estimates = [
            (YieldEstimate(yield_mean=0.75, yield_std=0.1), 0.0),
            (YieldEstimate(yield_mean=0.5, yield_std=0.2), 0.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 0.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 0.0),
        ]

        mean, std = get_weighted_mean_std(estimates)
        self.assertTrue(math.isnan(mean))
        self.assertTrue(math.isnan(std))

    def test_get_weighted_mean_std_only_one_weight(self):
        estimates = [
            (YieldEstimate(yield_mean=0.75, yield_std=0.1), 1000.0),
            (YieldEstimate(yield_mean=0.5, yield_std=0.2), 0.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 0.0),
            (YieldEstimate(yield_mean=0.6, yield_std=0.01), 0.0),
        ]

        mean, std = get_weighted_mean_std(estimates)
        self.assertAlmostEqual(0.75, mean, places=9)
        self.assertAlmostEqual(0.1, std, places=9)
