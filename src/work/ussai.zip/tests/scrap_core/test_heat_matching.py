from datetime import datetime, timedelta
from pytz import UTC
import unittest

from immutables import Map
import pandas as pd

from scrap_core.heat_matching import AppData, DbData, find_matching


APP_COLUMNS = [
    AppData.heat_key,
    AppData.scrap_weight,
    AppData.planned_grade_id,
    AppData.baskets,
    AppData.steelshop,
    AppData.closed_at,
    AppData.scrap_charge,
]


DB_COLUMNS = [
    DbData.heat_key,
    DbData.scrap_weight,
    DbData.planned_grade_id,
    DbData.baskets,
    DbData.steelshop,
    DbData.heat_datetime,
    DbData.scrap_charge,
]


class TestHeatMatching(unittest.TestCase):
    def test_already_matched_heats(self):
        """
        Check that `find_matching` function preserves already assigned heat keys.
        """
        df_app = pd.DataFrame(
            [
                [
                    (16000, 2023),
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 30, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 13, 30, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [(15000, 2023), 36000, 715, (10, 20), 1, datetime(2023, 1, 1, 14, tzinfo=UTC), {"HS": 34500}],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (16000, 2023), 1: (15000, 2023)}))

    def test_no_duplicates(self):
        """
        Check that function `find_matching` assigns heat from db at most once,
        even if more than one heat in app fulfills matching conditions.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, tzinfo=UTC), {"HS": 35000}],
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 13, 30, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [(15000, 2023), 36000, 715, (10, 20), 1, datetime(2023, 1, 1, 14, tzinfo=UTC), {"HS": 36000}],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_matched_baskets(self):
        """
        Check that baskets must match.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    35000,
                    684,
                    (11, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [
                    (15000, 2023),
                    35000,
                    246,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 14, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_matched_baskets_order(self):
        """
        Check that order of baskets is not important.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    35000,
                    684,
                    (11, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [
                    (15000, 2023),
                    35000,
                    246,
                    (20, 10),
                    1,
                    datetime(2023, 1, 1, 14, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_matched_timestamp_difference(self):
        """
        Check that difference of matched timestamps is
        in the interval specified by `time_tolerance` parameter.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    36000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 2, 1, 12, 40, tzinfo=UTC),
                    {"HS": 36000},
                ],
                [
                    (15000, 2023),
                    36000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 15, 40, tzinfo=UTC),
                    {"HS": 36000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_matched_timestamp_sequence(self):
        """
        Check that timestamp of matched db heat >= timestamp of app heat.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 11, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [
                    (15000, 2023),
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_matched_steelshop(self):
        """
        Check that steelshop must match. What about "prevozova tavba"?
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    35000,
                    684,
                    (10, 20),
                    2,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [
                    (15000, 2023),
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 35000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_similar_scrap_charge(self):
        """
        Check that scrap charge similarity is taken into account.
        """
        df_app = pd.DataFrame(
            [
                [
                    None,
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC),
                    {"HS": 20000, "HSB": 15000},
                ],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    36000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 36000},
                ],
                [
                    (15000, 2023),
                    33500,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 19000, "HSB": 14500},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (15000, 2023)}))

    def test_similar_baskets(self):
        """
        Check that mistake in basket ids is taken into account.
        """
        df_app = pd.DataFrame(
            [
                [None, 35000, 684, (10, 20), 1, datetime(2023, 1, 1, 12, 30, 20, tzinfo=UTC), {"HS": 35000}],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    35000,
                    684,
                    (10,),
                    1,
                    datetime(2023, 1, 1, 12, 50, tzinfo=UTC),
                    {"HS": 35000},
                ],
                [
                    (15000, 2023),
                    35000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 40, tzinfo=UTC),
                    {"HS": 20000, "HSB": 15000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(days=1))

        self.assertEqual(matching, Map({0: (14000, 2023)}))

    def test_general_simple_case(self):
        df_app = pd.DataFrame(
            [
                [None, 39000, 684, (50, 60), 2, datetime(2023, 1, 1, 12, 30, tzinfo=UTC), {"HS": 39000}],
                [None, 41000, 684, (30, 40), 1, datetime(2023, 1, 1, 12, 20, tzinfo=UTC), {"HS": 41000}],
                [
                    (14000, 2023),
                    41000,
                    684,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 20, tzinfo=UTC),
                    {"HS": 41000},
                ],
            ],
            columns=APP_COLUMNS,
        )

        df_db = pd.DataFrame(
            [
                [
                    (14000, 2023),
                    40000,
                    195,
                    (30, 40),
                    1,
                    datetime(2023, 1, 1, 12, 35, tzinfo=UTC),
                    {"HS": 40000},
                ],
                [
                    (15000, 2023),
                    36000,
                    22,
                    (10, 20),
                    1,
                    datetime(2023, 1, 1, 12, 50, tzinfo=UTC),
                    {"HS": 36000},
                ],
                [
                    (16000, 2023),
                    40000,
                    96,
                    (50, 60),
                    2,
                    datetime(2023, 1, 1, 14, 50, tzinfo=UTC),
                    {"HS": 40000},
                ],
                [
                    (17000, 2023),
                    40000,
                    96,
                    (60, 50),
                    2,
                    datetime(2023, 1, 1, 12, 50, tzinfo=UTC),
                    {"HS": 40000},
                ],
            ],
            columns=DB_COLUMNS,
        )

        matching = find_matching(df_app, df_db, time_tolerance=timedelta(hours=6))

        self.assertEqual(matching, Map({0: (17000, 2023), 2: (14000, 2023)}))


if __name__ == "__main__":
    unittest.main()
