import unittest
from datetime import date
from typing import Tuple

import attr
from immutables import Map

from scrap_core.optimization.datamodel import ModelSettings, MultipleHeatsOptimizationInput
from scrap_core.optimization.limitrelaxation import (
    join_relaxers,
    create_relaxable_risk_limit_relaxer,
    create_relaxable_summing_limits_relaxer,
    get_relaxers_by_schedule,
    get_relaxable_limits_relaxers,
)
from scrap_core import ScrapType, SUPPORTED_CHEMS
from scrap_core.datamodel import RawFeChem
from usskssgrades import SteelGradesHardcoded
from scrap_core.optimization.datamodel import (
    get_default_relaxable_risk_limit,
    MultipleHeatsOptimizationInput,
    ModelSettings,
    HeatInputs,
)
from scrap_core.testutils import get_default_relaxable_upper_summing_limits
from scrap_core.optimization.relaxable_limits import ACTIVE_RELAXATION_STEPS, RelaxationStep


AVAILABLE_SCRAP_TYPES: Tuple[ScrapType, ...] = ("1BC", "2PIT", "MCE", "HS", "1IB")
AVAILABLE_SCRAP_WEIGHT = 36_000
TOTAL_SCRAP_WEIGHT = 45_000
PIG_IRON_WEIGHT = 143_000
GRADE_ID = 248
GRADE_ID_2 = 597

DEFAULT_INPUT = MultipleHeatsOptimizationInput(
    model_settings=ModelSettings(),
    lower_bounds=Map({}),
    upper_bounds=Map({}),
    heats=(
        HeatInputs(
            grade_planned=SteelGradesHardcoded(SUPPORTED_CHEMS).get_grade_from_id(GRADE_ID, date.today()),
            total_scrap_weight=TOTAL_SCRAP_WEIGHT,
            pig_iron_weight=PIG_IRON_WEIGHT,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({}),
            upper_bounds=Map({}),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(GRADE_ID),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
        HeatInputs(
            grade_planned=SteelGradesHardcoded(SUPPORTED_CHEMS).get_grade_from_id(GRADE_ID_2, date.today()),
            total_scrap_weight=TOTAL_SCRAP_WEIGHT,
            pig_iron_weight=PIG_IRON_WEIGHT,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({}),
            upper_bounds=Map({}),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(GRADE_ID_2),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
    ),
)

TOTAL_STEPS = 10
SINGLE_RELAXATION_SCHEDULE = ACTIVE_RELAXATION_STEPS * [True] + (TOTAL_STEPS - ACTIVE_RELAXATION_STEPS) * [
    False
]
RELAXATION_SCHEDULE = tuple(RelaxationStep(step, step) for step in SINGLE_RELAXATION_SCHEDULE)


TEST_LOWER_BOUNDS = Map({"HS": 10000})
TEST_LOWER_BOUNDS_2 = Map({"HS": 20000})
TEST_UPPER_BOUNDS = Map({"HS": 15000})


class TestJointRelaxer(unittest.TestCase):
    def test_zero_relaxers(self):
        joint_relaxer = join_relaxers([])
        relaxed_input = joint_relaxer(DEFAULT_INPUT)
        self.assertEqual(relaxed_input, DEFAULT_INPUT)

    def test_one_relaxer(self):
        joint_relaxer = join_relaxers([lambda data: attr.evolve(data, lower_bounds=TEST_LOWER_BOUNDS)])
        relaxed_input = joint_relaxer(DEFAULT_INPUT)
        self.assertNotEqual(relaxed_input, DEFAULT_INPUT)
        self.assertEqual(relaxed_input.lower_bounds, TEST_LOWER_BOUNDS)

    def test_two_conflicting_relaxers(self):
        joint_relaxer = join_relaxers(
            [
                lambda data: attr.evolve(data, lower_bounds=TEST_LOWER_BOUNDS),
                lambda data: attr.evolve(data, lower_bounds=TEST_LOWER_BOUNDS_2),
            ]
        )
        relaxed_input = joint_relaxer(DEFAULT_INPUT)
        self.assertNotEqual(relaxed_input, DEFAULT_INPUT)
        self.assertEqual(relaxed_input.lower_bounds, TEST_LOWER_BOUNDS_2)

    def test_two_nonconflicting_relaxers(self):
        joint_relaxer = join_relaxers(
            [
                lambda data: attr.evolve(data, lower_bounds=TEST_LOWER_BOUNDS),
                lambda data: attr.evolve(data, upper_bounds=TEST_UPPER_BOUNDS),
            ]
        )
        relaxed_input = joint_relaxer(DEFAULT_INPUT)
        self.assertNotEqual(relaxed_input, DEFAULT_INPUT)
        self.assertEqual(relaxed_input.lower_bounds, TEST_LOWER_BOUNDS)
        self.assertEqual(relaxed_input.upper_bounds, TEST_UPPER_BOUNDS)


def get_relaxable_risk_limits_status(heats: Tuple[HeatInputs, ...]) -> Tuple[int, ...]:
    """Get current relaxation step for relaxable risk limit on each heat."""
    return tuple(heat.relaxable_risk_limit.step for heat in heats)


def get_relaxable_summing_limits_status(heats: Tuple[HeatInputs, ...]) -> Tuple[int, ...]:
    """Get current relaxation step for each relaxable summing limit on each heat."""
    relaxation_steps = []
    for heat in heats:
        for lim in heat.relaxable_lower_summing_limits + heat.relaxable_upper_summing_limits:
            relaxation_steps.append(lim.step)
    return tuple(relaxation_steps)


class TestRelaxableRiskLimitRelaxer(unittest.TestCase):
    def test_relaxable_risk_limit_on_each_heat_is_relaxed(self):
        default_input_status = get_relaxable_risk_limits_status(DEFAULT_INPUT.heats)
        self.assertTupleEqual(default_input_status, (0, 0))
        relaxed_input = create_relaxable_risk_limit_relaxer()(DEFAULT_INPUT)
        new_status = get_relaxable_risk_limits_status(relaxed_input.heats)
        self.assertTupleEqual(new_status, (1, 1))


class TestRelaxableSummingLimitsRelaxer(unittest.TestCase):
    def test_relaxable_summing_limits_on_each_heat_are_relaxed(self):
        default_input_status = get_relaxable_summing_limits_status(DEFAULT_INPUT.heats)
        self.assertTupleEqual(default_input_status, len(default_input_status) * (0,))
        relaxed_input = create_relaxable_summing_limits_relaxer()(DEFAULT_INPUT)
        new_status = get_relaxable_summing_limits_status(relaxed_input.heats)
        self.assertTupleEqual(new_status, len(new_status) * (1,))


class TestRelaxerSchedule(unittest.TestCase):
    def test_relaxable_risk_limit_relaxer_schedule(self):
        relaxers = get_relaxers_by_schedule(SINGLE_RELAXATION_SCHEDULE, create_relaxable_risk_limit_relaxer)
        self.assertEqual(len(relaxers), len(SINGLE_RELAXATION_SCHEDULE))

        relaxed_input, current_step = DEFAULT_INPUT, 0
        for relaxer, step in zip(relaxers, SINGLE_RELAXATION_SCHEDULE):
            relaxed_input = relaxer(relaxed_input)
            new_status = get_relaxable_risk_limits_status(relaxed_input.heats)
            current_step += step
            self.assertTupleEqual(new_status, len(new_status) * (current_step,))

    def test_relaxable_summing_limits_relaxer_schedule(self):
        relaxers = get_relaxers_by_schedule(
            SINGLE_RELAXATION_SCHEDULE, create_relaxable_summing_limits_relaxer
        )
        self.assertEqual(len(relaxers), len(SINGLE_RELAXATION_SCHEDULE))

        relaxed_input, current_step = DEFAULT_INPUT, 0
        for relaxer, step in zip(relaxers, SINGLE_RELAXATION_SCHEDULE):
            relaxed_input = relaxer(relaxed_input)
            new_status = get_relaxable_summing_limits_status(relaxed_input.heats)
            current_step = current_step + 1 if step else current_step
            self.assertTupleEqual(new_status, len(new_status) * (current_step,))

    def test_more_or_less_relaxation_steps_than_configured(self):
        less_steps = ACTIVE_RELAXATION_STEPS - 1
        more_steps = ACTIVE_RELAXATION_STEPS + 1

        self.assertRaises(
            ValueError,
            lambda: get_relaxers_by_schedule(more_steps * [True], create_relaxable_summing_limits_relaxer),
        )

        self.assertRaises(
            ValueError,
            lambda: get_relaxers_by_schedule(less_steps * [True], create_relaxable_risk_limit_relaxer),
        )


class TestRelaxableLimitsRelaxers(unittest.TestCase):
    def test_relaxable_limits_relaxers_set_final_relaxation_step(self):
        """Test that, when fully applied, relaxable limits relaxers leave limits at final relaxation step."""
        relaxers = get_relaxable_limits_relaxers(RELAXATION_SCHEDULE)
        self.assertEqual(len(relaxers), len(RELAXATION_SCHEDULE))

        relaxed_input = DEFAULT_INPUT
        for relaxer in relaxers:
            relaxed_input = relaxer(relaxed_input)

        for heat in relaxed_input.heats:
            relaxable_risk_limit = heat.relaxable_risk_limit
            self.assertEqual(relaxable_risk_limit.step, ACTIVE_RELAXATION_STEPS)
            for limit in heat.relaxable_upper_summing_limits + heat.relaxable_lower_summing_limits:
                self.assertEqual(limit.step, ACTIVE_RELAXATION_STEPS)


if __name__ == "__main__":
    unittest.main()
