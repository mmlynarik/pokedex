import unittest

from hypothesis import given
from hypothesis.strategies import integers, floats

from scrap_core.utils import heat_to_steel, steel_to_heat, scrap_to_steel, steel_to_scrap


class TestHeatConversionUtils(unittest.TestCase):
    def test_heat_to_steel(self):
        self.assertEqual(heat_to_steel(200000, 1, 1, 0.5), 200000)
        self.assertEqual(heat_to_steel(200000, 1, 0.5, 0.5), 150000)
        self.assertEqual(heat_to_steel(200000, 0.5, 1, 0.5), 150000)
        self.assertEqual(heat_to_steel(200000, 0.5, 0.5, 0.5), 100000)

    @given(integers(150000, 250000), floats(0.01, 1), floats(0.01, 1), floats(0.01, 1))
    def test_steel_to_heat(self, heat_w, pig_iron_y, scrap_y, scrap_r):
        """Test that `steel_to_heat` and `heat_to_steel` are inverse to each other"""
        self.assertAlmostEqual(
            steel_to_heat(heat_to_steel(heat_w, pig_iron_y, scrap_y, scrap_r), pig_iron_y, scrap_y, scrap_r),
            heat_w,
            places=2,
        )

    def test_scrap_to_steel(self):
        self.assertEqual(scrap_to_steel(40000, 1, 1, 0.5), 80000)
        self.assertEqual(scrap_to_steel(40000, 1, 0.5, 0.5), 60000)
        self.assertEqual(scrap_to_steel(40000, 0.5, 1, 0.5), 60000)
        self.assertEqual(scrap_to_steel(40000, 0.5, 0.5, 0.5), 40000)

    @given(integers(100000, 200000), floats(0.01, 1), floats(0.01, 1), floats(0.01, 1))
    def test_steel_to_scrap(self, steel_w, pig_iron_y, scrap_y, scrap_r):
        """Test that `steel_to_scrap` and `scrap_to_steel` are inverse to each other"""
        self.assertAlmostEqual(
            scrap_to_steel(
                steel_to_scrap(steel_w, pig_iron_y, scrap_y, scrap_r), pig_iron_y, scrap_y, scrap_r
            ),
            steel_w,
            places=2,
        )


if __name__ == "__main__":
    unittest.main()
