from pathlib import Path
from typing import Tuple

from scrap_core import ScrapMix, ScrapMixOrder, ScrapOrder, ScrapMixMapping
from scrap_core.optimization.datamodel import MultipleHeatsOptimizationOutput
from scrap_core.optimization.linprog_optimizer import get_affected_scrap_mixes


HEAT_52233_2020_CORRECT_DATA = Path(__file__).parent / "test_data/heat_52233_2020_correct_data.csv"
HEAT_47166_2019_INCORRECT_DATA = Path(__file__).parent / "test_data/heat_47166_2019_incorrect_data.csv"
TEST_HEATS = Path(__file__).parent / "test_data/heatdata.jsonl"
HEAT_46599_2021_CORRECT_DATA = Path(__file__).parent / "test_data/heat_46599_2021_correct_data.csv"
HEAT_57039_2021_CORRECT_DATA = Path(__file__).parent / "test_data/heat_57039_2021_correct_data.csv"
# kod srotu is changed to invalid values
ARTIFICIAL_HEAT_INVALID_SCRAP_TYPES = (
    Path(__file__).parent / "test_data/artificial_heat_invalid_scrap_code.csv"
)


def get_uniform_binning(low: float, upp: float, step: float) -> Tuple[float, ...]:
    binning = [low]
    while low + step <= upp:
        binning.append(low + step)
        low += step
    return tuple(binning)


def get_scrap_weights_sum_from_opt_result(
    opt_result: MultipleHeatsOptimizationOutput,
    heat_order: int,
    mix_mapping: ScrapMixMapping,
    limit_scrap_types: ScrapOrder,
):
    scrap_mixes = tuple(opt_result.scrap_weights_per_heat[heat_order].keys())
    affected_scrap_mixes = get_affected_scrap_mixes(scrap_mixes, mix_mapping, limit_scrap_types)
    return sum(
        opt_result.scrap_weights_per_heat[heat_order].get(scrap_mix, 0.0)
        for scrap_mix in affected_scrap_mixes
    )
