import unittest

import torch
from immutables import Map

from scrap_core import vectorize_scrap_weights, ScrapMix, ScrapMixMapping
from scrap_core.blendmodel import (
    ScrapBlendModel,
    ScrapBlendModelInput,
    get_blend_model,
    get_worst_case_scrap_mix_resolver,
    resolve_scrap_mix_as_worst_case,
)
from scrap_core.datamodel import RawFeChem


class TestScrapBlendModelV2(unittest.TestCase):
    model: ScrapBlendModel

    @classmethod
    def setUpClass(cls) -> None:
        cls.model = get_blend_model(2)

    def test_calculate_smoke_test(self):
        input_data = ScrapBlendModelInput(
            155600.0,
            RawFeChem(S=0.040),
            Map({"DSI": 20000.0}),
            0.0,
            0.0,
        )
        output = self.model.calculate(input_data)
        self.assertIsNotNone(output)

    def test_calculate_batch_smoke_test(self):
        input_data = ScrapBlendModelInput(
            155600.0,
            RawFeChem(),
            Map({"STS": 20000.0, "1IB": 20000.0}),
            1000.0,
            2000.0,
        )
        outputs = self.model.calculate_batch([input_data, input_data, input_data])
        self.assertEqual(len(outputs), 3)
        for output in outputs:
            self.assertIsNotNone(output)

    # pylint: disable=no-member
    def test_calculate_batch_fast_vs_classic(self):
        pig_iron_chem = RawFeChem()
        pig_iron_w = 155600
        pellets_w = 1000
        briquettes_w = 2000
        scrap_map = Map({"PIG IRON": 18000.0, "1BS": 15000.0, "HS": 3000.0})

        input_data = ScrapBlendModelInput(
            pig_iron_w,
            pig_iron_chem,
            scrap_map,
            pellets_w,
            briquettes_w,
        )
        classic_outputs = self.model.calculate_batch([input_data, input_data, input_data])

        scrap_matrix = torch.Tensor(
            [vectorize_scrap_weights(self.model.scrap_order, scrap_map) for _ in range(3)]
        )

        fast_output = self.model.calculate_batch_fast(
            pig_iron_chem, pig_iron_w, pellets_w, briquettes_w, scrap_matrix
        )

        classic_output_converted = {
            chem: torch.stack(
                [torch.Tensor(co.get_chem_estimate(chem).probas) for co in classic_outputs]  # type: ignore
            )
            for chem in self.model.SUPPORTED_CHEMS
        }

        for key in set(fast_output.keys()) | set(classic_output_converted.keys()):
            self.assertTrue(torch.equal(classic_output_converted[key], fast_output[key]))

    def test_calculate_with_scrap_mixtures(self):
        input_data = ScrapBlendModelInput(
            155600.0,
            RawFeChem(S=0.040),
            Map({ScrapMix("DSI"): 20000.0, ScrapMix("H1"): 20000.0}),
            0.0,
            0.0,
            Map({"H1": Map({"HS": 0.5, "PAS": 0.5})}),  # type: ignore
        )
        output = self.model.calculate(input_data)
        self.assertIsNotNone(output)


# TODO move to test_scrap_mix_resolvers.py module
class TestBlendModelMixtureResolving(unittest.TestCase):
    scrap_mix_mapping: ScrapMixMapping = Map(
        {
            ScrapMix("H1"): Map({"HS": 0.3, "PAS": 0.3, "MCE": 0.4}),
            ScrapMix("H2"): Map({"HS": 0.5, "MCE": 0.5}),
            ScrapMix("H3"): Map({"HS": 0.5, "PAS": 0.5}),
            ScrapMix("H4"): Map({"PAS": 0.5, "MCE": 0.5}),
        }
    )

    def test_resolve_mixture(self):
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("HS", "PAS", "MCE", "DSI")
            ),
            "HS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("DSI", "PAS", "MCE", "HS")
            ),
            "PAS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("MCE", "PAS", "HS", "DSI")
            ),
            "MCE",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("HS", "PAS", "MCE", "DSI")
            ),
            "HS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("DSI", "PAS", "MCE", "HS")
            ),
            "PAS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("MCE", "PAS", "HS", "DSI")
            ),
            "MCE",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("HS", "PAS", "MCE", "DSI")
            ),
            "HS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("DSI", "PAS", "MCE", "HS")
            ),
            "PAS",
        )
        self.assertEqual(
            resolve_scrap_mix_as_worst_case(
                ScrapMix("H1"), self.scrap_mix_mapping, ("MCE", "PAS", "HS", "DSI")
            ),
            "MCE",
        )

    def test_resolve_mixture_missing_scrap_type(self):
        self.assertRaises(
            ValueError,
            lambda: resolve_scrap_mix_as_worst_case("H1", self.scrap_mix_mapping, ("PAS", "MCE", "DSI")),
        )

    def test_mixture_resolver(self):
        resolver = get_worst_case_scrap_mix_resolver(("HS", "PAS", "MCE"))
        resolved = resolver(Map({"H2": 10000.0}), self.scrap_mix_mapping)  # type: ignore
        self.assertEqual(resolved, Map({"HS": 10000.0}))

    def test_mixture_resolver_multiple_mixtures(self):
        resolver = get_worst_case_scrap_mix_resolver(("HS", "PAS", "MCE"))
        resolved = resolver(Map({"H2": 10000.0, "H3": 5000.0}), self.scrap_mix_mapping)  # type: ignore
        self.assertEqual(resolved, Map({"HS": 15000.0}))

    def test_mixture_resolver_multiple_outputs(self):
        resolver = get_worst_case_scrap_mix_resolver(("HS", "PAS", "MCE"))
        resolved = resolver(Map({"H2": 10000.0, "H4": 5000.0}), self.scrap_mix_mapping)  # type: ignore
        self.assertEqual(resolved, Map({"HS": 10000.0, "PAS": 5000.0}))


if __name__ == "__main__":
    unittest.main()
