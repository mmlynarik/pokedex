import unittest

from immutables import Map

from scrap_core.blendmodel import get_proportional_scrap_mix_resolver


class TestProportionalResolving(unittest.TestCase):
    def test_simple_scrap_types_only(self):
        charge = {"HS": 15000, "1IB": 15000, "PAS": 5000}
        scrap_mix_mapping = {}
        expected_result = Map(charge)

        resolver = get_proportional_scrap_mix_resolver(1000)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)

    def test_single_scrap_mix(self):
        charge = {"HOME": 40000}
        scrap_mix_mapping = {"HOME": {"HS": 0.6, "HSB": 0.1, "HDS": 0.3}}
        expected_result = Map({"HS": 24000, "HSB": 4000, "HDS": 12000})

        resolver = get_proportional_scrap_mix_resolver(1000)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)

    def test_overlapping_scrap_mixes(self):
        charge = {"HOME": 20000, "QUALITY": 20000}
        scrap_mix_mapping = {"HOME": {"HS": 0.6, "HSB": 0.1, "HDS": 0.3}, "QUALITY": {"1IB": 0.5, "HS": 0.5}}
        expected_result = Map({"1IB": 10000, "HS": 22000, "HSB": 2000, "HDS": 6000})

        resolver = get_proportional_scrap_mix_resolver(1000)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)

    def test_general_case(self):
        charge = {"HOME": 20000, "QUALITY": 20000, "PAS": 3000}
        scrap_mix_mapping = {"HOME": {"HS": 0.6, "HSB": 0.1, "HDS": 0.3}, "QUALITY": {"1IB": 0.5, "HS": 0.5}}
        expected_result = Map({"1IB": 10000, "HS": 22000, "HSB": 2000, "HDS": 6000, "PAS": 3000})

        resolver = get_proportional_scrap_mix_resolver(1000)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)

    def test_undefined_scrap_mix(self):
        charge = {"HOME": 40000}
        scrap_mix_mapping = {}

        resolver = get_proportional_scrap_mix_resolver(1000)

        with self.assertRaises(ValueError):
            __ = resolver(charge, scrap_mix_mapping)

    def test_precision(self):
        charge = {"HOME": 40000}
        scrap_mix_mapping = {"HOME": {"HS": 0.667, "HSB": 0.333}}
        expected_result = Map({"HS": 26500, "HSB": 13500})

        resolver = get_proportional_scrap_mix_resolver(500)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)

    def test_rounding(self):
        charge = {"HOME": 10000}
        scrap_mix_mapping = {"HOME": {"HS": 0.33333, "HSB": 0.33333, "HSZ": 0.33334}}
        expected_result = Map({"HS": 3350, "HSB": 3300, "HSZ": 3350})

        resolver = get_proportional_scrap_mix_resolver(50)

        self.assertEqual(resolver(charge, scrap_mix_mapping), expected_result)


if __name__ == "__main__":
    unittest.main()
