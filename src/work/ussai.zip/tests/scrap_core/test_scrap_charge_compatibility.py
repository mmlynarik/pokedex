from datetime import date
from unittest import TestCase

from immutables import Map
from usskssgrades.steel_grades_hardcoded import SteelGradesHardcoded

from scrap_core import SUPPORTED_CHEMS
from scrap_core.compatible_grades import (
    check_scrap_charge_grade_compatibility,
    is_scrap_charge_compatible_with_summing_limits,
)
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.datamodel import ModelSettings
from scrap_core.optimization.relaxable_limits import (
    RelaxableLowerSummingLimit,
    RelaxableUpperSummingLimit,
    RelaxableValue,
)

grades = SteelGradesHardcoded(SUPPORTED_CHEMS)


class TestScrapChargeGradeCompatibility(TestCase):
    LOWER_SUMMING_LIMITS = (
        RelaxableLowerSummingLimit(
            name="Test",
            scrap_types=("SHS", "HSB"),
            weight_limit=RelaxableValue(aim=20000, allowed=10000),
            ratio=RelaxableValue(aim=0, allowed=0),
        ).get_last_relaxation_step(),
        RelaxableLowerSummingLimit(
            name="Test1",
            scrap_types=("SHS",),
            weight_limit=RelaxableValue(aim=15000, allowed=9000),
            ratio=RelaxableValue(aim=0, allowed=0),
        ).get_last_relaxation_step(),
    )
    UPPER_SUMMING_LIMITS = (
        RelaxableUpperSummingLimit(
            name="Test2",
            scrap_types=("HSA", "HS"),
            weight_limit=RelaxableValue(aim=10000, allowed=20000),
            ratio=RelaxableValue(aim=1, allowed=1),
        ).get_last_relaxation_step(),
        RelaxableUpperSummingLimit(
            name="Test3",
            scrap_types=("HSA",),
            weight_limit=RelaxableValue(aim=10000, allowed=15000),
            ratio=RelaxableValue(aim=1, allowed=1),
        ).get_last_relaxation_step(),
    )

    def test_risk_lower_than_expected(self):
        model_settings = ModelSettings()
        scrap_charge = Map({"MCE": 7500.0, "1TB": 2500.0, "1PIT": 11300.0, "HS": 2500.0, "1SH": 11500.0})
        pig_iron_chem = RawFeChem(Cr=0.008, Cu=0.005, Mo=0.003, Ni=0.005, S=0.002, Sn=0.002, Si=0.673)
        grade = grades.get_grade_from_id(575, date.today())
        self.assertTrue(
            check_scrap_charge_grade_compatibility(
                scrap_charge=scrap_charge,  # type: ignore
                pig_iron_weight=153700.0,
                pig_iron_chem=pig_iron_chem,
                steel_grade=grade,
                model_settings=model_settings,
                risk_limits=Map(
                    {"Cr": 0.01, "Cu": 0.01, "Mo": 0.01, "Ni": 0.01, "S": 0.5, "Sn": 0.1, "Si": 0.01}  # type: ignore
                ),
            )
        )

    def test_risk_higher_than_expected(self):
        model_settings = ModelSettings()
        scrap_charge = Map({"MCE": 7500.0, "1TB": 2500.0, "1PIT": 11300.0, "HS": 2500.0, "1SH": 11500.0})  # type: ignore
        pig_iron_chem = RawFeChem(Cr=0.008, Cu=0.005, Mo=0.003, Ni=0.005, S=0.002, Sn=0.002, Si=0.673)
        grade = grades.get_grade_from_id(575, date.today())
        self.assertFalse(
            check_scrap_charge_grade_compatibility(
                scrap_charge=scrap_charge,  # type: ignore
                pig_iron_weight=153700.0,
                pig_iron_chem=pig_iron_chem,
                steel_grade=grade,
                model_settings=model_settings,
                risk_limits=Map(
                    {
                        "Cr": 0.001,
                        "Cu": 0.003,
                        "Mo": 0.005,
                        "Ni": 0.001,
                        "S": 0.12,
                        "Sn": 0.01,
                        "Si": 0.01,
                    }  # type: ignore
                ),
            )
        )

    def test_summing_limits_with_compatible_scrap_charge(self):
        scrap_charge = Map(  # type: ignore
            {"HSA": 15000.0, "1SH": 7000.0, "HST": 4100.0, "SHS": 9000.0, "HS": 1000.0, "HSB": 2500.0}
        )
        self.assertTrue(
            is_scrap_charge_compatible_with_summing_limits(
                scrap_charge,  # type: ignore
                self.LOWER_SUMMING_LIMITS,
                Map(),
            )
        )
        self.assertTrue(
            is_scrap_charge_compatible_with_summing_limits(
                scrap_charge,  # type: ignore
                self.UPPER_SUMMING_LIMITS,
                Map(),
            )
        )

    def test_summing_limits_with_incompatible_scrap_charge(self):
        scrap_charge = Map(  # type: ignore
            {"HSA": 14000.0, "1SH": 7000.0, "HST": 4100.0, "SHS": 9000.0, "HS": 10000.0, "HSB": 500.0}
        )
        self.assertFalse(
            is_scrap_charge_compatible_with_summing_limits(
                scrap_charge,  # type: ignore
                self.LOWER_SUMMING_LIMITS,
                Map(),
            )
        )
        self.assertFalse(
            is_scrap_charge_compatible_with_summing_limits(
                scrap_charge,  # type: ignore
                self.UPPER_SUMMING_LIMITS,
                Map(),
            )
        )
