from typing import Tuple
import unittest
from scrap_core import ScrapMix
from scrap_core.optimization.datamodel import AvailableScrap, ScrapMixLimit
from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit, RelaxableValue
from scrap_core.optimization.validations import NO_VALIDATION_PROBLEMS, validate_scrap_limits


class TestValidations(unittest.TestCase):
    available_scrap: Tuple[AvailableScrap, ...] = (
        AvailableScrap(scrap_type=ScrapMix("HS"), weight=100000),
        AvailableScrap(scrap_type=ScrapMix("HSD"), weight=100000),
        AvailableScrap(scrap_type=ScrapMix("1PIT"), weight=100000),
    )

    total_scrap_weight: int = 40000

    grade_id: int = 99

    relaxable_upper_summing_limits: Tuple[RelaxableUpperSummingLimit, ...] = (
        RelaxableUpperSummingLimit(
            name="meltability_easy",
            scrap_types=("HS",),
            weight_limit=RelaxableValue(100_000, 100_000),
            ratio=RelaxableValue(1, 1),
        ),  # test names and priority ( fake )
        RelaxableUpperSummingLimit(
            name="meltability_hard",
            scrap_types=("1PIT", "HSD"),
            weight_limit=RelaxableValue(20000, 20000),
            ratio=RelaxableValue(1, 1),
        ),
    )

    def test_valid_inputs(self):
        user_defined_valid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), minimum=1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT"), minimum=0, maximum=2000),
            ScrapMixLimit(scrap_type=ScrapMix("HSD"), maximum=23000),
        )
        self.assertEqual(
            validate_scrap_limits(
                user_defined_valid_limits,
                self.total_scrap_weight,
                self.available_scrap,
                (),
                self.relaxable_upper_summing_limits,
                self.grade_id,
            ),
            NO_VALIDATION_PROBLEMS,
        )

    def test_lower_limit_greater_than_upper_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), minimum=2000, maximum=1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = "Pre typ šrotu HS je minimálne 2 množstvo väčšie ako maximálne 1"

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_negative_minimal_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), minimum=-1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = "Pre typ šrotu HS je hodnota minima -1.0 menšia ako 0"

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_negative_maximal_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), maximum=-1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = "Pre typ šrotu HS je hodnota maxima -1.0 menšia ako 0"

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_sum_of_maximum_values_lower_than_total_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), maximum=1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT"), maximum=1000),
            ScrapMixLimit(scrap_type=ScrapMix("HSD"), maximum=1000),
        )
        expected_error_msg: str = "Suma maxím pre šroty je menšia ako objednaná hmotnosť šrotu"

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_sum_of_minimum_values_greater_than_total_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), minimum=999000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = "Suma miním pre šroty je vačšia ako objednaná hmotnosť šrotu"

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_not_enough_available_scrap_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), minimum=1000000000000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = "Pre naloženie 1000000000.0t HS nemáte dostatok šrotu."

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            grade_id=self.grade_id,
        )

        self.assertTrue(expected_error_msg in errors)

    def test_not_enough_scrap_in_lower_summing_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS")),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT"), minimum=11000),
            ScrapMixLimit(scrap_type=ScrapMix("HSD"), minimum=11000),
        )
        expected_warning_msg: str = (
            "Suma minimálnych limitov pre šroty ('1PIT', 'HSD') je väčšia ako povolené maximum 20.0 t."
        )

        _, warnings = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=self.relaxable_upper_summing_limits,
            grade_id=self.grade_id,
        )

        self.assertTrue(any(expected_warning_msg in warning for warning in warnings))

    def test_not_enough_scrap_in_upper_summing_limit(self):
        user_defined_invalid_limits: Tuple[ScrapMixLimit, ...] = (
            ScrapMixLimit(scrap_type=ScrapMix("HS"), maximum=1000),
            ScrapMixLimit(scrap_type=ScrapMix("1PIT")),
            ScrapMixLimit(scrap_type=ScrapMix("HSD")),
        )
        expected_error_msg: str = (
            "Potrebná hmotnosť šrotu HS >= 20.0 je vyššia než dovoľujú nastavené horné ohraničenia pre tieto typy šrotu: 1.0."
        )

        errors, _ = validate_scrap_limits(
            scrap_limits=user_defined_invalid_limits,
            total_scrap_weight=self.total_scrap_weight,
            available_scraps=self.available_scrap,
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=self.relaxable_upper_summing_limits,
            grade_id=self.grade_id,
        )

        self.assertTrue(any(expected_error_msg in error for error in errors))
