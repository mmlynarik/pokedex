from datetime import date
from typing import Mapping
import unittest

import attr

from scrap_core import Chem, ScrapBounds, ScrapCharge, ScrapMix, ScrapType, SUPPORTED_CHEMS
from scrap_core.correctiontechnologiesmodel.corr_tech_model import CorrectionTechnologiesModelSettings
from usskssgrades import SteelGradesHardcoded
from immutables import Map
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.relaxable_limits import (
    RelaxableRiskLimit,
    RelaxableValue,
    ACTIVE_RELAXATION_STEPS,
)
from scrap_core.optimization.datamodel import (
    ChemRiskLevels,
    HeatInputs,
    ModelSettings,
    get_default_relaxable_risk_limit,
)
from scrap_core.optimization.expected_risk import (
    get_ct_risk_limits,
    get_expected_risk_levels,
    select_chems_by_risk,
)

GRADES = SteelGradesHardcoded(SUPPORTED_CHEMS)
GRADE_494 = GRADES.get_grade_from_id(494, date.today())
GRADE_684 = GRADES.get_grade_from_id(684, date.today())
GRADE_002 = GRADES.get_grade_from_id(2, date.today())
MODEL_SETTINGS = ModelSettings(
    correction_technologies_settings=CorrectionTechnologiesModelSettings(
        chems_for_correction_technologies=("Cr", "Cu", "Mo", "Ni", "S", "Sn")  # type: ignore
    )
)
TOTAL_SCRAP_WEIGHT = 30000
PIG_IRON_WEIGHT = 160000
PIG_IRON_CHEM = RawFeChem(S=0.002, Cu=0.005, Ni=0.005, Cr=0.010, Mo=0.003, Sn=0.002, Si=0.562)
LOWER_BOUNDS: ScrapBounds = Map({})
UPPER_BOUNDS: ScrapBounds = Map({})

HEAT_GRADE_684 = HeatInputs(
    grade_planned=GRADE_684,
    total_scrap_weight=TOTAL_SCRAP_WEIGHT,
    pig_iron_weight=PIG_IRON_WEIGHT,
    pig_iron_chem=PIG_IRON_CHEM,
    lower_bounds=LOWER_BOUNDS,
    upper_bounds=UPPER_BOUNDS,
    relaxable_risk_limit=get_default_relaxable_risk_limit(),
    relaxable_upper_summing_limits=(),
    relaxable_lower_summing_limits=(),
)

HEAT_GRADE_494 = HeatInputs(
    grade_planned=GRADE_494,
    total_scrap_weight=TOTAL_SCRAP_WEIGHT,
    pig_iron_weight=PIG_IRON_WEIGHT,
    pig_iron_chem=PIG_IRON_CHEM,
    lower_bounds=LOWER_BOUNDS,
    upper_bounds=UPPER_BOUNDS,
    relaxable_risk_limit=get_default_relaxable_risk_limit(),
    relaxable_upper_summing_limits=(),
    relaxable_lower_summing_limits=(),
)

HEAT_GRADE_002 = HeatInputs(
    grade_planned=GRADE_002,
    total_scrap_weight=TOTAL_SCRAP_WEIGHT,
    pig_iron_weight=PIG_IRON_WEIGHT,
    pig_iron_chem=PIG_IRON_CHEM,
    lower_bounds=LOWER_BOUNDS,
    upper_bounds=UPPER_BOUNDS,
    relaxable_risk_limit=get_default_relaxable_risk_limit(),
    relaxable_upper_summing_limits=(),
    relaxable_lower_summing_limits=(),
)


class TestExpectedRiskLevels(unittest.TestCase):
    def test_high_risk(self):
        scrap: Mapping[ScrapMix, float] = {ScrapMix("HST"): 6000.0, ScrapMix("HS"): 24000.0}
        scrap_charge: ScrapCharge = Map(scrap)
        self.assertEqual(
            get_expected_risk_levels(scrap_charge, HEAT_GRADE_494, MODEL_SETTINGS).high, ("Mo", "S", "Sn")
        )

    def test_high_risk_input_with_custom_settings(self):
        scrap: Mapping[ScrapMix, float] = {ScrapMix("HST"): 6000.0, ScrapMix("HS"): 24000.0}
        scrap_charge: ScrapCharge = Map(scrap)
        RelaxableRiskLimit.n_steps = 2
        custom_relaxable_risk_limit = RelaxableRiskLimit(
            name="custom",
            Cr=RelaxableValue(0.01, 0.02),
            Cu=RelaxableValue(0.01, 0.02),
            Mo=RelaxableValue(0.001, 0.99),
            Ni=RelaxableValue(0.01, 0.02),
            S=RelaxableValue(0.001, 0.99),
            Sn=RelaxableValue(0.001, 0.99),
            Si=RelaxableValue(0.01, 0.02),
        )
        RelaxableRiskLimit.n_steps = ACTIVE_RELAXATION_STEPS
        custom_heat = attr.evolve(HEAT_GRADE_494, relaxable_risk_limit=custom_relaxable_risk_limit)
        self.assertEqual(
            get_expected_risk_levels(
                scrap_charge,
                custom_heat,
                MODEL_SETTINGS,
            ).medium,
            ("Mo", "S", "Sn"),
        )

    def test_medium_risk(self):
        scrap: Mapping[ScrapMix, float] = {
            ScrapMix("1SH"): 12000.0,
            ScrapMix("HS"): 11000.0,
            ScrapMix("SHS"): 7000.0,
        }
        scrap_charge: ScrapCharge = Map(scrap)
        heat_inputs = HEAT_GRADE_684
        risks = get_expected_risk_levels(scrap_charge, heat_inputs, MODEL_SETTINGS)
        self.assertEqual(risks.high, ())
        self.assertEqual(risks.medium, ("S",))

    def test_low_risk(self):
        scrap: Mapping[ScrapMix, float] = {ScrapMix("HS"): 30000.0}
        scrap_charge: ScrapCharge = Map(scrap)
        heat_inputs = HEAT_GRADE_684
        self.assertEqual(
            get_expected_risk_levels(scrap_charge, heat_inputs, MODEL_SETTINGS), ChemRiskLevels((), ())
        )

    def test_ct_thresholds_for_specific_grade(self):
        self.assertEqual(
            get_ct_risk_limits(settings=MODEL_SETTINGS, limit=HEAT_GRADE_684.relaxable_risk_limit),
            (
                Map({"Mo": 0.01, "Sn": 0.01, "S": 0.15, "Cr": 0.01, "Ni": 0.01, "Cu": 0.01}),
                Map({"Mo": 0.02, "Sn": 0.02, "S": 0.291, "Cr": 0.02, "Ni": 0.02, "Cu": 0.02}),
            ),
        )

    def test_chems_selections_without_warning(self):
        expected_ct_risk: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.001,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.001,
            "Sn": 0.001,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk),
            ),
            ((), ()),
        )

    def test_chems_selections_with_one_medium_warning(self):
        expected_ct_risk: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.001,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.001,
            "Sn": 0.01,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk),
            ),
            (("Sn",), ()),
        )

    def test_chems_selections_with_multiple_medium_warnings(self):
        expected_ct_risk_684: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.01,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.16,
            "Sn": 0.015,
        }
        expected_ct_risk_494: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.01,
            "Mo": 0.001,
            "Ni": 0.015,
            "S": 0.16,
            "Sn": 0.015,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk_684),
            ),
            (
                (
                    "S",
                    "Sn",
                ),
                (),
            ),
        )

        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_494,
                expected_ct_risks=Map(expected_ct_risk_494),
            ),
            (
                (
                    "Cu",
                    "Ni",
                    "S",
                    "Sn",
                ),
                (),
            ),
        )

    def test_chems_selections_with_one_high_warning(self):
        expected_ct_risk: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.01,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.56,
            "Sn": 0.001,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk),
            ),
            ((), ("S",)),
        )

    def test_chems_selections_with_multiple_high_warnings(self):
        expected_ct_risk: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.01,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.56,
            "Sn": 0.3,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk),
            ),
            ((), ("S", "Sn")),
        )

    def test_chems_selections_with_medium_and_high_warnings(self):
        expected_ct_risk_684: Mapping[Chem, float] = {
            "Cr": 0.001,
            "Cu": 0.01,
            "Mo": 0.001,
            "Ni": 0.001,
            "S": 0.56,
            "Sn": 0.015,
        }
        expected_ct_risk_494: Mapping[Chem, float] = {
            "Cr": 0.015,
            "Cu": 0.015,
            "Mo": 0.5,
            "Ni": 0.001,
            "S": 0.56,
            "Sn": 0.015,
        }
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=Map(expected_ct_risk_684),
            ),
            (("Sn",), ("S",)),
        )

        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_494,
                expected_ct_risks=Map(expected_ct_risk_494),
            ),
            (
                (
                    "Cr",
                    "Cu",
                    "Sn",
                ),
                (
                    "Mo",
                    "S",
                ),
            ),
        )

    def test_chems_selections_with_ignored_chems(self):
        expected_ct_risk_retype: Mapping[Chem, float] = {
            "Cr": 0.05,
            "Cu": 0.5,
            "Mo": 0.5,
            "Ni": 0.5,
            "S": 0.1,
            "Sn": 0.001,
        }
        expected_ct_risks: Map[Chem, float] = Map(expected_ct_risk_retype)
        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_684,
                expected_ct_risks=expected_ct_risks,
            ),
            ((), ()),
        )

        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_494,
                expected_ct_risks=expected_ct_risks,
            ),
            ((), ("Cr", "Cu", "Mo", "Ni")),
        )

        self.assertEqual(
            select_chems_by_risk(
                settings=MODEL_SETTINGS,
                heat=HEAT_GRADE_002,
                expected_ct_risks=expected_ct_risks,
            ),
            ((), ("Cr", "Cu", "Mo")),
        )

    def test_grade_specific_ignored_chems(self):
        self.assertEqual(MODEL_SETTINGS.get_ignored_chems(GRADE_002), ("Ni",))
        self.assertEqual(MODEL_SETTINGS.get_ignored_chems(GRADE_494), ())
        self.assertEqual(MODEL_SETTINGS.get_ignored_chems(GRADE_684), ("Cr", "Cu", "Mo", "Ni"))


if __name__ == "__main__":
    unittest.main()
