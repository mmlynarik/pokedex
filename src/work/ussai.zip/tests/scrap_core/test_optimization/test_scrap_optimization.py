import unittest
from datetime import date
from typing import Dict

from immutables import Map
from scrap_core import ScrapMix, ScrapOrder, ScrapMixMapping, SUPPORTED_CHEMS
from scrap_core.blendmodel import ScrapBlendModelInput, get_blend_model
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    CorrectionTechnologiesModelSettings,
    get_corr_tech_model,
)
from scrap_core.datamodel import RawFeChem, load_heats_from_file
from usskssgrades import SteelGradesHardcoded
from scrap_core.optimization.datamodel import (
    HeatInputs,
    ModelSettings,
    MultipleHeatsOptimizationInput,
    OptimizerSettings,
    ChemRiskLevels,
    ScrapExclusiveGroup,
    MultipleHeatsOptimizationOutput,
    get_default_relaxable_risk_limit,
)
from scrap_core.testutils import get_default_relaxable_upper_summing_limits
from scrap_core.optimization.relaxable_limits import RelaxableRiskLimit, RelaxableValue
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats

from .. import TEST_HEATS

steel_grades = SteelGradesHardcoded(SUPPORTED_CHEMS)

GRADE_202 = steel_grades.get_grade_from_id(202, date.today())
GRADE_2 = steel_grades.get_grade_from_id(2, date.today())
GRADE_303 = steel_grades.get_grade_from_id(303, date.today())
GRADE_515 = steel_grades.get_grade_from_id(515, date.today())
GRADE_684 = steel_grades.get_grade_from_id(684, date.today())

HS = ScrapMix("HS")
PAS = ScrapMix("PAS")
MCE = ScrapMix("MCE")
DSI = ScrapMix("DSI")
PIT1 = ScrapMix("1PIT")
PIT2 = ScrapMix("2PIT")
HEAP1 = ScrapMix("HEAP1")
HEAP2 = ScrapMix("HEAP2")

HEAP1_SCRAPS: ScrapOrder = ("HS", "PAS")
HEAP2_SCRAPS: ScrapOrder = ("MCE", "1PIT", "2PIT")
RATIOS = (0.3, 0.4, 0.3)
MIX_MAPPING: ScrapMixMapping = Map(
    {HEAP1: Map(zip(HEAP1_SCRAPS, RATIOS[:-1])), HEAP2: Map(zip(HEAP2_SCRAPS, RATIOS))}
)


class TestCompositeScrapMixes(unittest.TestCase):
    available_scrap: Dict[ScrapMix, float] = {HEAP1: 100000, HEAP2: 100000, HS: 100000, DSI: 100000}

    def test_composite_mixes(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(scrap_mix_mapping=MIX_MAPPING)),
            lower_bounds=Map(),
            upper_bounds=Map(self.available_scrap),
            heats=(
                HeatInputs(
                    grade_planned=GRADE_202,
                    total_scrap_weight=36000,
                    pig_iron_weight=155000,
                    pig_iron_chem=RawFeChem(),
                    lower_bounds=Map(),
                    upper_bounds=Map(),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)
        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(36000, sum(result.scrap_weights_per_heat[0].values()))

    def test_composite_mixes_with_user_limits(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(scrap_mix_mapping=MIX_MAPPING)),
            lower_bounds=Map(),
            upper_bounds=Map(self.available_scrap),
            heats=(
                HeatInputs(
                    grade_planned=GRADE_202,
                    total_scrap_weight=36000,
                    pig_iron_weight=155000,
                    pig_iron_chem=RawFeChem(),
                    lower_bounds=Map({HEAP2: 15000}),
                    upper_bounds=Map(),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)
        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(36000, sum(result.scrap_weights_per_heat[0].values()))
        self.assertGreaterEqual(result.scrap_weights_per_heat[0][HEAP2], 15000)

    def test_composite_mixes_with_user_limits_and_exclusive_groups(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(
                    scrap_mix_mapping=MIX_MAPPING,
                    scrap_exclusive_groups=(ScrapExclusiveGroup("TEST-COMPOSITE", (HEAP1, HEAP2)),),
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map(self.available_scrap),
            heats=(
                HeatInputs(
                    grade_planned=GRADE_202,
                    total_scrap_weight=36000,
                    pig_iron_weight=155000,
                    pig_iron_chem=RawFeChem(),
                    lower_bounds=Map({HEAP2: 3000}),
                    upper_bounds=Map(),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)

        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(36000, sum(result.scrap_weights_per_heat[0].values()))


class TestOneHeatOptimizations(unittest.TestCase):
    def test_one_heat_without_user_defined_limits(self):
        available_scrap: Dict[ScrapMix, float] = {
            ScrapMix("HS"): 40000,
            ScrapMix("PAS"): 40000,
            ScrapMix("2PIT"): 40000,
            ScrapMix("1IB"): 40000,
            ScrapMix("MCE"): 40000,
        }
        ordered_scrap_weight = 36000.0
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=1000),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=("S", "Cu", "Ni", "Cr", "Mo", "Sn"),  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=Map(),
                    grade_planned=GRADE_202,
                    total_scrap_weight=36000,
                    pig_iron_weight=155000,
                    pig_iron_chem=RawFeChem(),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)

        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(ordered_scrap_weight, sum(result.scrap_weights_per_heat[0].values()))

    def test_one_real_heat_with_user_defined_limits(self):
        heats = load_heats_from_file(str(TEST_HEATS))
        heat = heats[0]
        scraps = heat.get_scrap_map()
        ordered_scrap_weight = sum(heat.get_scrap_map().values())
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=100),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=("S", "Cu", "Ni", "Cr", "Mo", "Sn"),  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map({ScrapMix(k): ordered_scrap_weight for k in scraps}),
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=Map(),
                    grade_planned=heat.grade_planned,
                    total_scrap_weight=int(ordered_scrap_weight),
                    pig_iron_weight=int(heat.raw_fe_weight),
                    pig_iron_chem=RawFeChem(
                        S=heat.after_desulf.S,
                        Cu=heat.after_desulf.Cu,
                        Ni=heat.after_desulf.Ni,
                        Cr=heat.after_desulf.Cr,
                        Mo=heat.after_desulf.Mo,
                        Sn=heat.after_desulf.Sn,
                        Si=heat.after_desulf.Si,
                    ),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(
                        heat.grade_planned.grade_id
                    ),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(ordered_scrap_weight, sum(result.scrap_weights_per_heat[0].values()))

    def test_one_heat_with_tight_user_defined_limits(self):
        planned_scrap_weight = 20000
        planned_pig_iron_weight = 100000

        upper_bounds: Map[ScrapMix, float] = Map(
            {
                ScrapMix("DSI"): 5000,
                ScrapMix("1PIT"): 5000,
                ScrapMix("SHS"): 6000,
                ScrapMix("MCE"): 4000,
                ScrapMix("HS"): 4000,
            }  # type: ignore
        )
        # Make sure that the optimization task is feasible.
        assert planned_scrap_weight < sum(upper_bounds.values())  # type: ignore

        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=1000),
            ),
            lower_bounds=Map(),
            upper_bounds=upper_bounds,
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=upper_bounds,
                    grade_planned=GRADE_2,
                    total_scrap_weight=planned_scrap_weight,
                    pig_iron_weight=planned_pig_iron_weight,
                    pig_iron_chem=RawFeChem(S=0.006),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(2),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)

        # Check that error is not present, thus the optimization was successful and found a solution.
        self.assertIsNotNone(result)
        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels((), ()))
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(planned_scrap_weight, sum(result.scrap_weights_per_heat[0].values()))

    def test_one_heat_negative_corrtech_proba_bug(self):
        upper_bounds = Map(
            {
                ScrapMix("1BS"): 200.0,
                ScrapMix("HST"): 1200.0,
                ScrapMix("1SH"): 1575200.0,
                ScrapMix("1DB"): 200.0,
                ScrapMix("PAS"): 1526600.0,
                ScrapMix("TBC"): 2300.0,
                ScrapMix("1IB"): 2667000.0,
                ScrapMix("HSD"): 200.0,
                ScrapMix("1BBC"): 200.0,
                ScrapMix("DSI"): 1160600.0,
                ScrapMix("ZBS"): 200.0,
                ScrapMix("2SH"): 200.0,
                ScrapMix("SHS"): 5613800.0,
                ScrapMix("HS"): 1126000.0,
                ScrapMix("1BC"): 2400.0,
            }
        )
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=100),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=("S", "Cu", "Ni", "Cr", "Mo", "Sn"),  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=upper_bounds,  # type: ignore
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=upper_bounds,  # type: ignore
                    grade_planned=GRADE_303,
                    total_scrap_weight=36900,
                    pig_iron_weight=151300,
                    pig_iron_chem=RawFeChem(),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(303),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)

        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(36900, sum(result.scrap_weights_per_heat[0].values()))

    @unittest.skip("unskip when fixed")
    def test_one_heat_minimal_loadable_weights(self):
        # TODO find out why it does not work with 5000
        minimal_loadable_weight = 3000
        heats = load_heats_from_file(str(TEST_HEATS))
        heat = heats[0]
        scraps = heat.get_scrap_map()
        ordered_scrap_weight = sum(heat.get_scrap_map().values())
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(
                    precision_step=100,
                    minimal_loadable_scrap_weights={
                        scrap_type: minimal_loadable_weight for scrap_type in scraps
                    },
                ),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=("S", "Cu", "Ni", "Cr", "Mo", "Sn"),  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map({ScrapMix(k): ordered_scrap_weight for k in scraps}),
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=Map({ScrapMix(k): ordered_scrap_weight for k in scraps}),
                    grade_planned=heat.grade_planned,
                    total_scrap_weight=int(ordered_scrap_weight),
                    pig_iron_weight=int(heat.raw_fe_weight),
                    pig_iron_chem=RawFeChem(
                        S=heat.after_desulf.S,
                        Cu=heat.after_desulf.Cu,
                        Ni=heat.after_desulf.Ni,
                        Cr=heat.after_desulf.Cr,
                        Mo=heat.after_desulf.Mo,
                        Sn=heat.after_desulf.Sn,
                        Si=heat.after_desulf.Si,
                    ),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(
                        heat.grade_planned.grade_id
                    ),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(ordered_scrap_weight, sum(result.scrap_weights_per_heat[0].values()))
        for weight in result.scrap_weights_per_heat[0].values():
            self.assertTrue(
                weight == 0 or weight >= minimal_loadable_weight,
                f"Invalid optimization result (some scrap weights "
                f"are smaller than {minimal_loadable_weight}): {result}",
            )

    def test_easy_to_create_charge_with_invalid_chem(self):
        ordered_scrap_weight = 45000.0
        upper_bounds = {
            "DSI": 46000,
            "PAS": 46000,
            "HS": 3000,
            "TBS": 46000,
            "HSZ": 2500,
        }
        relaxable_risk_limit = RelaxableRiskLimit(
            name="test",
            Cr=RelaxableValue(0.01, 0.02),
            Cu=RelaxableValue(0.01, 0.02),
            Mo=RelaxableValue(0.01, 0.02),
            Ni=RelaxableValue(0.01, 0.02),
            S=RelaxableValue(0.15, 0.291),
            Si=RelaxableValue(0.01, 0.02),
            Sn=RelaxableValue(0.05, 0.10),
        )

        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(
                    precision_step=1000,
                ),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=["S", "Cu", "Ni", "Cr", "Mo", "Sn"],  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map(upper_bounds),  # type: ignore
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=Map(upper_bounds),  # type: ignore
                    grade_planned=GRADE_515,
                    total_scrap_weight=int(ordered_scrap_weight),
                    pig_iron_weight=147000,
                    pig_iron_chem=RawFeChem(S=0.014),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(515),
                    relaxable_risk_limit=relaxable_risk_limit,
                ),
            ),
        )
        result = optimize_multiple_heats(input_data)
        self.assertNotEqual(result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(result)
        self.assertIsNone(result.error)
        self.assertEqual(len(result.scrap_weights_per_heat), 1)
        self.assertIsInstance(result.scrap_weights_per_heat[0], Map)
        self.assertAlmostEqual(ordered_scrap_weight, sum(result.scrap_weights_per_heat[0].values()))

        blend_model = get_blend_model(2)
        blend_model_input = ScrapBlendModelInput(
            raw_fe_weight=147000,
            raw_fe_chem=RawFeChem(S=0.014),
            scrap_weights=result.scrap_weights_per_heat[0],
            pellets_weight=0.0,
            briquetes_weight=0.0,
        )
        blend_model_output = blend_model.calculate(blend_model_input)
        corr_tech_model = get_corr_tech_model(1, ("S", "Cu", "Ni", "Cr", "Mo", "Sn"))
        corr_tech_model_input = CorrectionTechnologiesModelInput(grade=GRADE_515, eob_chem=blend_model_output)
        corr_tech_model_output = corr_tech_model.calculate(corr_tech_model_input)
        self.assertLessEqual(corr_tech_model_output.undesirable_corr_tech_proba, 0.30)


class TestDataModelSerialization(unittest.TestCase):
    def test_input_serialize_deserialize(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=515),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=["S", "Cu", "Ni", "Cr", "Mo", "Sn"],  # type: ignore
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map({"DSI": 1000}),  # type: ignore
            heats=(
                HeatInputs(
                    lower_bounds=Map(),
                    upper_bounds=Map({"DSI": 1000}),  # type: ignore
                    grade_planned=GRADE_202,
                    total_scrap_weight=36000,
                    pig_iron_weight=150000,
                    pig_iron_chem=RawFeChem(
                        S=0.002,
                        Cu=0.1,
                        Ni=0.04,
                        Cr=0.243,
                        Mo=5.43423,
                        Sn=2.444,
                    ),
                    relaxable_lower_summing_limits=(),
                    relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
                    relaxable_risk_limit=get_default_relaxable_risk_limit(),
                ),
            ),
        )
        serialized = input_data.serialize()
        deserialized = MultipleHeatsOptimizationInput.deserialize(serialized)
        self.assertEqual(deserialized, input_data)

    def test_output_serialize_deserialize(self):
        data = MultipleHeatsOptimizationOutput(None, None, (Map({"DSI": 100.0, "SHS": 500.9}),))  # type: ignore
        serialized = data.serialize()
        deserialized = MultipleHeatsOptimizationOutput.deserialize(serialized)
        self.assertEqual(deserialized, data)

    def test_output_serialize_deserialize_error_state(self):
        data = MultipleHeatsOptimizationOutput("Error", None, ())
        serialized = data.serialize()
        deserialized = MultipleHeatsOptimizationOutput.deserialize(serialized)
        self.assertEqual(deserialized, data)


class TestMultiheatOptimizer(unittest.TestCase):
    def test_one_heat(self):
        available_scrap: Dict[ScrapMix, float] = {
            ScrapMix("HS"): 40000,
            ScrapMix("PAS"): 40000,
            ScrapMix("2PIT"): 40000,
            ScrapMix("1IB"): 40000,
            ScrapMix("MCE"): 40000,
        }
        heat1 = HeatInputs(
            grade_planned=GRADE_202,
            total_scrap_weight=36000,
            pig_iron_weight=155000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map(),
            upper_bounds=Map(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        )
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(precision_step=100),
            ),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=(heat1,),
        )
        optimization_result = optimize_multiple_heats(input_data)
        self.assertNotEqual(optimization_result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(optimization_result)
        self.assertIsNone(optimization_result.error)
        self.assertIsInstance(optimization_result.scrap_weights_per_heat, tuple)
        self.assertAlmostEqual(
            heat1.total_scrap_weight, sum(optimization_result.first_heat_scrap_weights.values())
        )

    def test_two_heats(self):
        available_scrap: Dict[ScrapMix, float] = {
            ScrapMix("HS"): 80000,
            ScrapMix("PAS"): 80000,
            ScrapMix("2PIT"): 80000,
            ScrapMix("1IB"): 80000,
            ScrapMix("MCE"): 80000,
            ScrapMix("1BS"): 80000,
        }
        heat1 = HeatInputs(
            grade_planned=GRADE_2,
            total_scrap_weight=36000,
            pig_iron_weight=155000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map(),
            upper_bounds=Map(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(2),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        )
        heat2 = HeatInputs(
            grade_planned=GRADE_684,
            total_scrap_weight=38000,
            pig_iron_weight=155000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map(),
            upper_bounds=Map(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(684),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        )
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(precision_step=1000)),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=(heat1, heat2),
        )
        optimization_result = optimize_multiple_heats(input_data)
        self.assertNotEqual(optimization_result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))
        self.assertIsNotNone(optimization_result)
        self.assertIsNone(optimization_result.error)
        self.assertIsInstance(optimization_result.scrap_weights_per_heat, tuple)
        self.assertAlmostEqual(
            heat1.total_scrap_weight, sum(optimization_result.first_heat_scrap_weights.values())
        )
        self.assertAlmostEqual(
            heat2.total_scrap_weight, sum(optimization_result.scrap_weights_per_heat[1].values())
        )

    def test_two_heats_with_scrap_bounds(self):

        hs_low = 10000
        hs_upp = 20000

        ib_upp = 10000
        available_scrap: Dict[ScrapMix, float] = {
            ScrapMix("HS"): hs_upp,
            ScrapMix("1TB"): 80000,
            ScrapMix("1BC"): 80000,
            ScrapMix("1IB"): ib_upp,
            ScrapMix("1BS"): 80000,
            ScrapMix("1HM"): 80000,
            ScrapMix("HSB"): 10000,
            ScrapMix("HST"): 80000,
            ScrapMix("1DB"): 80000,
            ScrapMix("PAS"): 80000,
            ScrapMix("SHS"): 80000,
        }

        heat1 = HeatInputs(
            grade_planned=GRADE_202,
            total_scrap_weight=35000,
            pig_iron_weight=155000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map(),
            upper_bounds=Map({"1IB": ib_upp, "HS": 0}),  # type: ignore
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(202),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        )
        heat2 = HeatInputs(
            grade_planned=GRADE_684,
            total_scrap_weight=40000,
            pig_iron_weight=155000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({"HS": hs_low}),  # type: ignore
            upper_bounds=Map({"HS": hs_upp}),  # type: ignore
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(684),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        )
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(precision_step=1000)),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=(heat1, heat2),
        )
        optimization_result = optimize_multiple_heats(input_data)

        self.assertNotEqual(optimization_result.first_heat_expected_risk, ChemRiskLevels(medium=(), high=()))

        # check that HS is not used in heat1, because lower and upper bounds were not set
        heat1_scrap = optimization_result.scrap_weights_per_heat[0]
        self.assertEqual(
            heat1_scrap.get(ScrapMix("HS"), 0),
            0,
            msg=f"Expected weight of 'HS' scrap is 0, got {heat1_scrap}",
        )

        # check that upper bound for 1IB is respected
        ib_weight_1 = heat1_scrap.get(ScrapMix("1IB"), 0)
        self.assertLessEqual(
            ib_weight_1, ib_upp, msg=f"Expected weight of '1IB' scrap is <= {ib_upp}, got {heat1_scrap}"
        )

        # check that HS is used in heat2, because lower and upper bounds were set
        heat2_scrap = optimization_result.scrap_weights_per_heat[1]
        hs_weight_2 = heat2_scrap.get(ScrapMix("HS"), 0)
        self.assertGreaterEqual(
            hs_weight_2, hs_low, msg=f"Expected weight of 'HS' scrap is >= {hs_low}, got {heat2_scrap}"
        )
        self.assertLessEqual(
            hs_weight_2, hs_upp, msg=f"Expected weight of 'HS' scrap is <= {hs_upp}, got {heat2_scrap}"
        )


if __name__ == "__main__":
    unittest.main()
