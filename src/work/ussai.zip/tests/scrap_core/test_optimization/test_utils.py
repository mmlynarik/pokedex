import unittest
from datetime import date
from typing import Dict

import numpy as np
from immutables import Map

from scrap_core import ScrapMix, ScrapOrder, ScrapMixMapping, SUPPORTED_CHEMS
from usskssgrades.steel_grades_hardcoded import SteelGradesHardcoded
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.datamodel import (
    HeatInputs,
    ModelSettings,
    MultipleHeatsOptimizationInput,
    OptimizerSettings,
    scrap_mix_to_scrap_type_set,
    get_default_relaxable_risk_limit,
)
from scrap_core.optimization.linprog_optimizer import (
    get_affected_scrap_mixes,
    get_available_scrap_mixes,
    get_optimization_upper_bounds_for_one_heat,
    get_reference_blend_model_input,
)
from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit, RelaxableValue

grades = SteelGradesHardcoded(SUPPORTED_CHEMS)
GRADE_684 = grades.get_grade_from_id(684, date.today())

HS = ScrapMix("HS")
PAS = ScrapMix("PAS")
HEAP1 = ScrapMix("Hromada1")
HEAP2 = ScrapMix("Hromada2")

HEAP1_SCRAPS: ScrapOrder = ("HS", "PAS", "2PIT")
HEAP2_SCRAPS: ScrapOrder = ("MCE", "1PIT", "2PIT")
RATIOS = (0.3, 0.3, 0.4)
OTHER_RATIOS = (0.5, 0.5)
MIX_MAPPING: ScrapMixMapping = Map(
    {HEAP1: Map(zip(HEAP1_SCRAPS, RATIOS)), HEAP2: Map(zip(HEAP2_SCRAPS, RATIOS))}
)
OTHER_MIX_MAPPING = Map(
    {HEAP1: Map(zip(("1RR", "2HM"), OTHER_RATIOS)), HEAP2: Map(zip(("1PIT", "2PIT"), OTHER_RATIOS))}
)

available_scrap_single: Dict[ScrapMix, float] = {
    ScrapMix("HS"): 40000,
    ScrapMix("PAS"): 40000,
    ScrapMix("2PIT"): 40000,
    ScrapMix("1IB"): 40000,
    ScrapMix("MCE"): 40000,
}
available_scrap_composite: Dict[ScrapMix, float] = {HEAP1: 40000, HEAP2: 40000}
available_scrap: Dict[ScrapMix, float] = {**available_scrap_single, **available_scrap_composite}


class TestGetAvailableScrapMixes(unittest.TestCase):
    def test_without_scrap_mixes(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap_single),
            heats=(),
        )
        available = set(get_available_scrap_mixes(input_data))
        expected = set(available_scrap_single)
        self.assertSetEqual(available, expected)

    def test_empty(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(),
            lower_bounds=Map(),
            upper_bounds=Map(),
            heats=(),
        )
        available = set(get_available_scrap_mixes(input_data))
        self.assertSetEqual(available, set())

    def test_with_scrap_mixes_with_zero_upper_bounds(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(scrap_mix_mapping=MIX_MAPPING)),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap_single),
            heats=(),
        )
        available = set(get_available_scrap_mixes(input_data))
        expected = set(available_scrap_single)
        self.assertSetEqual(available, expected)

    def test_with_scrap_mixes(self):
        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(optimizer_settings=OptimizerSettings(scrap_mix_mapping=MIX_MAPPING)),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=(),
        )
        available = set(get_available_scrap_mixes(input_data))
        expected = set(available_scrap)
        self.assertSetEqual(available, expected)


class TestGetReferenceInput(unittest.TestCase):
    def test_without_scrap_mixes_without_lower_bounds(self):
        pig_iron_weight = 150000
        scrap_weight = 40000
        pig_iron_chem = RawFeChem(S=0.012)
        heat_input = HeatInputs(
            GRADE_684,
            scrap_weight,
            pig_iron_weight,
            pig_iron_chem,
            Map({}),
            Map({HS: 40000.0, PAS: 50000.0}),
        )

        reference = get_reference_blend_model_input(heat_input, Map())

        self.assertEqual(reference.briquetes_weight, 0)
        self.assertEqual(reference.pellets_weight, 0)
        self.assertEqual(reference.raw_fe_chem, pig_iron_chem)
        self.assertEqual(reference.raw_fe_weight, pig_iron_weight)
        self.assertEqual(reference.scrap_weights, Map())

    def test_without_scrap_mixes_with_lower_bounds(self):
        pig_iron_weight = 153000
        scrap_weight = 38000
        pig_iron_chem = RawFeChem(Cr=0.012)
        heat_input = HeatInputs(
            GRADE_684,
            scrap_weight,
            pig_iron_weight,
            pig_iron_chem,
            Map({HS: 5000.0, PAS: 5000.0}),
            Map({HS: 40000.0, PAS: 40000.0}),
        )

        reference = get_reference_blend_model_input(heat_input, Map())

        self.assertEqual(reference.briquetes_weight, 0)
        self.assertEqual(reference.pellets_weight, 0)
        self.assertEqual(reference.raw_fe_chem, pig_iron_chem)
        self.assertEqual(reference.raw_fe_weight, pig_iron_weight)
        self.assertEqual(reference.scrap_weights, Map({"HS": 5000.0, "PAS": 5000.0}))

    def test_with_scrap_mixes_without_lower_bounds(self):
        pig_iron_weight = 150000
        scrap_weight = 40000
        pig_iron_chem = RawFeChem(S=0.012)
        heat_input = HeatInputs(
            GRADE_684,
            scrap_weight,
            pig_iron_weight,
            pig_iron_chem,
            Map(),
            Map({HS: 50000.0, PAS: 50000.0, HEAP1: 50000.0, HEAP2: 50000.0}),
        )

        reference = get_reference_blend_model_input(heat_input, OTHER_MIX_MAPPING)  # type: ignore

        self.assertEqual(reference.briquetes_weight, 0)
        self.assertEqual(reference.pellets_weight, 0)
        self.assertEqual(reference.raw_fe_chem, pig_iron_chem)
        self.assertEqual(reference.raw_fe_weight, pig_iron_weight)
        self.assertEqual(reference.scrap_weights, Map())

    def test_with_scrap_mixes_with_lower_bounds(self):
        pig_iron_weight = 150000
        scrap_weight = 40000
        pig_iron_chem = RawFeChem(S=0.012)
        heat_input = HeatInputs(
            GRADE_684,
            scrap_weight,
            pig_iron_weight,
            pig_iron_chem,
            Map({HS: 5000.0, HEAP1: 5000.0}),
            Map({HS: 50000.0, PAS: 50000.0, HEAP1: 50000.0, HEAP2: 50000.0}),
        )

        reference = get_reference_blend_model_input(heat_input, OTHER_MIX_MAPPING)  # type: ignore

        self.assertEqual(reference.briquetes_weight, 0)
        self.assertEqual(reference.pellets_weight, 0)
        self.assertEqual(reference.raw_fe_chem, pig_iron_chem)
        self.assertEqual(reference.raw_fe_weight, pig_iron_weight)
        self.assertEqual(reference.scrap_weights, Map({"HS": 5000.0, HEAP1: 5000}))


class TestGetOptimizationUpperBounds(unittest.TestCase):
    pig_iron_weight = 150000
    scrap_weight = 40000
    pig_iron_chem = RawFeChem(S=0.012)

    def test_limit_scrap_types_affect_zero_available_mixes(self):
        limit_zero = RelaxableUpperSummingLimit(
            "Test", ("1IB",), weight_limit=RelaxableValue(5000, 5000), ratio=RelaxableValue(1.0, 1.0)
        )
        heat_input = HeatInputs(
            GRADE_684,
            self.scrap_weight,
            self.pig_iron_weight,
            self.pig_iron_chem,
            Map({}),
            Map({HS: 40000.0, HEAP2: 50000, HEAP1: 60000}),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(limit_zero,),
        )
        scrap_mix_order, mix_mapping = (HEAP1, HEAP2, "1IB", HS), MIX_MAPPING
        constraint = get_optimization_upper_bounds_for_one_heat(heat_input, scrap_mix_order, mix_mapping)
        np.testing.assert_equal(
            constraint.coef_matrix,
            np.array([[0, 0, 0, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]]),
        )
        np.testing.assert_equal(constraint.values_vector, np.array([0, 40000, 60000, 50000, 5000]))

    def test_limit_scrap_types_affect_one_available_mix(self):
        limit_one = RelaxableUpperSummingLimit(
            "Test", ("HS", "PAS"), weight_limit=RelaxableValue(5000, 5000), ratio=RelaxableValue(1.0, 1.0)
        )
        heat_input = HeatInputs(
            GRADE_684,
            self.scrap_weight,
            self.pig_iron_weight,
            self.pig_iron_chem,
            Map({}),
            Map({HS: 40000.0, HEAP2: 50000, HEAP1: 60000}),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(limit_one,),
        )
        # 1IB < HS < Hromada1 < Hromada2
        scrap_mix_order, mix_mapping = (HEAP1, HEAP2, "1IB", HS), MIX_MAPPING
        constraint = get_optimization_upper_bounds_for_one_heat(heat_input, scrap_mix_order, mix_mapping)
        np.testing.assert_equal(
            constraint.coef_matrix,
            np.array([[0, 0, 0, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0], [1, 0, 0, 1]]),
        )
        np.testing.assert_equal(constraint.values_vector, np.array([0, 40000, 60000, 50000, 5000]))

    def test_limit_scrap_types_affect_two_available_mixes(self):
        limit_two = RelaxableUpperSummingLimit(
            "Test", ("HS", "2PIT"), weight_limit=RelaxableValue(5000, 5000), ratio=RelaxableValue(1.0, 1.0)
        )
        heat_input = HeatInputs(
            GRADE_684,
            self.scrap_weight,
            self.pig_iron_weight,
            self.pig_iron_chem,
            Map({}),
            Map({HS: 40000.0, HEAP2: 50000, HEAP1: 60000}),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(limit_two,),
        )
        # 1IB < HS < Hromada1 < Hromada2
        scrap_mix_order, mix_mapping = (HEAP1, HEAP2, "1IB", HS), MIX_MAPPING
        constraint = get_optimization_upper_bounds_for_one_heat(heat_input, scrap_mix_order, mix_mapping)
        np.testing.assert_equal(
            constraint.coef_matrix,
            np.array([[0, 0, 0, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0], [1, 1, 0, 1]]),
        )
        np.testing.assert_equal(constraint.values_vector, np.array([0, 40000, 60000, 50000, 5000]))


class TestResolveScrapTypeSet(unittest.TestCase):
    def test_existing_mix(self):
        resolved = scrap_mix_to_scrap_type_set(MIX_MAPPING, HEAP1)
        self.assertSetEqual(resolved, set(HEAP1_SCRAPS))

        resolved = scrap_mix_to_scrap_type_set(MIX_MAPPING, HEAP2)
        self.assertSetEqual(resolved, set(HEAP2_SCRAPS))

    def test_non_existing_mix(self):
        self.assertRaises(ValueError, lambda: scrap_mix_to_scrap_type_set(MIX_MAPPING, ScrapMix("Hromada3")))

    def test_scrap_type(self):
        resolved = scrap_mix_to_scrap_type_set(MIX_MAPPING, ScrapMix("PAS"))
        self.assertSetEqual(resolved, set(["PAS"]))

        resolved = scrap_mix_to_scrap_type_set(MIX_MAPPING, ScrapMix("DSI"))
        self.assertSetEqual(resolved, set(["DSI"]))


class TestGetAffectedScrapMixes(unittest.TestCase):
    def test_only_one_separate_scrap_type(self):
        affected = get_affected_scrap_mixes(
            (HEAP1, HEAP2, ScrapMix("PAS"), ScrapMix("MCE"), ScrapMix("DSI")),
            MIX_MAPPING,
            ("DSI",),
        )
        self.assertSetEqual(set(affected), set(["DSI"]))

    def test_only_one_in_scrap_mix(self):
        affected = get_affected_scrap_mixes(
            (HEAP1, HEAP2, ScrapMix("PAS"), ScrapMix("MCE"), ScrapMix("DSI")),
            MIX_MAPPING,
            ("HS",),
        )
        self.assertSetEqual(set(affected), set([HEAP1]))

    def test_only_one_in_multiple(self):
        affected = get_affected_scrap_mixes(
            (HEAP1, HEAP2, ScrapMix("PAS"), ScrapMix("MCE"), ScrapMix("DSI")),
            MIX_MAPPING,
            ("MCE",),
        )
        self.assertSetEqual(set(affected), set([HEAP2, "MCE"]))

    def test_not_present(self):
        affected = get_affected_scrap_mixes(
            (HEAP1, HEAP2, ScrapMix("PAS"), ScrapMix("MCE"), ScrapMix("DSI")),
            MIX_MAPPING,
            ("1RR", "1SH"),
        )
        self.assertSetEqual(set(affected), set())

    def test_two_in_multiple(self):
        affected = get_affected_scrap_mixes(
            (HEAP1, HEAP2, ScrapMix("PAS"), ScrapMix("MCE"), ScrapMix("DSI")),
            MIX_MAPPING,
            ("MCE", "PAS"),
        )
        self.assertSetEqual(set(affected), set([HEAP2, HEAP1, "MCE", "PAS"]))


if __name__ == "__main__":
    unittest.main()
