from functools import partial
import unittest
from datetime import date
from typing import Dict

from immutables import Map
from scrap_core import ScrapBounds, ScrapMix, SUPPORTED_CHEMS
from scrap_core.blendmodel import ScrapBlendModelInput, get_blend_model
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    CorrectionTechnologiesModelSettings,
    get_corr_tech_model,
)
from scrap_core.optimization.datamodel import (
    RawFeChem,
    HeatInputs,
    ModelSettings,
    MultipleHeatsOptimizationInput,
    OptimizerSettings,
)
from usskssgrades import SteelGradesHardcoded
from usskssgrades.grade import Grade
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats


steel_grades = SteelGradesHardcoded(SUPPORTED_CHEMS)

GRADE_647 = steel_grades.get_grade_from_id(647, date.today())
GRADE_645 = steel_grades.get_grade_from_id(645, date.today())
GRADE_516 = steel_grades.get_grade_from_id(516, date.today())
GRADE_592 = steel_grades.get_grade_from_id(592, date.today())
GRADE_684 = steel_grades.get_grade_from_id(684, date.today())
S2_RAW_FE_CHEM = RawFeChem(S=0.002, Cu=0.005, Ni=0.005, Cr=0.01, Mo=0.003, Sn=0.002, Si=0.562)


def get_heat_input(
    total_scrap_weight: int, pig_iron_weight: int, grade: Grade, raw_fe_chem: RawFeChem
) -> HeatInputs:
    return HeatInputs(
        grade_planned=grade,
        total_scrap_weight=total_scrap_weight,
        pig_iron_weight=pig_iron_weight,
        pig_iron_chem=raw_fe_chem,
        lower_bounds=Map(),
        upper_bounds=Map(),
    )


# There are cases when operations complaint was "too good scrap"
# Worst mode should solve the issue
class TestMultiheatOptimizerTooGoodScrap(unittest.TestCase):
    def test_too_good_scrap(self):
        available_scrap: ScrapBounds = Map(
            {
                ScrapMix("MCE"): 30000.0,
                ScrapMix("HS"): 130000.0,
                ScrapMix("DSI"): 15000.0,
                ScrapMix("2PIT"): 26000.0,
                ScrapMix("1BS"): 60000.0,
                ScrapMix("1PIT"): 70000.0,
                ScrapMix("HST"): 7000.0,
                ScrapMix("PAS"): 30000.0,
                ScrapMix("1SH"): 20000.0,
                ScrapMix("PIG IRON"): 30000.0,
                ScrapMix("HSB"): 30000.0,
            }
        )
        heat_creator = partial(get_heat_input, 32000, 158000)
        heats = tuple(
            [heat_creator(GRADE_647, S2_RAW_FE_CHEM)] * 2
            + [heat_creator(GRADE_647, S2_RAW_FE_CHEM)] * 5
            + [heat_creator(GRADE_516, S2_RAW_FE_CHEM), heat_creator(GRADE_592, S2_RAW_FE_CHEM)]
            + [heat_creator(GRADE_684, S2_RAW_FE_CHEM)] * 2
        )

        input_data = MultipleHeatsOptimizationInput(
            model_settings=ModelSettings(
                optimizer_settings=OptimizerSettings(
                    precision_step=1000,
                    max_undesirable_corr_tech_probability=0.15,
                    optimization_mode="Worst",
                    h_min_ratio=0.15,
                    h_max_ratio=0.4,
                    l_min_ratio=0.0,
                    l_max_ratio=0.5,
                ),
                correction_technologies_settings=CorrectionTechnologiesModelSettings(
                    chems_for_correction_technologies=("S", "Cu", "Mo", "Cr", "Sn", "Ni"),  # type: ignore
                    version=1,
                ),
            ),
            lower_bounds=Map(),
            upper_bounds=Map(available_scrap),
            heats=heats,
        )
        optimization_result = optimize_multiple_heats(input_data)
        self.assertIsNotNone(optimization_result)
        self.assertIsNone(optimization_result.error)
        self.assertIsInstance(optimization_result.scrap_weights_per_heat, tuple)

        blend_model = get_blend_model(2)
        blend_model_input = ScrapBlendModelInput(
            raw_fe_weight=158000,
            raw_fe_chem=S2_RAW_FE_CHEM,
            scrap_weights=optimization_result.scrap_weights_per_heat[0],
            pellets_weight=0.0,
            briquetes_weight=0.0,
        )
        blend_model_output = blend_model.calculate(blend_model_input)
        corr_tech_model = get_corr_tech_model(1, ("S", "Cu", "Ni", "Cr", "Mo", "Sn"))
        corr_tech_model_input = CorrectionTechnologiesModelInput(grade=GRADE_647, eob_chem=blend_model_output)
        corr_tech_model_output = corr_tech_model.calculate(corr_tech_model_input)
        self.assertLessEqual(corr_tech_model_output.undesirable_corr_tech_proba, 0.30)


if __name__ == "__main__":
    unittest.main()
