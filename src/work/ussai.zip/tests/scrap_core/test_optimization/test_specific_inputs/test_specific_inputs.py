"""
Create test data using

`python manage.py dumpdata scrap.MultipleHeatsOptimizationResult --pks 8761 -o opt_8761.json`
"""

import json
import os
import unittest
import unittest.mock
from typing import Tuple

import attr

from scrap_core.optimization.datamodel import MultipleHeatsOptimizationInput, HeatInputs
from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats
from scrap_core.utils import replace_attribute
from scrap_core.modelutils import get_ct_risk


TEST_DATA_PATH = os.path.join(os.path.dirname(__file__), "test_data")


class TestSpecificInput(unittest.TestCase):
    def test_input_8761(self):
        """
        Heat count:
        4

        First heat specs:
        282 - S max: 0.012 - scrap weight: 38000 - pig iron weight 152000 - lb: {} ub: {}

        Available scrap:
               HSB:-0.0001 / 30000.0
                HS:-0.0001 / 10000.0
               1BC:-0.0001 / 90000.0
               SHS:-0.0005 / 30000.0
               1SH:-0.0005 / 60000.0
               DSI:-0.0027 / 20000.0

        Remark:
        We have 2 types of hard to melt scrap (hM) - HSB and DSI, 3 types of easy to melt
        scrap (eM) - 1BC, SHS and 1SH, and only 1 type of scrap (and 10t only) with medium
        meltability (mM) - HS. Consequently, due to meltability limits we may use only 19t of eM scrap,
        10t of mM scrap, so the rest 8t must be hM scrap. Since we have another limit for heavy scrap types,
        we may use at most 5t of HSB, so the rest must be DSI (3t) and we end up with high ct risk for S.

        Expected remedy:
        Working relaxation strategy of summing scrap limits.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_8761.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        # add less strict meltability summing limits with lower priority
        new_heats: Tuple[HeatInputs, ...] = ()
        for heat in input_data.heats:
            new_upper_limits: Tuple[RelaxableUpperSummingLimit, ...] = ()
            for lim in heat.relaxable_upper_summing_limits:
                if lim.name == "meltability_easy_limit":
                    new_upper_limits += (attr.evolve(lim, ratio=attr.evolve(lim.ratio, allowed=0.6)),)
                elif lim.name == "meltability_hard_limit":
                    new_upper_limits += (attr.evolve(lim, ratio=attr.evolve(lim.ratio, allowed=0.7)),)
                else:
                    new_upper_limits += (lim,)

            new_heat = attr.evolve(heat, relaxable_upper_summing_limits=new_upper_limits)
            new_heats += (new_heat,)

        altered_input_data = attr.evolve(input_data, heats=new_heats)

        opt_res = optimize_multiple_heats(altered_input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]
        heat_data = altered_input_data.heats[0]
        model_settings = altered_input_data.model_settings
        limit = heat_data.relaxable_risk_limit

        # check that result is reasonable
        for chem in ["Cr", "Cu", "Ni", "Mo", "S", "Sn"]:  # type: ignore
            self.assertLessEqual(  # type: ignore
                get_ct_risk(recommended_charge, chem, heat_data, model_settings),  # type: ignore
                getattr(limit, chem).allowed,  # type: ignore
            )

    @unittest.skip("Optimization/relaxation improvement is required")
    def test_input_8508(self):
        """
        Heat count:
        11

        First heat specs:
        704 - S max: 0.008 - scrap weight: 36000 - pig iron weight 154000 - lb: {} ub: {}

        Available scrap:
               HSZ:-0.0001 / 161000.0
               HSB:-0.0001 / 38000.0
                HS:-0.0001 / 95000.0
               1BC:-0.0001 / 33000.0
          PIG IRON:-0.0002 / 90000.0
               1SH:-0.0005 / 72000.0
              1PIT:-0.0006 / 286000.0

        Remark:
        Grade 704 has strict S limit (0.008) and very strict Sn limit (0.005) so it is
        difficult to satisfy both of them with given scrap. In particular, 1PIT scrap has high S
        and low Sn content, the rest of scrap have lower S content, but higher Sn content than 1PIT.

        Expected remedy:
        Bin-search optimizer.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_8508.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]
        heat_data = input_data.heats[0]
        model_settings = input_data.model_settings

        # assert that result is reasonable
        self.assertLessEqual(get_ct_risk(recommended_charge, "Cr", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Cu", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Ni", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Mo", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "S", heat_data, model_settings), 0.30)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Sn", heat_data, model_settings), 0.05)

    def test_input_9902(self):
        """
        Result without post-processing is

        {'HS': 23618.81489608148, 'MCE': 10000.0, '2SH': 4881.185103918522, 'DSI': 1500.0}

        We expect that post-processing is able to round this raw charge as needed.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_9902.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        # disable post-processing
        with unittest.mock.patch(
            "scrap_core.optimization.linprog_optimizer.get_postprocessor", return_value=lambda x: x
        ):
            raw_res = optimize_multiple_heats(input_data)
            raw_charge = raw_res.scrap_weights_per_heat[0]

        opt_res = optimize_multiple_heats(input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]

        precision = input_data.model_settings.optimizer_settings.precision_step

        # check that each weight is multiply of precision
        self.assertTrue(all(weight % precision == 0 for weight in recommended_charge.values()))

        # check that recommended charge is close to raw charge
        self.assertTrue(
            all(
                abs(recommended_charge.get(scrap_type, 0) - raw_charge.get(scrap_type, 0)) <= precision
                for scrap_type in set(recommended_charge) | set(raw_charge)
            )
        )
        self.assertEqual(sum(recommended_charge.values()), round(sum(raw_charge.values())))

    def test_input_14855(self):
        """
        Heat count: 4

        Grades:
        9 - S max: 0.01 - scrap weight: 37000 - pig iron weight 153000 - lb: {} ub: {}
        9 - S max: 0.01 - scrap weight: 37000 - pig iron weight 153000 - lb: {} ub: {}
        9 - S max: 0.01 - scrap weight: 37000 - pig iron weight 153000 - lb: {} ub: {}
        8 - S max: 0.01 - scrap weight: 37000 - pig iron weight 153000 - lb: {} ub: {}

        Scraps:
               HSB:-0.0001 / 31000.0
                HS:-0.0001 / 190000.0
               PAS:-0.0004 / 143000.0
               1RR:-0.0004 / 134000.0
               1SH:-0.0005 / 29000.0

        Remark:
                orig output {'1SH': 12000.0, 'PAS': 5000.0, '1RR': 20000.0}
                Cr risk 7.5, Cu risk 57.3, Mo risk 2.0, S risk 60.9

                new output {'1SH': 12000.0, 'HS': 19000.0, '1RR': 6000.0}
                Cr risk 0.7, Cu risk 4.0, Mo risk 2.0, S risk 22.0

        Remedy:
                Set limits in initial optimization state to finite values.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_14855.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]
        heat_data = input_data.heats[0]
        model_settings = input_data.model_settings

        # assert that result is reasonable
        self.assertLessEqual(get_ct_risk(recommended_charge, "Cr", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Cu", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Ni", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Mo", heat_data, model_settings), 0.05)
        self.assertLessEqual(get_ct_risk(recommended_charge, "S", heat_data, model_settings), 0.30)
        self.assertLessEqual(get_ct_risk(recommended_charge, "Sn", heat_data, model_settings), 0.05)

    def test_input_17148(self):
        """
        Heat count: 4

        Grades:
        804 - S max: 0.005 - scrap weight: 35000 - pig iron weight 155000 - lb: {'1TB': 2000.0} ub: {}
        804 - S max: 0.005 - scrap weight: 35000 - pig iron weight 155000 - lb: {} ub: {}
        804 - S max: 0.005 - scrap weight: 35000 - pig iron weight 155000 - lb: {} ub: {}
        804 - S max: 0.005 - scrap weight: 35000 - pig iron weight 155000 - lb: {} ub: {}

        Scraps:
               HSB:-0.0001 / 5000.0
                HS:-0.0001 / 176000.0
               1TB:-0.0002 / 44000.0
               SHS:-0.0005 / 50000.0
               1SH:-0.0005 / 250000.0
               DSI:-0.0027 / 13000.0

        Remark:
                orig result without preprocessing
                [{'HSB': 5000.0, 'HS': 27033.382527981834, '1TB': 2089.510262681826, '1SH': 877.107209336345}]
                after postprocessing
                [{'HSB': 5000.0, 'HS': 27000, '1TB': 3000}]
                Consequently, due to 3t of 1TB scrap, risk for Sn is unacceptable and high risk warning is displayed,
                despite the original solution is feasible.

        Remedy:
                Add risk penalty to postprocessing.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_17148.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]
        heat_data = input_data.heats[0]
        model_settings = input_data.model_settings

        # assert that result satisfies given limits
        for chem in model_settings.supported_chems:
            # extract acceptable risk from the lowest priority risk limit
            limit = heat_data.relaxable_risk_limit
            acceptable_risk = getattr(limit, chem).allowed
            self.assertLessEqual(
                get_ct_risk(recommended_charge, chem, heat_data, model_settings), acceptable_risk
            )

    def test_input_41175(self):
        """
        Despite available quality scrap, risk limits were relaxed
        far above aim (due to inapplicable lower limit HSA >= 8t)
        and recommended charge had expected risk about 29% instead of aimed 12% (for sulphur).
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_41175.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        recommended_charge = opt_res.scrap_weights_per_heat[0]
        heat_data = input_data.heats[0]
        model_settings = input_data.model_settings

        # assert that result satisfies given aimed risk + small tolerance due to rounding
        for chem in model_settings.supported_chems:
            limit = heat_data.relaxable_risk_limit
            aimed_risk = getattr(limit, chem).aim
            self.assertLessEqual(
                get_ct_risk(recommended_charge, chem, heat_data, model_settings), aimed_risk + 0.01
            )

    def test_input_133354(self):
        """
        Due to bug in function `linprog_optimizer.get_exclusive_scrap_space`
        no result was found, because `bound_active_scrap_space` was empty.

        Remark: This optimization was executed/found in test environment (not production)
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_133354_test.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        self.assertIsNone(opt_res.error)

    def test_input_133529(self):
        """
        Remark: This optimization was executed/found in test environment (not production)

        Available scrap:
        {
            'PAS': 93000.0,
            'HSCA': 70000.0,
            '2PIT': 50000,
            '1BC': 71000.0,
            '1IB': 3000.0,
            'HSZ': 32000.0,
            'HSB': 81000.0,
            'HS': 50000
        }

        There are two exclusive scrap groups (EG):

         - PIT EG listing all PIT-like scrap types
            - due to scrap availability effectively (2PIT,)

         - OUTDOOR EG consisting of HS and 2PIT

        Bound active scrap space is (or was) cartesian product of exclusive groups, i.e.

        (2PIT,) X (2PIT, HS) = {(2PIT, HS), (2PIT, 2PIT)}

        Since target grade 22 is low sulphur grade, it is not possible to find solution without outdoor HS scrap,
        because we don't have enough 1IB scrap and there is tight load limit on 1BC scrap. Selector (HS, 2PIT)
        corresponds to bringing outdoor HS scrap to steelshop, however it is incompatible with OUTDOOR EG
        (see function `linprog_optimizer.validate_bound_group`)

        On the other hand, charge {HS: 35000} is clearly compatible with all constraints
        defined by EGs, so the optimizer shall be able to find this (or similar) solution.

        Remedy:
        Add sub-selectors to `bound_active_scrap_space`,
        see function `linprog_optimizers.get_exclusive_scrap_space`. In particular,
        sub-selector (HS,) is what we need in this optimization.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_133529_test.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        self.assertIsNone(opt_res.error)

    def test_input_58057(self):
        """
        Optimization with forced HSCA scrap failed due to following reasons:

        1. Estimated chrome content of HSCA (or HSR Cr) scrap by function `get_unit_chem_weights`
        is 1, i.e. 1kg of this scrap contains 1kg of chrome (possibly a bug itself).

        2. Consequently, `get_chem_constraints` led to constraint

            1 * scrap_1_w + 1 * scrap_2_w + ... + 1 * scrap_n_w <= 10000

        3. And together with constraint for scrap charge weight

            1 * scrap_1_w + 1 * scrap_2_w + ... + 1 * scrap_n_w = scrap_charge_w

        we have an infeasible pair of inequalities whenever scrap_charge_w > 10000.

        Remedy:
        Increase current and last working limits in `get_initial_optimization_state` function.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_58057.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        self.assertIsNone(opt_res.error)

    def test_input_133824(self):
        """
        DSI scrap forced by user-defined lower limit was ignored (DSI >= 5t),
        because selected result came from optimization with exclusive group sub-selector {HS},
        which does not contain DSI scrap.

        Remedy:
        Skip every sub-selector, that is "disjoint" with user defined lower limits.
        """
        with open(os.path.join(TEST_DATA_PATH, "opt_133824_test.json")) as f:
            data = json.load(f)[0]

        input_data = MultipleHeatsOptimizationInput.deserialize(data["fields"]["input_data"])

        opt_res = optimize_multiple_heats(input_data)

        self.assertGreaterEqual(opt_res.scrap_weights_per_heat[0]["DSI"], 5000)


if __name__ == "__main__":
    unittest.main()
