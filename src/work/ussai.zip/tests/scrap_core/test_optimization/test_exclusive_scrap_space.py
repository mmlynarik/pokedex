import unittest
from datetime import date
from typing import Collection

import attr
from immutables import Map

from scrap_core import ScrapMixOrder, ScrapMix, ScrapOrder, ScrapMixMapping, SUPPORTED_CHEMS
from scrap_core.optimization.datamodel import (
    ScrapExclusiveGroup,
    ScrapExclusiveGroups,
    get_default_relaxable_risk_limit,
    MultipleHeatsOptimizationInput,
    ModelSettings,
    HeatInputs,
    RawFeChem,
)
from scrap_core.optimization.linprog_optimizer import (
    get_exclusive_scrap_space,
    get_active_original_scrap_exclusive_groups,
    get_active_derived_scrap_exclusive_groups,
    get_active_scrap_exclusive_groups,
    are_disjoint,
)
from usskssgrades.steel_grades_hardcoded import SteelGradesHardcoded

from scrap_core.optimization.relaxable_limits import RelaxableLowerSummingLimit, RelaxableValue

INPUT_DATA = MultipleHeatsOptimizationInput(
    model_settings=ModelSettings(),
    lower_bounds=Map(),
    upper_bounds=Map(),
    heats=(
        HeatInputs(
            grade_planned=SteelGradesHardcoded(SUPPORTED_CHEMS).get_grade_from_id(684, date.today()),
            total_scrap_weight=38000,
            pig_iron_weight=152000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map(),
            upper_bounds=Map(),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=(),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
    ),
)

HS = ScrapMix("HS")
PAS = ScrapMix("PAS")
MCE = ScrapMix("MCE")
DSI = ScrapMix("DSI")
PIT1 = ScrapMix("1PIT")
PIT2 = ScrapMix("2PIT")
HEAP1 = ScrapMix("HEAP1")
HEAP2 = ScrapMix("HEAP2")

HEAP1_SCRAPS: ScrapOrder = ("HS", "PAS", "2PIT")
HEAP2_SCRAPS: ScrapOrder = ("MCE", "1PIT", "2PIT")
RATIOS = (0.3, 0.4, 0.3)
MIX_MAPPING: ScrapMixMapping = Map(
    {HEAP1: Map(zip(HEAP1_SCRAPS, RATIOS)), HEAP2: Map(zip(HEAP2_SCRAPS, RATIOS))}
)


def finalize_input_data(
    input_data: MultipleHeatsOptimizationInput,
    available_scrap: ScrapMixOrder,
    forced_scrap: ScrapMixOrder,
    exclusive_groups: ScrapExclusiveGroups,
):
    upper_bounds = Map({scrap: 100000 for scrap in available_scrap})
    optimizer_settings = attr.evolve(
        input_data.model_settings.optimizer_settings,
        scrap_exclusive_groups=exclusive_groups,
        scrap_mix_mapping=MIX_MAPPING,
    )
    model_settings = attr.evolve(input_data.model_settings, optimizer_settings=optimizer_settings)
    user_lower_bounds = Map({scrap: 2000 for scrap in forced_scrap})
    heats = (attr.evolve(input_data.heats[0], lower_bounds=user_lower_bounds),)
    return attr.evolve(input_data, upper_bounds=upper_bounds, model_settings=model_settings, heats=heats)


class TestExclusiveScrapSpace(unittest.TestCase):
    available_scraps: ScrapMixOrder = (HEAP1, HEAP2, HS, PAS, MCE, DSI)
    forced_scrap: ScrapMixOrder = (MCE, HS)
    group_exc_1 = ScrapExclusiveGroup(name="exclusive-1", scrap_types=(DSI, PIT2))
    group_exc_2 = ScrapExclusiveGroup(name="exclusive-2", scrap_types=(HS, PIT1))
    group_exc_3 = ScrapExclusiveGroup(name="exclusive-3", scrap_types=(HS, PIT2))
    group_exc_4 = ScrapExclusiveGroup(name="exclusive-4", scrap_types=(HS, PAS))
    group_out = ScrapExclusiveGroup(name="outdoor", scrap_types=(HEAP1, HEAP2, MCE))
    groups = (group_exc_1, group_exc_2, group_exc_3, group_exc_4, group_out)

    def assertEquivalent(self, col_a: Collection[Collection], col_b: Collection[Collection]) -> None:
        self.assertEqual(
            {frozenset(item) for item in col_a},
            {frozenset(item) for item in col_b},
        )

    def test_active_original_exclusive_groups(self):
        """Test that [ordered] active original exclusive groups are DSI-2PIT, HS-1PIT, HEAP1-HEAP2-MCE."""
        input_data = finalize_input_data(INPUT_DATA, self.available_scraps, self.forced_scrap, self.groups)
        active_original_groups = get_active_original_scrap_exclusive_groups(input_data)
        self.assertEqual(active_original_groups, (self.group_exc_1, self.group_exc_2, self.group_out))

    def test_active_derived_exclusive_groups(self):
        """
        Test that active derived exclusive groups are calculated with exclusive-1 and exclusive-2 groups only:
        HEAP2-DSI, HEAP1-DSI, HEAP2-HS, HEAP1-1PIT, HEAP1-HEAP2
        """
        input_data = finalize_input_data(INPUT_DATA, self.available_scraps, self.forced_scrap, self.groups)
        active_derived_groups = get_active_derived_scrap_exclusive_groups(input_data)
        actual_names = set([group.name[len("Derived:") :] for group in active_derived_groups])
        expected_names = set(["DSI-HEAP1", "DSI-HEAP2", "HEAP2-HS", "1PIT-HEAP1", "HEAP1-HEAP2"])
        self.assertEqual(actual_names, expected_names)

    def test_active_scrap_types_for_active_groups(self):
        """Test active scrap types of active groups from which bound scrap space will be constructed."""
        input_data = finalize_input_data(INPUT_DATA, self.available_scraps, self.forced_scrap, self.groups)
        active_scrap_mixes = set(
            frozenset(g.get_active_scrap_mixes(self.available_scraps, self.forced_scrap, MIX_MAPPING))
            for g in get_active_scrap_exclusive_groups(input_data)
        )
        self.assertSetEqual(
            active_scrap_mixes,
            {
                frozenset(x)
                for x in [
                    {"DSI"},
                    {"HEAP1", "HEAP2"},
                    {"HEAP1", "DSI"},
                    {"HS"},
                    {"MCE"},
                    {"DSI", "HEAP2"},
                    {"HEAP1"},
                ]
            },
        )

    def test_disjointness(self):
        """Free group and each bound selector must be disjoint."""
        input_data = finalize_input_data(INPUT_DATA, self.available_scraps, self.forced_scrap, self.groups)
        free_scrap, bound_scrap_space = get_exclusive_scrap_space(input_data)

        bound_scrap_space_list = list(bound_scrap_space)

        # check that free scrap is nonempty
        self.assertTrue(free_scrap)
        # check that bound scrap space is nonempty
        self.assertTrue(bound_scrap_space_list)
        # check that every selector in bound scrap space is nonempty
        self.assertTrue(all(selector for selector in bound_scrap_space_list))
        for selector in bound_scrap_space_list:
            # check disjointness
            self.assertTrue(set(selector).isdisjoint(free_scrap))

    def test_free_bound_scrap_space(self):
        """
        Available scrap:
        (HEAP1, HEAP2, HS, PAS, MCE, DSI)

        HEAP1 = (HS, PAS, 2PIT)
        HEAP2 = (MCE, 1PIT, 2PIT)

        Exclusive groups:
        (DSI, PIT2)
        (HS, PIT1)
        (HS, PIT2) // inactive due to HEAP1
        (HS, PAS)  // inactive due to HEAP1
        (HEAP1, HEAP2, MCE)

        Derived exclusive groups:
        (DSI, PIT2)
            -> (DSI, HEAP1)
            -> (DSI, HEAP2)
        (HS, PIT1)
            -> (HEAP1, PIT1)
            -> (HS, HEAP2)
            -> (HEAP1, HEAP2)

        All active exclusive groups:
        (DSI, PIT2)
        (HS, PIT1)
        (DSI, HEAP1)
        (DSI, HEAP2)
        (HEAP1, PIT1)
        (HS, HEAP2)
        (HEAP1, HEAP2)
        (HEAP1, HEAP2, MCE)

        Forced scrap:
        (HS, MCE)

        Available scrap:
        (HEAP1, HEAP2, HS, PAS, MCE, DSI)

        Restricted active groups:
        (DSI,)      // availability
        (HS,)       // availability
        (DSI, HEAP1)
        (DSI, HEAP2)
        (HEAP1,)    // availability
        (HS,)       // forced scrap
        (HEAP1, HEAP2)
        (MCE,)      // forced scrap

        Potentially invalid top-level selectors:
        {'HEAP2', 'HEAP1', 'DSI', 'MCE', 'HS'}
        {'HS', 'MCE', 'HEAP1', 'DSI'}

        (sub)selectors:
            TBD
        """
        input_data = finalize_input_data(INPUT_DATA, self.available_scraps, self.forced_scrap, self.groups)

        self.assertEquivalent(
            {item.scrap_types for item in get_active_original_scrap_exclusive_groups(input_data)},
            {
                (DSI, PIT2),
                (HS, PIT1),
                (HEAP1, HEAP2, MCE),
            },
        )

        self.assertEquivalent(
            {item.scrap_types for item in get_active_derived_scrap_exclusive_groups(input_data)},
            {
                (DSI, HEAP1),
                (DSI, HEAP2),
                (HEAP1, PIT1),
                (HS, HEAP2),
                (HEAP1, HEAP2),
            },
        )

        free_scrap, bound_scrap_space = get_exclusive_scrap_space(input_data)
        self.assertEqual(free_scrap, (PAS,))

        actual_bound_scrap_space = set(frozenset(combination) for combination in bound_scrap_space)
        expected_bound_scrap_space = {
            (MCE, HS, DSI),
            (HS, MCE),
        }
        self.assertEquivalent(actual_bound_scrap_space, expected_bound_scrap_space)

    def test_exclusive_groups_and_lower_limit_interplay(self):
        """
        Check that every "exclusive space" (bound space + free space)
        is compatible with at least 1 lower limit
        """
        group_1 = ScrapExclusiveGroup("group_1", (HS, MCE))

        group_2 = ScrapExclusiveGroup("group_2", (HS, HEAP2))

        lower_limit_1 = RelaxableLowerSummingLimit(
            "limit_1",
            scrap_types=(MCE, PAS),
            weight_limit=RelaxableValue(1000, 0),
            ratio=RelaxableValue(0.1, 0),
        )

        lower_limit_2 = RelaxableLowerSummingLimit(
            "limit_2",
            scrap_types=(HS,),
            weight_limit=RelaxableValue(1000, 0),
            ratio=RelaxableValue(0.1, 0),
        )

        tmp_input_data = finalize_input_data(
            INPUT_DATA, self.available_scraps, forced_scrap=(), exclusive_groups=(group_1, group_2)
        )
        tmp_first_heat = tmp_input_data.heats[0]

        first_heat = attr.evolve(tmp_first_heat, relaxable_lower_summing_limits=(lower_limit_1,))
        input_data = attr.evolve(tmp_input_data, heats=(first_heat,))

        free_scrap, bound_scrap_space = get_exclusive_scrap_space(input_data)

        mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping

        for selector in bound_scrap_space:
            self.assertFalse(
                all(
                    are_disjoint(selector + free_scrap, limit, mix_mapping)
                    for limit in (lower_limit_1, lower_limit_2)
                ),
            )


if __name__ == "__main__":
    unittest.main()
