import logging
import unittest
from datetime import date

from usskssgrades import SteelGradesHardcoded
from scrap_core.datamodel.model import ChemAnalysis, find_missed_chems
from scrap_core import SUPPORTED_CHEMS

grades = SteelGradesHardcoded(SUPPORTED_CHEMS)

# TODO: Add more tests


class TestChemicalAnalysisValidationByGrades(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        logging.disable(logging.ERROR)

    @classmethod
    def tearDownClass(cls) -> None:
        logging.disable(logging.NOTSET)
        super().tearDownClass()

    def test_simple_validation(self):
        grade_494 = grades.get_grade_from_id(494, date.today())
        chem = ChemAnalysis(
            C=0.06,
            Mn=0.3,
            Si=0.01,
            P=0.015,
            S=0.0021,
            Al=0.03,
            N=0.003,
            Cu=0.01,
            Ni=0.0,
            Cr=0.03,
            As=0.01,
            Sn=0.01,
            Mo=0.001,
            Ti=0.003,
            V=0,
            Zr=0,
            Nb=0.03,
            time_of_analysis="final",
        )
        self.assertEqual(find_missed_chems(chem, grade_494)[0], ())

    def test_multiple_error_validation(self):
        grade_494 = grades.get_grade_from_id(494, date.today())
        chem = ChemAnalysis(
            C=1,
            Mn=1,
            Si=0.01,
            P=0.015,
            S=0.0021,
            Al=0.03,
            N=0.003,
            Cu=0.01,
            Ni=0.0,
            Cr=0.03,
            As=0.01,
            Sn=0.01,
            Mo=0.001,
            Ti=0.003,
            V=0,
            Zr=0,
            Nb=0.03,
            time_of_analysis="final",
        )
        self.assertEqual(
            find_missed_chems(chem, grade_494)[0],
            (
                "C",
                "Mn",
            ),
        )

    def test_more_than_max_validation(self):
        grade_494 = grades.get_grade_from_id(494, date.today())
        chem = ChemAnalysis(
            C=0.1,
            Mn=0.3,
            Si=0.01,
            P=0.015,
            S=0.0021,
            Al=0.03,
            N=0.003,
            Cu=0.01,
            Ni=0.0,
            Cr=0.03,
            As=0.01,
            Sn=0.01,
            Mo=0.001,
            Ti=0.003,
            V=0,
            Zr=0,
            Nb=0.03,
            time_of_analysis="final",
        )
        self.assertEqual(
            find_missed_chems(chem, grade_494)[0],
            ("C",),
        )

    def test_less_than_min_validation(self):
        grade_494 = grades.get_grade_from_id(494, date.today())
        chem = ChemAnalysis(
            C=0.002,
            Mn=0.3,
            Si=0.01,
            P=0.015,
            S=0.0021,
            Al=0.03,
            N=0.003,
            Cu=0.01,
            Ni=0.0,
            Cr=0.03,
            As=0.01,
            Sn=0.01,
            Mo=0.001,
            Ti=0.003,
            V=0,
            Zr=0,
            Nb=0.03,
            time_of_analysis="final",
        )
        self.assertEqual(
            find_missed_chems(chem, grade_494)[0],
            ("C",),
        )
