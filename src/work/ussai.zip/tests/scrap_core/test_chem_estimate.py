import unittest

from hypothesis import given
from hypothesis.strategies import floats
import torch

from scrap_core.blendmodel.datamodel import OrdinalRegressionChemEstimate


class TestOrdinalRegressionChemEstimate(unittest.TestCase):
    def test_zero(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))
        result = estimate.cdf_unsafe(torch.Tensor([0.0]))
        self.assertAlmostEqual(float(result[0]), 0.0, 10)

    def test_bin_border(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))
        result = estimate.cdf_unsafe(torch.Tensor([0.0, 1.0, 2.0, 3.0, 100.0, 200.0, float("inf")]))
        self.assertAlmostEqual(float(result[0]), 0.0, 7)
        self.assertAlmostEqual(float(result[1]), 0.1, 7)
        self.assertAlmostEqual(float(result[2]), 0.3, 7)
        self.assertAlmostEqual(float(result[3]), 0.6, 7)
        self.assertAlmostEqual(float(result[4]), 1.0, 7)
        self.assertAlmostEqual(float(result[5]), 1.0, 7)
        self.assertAlmostEqual(float(result[6]), 1.0, 7)

    def test_interpolation_border(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))
        result = estimate.cdf_unsafe(torch.Tensor([0.5, 1.2, 10.0]))
        self.assertAlmostEqual(float(result[0]), 0.05, 7)
        self.assertAlmostEqual(float(result[1]), 0.14, 7)
        self.assertAlmostEqual(float(result[2]), 0.6, 5)

    def test_negative(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))
        result = estimate.cdf_unsafe(torch.Tensor([-10.0]))
        self.assertAlmostEqual(float(result[0]), 0.0, 10)

    def test_one_number(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))
        result = estimate.cdf(1.0)
        self.assertAlmostEqual(result, 0.1, 7)

    def test_simple_cdf(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))

        self.assertAlmostEqual(estimate.cdf(0), 0, 5)
        self.assertAlmostEqual(estimate.cdf(0.5), 0.05, 5)
        self.assertAlmostEqual(estimate.cdf(1), 0.1, 5)
        self.assertAlmostEqual(estimate.cdf(1.75), 0.25, 5)
        self.assertAlmostEqual(estimate.cdf(2 + 2 / 3), 0.5, 5)
        self.assertAlmostEqual(estimate.cdf(3), 0.6, 5)
        self.assertAlmostEqual(estimate.cdf(3.1), 0.6, 5)
        self.assertAlmostEqual(estimate.cdf(float("inf")), 1, 5)

    def test_simple_percentiles(self):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))

        self.assertAlmostEqual(estimate.percentile(0), 0, 5)
        self.assertAlmostEqual(estimate.percentile(0.05), 0.5, 5)
        self.assertAlmostEqual(estimate.percentile(0.1), 1, 5)
        self.assertAlmostEqual(estimate.percentile(0.25), 1.75, 5)
        self.assertAlmostEqual(estimate.percentile(0.5), 2 + 2 / 3, 5)
        self.assertAlmostEqual(estimate.percentile(0.6), 3, 5)
        self.assertAlmostEqual(estimate.percentile(0.6000000000000002), 100, 5)
        self.assertAlmostEqual(estimate.percentile(0.9), 100, 5)
        self.assertAlmostEqual(estimate.percentile(1), 100, 5)

    @given(floats(0, 0.6))
    def test_percentiles(self, probability):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))

        value = estimate.percentile(probability)

        self.assertAlmostEqual(probability, estimate.cdf(value), places=5)

    # this ridiculous min is due to python float arithmetic, in particular
    # 0.1 + 0.2 + 0.3 = 0.6000000000000001
    @given(floats(0.1 + 0.2 + 0.3, 1, exclude_min=True))
    def test_percentiles_last_bin(self, probability):
        estimate = OrdinalRegressionChemEstimate((1.0, 2.0, 3.0), (0.1, 0.2, 0.3, 0.4))

        value = estimate.percentile(probability)

        self.assertAlmostEqual(1, estimate.cdf(value), places=5)


if __name__ == "__main__":
    unittest.main()
