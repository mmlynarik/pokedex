# pylint: disable=no-member
import unittest
from datetime import date
from typing import Tuple

import attr
import torch
from hypothesis import given
from hypothesis.strategies import floats
from immutables import Map
from usskssgrades.grade import DISALLOWED_REBLOW_DUE_CR_GRADES

from scrap_core import Chem
from scrap_core.blendmodel import (
    OrdinalRegressionChemEstimate,
    ScrapBlendModelInput,
    ScrapBlendModelOutput,
    get_blend_model,
    get_full_binning,
)
from scrap_core.blendmodel.datamodel import cdf_batch, get_synthetic_chem_estimate, get_uniform_chem_estimate
from scrap_core.blendmodel.eob_config import BINNING, EOB_MODEL_SUPPORTED_CHEMS
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    CorrectionTechnologyType,
    get_corr_tech_model,
)
from scrap_core.correctiontechnologiesmodel.correction_technologies import (
    get_correction_technologies_for_grade,
)
from scrap_core.datamodel import RawFeChem
from usskssgrades import ChemLimit, Grade, SteelGradesHardcoded

from . import get_uniform_binning

# Following values are calculated as maximal limits of all available grades
# at 2021-09-09 (except for 333)
GRADE_LIMIT_MAX = {
    "Cr": 1.15,
    "Cu": 0.55,
    "Mo": 0.354,
    "Ni": 0.305,
    "P": 0.2,
    "S": 0.08,
    "Si": 3.25,
    "Sn": 0.11,
}


class TestCorrTechModel(unittest.TestCase):
    def check_probas_are_one_for_keys_and_zero_for_other(self, output, expected_keys):
        for expected_key in expected_keys:
            self.assertIn(expected_key, output.correction_technologies_probas)
            self.assertAlmostEqual(output.correction_technologies_probas[expected_key], 1.0, places=4)
        for key, value in output.correction_technologies_probas.items():
            if key not in expected_keys:
                self.assertAlmostEqual(value, 0.0, places=4)

    def test_grade_limit_in_last_bin_with_high_sn(self):
        """
        Real life example: Last bin for Sn is [0.023, 0.22) and limit for grade 595 is 0.05.
        A heat with 146t of pig iron, 3t of HSB, 37t of HST and 4t of MCE has expected value of Sn
        higher than the limit. Thus we expect high probability of reclassification.
        """
        grade_595 = SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(
            595, date.today()
        )

        eob_model = get_blend_model(version=2)

        scrap_map = {"HSB": 3000, "HST": 37000, "MCE": 4000}

        eob_model_input = ScrapBlendModelInput(
            raw_fe_weight=146000,
            raw_fe_chem=RawFeChem(),
            scrap_weights=Map(scrap_map),
            pellets_weight=0,
            briquetes_weight=0,
        )
        eob_model_output = eob_model.calculate(eob_model_input)

        ct_model_input = CorrectionTechnologiesModelInput(grade_595, eob_model_output)

        ct_model = get_corr_tech_model(1, frozenset(["Sn"]))

        ct_model_output = ct_model.calculate(ct_model_input)

        reclassification_probability = ct_model_output.correction_technologies_probas[
            (CorrectionTechnologyType.RECLASSIFICATION, 1)
        ]

        self.assertGreater(reclassification_probability, 0.9)

    def test_grade_limit_in_last_bin_high_mo_grade_limit(self):
        grade_595 = SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(
            595, date.today()
        )

        eob_model = get_blend_model(version=2)

        # This should be very safe
        scrap_map = {"HS": 40000}

        eob_model_input = ScrapBlendModelInput(
            raw_fe_weight=150000,
            raw_fe_chem=RawFeChem(),
            scrap_weights=Map(scrap_map),
            pellets_weight=0,
            briquetes_weight=0,
        )
        eob_model_output = eob_model.calculate(eob_model_input)

        ct_model_input = CorrectionTechnologiesModelInput(grade_595, eob_model_output)

        ct_model = get_corr_tech_model(1, frozenset(["Mo"]))

        ct_model_output = ct_model.calculate(ct_model_input)

        reclassification_probability = ct_model_output.correction_technologies_probas[
            (CorrectionTechnologyType.RECLASSIFICATION, 1)
        ]

        self.assertLess(reclassification_probability, 0.015)

    def test_edge_case_reclassification(self):
        """
        Check that even grades with the highest possible limits are reclassified,
        if probability of the last bin is 1.
        """
        uniform_binning = get_uniform_binning(0.1, 0.2, 0.01)
        dummy_estimate = get_synthetic_chem_estimate(uniform_binning, 0)

        def get_estimate(expected_chem: str, chem_: str) -> OrdinalRegressionChemEstimate:
            if chem_ != expected_chem:
                return dummy_estimate

            return OrdinalRegressionChemEstimate(BINNING[chem_], (0,) * len(BINNING[chem_]) + (1,))

        for chem in EOB_MODEL_SUPPORTED_CHEMS:
            with self.subTest(msg=f"{chem}"):
                limits = (ChemLimit(chem=chem, minimum=0.0, maximum=GRADE_LIMIT_MAX[chem]),)
                if chem != "S":
                    limits += (ChemLimit(chem="S", minimum=0.0, maximum=0.012),)  # type: ignore

                if chem != "Si":
                    limits += (ChemLimit(chem="Si", minimum=0.0, maximum=0.012),)  # type: ignore

                model_input = CorrectionTechnologiesModelInput(
                    Grade(
                        grade_id=0,
                        display_name="test_grade",
                        limits=limits,
                        is_calmed=True,
                        min_synt_slag=200.0,
                    ),
                    ScrapBlendModelOutput(
                        S=get_estimate("S", chem),
                        Si=get_estimate("Si", chem),
                        Cu=get_estimate("Cu", chem),
                        Ni=get_estimate("Ni", chem),
                        Cr=get_estimate("Cr", chem),
                        Mo=get_estimate("Mo", chem),
                        Sn=get_estimate("Sn", chem),
                    ),
                )

                model = get_corr_tech_model(1, frozenset([chem]))

                output = model.calculate(model_input)

                # With 0.2 probability of the right half of the last bin specified
                # in `bin_cdf` we get at least 0.18 probability of undesired corr tech
                # even for grades with high limit
                self.assertGreaterEqual(output.undesirable_corr_tech_proba, 0.18)

    def test_model_no_corrtech_with_min_synt_slag(self):
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.NO_CORRECTION, 1.0),
        ]
        self.check_probas_are_one_for_keys_and_zero_for_other(output, expected_keys)

    def test_model_no_corrtech_wo_min_synt_slag(self):
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=0.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_key = (CorrectionTechnologyType.NO_CORRECTION, 1.0)
        self.check_probas_are_one_for_keys_and_zero_for_other(output, [expected_key])

    def test_model_no_corrtech_wo_min_synt_slag_wo_s(self):
        uniform_binning = get_uniform_binning(0.1, 1, 0.1)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=0.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 1),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_key = (CorrectionTechnologyType.NO_CORRECTION, 1.0)
        self.check_probas_are_one_for_keys_and_zero_for_other(output, [expected_key])

    def test_model_no_corrtech_min_synt_slag_wo_s(self):
        uniform_binning = get_uniform_binning(0.1, 1, 0.1)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 1),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.NO_CORRECTION, 1.0),
        ]
        self.check_probas_are_one_for_keys_and_zero_for_other(output, expected_keys)

    def test_model_reclassification_with_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.1, 1, 0.1)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 1),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.RECLASSIFICATION, 1.0),
        ]
        self.check_probas_are_one_for_keys_and_zero_for_other(output, expected_keys)

    def test_model_reclassification_wo_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.1, 1, 0.1)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=0.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 1),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_key = (CorrectionTechnologyType.RECLASSIFICATION, 1.0)
        self.check_probas_are_one_for_keys_and_zero_for_other(output, [expected_key])

    def test_model_synt_slag_with_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.01, 0.02, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.0125),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.SYNT_SLAG, 1000.0),
        ]
        self.check_probas_are_one_for_keys_and_zero_for_other(output, expected_keys)

    def test_model_synt_slag_wo_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.01, 0.02, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=0.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.0125),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_key = (CorrectionTechnologyType.SYNT_SLAG, 1000.0)
        self.check_probas_are_one_for_keys_and_zero_for_other(output, [expected_key])

    def test_model_reblow_with_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.01, 0.02, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.0155),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.REBLOW, 1.0),
        ]
        self.check_probas_are_one_for_keys_and_zero_for_other(output, expected_keys)

    def test_model_reblow_wo_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.01, 0.02, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.002, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=0.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.0155),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_key = (CorrectionTechnologyType.REBLOW, 1.0)
        self.check_probas_are_one_for_keys_and_zero_for_other(output, [expected_key])

    def test_model_two_cortechs_with_min_synt_slag(self):
        uniform_binning = get_uniform_binning(0.01, 0.03, 0.01)
        small_uniform_binning = get_uniform_binning(0.001, 0.003, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.014),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.0146),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)

        expected_keys = [
            (CorrectionTechnologyType.SYNT_SLAG, 1000.0),
            (CorrectionTechnologyType.NO_CORRECTION, 1.0),
        ]

        for expected_key in expected_keys:
            self.assertIn(expected_key, output.correction_technologies_probas)

        self.assertGreater(
            output.correction_technologies_probas[(CorrectionTechnologyType.SYNT_SLAG, 1000.0)], 0
        )
        self.assertGreater(
            output.correction_technologies_probas[(CorrectionTechnologyType.NO_CORRECTION, 1.0)],
            0,
        )

    def test_disallows_reblow_for_selected_heat_wrt_chromium(self):
        grade_id = 1
        model_input = CorrectionTechnologiesModelInput(
            grade=Grade(
                grade_id=grade_id,  # reblow is not allowed for given grade
                display_name="test_grade",
                limits=(ChemLimit(chem="S", minimum=0.0, maximum=0.006),),
                is_calmed=False,
                min_synt_slag=200.0,
            ),
            eob_chem=ScrapBlendModelOutput(
                S=get_uniform_chem_estimate(BINNING["S"]),
                Si=get_uniform_chem_estimate(BINNING["Si"]),
                Cu=get_uniform_chem_estimate(BINNING["Cu"]),
                Ni=get_uniform_chem_estimate(BINNING["Ni"]),
                Cr=get_uniform_chem_estimate(BINNING["Cr"]),
                Mo=get_uniform_chem_estimate(BINNING["Mo"]),
                Sn=get_uniform_chem_estimate(BINNING["Sn"]),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)
        self.assertIn(grade_id, DISALLOWED_REBLOW_DUE_CR_GRADES)
        self.assertNotIn((CorrectionTechnologyType.REBLOW, 1.0), output.correction_technologies_probas)

    def test_low_N_grade_disallows_reblow(self):
        """Test if grade with N limit <= 0.0054 does not allow reblow corr tech."""
        model_input = CorrectionTechnologiesModelInput(
            grade=Grade(
                grade_id=20,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.006),
                    ChemLimit(chem="N", minimum=0, maximum=0.005),
                ),
                is_calmed=False,
                min_synt_slag=200.0,
            ),
            eob_chem=ScrapBlendModelOutput(
                S=get_uniform_chem_estimate(BINNING["S"]),
                Si=get_uniform_chem_estimate(BINNING["Si"]),
                Cu=get_uniform_chem_estimate(BINNING["Cu"]),
                Ni=get_uniform_chem_estimate(BINNING["Ni"]),
                Cr=get_uniform_chem_estimate(BINNING["Cr"]),
                Mo=get_uniform_chem_estimate(BINNING["Mo"]),
                Sn=get_uniform_chem_estimate(BINNING["Sn"]),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)
        self.assertNotIn((CorrectionTechnologyType.REBLOW, 1.0), output.correction_technologies_probas)

    def test_keep_reblow_for_not_low_N_grade(self):
        """Test if grade with N limit > 0.0054 allows reblow corr tech."""
        model_input = CorrectionTechnologiesModelInput(
            grade=Grade(
                grade_id=20,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.006),
                    ChemLimit(chem="N", minimum=0, maximum=0.007),
                ),
                is_calmed=False,
                min_synt_slag=200.0,
            ),
            eob_chem=ScrapBlendModelOutput(
                S=get_uniform_chem_estimate(BINNING["S"]),
                Si=get_uniform_chem_estimate(BINNING["Si"]),
                Cu=get_uniform_chem_estimate(BINNING["Cu"]),
                Ni=get_uniform_chem_estimate(BINNING["Ni"]),
                Cr=get_uniform_chem_estimate(BINNING["Cr"]),
                Mo=get_uniform_chem_estimate(BINNING["Mo"]),
                Sn=get_uniform_chem_estimate(BINNING["Sn"]),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        output = model.calculate(model_input)
        self.assertGreater(output.correction_technologies_probas[(CorrectionTechnologyType.REBLOW, 1.0)], 0)

    def test_calculate_batch(self):
        uniform_binning = get_uniform_binning(0.01, 0.015, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.003, 0.001)

        model_input = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.012),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))
        inputs = [model_input for __ in range(10)]
        results = model.calculate_batch(inputs)

        self.assertEqual(len(results), len(inputs))
        # Check that all results are the same, as inputs are the same.
        for idx in range(1, len(results)):
            self.assertEqual(results[idx], results[0])

    def test_calculate_batch_with_different_grade(self):
        uniform_binning = get_uniform_binning(0.01, 0.015, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.003, 0.001)

        model_input_1 = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=202,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.012),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )
        model_input_2 = CorrectionTechnologiesModelInput(
            Grade(
                grade_id=203,
                display_name="test_grade",
                limits=(
                    ChemLimit(chem="S", minimum=0.0, maximum=0.010),
                    ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                    ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
                ),
                is_calmed=True,
                min_synt_slag=200.0,
            ),
            ScrapBlendModelOutput(
                S=get_synthetic_chem_estimate(uniform_binning, 0.010),
                Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
                Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
            ),
        )

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))
        inputs = [model_input_1 for __ in range(5)] + [model_input_2 for __ in range(5)]
        results = model.calculate_batch_for_multiple_grades(inputs)
        normal_result = [model.calculate(i) for i in inputs]

        with self.assertRaises(ValueError):
            model.calculate_batch(inputs)

        self.assertEqual(len(results), len(inputs))
        for normal_res, batch_res in zip(normal_result, results):
            self.assertEqual(normal_res, batch_res)

    def test_calculate_invalid_batch(self):
        uniform_binning = get_uniform_binning(0.01, 0.015, 0.001)
        small_uniform_binning = get_uniform_binning(0.001, 0.003, 0.001)

        grade = Grade(
            grade_id=202,
            display_name="test_grade",
            limits=(
                ChemLimit(chem="S", minimum=0.0, maximum=0.012),
                ChemLimit(chem="P_blow", minimum=0.0, maximum=0.015),
                ChemLimit(chem="Si", minimum=0.0, maximum=0.02),
            ),
            is_calmed=True,
            min_synt_slag=200.0,
        )
        model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, 0.012),
            Si=get_synthetic_chem_estimate(small_uniform_binning, 0),
            Cu=get_synthetic_chem_estimate(small_uniform_binning, 0),
            Ni=get_synthetic_chem_estimate(small_uniform_binning, 0),
            Cr=get_synthetic_chem_estimate(small_uniform_binning, 0),
            Mo=get_synthetic_chem_estimate(small_uniform_binning, 0),
            Sn=get_synthetic_chem_estimate(small_uniform_binning, 0),
        )

        model_input_1 = CorrectionTechnologiesModelInput(grade, model_output)

        model_input_2 = CorrectionTechnologiesModelInput(attr.evolve(grade, grade_id=0), model_output)

        model = get_corr_tech_model(1, frozenset(["S", "Cu", "Ni", "Cr", "Mo", "Sn"]))

        # Check exception, if inputs have different grades.
        with self.assertRaises(ValueError):
            model.calculate_batch([model_input_1, model_input_2])

    # pylint: disable=too-many-locals, too-many-arguments
    @given(floats(0, 1), floats(0, 1), floats(0, 1), floats(0, 1), floats(0, 1), floats(0, 1), floats(0, 1))
    def test_calculate_batch_fast_vs_classic(
        self, s_real, si_real, cu_real, ni_real, cr_real, mo_real, sn_real
    ):
        uniform_binning = get_uniform_binning(0.001, 0.015, 0.001)
        grade = SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(595, date.today())

        eob_model_output = ScrapBlendModelOutput(
            S=get_synthetic_chem_estimate(uniform_binning, s_real),
            Si=get_synthetic_chem_estimate(uniform_binning, si_real),
            Cu=get_synthetic_chem_estimate(uniform_binning, cu_real),
            Ni=get_synthetic_chem_estimate(uniform_binning, ni_real),
            Cr=get_synthetic_chem_estimate(uniform_binning, cr_real),
            Mo=get_synthetic_chem_estimate(uniform_binning, mo_real),
            Sn=get_synthetic_chem_estimate(uniform_binning, sn_real),
        )

        model_input = CorrectionTechnologiesModelInput(grade, eob_model_output)

        predicted_chems: Tuple[Chem, ...] = ("S", "Cu", "Ni", "Cr", "Mo", "Si", "Sn")

        full_binning_map = Map(
            {
                chem: get_full_binning(model_input.eob_chem.get_chem_estimate(chem).binning)  # type: ignore
                for chem in predicted_chems
            }
        )

        model = get_corr_tech_model(1, frozenset(predicted_chems), full_binning_map)

        inputs = [model_input for __ in range(10)]
        classic_results = model.calculate_batch(inputs)
        eob_proba_matrix_map = {
            chem: torch.stack(  # pylint: disable=no-member
                [
                    torch.Tensor(eob_model_output.get_chem_estimate(chem).probas)  # type: ignore
                    for _ in range(10)
                ]
            )
            for chem in predicted_chems
        }

        fast_results = model.calculate_batch_fast(eob_proba_matrix_map, model_input.grade)

        ct_ranks = get_correction_technologies_for_grade(grade).get_corr_tech_ranks(predicted_chems)

        _, ncols = fast_results.shape

        self.assertEqual(len(ct_ranks), ncols)

        fast_results_converted = [dict(zip(ct_ranks, row)) for row in fast_results]

        for classic, fast in zip(classic_results, fast_results_converted):
            self.assertDictEqual(dict(classic.correction_technologies_probas), dict(fast))

    # pylint: disable=too-many-locals, too-many-arguments
    @given(floats(0.1, 1), floats(0.1, 1), floats(0.1, 1), floats(0.0, 1.0))
    def test_calculate_batch_fast_vs_classic2(self, scrap1, scrap2, scrap3, value):
        blend_model = get_blend_model(2)

        scrap1w = 40000 * (scrap1 / (scrap1 + scrap2 + scrap3))
        scrap2w = 40000 * (scrap2 / (scrap1 + scrap2 + scrap3))
        scrap3w = 40000 * (scrap3 / (scrap1 + scrap2 + scrap3))

        blend_model_inputs = [
            ScrapBlendModelInput(
                150000, RawFeChem(S=0.002), Map({"TBC": scrap1w, "HS": scrap2w, "PAS": scrap3w}), 0.0, 0.0
            ),
            ScrapBlendModelInput(
                150000, RawFeChem(S=0.002), Map({"DSI": scrap1w, "2HM": scrap2w, "MCE": scrap3w}), 0.0, 0.0
            ),
            ScrapBlendModelInput(
                150000, RawFeChem(S=0.002), Map({"1HM": scrap1w, "1RR": scrap2w, "HS": scrap3w}), 0.0, 0.0
            ),
            ScrapBlendModelInput(
                150000, RawFeChem(S=0.002), Map({"HSB": scrap1w, "HS": scrap2w, "PAS": scrap3w}), 0.0, 0.0
            ),
            ScrapBlendModelInput(
                150000, RawFeChem(S=0.002), Map({"SHS": scrap1w, "PAS": scrap2w, "MCE": scrap3w}), 0.0, 0.0
            ),
        ]

        eob_outputs = blend_model.calculate_batch(blend_model_inputs)
        predicted_chems: Tuple[Chem, ...] = ("S", "Cu", "Ni", "Cr", "Mo", "Si", "Sn")

        for chem in predicted_chems:
            cdfs = [bmo.get_chem_estimate(chem).cdf(value) for bmo in eob_outputs]
            probas = torch.stack(
                [torch.Tensor(bmo.get_chem_estimate(chem).probas) for bmo in eob_outputs]  # type: ignore
            )
            binning = get_full_binning(eob_outputs[0].get_chem_estimate(chem).binning)  # type: ignore
            batch_result = list(cdf_batch(value, probas, binning))
            for res1, res2 in zip(cdfs, batch_result):
                self.assertAlmostEqual(res1, float(res2), 5)


if __name__ == "__main__":
    unittest.main()
