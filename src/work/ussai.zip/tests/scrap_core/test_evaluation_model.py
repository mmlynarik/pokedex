import unittest

from scrap_core.evaluation import calculate_effective_lower_bound


# Tuple in this tests are lower bounds and results
class TestEffectiveLowerBoundCalculation(unittest.TestCase):
    def test_only_one_optimization(self):
        self.assertEqual(calculate_effective_lower_bound([(0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(2, 4)]), 0)
        # This test case is debatable - this should never happen - but for the future
        # if we would somehow change limits this should be consistent with definition
        # of effective lower bound
        self.assertEqual(calculate_effective_lower_bound([(2, 1)]), 1)

    def test_two_optimizations(self):
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (0, 0)]), 0)
        # Below is the most important case
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (2, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (2, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (2, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (3, 3)]), 3)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (3, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (3, 1)]), 1)

        self.assertEqual(calculate_effective_lower_bound([(0, 0), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 0), (0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 0), (2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(0, 0), (2, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 0), (2, 1)]), 1)

        self.assertEqual(calculate_effective_lower_bound([(2, 2), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (2, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (2, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (3, 3)]), 3)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (3, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (3, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (1, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (1, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 2), (1, 0)]), 0)

        self.assertEqual(calculate_effective_lower_bound([(2, 4), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (2, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (2, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (3, 3)]), 3)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (3, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (3, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (1, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (1, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (1, 0)]), 0)

        self.assertEqual(calculate_effective_lower_bound([(2, 1), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (2, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (2, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (3, 3)]), 3)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (3, 4)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (3, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (1, 1)]), 1)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (1, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(2, 1), (1, 0)]), 0)

    def test_three_optimizations(self):
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (0, 2), (0, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (0, 0), (0, 0)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 2), (0, 2), (2, 2)]), 0)
        self.assertEqual(calculate_effective_lower_bound([(0, 4), (2, 4), (6, 6)]), 6)
        self.assertEqual(calculate_effective_lower_bound([(2, 4), (4, 4), (6, 6)]), 6)
        self.assertEqual(calculate_effective_lower_bound([(6, 6), (4, 4), (2, 2)]), 2)
        self.assertEqual(calculate_effective_lower_bound([(0, 4), (4, 5), (4, 5)]), 0)
