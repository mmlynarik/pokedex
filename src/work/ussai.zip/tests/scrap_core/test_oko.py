import logging
import unittest

import pandas as pd
from attr_runtime_validation.validators import ValidationError

from usskssgrades import SteelGradesHardcoded
from scrap_core.datamodel.model import Heat
from scrap_core import SUPPORTED_CHEMS
from scrap_core.datamodel.oko import (
    validate_oko_env_config,
    get_tap_alloys_weight,
    parse_one_heat,
)

from . import (
    ARTIFICIAL_HEAT_INVALID_SCRAP_TYPES,
    HEAT_47166_2019_INCORRECT_DATA,
    HEAT_52233_2020_CORRECT_DATA,
)

steel_grades = SteelGradesHardcoded(SUPPORTED_CHEMS)


class TestOko(unittest.TestCase):
    def test_parse_one_heat_check_output_values_correct(self):
        db_data = pd.read_csv(HEAT_52233_2020_CORRECT_DATA)
        heat, error = parse_one_heat(db_data, steel_grades)

        self.assertIsNone(error)
        self.assertIsNotNone(heat)
        self.assertIsInstance(heat, Heat)

    def test_parse_one_heat_check_output_values_incorrect(self):
        db_data = pd.read_csv(HEAT_47166_2019_INCORRECT_DATA)
        heat, error = parse_one_heat(db_data, steel_grades)

        self.assertIsNone(heat)
        self.assertIsNotNone(error)
        self.assertTrue(isinstance(error, str))

        heat_no_validation, error_no_validation = parse_one_heat(db_data, steel_grades, False)
        self.assertIsNotNone(heat_no_validation)
        self.assertIsNone(error_no_validation)

    def test_parse_one_heat_check_values_incorrect(self):
        db_data = pd.read_csv(HEAT_47166_2019_INCORRECT_DATA)
        heat_no_validation, _ = parse_one_heat(db_data, steel_grades, False)

        if heat_no_validation is not None:
            self.assertAlmostEqual(heat_no_validation.heat_datetime, 1549071300.0)
            with self.assertRaises(ValidationError):
                _ = heat_no_validation.after_desulf
            try:
                heat_no_validation.disable_on_access_validation()
                self.assertAlmostEqual(heat_no_validation.after_desulf.S, 0.002)
            finally:
                heat_no_validation.enable_on_access_validation()

    def test_parse_one_heat_check_output_values_type_err(self):
        heat, error = parse_one_heat(None, steel_grades)
        self.assertIsNone(heat)
        self.assertIsNotNone(error)
        self.assertTrue(isinstance(error, str))

    def test_parser_one_heat_after_desulf_chem_analysis(self):
        db_data = pd.read_csv(HEAT_52233_2020_CORRECT_DATA)
        heat, _ = parse_one_heat(db_data, steel_grades)

        if heat is None:
            return

        self.assertAlmostEqual(heat.after_desulf.C, 4.529, 9)
        self.assertAlmostEqual(heat.after_desulf.Mn, 0.454, 9)
        self.assertAlmostEqual(heat.after_desulf.Si, 0.769, 9)
        self.assertAlmostEqual(heat.after_desulf.P, 0.050, 9)
        self.assertAlmostEqual(heat.after_desulf.S, 0.002, 9)
        self.assertAlmostEqual(heat.after_desulf.Al, 0.002, 9)
        self.assertAlmostEqual(heat.after_desulf.N, 0.0, 9)
        self.assertAlmostEqual(heat.after_desulf.Cu, 0.005, 9)
        self.assertAlmostEqual(heat.after_desulf.Ni, 0.005, 9)
        self.assertAlmostEqual(heat.after_desulf.Cr, 0.007, 9)
        self.assertAlmostEqual(heat.after_desulf.As, 0.001, 9)
        self.assertAlmostEqual(heat.after_desulf.Sn, 0.001, 9)
        self.assertAlmostEqual(heat.after_desulf.Mo, 0.002, 9)
        self.assertAlmostEqual(heat.after_desulf.Ti, 0.024, 9)
        self.assertAlmostEqual(heat.after_desulf.V, 0.005, 9)
        self.assertAlmostEqual(heat.after_desulf.Zr, 0.001, 9)
        self.assertAlmostEqual(heat.after_desulf.Nb, 0.002, 9)

    def test_parser_one_heat_check_eob_chem_analysis_value(self):
        db_data = pd.read_csv(HEAT_52233_2020_CORRECT_DATA)
        heat, _ = parse_one_heat(db_data, steel_grades)

        if heat is None:
            return

        self.assertAlmostEqual(heat.eob.C, 0.045, 9)
        self.assertAlmostEqual(heat.eob.Mn, 0.140, 9)
        self.assertAlmostEqual(heat.eob.Si, 0.0, 9)
        self.assertAlmostEqual(heat.eob.P, 0.011, 9)
        self.assertAlmostEqual(heat.eob.S, 0.0099, 9)
        self.assertAlmostEqual(heat.eob.Al, 0.207, 9)
        self.assertAlmostEqual(heat.eob.N, 0.0, 9)
        self.assertAlmostEqual(heat.eob.Cu, 0.023, 9)
        self.assertAlmostEqual(heat.eob.Ni, 0.014, 9)
        self.assertAlmostEqual(heat.eob.Cr, 0.017, 9)
        self.assertAlmostEqual(heat.eob.As, 0.008, 9)
        self.assertAlmostEqual(heat.eob.Sn, 0.0, 9)
        self.assertAlmostEqual(heat.eob.Mo, 0.0, 9)
        self.assertAlmostEqual(heat.eob.Ti, 0.0, 9)
        self.assertAlmostEqual(heat.eob.V, 0.0, 9)
        self.assertAlmostEqual(heat.eob.Zr, 0.001, 9)
        self.assertAlmostEqual(heat.eob.Nb, 0.0, 9)

    def test_parser_one_heat_final_chem_analysis(self):
        db_data = pd.read_csv(HEAT_52233_2020_CORRECT_DATA)
        heat, _ = parse_one_heat(db_data, steel_grades)

        if heat is None:
            return

        self.assertAlmostEqual(heat.final.C, 0.08, 9)
        self.assertAlmostEqual(heat.final.Mn, 0.673, 9)
        self.assertAlmostEqual(heat.final.Si, 0.016, 9)
        self.assertAlmostEqual(heat.final.P, 0.014, 9)
        self.assertAlmostEqual(heat.final.S, 0.006, 9)
        self.assertAlmostEqual(heat.final.Al, 0.0290, 9)
        self.assertAlmostEqual(heat.final.N, 0.004, 9)
        self.assertAlmostEqual(heat.final.Cu, 0.022, 9)
        self.assertAlmostEqual(heat.final.Ni, 0.011, 9)
        self.assertAlmostEqual(heat.final.Cr, 0.022, 9)
        self.assertAlmostEqual(heat.final.As, 0.001, 9)
        self.assertAlmostEqual(heat.final.Sn, 0.002, 9)
        self.assertAlmostEqual(heat.final.Mo, 0.003, 9)
        self.assertAlmostEqual(heat.final.Ti, 0.017, 9)
        self.assertAlmostEqual(heat.final.V, 0.002, 9)
        self.assertAlmostEqual(heat.final.Zr, 0.001, 9)
        self.assertAlmostEqual(heat.final.Nb, 0.027, 9)

    def test_parse_one_heat_correct_value(self):
        db_data = pd.read_csv(HEAT_52233_2020_CORRECT_DATA)
        heat, _ = parse_one_heat(db_data, steel_grades)
        series_db_data = db_data.transpose()[0]
        tap_alloys_weight = get_tap_alloys_weight(series_db_data)

        if heat is None:
            return

        self.assertAlmostEqual(tap_alloys_weight, 1700.0, 9)
        self.assertTupleEqual(heat.heat_key, (52233, 2020))
        self.assertAlmostEqual(heat.heat_datetime, 1579836599.0, 9)
        self.assertEqual(heat.furnace, 5)
        self.assertAlmostEqual(heat.slag_s, 0.03, 9)
        self.assertAlmostEqual(heat.raw_fe_weight, 151100, 9)
        self.assertAlmostEqual(heat.o2_pureness, 100.00, 9)
        self.assertFalse(heat.reblow_cause_p)
        self.assertFalse(heat.reblow_cause_s)
        self.assertAlmostEqual(heat.main_o2, 8151.0, 9)
        self.assertAlmostEqual(heat.extra_o2, 0.0, 9)
        self.assertEqual(heat.grade_planned.grade_id, 595)
        self.assertEqual(heat.grade_final.grade_id, 595)
        self.assertAlmostEqual(heat.final_steel_weight, 173400, 9)
        self.assertAlmostEqual(heat.temperature_after_desulf, 1367, 9)
        self.assertAlmostEqual(heat.desulf_slag_weight, 300, 9)
        self.assertAlmostEqual(heat.synt_slag, 1417.0, 9)
        self.assertAlmostEqual(heat.lime, 5373.0, 9)
        self.assertAlmostEqual(heat.magn, 0.0, 9)
        self.assertAlmostEqual(heat.dolo, 3416.0, 9)
        self.assertAlmostEqual(heat.coke, 0.0, 9)
        self.assertAlmostEqual(heat.pellets_weight, 0.0, 9)
        self.assertAlmostEqual(heat.briquets_weight, 596.0, 9)
        self.assertAlmostEqual(heat.returned_steel_weight, 0.0, 9)
        self.assertFalse(heat.vacuum_heat)

    def test_clear_env_config(self):
        oko_db = validate_oko_env_config(
            {
                "drivername": "drivername",
                "host": "host",
                "username": "username",
                "password": "password",
                "database": "database",
                "port": "1234",
            }
        )

        self.assertEqual(oko_db["host"], "host")
        self.assertEqual(oko_db["username"], "username")
        self.assertEqual(oko_db["password"], "password")
        self.assertEqual(oko_db["database"], "database")
        self.assertEqual(oko_db["port"], 1234)

    def test_parse_one_heat_invalid_scrap(self):
        # TODO remove with better test runner - maybe ward ?
        logging.disable(logging.CRITICAL)
        try:
            db_data = pd.read_csv(ARTIFICIAL_HEAT_INVALID_SCRAP_TYPES)
            heat_data, error = parse_one_heat(db_data, steel_grades, True)

            self.assertIsNone(heat_data)
            self.assertIsNotNone(error)
            self.assertTrue(isinstance(error, str))
        finally:
            logging.disable(logging.NOTSET)

    def test_parse_one_heat_invalid_scrap_wo_validation(self):
        # TODO remove with better test runner - maybe ward ?
        logging.disable(logging.CRITICAL)
        try:
            db_data = pd.read_csv(ARTIFICIAL_HEAT_INVALID_SCRAP_TYPES)
            heat_data, error = parse_one_heat(db_data, steel_grades, False)

            self.assertIsNotNone(heat_data)
            self.assertIsNone(error)
            if heat_data is not None:
                heat_data.disable_on_access_validation()
                self.assertEqual(len(heat_data.get_scrap_map()), 2)
                self.assertIn("XXX", heat_data.get_scrap_map())
                self.assertEqual(35200, heat_data.get_scrap_map()["XXX"])
        finally:
            logging.disable(logging.NOTSET)


if __name__ == "__main__":
    unittest.main()
