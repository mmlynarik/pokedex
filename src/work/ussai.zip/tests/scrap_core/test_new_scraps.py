import unittest
from datetime import date

from immutables import Map

from scrap_core.blendmodel.datamodel import ScrapBlendModelInput
from scrap_core.datamodel import RawFeChem
from scrap_core.blendmodel import get_blend_model
from scrap_core.blendmodel.eob_config import EOB_MODEL_SUPPORTED_CHEMS
from scrap_core.correctiontechnologiesmodel.datamodel import CorrectionTechnologiesModelInput
from scrap_core.correctiontechnologiesmodel import get_corr_tech_model
from usskssgrades.steel_grades_hardcoded import SteelGradesHardcoded


class TestNewScraps(unittest.TestCase):
    """Test newly added scrap types HSA, HSCa and DSI A1 3."""

    def setUp(self):
        blend_model = get_blend_model(2)
        blend_model_inputs_hsa = [
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"HSA": 4000}), 0.0, 0.0),
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"HS": 4000}), 0.0, 0.0),
        ]
        blend_model_inputs_hsca = [
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"HSCA": 4000}), 0.0, 0.0),
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"HSR Cr": 4000}), 0.0, 0.0),
        ]
        blend_model_inputs_dsi = [
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"DSI A1 3": 4000}), 0.0, 0.0),
            ScrapBlendModelInput(150000, RawFeChem(S=0.002), Map({"DSI": 4000}), 0.0, 0.0),
        ]
        self.bmo_hsa = blend_model.calculate_batch(blend_model_inputs_hsa)
        self.bmo_hsca = blend_model.calculate_batch(blend_model_inputs_hsca)
        self.bmo_dsi = blend_model.calculate_batch(blend_model_inputs_dsi)

    def test_new_scraps_give_same_blend_model_results(self):
        self.assertEqual(self.bmo_hsa[0], self.bmo_hsa[1])
        self.assertEqual(self.bmo_dsi[0], self.bmo_dsi[1])

        for chem in EOB_MODEL_SUPPORTED_CHEMS:
            for i, j in zip(getattr(self.bmo_hsca[0], chem).probas, getattr(self.bmo_hsca[1], chem).probas):
                self.assertAlmostEqual(i, j, 5)  # See Task #338 for details why assertAlmostEqual is needed

    def test_new_scraps_give_same_corr_tech_model_results(self):
        corr_tech_model = get_corr_tech_model(1, tuple(EOB_MODEL_SUPPORTED_CHEMS))
        grade = SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(248, date.today())

        ctmo_hsa_new = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_hsa[0]))
        ctmo_hsa_old = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_hsa[1]))

        ctmo_hsca_old = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_hsca[0]))
        ctmo_hsca_new = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_hsca[1]))

        ctmo_dsi_new = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_dsi[0]))
        ctmo_dsi_old = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, self.bmo_dsi[1]))

        self.assertEqual(ctmo_hsa_new, ctmo_hsa_old)
        self.assertEqual(ctmo_dsi_new, ctmo_dsi_old)

        for i, j in zip(
            ctmo_hsca_new.correction_technologies_probas.values(),
            ctmo_hsca_old.correction_technologies_probas.values(),
        ):
            self.assertAlmostEqual(i, j, 5)  # See Task #338 for details why assertAlmostEqual is needed


if __name__ == "__main__":
    unittest.main()
