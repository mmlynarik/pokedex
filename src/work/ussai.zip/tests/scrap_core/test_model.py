import unittest
from datetime import datetime

from usskssgrades import ChemLimit, Grade

from attr_runtime_validation.validators import ValidationError
from scrap_core.datamodel.model import ChemAnalysis, Heat, ScrapInput, TimeOfAnalysis
from scrap_core.optimization.datamodel import ScrapMixLimit, ScrapMix, converter


class TestModel(unittest.TestCase):
    def test_chem_analysis(self):
        data = ChemAnalysis(
            C=4.0,
            Mn=4.1,
            Si=12.0,
            P=0.2,
            S=0.15,
            Al=0.17,
            N=7.0,
            Cu=0.12,
            Ni=0.12,
            Cr=0.27,
            As=0.23,
            Sn=0.021,
            Mo=0.1,
            Ti=0.12,
            V=0.11,
            Zr=0.9,
            Nb=0.0,
            time_of_analysis="after_desulf",
        )

        _ = data.C
        with self.assertRaises(ValidationError):
            _ = data.Mn
        with self.assertRaises(ValidationError):
            _ = data.S

    def test_scrap_input(self):
        data = ScrapInput("DSI", 125.0)
        _ = data.kind
        scrap_kind_none = ScrapInput(None, 125.0)
        with self.assertRaises(ValueError):
            _ = scrap_kind_none.kind
        invalid_scrap = ScrapInput("ASD", 125.0)
        with self.assertRaises(ValueError):
            _ = invalid_scrap.kind

    def test_heat(self):
        data = Heat(
            heat_key=(12345, datetime.now().year + 1),  # invalid year
            heat_datetime=1617866183.0,
            furnace=6,  # invalid furnace
            slag_s=123456.0,
            raw_fe_weight=127000.0,
            o2_pureness=123.0,
            reblow_cause_p=False,
            reblow_cause_s=True,
            main_o2=123.0,
            extra_o2=-123.0,  # invalid extra_o2
            grade_planned=Grade(
                132, "str", (ChemLimit("str", 0, 0.15), ChemLimit("str", 0, 0.15)), True, 12.5  # type: ignore
            ),
            grade_final=Grade(132, "str", (ChemLimit("str", 0, 0.15), ChemLimit("str", 0, 0.15)), True, 12.5),  # type: ignore
            final_steel_weight=157000.0,
            steel_weight_from_stand_without_slag=157000.0,
            steel_weight_from_stand_with_slag=157000.0,
            temperature_after_desulf=2100.0,  # invalid temperature
            desulf_slag_weight=5000.0,
            synt_slag=123.0,
            lime=123.0,
            magn=123.0,
            dolo=123.0,
            coke=123.0,
            pellets_weight=123.0,
            briquets_weight=123.0,
            tap_alloys_weight=123.0,
            yield_corrected_tap_alloys_weight=123.0,
            returned_steel_weight=123.0,
            vacuum_heat=True,
            after_desulf=ChemAnalysis(
                C=4.0,
                Mn=3.8,
                Si=0.17,
                P=0.22,
                S=0.05,
                Al=0.2,
                N=1.25,
                Cu=0.15,
                Ni=0.02,
                Cr=1.25,
                As=0.02,
                Sn=0.01,
                Mo=0.15,
                Ti=0.0,
                V=0.01,
                Zr=0.17,
                Nb=0.1,
                time_of_analysis="after_desulf",
            ),
            eob=ChemAnalysis(
                C=4.0,
                Mn=0.0,
                Si=0.0,
                P=0.0,
                S=0.0,
                Al=0.2,
                N=0.15,
                Cu=0.1,
                Ni=0.05,
                Cr=0.0,
                As=0.0,
                Sn=1.0,
                Mo=0.05,
                Ti=0.05,
                V=0.0,
                Zr=0.0,
                Nb=0.1,
                time_of_analysis="eob",
            ),  # eob too many zeroes
            final=ChemAnalysis(
                C=4.0,
                Mn=4.0,
                Si=0.17,
                P=0.22,
                S=0.05,
                Al=0.2,
                N=1.25,
                Cu=0.15,
                Ni=0.02,
                Cr=1.25,
                As=0.02,
                Sn=0.01,
                Mo=0.15,
                Ti=0.0,
                V=0.01,
                Zr=0.17,
                Nb=0.1,
                time_of_analysis="final",
            ),  # C and Mn are the same
            scrap=(ScrapInput("DSI", 125.0), ScrapInput("ASD", 125.0)),
        )

        with self.assertRaises(ValidationError):
            _ = data.heat_key
        with self.assertRaises(ValueError):
            _ = data.furnace
        with self.assertRaises(ValueError):
            _ = data.extra_o2
        with self.assertRaises(ValidationError):
            _ = data.temperature_after_desulf
        with self.assertRaises(ValidationError):
            _ = data.eob
        with self.assertRaises(ValidationError):
            _ = data.final
        with self.assertRaises(ValueError):
            _ = data.scrap[1].kind

    def test_time_of_analysis_converter_string(self):
        data_with_string = ChemAnalysis(
            C=4.0,
            Mn=4.1,
            Si=12.0,
            P=0.2,
            S=0.15,
            Al=0.17,
            N=7.0,
            Cu=0.12,
            Ni=0.12,
            Cr=0.27,
            As=0.23,
            Sn=0.021,
            Mo=0.1,
            Ti=0.12,
            V=0.11,
            Zr=0.9,
            Nb=0.0,
            time_of_analysis="after_desulf",
        )
        self.assertIsInstance(data_with_string.time_of_analysis, str)
        self.assertEqual(data_with_string.time_of_analysis, "after_desulf")

    def test_time_of_analysis_converter_enum(self):
        data_with_enum = ChemAnalysis(
            C=4.0,
            Mn=4.1,
            Si=12.0,
            P=0.2,
            S=0.15,
            Al=0.17,
            N=7.0,
            Cu=0.12,
            Ni=0.12,
            Cr=0.27,
            As=0.23,
            Sn=0.021,
            Mo=0.1,
            Ti=0.12,
            V=0.11,
            Zr=0.9,
            Nb=0.0,
            time_of_analysis=TimeOfAnalysis.AFTERDESULF,
        )
        self.assertIsInstance(data_with_enum.time_of_analysis, str)
        self.assertEqual(data_with_enum.time_of_analysis, "after_desulf")

    def test_time_of_analysis_validator(self):
        data_with_invalid_time_of_analysis = ChemAnalysis(
            C=4.0,
            Mn=4.1,
            Si=12.0,
            P=0.2,
            S=0.15,
            Al=0.17,
            N=7.0,
            Cu=0.12,
            Ni=0.12,
            Cr=0.27,
            As=0.23,
            Sn=0.021,
            Mo=0.1,
            Ti=0.12,
            V=0.11,
            Zr=0.9,
            Nb=0.0,
            time_of_analysis="asd",
        )
        with self.assertRaises(ValueError):
            _ = data_with_invalid_time_of_analysis.time_of_analysis


class TestConverterModel(unittest.TestCase):
    def test_scrap_type_limit_converstion(self):
        test_scrap_mixes = [
            ScrapMixLimit(ScrapMix("PAS"), 0.1, 0.3),
            ScrapMixLimit(ScrapMix("MCE"), None, 0.3),
            ScrapMixLimit(ScrapMix("1IB"), 0.1, None),
        ]

        for test_scrap_mix in test_scrap_mixes:
            tested = converter.structure(converter.unstructure(test_scrap_mix), ScrapMixLimit)
            self.assertEqual(tested, test_scrap_mix)


if __name__ == "__main__":
    unittest.main()
