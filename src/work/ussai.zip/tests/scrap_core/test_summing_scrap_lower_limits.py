"""
TODO if number of iterations in optimizations is configurable via settings,
    then lower number of iterations in these tests so they run faster
"""

from datetime import date
from typing import Tuple
import unittest

import attr
from immutables import Map
from scrap_core import SUPPORTED_CHEMS, ScrapOrder, ScrapMix
from scrap_core.datamodel import RawFeChem
from usskssgrades import SteelGradesHardcoded
from scrap_core.optimization.datamodel import (
    get_default_relaxable_risk_limit,
    MultipleHeatsOptimizationInput,
    ModelSettings,
    OptimizerSettings,
    HeatInputs,
)
from scrap_core.testutils import get_default_relaxable_upper_summing_limits
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats
from scrap_core.optimization.relaxable_limits import (
    RelaxableLowerSummingLimit,
    RelaxableValue,
)

from . import get_scrap_weights_sum_from_opt_result
from scrap_core.utils import to_mixes


def update_relaxable_lower_summing_limits_on_first_heat(
    obj: MultipleHeatsOptimizationInput,
    new_limits: Tuple[RelaxableLowerSummingLimit, ...],
) -> MultipleHeatsOptimizationInput:
    current_limits = obj.heats[0].relaxable_lower_summing_limits
    updated_heat = attr.evolve(obj.heats[0], relaxable_lower_summing_limits=current_limits + new_limits)
    return attr.evolve(obj, heats=(updated_heat,))


COMPOSITE_SCRAP_MIXES = to_mixes("H1")
H1_SCRAPS: ScrapOrder = ("HS", "HSA", "MCE")
RATIOS = (0.3, 0.3, 0.4)
SCRAP_MIX_MAPPING = Map({ScrapMix("H1"): Map(zip(H1_SCRAPS, RATIOS))})

AVAILABLE_SCRAP_MIXES = to_mixes("1BC", "2PIT", "MCE", "HS", "1IB") + COMPOSITE_SCRAP_MIXES
AVAILABLE_SCRAP_WEIGHT = 36_000
TOTAL_SCRAP_WEIGHT = 45_000
PIG_IRON_WEIGHT = 143_000
GRADE_ID = 248

BASE_INPUT = MultipleHeatsOptimizationInput(
    model_settings=ModelSettings(optimizer_settings=OptimizerSettings(scrap_mix_mapping=SCRAP_MIX_MAPPING)),
    lower_bounds=Map({}),
    upper_bounds=Map({scrap_mix: AVAILABLE_SCRAP_WEIGHT for scrap_mix in AVAILABLE_SCRAP_MIXES}),
    heats=(
        HeatInputs(
            grade_planned=SteelGradesHardcoded(SUPPORTED_CHEMS).get_grade_from_id(GRADE_ID, date.today()),
            total_scrap_weight=TOTAL_SCRAP_WEIGHT,
            pig_iron_weight=PIG_IRON_WEIGHT,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({}),
            upper_bounds=Map({}),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=get_default_relaxable_upper_summing_limits(GRADE_ID),
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
    ),
)


class TestLowerRelaxableLowerSummingLimits(unittest.TestCase):
    def test_one_lower_summing_limit(self):
        """Test that lower summing limit is correctly applied."""
        ANALYSIS_SCRAP_TYPES: ScrapOrder = ("1IB", "MCE")
        ANALYSIS_LIMIT_VALUE = 27000
        LOWER_LIMIT = RelaxableLowerSummingLimit(
            name="custom_limit",
            scrap_types=ANALYSIS_SCRAP_TYPES,
            weight_limit=RelaxableValue(ANALYSIS_LIMIT_VALUE, ANALYSIS_LIMIT_VALUE),
            ratio=RelaxableValue(0, 0),
        )
        # Inputs w/o lower limit
        res_wo_limit = optimize_multiple_heats(BASE_INPUT)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_wo_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertLess(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE)

        # Inputs with lower limit
        opt_input_with_limits = update_relaxable_lower_summing_limits_on_first_heat(
            BASE_INPUT, (LOWER_LIMIT,)
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_with_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertGreaterEqual(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE)

    def test_one_lower_summing_limit_and_one_lower_user_limit_below(self):
        """Test that lower summing limit along with lower user limit are correctly applied."""
        ANALYSIS_SCRAP_TYPES: ScrapOrder = ("MCE", "HS")
        ANALYSIS_SCRAP_SUM_BEFORE = 23_000
        ANALYSIS_SCRAP_SUM_AFTER = 35_000
        LOWER_LIMIT = RelaxableLowerSummingLimit(
            name="custom_limit",
            scrap_types=ANALYSIS_SCRAP_TYPES,
            weight_limit=RelaxableValue(ANALYSIS_SCRAP_SUM_AFTER, ANALYSIS_SCRAP_SUM_AFTER),
            ratio=RelaxableValue(0, 0),
        )
        heat_inputs_with_lower_limits = attr.evolve(
            BASE_INPUT.heats[0],
            lower_bounds=Map({"HS": ANALYSIS_SCRAP_SUM_AFTER - 1e3}),
        )
        BASE_INPUT_WITH_LIMITS = attr.evolve(BASE_INPUT, heats=(heat_inputs_with_lower_limits,))

        # Inputs w/o lower limit
        res_wo_limit = optimize_multiple_heats(BASE_INPUT)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_wo_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertLess(analysis_scrap_sum_fh, ANALYSIS_SCRAP_SUM_BEFORE)

        # Inputs with lower limit
        opt_input_with_limits = update_relaxable_lower_summing_limits_on_first_heat(
            BASE_INPUT_WITH_LIMITS, (LOWER_LIMIT,)
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_with_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertGreaterEqual(analysis_scrap_sum_fh, ANALYSIS_SCRAP_SUM_AFTER)

    def test_one_lower_summing_limit_and_one_lower_user_limit_above(self):
        """Test that lower summing limit along with lower user limit are correctly applied."""
        ANALYSIS_SCRAP_TYPES: ScrapOrder = ("MCE", "HS")
        ANALYSIS_SCRAP_SUM_BEFORE = 23_000
        ANALYSIS_SCRAP_SUM_AFTER = 35_000
        LOWER_LIMIT = RelaxableLowerSummingLimit(
            name="custom_limit",
            scrap_types=ANALYSIS_SCRAP_TYPES,
            weight_limit=RelaxableValue(ANALYSIS_SCRAP_SUM_AFTER, ANALYSIS_SCRAP_SUM_AFTER),
            ratio=RelaxableValue(0, 0),
        )
        heat_inputs_with_lower_limits = attr.evolve(
            BASE_INPUT.heats[0],
            lower_bounds=Map({ScrapMix("HS"): ANALYSIS_SCRAP_SUM_AFTER + 1e3}),
        )
        BASE_INPUT_WITH_LIMITS = attr.evolve(BASE_INPUT, heats=(heat_inputs_with_lower_limits,))

        # Inputs without lower limit
        res_wo_limit = optimize_multiple_heats(BASE_INPUT)
        analysis_scrap_sum = get_scrap_weights_sum_from_opt_result(
            res_wo_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertLessEqual(analysis_scrap_sum, ANALYSIS_SCRAP_SUM_BEFORE)

        # Inputs with lower limit
        opt_input_with_limits = update_relaxable_lower_summing_limits_on_first_heat(
            BASE_INPUT_WITH_LIMITS, (LOWER_LIMIT,)
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)
        analysis_scrap_sum = get_scrap_weights_sum_from_opt_result(
            res_with_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertGreaterEqual(analysis_scrap_sum, ANALYSIS_SCRAP_SUM_AFTER + 1e3)

    def test_two_lower_summing_limit(self):
        """Test that two lower summing limits are correctly applied."""
        ANALYSIS_SCRAP_TYPES: ScrapOrder = ("2PIT", "HS")
        ANALYSIS_SCRAP_TYPES_2: ScrapOrder = ("MCE", "HS")
        ANALYSIS_LIMIT_VALUE = 27_000
        ANALYSIS_LIMIT_VALUE_2 = 23_000
        LOWER_LIMIT = RelaxableLowerSummingLimit(
            name="custom_limit",
            scrap_types=ANALYSIS_SCRAP_TYPES,
            weight_limit=RelaxableValue(ANALYSIS_LIMIT_VALUE, ANALYSIS_LIMIT_VALUE),
            ratio=RelaxableValue(0, 0),
        )
        LOWER_LIMIT_2 = RelaxableLowerSummingLimit(
            name="custom_limit_2",
            scrap_types=ANALYSIS_SCRAP_TYPES_2,
            weight_limit=RelaxableValue(ANALYSIS_LIMIT_VALUE_2, ANALYSIS_LIMIT_VALUE_2),
            ratio=RelaxableValue(0, 0),
        )

        # Inputs w/o lower limit
        res_wo_limit = optimize_multiple_heats(BASE_INPUT)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_wo_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertLess(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_wo_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES_2
        )
        self.assertLess(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE_2)

        # Inputs with lower limit
        opt_input_with_limits = update_relaxable_lower_summing_limits_on_first_heat(
            BASE_INPUT, (LOWER_LIMIT, LOWER_LIMIT_2)
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_with_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES
        )
        self.assertGreaterEqual(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE)
        analysis_scrap_sum_fh = get_scrap_weights_sum_from_opt_result(
            res_with_limit, 0, SCRAP_MIX_MAPPING, ANALYSIS_SCRAP_TYPES_2
        )
        self.assertGreaterEqual(analysis_scrap_sum_fh, ANALYSIS_LIMIT_VALUE_2)


if __name__ == "__main__":
    unittest.main()
