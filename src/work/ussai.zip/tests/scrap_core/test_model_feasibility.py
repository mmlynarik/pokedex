from typing import Mapping
import unittest

from immutables import Map
from scrap_core import Chem

from scrap_core.blendmodel import get_blend_model, ScrapBlendModelInput
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologyType as Ctt
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import get_corr_tech_probabilities
from scrap_core.datamodel import RawFeChem
from usskssgrades import Grade, ChemLimit


# These values were extracted from `SteelGradesHardcoded` at 2021-09-19
MINIMAL_GRADE_UPPER_LIMITS: Mapping[Chem, float] = {
    "Cr": 0.03,
    "Cu": 0.015,
    "Mo": 0.004,
    "Ni": 0.03,
    "S": 0.005,  # There is a grade with limit 0.003, however it was used 7x since 2015
    "Si": 0.01,
    "Sn": 0.004,
}


class TestModelFeasibility(unittest.TestCase):
    """Check that even grades with strict limit have solution"""

    @unittest.skip(
        "Test for Sn fails, hopefully better bin 'interpolation', i.e. better `bin_cdf` function, will help"
    )
    def test_corr_tech_model_feasibility_per_chem(self):
        strict_grade = Grade(
            grade_id=0,
            display_name="the most strict grade",
            limits=tuple(ChemLimit(chem, 0, limit) for chem, limit in MINIMAL_GRADE_UPPER_LIMITS.items()),
            is_calmed=True,
            min_synt_slag=0,
        )

        eob_model = get_blend_model(version=2)

        for chem in eob_model.SUPPORTED_CHEMS:
            with self.subTest(msg=f"{chem}"):
                safe_scrap_weights = (
                    Map({"1BC": 24000, "PAS": 12000}) if chem == "Sn" else Map({"1DB": 34000, "HS": 2000})
                )

                safe_bmi = ScrapBlendModelInput(
                    raw_fe_weight=155000,
                    scrap_weights=safe_scrap_weights,
                    pellets_weight=0,
                    briquetes_weight=0,
                    raw_fe_chem=RawFeChem(),
                )

                bmo = eob_model.calculate(safe_bmi)

                corr_tech_probabilities = get_corr_tech_probabilities([bmo], strict_grade, (chem,))[0]
                undesirable_corr_tech_probability = corr_tech_probabilities.get(
                    (Ctt.REBLOW, 1), 0
                ) + corr_tech_probabilities.get((Ctt.RECLASSIFICATION, 1), 0)

                self.assertLessEqual(undesirable_corr_tech_probability, 0.2)


if __name__ == "__main__":
    unittest.main()
