# pylint: disable=no-member
import unittest
import torch

from scrap_core import run_by_group


class SelectorWithMemory:
    def __init__(self, selector):
        self.memory = []
        self.selector = selector

    def select(self, indexes):
        self.memory.append(tuple(indexes.tolist()))
        return self.selector(indexes)


class AggregationWithMemory:
    def __init__(self, aggregator):
        self.memory = []
        self.aggregator = aggregator

    def aggregate(self, group, data):
        self.memory.append((int(group), data))
        return self.aggregator(group, data)

    @property
    def groups_memory(self):
        return [x[0] for x in self.memory]


def test_aggregate(results, orig_order):
    return torch.cat(results)[orig_order]


class TestRunByGroup(unittest.TestCase):
    def test_basic(self):
        grouping_vector = torch.LongTensor([100, 100, 200, 100, 200, 300])
        selector = SelectorWithMemory(lambda indexes: ((indexes * 3).tile((5, 1)).T))
        aggregator = AggregationWithMemory(lambda group, data: data.sum(dim=1) + group)
        result = run_by_group(grouping_vector, selector.select, aggregator.aggregate, test_aggregate)

        # Selector and aggregator should be called 3 times as there are 3 distinct groups
        self.assertEqual(len(selector.memory), 3)
        self.assertEqual(len(aggregator.memory), 3)

        self.assertIn((0, 1, 3), selector.memory)
        self.assertIn((2, 4), selector.memory)
        self.assertIn((5,), selector.memory)

        self.assertIn(100, aggregator.groups_memory)
        self.assertIn(200, aggregator.groups_memory)
        self.assertIn(300, aggregator.groups_memory)

        self.assertListEqual(
            result.tolist(),
            [
                100 + (0 * 3 * 5),
                100 + (1 * 3 * 5),
                200 + (2 * 3 * 5),
                100 + (3 * 3 * 5),
                200 + (4 * 3 * 5),
                300 + (5 * 3 * 5),
            ],
        )

    def test_all_same(self):
        grouping_vector = torch.LongTensor([100, 100, 100, 100, 100, 100])
        selector = SelectorWithMemory(lambda indexes: ((indexes * 3).tile((5, 1)).T))
        aggregator = AggregationWithMemory(lambda group, data: data.sum(dim=1) + group)
        result = run_by_group(grouping_vector, selector.select, aggregator.aggregate, test_aggregate)

        self.assertEqual(len(selector.memory), 1)
        self.assertEqual(len(aggregator.memory), 1)

        self.assertIn((0, 1, 2, 3, 4, 5), selector.memory)

        self.assertIn(100, aggregator.groups_memory)

        self.assertListEqual(
            result.tolist(),
            [
                100 + (0 * 3 * 5),
                100 + (1 * 3 * 5),
                100 + (2 * 3 * 5),
                100 + (3 * 3 * 5),
                100 + (4 * 3 * 5),
                100 + (5 * 3 * 5),
            ],
        )

    def test_all_different(self):
        grouping_vector = torch.LongTensor([100, 200, 300, 400, 500, 600])
        selector = SelectorWithMemory(lambda indexes: ((indexes * 3).tile((5, 1)).T))
        aggregator = AggregationWithMemory(lambda group, data: data.sum(dim=1) + group)
        result = run_by_group(grouping_vector, selector.select, aggregator.aggregate, test_aggregate)

        self.assertEqual(len(selector.memory), 6)
        self.assertEqual(len(aggregator.memory), 6)

        self.assertIn((0,), selector.memory)
        self.assertIn((1,), selector.memory)
        self.assertIn((2,), selector.memory)
        self.assertIn((3,), selector.memory)
        self.assertIn((4,), selector.memory)
        self.assertIn((5,), selector.memory)

        self.assertIn(100, aggregator.groups_memory)
        self.assertIn(200, aggregator.groups_memory)
        self.assertIn(300, aggregator.groups_memory)
        self.assertIn(400, aggregator.groups_memory)
        self.assertIn(500, aggregator.groups_memory)
        self.assertIn(600, aggregator.groups_memory)

        self.assertListEqual(
            result.tolist(),
            [
                100 + (0 * 3 * 5),
                200 + (1 * 3 * 5),
                300 + (2 * 3 * 5),
                400 + (3 * 3 * 5),
                500 + (4 * 3 * 5),
                600 + (5 * 3 * 5),
            ],
        )

    def test_basic_2(self):
        grouping_vector = torch.LongTensor([100, 200, 300, 300, 200, 100])
        selector = SelectorWithMemory(lambda indexes: ((indexes * 3).tile((5, 1)).T))
        aggregator = AggregationWithMemory(lambda group, data: data.sum(dim=1) + group)
        result = run_by_group(grouping_vector, selector.select, aggregator.aggregate, test_aggregate)

        # Selector and aggregator should be called 3 times as there are 3 distinct groups
        self.assertEqual(len(selector.memory), 3)
        self.assertEqual(len(aggregator.memory), 3)

        self.assertIn((0, 5), selector.memory)
        self.assertIn((1, 4), selector.memory)
        self.assertIn((2, 3), selector.memory)

        self.assertIn(100, aggregator.groups_memory)
        self.assertIn(200, aggregator.groups_memory)
        self.assertIn(300, aggregator.groups_memory)

        self.assertListEqual(
            result.tolist(),
            [
                100 + (0 * 3 * 5),
                200 + (1 * 3 * 5),
                300 + (2 * 3 * 5),
                300 + (3 * 3 * 5),
                200 + (4 * 3 * 5),
                100 + (5 * 3 * 5),
            ],
        )

    def test_basic_3(self):
        grouping_vector = torch.LongTensor([100, 200, 100, 200, 100, 200])
        selector = SelectorWithMemory(lambda indexes: ((indexes * 3).tile((5, 1)).T))
        aggregator = AggregationWithMemory(lambda group, data: data.sum(dim=1) + group)
        result = run_by_group(grouping_vector, selector.select, aggregator.aggregate, test_aggregate)

        # Selector and aggregator should be called 3 times as there are 3 distinct groups
        self.assertEqual(len(selector.memory), 2)
        self.assertEqual(len(aggregator.memory), 2)

        self.assertIn((0, 2, 4), selector.memory)
        self.assertIn((1, 3, 5), selector.memory)

        self.assertIn(100, aggregator.groups_memory)
        self.assertIn(200, aggregator.groups_memory)

        self.assertListEqual(
            result.tolist(),
            [
                100 + (0 * 3 * 5),
                200 + (1 * 3 * 5),
                100 + (2 * 3 * 5),
                200 + (3 * 3 * 5),
                100 + (4 * 3 * 5),
                200 + (5 * 3 * 5),
            ],
        )
