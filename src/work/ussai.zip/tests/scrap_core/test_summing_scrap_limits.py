"""
TODO if number of iterations in optimizations is configurable via settings,
    then lower number of iterations in these tests so they run faster
"""

from datetime import date
from typing import Tuple
import unittest
from unittest.mock import patch

import attr
from immutables import Map

from usskssgrades import SteelGradesHardcoded
from scrap_core import (
    SUPPORTED_SCRAP_TYPES,
    SUPPORTED_SCRAP_TYPES_AS_MIXES,
    ScrapMix,
    ScrapOrder,
)
from scrap_core.blendmodel.eob_config import EOB_MODEL_SUPPORTED_CHEMS

from scrap_core.datamodel import RawFeChem
from scrap_core.meltabilitymodel import SCRAP_MELTABILITY_V2
from scrap_core.optimization.relaxable_limits import (
    RelaxableValue,
    RelaxableUpperSummingLimit,
    ACTIVE_RELAXATION_STEPS,
)
from scrap_core.optimization.datamodel import (
    MultipleHeatsOptimizationInput,
    ModelSettings,
    HeatInputs,
    get_default_relaxable_risk_limit,
    scrap_mix_to_scrap_type_set,
)
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats, get_affected_scrap_mixes
from scrap_core.utils import to_mixes
from tests.scrap_core import get_scrap_weights_sum_from_opt_result


# TODO current optimizer does not work without meltability limits, it just does not converge,
#   hence remove meltability limits below when the PR with bin-search optimizer is completed
MELTABILITY_LIMITS = tuple(
    RelaxableUpperSummingLimit(
        name=f"meltability_{'easy' if meltability_type == 'L' else 'hard'}_limit",
        scrap_types=tuple(
            scrap_type
            for scrap_type in SUPPORTED_SCRAP_TYPES
            # scrap with unknown meltability is considered
            # as a scrap with medium meltability, hence omitted
            if SCRAP_MELTABILITY_V2.get(scrap_type, "S") == meltability_type
        ),
        weight_limit=RelaxableValue(100000, 100000),
        ratio=RelaxableValue(0.5, 0.5),
    )
    for meltability_type in ["L", "T"]
)

COMPOSITE_SCRAP_MIXES = to_mixes("H1", "H2")
H1_SCRAPS: ScrapOrder = ("HS", "HSA")
H2_SCRAPS: ScrapOrder = ("1PIT", "2PIT")
RATIOS = (0.5, 0.5)
SCRAP_MIX_MAPPING = Map(
    {ScrapMix("H1"): Map(zip(H1_SCRAPS, RATIOS)), ScrapMix("H2"): Map(zip(H2_SCRAPS, RATIOS))}
)


AVAILABLE_SCRAP_MIXES = SUPPORTED_SCRAP_TYPES_AS_MIXES


OPTIMIZATION_INPUT_WITHOUT_LIMITS = MultipleHeatsOptimizationInput(
    model_settings=ModelSettings(),
    lower_bounds=Map({}),
    upper_bounds=Map({scrap_mix: 10**6 for scrap_mix in AVAILABLE_SCRAP_MIXES}),
    heats=(
        HeatInputs(
            grade_planned=SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(
                684, date.today()
            ),
            total_scrap_weight=38000,
            pig_iron_weight=152000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({}),
            upper_bounds=Map({}),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=MELTABILITY_LIMITS,
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
        HeatInputs(
            grade_planned=SteelGradesHardcoded(tuple(EOB_MODEL_SUPPORTED_CHEMS)).get_grade_from_id(
                597, date.today()
            ),
            total_scrap_weight=38000,
            pig_iron_weight=152000,
            pig_iron_chem=RawFeChem(),
            lower_bounds=Map({}),
            upper_bounds=Map({}),
            relaxable_lower_summing_limits=(),
            relaxable_upper_summing_limits=MELTABILITY_LIMITS,
            relaxable_risk_limit=get_default_relaxable_risk_limit(),
        ),
    ),
)


def replace_relaxable_upper_summing_limits_on_all_heats(
    obj: MultipleHeatsOptimizationInput,
    new_limits: Tuple[RelaxableUpperSummingLimit, ...],
) -> MultipleHeatsOptimizationInput:
    new_heats = tuple(attr.evolve(heat, relaxable_upper_summing_limits=new_limits) for heat in obj.heats)
    return attr.evolve(obj, heats=new_heats)


class TestAbsoluteRelaxableUpperSummingLimits(unittest.TestCase):
    def test_all_grades_limit(self):
        """Test that limit without grade ids specified is applied to every heat (regardless its grade)"""
        res_without_limit = optimize_multiple_heats(OPTIMIZATION_INPUT_WITHOUT_LIMITS)

        self.assertIsNone(res_without_limit.error)

        limited_scrap_types = sum(
            [
                tuple(scrap_mix_to_scrap_type_set(SCRAP_MIX_MAPPING, scrap_mix))
                for scrap_map in res_without_limit.scrap_weights_per_heat
                for scrap_mix in scrap_map
            ],
            (),
        )
        custom_limit = RelaxableUpperSummingLimit(
            name="custom_limit",
            scrap_types=tuple(limited_scrap_types),
            weight_limit=RelaxableValue(5000, 5000),
            ratio=RelaxableValue(1, 1),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limit.error)

        # take tolerance into account due to rounding in result post-processing
        tolerance = OPTIMIZATION_INPUT_WITHOUT_LIMITS.model_settings.optimizer_settings.precision_step

        for i in range(len(res_with_limit.scrap_weights_per_heat)):
            scrap_weights_sum = get_scrap_weights_sum_from_opt_result(
                res_with_limit, i, SCRAP_MIX_MAPPING, limited_scrap_types
            )
            self.assertLessEqual(
                scrap_weights_sum,
                custom_limit.weight_limit.get_relaxed_value(custom_limit.relaxation_ratio) + tolerance,
            )

    def test_single_scrap_type_limit(self):
        """Test that single scrap type limits work as expected"""
        # When using small weight limit, there is large chance that rounding will not find correct result
        LIMIT_VALUE = 7000
        new_relaxable_upper_summing_limits = tuple(
            RelaxableUpperSummingLimit(
                name=f"custom_limit ({scrap_type})",
                scrap_types=(scrap_type,),
                weight_limit=RelaxableValue(LIMIT_VALUE, LIMIT_VALUE),
                ratio=RelaxableValue(1, 1),
            )
            for scrap_type in SUPPORTED_SCRAP_TYPES
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limits = optimize_multiple_heats(opt_input_with_limits)
        self.assertIsNone(res_with_limits.error)

        for scrap_map in res_with_limits.scrap_weights_per_heat:
            for scrap_type in SUPPORTED_SCRAP_TYPES:
                affected_scrap_mixes = get_affected_scrap_mixes(
                    AVAILABLE_SCRAP_MIXES, SCRAP_MIX_MAPPING, (scrap_type,)
                )
                self.assertLessEqual(
                    sum(scrap_map.get(scrap_mix, 0) for scrap_mix in affected_scrap_mixes), LIMIT_VALUE
                )

    def test_lower_bounds_override(self):
        """Test that (user defined) lower limits have precedence over summing scrap limits"""
        custom_limit = RelaxableUpperSummingLimit(
            name="custom_limit",
            scrap_types=("HS", "HST"),
            weight_limit=RelaxableValue(1000, 1000),
            ratio=RelaxableValue(1, 1),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        custom_heat = attr.evolve(opt_input_with_limits.heats[0], lower_bounds=Map({"HS": 2000, "HST": 2000}))
        with patch("scrap_core.optimization.linprog_optimizer.validate_first_heat_scrap_bounds"):
            res_with_limit = optimize_multiple_heats(attr.evolve(opt_input_with_limits, heats=(custom_heat,)))

        self.assertIsNone(res_with_limit.error)

        scrap_map = res_with_limit.scrap_weights_per_heat[0]
        affected_scrap_mixes = get_affected_scrap_mixes(
            AVAILABLE_SCRAP_MIXES, SCRAP_MIX_MAPPING, ("HS", "HST")
        )
        # Explicitly round to thousands of kgs because usual post-processing rounding is not performed here.
        self.assertEqual(
            round(sum(scrap_map.get(scrap_mix, 0) for scrap_mix in affected_scrap_mixes), -3), 4000
        )


class TestRelativeSummingLimits(unittest.TestCase):
    def test_relative_limit(self):
        """Test that relative summing limit works as expected"""
        custom_limits = tuple(
            RelaxableUpperSummingLimit(
                name=f"ratio_limit ({scrap_type})",
                scrap_types=(scrap_type,),
                weight_limit=RelaxableValue(100000, 100000),
                ratio=RelaxableValue(0.1, 0.1),
            )
            for scrap_type in SUPPORTED_SCRAP_TYPES
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            *custom_limits,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limits = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limits.error)

        for scrap_map in res_with_limits.scrap_weights_per_heat:
            for scrap_type in SUPPORTED_SCRAP_TYPES:
                # 1% tolerance added due to float arithmetic and rounding
                affected_scrap_mixes = get_affected_scrap_mixes(
                    AVAILABLE_SCRAP_MIXES, SCRAP_MIX_MAPPING, (scrap_type,)
                )
                self.assertLessEqual(
                    sum(scrap_map.get(scrap_mix, 0) for scrap_mix in affected_scrap_mixes),
                    0.11 * sum(scrap_map.values()),
                )

    def test_relative_limit_override(self):
        """Test that user defined lower limits have precedence over relative summing limit"""
        custom_limits = tuple(
            RelaxableUpperSummingLimit(
                name=f"ratio_limit ({scrap_type})",
                scrap_types=(scrap_type,),
                ratio=RelaxableValue(0.1, 0.1),
                weight_limit=RelaxableValue(100000, 100000),
            )
            for scrap_type in SUPPORTED_SCRAP_TYPES
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            *custom_limits,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        custom_heat = attr.evolve(opt_input_with_limits.heats[0], lower_bounds=Map({"1PIT": 10000}))

        res_with_limits = optimize_multiple_heats(attr.evolve(opt_input_with_limits, heats=(custom_heat,)))
        scrap_map = res_with_limits.first_heat_scrap_weights
        for scrap_type in set(SUPPORTED_SCRAP_TYPES) - {"1PIT"}:
            # 1% tolerance added due to float arithmetic and rounding
            affected_scrap_mixes = get_affected_scrap_mixes(
                AVAILABLE_SCRAP_MIXES, SCRAP_MIX_MAPPING, (scrap_type,)
            )
            self.assertLessEqual(
                sum(scrap_map.get(scrap_mix, 0) for scrap_mix in affected_scrap_mixes),
                0.11 * sum(scrap_map.values()),
            )
        self.assertEqual(scrap_map.get(ScrapMix("1PIT"), 0), 10000)


class TestSummingLimitResolution(unittest.TestCase):
    def test_relative_over_absolute_limit(self):
        """A test case when relative limit is more strict than absolute"""
        res_without_limit = optimize_multiple_heats(OPTIMIZATION_INPUT_WITHOUT_LIMITS)

        self.assertIsNone(res_without_limit.error)

        limited_scrap_types = sum(
            [
                tuple(scrap_mix_to_scrap_type_set(SCRAP_MIX_MAPPING, scrap_mix))
                for scrap_map in res_without_limit.scrap_weights_per_heat
                for scrap_mix in scrap_map
            ],
            (),
        )
        custom_limit = RelaxableUpperSummingLimit(
            name="custom_limit",
            scrap_types=tuple(limited_scrap_types),
            weight_limit=RelaxableValue(20000, 20000),
            ratio=RelaxableValue(0.5, 0.5),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limits = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limits.error)

        scrap_map = res_with_limits.scrap_weights_per_heat[0]
        scrap_weights_sum = get_scrap_weights_sum_from_opt_result(
            res_with_limits, 0, SCRAP_MIX_MAPPING, limited_scrap_types
        )
        self.assertLessEqual(
            scrap_weights_sum,
            custom_limit.get_effective_weight_limit(sum(scrap_map.values())),
        )

    def test_absolute_over_relative_limit(self):
        """A test case when absolute limit is more strict than relative"""
        res_without_limit = optimize_multiple_heats(OPTIMIZATION_INPUT_WITHOUT_LIMITS)

        self.assertIsNone(res_without_limit.error)

        limited_scrap_types = sum(
            [
                tuple(scrap_mix_to_scrap_type_set(SCRAP_MIX_MAPPING, scrap_mix))
                for scrap_map in res_without_limit.scrap_weights_per_heat
                for scrap_mix in scrap_map
            ],
            (),
        )
        custom_limit = RelaxableUpperSummingLimit(
            name="custom_limit",
            scrap_types=tuple(limited_scrap_types),
            weight_limit=RelaxableValue(10000, 10000),
            ratio=RelaxableValue(0.5, 0.5),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limits = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limits.error)

        scrap_map = res_with_limits.scrap_weights_per_heat[0]
        scrap_weights_sum = get_scrap_weights_sum_from_opt_result(
            res_with_limits, 0, SCRAP_MIX_MAPPING, limited_scrap_types
        )
        # take tolerance into account due to rounding in result post-processing
        tolerance = OPTIMIZATION_INPUT_WITHOUT_LIMITS.model_settings.optimizer_settings.precision_step
        self.assertLessEqual(
            scrap_weights_sum, custom_limit.get_effective_weight_limit(sum(scrap_map.values())) + tolerance
        )

    def test_limit_without_scrap_types(self):
        """Test that such limit is ignored"""
        res_without_limit = optimize_multiple_heats(OPTIMIZATION_INPUT_WITHOUT_LIMITS)

        self.assertIsNone(res_without_limit.error)

        custom_limit = RelaxableUpperSummingLimit(
            name="custom_limit",
            scrap_types=(),
            weight_limit=RelaxableValue(1, 1),
            ratio=RelaxableValue(0.1, 0.1),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limit.error)

        self.assertEqual(res_with_limit, res_without_limit)


class TestRelaxableSummingLimitsRelaxation(unittest.TestCase):
    """Tests that relaxation works as expected"""

    def test_relaxable_limit(self):
        """Test that relaxable limit is relaxed"""

        # The following limits are too strict, so to find any solution they must be relaxed first.
        RelaxableUpperSummingLimit.n_steps = 2
        custom_limits = tuple(
            RelaxableUpperSummingLimit(
                name=f"relaxable_limit_{scrap_type}",
                scrap_types=(scrap_type,),
                weight_limit=RelaxableValue(1, 5000),
                ratio=RelaxableValue(1, 1),
            )
            for scrap_type in SUPPORTED_SCRAP_TYPES
        )
        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            *custom_limits,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )

        with patch("scrap_core.optimization.linprog_optimizer.validate_first_heat_scrap_bounds"):
            res_with_limit = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limit.error)
        self.assertGreaterEqual(len(res_with_limit.scrap_weights_per_heat), 1)
        for scrap in res_with_limit.scrap_weights_per_heat:
            # Check that all relaxed limits (simulated by calling get_last_relaxation_step()) are fulfilled,
            # i.e. fulfil the current relaxed limit value
            self.assertTrue(
                all(
                    lim.get_last_relaxation_step().is_current_step_ok(scrap, SCRAP_MIX_MAPPING)
                    for lim in custom_limits
                )
            )
        RelaxableUpperSummingLimit.n_steps = ACTIVE_RELAXATION_STEPS

    def test_nonrelaxable_limit(self):
        """Test that nonrelaxable limit is not relaxed"""
        res_without_limit = optimize_multiple_heats(OPTIMIZATION_INPUT_WITHOUT_LIMITS)

        self.assertIsNone(res_without_limit.error)

        limited_scrap_types = sum(
            [
                tuple(scrap_mix_to_scrap_type_set(SCRAP_MIX_MAPPING, scrap_mix))
                for scrap_map in res_without_limit.scrap_weights_per_heat
                for scrap_mix in scrap_map
            ],
            (),
        )
        custom_limit = RelaxableUpperSummingLimit(
            name="nonrelaxable_limit",
            scrap_types=tuple(limited_scrap_types),
            weight_limit=RelaxableValue(5000, 5000),
            ratio=RelaxableValue(1, 1),
        )

        new_relaxable_upper_summing_limits = (
            # TODO remove when bin-search optimizer is merged
            *MELTABILITY_LIMITS,
            custom_limit,
        )
        opt_input_with_limits = replace_relaxable_upper_summing_limits_on_all_heats(
            OPTIMIZATION_INPUT_WITHOUT_LIMITS, new_relaxable_upper_summing_limits
        )
        res_with_limit = optimize_multiple_heats(opt_input_with_limits)

        self.assertIsNone(res_with_limit.error)

        # take tolerance into account due to rounding in result post-processing
        tolerance = OPTIMIZATION_INPUT_WITHOUT_LIMITS.model_settings.optimizer_settings.precision_step
        for recommended_scrap in res_with_limit.scrap_weights_per_heat:
            # check that custom limit is fulfilled, i.e. it has not been relaxed
            self.assertTrue(
                custom_limit.is_current_step_ok(
                    {scrap_type: weight - tolerance for scrap_type, weight in recommended_scrap.items()},
                    SCRAP_MIX_MAPPING,
                )
            )


if __name__ == "__main__":
    unittest.main()
