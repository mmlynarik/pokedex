"""
TODO if TestTCPServer receives nonempty bytes string, ConnectionResetError occurs. Thus, fix it.
    - let command_getter to return nonempty bytes string and you'll see the error
"""

import socket
import threading
import unittest
from time import sleep

from scalesingest.tcpclient import InterruptableTCPClient

LOCALHOST = "127.0.0.1"


class TestTCPServer:
    def __init__(self, iface, port):
        self._socket = socket.socket()
        self._socket.bind((iface, port))
        self._connection = None

    @property
    def port(self) -> int:
        return self._socket.getsockname()[1]

    def __enter__(self):
        try:
            self._socket.listen(0)
            self._socket.settimeout(1)
            self._connection, _ = self._socket.accept()
            return self._connection
        except Exception:
            self._socket.close()
            return None

    def __exit__(self, exc_type, exc_value, exc_tb):
        if self._connection is not None:
            self._connection.close()
        self._socket.close()


class ThreadingTestTCPServer:
    def __init__(self, iface, port, data_to_send):
        self._data = data_to_send
        self.tcp_server = TestTCPServer(iface, port)
        self._server_thread = threading.Thread(target=self.send_data)

    def send_data(self):
        with self.tcp_server as conn:
            if conn is not None:
                conn.sendall(self._data)

    def __enter__(self):
        self._server_thread.start()
        # Just to be sure it works on all machines - thread has enough time to start
        sleep(0.01)
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        self._server_thread.join()


class TestTCPClient(unittest.TestCase):
    def test_raises_if_server_not_available(self):
        with InterruptableTCPClient() as tcp_client:
            self.assertRaises(
                ConnectionRefusedError,
                lambda: tcp_client.start(LOCALHOST, 12345, lambda _: None, lambda: b"123"),
            )

    def test_interrupt_before_starting(self):
        with InterruptableTCPClient() as tcp_client:
            tcp_client.interrupt()

    def test_raises_if_not_used_as_ctx_manager(self):
        tcp_client = InterruptableTCPClient()
        self.assertRaises(
            Exception, lambda: tcp_client.start(LOCALHOST, 12345, lambda _: None, lambda: b"123")
        )

    def test_data_handler_is_called_with_valid_data(self):
        test_data = b"test data" * 5000

        # Start fake server in background thread
        with ThreadingTestTCPServer(LOCALHOST, 0, test_data) as tcp_server:
            with InterruptableTCPClient() as tcp_client:
                full_data = b""

                def data_handler(data):
                    nonlocal full_data
                    if len(data) == 0:
                        if tcp_client is not None:
                            tcp_client.interrupt()
                    full_data = full_data + data

                def command_getter() -> bytes:
                    return b""

                tcp_client.start(
                    LOCALHOST, tcp_server.tcp_server.port, data_handler, command_getter, buffer_size=4096
                )
                self.assertEqual(full_data, test_data)

    def test_restart_ability(self):
        """
        Test that if user tries to reuse tcp_client it fails.
        TCPClient is defined as not reusable so we cannot call start twice.
        """
        test_data = b"test data" * 5000
        full_data = b""

        def data_handler(data):
            nonlocal full_data
            full_data = full_data + data

        def command_getter() -> bytes:
            return b""

        with InterruptableTCPClient() as tcp_client:
            with ThreadingTestTCPServer(LOCALHOST, 0, test_data) as tcp_server:
                tcp_client.start(
                    LOCALHOST, tcp_server.tcp_server.port, data_handler, command_getter, buffer_size=4096
                )

            with ThreadingTestTCPServer(LOCALHOST, 0, test_data) as tcp_server:
                self.assertRaises(
                    Exception,
                    lambda: tcp_client.start(
                        LOCALHOST, tcp_server.tcp_server.port, data_handler, command_getter
                    ),
                )

    def test_server_disconnect(self):
        """
        Test that calling start is not blocking when remote server disconnect.
        """
        test_data = b"test data" * 5000
        full_data = b""

        def data_handler(data):
            nonlocal full_data
            full_data = full_data + data

        def command_getter() -> bytes:
            return b""

        with InterruptableTCPClient() as tcp_client:
            with ThreadingTestTCPServer(LOCALHOST, 0, test_data) as tcp_server:
                tcp_client.start(
                    LOCALHOST, tcp_server.tcp_server.port, data_handler, command_getter, buffer_size=4096
                )

            self.assertEqual(full_data, test_data)


if __name__ == "__main__":
    unittest.main()
