import pathlib
import unittest

import fakeredis

from scalesingest.redis_resources.heartbeat import RedisHeartbeat
from scalesingest.redis_resources.queue import RedisQueue
from scalesingest.redis_resources.stream import RedisStream
from scalesingest.scale_api import Ind310API
from tests.scalesingest.utils import load_test_data


class TestInd310API(unittest.TestCase):
    redis = fakeredis.FakeRedis()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        cls.redis.close()

    def setUp(self):
        stream_name = "stream"
        stream_size = 512
        self.stream = RedisStream(self.redis, stream_name, 32, stream_size)
        load_test_data(self.stream, pathlib.Path(__file__).parent / "test_data" / "ind310_data.csv.gz")
        self.command_queue = RedisQueue(self.redis, "command")
        self.heartbeat = RedisHeartbeat(self.redis, "heartbeat", 10)
        self.api = Ind310API(self.stream, self.command_queue, self.heartbeat, 128)

    def tearDown(self):
        self.redis.flushdb()

    def test_tare(self):
        self.api.tare()
        self.assertEqual((b"T",), self.command_queue.pop(count=3))
        self.assertEqual((), self.command_queue.pop())

    def test_read_and_parse(self):
        first_msg = self.stream.get_first()
        last_msg = self.stream.get_last()

        self.assertEqual(
            len(self.api.get_range(first_msg.timestamp, last_msg.timestamp)), self.stream.stream_size
        )


if __name__ == "__main__":
    unittest.main()
