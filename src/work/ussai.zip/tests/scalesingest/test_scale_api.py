import unittest
from time import sleep

import fakeredis

from scalesingest.message import ParsedMessage, RawMessage
from scalesingest.redis_resources.stream import RedisStream
from scalesingest.redis_resources.queue import RedisQueue
from scalesingest.redis_resources.heartbeat import RedisHeartbeat

from scalesingest.scale_api import ScaleAPI


def custom_parse(msg: RawMessage) -> ParsedMessage:
    value, overloaded, in_motion = msg.value.decode().split()
    return ParsedMessage(msg.timestamp, int(value), bool(int(overloaded)), bool(int(in_motion)))


class TestGenericScaleAPI(unittest.TestCase):
    redis = fakeredis.FakeRedis()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        cls.redis.close()

    def setUp(self):
        self.stream = RedisStream(self.redis, "stream", 32, 512)
        self.command_queue = RedisQueue(self.redis, "command")
        self.heartbeat = RedisHeartbeat(self.redis, "heartbeat", 10)
        self.api = ScaleAPI(self.stream, self.command_queue, self.heartbeat, 128, custom_parse)

    def tearDown(self):
        self.redis.flushdb()

    def test_get_valid_msg(self):
        # for simplicity, values are calculated from keys
        test_data = {
            key: f"{key * 10} {int(overloaded)} {int(in_motion)}".encode()
            for key, overloaded, in_motion in [
                (1, False, False),
                (2, False, False),
                (3, True, False),
                (4, False, True),
            ]
        }

        for key, data in test_data.items():
            self.stream.add(data, key)

        msg_2 = self.api.get_reliable_msg(2)
        msg_3 = self.api.get_reliable_msg(3)
        msg_4 = self.api.get_reliable_msg(4)

        self.assertEqual(msg_2, ParsedMessage(2, 20, False, False))

        self.assertEqual(msg_2, msg_3)
        self.assertEqual(msg_2, msg_4)

    def test_heartbeat_when_data_flow(self):
        for _ in range(10):
            self.heartbeat.update()
            sleep(self.heartbeat.freq // 1000 / 3)
            self.assertTrue(self.heartbeat.is_beating)
            self.assertTrue(self.api.is_operational)

    def test_heartbeat_when_data_do_not_flow(self):
        # wait for a bit longer than freq of heartbeat
        sleep(self.heartbeat.freq // 1000 + 10e-5)

        self.assertFalse(self.heartbeat.is_beating)

        self.assertFalse(self.api.is_operational)

    def test_significant_steps_selection(self):
        test_values = [1000, 950, 1000, 1050, 1500, 1450, 1600, 1300, 1500, 1400, 1400]
        test_data = [f"{val} 0 0".encode() for val in test_values]

        for item in test_data:
            self.stream.add(item)
            sleep(0.001)

        start = self.stream.get_first().timestamp
        end = self.stream.get_last().timestamp

        significant_data = self.api.get_range_significant(start, end, 50)

        self.assertListEqual([msg.weight for msg in significant_data], [1000, 1300, 1400])


if __name__ == "__main__":
    unittest.main()
