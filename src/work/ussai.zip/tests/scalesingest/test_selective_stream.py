import re
import unittest

import fakeredis

from scalesingest.redis_resources.selective_stream import SelectiveRedisStream
from scalesingest.error import ScaleAPINotFoundError


class TestSelectiveStream(unittest.TestCase):
    stream = None

    def setUp(self):
        client = fakeredis.FakeRedis()
        self.stream = SelectiveRedisStream(
            client, "test", batch_size=64, stream_size=1024, pattern=re.compile(b"\\d+")
        )

    def tearDown(self):
        self.stream._client.close()

    def test_add_invalid(self):
        test_data = b"hello world"

        with self.assertLogs(level="WARNING") as cm:
            self.stream.add(test_data)
            self.assertIn(
                f"WARNING:scalesingest.redis_resources.selective_stream:"
                f"Invalid data: {test_data} - skipped",
                cm.output,
            )

        with self.assertRaises(ScaleAPINotFoundError):
            self.stream.get_last()

    def test_add_duplicate(self):
        test_data = b"1234"
        self.stream.add(test_data)

        msg = self.stream.get_last()
        self.assertEqual(msg.value, test_data)

        with self.assertLogs(level="DEBUG") as cm:
            self.stream.add(test_data)
            self.assertIn(
                f"DEBUG:scalesingest.redis_resources.selective_stream:Repetitive data: {test_data}"
                f" (current latest data {self.stream._SelectiveRedisStream__latest_data}) - skipped",
                cm.output,
            )

        new_msg = self.stream.get_last()

        self.assertEqual(new_msg, msg)

    def test_add_malformed(self):
        test_data = b"hello 1234world"

        with self.assertLogs(level="ERROR") as cm:
            self.stream.add(test_data)
            self.assertIn(
                f"ERROR:scalesingest.redis_resources.selective_stream:Malformed data {test_data}"
                f" - pattern {self.stream.pattern.pattern} matched partially",
                cm.output,
            )

        msg = self.stream.get_last()
        self.assertEqual(msg.value, b"1234")


if __name__ == "__main__":
    unittest.main()
