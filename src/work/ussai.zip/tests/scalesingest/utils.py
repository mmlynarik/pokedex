from typing import Sequence, Tuple, Union

import pathlib

import pandas as pd

from scalesingest.redis_resources.stream import RedisStream


def dump_raw_data(data: Sequence[Tuple[int, bytes]], stream_name: str) -> str:
    output_path = f"raw_data__{stream_name}.csv.gz"

    df = pd.DataFrame(data, columns=["key", "value"])

    df["value"] = df["value"].str.decode("utf-8")

    df.to_csv(output_path, index=False)

    return output_path


def load_raw_data(path: Union[str, pathlib.Path]) -> pd.DataFrame:
    df = pd.read_csv(path)

    df["value"] = df["value"].str.encode("utf-8")

    return df


def load_test_data(stream: RedisStream, path: Union[str, pathlib.Path]) -> None:

    df = load_raw_data(path)

    df.apply(lambda row: stream.add(row["value"], row["key"]), axis=1)
