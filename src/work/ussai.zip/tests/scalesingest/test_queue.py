import unittest
import string
import time

import fakeredis

from scalesingest.redis_resources.queue import RedisQueue


class TestStream(unittest.TestCase):
    queue = None

    def setUp(self):
        client = fakeredis.FakeRedis()
        self.queue = RedisQueue(client, "test")

    def tearDown(self):
        self.queue._client.close()

    def test_push_values(self):
        self.queue.push(b"hello", b"world")

        self.assertEqual(self.queue.pop(), (b"hello",))
        self.assertEqual(self.queue.pop(), (b"world",))

    def test_pop_value_from_empty_queue(self):
        self.assertEqual((), self.queue.pop())


if __name__ == "__main__":
    unittest.main()
