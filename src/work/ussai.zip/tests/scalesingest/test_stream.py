import unittest
import string
import time

import fakeredis

from scalesingest.redis_resources.stream import RedisStream


class TestStream(unittest.TestCase):
    stream = None

    def setUp(self):
        client = fakeredis.FakeRedis()
        self.stream = RedisStream(client, "test", batch_size=64, stream_size=1024)

    def tearDown(self):
        self.stream._client.close()

    def test_add(self):
        key = self.stream.add(b"hello world")

        msg = self.stream.get_last()

        self.assertEqual(key, f"{msg.timestamp}-0")
        self.assertEqual(msg.value, b"hello world")

    def test_get_range(self):
        test_data = list(map(lambda x: x.encode("utf-8"), string.ascii_uppercase))

        for key, item in enumerate(test_data):
            self.stream.add(item)

        data = self.stream.get_range("-", "+")

        self.assertListEqual([msg.value for msg in data], test_data)

    def test_interval_bounds(self):
        """Test that `get_range` method returns all messages from closed interval [start_pos, end_pos]."""
        test_data = [item.encode("utf-8") for item in "abcdef"]

        for key, item in enumerate(test_data):
            self.stream.add(item, key)

        msgs = self.stream.get_range("2-0", "4-1")

        self.assertEqual([msg.value for msg in msgs], [b"c", b"d", b"e"])


if __name__ == "__main__":
    unittest.main()
