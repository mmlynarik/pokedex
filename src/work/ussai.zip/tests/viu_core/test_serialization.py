import unittest

from pycel import ExcelCompiler

from viu_core import (
    ExcelCellMapping,
    OptimizationLimits,
    VsadzkaInput,
    generate_input_from_excel,
    generate_limits_from_excel,
)

from . import DATA_PATH_REV11


class TestSerialization(unittest.TestCase):
    excel = ExcelCompiler(filename=DATA_PATH_REV11)
    cell_mapping = ExcelCellMapping(excel)

    def test_input_data_serialization(self):
        input_data = generate_input_from_excel(self.excel, self.cell_mapping)
        serialized = input_data.serialize()
        deserialized = VsadzkaInput.deserialize(serialized)
        self.assertEqual(input_data, deserialized)

    def test_limits_serialization(self):
        limits = generate_limits_from_excel(self.excel, self.cell_mapping)
        serialized = limits.serialize()
        deserialized = OptimizationLimits.deserialize(serialized)
        self.assertEqual(limits, deserialized)


if __name__ == "__main__":
    unittest.main()
