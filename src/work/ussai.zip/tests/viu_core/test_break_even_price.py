# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
import unittest

from pycel import ExcelCompiler

from viu_core import (
    ExcelCellMapping,
    generate_input_from_excel,
    generate_limits_from_excel,
)

from viu_core.optimization.break_even_price import (
    update_limit_fields,
    get_ingredient_type,
    update_price_per_tonnes_field,
    get_limit_for,
    get_price_with_deviation,
    check_limit,
    is_price_in_range,
)

from . import DATA_PATH_REV11


class TestBreakEvenPrice(unittest.TestCase):
    excel = ExcelCompiler(filename=DATA_PATH_REV11)
    cell_mapping = ExcelCellMapping(excel)
    limits = generate_limits_from_excel(excel, cell_mapping)
    input_data = generate_input_from_excel(excel, cell_mapping)

    def test_getter_ingredient_type(self):
        ingredient_type = get_ingredient_type(self.limits, "OKU-KYS")
        self.assertEqual(ingredient_type, "prisady_do_aglomeratu")
        ingredient_type = get_ingredient_type(self.limits, "AR-SB60")
        self.assertEqual(ingredient_type, "aglorudy")
        ingredient_type = get_ingredient_type(self.limits, "TR-B-110")
        self.assertEqual(ingredient_type, "prisady_do_vp")
        ingredient_type = get_ingredient_type(self.limits, "PEL-SE63")
        self.assertEqual(ingredient_type, "pelety")
        ingredient_type = get_ingredient_type(self.limits, "KC-ING68")
        self.assertEqual(ingredient_type, None)

    def test_update_limit_fields(self):
        tested_ingredient = "OKU-VAL"
        new_minimum = 3000
        new_maximum = 6000
        new_limits = update_limit_fields(self.limits, tested_ingredient, new_minimum, new_maximum)
        ingredient_type = get_ingredient_type(self.limits, tested_ingredient)
        if ingredient_type is not None:
            for limit in list(getattr(new_limits, ingredient_type)):
                if limit.nazov == tested_ingredient:
                    self.assertEqual(limit.min, new_minimum)
                    self.assertEqual(limit.max, new_maximum)
                else:
                    self.assertEqual(limit.min, limit.min)
                    self.assertEqual(limit.max, limit.max)

    def test_update_price_fields(self):
        tested_ingredient = "OKU-VAL"
        new_price = 3000
        new_input_data = update_price_per_tonnes_field(
            self.limits, self.input_data, tested_ingredient, new_price
        )
        ingredient_type = get_ingredient_type(self.limits, tested_ingredient)
        if ingredient_type is not None:
            for input_data in list(getattr(new_input_data, ingredient_type)):
                if input_data.nazov == tested_ingredient:
                    self.assertEqual(input_data.cena_za_tonu, new_price)
                else:
                    self.assertEqual(input_data.cena_za_tonu, input_data.cena_za_tonu)

    def test_get_limit_for(self):
        tested_ingredient = "KC-LEB"
        limit = get_limit_for(self.limits, tested_ingredient)
        if not limit:
            self.assertEqual(limit, None)
        else:
            self.assertEqual(limit.nazov, tested_ingredient)
            self.assertAlmostEqual(limit.min, 132000.0)
            self.assertAlmostEqual(limit.max, 210000.0)

    def test_getter_price_with_deviation(self):
        price_with_deviation = get_price_with_deviation(100.0, 1)
        self.assertAlmostEqual(price_with_deviation, 101.0)

    def test_check_limit(self):
        test_ingredient = "KC-LEB"
        limit = get_limit_for(self.limits, test_ingredient)
        if not limit:
            self.assertEqual(limit, None)
        else:
            check_upper_limit = check_limit(limit, 210000.1, 1)
            self.assertFalse(check_upper_limit)
            check_upper_limit = check_limit(limit, 210000.01, 2)
            self.assertFalse(check_upper_limit)
            check_upper_limit = check_limit(limit, 210000.001, 2)
            self.assertTrue(check_upper_limit)
            check_upper_limit = check_limit(limit, 210000.0, 1)
            self.assertTrue(check_upper_limit)

            check_lower_limit = check_limit(limit, 132000.001, 2)
            self.assertTrue(check_lower_limit)
            check_lower_limit = check_limit(limit, 132000.9, 0)
            self.assertTrue(check_lower_limit)
            check_lower_limit = check_limit(limit, 131999.9, 1)
            self.assertFalse(check_lower_limit)
            check_lower_limit = check_limit(limit, 132000.1, 1)
            self.assertTrue(check_lower_limit)

    def test_is_price_in_range(self):
        in_range = is_price_in_range(321.0, 320.0, 1.0)
        self.assertTrue(in_range)
        in_range = is_price_in_range(323.3, 320.0, 1.0)
        self.assertFalse(in_range)
        in_range = is_price_in_range(320.0, 320.0, 1.0)
        self.assertTrue(in_range)
        in_range = is_price_in_range(319.9, 320.0, 1.0)
        self.assertFalse(in_range)
