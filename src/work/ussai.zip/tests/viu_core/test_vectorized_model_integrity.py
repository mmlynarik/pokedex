# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
# pylint: disable=unused-wildcard-import,wildcard-import,too-many-public-methods,invalid-name
import itertools
import unittest
from typing import Mapping

import numpy as np
from pycel import ExcelCompiler

from viu_core import *
from viu_core import Vectorized_VIU, VsadzkaInput

from . import DATA_PATH_REV12


class TestVectorizedModelIntegrity(unittest.TestCase):
    input_data: VsadzkaInput
    excel: ExcelCompiler
    vectorized: Vectorized_VIU
    required_accuracy: int
    corrected_weights: Mapping[str, float]
    corrected_weights_vector: np.ndarray
    cell_mapping: ExcelCellMapping
    weights: Mapping[str, float]
    weights_vector: np.ndarray
    prisada_podsitne_pelety: Prisada
    vaha_podsitnych_peliet: float
    podsitne_pelety_vsadzka: float

    @classmethod
    def setUpClass(cls):
        super(TestVectorizedModelIntegrity, cls).setUpClass()
        cls.excel = ExcelCompiler(filename=DATA_PATH_REV12)
        cls.cell_mapping = ExcelCellMapping(cls.excel)
        cls.input_data = generate_input_from_excel(cls.excel, cls.cell_mapping)
        cls.required_accuracy = 6  # 6 decimal places
        cls.vectorized = Vectorized_VIU(cls.input_data)
        cls.weights = load_hmotnosti_prisad(cls.excel, cls.cell_mapping)
        cls.corrected_weights = korekcia_hmotnosti(cls.input_data, cls.weights)
        cls.weights_vector = vectorize_weights(cls.weights, cls.vectorized.mapping)
        cls.corrected_weights_vector = vectorize_weights(cls.corrected_weights, cls.vectorized.mapping)
        cls.prisada_podsitne_pelety = cls.vectorized.prisada_podsitnych_peliet_vectorized(
            cls.vectorized.bf_input_chem_for_pellets(cls.corrected_weights_vector),
            cls.corrected_weights_vector * cls.vectorized.pellets_input_vector,
            cls.weights_vector * cls.vectorized.pellets_input_vector,
        )
        cls.vaha_podsitnych_peliet = cls.vectorized.vaha_podsitnych_peliet_vectorized(cls.weights_vector)
        cls.podsitne_pelety_vsadzka = hmotnost_podsitnych_peliet_do_vsadzky_vectorized(
            cls.vaha_podsitnych_peliet, cls.prisada_podsitne_pelety
        )

    def test_processing_cost_for_ton_fe_vp(self):
        self.assertAlmostEqual(
            self.vectorized.processing_cost_for_ton_fe_vp(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            spracovacie_naklady_na_tonu_fe_na_vp(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_cena_co2_v_tonach_na_1_tsz_zo_suroviny_vectorized(self):
        self.assertAlmostEqual(
            self.vectorized.cena_co2_v_tonach_na_1_tsz_zo_suroviny_vectorized(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            cena_co2_v_tonach_na_1_tsz_zo_suroviny(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_co2_vp_price(self):
        self.assertAlmostEqual(
            self.vectorized.co2_vp_price(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            cena_co2_na_vysokej_peci(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_total_alkali_weight(self):
        self.assertAlmostEqual(
            self.vectorized.total_alkali_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            celkova_hmotnost_alkalii(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_total_met_fe(self):
        self.assertAlmostEqual(
            self.vectorized.total_met_fe(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            celkovy_koeficient_na_met_fe(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_vypocet_paliva(self):
        self.assertAlmostEqual(
            self.vectorized.vypocet_paliva_vectorized(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            vypocet_paliva(self.input_data, self.corrected_weights),
            places=self.required_accuracy - 3,
        )

    def test_total_fuel_price_per_tone_fe_bvs(self):
        self.assertAlmostEqual(
            self.vectorized.total_fuel_price_per_tone_fe_bvs(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            cena_paliva_na_tonu_fe_z_bvs(self.input_data, self.corrected_weights),
            places=self.required_accuracy - 3,
        )

    def test_cao_to_limestone(self):
        self.assertAlmostEqual(
            self.vectorized.cao_to_limestone(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            prepocet_cao_na_vapenec(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_input_s_from_fuel_for_t_bf_input_ore(self):
        self.assertAlmostEqual(
            self.vectorized.input_s_from_fuel_for_t_bf_input_ore(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            vstupna_s_z_paliva_na_t_fe_rudna_vsadzka(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_bf_input_ore_weight(self):
        self.assertAlmostEqual(
            self.vectorized.bf_input_ore_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            hmotnost_rudnej_vsadzky(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_input_s_from_fuel_for_t_fe_fuel(self):
        self.assertAlmostEqual(
            self.vectorized.input_s_from_fuel_for_t_fe_fuel(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet, self.prisada_podsitne_pelety
            ),
            vstupna_s_z_paliva_na_t_fe_palivo(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_raw_fe_weight(self):
        self.assertAlmostEqual(
            self.vectorized.raw_fe_weight(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet, self.prisada_podsitne_pelety
            ),
            hmotnost_vyroby_suroveho_fe(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_vyhoz_kal_loss(self):
        self.assertAlmostEqual(
            self.vectorized.vyhoz_kal_loss(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet, self.prisada_podsitne_pelety
            ),
            strata_vyhodzu_kalu(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_impact_on_fuel(self):
        self.assertAlmostEqual(
            self.vectorized.impact_on_fuel(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            vplyv_na_palivo(self.corrected_weights, self.input_data),
            places=self.required_accuracy,
        )

    def test_weighted_average_under_5mm_agglomerate(self):
        self.assertAlmostEqual(
            self.vectorized.weighted_average_under_5mm_agglomerate(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            vazeny_priemer_podielu_pod_5mm_aglomerat(self.corrected_weights, self.input_data),
            places=self.required_accuracy,
        )

    def test_hmotnost_podsitnych_peliet_do_vsadzky(self):
        self.assertAlmostEqual(
            self.podsitne_pelety_vsadzka,
            hmotnost_podsitnych_peliet_do_vsadzky(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_celkova_vaha_peliet(self):
        self.assertAlmostEqual(
            self.vectorized.celkova_vaha_peliet_vectorized(self.weights_vector),
            celkova_vaha_peliet(self.input_data, self.weights),
            places=self.required_accuracy,
        )

    def test_ceny_podsitnych_peliet(self):
        self.assertAlmostEqual(
            self.prisada_podsitne_pelety.cena_za_tonu,
            prisada_podsitnych_peliet(self.input_data, self.corrected_weights).cena_za_tonu,
            places=self.required_accuracy,
        )

    def test_vahy_podsitnych_peliet(self):
        self.assertAlmostEqual(
            self.vaha_podsitnych_peliet,
            vaha_podsitnych_peliet(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_percento_recyklatov(self):
        self.assertAlmostEqual(
            self.vectorized.percento_recyklatov_vectorized(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet, self.podsitne_pelety_vsadzka
            ),
            percento_recyklatov(self.corrected_weights, self.input_data),
            places=self.required_accuracy,
        )

    def test_suma_recyklatov(self):
        self.assertAlmostEqual(
            self.vectorized.suma_recyklatov_vectorized(self.corrected_weights_vector),
            suma_recyklatov(self.corrected_weights, self.input_data),
            places=self.required_accuracy,
        )

    def test_hmotnosti_aglomeracnej_vsadzky(self):
        self.assertAlmostEqual(
            self.vectorized.hmotnost_aglomeracnej_vsadzky_vectorized(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet, self.podsitne_pelety_vsadzka
            ),
            hmotnost_aglomeracnej_vsadzky(self.corrected_weights, self.input_data),
            places=self.required_accuracy,
        )

    def test_sumy_vah_pre_prisadu(self):
        vectors = [
            self.vectorized.agglomerate_vector,
            self.vectorized.concentrate_vector,
            self.vectorized.agglomerate_addition_vector,
            self.vectorized.pellets_input_vector,
            self.vectorized.additives_vector,
        ]
        for typ_prisady, vector in zip(list(TypPrisady)[:5], vectors):
            with self.subTest(typ_prisady):
                self.assertAlmostEqual(
                    self.vectorized.suma_vah_pre_prisadu_vectorized(
                        self.corrected_weights_vector, vector, self.vaha_podsitnych_peliet
                    ),
                    suma_vah_pre_prisadu(self.corrected_weights, self.input_data, typ_prisady),
                    places=self.required_accuracy,
                    msg=typ_prisady,
                )

    def test_total_agglomerate_weight(self):
        self.assertAlmostEqual(
            self.vectorized.total_agglomerate_weight(
                self.corrected_weights_vector, self.podsitne_pelety_vsadzka, self.vaha_podsitnych_peliet
            ),
            hmotnost_vo_vsadzke(self.input_data, ZlozkaVsadzky.AGLOMERAT, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_chem_matrix(self):
        for component in self.input_data.vsetky_prisady:
            for compound in ChemickaLatka:
                self.assertAlmostEqual(
                    self.vectorized.chem_matrix[self.vectorized.mapping[component.nazov], compound],
                    component.chemicke_zlozenie[compound],
                    places=self.required_accuracy,
                    msg=(component, compound),
                )

    def test_dry_chem_matrix(self):
        for component in self.input_data.vsetky_prisady:
            for compound in ChemickaLatka:
                self.assertAlmostEqual(
                    self.vectorized.dry_chem_matrix[self.vectorized.mapping[component.nazov], compound],
                    pomer_prvku_v_prisade_susina(component, compound),
                    places=self.required_accuracy,
                    msg=(component, compound),
                )

    def test_fe_production(self):
        self.assertAlmostEqual(
            self.vectorized.fe_production(
                self.corrected_weights_vector,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            celkovy_vytazok_fe(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_fe_production_with_losses(self):
        self.assertAlmostEqual(
            self.vectorized.fe_production_with_losses(
                self.corrected_weights_vector,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            celkovy_vytazok_fe_so_stratami(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomeration_fuel(self):
        for component in self.input_data.vsetky_prisady:
            if not component.bazicky_typ != BazickyTyp.ZIADEN:
                self.assertAlmostEqual(
                    self.vectorized.agglomeration_fuel_vector[self.vectorized.mapping[component.nazov]],
                    palivo_na_aglomeracii_prisada(
                        self.input_data,
                        component,
                        self.corrected_weights,
                    ),
                    places=self.required_accuracy,
                    msg=component,
                )

    def test_ash_weight(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.ash_weight_from_500kg_coke_vector[self.vectorized.mapping[component.nazov]],
                popol_t_z_500kg_koksu_na_t_suroviny_prisada(
                    self.input_data, component, self.corrected_weights
                ),
                places=self.required_accuracy,
                msg=component,
            )

    def test_limestone_addition_vector(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.limestone_addition_vector[self.vectorized.mapping[component.nazov]],
                pridavok_vapenca_prisada(self.input_data, component, self.corrected_weights),
                places=self.required_accuracy,
                msg=component,
            )

    def test_chem_composition_with_limestone(self):
        for component in self.input_data.vsetky_prisady:
            for compound in ChemickaLatka:
                self.assertAlmostEqual(
                    self.vectorized.chem_composition_with_limestone_matrix[
                        self.vectorized.mapping[component.nazov], compound
                    ],
                    pomer_prvku_v_prisade_s_pridanim_vapenca(
                        self.input_data,
                        component,
                        compound,
                        self.corrected_weights,
                    ),
                    places=self.required_accuracy,
                    msg=(component, compound),
                )

    def test_slag(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.slag[self.vectorized.mapping[component.nazov]],
                vyskyt_trosky_prisada(self.input_data, component, self.corrected_weights),
                places=self.required_accuracy,
                msg=component,
            )

    def test_alkali(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.alkali[self.vectorized.mapping[component.nazov]],
                alkalie_prisada(self.input_data, component, self.corrected_weights),
                places=self.required_accuracy,
                msg=component,
            )

    def test_limestone_usage(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.limestone_usage_coeficient_vector[self.vectorized.mapping[component.nazov]],
                koeficient_na_spotrebu_vapenca_prisada(self.input_data, component, self.corrected_weights),
                places=self.required_accuracy,
                msg=component,
            )

    def test_met_fe_coeficient(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.met_fe_coeficient[self.vectorized.mapping[component.nazov]],
                koeficient_na_metalicke_zelezo_prisada(self.input_data, component, self.corrected_weights),
                places=self.required_accuracy,
                msg=component,
            )

    def test_fuel(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.blast_furnance_fuel[self.vectorized.mapping[component.nazov]],
                palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(
                    self.input_data, component, self.corrected_weights
                ),
                places=self.required_accuracy,
                msg=component,
            )

    def test_fuel_addition_for_water_evaporation(self):
        for component in self.input_data.vsetky_prisady:
            with self.subTest(component.nazov):
                self.assertAlmostEqual(
                    self.vectorized.fuel_addition_for_water_evaporation[
                        self.vectorized.mapping[component.nazov]
                    ],
                    pridavok_paliva_na_odparenie_vlhkosti_prisada(
                        self.input_data, component, self.corrected_weights
                    ),
                    places=self.required_accuracy,
                    msg=component,
                )

    def test_blast_furnance_coke_weight(self):
        self.assertAlmostEqual(
            self.vectorized.blast_furnance_coke_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            celkove_mnozstvo_paliva_do_VP(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_fuel_to_produce_agglomerate(self):
        self.assertAlmostEqual(
            self.vectorized.fuel_to_produce_agglomerate(
                self.corrected_weights_vector, self.vaha_podsitnych_peliet
            ),
            palivo_potrebne_na_skut_vyrobu_aglomeratu(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_limestone_weight_2(self):
        self.assertAlmostEqual(
            self.vectorized.limestone_weight_2(self.corrected_weights_vector),
            hmotnost_vapenca_2(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomerate_dry_fe(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_dry_fe(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            fe_susina_aglomerat(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_chem_percentage_in_original_state(self):
        for component in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                self.vectorized.chem_percentage_in_original_state[self.vectorized.mapping[component.nazov]],
                percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(component),
                places=self.required_accuracy,
                msg=component,
            )

    def test_ash_weight_from_aglomerate_coke(self):
        self.assertAlmostEqual(
            self.vectorized.ash_weight_from_aglomerate_coke(
                self.corrected_weights_vector, self.podsitne_pelety_vsadzka, self.vaha_podsitnych_peliet
            ),
            hmotnost_popola_z_aglomeracneho_koksu(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomerate_weight_to_blast_furnance_input(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_weight_to_blast_furnance_input(
                self.corrected_weights_vector, self.podsitne_pelety_vsadzka
            ),
            (
                hmotnost_v_aglomerate_do_vsadzky(
                    self.input_data,
                    ZlozkaAglomeratu.AGLORUDA,
                    self.corrected_weights,
                )
                + hmotnost_v_aglomerate_do_vsadzky(
                    self.input_data,
                    ZlozkaAglomeratu.KONCENTRAT,
                    self.corrected_weights,
                )
                + hmotnost_v_aglomerate_do_vsadzky(
                    self.input_data,
                    ZlozkaAglomeratu.PRISADA_DO_AGLOMERATU,
                    self.corrected_weights,
                )
            ),
            places=self.required_accuracy,
        )

    def test_agglomerate_fuel_ash_limestone_addition(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_fuel_ash_limestone_addition,
            pridavok_vapenca_algo_koks_popol(self.input_data, TypPrisady.VAPENEC),
            places=self.required_accuracy,
        )

    def test_aglomerate_fuel_ash_fe_percentage(self):
        self.assertAlmostEqual(
            self.vectorized.aglomerate_fuel_ash_fe_percentage,
            fe_susina_v_zlozke_aglomeratu(
                self.input_data,
                ZlozkaAglomeratu.POPOL_Z_AGLOMERACNEHO_KOKSU,
                self.corrected_weights,
            ),
            places=self.required_accuracy,
        )

    def test_agglomerate_fuel(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_fuel(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_slag_agglomerate(self):
        self.assertAlmostEqual(
            self.vectorized.slag_agglomerate(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            vyskyt_trosky_aglomerat(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomerate_chem_composition(self):
        for compound in ChemickaLatka:
            with self.subTest(compound):
                self.assertAlmostEqual(
                    self.vectorized.agglomerate_chem(
                        self.corrected_weights_vector,
                        self.podsitne_pelety_vsadzka,
                        self.prisada_podsitne_pelety,
                        self.vaha_podsitnych_peliet,
                    )[compound],
                    percentualny_obsah_latky_v_aglomerate_susina(
                        self.input_data, compound, self.corrected_weights
                    ),
                    places=self.required_accuracy,
                    msg=compound,
                )

    def test_zn_weight(self):
        self.assertAlmostEqual(
            self.vectorized.zn_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (celkovy_zn(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_blast_furnance_input_chem_without_agglomerate(self):
        for compound in ChemickaLatka:
            self.assertAlmostEqual(
                self.vectorized.blast_furnance_input_chem_without_agglomerate(self.corrected_weights_vector)[
                    compound
                ],
                percentualny_obsah(
                    frozenset(
                        itertools.chain.from_iterable(
                            [
                                self.input_data.pelety,
                                self.input_data.prisady_do_vp,
                                [self.input_data.vapenec],
                            ]
                        )
                    ),
                    compound,
                    self.corrected_weights,
                ),
                places=self.required_accuracy,
                msg=compound,
            )

    def test_blast_furnance_input_chem(self):
        for compound in ChemickaLatka:
            with self.subTest(compound):
                self.assertAlmostEqual(
                    self.vectorized.blast_furnance_input_chem(
                        self.corrected_weights_vector,
                        self.podsitne_pelety_vsadzka,
                        self.prisada_podsitne_pelety,
                        self.vaha_podsitnych_peliet,
                    )[compound],
                    obsah_chemickej_latky_vo_vsadzke(self.input_data, compound, self.corrected_weights),
                    places=self.required_accuracy,
                    msg=compound,
                )

    def test_kc_ar_ratio(self):
        self.assertAlmostEqual(
            self.vectorized.kc_ar_ratio(self.corrected_weights_vector, self.vaha_podsitnych_peliet),
            (pomer_kc_ar(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_total_slag(self):
        self.assertAlmostEqual(
            self.vectorized.total_slag(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (celkovy_vyskyt_trosky(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_total_limestone_usage(self):
        self.assertAlmostEqual(
            self.vectorized.total_limestone_usage(
                self.corrected_weights_vector,
                self.vaha_podsitnych_peliet,
                self.prisada_podsitne_pelety,
            ),
            (celkova_spotreba_vapenca(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_total_alkali(self):
        self.assertAlmostEqual(
            self.vectorized.total_alkali(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (celkove_alkalie(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_total_fuel(self):
        self.assertAlmostEqual(
            self.vectorized.total_fuel(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_fuel_addition_to_water_evaporation(self):
        self.assertAlmostEqual(
            self.vectorized.fuel_addition_to_water_evaporation(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (pridavok_paliva_na_odparenie_vlhkosti(self.input_data, self.corrected_weights)),
            places=self.required_accuracy,
        )

    def test_recalculation_price(self):
        self.assertAlmostEqual(
            self.vectorized.recalculation_price(
                self.corrected_weights_vector,
                self.weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            prepoctova_cena(self.input_data, self.weights, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_price_per_ton_fe(self):
        self.assertAlmostEqual(
            self.vectorized.price_per_ton_fe(
                self.corrected_weights_vector,
                self.weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            celkova_cena_za_tonu_zeleza(self.input_data, self.weights, self.corrected_weights),
            places=self.required_accuracy - 3,
        )

    def test_total_basicity(self):
        self.assertAlmostEqual(
            self.vectorized.total_basicity(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            celkova_bazicita(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_mn_weight(self):
        self.assertAlmostEqual(
            self.vectorized.mn_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (
                obsah_chemickej_latky_vo_vsadzke(
                    self.input_data,
                    ChemickaLatka.Mn,
                    self.corrected_weights,
                )
                * celkova_hmotnost_vsadzky(self.input_data, self.corrected_weights)
            ),
            places=self.required_accuracy,
        )

    def test_p_weight(self):
        self.assertAlmostEqual(
            self.vectorized.p_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (
                obsah_chemickej_latky_vo_vsadzke(
                    self.input_data,
                    ChemickaLatka.P,
                    self.corrected_weights,
                )
                * celkova_hmotnost_vsadzky(self.input_data, self.corrected_weights)
            ),
            places=self.required_accuracy,
        )

    def test_total_bf_input_weight(self):
        self.assertAlmostEqual(
            self.vectorized.total_bf_input_weight(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            celkova_hmotnost_vsadzky(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomerate_total_price(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_total_price(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            (
                cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(self.input_data, self.corrected_weights)
                * hmotnost_vo_vsadzke(self.input_data, ZlozkaVsadzky.AGLOMERAT, self.corrected_weights)
            ),
            places=self.required_accuracy - 2,
        )

    def test_mn_percentage(self):
        self.assertAlmostEqual(
            self.vectorized.mn_percentage(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            percento_Mn(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_p_percentage(self):
        self.assertAlmostEqual(
            self.vectorized.p_percentage(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            percento_P(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_mgo_in_slag(self):
        self.assertAlmostEqual(
            self.vectorized.mgo_in_slag(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            mgo_v_troske(self.input_data, self.corrected_weights),
            places=self.required_accuracy,
        )

    def test_agglomerate_co2_cost(self):
        self.assertAlmostEqual(
            self.vectorized.agglomerate_co2_cost(
                self.corrected_weights_vector,
                self.podsitne_pelety_vsadzka,
                self.prisada_podsitne_pelety,
                self.vaha_podsitnych_peliet,
            ),
            hmotnost_vo_vsadzke(self.input_data, ZlozkaVsadzky.AGLOMERAT, self.corrected_weights)
            * mnozstvo_co2_na_t_fe_z_aglomeratu(self.input_data, self.corrected_weights)
            * self.input_data.cena_tony_co2,
            places=self.required_accuracy,
        )

    def test_solve_method(self):
        result = self.vectorized.solve(self.weights_vector)
        result2 = model_vsadzky(self.input_data, self.weights)

        self.assertAlmostEqual(
            result.celkova_cena_za_tonu_zeleza,
            result2.celkova_cena_za_tonu_zeleza,
            places=self.required_accuracy - 3,
            msg="celkova_cena_za_tonu_zeleza",
        )
        # FUEL NOT SUPPORTED YET - we do not need it for optimization
        self.assertAlmostEqual(
            result.vypocet_paliva,
            result2.vypocet_paliva,
            places=self.required_accuracy - 3,
            msg="vypocet_paliva",
        )
        self.assertAlmostEqual(
            result.cena_paliva_na_tonu_fe_z_bvs,
            result2.cena_paliva_na_tonu_fe_z_bvs,
            places=self.required_accuracy - 3,
            msg="cena_paliva_na_tonu_fe_z_bvs",
        )
        self.assertAlmostEqual(
            result.cena_tony_aglomeratu,
            result2.cena_tony_aglomeratu,
            places=self.required_accuracy,
            msg="cena_tony_aglomeratu",
        )
        self.assertAlmostEqual(
            result.vytazok_fe, result2.vytazok_fe, places=self.required_accuracy, msg="vytazok_fe"
        )
        self.assertAlmostEqual(
            result.vyskyt_trosky, result2.vyskyt_trosky, places=self.required_accuracy, msg="vyskyt_trosky"
        )
        self.assertAlmostEqual(
            result.bazicita, result2.bazicita, places=self.required_accuracy, msg="bazicita"
        )
        self.assertAlmostEqual(result.BVS, result2.BVS, places=self.required_accuracy, msg="BVS")
        self.assertAlmostEqual(
            result.hmotnost_vsadzky,
            result2.hmotnost_vsadzky,
            places=self.required_accuracy,
            msg="hmotnost_vsadzky",
        )
        self.assertAlmostEqual(result.zn, result2.zn, places=self.required_accuracy, msg="zn")
        self.assertAlmostEqual(result.alkalie, result2.alkalie, places=self.required_accuracy, msg="alkalie")
        self.assertAlmostEqual(result.p, result2.p, places=self.required_accuracy, msg="p")
        self.assertAlmostEqual(result.mn, result2.mn, places=self.required_accuracy, msg="mn")
        self.assertAlmostEqual(
            result.pomer_kc_ar, result2.pomer_kc_ar, places=self.required_accuracy, msg="pomer_kc_ar"
        )
        self.assertAlmostEqual(
            result.celkove_so2, result2.celkove_so2, places=self.required_accuracy, msg="celkove_so2"
        )
        self.assertAlmostEqual(
            result.mgo_v_troske, result2.mgo_v_troske, places=self.required_accuracy, msg="mgo_v_troske"
        )
        self.assertAlmostEqual(
            result.hmotnost_aglomeratu,
            result2.hmotnost_aglomeratu,
            places=self.required_accuracy,
            msg="hmotnost_aglomeratu",
        )
        self.assertAlmostEqual(
            result.cena_surovin,
            result2.cena_surovin,
            places=self.required_accuracy,
            msg="cena_surovin",
        )
        self.assertAlmostEqual(
            result.cena_paliva_vp,
            result2.cena_paliva_vp,
            places=self.required_accuracy,
            msg="cena_paliva_vp",
        )
        self.assertAlmostEqual(
            result.cena_paliva_suroviny,
            result2.cena_paliva_suroviny,
            places=self.required_accuracy,
            msg="cena_paliva_suroviny",
        )
        self.assertAlmostEqual(
            result.cena_paliva_aglomeracia,
            result2.cena_paliva_aglomeracia,
            places=self.required_accuracy,
            msg="cena_paliva_aglomeracia",
        )
        self.assertAlmostEqual(
            result.cena_co2_vp,
            result2.cena_co2_vp,
            places=self.required_accuracy,
            msg="cena_co2_vp",
        )
        self.assertAlmostEqual(
            result.cena_co2_suroviny,
            result2.cena_co2_suroviny,
            places=self.required_accuracy,
            msg="cena_co2_suroviny",
        )
        self.assertAlmostEqual(
            result.cena_co2_aglomeracia,
            result2.cena_co2_aglomeracia,
            places=self.required_accuracy,
            msg="cena_co2_aglomeracia",
        )
        self.assertAlmostEqual(
            result.spracovacie_naklady_vp,
            result2.spracovacie_naklady_vp,
            places=self.required_accuracy,
            msg="spracovacie_naklady_vp",
        )
        self.assertAlmostEqual(
            result.spracovacie_naklady_aglomeracia,
            result2.spracovacie_naklady_aglomeracia,
            places=self.required_accuracy,
            msg="spracovacie_naklady_aglomeracia",
        )
        self.assertAlmostEqual(
            result.penalta_P,
            result2.penalta_P,
            places=self.required_accuracy,
            msg="penalta_P",
        )
        self.assertAlmostEqual(
            result.penalta_S,
            result2.penalta_S,
            places=self.required_accuracy,
            msg="penalta_S",
        )
        self.assertAlmostEqual(
            result.bazicita_aglomeratu,
            result2.bazicita_aglomeratu,
            places=self.required_accuracy,
            msg="bazicita aglomeratu",
        )
        self.assertAlmostEqual(
            result.q_spalin,
            result2.q_spalin,
            places=4,
            msg="q spalin",
        )
