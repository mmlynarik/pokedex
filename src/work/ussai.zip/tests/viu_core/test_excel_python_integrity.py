# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
# pylint: disable=unused-wildcard-import,wildcard-import,too-many-public-methods,invalid-name
import unittest
from typing import Mapping
from pycel import ExcelCompiler
from viu_core import *
from viu_core import Prisada, VsadzkaInput

from . import DATA_PATH_REV12


class TestExcelPythonIntegrity(unittest.TestCase):
    input_data: VsadzkaInput
    excel: ExcelCompiler
    hmotnosti: Mapping[str, float]
    cell_mapping: ExcelCellMapping
    required_accuracy: int
    korigovane_hmotnosti: Mapping[str, float]

    @classmethod
    def setUpClass(cls):
        super(TestExcelPythonIntegrity, cls).setUpClass()
        cls.excel = ExcelCompiler(filename=DATA_PATH_REV12)
        cls.cell_mapping = ExcelCellMapping(cls.excel)
        cls.input_data = generate_input_from_excel(cls.excel, cls.cell_mapping)
        cls.hmotnosti = load_hmotnosti_prisad(cls.excel, cls.cell_mapping)
        cls.korigovane_hmotnosti = korekcia_hmotnosti(cls.input_data, cls.hmotnosti)
        cls.required_accuracy = 4

    @classmethod
    def value_from_excel(cls, cell: str) -> float:
        excel_value = cls.excel.evaluate(cell)
        if excel_value is None:
            return 0.0
        return excel_value

    def test_celkova_cena_za_tonu_zeleza(self):
        self.assertAlmostEqual(
            celkova_cena_za_tonu_zeleza(self.input_data, self.hmotnosti, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("BS180")),
            places=self.required_accuracy,
        )

    def test_vp_metalurg(self):
        self.assertAlmostEqual(
            vp_metalurg(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._dry_sheet_template("BB27")),
            places=self.required_accuracy,
        )

    def test_vypocet_paliva(self):
        self.assertAlmostEqual(
            vypocet_paliva(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("I182")),
            places=self.required_accuracy,
        )

    def test_celkova_vaha_peliet(self):
        self.assertAlmostEqual(
            celkova_vaha_peliet(self.input_data, self.hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("R41")),
            places=self.required_accuracy,
        )

    def test_prepocet_cao_na_vapenec(self):
        self.assertAlmostEqual(
            prepocet_cao_na_vapenec(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("L214")),
            places=self.required_accuracy,
        )

    def test_cao_na_odsirenie(self):
        self.assertAlmostEqual(
            cao_na_odsirenie(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("K214")),
            places=self.required_accuracy,
        )

    def test_s_spolu(self):
        self.assertAlmostEqual(
            vstup_s_spolu(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("J214")),
            places=self.required_accuracy,
        )

    def test_vstupna_s_z_paliva_na_t_fe_rudna_vsadzka(self):
        self.assertAlmostEqual(
            vstupna_s_z_paliva_na_t_fe_rudna_vsadzka(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("J211")),
            places=self.required_accuracy,
        )

    def test_hmotnost_rudnej_vsadzky(self):
        self.assertAlmostEqual(
            hmotnost_rudnej_vsadzky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("E211")),
            places=self.required_accuracy,
        )

    def test_hmotnost_pu(self):
        self.assertAlmostEqual(
            hmotnost_pu(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("E208")),
            places=self.required_accuracy,
        )

    def test_hmotnost_koks(self):
        self.assertAlmostEqual(
            hmotnost_koks(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("E207")),
            places=self.required_accuracy,
        )

    def test_hmotnost_msp_msk(self):
        self.assertAlmostEqual(
            hmotnost_msp_msk(self.input_data),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("E205")),
            places=self.required_accuracy,
        )

    def test_strata_vyhodzu_kalu(self):
        self.assertAlmostEqual(
            strata_vyhodzu_kalu(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("R185")),
            places=self.required_accuracy,
        )

    def test_hmotnost_vyroby_suroveho_fe(self):
        self.assertAlmostEqual(
            hmotnost_vyroby_suroveho_fe(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("E204")),
            places=self.required_accuracy,
        )

    def test_vstupna_s_z_paliva_na_t_fe_palivo(self):
        self.assertAlmostEqual(
            vstupna_s_z_paliva_na_t_fe_palivo(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("J208")),
        )

    def test_vplyv_na_palivo(self):
        self.assertAlmostEqual(
            vplyv_na_palivo(self.korigovane_hmotnosti, self.input_data),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("BO180")),
        )

    def test_vazeny_priemer_podielu_pod_5mm_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada):
                self.assertAlmostEqual(
                    vazeny_priemer_podielu_pod_5mm_prisada(
                        prisada,
                        podiel_suroviny_v_celkovej_vsadzke(
                            prisada, self.korigovane_hmotnosti, self.input_data
                        ),
                    ),
                    self.value_from_excel(self.cell_mapping.vazeny_priemer_podielu_pod_5mm(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_podiel_suroviny_v_celkovej_vsadzke(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada):
                self.assertAlmostEqual(
                    podiel_suroviny_v_celkovej_vsadzke(prisada, self.korigovane_hmotnosti, self.input_data),
                    self.value_from_excel(self.cell_mapping.podiel_suroviny_v_celkovej_vsadzke(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_hmotnosti_aglomeracnej_vsadzky(self):
        self.assertAlmostEqual(
            hmotnost_aglomeracnej_vsadzky(self.korigovane_hmotnosti, self.input_data),
            self.value_from_excel(self.cell_mapping._dry_sheet_template("BA5")),
            places=self.required_accuracy,
        )

    def test_sumy_recyklatov(self):
        self.assertAlmostEqual(
            suma_recyklatov(self.korigovane_hmotnosti, self.input_data),
            self.value_from_excel(self.cell_mapping._dry_sheet_template("AT36")),
            places=self.required_accuracy,
        )

    def test_percenta_recyklatov(self):
        self.assertAlmostEqual(
            percento_recyklatov(self.korigovane_hmotnosti, self.input_data),
            self.value_from_excel(self.cell_mapping._dry_sheet_template("AT37")),
            places=self.required_accuracy,
        )

    def test_sumy_hmotnosti_pre_prisadu(self):
        for typ_prisady in list(TypPrisady)[:5]:
            with self.subTest(typ_prisady):
                self.assertAlmostEqual(
                    suma_vah_pre_prisadu(self.korigovane_hmotnosti, self.input_data, typ_prisady),
                    self.value_from_excel(self.cell_mapping.suma_vah_pre_prisadu_cell(typ_prisady)),
                    places=self.required_accuracy,
                    msg=typ_prisady,
                )

    def test_vahy_podsitnych_peliet(self):
        self.assertAlmostEqual(
            vaha_podsitnych_peliet(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._dry_sheet_template("AN20")),
            places=self.required_accuracy,
        )

    def test_alkalie_aglomerat(self):
        self.assertAlmostEqual(
            alkalie_aglomerat(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.alkalie_aglomerat),
            places=self.required_accuracy,
        )

    def test_celkova_hmotnost_vsadzky(self):
        self.assertAlmostEqual(
            celkova_hmotnost_vsadzky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkova_hmotnost_vsadzky),
            places=self.required_accuracy,
        )

    def test_vazeny_priemer_ceny(self):
        self.assertAlmostEqual(
            vazeny_priemer_ceny(self.input_data.pelety, self.hmotnosti, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("G174")),
            places=self.required_accuracy,
        )
        self.assertAlmostEqual(
            vazeny_priemer_ceny(self.input_data.prisady_do_vp, self.hmotnosti, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping._wet_sheet_template("H174")),
            places=self.required_accuracy,
        )

    def test_percentualny_obsah_latky_v_aglomerate_susina(self):
        for latka in ChemickaLatka:
            with self.subTest(latka):
                self.assertAlmostEqual(
                    percentualny_obsah_latky_v_aglomerate_susina(
                        self.input_data, latka, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.percentualny_obsah_latky_v_aglomerate_susina(latka)
                    ),
                    places=self.required_accuracy,
                    msg=latka,
                )

    def test_ceny_podsitnych_peliet(self):
        self.assertAlmostEqual(
            cena_podsitnych_peliet(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.cena_peliet),
            places=self.required_accuracy,
        )

    def test_vyskyt_trosky_aglomerat(self):
        self.assertAlmostEqual(
            vyskyt_trosky_aglomerat(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.vyskyt_trosky_aglomerat),
            places=self.required_accuracy,
        )

    def test_fe_susina_aglomerat(self):
        self.assertAlmostEqual(
            fe_susina_aglomerat(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.fe_susina_aglomerat),
            places=self.required_accuracy,
        )

    def test_fe_susina_v_zlozke_aglomeratu_agloruda(self):
        self.assertAlmostEqual(
            fe_susina_v_zlozke_aglomeratu(
                self.input_data, ZlozkaAglomeratu.AGLORUDA, self.korigovane_hmotnosti
            ),
            self.value_from_excel(self.cell_mapping.fe_susina_v_zlozke_aglomeratu),
            places=self.required_accuracy,
        )

    def test_percentualneho_podielu_prvkov_v_dod_stave_podsitne_pelety(self):
        self.assertAlmostEqual(
            percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(
                prisada_podsitnych_peliet(self.input_data, self.korigovane_hmotnosti)
            ),
            self.value_from_excel(
                self.cell_mapping.percentualny_podiel_prvkov_v_surovine_v_dod_stave_podsitne_pelety
            ),
            places=self.required_accuracy,
        )

    def test_hmotnosti_podsitnych_peliet_do_vsadzky(self):
        self.assertAlmostEqual(
            hmotnost_podsitnych_peliet_do_vsadzky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.hmotnost_podsitnych_peliet_do_vsadzky),
            places=self.required_accuracy,
        )

    def test_chemie_podsitnych_peliet(self):
        for latka in ChemickaLatka:
            with self.subTest(latka):
                self.assertAlmostEqual(
                    percentualny_obsah_v_zlozke_vsadzky(
                        self.input_data, latka, ZlozkaVsadzky.PELETY, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.obsah_chemickej_latky_v_podsitnych_peletach_cell(latka)
                    ),
                    places=self.required_accuracy,
                    msg=latka,
                )

    def test_model_vsadzky(self):
        result = model_vsadzky(self.input_data, self.hmotnosti)

        self.assertAlmostEqual(
            result.celkova_cena_za_tonu_zeleza,
            self.value_from_excel(self.cell_mapping.cena_za_tonu_cell),
            places=self.required_accuracy,
            msg="Celkova cena za tonu zeleza",
        )

        self.assertAlmostEqual(
            result.vypocet_paliva,
            self.value_from_excel(self.cell_mapping.vypocet_paliva_cell),
            places=self.required_accuracy,
            msg="Vypocet paliva",
        )

        self.assertAlmostEqual(
            result.vytazok_fe,
            self.value_from_excel(self.cell_mapping.vytazok_fe_cell),
            places=self.required_accuracy,
            msg="Vytazok fe",
        )

        self.assertAlmostEqual(
            result.vyskyt_trosky,
            self.value_from_excel(self.cell_mapping.vyskyt_trosky_cell),
            places=self.required_accuracy,
            msg="Vyskyt trosky",
        )

        self.assertAlmostEqual(
            result.bazicita,
            self.value_from_excel(self.cell_mapping.bazicita_cell),
            places=self.required_accuracy,
            msg="Bazicita",
        )

        self.assertAlmostEqual(
            result.BVS,
            self.value_from_excel(self.cell_mapping.BVS_cell),
            places=self.required_accuracy,
            msg="BVS",
        )

        self.assertAlmostEqual(
            result.hmotnost_vsadzky,
            self.value_from_excel(self.cell_mapping.hmotnost_vsadzky_cell),
            places=self.required_accuracy,
            msg="Hmotnost vsadzky",
        )

        self.assertAlmostEqual(
            result.zn,
            self.value_from_excel(self.cell_mapping.zn_cell),
            places=self.required_accuracy,
            msg="Zn",
        )

        self.assertAlmostEqual(
            result.alkalie,
            self.value_from_excel(self.cell_mapping.alkalie_cell),
            places=self.required_accuracy,
            msg="Alkalie",
        )

        self.assertAlmostEqual(
            result.p,
            self.value_from_excel(self.cell_mapping.p_cell),
            places=self.required_accuracy,
            msg="P",
        )

        self.assertAlmostEqual(
            result.mn,
            self.value_from_excel(self.cell_mapping.mn_cell),
            places=self.required_accuracy,
            msg="Mn",
        )

        self.assertAlmostEqual(
            result.pomer_kc_ar,
            self.value_from_excel(self.cell_mapping.pomer_kc_ar_cell),
            places=self.required_accuracy,
            msg="Pomer kc ku ar",
        )

        self.assertAlmostEqual(
            result.celkove_so2,
            self.value_from_excel(self.cell_mapping.celkove_so2_cell),
            places=self.required_accuracy,
            msg="Celkove SO2",
        )

        self.assertAlmostEqual(
            result.mgo_v_troske,
            self.value_from_excel(self.cell_mapping.mgo_v_troske_cell),
            places=self.required_accuracy,
            msg="MgO v troske",
        )

        self.assertAlmostEqual(
            result.hmotnost_aglomeratu,
            self.value_from_excel(self.cell_mapping.hmotnost_aglomeratu_cell),
            places=self.required_accuracy,
            msg="Hmotnost aglomeratu",
        )

        self.assertAlmostEqual(
            result.bazicita_aglomeratu,
            self.value_from_excel(self.cell_mapping.bazicita_aglomeratu_cell),
            places=self.required_accuracy,
            msg="Bazicita aglomeratu",
        )

        self.assertAlmostEqual(
            result.q_spalin,
            self.value_from_excel(self.cell_mapping.q_spalin_cell),
            places=0,
            # test was failing randomly with default accuracy, most likely due to float arithmetic
            msg="Q spalin",
        )

    def test_spracovacie_naklady_na_tonu_fe_na_vp(self):
        self.assertAlmostEqual(
            spracovacie_naklady_na_tonu_fe_na_vp(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.spracovacie_naklady_na_tonu_fe_na_vp_cell),
            places=self.required_accuracy,
        )

    def test_s_zo_vsadzky(self):
        self.assertAlmostEqual(
            s_zo_vsadzky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.s_zo_vsadzky_cell),
            places=self.required_accuracy,
        )

    def test_s_po_zihani_v_aglomerate(self):
        for zlozka_aglomeratu in ZlozkaAglomeratu:
            self.assertAlmostEqual(
                s_po_zihani_v_aglomerate(self.input_data, zlozka_aglomeratu, self.korigovane_hmotnosti),
                self.value_from_excel(self.cell_mapping.s_po_zihani_v_aglomerate_cell(zlozka_aglomeratu)),
                places=self.required_accuracy,
                msg=zlozka_aglomeratu,
            )

    def test_cena_co2(self):
        self.assertAlmostEqual(
            cena_co2(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkova_cena_co2_cell),
            places=self.required_accuracy,
        )

    def test_cena_paliva_na_tonu_fe_z_bvs(self):
        self.assertAlmostEqual(
            cena_paliva_na_tonu_fe_z_bvs(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkova_cena_paliva_na_tonu_fe_z_bvs_cell),
            places=self.required_accuracy,
        )

    def test_prepoctova_cena(self):
        self.assertAlmostEqual(
            prepoctova_cena(self.input_data, self.hmotnosti, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.prepoctova_cena_cell),
            places=self.required_accuracy,
        )

    def test_celkovy_vyskyt_trosky(self):
        self.assertAlmostEqual(
            celkovy_vyskyt_trosky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkovy_vyskyt_trosky_cell),
            places=self.required_accuracy,
        )

    def test_celkovy_vytazok_fe(self):
        self.assertAlmostEqual(
            celkovy_vytazok_fe(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkovy_vytazok_fe_cell),
            places=self.required_accuracy,
        )

    def test_celkova_spotreba_vapenca(self):
        self.assertAlmostEqual(
            celkova_spotreba_vapenca(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkova_spotreba_vapenca_cell),
            places=self.required_accuracy,
        )

    def test_celkove_alkalie(self):
        self.assertAlmostEqual(
            celkove_alkalie(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkove_alkalie_cell),
            places=self.required_accuracy,
        )

    def test_celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(self):
        self.assertAlmostEqual(
            celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkove_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky_cell),
            places=self.required_accuracy,
        )

    def test_penalta_s(self):
        self.assertAlmostEqual(
            penalta_na_S(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.penalta_na_S_cell),
            places=self.required_accuracy,
        )

    def test_penalta_p(self):
        self.assertAlmostEqual(
            penalta_na_P(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.penalta_na_P_cell),
            places=self.required_accuracy,
        )

    def test_palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky(self):
        self.assertAlmostEqual(
            palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.palivo_na_aglomerat_z_bvs_plus_vyskyt_trosky_cell),
            places=self.required_accuracy,
        )

    def test_pridavok_paliva_na_odparenie_vlhkosti(self):
        self.assertAlmostEqual(
            pridavok_paliva_na_odparenie_vlhkosti(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.pridavok_paliva_na_odparenie_vlhkosti_cell),
            places=self.required_accuracy,
        )

    def test_percentualny_podiel_prvkov_v_surovine_v_dodanom_stave(self):
        self.assertAlmostEqual(
            percentualny_podiel_prvkov_v_surovine_v_dodanom_stave(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(
                self.cell_mapping.percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_cell
            ),
            places=self.required_accuracy,
        )

    def test_percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    percentualny_podiel_prvkov_v_surovine_v_dodanom_stave_pre_prisadu(prisada),
                    self.value_from_excel(
                        self.cell_mapping.podiel_prvkov_v_surovine_v_dodanom_stave_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_pridavok_paliva_na_odparenie_vlhkosti_pre_prisadu(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    pridavok_paliva_na_odparenie_vlhkosti_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.pridavok_paliva_na_odparenie_vlhkosti_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_s_po_zihani_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    s_po_zihani_prisada(prisada),
                    self.value_from_excel(self.cell_mapping.s_po_zihani_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_hmotnost_v_aglomerate_do_vsadzky(self):
        for zlozka_aglomeratu in ZlozkaAglomeratu:
            with self.subTest(zlozka_aglomeratu):
                self.assertAlmostEqual(
                    hmotnost_v_aglomerate_do_vsadzky(
                        self.input_data, zlozka_aglomeratu, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.hmotnost_v_aglomerate_do_vsadzky_cell(zlozka_aglomeratu)
                    ),
                    places=self.required_accuracy,
                    msg=zlozka_aglomeratu,
                )

    def test_percentualny_podiel_paliva(self):
        for typ_paliva in TypPaliva:
            self.assertAlmostEqual(
                percentualny_podiel_paliva(self.input_data, typ_paliva),
                self.value_from_excel(self.cell_mapping.percentualny_podiel_paliva_cell(typ_paliva)),
                places=self.required_accuracy,
                msg=typ_paliva,
            )

    def test_palivo_potrebne_na_skut_vyrobu_aglomeratu(self):
        self.assertAlmostEqual(
            palivo_potrebne_na_skut_vyrobu_aglomeratu(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.palivo_potrebne_na_skut_vyrobu_aglomeratu_cell),
            places=self.required_accuracy,
        )

    def test_percentualny_obsah_latky_v_zlozke_vsadzky(self):
        for zlozka_vsadzky in ZlozkaVsadzky:
            for latka in ChemickaLatka:
                self.assertAlmostEqual(
                    percentualny_obsah_v_zlozke_vsadzky(
                        self.input_data,
                        latka,
                        zlozka_vsadzky,
                        self.korigovane_hmotnosti,
                    ),
                    self.value_from_excel(
                        self.cell_mapping.percentualny_obsah_v_zlozke_vsadzky_cell(latka, zlozka_vsadzky)
                    ),
                    places=self.required_accuracy,
                    msg=(latka, zlozka_vsadzky),
                )

    def test_percentualny_obsah_latky_v_zlozke_aglomeratu(self):
        for zlozka_aglomeratu in ZlozkaAglomeratu:
            for latka in ChemickaLatka:
                self.assertAlmostEqual(
                    percentualny_obsah_v_zlozke_aglomeratu(
                        self.input_data,
                        latka,
                        zlozka_aglomeratu,
                        self.korigovane_hmotnosti,
                    ),
                    self.value_from_excel(
                        self.cell_mapping.percentualny_obsah_v_zlozke_aglomeratu_cell(
                            latka, zlozka_aglomeratu
                        )
                    ),
                    places=self.required_accuracy,
                    msg=(latka, zlozka_aglomeratu),
                )

    def test_obsah_chemickej_latky_vo_vsadzke(self):
        for latka in ChemickaLatka:
            with self.subTest(latka):
                self.assertAlmostEqual(
                    obsah_chemickej_latky_vo_vsadzke(self.input_data, latka, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.obsah_chemickej_latky_vo_vsadzke_cell(latka)),
                    places=self.required_accuracy,
                    msg=latka,
                )

    def test_hmotnost_vo_vsadzke(self):
        for zlozka_vsadzky in ZlozkaVsadzky:
            self.assertAlmostEqual(
                hmotnost_vo_vsadzke(self.input_data, zlozka_vsadzky, self.korigovane_hmotnosti),
                self.value_from_excel(self.cell_mapping.hmotnost_vo_vsadzke_cell(zlozka_vsadzky)),
                places=self.required_accuracy,
                msg=zlozka_vsadzky,
            )

    def test_pomer_zlozky_vsadzky_vo_vsadzke(self):
        for zlozka_vsadzky in ZlozkaVsadzky:
            self.assertAlmostEqual(
                pomer_zlozky_vsadzky_vo_vsadzke(self.input_data, zlozka_vsadzky, self.korigovane_hmotnosti),
                self.value_from_excel(self.cell_mapping.pomer_zlozky_vsadzky_vo_vsadzke_cell(zlozka_vsadzky)),
                places=self.required_accuracy,
                msg=zlozka_vsadzky,
            )

    def test_celkove_mnozstvo_paliva_do_vp(self):
        self.assertAlmostEqual(
            celkove_mnozstvo_paliva_do_VP(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.celkove_mnozstvo_paliva_do_VP_cell),
            places=self.required_accuracy,
        )

    def test_mnozstvo_koksu_na_zlozku_vsadzky(self):
        for zlozka_vsadzky in ZlozkaVsadzky:
            with self.subTest(zlozka_vsadzky):
                mnozstvo_koksu_hodnota = mnozstvo_koksu_na_zlozku_vsadzky(
                    self.input_data, zlozka_vsadzky, self.korigovane_hmotnosti
                )
                if zlozka_vsadzky in {ZlozkaVsadzky.VAPENEC, ZlozkaVsadzky.POPOL_Z_PALIVA}:
                    self.assertEqual(mnozstvo_koksu_hodnota, 0.0, msg=zlozka_vsadzky)
                else:
                    self.assertAlmostEqual(
                        mnozstvo_koksu_hodnota,
                        self.value_from_excel(
                            self.cell_mapping.mnozstvo_koksu_na_zlozku_vsadzky_cell(zlozka_vsadzky)
                        ),
                        places=self.required_accuracy,
                        msg=zlozka_vsadzky,
                    )

    def test_palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    palivo_na_surovinu_z_bvs_plus_vyskyt_trosky(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.palivo_na_surovinu_z_bvs_plus_vyskyt_trosky_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_vyskyt_trosky_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    vyskyt_trosky_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.vyskyt_trosky_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_pomer_prvku_v_prisade_s_pridanim_vapenca(self):
        for prisada in self.input_data.vsetky_prisady:
            for latka in ChemickaLatka:
                with self.subTest(f"Prisada: {prisada.nazov} latka: {latka}"):
                    if latka == ChemickaLatka.Fe_MET:
                        continue
                    self.assertAlmostEqual(
                        pomer_prvku_v_prisade_s_pridanim_vapenca(
                            self.input_data,
                            prisada,
                            latka,
                            self.korigovane_hmotnosti,
                        ),
                        self.value_from_excel(
                            self.cell_mapping.pomer_prvku_v_prisade_s_pridanim_vapenca_cell(prisada, latka)
                        ),
                        places=self.required_accuracy,
                        msg=(prisada, latka),
                    )

    def test_pomer_prvku_v_prisade_susina(self):
        for prisada in self.input_data.vsetky_prisady:
            for latka in ChemickaLatka:
                with self.subTest(f"Prisada: {prisada.nazov} latka: {latka}"):
                    self.assertAlmostEqual(
                        pomer_prvku_v_prisade_susina(prisada, latka),
                        self.value_from_excel(
                            self.cell_mapping.pomer_prvku_v_prisade_susina_cell(prisada, latka)
                        ),
                        places=self.required_accuracy,
                        msg=(prisada, latka),
                    )

    def test_pridavok_vapenca(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    pridavok_vapenca_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.pridavok_vapenca_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_popol_t_z_500kg_koksu_na_t_suroviny(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    popol_t_z_500kg_koksu_na_t_suroviny_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.popol_t_z_500kg_koksu_na_t_suroviny_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_palivo_na_aglomeracii_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(f"Prisada: {prisada.nazov} bazicky typ: {prisada.bazicky_typ}"):
                self.assertAlmostEqual(
                    palivo_na_aglomeracii_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.palivo_na_aglomeracii_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_palivo_na_aglomeracii(self):
        self.assertAlmostEqual(
            palivo_na_aglomeracii(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.palivo_na_aglomeracii_cell),
            places=self.required_accuracy,
        )

    def test_mnozstvo_co2_na_t_fe_z_aglomeratu(self):
        self.assertAlmostEqual(
            mnozstvo_co2_na_t_fe_z_aglomeratu(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.mnozstvo_co2_na_t_fe_z_aglomeratu_cell),
            places=self.required_accuracy,
        )

    def test_mnozstvo_paliva_na_aglomerat(self):
        self.assertAlmostEqual(
            mnozstvo_paliva_na_aglomerat(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.mnozstvo_paliva_na_aglomerat_cell),
            places=self.required_accuracy,
        )

    def test_hmotnost_vapenca_2(self):
        self.assertAlmostEqual(
            hmotnost_vapenca_2(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.hmotnost_vapenca_2_cell),
            places=self.required_accuracy,
        )

    def test_alkalie_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    alkalie_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.alkalie_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_koeficient_na_spotrebu_vapenca_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    koeficient_na_spotrebu_vapenca_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.koeficient_na_spotrebu_vapenca_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_koeficient_na_metalicke_zelezo_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    koeficient_na_metalicke_zelezo_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.koeficient_na_metalicke_zelezo_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_fe_met_pri_jednotkovom_p2(self):
        for prisada in self.input_data.vsetky_prisady:
            self.assertAlmostEqual(
                fe_met_pri_jednotkovom_p2(self.input_data, prisada, self.korigovane_hmotnosti),
                self.value_from_excel(self.cell_mapping.fe_met_pri_jednotkovom_p2_cell(prisada)),
                places=self.required_accuracy,
                msg=prisada,
            )

    def test_mnozstvo_koksu_na_prisadu(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    mnozstvo_koksu_na_prisadu(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.mnozstvo_koksu_na_prisadu_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_mgo_v_troske(self):
        self.assertAlmostEqual(
            mgo_v_troske(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.mgo_v_troske_cell),
            places=self.required_accuracy,
        )

    def test_cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(self):
        self.assertAlmostEqual(
            cena_aglom_suroviny_plus_palivo_na_tonu_suroviny(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.cena_aglom_suroviny_plus_palivo_na_tonu_suroviny_cell),
            places=self.required_accuracy,
        )

    def test_cena_aglomeracneho_paliva(self):
        self.assertAlmostEqual(
            cena_aglomeracneho_paliva(self.input_data, self.korigovane_hmotnosti),
            self.value_from_excel(self.cell_mapping.cena_aglomeracneho_paliva_cell),
            places=self.required_accuracy,
        )

    def test_cena_prisady_na_tonu_fe(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    celkova_cena_za_tonu_fe_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.celkova_cena_za_tonu_fe_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_spracovacie_naklady_na_tonu_fe_na_vp_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    spracovacie_naklady_na_tonu_fe_na_vp_prisada(self.input_data, prisada),
                    self.value_from_excel(
                        self.cell_mapping.spracovacie_naklady_na_tonu_fe_na_vp_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_cena_co2_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    cena_co2_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.cena_co2_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_cena_co2_v_tonach_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.cena_co2_v_tonach_na_1_tsz_zo_suroviny_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_penaltka_P_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    penalta_na_P_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.penalta_na_P_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_penaltka_S_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    penalta_na_S_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.penalta_na_S_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_cena_paliva_na_tonu_fe_z_bvs_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    cena_paliva_na_tonu_fe_z_bvs_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(
                        self.cell_mapping.cena_paliva_na_tonu_fe_z_bvs_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_cena_prepoctova_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    cena_prepoctova_prisada(self.input_data, prisada, self.korigovane_hmotnosti),
                    self.value_from_excel(self.cell_mapping.cena_prepoctova_prisada_cell(prisada)),
                    places=self.required_accuracy,
                    msg=prisada,
                )

    def test_mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada(self):
        for prisada in self.input_data.vsetky_prisady:
            with self.subTest(prisada.nazov):
                self.assertAlmostEqual(
                    mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada(
                        self.input_data, prisada, self.korigovane_hmotnosti
                    ),
                    self.value_from_excel(
                        self.cell_mapping.mnozstvo_co2_na_tonu_fe_z_tony_aglomeratu_prisada_cell(prisada)
                    ),
                    places=self.required_accuracy,
                    msg=prisada,
                )
