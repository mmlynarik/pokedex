# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
# pylint: disable=too-many-statements
import unittest

from pycel import ExcelCompiler

from viu_core import (
    ChemickaLatka,
    ExcelCellMapping,
    generate_input_from_excel,
    generate_limits_from_excel,
    load_hmotnosti_prisad,
)
from viu_core.datamodel.model import AglomeracnyTyp, BazickyTyp

from . import DATA_PATH_REV12


class TestGenerateInputData(unittest.TestCase):
    excel = ExcelCompiler(filename=DATA_PATH_REV12)
    cell_mapping = ExcelCellMapping(excel)

    def test_input_data(self):
        input_data = generate_input_from_excel(self.excel, self.cell_mapping)
        required_accuracy = 9  # 9 decimal places

        self.assertAlmostEqual(input_data.koef_odtriedenia_peliet, 0.8, places=required_accuracy)
        self.assertAlmostEqual(input_data.cena_vp_koksu, 209.04, places=required_accuracy)
        self.assertAlmostEqual(input_data.cena_tony_co2, 55, places=required_accuracy)
        self.assertAlmostEqual(input_data.bvs_minuly_mesiac, 59.37, places=required_accuracy)
        self.assertAlmostEqual(
            input_data.spracovacie_naklady_na_tonu_suroveho_zeleza, 40.76, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.spracovacie_naklady_na_tonu_aglomeratu, 21.75, places=required_accuracy
        )
        self.assertAlmostEqual(input_data.priemerne_percento_P, 0.057, places=required_accuracy)
        self.assertAlmostEqual(input_data.priemerne_percento_S, 0.048, places=required_accuracy)
        self.assertAlmostEqual(input_data.percento_Si, 0.63, places=required_accuracy)
        self.assertAlmostEqual(input_data.hbt, 1100, places=required_accuracy)
        self.assertAlmostEqual(input_data.eta_co, 50, places=required_accuracy)
        self.assertAlmostEqual(input_data.msp, 500, places=required_accuracy)
        self.assertAlmostEqual(
            input_data.suma_vapencov_a_dolomitov_na_t_aglomeratu_z_thu, 272.53, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.realne_palivo_pri_p2_z_minuleho_mesiaca, 61.72, places=required_accuracy
        )
        self.assertAlmostEqual(input_data.cena_aglom_paliva, 81.86, places=required_accuracy)
        self.assertAlmostEqual(input_data.bohatost_suroveho_zeleza, 94.53, places=required_accuracy)
        self.assertAlmostEqual(input_data.co2_z_uhlia, 2.84, places=required_accuracy)
        self.assertAlmostEqual(input_data.co2_z_koks_orech, 2.848, places=required_accuracy)
        self.assertAlmostEqual(input_data.co2_z_vp_metalurg, 3.063, places=required_accuracy)
        self.assertAlmostEqual(input_data.co2_z_koks_prach, 2.591, places=required_accuracy)
        self.assertAlmostEqual(input_data.celkove_palivo_uhlie, 126, places=required_accuracy)
        self.assertAlmostEqual(input_data.celkove_palivo_koks_orech, 30, places=required_accuracy)
        self.assertAlmostEqual(input_data.percento_fe_kal, 63.360795, places=required_accuracy)
        self.assertAlmostEqual(input_data.percento_fe_vyhoz, 42.41754, places=required_accuracy)
        self.assertAlmostEqual(input_data.koeficient_vyroby_aglomeratu, 1.03, places=required_accuracy)
        self.assertAlmostEqual(input_data.koef_na_bvs, 1.05391, places=required_accuracy)
        self.assertAlmostEqual(input_data.planovane_mnozstvo_zp, 10.0, places=required_accuracy)
        self.assertAlmostEqual(input_data.cena_zp, 0.34, places=required_accuracy)
        self.assertAlmostEqual(input_data.cena_pu, 150.0, places=required_accuracy)
        self.assertAlmostEqual(input_data.planovane_mnozstvo_pu, 140.0, places=required_accuracy)
        self.assertAlmostEqual(input_data.hmotnost_mspu, 139.986, places=required_accuracy)

        # ASH
        self.assertAlmostEqual(input_data.popol_koks_prach.percento_popola, 16.3, places=required_accuracy)
        self.assertAlmostEqual(input_data.popol_kb1.percento_popola, 10.48, places=required_accuracy)
        # Just few random components
        self.assertAlmostEqual(
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe], 0.0, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe2O3], 8.02, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Fe_MET], 0.0, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.popol_koks_prach.chemicke_zlozenie[ChemickaLatka.Na2O], 0.74, places=required_accuracy
        )

        # AGLOORES
        self.assertEqual(len(input_data.aglorudy), 6)
        agloores_dict = {x.nazov: x for x in input_data.aglorudy}
        self.assertIn("AR-KB57", agloores_dict)
        self.assertIn("AR-KB52", agloores_dict)
        self.assertNotIn("Podsitné pelety", agloores_dict)
        self.assertNotIn("OTER-MIN (NORDKAP)", agloores_dict)

        self.assertAlmostEqual(agloores_dict["AR-KB57"].cena_za_tonu, 81.98, places=required_accuracy)
        self.assertAlmostEqual(
            agloores_dict["AR-KB52"].chemicke_zlozenie[ChemickaLatka.Fe], 54.79, places=required_accuracy
        )
        self.assertAlmostEqual(
            agloores_dict["AR-KB57"].chemicke_zlozenie[ChemickaLatka.H2O], 3.7, places=required_accuracy
        )
        self.assertAlmostEqual(
            agloores_dict["AR-KB52"].chemicke_zlozenie[ChemickaLatka.FeO], 0.83, places=required_accuracy
        )
        self.assertAlmostEqual(
            agloores_dict["AR-SB60"].chemicke_zlozenie[ChemickaLatka.Fe2O3],
            82.19,
            places=required_accuracy,
        )
        self.assertEqual(agloores_dict["AR-KB57"].aglomeracny_typ, AglomeracnyTyp.AGLORUDA)

        # CONCENTRATES
        self.assertEqual(len(input_data.koncentraty), 1)
        concentrates_dict = {x.nazov: x for x in input_data.koncentraty}
        self.assertNotIn("KC-Juz65,5", concentrates_dict)
        self.assertIn("KC-LEB", concentrates_dict)
        self.assertAlmostEqual(concentrates_dict["KC-LEB"].cena_za_tonu, 110.96, places=required_accuracy)
        self.assertAlmostEqual(
            concentrates_dict["KC-LEB"].chemicke_zlozenie[ChemickaLatka.SiO2],
            4.35,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            concentrates_dict["KC-LEB"].chemicke_zlozenie[ChemickaLatka.CaO],
            0.22,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            concentrates_dict["KC-LEB"].chemicke_zlozenie[ChemickaLatka.MgO], 0.32, places=required_accuracy
        )
        self.assertAlmostEqual(
            concentrates_dict["KC-LEB"].chemicke_zlozenie[ChemickaLatka.Al2O3],
            0.16,
            places=required_accuracy,
        )
        self.assertEqual(concentrates_dict["KC-LEB"].aglomeracny_typ, AglomeracnyTyp.KONCENTRAT)

        # PELLETS
        self.assertEqual(len(input_data.pelety), 11)
        pellets_dict = {x.nazov: x for x in input_data.pelety}
        self.assertIn("PEL-MI63", pellets_dict)
        self.assertIn("PEL-MI65", pellets_dict)
        self.assertIn("PEL-MINN", pellets_dict)
        self.assertIn("PEL-Kachkanar", pellets_dict)
        self.assertIn("PEL-CEG65 F", pellets_dict)
        self.assertAlmostEqual(pellets_dict["PEL-CEG65 F"].cena_za_tonu, 178.47, places=required_accuracy)
        self.assertAlmostEqual(
            pellets_dict["PEL-MI63"].chemicke_zlozenie[ChemickaLatka.Mn],
            0.020,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            pellets_dict["PEL-MI65"].chemicke_zlozenie[ChemickaLatka.Fe_MET],
            0.0,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            pellets_dict["PEL-CEG65 F"].chemicke_zlozenie[ChemickaLatka.P], 0.009, places=required_accuracy
        )
        self.assertAlmostEqual(
            pellets_dict["PEL-MI65"].chemicke_zlozenie[ChemickaLatka.S], 0.011, places=required_accuracy
        )
        self.assertAlmostEqual(pellets_dict["PEL-MI65"].rozsev_pod_5mm, 3.4079, places=required_accuracy)
        self.assertAlmostEqual(pellets_dict["PEL-MINN"].rozsev_pod_5mm, 5.7628, places=required_accuracy)
        self.assertAlmostEqual(pellets_dict["PEL-SE63"].rozsev_pod_5mm, 2.48, places=required_accuracy)
        self.assertAlmostEqual(
            pellets_dict["PEL-MINN"].chemicke_zlozenie[ChemickaLatka.Na2O],
            0.012,
            places=required_accuracy,
        )
        self.assertEqual(pellets_dict["PEL-MINN"].aglomeracny_typ, AglomeracnyTyp.ZIADEN)

        # BF ADDITIVES
        self.assertEqual(len(input_data.prisady_do_vp), 5)
        bf_additives_dict = {x.nazov: x for x in input_data.prisady_do_vp}
        self.assertIn("TR-B-110", bf_additives_dict)
        self.assertIn("Briketa - K", bf_additives_dict)
        self.assertNotIn("TR-PST", bf_additives_dict)
        self.assertAlmostEqual(bf_additives_dict["TR-B-110"].rozsev_pod_5mm, 5, places=required_accuracy)
        self.assertAlmostEqual(bf_additives_dict["TR-B-110"].cena_za_tonu, 21.41, places=required_accuracy)
        self.assertAlmostEqual(
            bf_additives_dict["TR-B-110"].chemicke_zlozenie[ChemickaLatka.K2O],
            0.05,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            bf_additives_dict["TR-B-110"].chemicke_zlozenie[ChemickaLatka.TiO2],
            0.022,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            bf_additives_dict["Briketa - K"].chemicke_zlozenie[ChemickaLatka.Pb],
            0.008,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            bf_additives_dict["Briketa - K"].chemicke_zlozenie[ChemickaLatka.Zn],
            0.157,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            bf_additives_dict["TR-B-110"].chemicke_zlozenie[ChemickaLatka.Fe_MET],
            80,
            places=required_accuracy,
        )
        self.assertEqual(bf_additives_dict["Briketa - K"].aglomeracny_typ, AglomeracnyTyp.ZIADEN)

        # AGLO ADDITIVES
        self.assertEqual(len(input_data.prisady_do_aglomeratu), 11)
        aglo_additives_dict = {x.nazov: x for x in input_data.prisady_do_aglomeratu}
        self.assertIn("KC-BULG", aglo_additives_dict)
        self.assertIn("MN-RUMUN 17%", aglo_additives_dict)
        self.assertIn("KRA-VAP", aglo_additives_dict)
        self.assertIn("MIK-VAP", aglo_additives_dict)
        self.assertIn("OKU-VAL", aglo_additives_dict)
        self.assertIn("OKU-KYS", aglo_additives_dict)
        self.assertNotIn("Oter z peliet", aglo_additives_dict)
        self.assertIn("VYHOZ VP1", aglo_additives_dict)
        self.assertIn("AG-VAP-P", aglo_additives_dict)
        self.assertIn("DOLOM-P", aglo_additives_dict)
        self.assertIn("VA-K", aglo_additives_dict)
        self.assertIn("Eramet 44% (Mn Gabon)", aglo_additives_dict)
        self.assertAlmostEqual(aglo_additives_dict["VYHOZ VP1"].cena_za_tonu, 3.98, places=required_accuracy)
        self.assertAlmostEqual(
            aglo_additives_dict["VA-K"].chemicke_zlozenie[ChemickaLatka.As],
            0.0,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            aglo_additives_dict["DOLOM-P"].chemicke_zlozenie[ChemickaLatka.C],
            12.476,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            aglo_additives_dict["OKU-KYS"].chemicke_zlozenie[ChemickaLatka.Cl],
            0.02,
            places=required_accuracy,
        )
        self.assertAlmostEqual(
            aglo_additives_dict["KC-BULG"].chemicke_zlozenie[ChemickaLatka.Fe_MET],
            0.0,
            places=required_accuracy,
        )
        self.assertEqual(aglo_additives_dict["DOLOM-P"].aglomeracny_typ, AglomeracnyTyp.ZIADEN)
        self.assertEqual(aglo_additives_dict["DOLOM-P"].bazicky_typ, BazickyTyp.AGLO_DOLOMIT)
        self.assertEqual(aglo_additives_dict["VA-K"].bazicky_typ, BazickyTyp.AGLO_VAPNO)
        self.assertEqual(aglo_additives_dict["AG-VAP-P"].bazicky_typ, BazickyTyp.AGLO_VAPENEC)

        # LIMESTONE
        self.assertAlmostEqual(input_data.vapenec.cena_za_tonu, 9.85, places=required_accuracy)
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.H2O], 0.0, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.SiO2], 0.12, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.CaO], 55.81, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.MgO], 0.44, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.Al2O3], 0.13, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.C], 12.2, places=required_accuracy
        )
        self.assertAlmostEqual(
            input_data.vapenec.chemicke_zlozenie[ChemickaLatka.Fe], 0.1, places=required_accuracy
        )
        self.assertEqual(input_data.vapenec.aglomeracny_typ, AglomeracnyTyp.ZIADEN)
        self.assertEqual(input_data.vapenec.bazicky_typ, BazickyTyp.VP_VAPENEC)

    def test_weights(self):
        weights = load_hmotnosti_prisad(self.excel, self.cell_mapping)
        required_accuracy = 9  # 9 decimal places
        self.assertEqual(len(weights), 35)
        self.assertIn("AR-KB57", weights)
        self.assertIn("AR-KB52", weights)
        self.assertIn("Dijap 51 (Rudomine)", weights)
        self.assertNotIn("OTER-MIN (NORDKAP)", weights)
        self.assertNotIn("KC-Juz65,5", weights)
        self.assertIn("KC-LEB", weights)
        self.assertIn("PEL-MI63", weights)
        self.assertIn("PEL-MI65", weights)
        self.assertIn("PEL-MINN", weights)
        self.assertIn("PEL-Kachkanar", weights)
        self.assertIn("PEL-CEG65 F", weights)
        self.assertIn("TR-B-110", weights)
        self.assertIn("Briketa - K", weights)
        self.assertIn("KC-BULG", weights)
        self.assertIn("MN-RUMUN 17%", weights)
        self.assertIn("KRA-VAP", weights)
        self.assertIn("MIK-VAP", weights)
        self.assertIn("OKU-VAL", weights)
        self.assertIn("OKU-KYS", weights)
        self.assertNotIn("Oter z peliet", weights)
        self.assertIn("VYHOZ VP1", weights)
        self.assertIn("AG-VAP-P", weights)
        self.assertIn("DOLOM-P", weights)
        self.assertIn("VA-K", weights)
        self.assertIn("Eramet 44% (Mn Gabon)", weights)

        self.assertAlmostEqual(weights["AR-KB57"], 0, places=required_accuracy)
        self.assertAlmostEqual(weights["KC-LEB"], 631578.2128927412, places=required_accuracy)
        self.assertAlmostEqual(weights["PEL-MI63"], 158911.9869272426, places=required_accuracy)
        self.assertAlmostEqual(weights["Briketa - K"], 12000, places=required_accuracy)
        self.assertAlmostEqual(weights["MIK-VAP"], 37999.98061556293, places=required_accuracy)
        self.assertAlmostEqual(weights["VA-K"], 8865.27057143697, places=required_accuracy)
        self.assertAlmostEqual(weights["PEL-SE63"], 161.9547702856005, places=required_accuracy)

    def test_limits(self):
        limits = generate_limits_from_excel(self.excel, self.cell_mapping)
        required_accuracy = 9  # 9 decimal places

        self.assertAlmostEqual(limits.aglomerat.min, 1200000, places=required_accuracy)
        self.assertAlmostEqual(limits.aglomerat.max, 1500000, places=required_accuracy)
        self.assertAlmostEqual(limits.vytazok_fe.min, 3666800, places=required_accuracy)
        self.assertAlmostEqual(limits.vytazok_fe.max, 3666900, places=required_accuracy)
        self.assertAlmostEqual(limits.bazicita.min, 0.95, places=required_accuracy)
        self.assertAlmostEqual(limits.bazicita.max, 1.0, places=required_accuracy)
        self.assertAlmostEqual(limits.mgo_do_trosky.min, 7.3, places=required_accuracy)
        self.assertAlmostEqual(limits.mgo_do_trosky.max, 9.0, places=required_accuracy)
        self.assertAlmostEqual(limits.zn.min, 0.0, places=required_accuracy)
        self.assertAlmostEqual(limits.zn.max, 220, places=required_accuracy)
        self.assertAlmostEqual(limits.alkalie.min, 2.0, places=required_accuracy)
        self.assertAlmostEqual(limits.alkalie.max, 3.1, places=required_accuracy)
        self.assertAlmostEqual(limits.p.min, 0.0, places=required_accuracy)
        self.assertAlmostEqual(limits.p.max, 0.06, places=required_accuracy)
        self.assertAlmostEqual(limits.mn.min, 0.45, places=required_accuracy)
        self.assertAlmostEqual(limits.mn.max, 0.5, places=required_accuracy)
        self.assertAlmostEqual(limits.pomer_kc_ar.min, 1, places=required_accuracy)
        self.assertAlmostEqual(limits.pomer_kc_ar.max, 1.04, places=required_accuracy)

        # AGLOORES
        self.assertEqual(len(limits.aglorudy), 6)
        agloores_dict = {x.nazov: x for x in limits.aglorudy}
        self.assertIn("AR-KB57", agloores_dict)
        self.assertIn("AR-KB52", agloores_dict)
        self.assertNotIn("OTER-MIN (NORDKAP)", agloores_dict)
        self.assertAlmostEqual(agloores_dict["AR-KB57"].min, 0, places=required_accuracy)
        self.assertAlmostEqual(agloores_dict["AR-KB57"].max, 850000.0, places=required_accuracy)

        # CONCENTRATES
        self.assertEqual(len(limits.koncentraty), 1)
        concentrates_dict = {x.nazov: x for x in limits.koncentraty}
        self.assertNotIn("KC-Juz65,5", concentrates_dict)
        self.assertIn("KC-LEB", concentrates_dict)
        self.assertNotIn("KC-JUZ68", concentrates_dict)
        self.assertAlmostEqual(concentrates_dict["KC-LEB"].min, 1, places=required_accuracy)
        self.assertAlmostEqual(concentrates_dict["KC-LEB"].max, 1000000, places=required_accuracy)

        # PELLETS
        self.assertEqual(len(limits.pelety), 11)
        pellets_dict = {x.nazov: x for x in limits.pelety}
        self.assertIn("PEL-MI63", pellets_dict)
        self.assertIn("PEL-MI65", pellets_dict)
        self.assertIn("PEL-MINN", pellets_dict)
        self.assertIn("PEL-Kachkanar", pellets_dict)
        self.assertIn("PEL-CEG65 F", pellets_dict)
        self.assertAlmostEqual(pellets_dict["PEL-MI63"].min, 1, places=required_accuracy)
        self.assertAlmostEqual(pellets_dict["PEL-MI63"].max, 2000000, places=required_accuracy)

        # BF ADDITIVES
        self.assertEqual(len(limits.prisady_do_vp), 5)
        bf_additives_dict = {x.nazov: x for x in limits.prisady_do_vp}
        self.assertIn("TR-B-110", bf_additives_dict)
        self.assertIn("Briketa - K", bf_additives_dict)
        self.assertAlmostEqual(bf_additives_dict["TR-B-110"].min, 1.0, places=required_accuracy)
        self.assertAlmostEqual(bf_additives_dict["TR-B-110"].max, 60000, places=required_accuracy)

        # AGLO ADDITIVES
        self.assertEqual(len(limits.prisady_do_aglomeratu), 11)
        aglo_additives_dict = {x.nazov: x for x in limits.prisady_do_aglomeratu}
        self.assertIn("KC-BULG", aglo_additives_dict)
        self.assertIn("MN-RUMUN 17%", aglo_additives_dict)
        self.assertIn("KRA-VAP", aglo_additives_dict)
        self.assertIn("MIK-VAP", aglo_additives_dict)
        self.assertIn("OKU-VAL", aglo_additives_dict)
        self.assertIn("OKU-KYS", aglo_additives_dict)
        self.assertNotIn("Oter z peliet", aglo_additives_dict)
        self.assertIn("VYHOZ VP1", aglo_additives_dict)
        self.assertIn("AG-VAP-P", aglo_additives_dict)
        self.assertIn("DOLOM-P", aglo_additives_dict)
        self.assertIn("VA-K", aglo_additives_dict)
        self.assertIn("Eramet 44% (Mn Gabon)", aglo_additives_dict)
        self.assertAlmostEqual(aglo_additives_dict["VYHOZ VP1"].min, 9000.0, places=required_accuracy)
        self.assertAlmostEqual(aglo_additives_dict["VYHOZ VP1"].max, 30000.0, places=required_accuracy)

        # LIMESTONE
        self.assertAlmostEqual(limits.vapenec.min, 0.0, places=required_accuracy)
        self.assertAlmostEqual(limits.vapenec.max, 250000.0, places=required_accuracy)
