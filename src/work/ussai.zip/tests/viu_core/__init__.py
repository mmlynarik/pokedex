from pathlib import Path

DATA_PATH_REV8 = Path(__file__).parent / "test_data/model_rev8.xlsm"
DATA_PATH_REV9 = Path(__file__).parent / "test_data/model_rev9.xlsm"
DATA_PATH_REV11 = Path(__file__).parent / "test_data/model_rev11.xlsm"
DATA_PATH_REV12 = Path(__file__).parent / "test_data/model_rev12.xlsm"
