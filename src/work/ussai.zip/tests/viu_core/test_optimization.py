# type: ignore
# TODO see http://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/441
import unittest
from typing import List

from pycel import ExcelCompiler

from viu_core import (
    ExcelCellMapping,
    VsadzkaInput,
    generate_input_from_excel,
    generate_limits_from_excel,
    optimize_slsqp,
    precise_optimization,
)

from . import DATA_PATH_REV12


def get_all_component_names(input_data: VsadzkaInput) -> List[str]:
    return [x.nazov for x in input_data.vsetky_prisady]


class TestOptimization(unittest.TestCase):
    excel = ExcelCompiler(filename=DATA_PATH_REV12)
    cell_mapping = ExcelCellMapping(excel)

    def _test_loop(self, method, options):
        input_data = generate_input_from_excel(self.excel, self.cell_mapping)
        limits = generate_limits_from_excel(self.excel, self.cell_mapping)
        weight_limits_dict = {x.nazov: x for x in limits.all_limits}

        callback_called = 0
        last_percentage = 0.0

        def process_callback(percentage_done: float):
            nonlocal callback_called
            nonlocal last_percentage

            callback_called += 1
            self.assertGreater(percentage_done, last_percentage)
            last_percentage = percentage_done

        variants = method(input_data, limits, options, process_callback)
        self.assertGreater(len(variants), 0)
        for weights, price in variants:
            self.assertGreater(price, 0.0)
            for name in get_all_component_names(input_data):
                self.assertIn(name, weights)
                self.assertGreaterEqual(weights[name], weight_limits_dict[name].min, msg=name)
                self.assertLessEqual(weights[name], weight_limits_dict[name].max, msg=name)

        self.assertGreater(callback_called, 0)

    def test_basic_optimization(self):
        self._test_loop(optimize_slsqp, {"maxiter": 10, "ftol": 1e-10})

    @unittest.skip("Test runs about 45 minutes. Optimization is required.")
    def test_precise_optimization(self):
        self._test_loop(precise_optimization, {"random_iters": 2, "maxiter": 20, "ftol": 1e-10})


if __name__ == "__main__":
    unittest.main()
