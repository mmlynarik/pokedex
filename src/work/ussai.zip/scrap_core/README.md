# Scrap Core

Core calculations for scrap model

To run `train_scrap_blend_model`.

TODO write more about dataset creation, model training ...

## Setup problems

Pytorch wheel for windows is not available from pypy. Therefore, on Windows machines it needs to be installed separately with command 

`pip install torch===1.4.0 -f https://download.pytorch.org/whl/torch_stable.html` 

## Versions

| Version | Date       | Change Description                                      |
|---------|------------|---------------------------------------------------------|
| 0.0.1   | 2020-??-?? | Initial version of `scrap_core` package                 |
| 0.1.0   | 2023-10-31 | Update version of `scrap_core` package for the 1st time |
