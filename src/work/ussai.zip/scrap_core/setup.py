"""A setuptools based setup module.

See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

from os import path

# Always prefer setuptools over distutils
from setuptools import setup

here = path.abspath(path.dirname(__file__))

with open(path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="scrapcore",
    version="0.4.0",
    package_data={
        "scrap_core": ["py.typed"],
        "scrap_core.datamodel": ["py.typed", "load_full_heat_from_oko.sql", "load_heat_plan_from_iars.sql"],
        "scrap_core.blendmodel": [
            "py.typed",
            "trained_models/blend_model_v1.pth",
            "trained_models/eob_model_v6.pth",
        ],
        "scrap_core.yieldmodel": ["py.typed"],
        "scrap_core.meltabilitymodel": ["py.typed"],
        "scrap_core.optimization": ["py.typed"],
        "scrap_core.correctiontechnologiesmodel": ["py.typed"],
        "scrap_core.evaluation": ["py.typed"],
        "scrap_core.blendmodel.eob_datamodule": ["py.typed"],
        "scrap_core.home_scrap_estimation": [
            "py.typed",
            "estimators/1PIT.json",
            "estimators/DSI.json",
            "estimators/HS.json",
            "estimators/HSB.json",
            "estimators/HST.json",
            "estimators/HSZ.json",
        ],
    },
    packages=[
        "scrap_core",
        "scrap_core.datamodel",
        "scrap_core.blendmodel",
        "scrap_core.home_scrap_estimation",
        "scrap_core.home_scrap_estimation.scrap_supplies",
        "scrap_core.yieldmodel",
        "scrap_core.optimization",
        "scrap_core.meltabilitymodel",
        "scrap_core.correctiontechnologiesmodel",
        "scrap_core.evaluation",
        "scrap_core.heat_matching",
        "scrap_core.blendmodel.eob_datamodule",
        "scrap_core.pytorch_balanced_sampler",
        "scrap_core.telegrams",
        "scrap_core.weightmodel",
    ],
    description="Calculations for scrap model",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=[
        "attr_runtime_validation==0.0.1",
        "torch==2.1.1",
        "torchvision==0.16.1",
        "pytorch-lightning==1.7.7",
        "torchmetrics==0.7.0",
        "attrs>=22.1.0",
        "cattrs>=22.1.0",
        "numpy==1.26.*",
        "tqdm==4.66.*",
        "immutables>=0.14",
        "pymssql==2.3.*",
        "python-dotenv==1.0.*",
        "jsonlines==4.0.*",
        "bayesian-optimization==1.5.*",
        "cachetools==5.5.*",
        "pandas==2.0.*",
        "pandera==0.13.*",
        "pyodbc==5.1.*",
        "spacecutter==0.2.*",
        "scipy>=1.7.3",
        "returns>=0.23.0",
        # this is needed for bug in tensorboard - # TODO remove tensorboard dependency
        # "setuptools==59.5.0",
        "ussklevel2==0.9.*",
        "usskscadaocclient==1.4.*",
    ],
    zip_safe=False,
    entry_points={
        "console_scripts": [
            "generate_blend_model_training_data=scrap_core.generate_blendmodel_training_data:main",
            "pig_iron=scrap_core.pigironanalysis:main",
            "train_eob_model=scrap_core.blendmodel.eob_model_training:main",
            "test_eob_model=scrap_core.blendmodel.eob_model_test:main",
            "train_home_scrap_estimators=scrap_core.home_scrap_estimation.train_home_scrap_estimators:main",
        ]
    },
)
