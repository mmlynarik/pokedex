#!/usr/bin/env python

import argparse
import datetime
import time
from statistics import mean, median
from typing import List, Callable, NamedTuple, Dict

from bayes_opt import BayesianOptimization
import pandas as pd
import numpy as np
from scrap_core import Chem
from sklearn.metrics import mean_absolute_error
from tqdm import tqdm

from scrap_core.datamodel import Heat, load_heats_from_file


class ValueWithTimestamp(NamedTuple):
    value: float
    timestamp: int


class PredictorWithError(NamedTuple):
    error: float
    name: str


Predictor = Callable[[List[float]], float]
ChemData = List[ValueWithTimestamp]


def parse_args():
    parser = argparse.ArgumentParser(
        description="Analysis to determine chemistry of pig iron for next x days"
    )
    parser.add_argument("path", type=str, help="Path to json with heat data")
    parser.add_argument("length_of_prediction", type=float, help="Length of prediction in days")
    parser.add_argument(
        "chem",
        type=str,
        choices=["S", "P", "Cu", "Sn", "Cr", "Mo", "Ni", "Si"],
        help="What chem to predict",
    )
    return parser.parse_args()


def get_prediction_for_chem(heats: List[Heat], predictor: Predictor, chem: Chem) -> float:
    chem_values = [x.value for x in get_after_desulf_values_for_chem(heats, chem)]
    return predictor(chem_values)


def get_s_values_by_grade(heats: List[Heat]) -> Dict[int, float]:
    grade_and_values_pd = pd.DataFrame.from_records(
        [(heat.grade_planned.grade_id, heat.after_desulf.S) for heat in heats],
        columns=["grade", "values_of_s"],
    )
    grade_and_values_mean = (grade_and_values_pd.groupby("grade").mean()).to_dict("dict")["values_of_s"]
    grade_and_values_median = (grade_and_values_pd.groupby("grade").median()).to_dict("dict")["values_of_s"]

    real_s_values = [heat.after_desulf.S for heat in heats]
    mean_predictions = [grade_and_values_mean.get(heat.grade_planned.grade_id) for heat in heats]
    median_predictions = [grade_and_values_median.get(heat.grade_planned.grade_id) for heat in heats]

    mean_error = mean_absolute_error(real_s_values, mean_predictions)
    median_error = mean_absolute_error(real_s_values, median_predictions)

    if mean_error < median_error:
        return grade_and_values_mean

    return grade_and_values_median


def create_median_predictor(window_size: int) -> Predictor:
    def median_predictor(train_data: List[float]) -> float:
        return median(train_data[-window_size:])

    return median_predictor


def create_average_predictor(window_size: int) -> Predictor:
    def average_predictor(train_data: List[float]) -> float:
        return mean(train_data[-window_size:])

    return average_predictor


def all_data_median_predictor(train_data: List[float]) -> float:
    return median(train_data)


def all_data_average_predictor(train_data: List[float]) -> float:
    return mean(train_data)


def create_linear_weighted_average_predictor(window_size: int) -> Predictor:
    def weighted_linear_average_predictor(train_data: List[float]) -> float:
        window = np.array(train_data[-window_size:])
        weights = np.linspace(0.1, 1.0, len(window))
        weights = weights / weights.sum()
        return (window * weights).sum()

    return weighted_linear_average_predictor


def create_exponential_weighted_average_predictor(window_size: int) -> Predictor:
    def weighted_exponential_average_predictor(train_data: List[float]) -> float:
        window = np.array(train_data[-window_size:])
        weights = np.logspace(-1.0, 0.0, len(window))
        weights = weights / weights.sum()
        return (window * weights).sum()

    return weighted_exponential_average_predictor


def get_time_window_starts(predicted_interval: int, data: ChemData, test_data_start: int) -> List[int]:
    timestamp = data[test_data_start].timestamp
    string_datetime = datetime.datetime.fromtimestamp(int(timestamp)).strftime("%Y-%m-%d")
    timestamp = int(time.mktime(datetime.datetime.strptime(string_datetime, "%Y-%m-%d").timetuple()))
    time_window_starts = [timestamp + predicted_interval]
    while time_window_starts[-1] + predicted_interval < data[len(data) - 1].timestamp:
        tmp = time_window_starts[-1] + predicted_interval
        time_window_starts.append(tmp)
    return time_window_starts


def test_predictor(
    data: ChemData, predictor: Predictor, test_data_start: int, predicted_interval: int
) -> float:
    all_errors = []
    time_window_starts = get_time_window_starts(predicted_interval, data, test_data_start)
    for window_start in time_window_starts:

        train_data = [x.value for x in data if x.timestamp < window_start]
        test_data = [x.value for x in data if window_start <= x.timestamp < window_start + predicted_interval]

        if test_data:
            prediction = predictor(train_data)
            error = mean_absolute_error([prediction] * len(test_data), test_data)
            all_errors.append(error)
    return sum(all_errors) / len(all_errors)


def pick_best_predictor(data: ChemData, predictors: list, test_data_start: int, predicted_interval: int):
    results = [
        PredictorWithError(test_predictor(data, predictor, test_data_start, predicted_interval), name)
        for name, predictor in tqdm(predictors)
    ]
    best_predictor = min(results, key=lambda x: x.error)
    valid_predictors = [x.name for x in results if x.error <= best_predictor.error + 0.001]

    return best_predictor, valid_predictors


def get_after_desulf_values_for_chem(heats: List[Heat], chem: Chem) -> ChemData:
    return [ValueWithTimestamp(getattr(h.after_desulf, chem), int(h.heat_datetime)) for h in heats]


def get_best_predictor_window(
    window_size: int, predicted_interval: int, predictor: Predictor, data: ChemData, test_data_start: int
) -> float:
    if not isinstance(window_size, int):
        raise Exception(f"Window size must be int but was: {window_size}")

    all_errors = []

    time_window_starts = get_time_window_starts(predicted_interval, data, test_data_start)
    for window_start in time_window_starts:

        train_data = [x.value for x in data if x.timestamp < window_start]
        test_data = [x.value for x in data if window_start <= x.timestamp < window_start + predicted_interval]

        if test_data:
            prediction = predictor(train_data)
            error = mean_absolute_error([prediction] * len(test_data), test_data)
            all_errors.append(error)
    return -(sum(all_errors) / len(all_errors))


def get_best_window_size(
    pbounds_min: int,
    pbounds_max: int,
    predicted_interval: int,
    predictor: Callable[[int], Predictor],
    data: ChemData,
) -> int:
    optimizer = BayesianOptimization(
        f=create_fitness_function(predictor, predicted_interval, data, pbounds_max),
        pbounds={"x": (pbounds_min, pbounds_max)},
        random_state=1,
    )
    optimizer.maximize(n_iter=25, init_points=5, kappa=10)  # 1 and 0 just for testing
    best_window_size = optimizer.max

    return int(best_window_size["params"]["x"])


def create_fitness_function(
    predictor: Callable[[int], Predictor], predicted_interval: int, data: ChemData, test_data_start: int
) -> Callable[[float], float]:
    def fitness_function(x: float) -> float:
        window_size = int(x)
        return get_best_predictor_window(
            window_size, predicted_interval, predictor(window_size), data, test_data_start
        )

    return fitness_function


def load_and_sort_heats(path_to_heats: str) -> List[Heat]:
    heats = load_heats_from_file(path_to_heats)
    heats.sort(key=lambda heat: heat.heat_datetime)
    return heats


def get_best_predictor_for_chem(heats: List[Heat], chem: Chem, predicted_days: float, max_window_size: int):
    heats_chem = get_after_desulf_values_for_chem(heats, chem)
    predicted_interval = int(predicted_days * 86400)  # 24 * 60 * 60
    # for all calls of get_best_window_size we have to use same bounds
    # it has to be the same so we can test on the same dataset
    min_window_size = 1

    predictor_median_best_window = get_best_window_size(
        min_window_size, max_window_size, predicted_interval, create_median_predictor, heats_chem
    )
    predictor_average_best_window = get_best_window_size(
        min_window_size, max_window_size, predicted_interval, create_average_predictor, heats_chem
    )
    predictor_lin_best_window = get_best_window_size(
        min_window_size,
        max_window_size,
        predicted_interval,
        create_linear_weighted_average_predictor,
        heats_chem,
    )
    predictor_exp_best_window = get_best_window_size(
        min_window_size,
        max_window_size,
        predicted_interval,
        create_exponential_weighted_average_predictor,
        heats_chem,
    )

    predictor = (
        [
            (
                f"Median {predictor_median_best_window}",
                create_median_predictor(predictor_median_best_window),
            )
        ]
        + [
            (
                f"Average {predictor_average_best_window}",
                create_average_predictor(predictor_average_best_window),
            )
        ]
        + [
            (
                f"Linear weighted average {predictor_lin_best_window}",
                create_linear_weighted_average_predictor(predictor_lin_best_window),
            )
        ]
        + [
            (
                f"Exponential weighted average {predictor_exp_best_window}",
                create_exponential_weighted_average_predictor(predictor_exp_best_window),
            )
        ]
        + [("All data median", all_data_median_predictor)]
        + [("All data average", all_data_average_predictor)]
    )

    return pick_best_predictor(heats_chem, predictor, max_window_size, predicted_interval)


def main():
    args = parse_args()
    heats = load_and_sort_heats(args.path)
    valid_heats = [h for h in heats if not np.isnan(getattr(h.after_desulf, args.chem))]

    # S values are calcualted by grade due to desulf process
    if args.chem == "S":
        print("Values for S:")
        print(get_s_values_by_grade(valid_heats))

    if args.chem != "S":
        best_predictor, valid_predictors = get_best_predictor_for_chem(
            valid_heats, args.chem, args.length_of_prediction, 1800
        )
        print("Best predictor is:", best_predictor.name, "Error is:", best_predictor.error)
        print("Also predictors with error within 0.001 of best predictor: ", valid_predictors)


if __name__ == "__main__":
    main()
