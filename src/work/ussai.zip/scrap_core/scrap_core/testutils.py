from typing import Tuple

from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit, RelaxableValue
from scrap_core.meltabilitymodel import SCRAP_MELTABILITY_V2
from scrap_core.optimization.default_settings import DEFAULT_LOADABILITY_LIMITS
from scrap_core import SUPPORTED_SCRAP_TYPES, ScrapMix, ScrapMixOrder
from usskssgrades.grade import QST_GRADES


def get_default_relaxable_upper_summing_limits(
    grade_id: int, allowed_factor: float = 1.2
) -> Tuple[RelaxableUpperSummingLimit, ...]:
    all_grades_limits = (
        # Since buckets have limited volume, sometimes scrap just don't fit
        # if we try to use to much of certain types. Due to space limitations of buckets
        # we limit the amount of scrap that can be used/loaded in 1 heat
        # (usually 1 heat consists of 2 buckets)
        *(
            RelaxableUpperSummingLimit(
                name=f"load_limit ({scrap_type})",
                scrap_types=(scrap_type,),  # type: ignore
                weight_limit=RelaxableValue(weight, weight * allowed_factor),
                ratio=RelaxableValue(1, 1),
            )
            for scrap_type, weight in DEFAULT_LOADABILITY_LIMITS.items()
        ),
        # Limit usage of heavy scrap, because it is rare and it is usually used
        # on top of the heat to squeeze the scrap below. It is hard to melt, too.
        RelaxableUpperSummingLimit(
            name="heavy_scrap_limit",
            scrap_types=("HSZ", "HSB", "HSB COOL"),
            weight_limit=RelaxableValue(5000, 5000 * allowed_factor),
            ratio=RelaxableValue(1, 1),
        ),
        # optimal heat should consist of scrap with easy and hard meltability in ratio 1:1
        *(
            RelaxableUpperSummingLimit(
                name=f"meltability_{'easy' if meltability_type == 'L' else 'hard'}_limit",
                scrap_types=tuple(
                    scrap_type
                    for scrap_type in SUPPORTED_SCRAP_TYPES
                    # scrap with unknown meltability is considered
                    # as a scrap with medium meltability, hence omitted
                    if SCRAP_MELTABILITY_V2.get(scrap_type, "S") == meltability_type
                ),
                weight_limit=RelaxableValue(100000, 100000),
                ratio=RelaxableValue(0.5, 0.5 * allowed_factor),
            )
            for meltability_type in ["L", "T"]
        ),
    )

    # QSt steel grades are alloyed and hence it is difficult to reclassify
    # such heat if needed. Moreover, PIT-like scrap usually contains lot of dirt,
    # which is undesirable in these grades as well.
    # TODO fill in correct values - scrap types and weight limit
    specific_limits = (
        RelaxableUpperSummingLimit(
            name="qst_pit_limit",
            scrap_types=(),
            weight_limit=RelaxableValue(10000, 10000 * allowed_factor),
            ratio=RelaxableValue(1, 1),
        ),
    )
    if grade_id in QST_GRADES:
        return all_grades_limits + specific_limits
    return all_grades_limits
