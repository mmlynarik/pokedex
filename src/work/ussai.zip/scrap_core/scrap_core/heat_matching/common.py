import datetime
from typing import Tuple, Optional, Callable, Dict

from immutables import Map
import pandera as pa
from pandera.typing import Index, DataFrame, Series

from scrap_core import HeatKey


BASKET_TYPO_TOLERANCE = 1


class _CommonData(pa.SchemaModel):
    heat_key: Series[HeatKey]
    scrap_weight: Series[int]
    scrap_charge: Series[Dict[str, float]]
    planned_grade_id: Series[int]
    baskets: Series[Tuple[int, ...]]
    steelshop: Series[int]

    @classmethod
    def get_columns(cls):
        return [
            cls.heat_key,
            cls.scrap_weight,
            cls.scrap_charge,
            cls.planned_grade_id,
            cls.baskets,
            cls.steelshop,
        ]


class AppData(_CommonData):
    scrap_charge_id: Index[int]
    closed_at: Series[datetime.datetime]

    @classmethod
    def get_columns(cls):
        return super().get_columns() + [cls.closed_at]


class DbData(_CommonData):
    heat_datetime: Series[datetime.datetime]  # utc of course

    @classmethod
    def get_columns(cls):
        return super().get_columns() + [cls.heat_datetime]


# index of app data record (closed_heat_id) matched with heat key
Matching = Map[int, HeatKey]

# inputs are record/row in AppData table and table of db data to match,
# output is the heat key of matched db record, if any
MatchingStrategy = Callable[[Series[AppData], DataFrame[DbData]], Optional[HeatKey]]
