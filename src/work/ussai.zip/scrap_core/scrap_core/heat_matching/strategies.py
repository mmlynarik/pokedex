"""
same steelshop everywhere

[v1] baskets exact, scrap charge similar

[v1] baskets similar, scrap charge similar

[v0] baskets exact
"""

import datetime
from typing import Optional, Dict, Any, Tuple

import pandas as pd
from pandera.typing import DataFrame, Series

from scrap_core import HeatKey
from scrap_core.heat_matching.common import AppData, DbData, BASKET_TYPO_TOLERANCE


def _dicts_are_similar(a: Dict[Any, float], b: Dict[Any, float], tolerance: float) -> bool:

    keys = set(a) | set(b)

    return all(abs(a.get(key, 0) - b.get(key, 0)) <= tolerance for key in keys)


def _strings_are_similar(a: str, b: str, tolerance: int) -> bool:
    return len(a) == len(b) and sum(ca != cb for ca, cb in zip(a, b)) <= tolerance


def baskets_are_similar(baskets_a: Tuple[int, ...], baskets_b: Tuple[int, ...], typo_tolerance: int) -> bool:
    # same baskets
    if set(baskets_a) == set(baskets_b):
        return True

    # missing 1 basket
    if abs(len(baskets_a) - len(baskets_b)) <= 1 and (
        set(baskets_a).issubset(baskets_b) or set(baskets_b).issubset(baskets_a)
    ):
        return True

    # typo in 1 basket
    if _strings_are_similar("".join(map(str, baskets_a)), "".join(map(str, baskets_b)), typo_tolerance):
        return True

    # typo in 1 basket and different order
    if _strings_are_similar("".join(map(str, baskets_a)), "".join(map(str, baskets_b[::-1])), typo_tolerance):
        return True

    return False


def _restrict_by_time(df: DataFrame[DbData], *, start: pd.Timestamp, end: pd.Timestamp) -> DataFrame[DbData]:
    within_expected_window = (start <= df[DbData.heat_datetime]) & (df[DbData.heat_datetime] < end)
    return df[within_expected_window].copy()


def match_record_by_baskets_exact_and_scrap_charge_similar(
    rec_app: Series[AppData],
    df_db: DataFrame[DbData],
    time_tolerance: datetime.timedelta,
    weight_tolerance: float,
) -> Optional[HeatKey]:
    """
    Pick the first db record satisfying following conditions:
        - is inside window [created_at, created_at + time_tolerance]
        - steelshop is the same
        - basket ids are the same
        - scrap charges are similar
    """
    # select matching window first - optimization step
    df_window = _restrict_by_time(
        df_db, start=rec_app[AppData.closed_at], end=rec_app[AppData.closed_at] + time_tolerance
    )

    same_steelshop = df_window[DbData.steelshop] == rec_app[AppData.steelshop]

    same_baskets = df_window[DbData.baskets].apply(sorted).astype(str) == str(
        sorted(rec_app[AppData.baskets])
    )

    similar_scrap_charge = df_window[DbData.scrap_charge].apply(
        lambda sc: _dicts_are_similar(sc, rec_app[AppData.scrap_charge], weight_tolerance)
    )

    candidates_db = df_window[same_steelshop & same_baskets & similar_scrap_charge]

    if candidates_db.empty:
        return None

    # pick the first matching record's heat key
    return candidates_db.sort_values(DbData.heat_datetime)[DbData.heat_key].iloc[0]


def match_record_by_baskets_similar_and_scrap_charge_similar(
    rec_app: Series[AppData],
    df_db: DataFrame[DbData],
    time_tolerance: datetime.timedelta,
    weight_tolerance: int,
) -> Optional[HeatKey]:
    """
    Pick the first db record satisfying following conditions:
        - is inside window [created_at, created_at + time_tolerance]
        - steelshop is the same
        - basket ids are similar
        - scrap charges are similar
    """
    # select matching window first - optimization step
    df_window = _restrict_by_time(
        df_db, start=rec_app[AppData.closed_at], end=rec_app[AppData.closed_at] + time_tolerance
    )

    same_steelshop = df_window[DbData.steelshop] == rec_app[AppData.steelshop]

    similar_baskets = df_window[DbData.baskets].apply(
        lambda b: baskets_are_similar(b, rec_app[AppData.baskets], BASKET_TYPO_TOLERANCE)
    )

    similar_scrap_charge = df_window[DbData.scrap_charge].apply(
        lambda sc: _dicts_are_similar(sc, rec_app[AppData.scrap_charge], weight_tolerance)
    )

    candidates_db = df_window[same_steelshop & similar_baskets & similar_scrap_charge]

    if candidates_db.empty:
        return None

    # pick the first matching record's heat key
    return candidates_db.sort_values(DbData.heat_datetime)[DbData.heat_key].iloc[0]


def match_record_by_baskets_exact(
    rec_app: Series[AppData],
    df_db: DataFrame[DbData],
    time_tolerance: datetime.timedelta,
) -> Optional[HeatKey]:
    """
    Pick the first db record satisfying following conditions:
        - is inside window [created_at, created_at + time_tolerance]
        - steelshop is the same
        - basket ids are the same
    """
    # select matching window first - optimization step
    df_window = _restrict_by_time(
        df_db, start=rec_app[AppData.closed_at], end=rec_app[AppData.closed_at] + time_tolerance
    )

    same_steelshop = df_window[DbData.steelshop] == rec_app[AppData.steelshop]

    same_baskets = df_window[DbData.baskets].apply(sorted).astype(str) == str(
        sorted(rec_app[AppData.baskets])
    )

    candidates_db = df_window[same_steelshop & same_baskets]

    if candidates_db.empty:
        return None

    # pick the first matching record's heat key
    return candidates_db.sort_values(DbData.heat_datetime)[DbData.heat_key].iloc[0]
