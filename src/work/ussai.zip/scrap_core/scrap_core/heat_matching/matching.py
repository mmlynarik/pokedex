"""
Purpose of this module is to pair records from `AppData` dataframe (closed heats from VIU Scrap app)
and records from `DbData` dataframe (heat data from Scada OC database)

Actual matching is implemented in `find_matching` function as follows:

    for each matching strategy:
        - using given matching strategy match records from app and db // `_match_records` function
        - find unmatched records from app and db data // `_find_remainders` function

Currently 3 simple matching strategy is implemented:
    - `match_record_by_baskets_exact_and_scrap_charge_similar`
    - `match_record_by_baskets_similar_and_scrap_charge_similar`
    - `match_record_by_baskets_exact`

This setting provides successfulness about 90-95%. Possible improvements may be

TODO we may start with strict time tolerance and relax it to maximum time_tolerance given by parameter

For experiments notebook `Close_Heat_Matching.ipynb` may be a good starting point.
"""

import collections
import datetime
import functools
import logging
from typing import Tuple, Dict

from immutables import Map
from pandera.typing import DataFrame

from scrap_core import HeatKey
from scrap_core.heat_matching.common import AppData, DbData, Matching, MatchingStrategy
from scrap_core.heat_matching.strategies import (
    match_record_by_baskets_exact,
    match_record_by_baskets_exact_and_scrap_charge_similar,
    match_record_by_baskets_similar_and_scrap_charge_similar,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def _find_remainders(
    df_app: DataFrame[AppData], df_db: DataFrame[DbData], matching: Matching
) -> Tuple[DataFrame[AppData], DataFrame[DbData]]:
    """Return data from both tables that are not matched yet"""
    rem_app = df_app.loc[~df_app.index.isin(matching.keys())]
    rem_db = df_db.loc[~df_db[DbData.heat_key].isin(matching.values())]
    return rem_app, rem_db


def _get_initial_data(
    df_app: DataFrame[AppData], df_db: DataFrame[DbData]
) -> Tuple[DataFrame[AppData], DataFrame[DbData], Matching]:
    # pick already matched records
    matching = Map(df_app[AppData.heat_key].dropna().to_dict())

    # select remainders
    rem_app, rem_db = _find_remainders(df_app, df_db, matching)

    return rem_app, rem_db, matching


def _match_records(
    df_app: DataFrame[AppData], df_db: DataFrame[DbData], matching_strategy: MatchingStrategy
) -> Matching:
    matching: Dict[int, HeatKey] = {}

    for idx_app, rec_app in df_app.sort_values(AppData.closed_at).iterrows():

        # exclude already matched records to avoid duplicates
        not_matched_yet = ~df_db[DbData.heat_key].isin(matching.values())

        heat_key = matching_strategy(rec_app, df_db[not_matched_yet])

        if heat_key is None:
            continue

        matching[idx_app] = heat_key

    return Map(matching)


def find_matching(
    df_app: DataFrame[AppData],
    df_db: DataFrame[DbData],
    time_tolerance: datetime.timedelta,
) -> Matching:
    def calc_success(matching_len: int, data_len: int) -> float:
        if data_len == 0:
            return 1

        return round(matching_len / data_len, 3)

    def log_statistics(
        state: str, matching_len: int, app_data_len: int, unmatched_app_len: int, unmatched_db_len: int
    ) -> None:
        log.info(
            f"{state} - matched records: {matching_len} / {app_data_len},"
            f" successfulness: {calc_success(matching_len, app_data_len)},"
            f" unmatched records: app = {unmatched_app_len}, db = {unmatched_db_len}"
        )

    initial_app_data_len = len(df_app)

    df_app, df_db, initial_matching = _get_initial_data(df_app, df_db)

    log_statistics(
        state="Initial stats",
        matching_len=len(initial_matching),
        app_data_len=initial_app_data_len,
        unmatched_app_len=len(df_app),
        unmatched_db_len=len(df_db),
    )

    matchings = [initial_matching]

    # rationale:
    #   - at first match records that very likely correspond to the same heat
    #   - relax condition and take typos in basket ids into account
    #   - relax condition and look at baskets only
    strategies: Dict[str, MatchingStrategy] = {
        "exact_baskets_&_similar_charge": functools.partial(
            match_record_by_baskets_exact_and_scrap_charge_similar,
            time_tolerance=time_tolerance,
            weight_tolerance=2000,
        ),
        "similar_baskets_&_similar_charge": functools.partial(
            match_record_by_baskets_similar_and_scrap_charge_similar,
            time_tolerance=time_tolerance,
            weight_tolerance=2000,
        ),
        "exact_baskets": functools.partial(match_record_by_baskets_exact, time_tolerance=time_tolerance),
    }

    for name, strategy in strategies.items():
        current_app_data_len = len(df_app)

        partial_matching = _match_records(df_app, df_db, matching_strategy=strategy)

        df_app, df_db = _find_remainders(df_app, df_db, partial_matching)

        log_statistics(
            state=f"Strategy '{name}'",
            matching_len=len(partial_matching),
            app_data_len=current_app_data_len,
            unmatched_app_len=len(df_app),
            unmatched_db_len=len(df_db),
        )

        matchings.append(partial_matching)

    # join matchings
    final_matching: Matching = Map(dict(collections.ChainMap(*[dict(matching) for matching in matchings])))

    log_statistics(
        state="Final stats",
        matching_len=len(final_matching),
        app_data_len=initial_app_data_len,
        unmatched_app_len=len(df_app),
        unmatched_db_len=len(df_db),
    )

    return final_matching
