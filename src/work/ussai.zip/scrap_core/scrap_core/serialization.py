import json
import logging

import cattr


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# TODO improve typing if possible
def serializable(converter: cattr.Converter):
    def serialize(self, sort_keys: bool = True, indent: int = 2) -> str:
        try:
            return json.dumps(converter.unstructure(self), indent=indent, sort_keys=sort_keys)
        except Exception:
            log.exception(f"Something went wrong when serializing {self}")
            raise

    def deserialize(cls, serialized: str):
        try:
            return converter.structure(json.loads(serialized), cls)
        except Exception:
            log.exception(f"Something went wrong when deserializing {cls}: {serialized}")
            raise

    def decorate(cls):
        cls.serialize = serialize
        cls.deserialize = classmethod(deserialize)
        return cls

    return decorate
