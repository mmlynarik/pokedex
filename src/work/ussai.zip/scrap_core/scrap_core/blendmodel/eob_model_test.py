import argparse
import collections
import logging
import pprint
from typing import Dict, List

import torch
from torch.utils.data import DataLoader

from .eob_config import OKO_CFG, SCADA_CFG, EOB_MODEL_SUPPORTED_CHEMS, DEFAULT_CACHE_DIR, get_chem_input
from .eob_datamodule import get_datamodule
from .eob_model import OrdinalRegressionBlendModel, PLOrdinalRegressionBlendModel
from .eob_model_metric import SimpleMetric, CompositeMetric


logging.basicConfig(level=logging.DEBUG)


def compute_metric(
    model: OrdinalRegressionBlendModel, metric: SimpleMetric, dataloader: DataLoader
) -> torch.Tensor:
    with torch.no_grad():
        metric.reset()
        for x, y in dataloader:
            x_transformed, _ = x
            predictions = model(x_transformed)
            metric.update(predictions, y)
        return metric.compute()


def compute_composite_metric(
    model: OrdinalRegressionBlendModel, metric: CompositeMetric, dataloader: DataLoader
) -> Dict[str, torch.Tensor]:
    with torch.no_grad():
        metric.reset()
        for x, y in dataloader:
            x_transformed, x_original = x
            predictions = model(x_transformed)
            metric.update(predictions, y, x_original)
        return metric.compute()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Test selected EOB (sub)models")

    parser.add_argument(
        "-c",
        "--chems",
        help="Chem elements to show model statistics for",
        type=get_chem_input,
        nargs="*",
        choices=EOB_MODEL_SUPPORTED_CHEMS,
        default=EOB_MODEL_SUPPORTED_CHEMS,
    )
    parser.add_argument(
        "--modelpath",
        help="Path to a model checkpoint",
        type=str,
        required=True,
    )
    parser.add_argument(
        "-a",
        "--allmetrics",
        help="If selected, even composite metrics are included in result statistics",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "-m",
        "--metadata",
        help="If selected, model and dataset parameters are displayed too",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--cachedir",
        help="Path to a directory where training, validation and test data are cached",
        type=str,
        default=DEFAULT_CACHE_DIR,
    )
    return parser.parse_args()


def test_eob_models(
    path: str, chems: List[str], cache_dir: str, all_metrics: bool, display_metadata: bool
) -> None:
    statistics = collections.defaultdict(dict)  # type: collections.defaultdict
    checkpoint = torch.load(path)

    for chem in chems:
        if chem not in checkpoint:
            logging.warning(f"Model for {chem} not available")
        else:
            metadata = checkpoint[chem]
            dataset_params = {
                **metadata["dataset_params"],
                "path_cache": cache_dir,
                "oko_config": OKO_CFG,
                "scada_config": SCADA_CFG,
            }
            datamodule = get_datamodule(**dataset_params)  # type: ignore

            datamodule.prepare_data()
            datamodule.setup(stage="test")

            model = OrdinalRegressionBlendModel(**metadata["model_config"])
            model.load_state_dict(metadata["state_dict"])
            model.eval()

            pl_module = PLOrdinalRegressionBlendModel(
                model,
                datamodule.bins,
                datamodule.input_names,
                learning_rate=0.1,  # dummy value
                model_cfg={},  # dummy value
                dataset_cfg={},  # dummy value
            )
            pl_module = pl_module.eval()

            for metric_name, metric in pl_module.metrics.items():
                statistics[chem][metric_name] = compute_metric(
                    model, metric, datamodule.test_dataloader()  # type: ignore
                )

            if all_metrics:
                for metric_name, metric in pl_module.composite_merics.items():
                    statistics[chem][metric_name] = (
                        compute_composite_metric(model, metric, datamodule.test_dataloader()),  # type: ignore
                    )

    if display_metadata:
        print("Model and dataset metadata")
        print(80 * "-")
        for chem in chems:
            metadata = checkpoint[chem]
            del metadata["state_dict"]
            pprint.pp(metadata)

    print("Model metrics")
    print(80 * "-")
    pprint.pp(statistics)


def main():
    args = parse_args()

    test_eob_models(args.modelpath, args.chems, args.cachedir, args.allmetrics, args.metadata)


if __name__ == "__main__":
    main()
