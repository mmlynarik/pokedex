import os
import re

import torch

from scrap_core.blendmodel.eob_config import EOB_MODEL_SUPPORTED_CHEMS, get_grouping


def get_latest_checkpoint(model_dir):
    latest_checkpoint_name = max(
        [
            filename
            for filename in os.listdir(model_dir)
            if filename.startswith("eob_model") and filename.endswith(".pth")
        ],
        key=lambda filename: os.path.getmtime(os.path.join(model_dir, filename)),
        default=None,
    )
    latest_checkpoint_idx = int(
        re.search(r"v(?P<index>\d+)", latest_checkpoint_name).group("index")  # type: ignore
    )

    return latest_checkpoint_name, latest_checkpoint_idx


def main():
    model_dir = os.path.join(os.path.dirname(__file__), "trained_models")

    checkpoint_name, checkpoint_idx = get_latest_checkpoint(model_dir)
    checkpoint_path = os.path.join(model_dir, checkpoint_name)
    checkpoint = torch.load(checkpoint_path)

    checkpoint_update = {}

    for chem in EOB_MODEL_SUPPORTED_CHEMS:
        grouping = get_grouping(chem)

        checkpoint_update[chem] = {
            "dataset_params": {**checkpoint[chem]["dataset_params"], "scrap_groups": grouping},
            "model_config": checkpoint[chem]["model_config"],
            "state_dict": checkpoint[chem]["state_dict"],
        }

    new_checkpoint = {**checkpoint, **checkpoint_update}
    new_checkpoint_path = os.path.join(model_dir, f"eob_model_v{checkpoint_idx + 1}.pth")
    torch.save(new_checkpoint, new_checkpoint_path)


if __name__ == "__main__":
    main()
