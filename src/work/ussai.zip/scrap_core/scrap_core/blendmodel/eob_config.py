import os

from typing import List, Mapping, Set, cast

from .. import SUPPORTED_SCRAP_TYPES_SET, Chem, ScrapType

SCADA_CFG = {
    "host": os.environ.get("SCADA_DB_HOST"),
    "port": os.environ.get("SCADA_DB_PORT"),
    "database": os.environ.get("SCADA_DB_SID"),
    "username": os.environ.get("SCADA_DB_USER"),
    "password": os.environ.get("SCADA_DB_PASSWORD"),
}

OKO_CFG = {
    "host": os.environ.get("OKO_DB_HOST"),
    "port": os.environ.get("OKO_DB_PORT"),
    "database": os.environ.get("OKO_DB_DATABASE"),
    "username": os.environ.get("OKO_DB_USER"),
    "password": os.environ.get("OKO_DB_PASSWORD"),
}

# eob/blend model for elements other than listed below is not used anywhere
EOB_MODEL_SUPPORTED_CHEMS: Set[Chem] = {"Cr", "Cu", "Mo", "Ni", "S", "Sn", "Si"}


# The rightmost bounded bin is used as bin of last resort to avoid reclassification
# (e.g. in case of Cr it is the bin [0.04, 0.103), the unbounded bin [0.103, 'inf')
# means reclassification) This way models do not automatically refuse to include
# chem sensitive scrap such as HSR Cr, TBC, etc.
BINNING = {
    # the first 2 values are equal to `grade limit - 0.005` due to chromium reblow definition
    "Cr": (0.025, 0.035, 0.103),
    "Cu": (0.015, 0.03, 0.04, 0.045, 0.05, 0.077),
    "Mo": (0.004, 0.006, 0.014),
    "Ni": (0.01, 0.03, 0.049),
    "P": (0.006, 0.01, 0.012, 0.013, 0.014, 0.015, 0.017, 0.018, 0.02, 0.023),
    "S": (0.005, 0.006, 0.007, 0.008, 0.009, 0.01, 0.012, 0.015, 0.016, 0.018, 0.020, 0.022, 0.025),
    "Si": (0.01, 0.019),
    "Sn": (0.003, 0.005, 0.010, 0.015, 0.023),
}

# Even if these scrap types are rare, we need to include them in training dataset,
# because the worst undervalue results correspond to heats with these scrap types.
# So we just remove them from `rare_scrap` dictionary whenever needed.
INTENTIONALLY_NOT_RARE_SCRAP: Mapping[Chem, List[ScrapType]] = {
    "Cr": ["STS", "HSR Cr"],
    "Mo": ["STS", "HSR"],
    "Ni": ["HSR"],
    "Cu": ["TBS", "TBC"],
    "Si": ["HSR Cr"],  # it somehow helps to prevent over-fitting
}

SAMPLER_ALPHA = {"Cr": 0, "Cu": 0.1, "Mo": 0.1, "Ni": 0, "S": 0, "Si": 0.1, "Sn": 0.1}

GROUPING: Mapping[Chem, List[List[str]]] = {
    "Cr": [
        ["HS", "HSR", "HSB", "HSB COOL", "HB", "HDS", "HSZ", "HSA"],
        ["DSI", "DSI A1 2", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "SRB", "BPIT", "2DB"],
        ["1BC", "1BBC", "2BC", "2BBC"],
        ["1TB", "TBC", "TBBC"],
        ["1RR", "1SR", "TRM", "XXX", "HSD"],
        ["ZBS", "TBS"],
        ["1HM", "STS"],
        ["PIG IRON Cr"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["HSR Cr", "HSCA"],
        ["HSK"],
        ["PAS"],
        ["2HM"],
        ["MCE"],
        ["HST"],
        ["SBS"],
        ["1IB"],
        ["1DB"],
        ["1SH"],
        ["2SH"],
        ["1BS"],
        ["SHS"],
        ["PIG IRON"],
    ],
    "Cu": [
        ["HSB", "HSB COOL", "HB", "HS", "HSZ", "HDS", "HSR", "HSR Cr", "HSA", "HSCA"],
        ["DSI", "DSI A1 2", "HSK", "PIG IRON", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2"],
        ["2HM", "1SR", "2DB", "BPIT"],
        ["1HM", "1RR", "1SH", "2SH", "SHS", "STS", "TRM", "XXX", "SRB", "HSD"],
        ["1BC", "2BC", "1BBC", "2BBC"],
        ["1IB", "1TB", "1DB", "1BS"],
        ["TBS", "TBC", "TBBC"],
        ["PIG IRON Cu"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["PAS"],
        ["MCE"],
        ["HST"],
        ["ZBS"],
        ["SBS"],
    ],
    "Mo": [
        ["HSB", "HSB COOL", "HB", "HS", "HSZ", "HSK", "HSR", "HSR Cr", "HDS", "HSA", "HSCA"],
        ["DSI", "DSI A1 2", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "SRB", "BPIT", "2BC", "2BBC"],
        ["1RR", "1SR", "1SH"],
        ["1TB", "TBC", "TBBC", "TRM", "XXX", "HSD"],
        ["ZBS", "TBS"],
        ["1BC", "1BBC"],
        ["STS", "2DB"],
        ["PIG IRON Mo"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["PAS"],
        ["2HM"],
        ["1HM"],
        ["MCE"],
        ["HST"],
        ["SBS"],
        ["1IB"],
        ["1DB"],
        ["2SH"],
        ["1BS"],
        ["SHS"],
        ["PIG IRON"],
    ],
    "Ni": [
        ["HSB", "HSB COOL", "HB", "HS", "HSR", "HSR Cr", "HDS", "HSZ", "HSA", "HSCA"],
        ["DSI", "DSI A1 2", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "SRB", "BPIT"],
        ["HST", "1RR", "1SR", "1SH", "2DB"],
        ["HSK", "TBS", "TBC", "TBBC"],
        ["1BC", "1BBC", "2BC", "2BBC"],
        ["1HM", "STS"],
        ["2HM", "XXX", "TRM", "HSD"],
        ["PIG IRON Ni"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["PAS"],
        ["MCE"],
        ["ZBS"],
        ["SBS"],
        ["1IB"],
        ["1DB"],
        ["1TB"],
        ["2SH"],
        ["1BS"],
        ["SHS"],
        ["PIG IRON"],
    ],
    "S": [
        [
            "HS",
            "HB",
            "HSB",
            "HSB COOL",
            "HST",
            "HSZ",
            "HSR",
            "HSR Cr",
            "HDS",
            "1IB",
            "1BS",
            "SBS",
            "HSA",
            "HSCA",
        ],
        ["1BC", "1BBC", "TBBC", "TBC", "TBS", "2BBC", "2BC"],
        ["DSI", "DSI A1 2", "STS", "TRM", "XXX", "HSD", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "BPIT", "SRB"],
        ["2HM", "2SH", "2DB", "1SR"],
        # ["MCE", "1TB"], -> neoplati sa spajat - mame dost dat
        # ["SHS", "1HM", "2HM"], -> neoplati sa spajat - mame dost dat
        ["HSK", "PIG IRON"],
        ["PIG IRON S"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["PAS"],
        ["1HM"],
        ["MCE"],
        ["ZBS"],
        ["1DB"],
        ["1TB"],
        ["1SH"],
        ["1RR"],
        ["SHS"],
    ],
    "Si": [
        ["HSB", "HSB COOL", "HS", "HB", "HSR", "HSR Cr", "1IB", "HSZ", "HSA", "HSCA"],
        ["DSI", "DSI A1 2", "DSI A1 3"],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "SRB", "BPIT"],
        ["PAS", "2DB", "STS", "SHS", "1SR", "2BC", "2BBC"],  # <= 0.3
        ["1BS", "TBS", "ZBS"],
        ["1BC", "1BBC", "TBC", "TBBC"],  # <= 0.03
        ["MCE", "1SH", "2SH", "1HM", "2HM", "1RR"],  # <= 0.5
        ["PIG IRON", "SBS", "TRM", "XXX", "HDS", "HSD"],  # <= 2.0
        ["PIG IRON Si"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["HSK"],
        ["HST"],
        ["1DB"],
        ["1TB"],
    ],
    "Sn": [
        [
            "HSB",
            "HSB COOL",
            "HS",
            "HB",
            "HSZ",
            "HSR",
            "HSR Cr",
            "1IB",
            "HDS",
            "DSI",
            "DSI A1 2",
            "STS",
            "HSA",
            "HSCA",
            "DSI A1 3",
        ],
        ["1PIT", "1PIT A2"],
        ["2PIT", "2PIT A2", "SRB", "BPIT"],
        ["1SH", "1SR"],
        ["1BC", "2BC", "1BBC", "2BBC"],
        ["1DB", "2DB"],
        ["HST", "TBS", "HSD", "TRM", "XXX"],
        ["1TB", "TBC", "TBBC"],
        ["PIG IRON Sn"],
        ["PIG IRON W"],
        ["PELLETS"],
        ["BRIQUETTES"],
        ["HSK"],
        ["PAS"],
        ["2HM"],
        ["1HM"],
        ["MCE"],
        ["ZBS"],
        ["SBS"],
        ["2SH"],
        ["1RR"],
        ["1BS"],
        ["SHS"],
        ["PIG IRON"],
    ],
}

HIDDEN_FEATURES_COUNT_DEFAULT = 512

HIDDEN_FEATURES_COUNT = {"Cr": 128, "Mo": 32, "Si": 32}

DROPOUT_DEFAULT = 0.5

DROPOUT = {"Cr": 0.8, "Mo": 0.8, "Si": 0.8}


def validate_grouping(grouping: List[List[str]]) -> bool:
    flattened = [item for group in grouping for item in group]
    non_scrap = {"PIG IRON W", "PELLETS", "BRIQUETTES"} | set(
        "PIG IRON " + chem for chem in EOB_MODEL_SUPPORTED_CHEMS
    )
    flattened_scraps = set(flattened).difference(non_scrap)
    return flattened_scraps == SUPPORTED_SCRAP_TYPES_SET and len(set(flattened)) == len(flattened)


def get_grouping(chem: Chem) -> List[List[str]]:
    grouping = GROUPING.get(chem, [])
    if not validate_grouping(grouping):
        raise ValueError(f"Grouping for {chem} does not match supported scrap types set.")
    return grouping


def get_chem_input(value: str) -> Chem:
    if value not in EOB_MODEL_SUPPORTED_CHEMS:
        raise ValueError(f"Unsupported value, expected {EOB_MODEL_SUPPORTED_CHEMS}, got {value}")

    return cast(Chem, value)


DEFAULT_CACHE_DIR = os.path.join("./eob_model_training_cache")
DEFAULT_LOG_DIR = os.path.join("./eob_model_training_logs")
DEFAULT_MODEL_DIR = os.path.join(os.path.dirname(__file__), "trained_models")
