# pylint:disable=no-member,not-callable

import functools
from typing import Callable, Dict, List, Tuple, Protocol

import torch
from torchmetrics import Metric

from .. import SUPPORTED_SCRAP_TYPES


class SimpleMetric(Protocol):
    def update(self, preds: torch.Tensor, target: torch.Tensor) -> None: ...

    def reset(self) -> None: ...

    def compute(self) -> torch.Tensor: ...


class CompositeMetric(Protocol):
    def update(self, preds: torch.Tensor, target: torch.Tensor, x_orig: torch.Tensor) -> None: ...

    def reset(self) -> None: ...

    def compute(self) -> Dict[str, torch.Tensor]: ...


def calc_centered(model_prediction: torch.Tensor, y: torch.Tensor, radius: int) -> torch.Tensor:
    """P(y - n <= prediction <= y + n) ~ prediction[y - n <= prediction <= y + n].sum(dim=1)"""
    return (
        1 - calc_undervalue(model_prediction, y, radius + 1) - calc_overvalue(model_prediction, y, radius + 1)
    )


def calc_undervalue(model_prediction: torch.Tensor, y: torch.Tensor, radius: int) -> torch.Tensor:
    """P(prediction <= y - n) ~ prediction[prediction <= y - n].sum(dim=1)"""
    batch_size, categories_count = model_prediction.size()
    if radius >= categories_count:
        return torch.zeros(1, batch_size).squeeze()
    padding_width = 2 * max(categories_count, abs(radius))
    padding = torch.zeros(batch_size, padding_width)
    padded_prediction = torch.cat([padding, model_prediction, padding], dim=1)
    columns_to_gather = torch.stack(
        [padding_width + y - radius - i for i in range(categories_count - radius, -1, -1)], dim=1
    ).squeeze()
    return padded_prediction.gather(1, columns_to_gather).sum(dim=1)


def calc_overvalue(model_prediction: torch.Tensor, y: torch.Tensor, radius: int) -> torch.Tensor:
    """P(y + n <= prediction) ~ prediction[y + n <= prediction].sum(dim=1)"""
    return 1 - calc_undervalue(model_prediction, y, 1 - radius)


class NPointProba(Metric):
    def __init__(self, radius: int, dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)

        self.calculator = functools.partial(calc_centered, radius=radius)
        self.add_state("proba_sum", default=torch.tensor(0.0), dist_reduce_fx="sum")
        self.add_state("total", default=torch.tensor(0), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor) -> None:  # type: ignore
        self.proba_sum += self.calculator(preds, target).sum()
        self.total += target.numel()  # type: ignore

    def compute(self) -> torch.Tensor:
        return torch.nan_to_num(self.proba_sum / self.total)  # type: ignore


class NPointProbaForScrap(Metric):
    def __init__(self, radius: int, input_names: List[str], dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)

        self.calculator = functools.partial(calc_centered, radius=radius)
        self.input_names = input_names
        self.add_state("proba_sum", default=torch.zeros(len(input_names)), dist_reduce_fx="sum")
        self.add_state("total", default=torch.zeros(len(input_names)), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor, x: torch.Tensor) -> None:  # type: ignore
        non_zeros = x > 0.0
        self.proba_sum += (self.calculator(preds, target).unsqueeze(dim=1) * non_zeros).sum(dim=0)
        self.total += non_zeros.sum(dim=0)

    def compute(self) -> Dict[str, torch.Tensor]:
        metric_value = torch.nan_to_num(self.proba_sum / self.total)  # type: ignore
        return {st: val for st, val in zip(self.input_names, metric_value) if st in SUPPORTED_SCRAP_TYPES}


class NPointProbaForBin(Metric):
    def __init__(self, radius: int, bins: torch.Tensor, dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)

        self.calculator = functools.partial(calc_centered, radius=radius)
        self.bins = bins
        self.eye = torch.eye(len(bins) - 1)
        self.add_state("proba_sum", default=torch.zeros(len(bins) - 1), dist_reduce_fx="sum")
        self.add_state("total", default=torch.zeros(len(bins) - 1), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ,unused-argument
    def update(self, preds: torch.Tensor, target: torch.Tensor, x: torch.Tensor) -> None:  # type: ignore
        """
        Argument `x` is provided only to conform to `update` method signature of composite metrics.
        """
        non_zeros = self.eye[target.squeeze(), :]
        self.proba_sum += (self.calculator(preds, target).unsqueeze(dim=1) * non_zeros).sum(dim=0)
        self.total += non_zeros.sum(dim=0)

    def compute(self) -> Dict[str, torch.Tensor]:
        metric_value = torch.nan_to_num(self.proba_sum / self.total)  # type: ignore
        return dict(
            zip(
                [
                    str([round(x, 4) for x in self.bins[i : i + 2].tolist()])
                    for i in range(len(self.bins) - 1)
                ],
                metric_value,
            )
        )


class NPointProbaForWorstBin(Metric):
    def __init__(self, radius: int, bins: torch.Tensor, dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)

        self.calculator = functools.partial(calc_centered, radius=radius)
        self.bins = bins
        self.eye = torch.eye(len(bins) - 1)
        self.add_state("proba_sum", default=torch.zeros(len(bins) - 1), dist_reduce_fx="sum")
        self.add_state("total", default=torch.zeros(len(bins) - 1), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor) -> None:  # type: ignore
        non_zeros = self.eye[target.squeeze(), :]
        self.proba_sum += (self.calculator(preds, target).unsqueeze(dim=1) * non_zeros).sum(dim=0)
        self.total += non_zeros.sum(dim=0)

    def compute(self) -> torch.Tensor:
        x = torch.nan_to_num(self.proba_sum / self.total)  # type: ignore
        return x.min()


def get_binning_selector(
    lower_bound: torch.Tensor, upper_bound: torch.Tensor
) -> Callable[[torch.Tensor, torch.Tensor], Tuple[torch.Tensor, torch.Tensor]]:
    def selector(data: torch.Tensor, other: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        mask = (lower_bound <= data) & (data < upper_bound)
        return data[mask], other[mask]

    return selector


def get_calibration_binner(
    min_value: float, max_value: float, step: float
) -> Tuple[Callable[[torch.Tensor, torch.Tensor], List[Tuple[torch.Tensor, torch.Tensor]]], int]:
    bins = torch.arange(min_value, max_value + step, step)
    transformers = [get_binning_selector(bins[i], bins[i + 1]) for i in range(len(bins) - 1)]

    def binner(model_prediction: torch.Tensor, y: torch.Tensor) -> List[Tuple[torch.Tensor, torch.Tensor]]:
        reality = torch.zeros_like(model_prediction)
        reality = reality.scatter(1, y, 1.0)
        return [t(model_prediction, reality) for t in transformers]

    return binner, len(transformers)


class CalibrationError(Metric):
    def __init__(
        self,
        step: float,
        min_samples: int,
        reducer: Callable[[torch.Tensor], torch.Tensor],
        dist_sync_on_step: bool = False,
    ):
        super().__init__(dist_sync_on_step=dist_sync_on_step)
        self.binner, bins_count = get_calibration_binner(0.0, 1.0, step)
        self.reducer = reducer

        self.add_state("prediction_bins_sum", default=torch.zeros(bins_count), dist_reduce_fx="sum")
        self.add_state("reality_bins_sum", default=torch.zeros(bins_count), dist_reduce_fx="sum")
        self.add_state("bins_count", default=torch.zeros(bins_count), dist_reduce_fx="sum")
        self.add_state("min_samples", default=torch.tensor(min_samples), dist_reduce_fx=None)

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor) -> None:  # type: ignore
        bins_stats = self.binner(preds, target)

        self.prediction_bins_sum += torch.tensor([x[0].sum() for x in bins_stats])
        self.reality_bins_sum += torch.tensor([x[1].sum() for x in bins_stats])
        self.bins_count += torch.tensor([x[0].numel() for x in bins_stats])

    def compute(self) -> torch.Tensor:
        return self.reducer(
            abs(
                (self.prediction_bins_sum / self.bins_count)  # type: ignore
                - (self.reality_bins_sum / self.bins_count)  # type: ignore
            )[
                self.bins_count > self.min_samples  # type: ignore
            ]
        )


class UndervalueNPointProba(Metric):
    def __init__(self, radius: int, dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)
        self.radius = radius
        self.add_state("proba_sum", default=torch.tensor(0.0), dist_reduce_fx="sum")
        self.add_state("total", default=torch.tensor(0), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor) -> None:  # type: ignore
        self.proba_sum += calc_undervalue(preds, target, self.radius).sum()
        self.total += target.numel()  # type: ignore

    def compute(self) -> torch.Tensor:
        return self.proba_sum / self.total  # type: ignore


class UndervalueNPointProbaForScrap(Metric):
    def __init__(self, radius: int, input_names: List[str], dist_sync_on_step: bool = False):
        super().__init__(dist_sync_on_step=dist_sync_on_step)
        self.radius = radius
        self.input_names = input_names
        self.add_state("proba_sum", default=torch.zeros(len(input_names)), dist_reduce_fx="sum")
        self.add_state("total", default=torch.zeros(len(input_names)), dist_reduce_fx="sum")

    # pylint:disable=arguments-differ
    def update(self, preds: torch.Tensor, target: torch.Tensor, x: torch.Tensor) -> None:  # type: ignore
        non_zeros = x > 0.0
        self.proba_sum += (calc_undervalue(preds, target, self.radius).unsqueeze(dim=1) * non_zeros).sum(
            dim=0
        )
        self.total += non_zeros.sum(dim=0)

    def compute(self) -> Dict[str, torch.Tensor]:
        metric_value = torch.nan_to_num(self.proba_sum / self.total)  # type: ignore
        return {st: val for st, val in zip(self.input_names, metric_value) if st in SUPPORTED_SCRAP_TYPES}
