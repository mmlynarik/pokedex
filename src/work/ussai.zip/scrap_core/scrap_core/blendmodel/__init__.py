import collections
from collections import defaultdict
from functools import cached_property, lru_cache
from pathlib import Path
from typing import Callable, DefaultDict, Dict, List, Mapping, Protocol, Tuple, cast, Union

import numpy as np
import torch
from immutables import Map
from scrap_core import (
    SUPPORTED_SCRAP_TYPES,
    SUPPORTED_SCRAP_TYPES_AS_MIXES,
    Chem,
    ScrapOrder,
    ScrapType,
    vectorize_scrap_weights,
    ScrapMix,
    ScrapMixMapping,
    reverse_vectorize,
)
from scrap_core.blendmodel.datamodel import get_full_binning
from scrap_core.blendmodel.eob_datamodule.eob_dataset import batch_transform, transform
from scrap_core.blendmodel.eob_datamodule.generic_eob_datamodule import (
    create_input_names,
    create_summation_indexes,
)
from scrap_core.blendmodel.eob_model import OrdinalRegressionBlendModel
from scrap_core.blendmodel.datamodel import (
    BlendModelSettings,
    ChemEstimate,
    OrdinalRegressionChemEstimate,
    RawFeChem,
    ScrapBlendModelInput,
    ScrapBlendModelOutput,
    convert_heat_to_scrap_blend_model_input,
    convert_heat_to_scrap_blend_model_output,
)
from scrap_core.utils import get_simple_integer_approximations

ScrapMixResolver = Callable[[Mapping[ScrapMix, float], ScrapMixMapping], Map[ScrapType, float]]

# Scrap mixtures will be transformed to one scrap with worst properties
# Scrap types below are sorted from worst to best for each element
# Calculated with get_chem_in_scrap_approximation
BLEND_MODEL_V2_MIXTURE_RESOLVING_ORDER: Mapping[Chem, Tuple[ScrapType, ...]] = {
    "Cr": (
        "HSCA",
        "HSR Cr",
        "1HM",
        "STS",
        "SHS",
        "2HM",
        "PAS",
        "1SH",
        "2SH",
        "HSK",
        "MCE",
        "1BC",
        "2BC",
        "1BBC",
        "2BBC",
        "1DB",
        "1BS",
        "HSD",
        "1RR",
        "1SR",
        "TRM",
        "XXX",
        "TBS",
        "ZBS",
        "1TB",
        "TBC",
        "TBBC",
        "1IB",
        "1PIT",
        "1PIT A2",
        "PIG IRON",
        "HST",
        "HSA",
        "HSR",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HS",
        "HB",
        "2DB",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "SBS",
        "DSI",
        "DSI A1 2",
        "DSI A1 3",
    ),
    "Cu": (
        "HSD",
        "1HM",
        "1SH",
        "2SH",
        "1RR",
        "STS",
        "SHS",
        "SRB",
        "TRM",
        "XXX",
        "2HM",
        "2DB",
        "1SR",
        "BPIT",
        "PAS",
        "TBS",
        "TBC",
        "TBBC",
        "MCE",
        "1BC",
        "2BC",
        "1BBC",
        "2BBC",
        "2PIT",
        "2PIT A2",
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HS",
        "HB",
        "1IB",
        "1DB",
        "1TB",
        "1BS",
        "HST",
        "ZBS",
        "SBS",
        "1PIT",
        "1PIT A2",
        "HSK",
        "DSI",
        "PIG IRON",
        "DSI A1 2",
        "DSI A1 3",
    ),
    "Mo": (
        "2DB",
        "STS",
        "2SH",
        "HSD",
        "1TB",
        "TBC",
        "TBBC",
        "TRM",
        "XXX",
        "1DB",
        "1BS",
        "1BC",
        "1BBC",
        "PAS",
        "2HM",
        "1IB",
        "PIG IRON",
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HSK",
        "HS",
        "HB",
        "1SH",
        "1RR",
        "1SR",
        "SBS",
        "SHS",
        "HST",
        "2BC",
        "2BBC",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "1PIT",
        "1PIT A2",
        "TBS",
        "ZBS",
        "MCE",
        "1HM",
        "DSI",
        "DSI A1 2",
        "DSI A1 3",
    ),
    "Ni": (
        "SHS",
        "1HM",
        "STS",
        "XXX",
        "HSD",
        "2HM",
        "TRM",
        "2SH",
        "PAS",
        "HST",
        "2DB",
        "1SH",
        "1RR",
        "1SR",
        "ZBS",
        "1BC",
        "2BC",
        "1BBC",
        "2BBC",
        "1BS",
        "HSK",
        "TBS",
        "TBC",
        "TBBC",
        "1IB",
        "MCE",
        "SBS",
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HS",
        "HB",
        "1DB",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "PIG IRON",
        "1TB",
        "1PIT",
        "1PIT A2",
        "DSI",
        "DSI A1 2",
        "DSI A1 3",
    ),
    "S": (
        "HSD",
        "STS",
        "DSI",
        "TRM",
        "DSI A1 2",
        "DSI A1 3",
        "XXX",
        "1PIT",
        "1PIT A2",
        "2HM",
        "2DB",
        "2SH",
        "1SR",
        "1SH",
        "SHS",
        "1HM",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "1RR",
        "PAS",
        "HSK",
        "PIG IRON",
        "MCE",
        "1TB",
        "1DB",
        "1BC",
        "TBS",
        "2BC",
        "TBC",
        "1BBC",
        "2BBC",
        "TBBC",
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HS",
        "HST",
        "SBS",
        "1IB",
        "HB",
        "1BS",
        "ZBS",
    ),
    "Sn": (
        "1TB",
        "TBC",
        "TBBC",
        "HSD",
        "HST",
        "TBS",
        "TRM",
        "XXX",
        "HSK",
        "SHS",
        "2SH",
        "1SH",
        "1SR",
        "2HM",
        "1HM",
        "1BC",
        "2BC",
        "1BBC",
        "2BBC",
        "1RR",
        "ZBS",
        "1DB",
        "2DB",
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HDS",
        "HS",
        "1IB",
        "STS",
        "HB",
        "DSI",
        "DSI A1 2",
        "DSI A1 3",
        "1BS",
        "SBS",
        "PAS",
        "1PIT",
        "1PIT A2",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "MCE",
        "PIG IRON",
    ),
    "Si": (
        "HSA",
        "HSCA",
        "HSR",
        "HSR Cr",
        "HSZ",
        "HSB",
        "HSB COOL",
        "HS",
        "1IB",
        "HB",
        "PAS",
        "2BC",
        "2DB",
        "1SR",
        "STS",
        "2BBC",
        "SHS",
        "DSI",
        "DSI A1 2",
        "DSI A1 3",
        "SRB",
        "BPIT",
        "2PIT",
        "2PIT A2",
        "1BC",
        "TBC",
        "1BBC",
        "TBBC",
        "2HM",
        "1HM",
        "MCE",
        "1SH",
        "2SH",
        "1RR",
        "HST",
        "HDS",
        "HSD",
        "SBS",
        "PIG IRON",
        "TRM",
        "XXX",
        "TBS",
        "ZBS",
        "1BS",
        "1PIT",
        "1PIT A2",
        "1DB",
        "1TB",
        "HSK",
    ),
}


class ScrapBlendModel(Protocol):
    SUPPORTED_CHEMS: Tuple[Chem, ...] = ()

    def calculate(self, input_data: ScrapBlendModelInput, **kwargs) -> ScrapBlendModelOutput: ...

    def calculate_batch(
        self, input_data: List[ScrapBlendModelInput], **kwargs
    ) -> List[ScrapBlendModelOutput]: ...

    def calculate_batch_fast(
        self,
        pig_iron_chem: RawFeChem,
        pig_iron_w: int,
        pellets_w: int,
        briquettes_w: int,
        scrap_matrix: torch.Tensor,
    ) -> Mapping[Chem, torch.Tensor]: ...

    @property
    def scrap_order(self) -> ScrapOrder: ...


def create_chem_vectorizer(
    chem: Chem,
    supported_scrap_types: ScrapOrder,
    scrap_mix_resolver: ScrapMixResolver,
) -> Callable[[ScrapBlendModelInput], torch.Tensor]:
    def vectorizer(data: ScrapBlendModelInput) -> torch.Tensor:
        scrap_weights: Map[ScrapType, float] = scrap_mix_resolver(data.scrap_weights, data.scrap_mix_mapping)
        raw_vector = torch.Tensor(
            [
                data.raw_fe_chem.get_chem(chem),
                data.raw_fe_weight,
                data.pellets_weight,
                data.briquetes_weight,
                *vectorize_scrap_weights(supported_scrap_types, scrap_weights),
            ]
        )
        return raw_vector

    return vectorizer


@lru_cache(maxsize=1024)
def resolve_scrap_mix_as_worst_case(
    scrap_mix: ScrapMix, mix_mapping: ScrapMixMapping, resolving_order: ScrapOrder
) -> ScrapType:
    if scrap_mix not in mix_mapping and scrap_mix not in SUPPORTED_SCRAP_TYPES_AS_MIXES:
        raise ValueError(
            f"Scrap mix {scrap_mix} is neither supported single scrap mix nor available composite scrap mix."
        )
    if scrap_mix in mix_mapping:
        mixture_components = mix_mapping[scrap_mix].keys()
        return min(mixture_components, key=resolving_order.index)
    return cast(ScrapType, scrap_mix)


def get_worst_case_scrap_mix_resolver(resolving_order: ScrapOrder) -> ScrapMixResolver:
    def resolver(
        scrap_mix_weights: Mapping[ScrapMix, float], mix_mapping: ScrapMixMapping
    ) -> Map[ScrapType, float]:
        resolved_mixes: List[Tuple[ScrapType, float]] = [
            (resolve_scrap_mix_as_worst_case(scrap_mix, mix_mapping, resolving_order), weight)
            for scrap_mix, weight in scrap_mix_weights.items()
        ]
        scrap_type_weights: DefaultDict[ScrapType, float] = defaultdict(float)
        for scrap_type, weight in resolved_mixes:
            scrap_type_weights[scrap_type] += weight
        return Map(scrap_type_weights)

    return resolver


def get_proportional_scrap_mix_resolver(precision: int) -> ScrapMixResolver:
    def resolver(
        scrap_mix_charge: Mapping[ScrapMix, float], scrap_mix_mapping: ScrapMixMapping
    ) -> Map[ScrapType, float]:
        scrap_charge: DefaultDict[Union[ScrapMix, ScrapType], float] = collections.defaultdict(float)

        for scrap_mix, weight in scrap_mix_charge.items():
            for scrap_type, ratio in scrap_mix_mapping.get(scrap_mix, {scrap_mix: 1}).items():
                scrap_charge[scrap_type] += weight * ratio

        undefined_scrap_mixes = set(scrap_charge).difference(SUPPORTED_SCRAP_TYPES)

        if undefined_scrap_mixes:
            raise ValueError(
                f"Scrap mix mapping {scrap_mix_mapping} does not define ratios"
                f" for following scrap mixes: {undefined_scrap_mixes}"
            )

        scrap_order = tuple(scrap_charge)

        scrap_charge_vec = np.array(vectorize_scrap_weights(scrap_order, Map(scrap_charge)))

        approx_gen = get_simple_integer_approximations(scrap_charge_vec, precision)

        approx_best = min(approx_gen, key=lambda approx: float(np.linalg.norm(scrap_charge_vec - approx)))

        scrap_charge_rounded = reverse_vectorize(scrap_order, tuple(approx_best), 0)

        return Map(
            {
                cast(ScrapType, scrap_type): round(weight / precision) * precision
                for scrap_type, weight in scrap_charge_rounded.items()
            }
        )

    return resolver


class ScrapBlendModelV2:
    SUPPORTED_CHEMS: Tuple[Chem, ...] = ("Cr", "Cu", "Mo", "Ni", "S", "Sn", "Si")

    def __init__(self):
        super().__init__()
        self.models = {}
        self.vectorizer = {}
        self.binning = {}
        self.summation_indexes = {}
        model_data = torch.load(Path(__file__).parent / "trained_models/eob_model_v6.pth")
        for chem in self.SUPPORTED_CHEMS:
            if chem not in model_data:
                raise Exception(f"Model for {chem} not available")
            chem_data = model_data[chem]
            chem_model = OrdinalRegressionBlendModel(**chem_data["model_config"])
            chem_model.load_state_dict(chem_data["state_dict"])
            scrap_mix_resolver = get_worst_case_scrap_mix_resolver(
                BLEND_MODEL_V2_MIXTURE_RESOLVING_ORDER[chem]
            )
            self.models[chem] = chem_model.eval()
            self.vectorizer[chem] = create_chem_vectorizer(chem, self.scrap_order, scrap_mix_resolver)
            self.summation_indexes[chem] = create_summation_indexes(
                create_input_names(chem), chem_data["dataset_params"]["scrap_groups"]
            )
            self.binning[chem] = tuple(chem_data["dataset_params"]["binning"])

    @cached_property
    def full_binning_map(self) -> Mapping[Chem, torch.Tensor]:
        return Map({chem: get_full_binning(self.binning[chem]) for chem in self.SUPPORTED_CHEMS})

    def calculate(self, input_data: ScrapBlendModelInput, **kwargs) -> ScrapBlendModelOutput:
        return self.calculate_batch([input_data], **kwargs)[0]

    def calculate_batch(
        self, input_data: List[ScrapBlendModelInput], **kwargs
    ) -> List[ScrapBlendModelOutput]:
        with torch.no_grad():
            all_estimates = []
            for chem, model in self.models.items():
                input_vectors = torch.stack(  # pylint: disable=no-member
                    [self.vectorizer[chem](item) for item in input_data]
                )
                chem_output = model.forward(batch_transform(input_vectors, self.summation_indexes[chem]))
                chem_binning = self.binning[chem]
                all_estimates.append(
                    [
                        OrdinalRegressionChemEstimate(chem_binning, one_output)
                        for one_output in chem_output.numpy()
                    ]
                )
        return [
            ScrapBlendModelOutput(Cr=cr, Cu=cu, Mo=mo, Ni=ni, S=s, Sn=sn, Si=si)
            for cr, cu, mo, ni, s, sn, si in zip(*all_estimates)
        ]

    @lru_cache(maxsize=2**10)
    def get_constant_column(self, value: float, height: int) -> torch.Tensor:
        return torch.ones(size=(height, 1)) * value  # pylint: disable=no-member

    # pylint: disable=no-member, too-many-locals
    def calculate_batch_fast(
        self,
        pig_iron_chem: RawFeChem,
        pig_iron_w: int,
        pellets_w: int,
        briquettes_w: int,
        scrap_matrix: torch.Tensor,
    ) -> Mapping[Chem, torch.Tensor]:
        height = len(scrap_matrix)
        col_pig_iron_w = self.get_constant_column(pig_iron_w, height)
        col_pellets = self.get_constant_column(pellets_w, height)
        col_briquettes = self.get_constant_column(briquettes_w, height)

        probas_matrices: Dict[Chem, torch.Tensor] = dict()
        with torch.no_grad():
            for chem, model in self.models.items():
                col_pig_iron_chem = self.get_constant_column(pig_iron_chem.get_chem(chem), height)

                input_matrix = torch.cat(  # type: ignore
                    [col_pig_iron_chem, col_pig_iron_w, col_pellets, col_briquettes, scrap_matrix], axis=1
                )

                eob_probas_matrix = model.forward(batch_transform(input_matrix, self.summation_indexes[chem]))

                probas_matrices[chem] = eob_probas_matrix

        return Map(probas_matrices)

    @property
    def scrap_order(self) -> ScrapOrder:
        return SUPPORTED_SCRAP_TYPES


@lru_cache(maxsize=2)
def get_blend_model(version: int = 2) -> ScrapBlendModel:
    if version == 2:
        return ScrapBlendModelV2()
    raise Exception(f"Invalid model version {version} - valid versions are: [2]")
