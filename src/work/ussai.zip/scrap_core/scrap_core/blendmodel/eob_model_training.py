import argparse
from datetime import date, datetime
import logging
import os
import re
from typing import List

from dateutil.relativedelta import relativedelta
import pytorch_lightning as pl
from pytorch_lightning.callbacks.early_stopping import EarlyStopping
from pytorch_lightning.loggers import TensorBoardLogger
from scrap_core import Chem
import torch

from .eob_config import (
    get_grouping,
    BINNING,
    INTENTIONALLY_NOT_RARE_SCRAP,
    SAMPLER_ALPHA,
    SCADA_CFG,
    OKO_CFG,
    HIDDEN_FEATURES_COUNT,
    HIDDEN_FEATURES_COUNT_DEFAULT,
    DROPOUT,
    DROPOUT_DEFAULT,
    EOB_MODEL_SUPPORTED_CHEMS,
    DEFAULT_CACHE_DIR,
    DEFAULT_LOG_DIR,
    DEFAULT_MODEL_DIR,
    get_chem_input,
)
from .eob_datamodule import get_datamodule
from .eob_model import (
    OrdinalRegressionBlendModel,
    PLOrdinalRegressionBlendModel,
    AscensionCallback,
    SCHEDULER_STEP_SIZE_UP,
)

logging.basicConfig(level=logging.DEBUG)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train selected EOB (sub)models")

    parser.add_argument(
        "-c",
        "--chems",
        help="Chem elements to train blend model for",
        type=get_chem_input,
        nargs="*",
        choices=EOB_MODEL_SUPPORTED_CHEMS,
        default=EOB_MODEL_SUPPORTED_CHEMS,
    )
    parser.add_argument(
        "-s",
        "--startdate",
        help="The Start Date - format YYYY-MM-DD",
        required=True,
        type=lambda s: datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-e",
        "--enddate",
        help="The End Date format YYYY-MM-DD",
        required=True,
        type=lambda s: datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-v",
        "--valperiod",
        help="Length of validation dateset in months",
        type=int,
    )
    parser.add_argument(
        "-t",
        "--testperiod",
        help="Length of test dataset in months",
        type=int,
    )
    parser.add_argument(
        "--cachedir",
        help="Path to a directory where training, validation and test data are cached",
        type=str,
        default=DEFAULT_CACHE_DIR,
    )
    parser.add_argument(
        "--logdir",
        help="Path to a directory where training statistics are stored",
        type=str,
        default=DEFAULT_LOG_DIR,
    )
    parser.add_argument(
        "--modeldir",
        help="Path to a directory where trained models are stored",
        type=str,
        default=DEFAULT_MODEL_DIR,
    )

    return parser.parse_args()


# pylint:disable=too-many-arguments,too-many-locals
def train_eob_models(
    chems: List[Chem],
    dt_from: date,
    dt_to: date,
    period_val: relativedelta,
    period_test: relativedelta,
    oko_cfg: dict,
    scada_cfg: dict,
    cache_dir: str,
    log_dir: str,
    model_dir: str,
) -> None:
    checkpoint_update = {}

    if not os.path.exists(model_dir):
        os.mkdir(model_dir)
        logging.info(f"Directory {model_dir} created")

    # find the latest checkpoint, if available
    latest_checkpoint_name = max(
        [
            filename
            for filename in os.listdir(model_dir)
            if filename.startswith("eob_model") and filename.endswith(".pth")
        ],
        key=lambda filename: os.path.getmtime(os.path.join(model_dir, filename)),
        default=None,
    )
    logging.info(f"Actual checkpoint {latest_checkpoint_name}")

    if latest_checkpoint_name is None:
        latest_checkpoint = {}
        latest_checkpoint_idx = -1
    else:
        latest_checkpoint = torch.load(os.path.join(model_dir, latest_checkpoint_name))
        try:
            latest_checkpoint_idx = int(
                re.search(r"v(?P<index>\d+)", latest_checkpoint_name).group("index")  # type: ignore
            )
        except AttributeError:
            raise SystemExit(
                f"Something is wrong, the latest model checkpoint {latest_checkpoint_name} "
                f"does not have version specified in expected format - 'eob_model_v\\d+.pth'"
            )

    # just check that all relevant groupings are valid
    for chem in chems:
        _ = get_grouping(chem)

    for chem in chems:
        alpha = SAMPLER_ALPHA.get(chem.title(), 0)
        logging.info(f"Training {chem} model with sampler alpha {alpha}")
        binning = BINNING[chem.title()]
        grouping = get_grouping(chem)

        dataset_params = {
            "chem": chem,
            "dt_from": dt_from,
            "dt_to": dt_to,
            "period_val": period_val,
            "period_test": period_test,
            "rare_scrap_threshold": 3000,
            "scrap_groups": grouping,
            "binning": binning,
            "sampler_alpha": alpha,
            "batch_size": 512,
            "intentionally_not_rare_scrap": INTENTIONALLY_NOT_RARE_SCRAP.get(chem.title(), []),  # type: ignore
            "path_cache": cache_dir,
        }

        datamodule = get_datamodule(
            **{
                **dataset_params,
                "oko_config": oko_cfg,
                "scada_config": scada_cfg,
            }  # type: ignore
        )
        dataset_config = {
            **dataset_params,
            "module_name": datamodule.__class__.__name__,
            "module_version": datamodule.version,
        }
        logging.info(f"Dataset configuration: {dataset_config}")

        datamodule.prepare_data()
        datamodule.setup()
        if datamodule.train_data is None:
            raise Exception("Train model should be initialized after setup")

        model_config = {
            "input_feature_count": datamodule.train_data.features_count,
            "hidden_features_count": HIDDEN_FEATURES_COUNT.get(chem.title(), HIDDEN_FEATURES_COUNT_DEFAULT),
            "chem_bins_count": datamodule.categories_count,
            "mean": datamodule.train_data.mean,
            "std": datamodule.train_data.std,
            "dropout": DROPOUT.get(chem.title(), DROPOUT_DEFAULT),
        }
        logging.info(f"Model configuration: {model_config}")

        model = OrdinalRegressionBlendModel(**model_config)  # type: ignore

        pl_module = PLOrdinalRegressionBlendModel(
            model,
            datamodule.bins,
            datamodule.input_names,
            learning_rate=0.0001,
            model_cfg=model_config,
            dataset_cfg=dataset_config,
        )

        logger = TensorBoardLogger(
            save_dir=os.path.dirname(log_dir), name=os.path.basename(log_dir), default_hp_metric=False
        )
        # Stochastic weight is not available after the upgrade torch package.
        # https://github.com/Lightning-AI/pytorch-lightning/pull/12535
        trainer = pl.Trainer(
            # stochastic_weight_avg=True,
            callbacks=[
                AscensionCallback(),
                EarlyStopping(
                    monitor="val/mce",
                    verbose=True,
                    patience=2 * SCHEDULER_STEP_SIZE_UP,
                    min_delta=0.001,
                    mode="min",
                ),
            ],
            logger=logger,
        )

        trainer.fit(pl_module, datamodule)

        trainer.test(verbose=False)

        # Exclude path to cache directory, as it is user specific
        del dataset_params["path_cache"]

        checkpoint_update[chem] = {
            "dataset_params": dataset_params,
            "model_config": model_config,
            "state_dict": model.state_dict(),
        }

    # save new checkpoint
    new_checkpoint = {**latest_checkpoint, **checkpoint_update}
    new_checkpoint_path = os.path.join(model_dir, f"eob_model_v{latest_checkpoint_idx + 1}.pth")
    torch.save(new_checkpoint, new_checkpoint_path)
    logging.info(f"New checkpoint saved successfully as {new_checkpoint_path}")


def main():
    args = parse_args()

    train_eob_models(
        args.chems,
        args.startdate.date(),
        args.enddate.date(),
        relativedelta(months=args.valperiod),
        relativedelta(months=args.testperiod),
        OKO_CFG,
        SCADA_CFG,
        args.cachedir,
        args.logdir,
        args.modeldir,
    )


if __name__ == "__main__":
    main()
