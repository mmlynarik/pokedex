from datetime import date
import inspect
import json
import logging
import os
from statistics import median
from typing import Callable, Mapping

import cx_Oracle
import numpy as np
import pandas as pd
import pymssql
from sqlalchemy.engine import create_engine, URL

from ... import SUPPORTED_SCRAP_TYPES, Chem
from ...datamodel.oko import scrap_code_to_scrap_type


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# Derived mostly using the following pseudo formula:
# max(grade.chem.max_limit for grade in available_grades)
ABS_MAX: Mapping[Chem, float] = {
    "Cr": 3.0,
    "Cu": 3.0,
    "Mo": 3.0,
    "Ni": 3.0,
    "P": 0.999,
    "S": 0.999,
    "Si": 4.005,
    "Sn": 0.999,
}


def get_data(
    path: str,
    callback: Callable[..., pd.DataFrame],
    callback_params: dict,
) -> pd.DataFrame:
    if os.path.exists(path):
        df_data = pd.read_csv(path)
        log.info(f"{len(df_data)} records loaded from (cached) file {path}")
    else:
        # A hack that helps us to send callback params
        # to nested calls of `get_data` function
        if len(inspect.signature(callback).parameters) == 1:
            df_data = callback(callback_params)
        else:
            host = callback_params["config"].get("host") or callback_params["config"].get("server")
            log.info(f"Reading data from '{host}' db ...")
            df_data = callback(**callback_params)
            log.info(f"{len(df_data)} records read from '{host}' db")

        df_data.to_csv(path, index=False)
        log.info(f"{len(df_data)} records dumped to {path} file")

    return df_data


def read_raw_heat_data_from_oko(query: str, config: dict, dt_from: date, dt_to: date) -> pd.DataFrame:
    # pylint:disable=c-extension-no-member
    engine = create_engine(URL.create("mssql+pymssql", **config))
    with engine.begin() as conn:
        df_oko = pd.read_sql(query, conn, params={"dt_from": dt_from, "dt_to": dt_to})

    df_oko[["heat_no", "heat_year"]] = df_oko[["heat_no", "heat_year"]].astype(int)

    return df_oko


def read_raw_heat_data_from_scada(query: str, config: dict, dt_from: date, dt_to: date) -> pd.DataFrame:
    # pylint:disable=c-extension-no-member
    engine = create_engine(URL.create("oracle+cx_oracle", **config))
    with engine.begin() as conn:
        df_scada = pd.read_sql(query, conn, params={"dt_from": dt_from, "dt_to": dt_to})

    df_scada = df_scada.rename(columns=str.lower)

    df_scada[["heat_no", "heat_year", "furnace"]] = df_scada[["heat_no", "heat_year", "furnace"]].astype(int)

    return df_scada


def preprocess_oko_scrap_data(df_oko: pd.DataFrame) -> pd.DataFrame:
    def convert_scrap_weights(df_data: pd.DataFrame) -> pd.DataFrame:
        df_total_scrap_weight = (
            df_data.groupby(["heat_no", "heat_year"])["scrap_weight"]
            .sum()
            .reset_index()
            .rename(columns={"scrap_weight": "total_scrap_weight"})
        )
        df_data = pd.merge(
            df_data,
            df_total_scrap_weight,
            left_on=["heat_no", "heat_year"],
            right_on=["heat_no", "heat_year"],
            how="inner",
        )

        df_data["scrap_weight"] = df_data["scrap_weight"] / np.where(
            df_data["total_scrap_weight"] < 10**5, 1, 100
        )

        return df_data.drop(columns="total_scrap_weight")

    def aggregate_same_scrap_types(df_data: pd.DataFrame) -> pd.DataFrame:
        # There are few heats with two entries for the same scrap type, e.g. (39898, 2015)
        df_aggregated_scrap = (
            df_data[["heat_no", "heat_year", "scrap_type", "scrap_weight"]]
            .groupby(["heat_no", "heat_year", "scrap_type"])
            .sum()
            .reset_index()
        )
        df_data = df_data.drop(columns="scrap_weight").drop_duplicates(
            subset=["heat_no", "heat_year", "scrap_type"]
        )
        df_data = pd.merge(
            df_data,
            df_aggregated_scrap,
            left_on=["heat_no", "heat_year", "scrap_type"],
            right_on=["heat_no", "heat_year", "scrap_type"],
            how="inner",
        )
        return df_data

    def pivot_scrap_weights_into_scrap_map(df_data: pd.DataFrame) -> pd.DataFrame:
        df_data["scrap_type"] = df_data["scrap_type"].apply(scrap_code_to_scrap_type)

        # Pandas version < 1.1.0 does not support multiple columns as `index` parameter to `pivot` method,
        # thus we need a helper "heat_key" column.
        df_data["heat_key"] = df_data["heat_key"] = df_data.apply(
            lambda row: (row["heat_no"], row["heat_year"]), axis=1
        )
        df_scrap = df_data.pivot(index="heat_key", columns="scrap_type", values="scrap_weight").reset_index()

        available_scrap_types = set(SUPPORTED_SCRAP_TYPES) & set(df_scrap.columns)
        df_scrap["scrap_map"] = df_scrap.apply(
            lambda row: {st: row[st] for st in available_scrap_types if not pd.isna(row[st])}, axis=1
        ).apply(json.dumps)

        df_data = df_data.drop(columns=["scrap_type", "scrap_weight"]).drop_duplicates()

        df_data = pd.merge(
            df_data, df_scrap[["heat_key", "scrap_map"]], left_on="heat_key", right_on="heat_key", how="inner"
        )
        return df_data.drop(columns="heat_key")

    def convert_heat_datetime(df_data: pd.DataFrame) -> pd.DataFrame:
        df_data["heat_datetime"] = (
            pd.to_datetime(df_data["heat_datetime"])
            # `ambiguous=True` means that values that can't be localized
            # are assigned CEST timezone (with DST)
            .dt.tz_localize("Europe/Bratislava", ambiguous=True).apply(lambda dt: dt.timestamp())
        )

        return df_data

    df_oko["grade_planned"] = df_oko["grade_planned"].astype(int)
    df_oko["grade_final"] = df_oko["grade_final"].astype(int)
    return (
        df_oko.pipe(convert_scrap_weights)
        .pipe(aggregate_same_scrap_types)
        .pipe(pivot_scrap_weights_into_scrap_map)
        .pipe(convert_heat_datetime)
    )


def get_eob_median(row_scada: pd.Series, chem: Chem) -> float:

    # EOB_CL is twice here to increase weight of this measurement
    cols_to_check = [f"{chem}_EOB", f"{chem}_EOB_CL", f"{chem}_EOB_CL"]
    # if we have invalid EOB measurement, sometimes a new measurement is done,
    # and results are stored in REBLOW columns
    if row_scada.o2_dofuk_skut <= 0.0:
        cols_to_check.extend([f"{chem}_RB1", f"{chem}_RB1_CL", f"{chem}_RB2", f"{chem}_RB2_CL"])
        if row_scada[f"{chem.lower()}_grade_min"] == 0.0:
            cols_to_check.extend([f"{chem}_PANVA", f"{chem}_PANVA_CL"])
    values = []
    for chem_measurement in cols_to_check:
        measurement = row_scada[chem_measurement.lower()]
        if not pd.isna(measurement) and (0.0 < measurement < ABS_MAX[chem]):
            values.append(measurement)
    if not values:
        return float("nan")
    return median(values)


def get_final_median(row_scada: pd.Series, chem: Chem) -> float:
    cols_to_check = [f"{chem}_LF2", f"{chem}_LF3", f"{chem}_LF5", f"{chem}_RH2", f"{chem}_RH3", f"{chem}_RH5"]
    cols_to_check.extend([x + "_CL" for x in cols_to_check])
    # TA_CL is twice here to increase weight of this measurement
    cols_to_check.extend([f"{chem}_TA_CL", f"{chem}_TA_CL"])
    values = []
    for chem_measurement in cols_to_check:
        measurement = row_scada[chem_measurement.lower()]
        if not pd.isna(measurement) and (0.0 < measurement < ABS_MAX[chem]):
            values.append(measurement)
    if not values:
        return float("nan")
    return median(values)
