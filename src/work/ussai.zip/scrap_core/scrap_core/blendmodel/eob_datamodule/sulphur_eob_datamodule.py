from datetime import date
import json
import logging
import os
from typing import Dict, Optional

from dateutil.relativedelta import relativedelta
import pandas as pd

from .generic_eob_datamodule import GenericEobDataModule
from .eob_queries import (
    QUERY_CHEM_DATA_OKO,
    QUERY_SCRAP_DATA_OKO,
    QUERY_SULPHUR_LECO_DATA_OKO,
    QUERY_DATA_SCADA,
)
from .eob_utils import (
    get_data,
    preprocess_oko_scrap_data,
    read_raw_heat_data_from_oko,
    get_eob_median,
    get_final_median,
    read_raw_heat_data_from_scada,
)


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def get_max_viable_s_drop(row_scada: pd.Series) -> float:
    # coefficients are 0.95 confidence interval of coefficients from linear regression
    return (row_scada.synt_slag * 2.0e-06) + (row_scada.o2_dofuk_skut * 3.2e-06)


def preprocess_scada_heat_data_sulphur_specific(df_scada: pd.DataFrame) -> pd.DataFrame:
    df_scada = df_scada.copy()

    df_scada["s_eob_median"] = df_scada.apply(lambda row: get_eob_median(row, "S"), axis=1)
    df_scada["s_final_median"] = df_scada.apply(lambda row: get_final_median(row, "S"), axis=1)

    df_scada["max_viable_s_drop"] = df_scada.apply(get_max_viable_s_drop, axis=1)

    df_scada["s_drop"] = df_scada["s_eob_median"] - df_scada["s_final_median"]
    df_scada["expected_s_drop_diff"] = df_scada["s_drop"] - df_scada["max_viable_s_drop"]

    return df_scada


class SulphurEobDataModule(GenericEobDataModule):
    version = GenericEobDataModule.version + 0.3

    # pylint:disable=too-many-arguments
    def __init__(
        self,
        dt_from: date,
        dt_to: date,
        period_val: relativedelta,
        period_test: relativedelta,
        rare_scrap_threshold: int,
        scrap_groups: list,
        binning: list,
        sampler_alpha: float,
        oko_config: dict,
        scada_config: dict,
        path_cache: str = "./cache",
        batch_size: int = 512,
        intentionally_not_rare_scrap: Optional[list] = None,
    ):
        super().__init__(
            "S",
            dt_from,
            dt_to,
            period_val,
            period_test,
            rare_scrap_threshold,
            scrap_groups,
            binning,
            sampler_alpha,
            oko_config,
            scada_config,
            path_cache,
            batch_size,
            intentionally_not_rare_scrap,
        )

    @property
    def _col_map(self) -> Dict[str, str]:
        tmp = super()._col_map
        # Replace pig iron S measurement with LECO measurement
        del tmp[f"pig_iron_{self.chem}_oko"]
        tmp["s_po_odsireni_oko"] = "pig_iron_s"
        return tmp

    def prepare_data(self) -> None:
        if not os.path.exists(self.path_cache):
            os.makedirs(self.path_cache)
            log.info(f"Cache directory {self.path_cache} created")

        if os.path.exists(self._path_filtered_data):
            log.info(f"Filtered data already exists in {self._path_filtered_data} file")
            return

        df_scrap_oko = get_data(
            path=self._path_common_preprocessed_data,
            callback=lambda params: preprocess_oko_scrap_data(
                get_data(self._path_common_raw_data, read_raw_heat_data_from_oko, params)
            ),
            callback_params={
                "query": QUERY_SCRAP_DATA_OKO,
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_chem_oko = get_data(
            path=self._get_path_preprocessed_data("chem_oko"),
            callback=read_raw_heat_data_from_oko,
            callback_params={
                "query": QUERY_CHEM_DATA_OKO.format(chem=self.chem),
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_scada = get_data(
            path=self._get_path_preprocessed_data("scada"),
            callback=lambda params: preprocess_scada_heat_data_sulphur_specific(
                get_data(self._get_path_raw_data("scada"), read_raw_heat_data_from_scada, params)
            ),
            callback_params={
                "query": QUERY_DATA_SCADA.format(chem=self.chem),
                "config": self.scada_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_leco_oko = get_data(
            path=self._get_path_raw_data("leco_oko"),
            callback=read_raw_heat_data_from_oko,
            callback_params={
                "query": QUERY_SULPHUR_LECO_DATA_OKO,
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_leco_oko = df_leco_oko.set_index(["heat_no", "heat_year"])
        df_scrap_oko = df_scrap_oko.set_index(["heat_no", "heat_year"])
        df_chem_oko = df_chem_oko.set_index(["heat_no", "heat_year"])
        df_scada = df_scada.set_index(["heat_no", "heat_year"])

        df_oko = df_scrap_oko.join(df_chem_oko).join(df_leco_oko)

        # OKO filters
        # -----------

        # Remove records with 2nd after_desulf measurement higher than the previous one
        tmp = len(df_oko)
        incompatible_leco_measurements = df_oko["ocs_leco_s_po"] < df_oko["ocs_leco_s_po_2"]
        df_oko = df_oko[~incompatible_leco_measurements]
        log.info(f"{tmp - len(df_oko)} OKO records removed due to incompatible S LECO measurements.")

        # Remove records with too big after_desulf measurement
        tmp = len(df_oko)
        too_big_after_desulf = df_oko["s_po_odsireni"] >= 0.033
        df_oko = df_oko[~too_big_after_desulf]
        log.info(f"{tmp - len(df_oko)} OKO records removed due to too big S after desulf measurement.")

        # Remove records where more than 5000 kg (version 0.2, 10000 kg) of DSI scrap is used
        tmp = len(df_oko)
        bound = 5000
        df_oko = df_oko[
            df_oko["scrap_map"]
            .apply(json.loads)
            .apply(lambda sm: sm.get("DSI", 0) + sm.get("DSI A1 2", 0) <= bound)
        ]
        log.info(f"{tmp - len(df_oko)} OKO records removed due to more than {bound} kg of DSI scrap used")

        # SCADA filters
        # -------------

        # Remove records where reblow cause is different from Sulphur (1)
        # Remark: column "o2_dofuk_skut" in SCADA contains more reliable values than column "extra_o2" in OKO
        tmp = len(df_scada)
        sulphur_unrelated_reblow_cause = (df_scada["o2_dofuk_skut"] > 0) & (df_scada["o2_dofuk_kod"] != 1)
        df_scada = df_scada[~sulphur_unrelated_reblow_cause]
        log.info(
            f"{tmp - len(df_scada)} SCADA records removed "
            f"due to reblow cause unrelated to Sulphur contained in scrap"
        )

        # Remove records with too big drop
        tmp = len(df_scada)
        unrealistic_s_drop = df_scada.expected_s_drop_diff > 0.002
        df_scada = df_scada[~unrealistic_s_drop]
        log.info(
            f"{tmp - len(df_scada)} SCADA records removed due to "
            f"unrealistic drop between eob and final S measurements."
        )

        df_data = pd.merge(
            df_oko.rename(columns=lambda col: col.lower() + "_oko"),
            df_scada.rename(columns=lambda col: col.lower() + "_scada"),
            left_index=True,
            right_index=True,
            how="inner",
        )
        log.info(f"Joined OKO and SCADA data contain {len(df_data)} records.")

        # combined OKO and SCADA filters
        # ------------------------------
        # Remove records with too high fall between after_desulf and eob measurements
        tmp = len(df_data)
        high_fall = df_data["s_eob_median_scada"] + 0.01 < df_data["s_po_odsireni_oko"]
        df_data = df_data[~high_fall]
        log.info(
            f"{tmp - len(df_data)} records removed from joined OKO and SCADA data due to "
            f"too high fall between after desulf and eob S measurements."
        )

        # Use CL measurement, whenever possible
        df_data[f"mended_{self.chem}_eob"] = df_data[f"{self.chem}_eob_cl_scada"].combine_first(
            df_data[f"{self.chem}_eob_scada"]
        )

        # Restrict data to relevant columns only
        df_data = df_data.reset_index()
        df_filtered_data = df_data[list(self._col_map)].copy().rename(columns=self._col_map)

        # Remove records with missing values
        df_filtered_data = df_filtered_data.dropna()
        log.info(f"Dataset consist of {len(df_filtered_data)} records with non-null values")

        df_filtered_data.to_csv(self._path_filtered_data, index=False)
