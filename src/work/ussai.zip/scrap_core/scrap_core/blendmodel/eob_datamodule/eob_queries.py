# ("Cr", "Cu", "Mo", "Ni", "P", "S", "Si") are supported
# Sn is not supported, data for Sn are not available in SCADA
QUERY_DATA_SCADA = """
    SELECT 
        heat.HEATNO AS heat_no,
        EXTRACT(year FROM heat.RELEASE_TIME) AS heat_year,
        heat.plant AS furnace,
        heat.release_time,
        O2_DOFUK_KOD,
        NVL(O2_DOFUK_SKUT, 0) AS o2_dofuk_skut,
        {chem}_EOB,
        {chem}_EOB_CL,
        {chem}_RB1,
        {chem}_RB1_CL,
        {chem}_RB2,
        {chem}_RB2_CL,
        {chem}_PANVA,
        {chem}_PANVA_CL,
        {chem}_LF2,
        {chem}_LF2_CL,
        {chem}_LF3,
        {chem}_LF3_CL,
        {chem}_LF5,
        {chem}_LF5_CL,
        {chem}_RH2,
        {chem}_RH2_CL,
        {chem}_RH3,
        {chem}_RH3_CL,
        {chem}_RH5,
        {chem}_RH5_CL,
        {chem}_RH6_CL,
        {chem}_TA_CL,
        {chem}_GRADE_MIN,
        NVL(RAF_R12, 0) + NVL(KRYCIA_TROSKA, 0) + NVL(ST_MAN, 0) + NVL(ST_AUT, 0) AS synt_slag

    FROM dboc.T_HEAT_APX heat

    JOIN dboc.T_HEAT_APX_ANALYSES analyses ON analyses.heat_id_seq = heat.heat_id_seq

    WHERE heat.RELEASE_TIME >= :dt_from AND heat.RELEASE_TIME < :dt_to
    """


QUERY_CHEM_DATA_OKO = """
    SELECT
        ds_tavba.oct_cis_tavby AS heat_no,
        ds_tavba.oct_rok_vyroby_tavby AS heat_year,
        oct_{chem}_sur_fe AS pig_iron_{chem},
        oct_{chem}_predsk_1 AS eob_{chem},
        oct_{chem}_predsk_2 AS reblow_{chem},
        ocl_{chem}_uvol_an AS final_{chem}
    FROM oko.dbo.ds_tavba

    JOIN oko.dbo.ds_tavba_odsir ON ds_tavba.oct_cis_tavby = ds_tavba_odsir.h_cislo_tavby
        AND ds_tavba.oct_rok_vyroby_tavby = ds_tavba_odsir.h_rok

    WHERE
        ds_tavba.oc_zac_vsadz >= %(dt_from)s
        AND ds_tavba.oc_zac_vsadz < %(dt_to)s    
"""


QUERY_SCRAP_DATA_OKO = """
    SELECT
        ds_tavba.oct_cis_tavby AS heat_no,
        ds_tavba.oct_rok_vyroby_tavby AS heat_year,
        oc_zac_vsadz as heat_datetime, 
        oct_hmotn_sur_zel * 10 AS pig_iron_w,
        oct_brikety AS briquettes,
        oct_pelety AS pellets,
        kod_srotu AS scrap_type,
        hmotnost AS scrap_weight,
        oct_hmotn_preliev_oc AS returned_steel_w,
        t1.akost_vyr AS grade_planned,
        t2.akost_vyr AS grade_final
    FROM oko.dbo.ds_tavba

    JOIN oko.dbo.dim_akost_vyr AS t1 ON ds_tavba.oc_kod_akost_vyrabana = t1.kod_akost_vyr

    JOIN oko.dbo.dim_akost_vyr AS t2 ON ds_tavba.oc_kod_akost_uvol = t2.kod_akost_vyr

    JOIN oko.dbo.iars_konv_srot ON ds_tavba.oct_cis_tavby = iars_konv_srot.cis_tavby
        AND ds_tavba.oct_rok_vyroby_tavby = iars_konv_srot.rok

    JOIN oko.dbo.ds_tavba_doplnok ON ds_tavba.kod_tavby = ds_tavba_doplnok.kod_tavby

    WHERE
        iars_konv_srot.kod_srotu IS NOT NULL
        AND iars_konv_srot.hmotnost IS NOT NULL
        AND iars_konv_srot.hmotnost > 0
        AND (oct_hmotn_preliev_oc IS NULL OR oct_hmotn_preliev_oc = 0)
        AND ds_tavba.oc_zac_vsadz >= %(dt_from)s
        AND ds_tavba.oc_zac_vsadz < %(dt_to)s     
"""


QUERY_SULPHUR_LECO_DATA_OKO = """
    SELECT DISTINCT
        ds_tavba.oct_cis_tavby AS heat_no,
        ds_tavba.oct_rok_vyroby_tavby AS heat_year,
        ocs_leco_s_pred,
        ocs_leco_s_po,
        ocs_leco_s_po_2,
        COALESCE(ocs_leco_s_po_2, ocs_leco_s_po) AS s_po_odsireni

    FROM oko.dbo.ds_tavba

    JOIN oko.dbo.ds_tavba_odsir ON ds_tavba.oct_cis_tavby = ds_tavba_odsir.h_cislo_tavby
        AND ds_tavba.oct_rok_vyroby_tavby = ds_tavba_odsir.h_rok

    WHERE ds_tavba.oc_zac_vsadz >= %(dt_from)s
        AND ds_tavba.oc_zac_vsadz < %(dt_to)s  
"""
