import collections
from datetime import date, datetime
from functools import cached_property
import json
import logging
import os
from typing import Callable, Dict, List, Optional, Tuple

from dateutil.relativedelta import relativedelta
from immutables import Map
import pandas as pd
import pytorch_lightning as pl
import torch
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from ...pytorch_balanced_sampler.sampler import SamplerFactory

from ... import Chem, vectorize_scrap_weights, SUPPORTED_SCRAP_TYPES, reverse_vectorize, HeatKey
from ..eob_config import validate_grouping
from .eob_dataset import EobDataset, CHEM_DIMS, WEIGHT_DIMS
from .eob_utils import (
    read_raw_heat_data_from_oko,
    read_raw_heat_data_from_scada,
    preprocess_oko_scrap_data,
    get_data,
)
from .eob_queries import QUERY_DATA_SCADA, QUERY_CHEM_DATA_OKO, QUERY_SCRAP_DATA_OKO


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def create_summation_indexes(input_names: List[str], grouping: List[List[str]]) -> List[torch.Tensor]:
    if not validate_grouping(grouping):
        raise ValueError(f"Grouping {grouping} does not match supported scrap types set.")
    index_groups = [[input_names.index(name) for name in group] for group in grouping]
    return [torch.Tensor(group).long() for group in index_groups]


def create_input_names(chem: Chem) -> List[str]:
    return [name.format(chem=chem.title()) for name in CHEM_DIMS] + WEIGHT_DIMS


def get_binning_transformer(
    lower_bound: torch.Tensor, upper_bound: torch.Tensor, class_id: int
) -> Callable[[torch.Tensor], torch.Tensor]:
    def transformer(data: torch.Tensor) -> torch.Tensor:
        return ((lower_bound <= data) & (data < upper_bound)) * class_id

    return transformer


# pylint:disable=no-member
def get_binner_from_binning(
    binning: List[float],
) -> Tuple[Callable[[torch.Tensor], torch.Tensor], torch.Tensor]:
    bins = torch.cat([torch.Tensor([0.0]), torch.Tensor(binning), torch.Tensor([float("inf")])])
    transformers = [get_binning_transformer(bins[i], bins[i + 1], i) for i in range(len(bins) - 1)]

    def binner(y: torch.Tensor) -> torch.Tensor:
        return torch.stack([t(y) for t in transformers]).sum(axis=0)  # type: ignore

    return binner, bins


class GenericEobDataModule(pl.LightningDataModule):
    version = 5.0
    # version 0 - no IQR filter
    # version 1 - IQR filter
    # version 2 - sampler & no filter & custom binning
    # version 3 - if grouping is provided,
    #   add to test dataset heats with rare scrap types that are included in scrap groups
    # version 4 - filter out heats that are tap alloyed with given chem
    # version 5 - split scrap and chem (measurements) OKO data

    # pylint:disable=too-many-arguments
    def __init__(
        self,
        chem: Chem,
        dt_from: date,
        dt_to: date,
        period_val: relativedelta,
        period_test: relativedelta,
        rare_scrap_threshold: int,
        scrap_groups: list,
        binning: list,
        sampler_alpha: float,
        oko_config: dict,
        scada_config: dict,
        path_cache: str = "./cache",
        batch_size: int = 512,
        intentionally_not_rare_scrap: Optional[list] = None,
    ):
        super().__init__()
        self.chem = chem.lower()
        self.dt_from = dt_from
        self.dt_to = dt_to
        self.period_val = period_val
        self.period_test = period_test
        self.binner, self.bins = get_binner_from_binning(binning)
        self.batch_size = batch_size
        self.sampler_alpha = sampler_alpha
        self.rare_scrap_threshold = rare_scrap_threshold
        self.scrap_groups = scrap_groups
        self.oko_config = oko_config
        self.scada_config = scada_config
        self.path_cache = os.path.normpath(os.path.join(path_cache, self.chem.title()))
        self.intentionally_not_rare_scrap = intentionally_not_rare_scrap or []
        self.train_data = None  # type: Optional[EobDataset]
        self.test_data = None  # type: Optional[EobDataset]
        self.val_data = None  # type: Optional[EobDataset]

    @property
    def input_names(self) -> List[str]:
        return create_input_names(self.chem)  # type: ignore

    @property
    def categories_count(self) -> int:
        return len(self.bins) - 1

    @property
    def summation_indexes(self) -> List[torch.Tensor]:
        return create_summation_indexes(self.input_names, self.scrap_groups)

    @property
    def _path_filtered_data(self) -> str:
        return os.path.join(
            self.path_cache,
            f"filtered_data"
            f"_{self.chem.lower()}"
            f"_v{self.version}"
            f"_from_{self.dt_from:%Y%m%d}"
            f"_to_{self.dt_to:%Y%m%d}.csv",
        )

    @property
    def _path_common_preprocessed_data(self) -> str:
        return os.path.join(
            os.path.dirname(self.path_cache),
            f"common_preprocessed_data"
            f"_v{self.version // 1}"
            f"_from_{self.dt_from:%Y%m%d}"
            f"_to_{self.dt_to:%Y%m%d}"
            f"_oko.csv",
        )

    @property
    def _path_common_raw_data(self) -> str:
        return os.path.join(
            os.path.dirname(self.path_cache),
            f"common_raw_data"
            f"_v{self.version // 1}"
            f"_from_{self.dt_from:%Y%m%d}"
            f"_to_{self.dt_to:%Y%m%d}"
            f"_oko.csv",
        )

    def _get_path_preprocessed_data(self, source: str) -> str:
        return os.path.join(
            self.path_cache,
            f"preprocessed_data"
            f"_{self.chem.lower()}"
            f"_v{self.version}"
            f"_from_{self.dt_from:%Y%m%d}"
            f"_to_{self.dt_to:%Y%m%d}"
            f"_{source}.csv",
        )

    def _get_path_raw_data(self, source: str) -> str:
        return os.path.join(
            self.path_cache,
            f"raw_data"
            f"_{self.chem.lower()}"
            f"_v{self.version}"
            f"_from_{self.dt_from:%Y%m%d}"
            f"_to_{self.dt_to:%Y%m%d}"
            f"_{source}.csv",
        )

    @property
    def _col_map(self) -> Dict[str, str]:
        return {
            "heat_no": "heat_no",
            "heat_year": "heat_year",
            "heat_datetime_oko": "heat_datetime",
            "pig_iron_w_oko": "pig_iron_w",
            "briquettes_oko": "briquettes",
            "pellets_oko": "pellets",
            "scrap_map_oko": "scrap_map",
            f"pig_iron_{self.chem}_oko": f"pig_iron_{self.chem}",
            f"mended_{self.chem}_eob": f"{self.chem}_eob",
            # "furnace_scada": "furnace"
            # "s_eob_corr_exp_scada": "s_eob_corr_exp"
        }

    def create_input_vector(self, record: pd.Series) -> torch.Tensor:
        return torch.Tensor(
            [
                record[f"pig_iron_{self.chem}"],
                record["pig_iron_w"],
                record["pellets"],
                record["briquettes"],
                *vectorize_scrap_weights(SUPPORTED_SCRAP_TYPES, record["scrap_map"]),
            ]
        )

    def revert_input_vector(self, vec: torch.Tensor) -> dict:
        return {
            f"pig_iron_{self.chem}": round(float(vec[0]), 5),
            "pig_iron_w": float(vec[1]),
            "pellets": float(vec[2]),
            "briquettes": float(vec[3]),
            "scrap_map": {
                st: float(val)
                for st, val in reverse_vectorize(
                    SUPPORTED_SCRAP_TYPES, vec[-len(SUPPORTED_SCRAP_TYPES) :], 0  # type: ignore
                ).items()
            },
        }

    def create_output_vector(self, record: pd.Series) -> torch.Tensor:
        return torch.Tensor([self.binner(record[f"{self.chem}_eob"])]).long()

    def _extract_vectors(
        self, df_data: pd.DataFrame, tqdm_desc: str
    ) -> List[Tuple[HeatKey, torch.Tensor, torch.Tensor]]:
        vectors = [
            (
                (record["heat_no"], record["heat_year"]),
                self.create_input_vector(record),
                self.create_output_vector(record),
            )
            for _, record in tqdm(df_data.iterrows(), desc=tqdm_desc, total=len(df_data))
        ]
        return vectors

    def filter_data(self, df_data: pd.DataFrame) -> pd.DataFrame:
        df_data = df_data.copy()

        # version 4
        # Remove records that correspond to heats tap alloyed with `self.chem`,
        # i.e. records where minimal limit for `self.chem` is > 0
        df_data = df_data[df_data[f"{self.chem}_grade_min_scada"] <= 0]
        log.info(f"{len(df_data)} heats are not tap alloyed with {self.chem}")
        # Consequently, we may use final measurement instead of eob measurement,
        # because there was no `self.chem` added between eob and final (TA CL) measurements
        df_data[f"mended_{self.chem}_eob"] = (
            df_data[f"{self.chem}_ta_cl_scada"]
            .combine_first(df_data[f"{self.chem}_eob_cl_scada"])
            .combine_first(df_data[f"{self.chem}_eob_scada"])
        )

        # Restrict data to relevant columns only
        df_data = df_data.reset_index()
        df_filtered_data = df_data[list(self._col_map)].copy().rename(columns=self._col_map)

        # Remove records with missing values
        df_filtered_data = df_filtered_data.dropna()
        log.info(f"Dataset consist of {len(df_filtered_data)} records with non-null values")

        return df_filtered_data

    def prepare_data(self) -> None:
        if not os.path.exists(self.path_cache):
            os.makedirs(self.path_cache)
            log.info(f"Cache directory {self.path_cache} created")

        if os.path.exists(self._path_filtered_data):
            log.info(f"Filtered data already exists in {self._path_filtered_data} file")
            return

        df_scrap_oko = get_data(
            path=self._path_common_preprocessed_data,
            callback=lambda params: preprocess_oko_scrap_data(
                get_data(self._path_common_raw_data, read_raw_heat_data_from_oko, params)
            ),
            callback_params={
                "query": QUERY_SCRAP_DATA_OKO,
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_chem_oko = get_data(
            path=self._get_path_preprocessed_data("chem_oko"),
            callback=read_raw_heat_data_from_oko,
            callback_params={
                "query": QUERY_CHEM_DATA_OKO.format(chem=self.chem),
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_scada = get_data(
            path=self._get_path_raw_data("scada"),
            callback=read_raw_heat_data_from_scada,
            callback_params={
                "query": QUERY_DATA_SCADA.format(chem=self.chem),
                "config": self.scada_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_scrap_oko = df_scrap_oko.set_index(["heat_no", "heat_year"])
        df_chem_oko = df_chem_oko.set_index(["heat_no", "heat_year"])
        df_oko = df_scrap_oko.join(df_chem_oko)

        df_scada = df_scada.set_index(["heat_no", "heat_year"])

        df_data = pd.merge(
            df_oko.rename(columns=lambda col: col.lower() + "_oko"),
            df_scada.rename(columns=lambda col: col.lower() + "_scada"),
            left_index=True,
            right_index=True,
            how="inner",
        )
        log.info(f"Joined OKO and SCADA data consist of {len(df_data)} records")

        df_filtered_data = self.filter_data(df_data)

        df_filtered_data.to_csv(self._path_filtered_data)

    @cached_property
    def rare_scrap(self) -> Dict[str, int]:
        df_filtered_data = self.get_filtered_data()
        df_scrap = pd.DataFrame(df_filtered_data["scrap_map"].to_list())
        scrap_count = df_scrap.count()
        return {
            st: num
            for st, num in scrap_count[scrap_count < self.rare_scrap_threshold].items()
            if st not in self.intentionally_not_rare_scrap
        }

    def get_filtered_data(self) -> pd.DataFrame:
        df_filtered_data = pd.read_csv(self._path_filtered_data)
        df_filtered_data["scrap_map"] = df_filtered_data["scrap_map"].apply(json.loads).apply(Map)
        return df_filtered_data

    # pylint:disable=too-many-locals
    def setup(self, stage: Optional[str] = None) -> None:
        df_filtered_data = self.get_filtered_data()
        log.info(
            f"Following scrap types are considered rare, because they are used "
            f"in less than {self.rare_scrap_threshold} heats: {sorted(self.rare_scrap)}"
        )
        df_filtered_data["has_rare_scrap"] = df_filtered_data["scrap_map"].apply(
            lambda scrap_map: set(self.rare_scrap) & set(scrap_map) != set()
        )
        rare_scrap_heats_count = df_filtered_data["has_rare_scrap"].sum()
        log.info(f"Filtered dataset contains {rare_scrap_heats_count} heats with rare scrap.")

        # Calculate training data split bounds
        dt_start = datetime.fromtimestamp(min(df_filtered_data["heat_datetime"]))
        dt_end = datetime.fromtimestamp(max(df_filtered_data["heat_datetime"]))
        dt_test_start = dt_end - self.period_test
        dt_val_start = dt_test_start - self.period_val

        if stage is None or stage == "fit":
            mask_training = (
                df_filtered_data["heat_datetime"] < dt_val_start.timestamp()
            ) & ~df_filtered_data["has_rare_scrap"]
            train_vectors = self._extract_vectors(
                df_filtered_data[mask_training], tqdm_desc="Extracting training vectors"
            )
            log.info(
                f"Training dataset consists of {len(train_vectors)} heats "
                f"between {dt_start} to {dt_val_start} (heats with rare scrap were excluded)"
            )
            self.train_data = EobDataset(train_vectors, self.summation_indexes, self.categories_count)

        if stage is None or stage == "validate":
            mask_validation = (
                (dt_val_start.timestamp() <= df_filtered_data["heat_datetime"])
                & (df_filtered_data["heat_datetime"] < dt_test_start.timestamp())
                & ~df_filtered_data["has_rare_scrap"]
            )
            val_vectors = self._extract_vectors(
                df_filtered_data[mask_validation], tqdm_desc="Extracting validation vectors"
            )
            log.info(
                f"Validation dataset consists of {len(val_vectors)} heats "
                f"between {dt_val_start} to {dt_test_start} (heats with rare scrap were excluded)."
            )
            self.val_data = EobDataset(val_vectors, self.summation_indexes, self.categories_count)

        if stage is None or stage == "test":
            log.info(f"Groups of similar scrap types are {self.scrap_groups}")
            mask_test = (dt_test_start.timestamp() <= df_filtered_data["heat_datetime"]) & ~df_filtered_data[
                "has_rare_scrap"
            ]
            if self.scrap_groups:
                grouped_scrap = {st for group in self.scrap_groups for st in group}
                rare_scrap_without_group = set(self.rare_scrap) - grouped_scrap
                mask_rare_but_grouped = df_filtered_data["has_rare_scrap"] & df_filtered_data[
                    "scrap_map"
                ].apply(lambda scrap_map: rare_scrap_without_group & set(scrap_map) == set())
                mask_test = mask_test | mask_rare_but_grouped
                log.info(
                    f"{mask_rare_but_grouped.sum()} heats with rare scrap types "
                    f"{set(self.rare_scrap) & grouped_scrap} have been added to test dataset"
                    f" as they are included in provided groups of similar scrap types"
                )
            else:
                # if groups of similar scrap types are not provided,
                # exclude all heats with rare scrap from test dataset, too
                log.info(
                    f"{df_filtered_data.has_rare_scrap.sum()} heats with rare scrap types "
                    f"excluded from model training completely"
                )

            test_vectors = self._extract_vectors(
                df_filtered_data[mask_test], tqdm_desc="Extracting test vectors"
            )
            log.info(
                f"Test dataset consists of {len(test_vectors)} " f"heats between {dt_test_start} to {dt_end}"
            )
            self.test_data = EobDataset(test_vectors, self.summation_indexes, self.categories_count)

    def train_dataloader(self) -> DataLoader:
        if self.train_data is None:
            raise SystemExit("Please run the `self.setup` method first")
        # version 2
        class_map = collections.defaultdict(list)
        for idx, (_, y) in enumerate(self.train_data):  # type: ignore
            class_map[float(y)].append(idx)  # type: ignore

        class_idxs = [class_map[cid] for cid in sorted(class_map)]

        batch_sampler = SamplerFactory().get(
            class_idxs=class_idxs,
            batch_size=self.batch_size,
            n_batches=len(self.train_data) // self.batch_size + 1,  # type: ignore
            alpha=self.sampler_alpha,
            kind="fixed",
        )

        return DataLoader(self.train_data, batch_sampler=batch_sampler)

    def val_dataloader(self) -> DataLoader:
        if self.val_data is None:
            raise SystemExit("Please run the `self.setup` method first")
        return DataLoader(self.val_data, batch_size=self.batch_size)

    def test_dataloader(self) -> DataLoader:
        if self.test_data is None:
            raise SystemExit("Please run the `self.setup` method first")
        return DataLoader(self.test_data, batch_size=self.batch_size)
