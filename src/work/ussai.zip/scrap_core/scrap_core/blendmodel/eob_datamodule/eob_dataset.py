# pylint:disable=no-member

from typing import List, Tuple

import torch
from torch.utils.data import Dataset
from tqdm.auto import tqdm

from ... import SUPPORTED_SCRAP_TYPES, HeatKey

# CHEM_DIMS = ["EOB CORR {chem}", "PIG IRON {chem}"]
CHEM_DIMS = ["PIG IRON {chem}"]
WEIGHT_DIMS = ["PIG IRON W", "PELLETS", "BRIQUETTES"] + list(SUPPORTED_SCRAP_TYPES)


def transform(input_vector: torch.Tensor, summation_indexes: List[torch.Tensor]) -> torch.Tensor:
    chem_vector = input_vector[: len(CHEM_DIMS)]
    weight_vector = input_vector[len(CHEM_DIMS) :]
    normalized = torch.cat([chem_vector, weight_vector / weight_vector.sum(axis=0)])  # type: ignore
    summed = torch.stack(
        [
            normalized.index_select(0, column_selector).sum(axis=0)  # type: ignore
            for column_selector in summation_indexes
        ],
        axis=0,
    )
    return summed


def batch_transform(input_matrix: torch.Tensor, summation_indexes: List[torch.Tensor]) -> torch.Tensor:
    chem_matrix = input_matrix[:, : len(CHEM_DIMS)]
    weight_matrix = input_matrix[:, len(CHEM_DIMS) :]

    normalized = torch.cat(
        [chem_matrix, weight_matrix / weight_matrix.sum(axis=1).unsqueeze(dim=1)], dim=1  # type: ignore
    )

    summed = torch.stack(
        [
            normalized.index_select(1, column_selector).sum(axis=1)  # type: ignore
            for column_selector in summation_indexes
        ],
        axis=1,
    )

    return summed


class EobDataset(Dataset):
    def __init__(
        self,
        data: List[Tuple[HeatKey, torch.Tensor, torch.Tensor]],
        summation_indexes: List[torch.Tensor],
        categories_count: int,
    ) -> None:
        super().__init__()
        # convert data to the form ((transformed_x, original_x), y)
        self.data = [
            ((transform(x_orig, summation_indexes), x_orig), y)
            for _, x_orig, y in tqdm(data, desc="Transforming data")
        ]
        self.key_map = {key: (x_orig, y) for key, x_orig, y in data}
        self.categories_count = categories_count

    def __getitem__(self, index: int) -> Tuple[Tuple[torch.Tensor, torch.Tensor], torch.Tensor]:
        return self.data[index]

    def __len__(self) -> int:
        return len(self.data)

    @property
    def mean(self) -> torch.Tensor:
        return torch.stack([x[0] for x, _ in self.data]).mean(dim=0)

    @property
    def std(self) -> torch.Tensor:
        return torch.stack([x[0] for x, _ in self.data]).std(dim=0).clamp(min=0.0000000001)

    @property
    def features_count(self) -> int:
        # each row has the form ((transformed x, original x), y)
        return self.data[0][0][0].shape[0]

    def find_heat_key(self, x_orig: torch.Tensor, y_exp: torch.Tensor) -> List[HeatKey]:
        result = []
        for heat_key, (x, y) in self.key_map.items():
            if torch.all(x == x_orig) and torch.all(y == y_exp):
                result.append(heat_key)
        return result
