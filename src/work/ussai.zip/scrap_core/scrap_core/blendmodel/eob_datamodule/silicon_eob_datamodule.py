from datetime import date
import logging
from typing import Optional

from dateutil.relativedelta import relativedelta
import pandas as pd

from .generic_eob_datamodule import GenericEobDataModule


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class SiliconEobDataModule(GenericEobDataModule):
    version = GenericEobDataModule.version + 0.1

    # pylint:disable=too-many-arguments
    def __init__(
        self,
        dt_from: date,
        dt_to: date,
        period_val: relativedelta,
        period_test: relativedelta,
        rare_scrap_threshold: int,
        scrap_groups: list,
        binning: list,
        sampler_alpha: float,
        oko_config: dict,
        scada_config: dict,
        path_cache: str = "./cache",
        batch_size: int = 512,
        intentionally_not_rare_scrap: Optional[list] = None,
    ):
        super().__init__(
            "Si",
            dt_from,
            dt_to,
            period_val,
            period_test,
            rare_scrap_threshold,
            scrap_groups,
            binning,
            sampler_alpha,
            oko_config,
            scada_config,
            path_cache,
            batch_size,
            intentionally_not_rare_scrap,
        )

    def filter_data(self, df_data: pd.DataFrame) -> pd.DataFrame:
        df_data = df_data.copy()

        df_data[f"mended_{self.chem}_eob"] = df_data[f"{self.chem}_eob_cl_scada"].combine_first(
            df_data[f"{self.chem}_eob_scada"]
        )

        # Restrict data to relevant columns only
        df_data = df_data.reset_index()
        df_filtered_data = df_data[list(self._col_map)].copy().rename(columns=self._col_map)

        # Remove records with missing values
        df_filtered_data = df_filtered_data.dropna()
        log.info(f"Dataset consist of {len(df_filtered_data)} records with non-null values")

        return df_filtered_data
