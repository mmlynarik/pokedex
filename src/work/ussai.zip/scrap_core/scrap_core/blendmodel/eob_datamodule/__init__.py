from scrap_core import Chem
from .generic_eob_datamodule import GenericEobDataModule
from .chromium_eob_datamodule import ChromiumEobDataModule
from .sulphur_eob_datamodule import SulphurEobDataModule
from .tin_eob_datamodule import TinEobDataModule
from .silicon_eob_datamodule import SiliconEobDataModule


def get_datamodule(chem: Chem, *args, **kwargs) -> GenericEobDataModule:
    if chem.title() == "Cr":
        return ChromiumEobDataModule(*args, **kwargs)
    if chem.title() == "P":
        raise SystemExit("Phosphorus not supported yet")
    if chem.title() == "S":
        return SulphurEobDataModule(*args, **kwargs)
    if chem.title() == "Si":
        return SiliconEobDataModule(*args, **kwargs)
    if chem.title() == "Sn":
        return TinEobDataModule(*args, **kwargs)
    return GenericEobDataModule(chem, *args, **kwargs)
