from datetime import date
import logging
import os
from typing import Optional

from dateutil.relativedelta import relativedelta
import numpy as np
import pandas as pd

from .eob_queries import QUERY_SCRAP_DATA_OKO, QUERY_CHEM_DATA_OKO
from .eob_utils import get_data, preprocess_oko_scrap_data, read_raw_heat_data_from_oko
from .generic_eob_datamodule import GenericEobDataModule


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class TinEobDataModule(GenericEobDataModule):
    """
    No measurement data are available in SCADA db for Sn,
    thus we need a dedicated EobDatamodule that reads data from OKO db only.
    """

    version = GenericEobDataModule.version + 0.4
    # version x.1 IQR filter with whisker = 1.5
    # version x.2 no IQR filter
    # version x.3 heats tap alloyed with Sn are removed from dataset
    #   and final measurement is used instead of eob measurement
    # version x.4 excluded heats with invalid Sn measurement (invalid ~ >=1.0)

    # pylint:disable=too-many-arguments
    def __init__(
        self,
        dt_from: date,
        dt_to: date,
        period_val: relativedelta,
        period_test: relativedelta,
        rare_scrap_threshold: int,
        scrap_groups: list,
        binning: list,
        sampler_alpha: float,
        oko_config: dict,
        scada_config: dict,
        path_cache: str = "./cache",
        batch_size: int = 512,
        intentionally_not_rare_scrap: Optional[list] = None,
    ):
        super().__init__(
            "Sn",
            dt_from,
            dt_to,
            period_val,
            period_test,
            rare_scrap_threshold,
            scrap_groups,
            binning,
            sampler_alpha,
            oko_config,
            scada_config,
            path_cache,
            batch_size,
            intentionally_not_rare_scrap,
        )

    def prepare_data(self) -> None:
        if not os.path.exists(self.path_cache):
            os.makedirs(self.path_cache)
            log.info(f"Cache directory {self.path_cache} created")

        if os.path.exists(self._path_filtered_data):
            log.info(f"Filtered data already exists in {self._path_filtered_data} file")
            return

        df_scrap_oko = get_data(
            path=self._path_common_preprocessed_data,
            callback=lambda params: preprocess_oko_scrap_data(
                get_data(self._path_common_raw_data, read_raw_heat_data_from_oko, params)
            ),
            callback_params={
                "query": QUERY_SCRAP_DATA_OKO,
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_chem_oko = get_data(
            path=self._get_path_preprocessed_data("chem_oko"),
            callback=read_raw_heat_data_from_oko,
            callback_params={
                "query": QUERY_CHEM_DATA_OKO.format(chem=self.chem),
                "config": self.oko_config,
                "dt_from": self.dt_from,
                "dt_to": self.dt_to,
            },
        )

        df_oko = pd.merge(
            df_scrap_oko,
            df_chem_oko,
            on=["heat_no", "heat_year"],
            how="inner",
        )

        # version x.3
        # Remove heats where Sn is used as tap alloy (grades with Sn min > 0)
        sn_tap_alloyed_grades = {28, 535, 536, 537, 991}
        df_oko = df_oko[~df_oko["grade_planned"].isin(sn_tap_alloyed_grades)]
        log.info(
            f"{len(df_oko)} heats are not tap alloyed with Sn, "
            f"i.e. their planned grades are different from {sn_tap_alloyed_grades}"
        )

        # Consequently, we may use final measurement instead of eob measurement,
        # because there was no tin added between eob and final measurements
        df_oko["mended_eob_sn"] = np.where(df_oko["final_sn"].isna(), df_oko["eob_sn"], df_oko["final_sn"])

        df_filtered_data = (
            df_oko[
                [
                    "heat_no",
                    "heat_year",
                    "heat_datetime",
                    "pig_iron_w",
                    "briquettes",
                    "pellets",
                    "scrap_map",
                    "pig_iron_sn",
                    "mended_eob_sn",
                    # "furnace_scada"
                    # "s_eob_corr_exp_scada"
                ]
            ]
            .copy()
            .rename(columns={"mended_eob_sn": "sn_eob"})
        )

        # Remove records with missing values
        df_filtered_data = df_filtered_data.dropna()
        log.info(f"Dataset consist of {len(df_filtered_data)} records with non-null values")

        # version x.4
        df_filtered_data = df_filtered_data[df_filtered_data["sn_eob"] < 1]
        log.info(f"Dataset consist of {len(df_filtered_data)} records with Sn eob values < 1")

        df_filtered_data.to_csv(self._path_filtered_data, index=False)
