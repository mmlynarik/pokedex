from collections import defaultdict
import functools
from typing import Any, Dict, Optional, Protocol, Sequence, Tuple

import attr
import numpy as np
import torch
from immutables import Map

from scrap_core import (
    SUPPORTED_SCRAP_TYPES_SET,
    SUPPORTED_SCRAP_TYPES_AS_MIXES,
    Chem,
    between,
    positive_finite,
    scrap_weights_converter,
    ScrapType,
    ScrapMixMapping,
    ScrapMix,
    scrap_mix_mapping_converter,
)
from scrap_core.datamodel import RawFeChem
from usskssgrades import Grade
from scrap_core.datamodel.model import Heat


def scrap_type_keys_validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    for scrap_type in value:
        if scrap_type not in SUPPORTED_SCRAP_TYPES_SET:
            raise ValueError(
                f"{attribute_type.name} contains key {scrap_type} which is not supported scrap type"
            )


def scrap_mix_keys_validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    for scrap_mix in value:
        if (
            scrap_mix not in full_instance.scrap_mix_mapping
            and scrap_mix not in SUPPORTED_SCRAP_TYPES_AS_MIXES
        ):
            raise ValueError(
                f"{attribute_type.name} contains key {scrap_mix} which is neither supported single scrap mix nor available composite scrap mix."
            )


@attr.s(slots=True, frozen=True)
class BlendModelSettings:
    version: int = attr.ib(default=2, validator=between(1, 2), converter=int)


# TODO change weights to int
@attr.s(slots=True, frozen=True)
class ScrapBlendModelInput:
    raw_fe_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    raw_fe_chem: RawFeChem = attr.ib(validator=attr.validators.instance_of(RawFeChem))
    scrap_weights: Map[ScrapMix, float] = attr.ib(
        validator=[attr.validators.instance_of(Map), scrap_mix_keys_validator], converter=scrap_weights_converter  # type: ignore
    )
    pellets_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    briquetes_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    scrap_mix_mapping: ScrapMixMapping = attr.ib(default=Map(), converter=scrap_mix_mapping_converter)

    @property
    def scrap_weight(self) -> float:
        return sum(self.scrap_weights.values())

    @property
    def total_weight_wo_scrap(self) -> float:
        return self.raw_fe_weight + self.pellets_weight + self.briquetes_weight

    @property
    def total_input_weight(self) -> float:
        return self.total_weight_wo_scrap + self.scrap_weight


class ChemEstimate(Protocol):
    def cdf_unsafe(self, values: torch.Tensor) -> torch.Tensor: ...

    def cdf(self, value: float) -> float: ...

    def percentile(self, percentile: float) -> float: ...

    def total_chem_weight(self, total_weight: float, percentile: float) -> float: ...


def to_python_float_tuple_converter(data: Any) -> Tuple[float, ...]:
    return tuple([float(x) for x in data])


def uniform_cdf(left: float, right: float, value: float) -> float:
    """
    Simple implementation of CDF of uniform distribution
    in the interval [left, right]
    """
    if value < left:
        return 0

    if value > right:
        return 1

    return (value - left) / (right - left)


def uniform_quantile(left: float, right: float, quantile: float) -> float:
    """
    Simple implementation of quantile function of uniform distribution
    in the interval [left, right]
    """
    if quantile < 0:
        return left

    if quantile > 1:
        return right

    return left + quantile * (right - left)


def zero_one_cdf(right: float, value: float) -> float:
    """
    CDF of distribution with following properties:
        a) P(X < right) = 0
        b) P(X == right) = 1
    """
    return 0 if value < right else 1


def zero_one_quantile(left: float, right: float, quantile: float) -> float:
    """
    Quantile function related to "zero-one" distribution. I follows that if 0 < q
    and q <= P(a <= X), then a == right, in particular, if 0.95 <= P(a <= X), then a == right.
    """
    return left if quantile <= 0 else right


# pylint: disable=no-member
def cdf_batch(value: float, probas_matrix: torch.Tensor, full_binning: torch.Tensor) -> torch.Tensor:
    """
    Calculate cdf(value) for every probas row in `probas_matrix`.
    Each row is pmf corresponding to the same (given) binning array.
    """
    if value <= 0:
        return torch.zeros(len(probas_matrix))

    if value >= full_binning[-1]:
        return torch.ones(len(probas_matrix))

    mask = full_binning <= value
    bin_idx = full_binning[mask].argmax()

    low = full_binning[bin_idx]
    upp = full_binning[bin_idx + 1]

    if upp == full_binning[-1]:
        # roughly, the last bin is equivalent to its right endpoint
        relative_bin_probability = zero_one_cdf(float(upp), value) * probas_matrix[:, bin_idx]
    else:
        # we expect uniform distribution in every bin except for the last one
        relative_bin_probability = uniform_cdf(float(low), float(upp), value) * probas_matrix[:, bin_idx]

    return (probas_matrix * mask[1:]).sum(dim=1) + relative_bin_probability


# pylint: disable=no-member
@functools.lru_cache(maxsize=2**4)
def get_full_binning(binning: Tuple[float, ...]) -> torch.Tensor:
    # since binning corresponds to content of trace elements in heat in percents,
    # maximal value is set to 100 %. See `total_chem_weight` method below.
    return torch.cat([torch.Tensor([0]), torch.Tensor(binning), torch.Tensor([100])])


@attr.s(slots=True, frozen=True)
class OrdinalRegressionChemEstimate(ChemEstimate):
    # TODO add check for monotonity
    binning: Tuple[float, ...] = attr.ib(converter=to_python_float_tuple_converter)
    probas: Tuple[float, ...] = attr.ib(converter=to_python_float_tuple_converter)

    @property
    def full_binning(self):
        return get_full_binning(self.binning)

    def cdf_unsafe(self, values: torch.Tensor) -> torch.Tensor:
        return torch.Tensor([self.cdf(val) for val in values])

    @functools.lru_cache(maxsize=2**16)
    def cdf(self, value: float) -> float:
        return float(cdf_batch(value, torch.Tensor([self.probas]), self.full_binning))

    def percentile(self, percentile: float) -> float:
        if percentile <= 0:
            return float(self.full_binning[0])

        if percentile > 1:
            return float(self.full_binning[-1])

        idx = min(idx for idx in range(len(self.probas)) if percentile <= sum(self.probas[: idx + 1]))

        low = self.full_binning[idx]
        upp = self.full_binning[idx + 1]

        # observe that `self.probas[idx] > 0` due to `percentile > 0` and definition of `idx`
        relative_percentile_remainder = (percentile - sum(self.probas[:idx])) / self.probas[idx]

        if upp == self.full_binning[-1]:
            return zero_one_quantile(float(low), float(upp), float(relative_percentile_remainder))

        return uniform_quantile(float(low), float(upp), float(relative_percentile_remainder))

    def __str__(self):
        idx_max = np.array(self.probas).argmax()
        return f"[{self.full_binning[idx_max]},{self.full_binning[idx_max + 1]})"

    def total_chem_weight(self, total_weight: float, percentile: float) -> float:
        return total_weight * self.percentile(percentile) / 100


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapBlendModelOutput:
    S: OrdinalRegressionChemEstimate
    Cu: OrdinalRegressionChemEstimate
    Ni: OrdinalRegressionChemEstimate
    Cr: OrdinalRegressionChemEstimate
    Mo: OrdinalRegressionChemEstimate
    Sn: OrdinalRegressionChemEstimate
    # With Si required, we can't serialize old (v1) data, and hence db backup does not work
    #  (blend model v1 did not predict Si) Consequently
    # TODO Find out how to convert v1 data to be v2 compatible
    Si: Optional[OrdinalRegressionChemEstimate] = attr.ib(default=None)

    def get_chem_estimate(self, chem: Chem) -> ChemEstimate:
        chem_lower = chem.lower()
        if chem_lower == "s":
            return self.S
        if chem_lower == "cu":
            return self.Cu
        if chem_lower == "ni":
            return self.Ni
        if chem_lower == "cr":
            return self.Cr
        if chem_lower == "mo":
            return self.Mo
        if chem_lower == "sn":
            return self.Sn
        if chem_lower == "si":
            # TODO enable type checking when Si is required again
            return self.Si  # type: ignore
        raise Exception(f"Unknown chem {chem}")

    # TODO calculate probs for composite limits
    def calculate_probs(self, grade: Grade, predicted_chems: Sequence[Chem]) -> Dict[Chem, float]:
        probs = {}
        for chem in predicted_chems:
            if chem == "P":
                limit = grade.get_limit("P_blow")
            else:
                limit = grade.get_limit(chem)
            probs[chem] = self.get_chem_estimate(chem).cdf(limit.maximum) if limit is not None else 1.0
        return probs


def convert_heat_to_raw_fe_chem(heat: Heat) -> RawFeChem:
    return RawFeChem(
        S=heat.after_desulf.S,
        Cu=heat.after_desulf.Cu,
        Ni=heat.after_desulf.Ni,
        Cr=heat.after_desulf.Cr,
        Mo=heat.after_desulf.Mo,
        Sn=heat.after_desulf.Sn,
        Si=heat.after_desulf.Si,
    )


def convert_heat_to_scrap_blend_model_input(heat: Heat) -> ScrapBlendModelInput:
    return ScrapBlendModelInput(
        raw_fe_weight=heat.raw_fe_weight,
        raw_fe_chem=convert_heat_to_raw_fe_chem(heat),
        scrap_weights=heat.get_scrap_map(),
        pellets_weight=heat.pellets_weight,
        briquetes_weight=heat.briquets_weight,
    )


def get_synthetic_chem_estimate(binning: Tuple[float, ...], value: float) -> OrdinalRegressionChemEstimate:
    pmf = [float(left < value <= right) for left, right in zip((0,) + binning, binning + (float("inf"),))]

    if value <= 0:
        pmf[0] = 1

    return OrdinalRegressionChemEstimate(binning, tuple(pmf))  # type: ignore


def get_uniform_chem_estimate(binning: Tuple[float, ...]) -> OrdinalRegressionChemEstimate:
    num_intervals = len(binning) + 1
    pmf = [1 / num_intervals for _ in range(num_intervals)]
    return OrdinalRegressionChemEstimate(binning, pmf)


def get_simple_binning(value: float, precision: float) -> Tuple[float, float]:
    """Return the simplest binning corresponding to measured value (and defined precision)"""
    return value - precision, value + precision


def convert_heat_to_scrap_blend_model_output(heat: Heat, analysis_type: str = "eob") -> ScrapBlendModelOutput:
    analysis = getattr(heat, analysis_type)
    return ScrapBlendModelOutput(
        S=get_synthetic_chem_estimate(get_simple_binning(analysis.S, 0.0005), analysis.S),
        Cu=get_synthetic_chem_estimate(get_simple_binning(analysis.Cu, 0.0005), analysis.Cu),
        Ni=get_synthetic_chem_estimate(get_simple_binning(analysis.Ni, 0.0005), analysis.Ni),
        Cr=get_synthetic_chem_estimate(get_simple_binning(analysis.Cr, 0.0005), analysis.Cr),
        Mo=get_synthetic_chem_estimate(get_simple_binning(analysis.Mo, 0.0005), analysis.Mo),
        Sn=get_synthetic_chem_estimate(get_simple_binning(analysis.Sn, 0.0005), analysis.Sn),
        Si=get_synthetic_chem_estimate(get_simple_binning(analysis.Si, 0.0005), analysis.Si),
    )
