# pylint:disable=no-member,arguments-differ,unexpected-keyword-arg

from collections import Counter
import json
import functools
from typing import Any, Callable, Dict, List, Tuple

from pytorch_lightning.utilities.types import STEP_OUTPUT, EPOCH_OUTPUT
from tqdm.auto import tqdm
import torch
from torch import nn
import pytorch_lightning as pl
from pytorch_lightning.callbacks import Callback
from spacecutter.models import LogisticCumulativeLink
from spacecutter.losses import cumulative_link_loss

from sklearn.neighbors import KDTree
from sklearn.preprocessing import MinMaxScaler

from .eob_datamodule import GenericEobDataModule

from .eob_model_metric import (
    NPointProba,
    CalibrationError,
    NPointProbaForScrap,
    NPointProbaForBin,
    NPointProbaForWorstBin,
    calc_overvalue,
    calc_undervalue,
    calc_centered,
    UndervalueNPointProbaForScrap,
    UndervalueNPointProba,
)


SCHEDULER_STEP_SIZE_UP = 20


def tensor_round(tensor: torch.Tensor, decimals: int) -> torch.Tensor:
    return torch.round(tensor * (10**decimals)) / (10**decimals)


def max_with_empty_handling(tensor: torch.Tensor) -> torch.Tensor:
    if tensor.numel() == 0:
        return torch.tensor(0.0)  # pylint:disable=not-callable
    return torch.max(tensor)


@functools.lru_cache()
def get_histogram_of_expected_results_constructor(
    datamodule: GenericEobDataModule,
) -> Callable[[torch.Tensor, int], Dict[int, int]]:
    x_orig = torch.stack(
        [item[0][1] for item in datamodule.train_data.data]  # type: ignore
        + [item[0][1] for item in datamodule.val_data.data]  # type: ignore
        + [item[0][1] for item in datamodule.test_data.data]  # type: ignore
    )

    y = torch.cat(
        [item[1] for item in datamodule.train_data.data]  # type: ignore
        + [item[1] for item in datamodule.val_data.data]  # type: ignore
        + [item[1] for item in datamodule.test_data.data]  # type: ignore
    )

    scaler = MinMaxScaler()

    tree = KDTree(scaler.fit_transform(x_orig))

    def histogram_constructor(record: torch.Tensor, sample_size: int) -> Dict[int, int]:
        _, similar_idx = tree.query(scaler.transform([record.numpy()]), k=sample_size)

        hist: Counter = Counter(y[similar_idx[0]].numpy())
        return {int(key): int(hist[key]) for key in sorted(hist)}

    return histogram_constructor


class OrdinalRegressionBlendModel(torch.nn.Module):
    # pylint:disable=too-many-arguments
    def __init__(
        self,
        input_feature_count: int,
        hidden_features_count: int,
        chem_bins_count: int,
        mean: torch.Tensor,
        std: torch.Tensor,
        dropout: float,
    ):
        super(OrdinalRegressionBlendModel, self).__init__()
        self.register_buffer("mean", mean)
        self.register_buffer("std", std)
        self.linear = nn.Sequential(
            nn.Linear(input_feature_count, hidden_features_count),
            nn.Dropout(p=dropout, inplace=False),
            nn.ReLU(),
            nn.Linear(hidden_features_count, 1),
        )
        self.link = LogisticCumulativeLink(chem_bins_count)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # return self.link(self.linear((x - self.mean) / self.std))
        return self.link(self.linear(x / self.std))


class PLOrdinalRegressionBlendModel(pl.LightningModule):
    # pylint:disable=unused-argument,too-many-arguments
    def __init__(
        self,
        model: OrdinalRegressionBlendModel,
        bins: torch.Tensor,
        input_names: List[str],
        learning_rate: float,
        model_cfg: Dict[str, Any],
        dataset_cfg: Dict[str, Any],
    ):
        super(PLOrdinalRegressionBlendModel, self).__init__()
        self.model = model
        self.bins = bins
        self.save_hyperparameters("learning_rate", "model_cfg", "dataset_cfg")
        self.metrics = {
            "zero_point_proba": NPointProba(0),
            "one_point_proba": NPointProba(1),
            "two_point_proba": NPointProba(2),
            "ece": CalibrationError(0.05, 300, torch.mean),
            "mce": CalibrationError(0.05, 300, max_with_empty_handling),
            "zero_point_undervalue": UndervalueNPointProba(0),
            "one_point_undervalue": UndervalueNPointProba(1),
            "two_point_undervalue": UndervalueNPointProba(2),
            "three_point_undervalue": UndervalueNPointProba(3),
            "four_point_undervalue": UndervalueNPointProba(4),
            "worst_bin_zero_point_proba": NPointProbaForWorstBin(0, bins),
        }

        self.composite_merics = {
            "scrap_zero_point_proba": NPointProbaForScrap(0, input_names),
            "scrap_zero_point_undervalue": UndervalueNPointProbaForScrap(0, input_names),
            "scrap_one_point_undervalue": UndervalueNPointProbaForScrap(1, input_names),
            "scrap_two_point_undervalue": UndervalueNPointProbaForScrap(2, input_names),
            "bin_zero_point_proba": NPointProbaForBin(0, bins),
        }

    def on_train_start(self) -> None:
        if self.logger is not None:
            self.logger.log_hyperparams(
                dict(self.hparams),
                {
                    "test/zero_point_proba": -1,
                    "test/one_point_proba": -1,
                    "test/two_point_proba": -1,
                    "test/ece": -1,
                    "test/mce": -1,
                },
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # type: ignore
        return self.model.forward(x)

    def configure_optimizers(self) -> Tuple[List[torch.optim.Adam], List[torch.optim.lr_scheduler.CyclicLR]]:
        learning_rate = self.hparams.learning_rate  # type: ignore
        optimizer = torch.optim.Adam(self.parameters(), lr=learning_rate)
        scheduler = torch.optim.lr_scheduler.CyclicLR(
            optimizer,
            base_lr=learning_rate,
            max_lr=learning_rate * 10,
            cycle_momentum=False,
            verbose=True,  # type: ignore
            step_size_up=SCHEDULER_STEP_SIZE_UP,
        )
        return [optimizer], [scheduler]

    def log_metrics(
        self, stage: str, model_prediction: torch.Tensor, y: torch.Tensor, on_step: Any, on_epoch: Any
    ) -> None:
        for name, metric in self.metrics.items():
            metric(model_prediction, y)
            self.log(f"{stage}/{name}", metric, on_step=on_step, on_epoch=on_epoch)

    def calc_composite_metrics(
        self, model_prediction: torch.Tensor, y: torch.Tensor, x: torch.Tensor
    ) -> None:
        for _, metric in self.composite_merics.items():
            metric(model_prediction, y, x)

    def log_composite_metrics(self, stage):
        for name, metric in self.composite_merics.items():
            metric_value = metric.compute()
            self.log_dict({f"{stage}/{name}/{metric}": v for metric, v in metric_value.items()})
            metric.reset()

    # pylint: disable=unused-argument
    def training_step(  # type: ignore
        self, batch: Tuple[Tuple[torch.Tensor, torch.Tensor], torch.Tensor], batch_idx: int
    ) -> STEP_OUTPUT:
        x, y = batch
        x_summed, x_orig = x
        model_prediction = self.model(x_summed)
        loss = cumulative_link_loss(model_prediction, y)
        self.log("train_loss", loss)

        self.log_metrics("train", model_prediction, y, True, False)
        self.calc_composite_metrics(model_prediction, y, x_orig)

        return loss

    def training_epoch_end(self, outputs: EPOCH_OUTPUT) -> None:
        self.log_composite_metrics("train")

    # pylint: disable=unused-argument
    def validation_step(  # type: ignore
        self, batch: Tuple[Tuple[torch.Tensor, torch.Tensor], torch.Tensor], batch_idx: int
    ) -> STEP_OUTPUT:
        x, y = batch
        x_summed, x_orig = x
        model_prediction = self.model(x_summed)
        loss = cumulative_link_loss(model_prediction, y)
        self.log("val_loss", loss)

        self.log_metrics("val", model_prediction, y, False, True)
        self.calc_composite_metrics(model_prediction, y, x_orig)

        return loss

    def validation_epoch_end(self, outputs: EPOCH_OUTPUT) -> None:  # type: ignore[override]
        self.log_composite_metrics("val")

    def test_step(  # type: ignore
        self, batch: Tuple[Tuple[torch.Tensor, torch.Tensor], torch.Tensor], batch_idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x, y = batch
        x_summed, x_orig = x
        model_prediction = self.model(x_summed)

        self.log_metrics("test", model_prediction, y, False, True)
        self.calc_composite_metrics(model_prediction, y, x_orig)

        return x_orig, y, model_prediction

    # pylint:disable=too-many-locals
    def log_top_test_outputs(
        self,
        tag: str,
        outputs: Tuple[torch.Tensor, torch.Tensor, torch.Tensor],
        n_distance: Callable[[torch.Tensor, torch.Tensor, int], torch.Tensor],
        reverse: bool,
        num=10,
    ) -> None:
        x_orig = torch.cat([x_orig for x_orig, _, _ in outputs])
        y = torch.cat([y for _, y, _ in outputs])
        model_prediction = torch.cat([model_prediction for _, _, model_prediction in outputs])

        dists = []
        for radius in range(len(self.bins) - 1):
            dists.append(n_distance(model_prediction, y, radius))

        stacked_dists = tensor_round(torch.stack(dists, dim=1), 4)
        badness = 1
        histogram_constructor = get_histogram_of_expected_results_constructor(
            self.trainer.datamodule  # type: ignore
        )
        for idx, score in tqdm(
            sorted(enumerate(stacked_dists), key=lambda item: tuple(item[1]), reverse=reverse)[:num],
            desc=f"{tag}: generating report",
        ):
            heat_no, heat_year = self.trainer.datamodule.test_data.find_heat_key(  # type: ignore
                x_orig[idx], y[idx]
            ).pop()
            url = (
                f"http://it.intranet.usske.sk/vykazy_oc/oc2_106/oc2_106.asp?tavba={heat_no}+&_rok={heat_year}"
            )
            item = {
                "predicted": list(model_prediction[idx].numpy().astype(float)),
                "expected": float(y[idx]),
                "input": self.trainer.datamodule.revert_input_vector(x_orig[idx]),  # type: ignore
                "score": list(score.numpy().astype(float)),
                "histogram_of_expected_results": histogram_constructor(x_orig[idx], 100),
            }
            if self.logger is not None:
                if hasattr(self.logger, "experiment"):
                    self.logger.experiment.add_text(
                        tag,
                        f"<a href='{url}'>({heat_no}, {heat_year})</a>"
                        f"<pre>{json.dumps(item, indent=2)}</pre>",
                        badness,
                    )
                else:
                    raise AttributeError("Missing experiment attribute")
            badness += 1

    def test_epoch_end(  # type: ignore
        self, outputs: Tuple[torch.Tensor, torch.Tensor, torch.Tensor]
    ) -> None:
        self.log_composite_metrics("test")

        rare_scrap = self.trainer.datamodule.rare_scrap  # type: ignore
        if self.logger is not None:
            if hasattr(self.logger, "experiment"):
                self.logger.experiment.add_text(
                    "rare_scrap",
                    f"<pre>{json.dumps(rare_scrap, indent=2, sort_keys=True)}</pre>",
                )
            else:
                raise AttributeError("Missing experiment attribute")

        num_of_errors = 10
        self.log_top_test_outputs(
            f"top_{num_of_errors}_biggest_errors", outputs, calc_centered, reverse=False, num=num_of_errors
        )
        self.log_top_test_outputs(
            f"top_{num_of_errors}_biggest_undervalue_errors",
            outputs,
            calc_undervalue,
            reverse=True,
            num=num_of_errors,
        )
        self.log_top_test_outputs(
            f"top_{num_of_errors}_biggest_overvalue_errors",
            outputs,
            calc_overvalue,
            reverse=True,
            num=num_of_errors,
        )


class AscensionCallback(Callback):
    def __init__(self, margin: float = 0.0, min_val: float = -1.0e6):
        super(AscensionCallback, self).__init__()
        self.margin = margin
        self.min_val = min_val

    # pylint:disable=too-many-arguments
    def on_train_batch_end(  # type: ignore
        self,
        trainer: pl.Trainer,
        pl_module: PLOrdinalRegressionBlendModel,
        outputs: STEP_OUTPUT,
        batch: Any,
        batch_idx: int,
        dataloader_idx: int,
    ) -> None:
        cutpoints = pl_module.model.link.cutpoints.data
        for i in range(cutpoints.shape[0] - 1):
            cutpoints[i].clamp_(self.min_val, cutpoints[i + 1] - self.margin)
