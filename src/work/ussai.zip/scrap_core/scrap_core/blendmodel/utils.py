from scrap_core import Chem
from scrap_core.blendmodel.datamodel import ScrapBlendModelOutput


def chem_in_scrap_approx_from_blend_model_result_diff(
    blend_model_output_without_scrap: ScrapBlendModelOutput,
    blend_model_output_with_scrap: ScrapBlendModelOutput,
    reference_input_weight: float,
    added_scrap_weight: float,
    approx_percentile: float,
    chem: Chem,
) -> float:
    """
    This function tries to approximate chem content in one weight unit of specific scrap mix
    from results of blend model in two states, one with scrap mix added and one without it
    """
    zero_w = blend_model_output_without_scrap.get_chem_estimate(chem).total_chem_weight(
        reference_input_weight, approx_percentile
    )
    constant_w = blend_model_output_with_scrap.get_chem_estimate(chem).total_chem_weight(
        reference_input_weight + added_scrap_weight, approx_percentile
    )

    # make sure that expected chem content has sane value
    return min(max((constant_w - zero_w) / added_scrap_weight, 0), 1)
