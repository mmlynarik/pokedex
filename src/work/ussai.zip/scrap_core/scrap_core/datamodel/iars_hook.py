"""
For each ZPO there 3 tables with data

 - p_zpo{zpo_id}_bramy   (contains data about planned or currently processed heats)
 - b_p_zpo{zpo_id}_bramy (contains data about recently closed heats)
 - p_zpo{zpo_id}         (contains data about planned grades)

where zpo_id = 1 corresponds to steelshop 2 and zpo_id = 2 corresponds to steelshop 1.

Remarks:

 - these tables contain data about planned production on ZPO, hence 'p_dat' timestamp corresponds
    to expected time when the heat will be processed on ZPO

 - if heat is in 'p_zpo{zpo_id}_bramy' table (version A) and 'cis_tavby' is valid heat number (>= 10000),
    then the heat is already being processed somewhere between KK and ZPO. Planned heats have invalid
    heat numbers (< 10000)

 - if heat is in 'b_p_zpo{zpo_id}_bramy' table (version B - note prefix "b_") and 'cis_tavby' is valid
    heat number (>= 10000), then this heat is closed

 - there may be records in 'b_p_zpo{zpo_id}_bramy' table with invalid 'cis_tavby' (< 10000),
    these records correspond to canceled (or somehow (very) unsuccessful) heats

Considerations:

 - the order of heats given by (c_sek, c_pol, por_tavby) may be more important
    than the order given by 'p_dat' timestamps, because it is defined based on
    succession of heats due to grade transitions, width transitions, etc.
"""

import configparser
import logging
import os
import pathlib
from typing import Optional, Tuple

import pyodbc
from immutables import Map

import pandas as pd
from sqlalchemy.engine import create_engine, Engine, URL
from sqlalchemy.exc import SQLAlchemyError

from scrap_core.datamodel.model import PlannedHeat


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


with open(os.path.join(os.path.dirname(__file__), "load_heat_plan_from_iars.sql")) as f:
    LOAD_HEAT_PLAN_FROM_IARS = f.read()


class IarsHook:
    def __init__(self, conf: dict):
        self.__conf = conf
        self.__engine: Optional[Engine] = None

    def __del__(self):
        if self.__engine is not None:
            self.__engine.dispose()

    @property
    def __conn_str(self) -> str:
        config = configparser.ConfigParser()

        config.read(pathlib.Path(os.environ["ODBCINI"]) / "odbc.ini")

        # At the moment I don't know how (or maybe it is not supported yet)
        # to establish connection using dsn only. Therefore, we read all
        # necessary data directly from `obdc.ini` file.
        return (
            "DriverType={drivertype};"
            "HostName={hostname};"
            "ListenAddress={listenaddress};"
            "Database={database};"
            "ServerType={servertype};"
            "ReadOnly={readonly};"
        ).format(**config[self.__conf["dsn"]])

    @property
    def url(self) -> URL:
        # due to (probably) bug in `ingres_sa_dialect` parameter "database" is required
        return URL.create(
            "ingres+pyodbc",
            database="",
            username=self.__conf["username"],
            password=self.__conf["password"],
            query={"odbc_connect": self.__conn_str},
        )

    @property
    def engine(self) -> Engine:
        if self.__engine is None:
            self.__engine = create_engine(self.url, pool_pre_ping=True)
        return self.__engine

    def __get_raw_data(self, num_of_heats: int, zpo_id: int) -> Optional[pd.DataFrame]:
        query = LOAD_HEAT_PLAN_FROM_IARS.format(num_of_heats=num_of_heats, zpo_id=zpo_id)

        try:
            with self.engine.begin() as conn:  # pylint:disable=c-extension-no-member
                df_heats = pd.read_sql(query, conn)
        except (SQLAlchemyError, pyodbc.Error):
            log.exception("Connection to IARS database failed")
            return None

        df_heats.p_akost = df_heats.p_akost.astype(int)
        df_heats.p_dat = df_heats.p_dat.dt.tz_localize(
            "Europe/Bratislava", ambiguous="NaT", nonexistent="NaT"
        ).dt.tz_convert("UTC")

        # Drop records with missing timestamp (due to DST)
        df_heats = df_heats.dropna(subset=["p_dat"])

        return df_heats

    def get_next_planned_heats(
        self, *, steelshop: int, num_of_heats: int
    ) -> Optional[Tuple[PlannedHeat, ...]]:
        zpo_id = 1 if steelshop == 2 else 2

        df_heats = self.__get_raw_data(num_of_heats, zpo_id)

        if df_heats is None:
            return None

        return tuple(
            PlannedHeat(
                zpo_timestamp=record.p_dat.timestamp(),
                grade_id=record.p_akost,
                weight=record.hmot_tavby,
                order_num=record.id_vyroby,
            )
            for record in df_heats.itertuples(index=False)
        )
