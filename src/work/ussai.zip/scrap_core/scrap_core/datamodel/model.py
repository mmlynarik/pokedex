import datetime
import json
import logging
from datetime import date
from enum import Enum
from math import isfinite
from typing import Any, Dict, List, Optional, Tuple, TypeVar

import attr
import cattr
import jsonlines
import numpy as np
from immutables import Map
from usskssgrades import Grade

from attr_runtime_validation import VALIDATORS, OnAccessValidated  # type: ignore
from attr_runtime_validation.on_access_validation import disabled_validation
from attr_runtime_validation.validators import ValidationError

from .. import (
    SUPPORTED_SCRAP_TYPES,
    Chem,
    HeatKey,
    ScrapCharge,
    ScrapType,
    all_values_validator,
    between,
    not_none,
    optional_converter,
    positive_finite,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


converter = cattr.Converter()


# TODO change to flags enum
class TimeOfAnalysis(Enum):
    FORALL = "for_all_analysis"
    AFTERDESULF = "after_desulf"
    EOB = "eob"
    AFTERREBLOW = "after_reblow"
    FINAL = "final"


@attr.s(slots=True, frozen=True)
class RawFeChem:
    S: float = attr.ib(
        default=0.002, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    Cu: float = attr.ib(
        default=0.005, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    Ni: float = attr.ib(
        default=0.005, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    Cr: float = attr.ib(
        default=0.01, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    Mo: float = attr.ib(
        default=0.003, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    Sn: float = attr.ib(
        default=0.002, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    # TODO better default
    Si: float = attr.ib(
        default=0.562, validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )

    def get_chem(self, chem: Chem) -> float:
        chem_lower = chem.lower()
        if chem_lower == "s":
            return self.S
        if chem_lower == "cu":
            return self.Cu
        if chem_lower == "ni":
            return self.Ni
        if chem_lower == "cr":
            return self.Cr
        if chem_lower == "mo":
            return self.Mo
        if chem_lower == "sn":
            return self.Sn
        if chem_lower == "si":
            return self.Si
        raise Exception(f"Unknown chem {chem}")

    @classmethod
    def all_chems(cls) -> List[Chem]:
        return ["S", "Cu", "Ni", "Cr", "Mo", "Sn", "Si"]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


T = TypeVar("T")


def num_or_zero(num: Optional[float]) -> float:
    if num is None:
        return 0.0
    if not isfinite(num):
        return 0.0
    return num


def float_or_nan(val: Optional[float]) -> float:
    return float(val) if val is not None else np.nan


def get_validator_between(minimum: float, maximum: float):
    def validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
        if value < minimum:
            raise ValidationError(
                f"{attribute_type.name} is {value} but it must be larger or equal than {minimum}"
            )
        if value > maximum:
            raise ValidationError(
                f"{attribute_type.name} is {value} but it must be smaller or equal than {maximum}"
            )

    return validator


def heat_key_validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    if len(value) != 2:
        raise ValidationError("Heat key must be composed from heat id and heat year")
    heat_id, heat_year = value
    if len(str(heat_id)) != 5:
        raise ValidationError("Heat id must have lenght of 5 digits")
    if len(str(heat_year)) != 4:
        raise ValidationError("Heat year must have lenght of 4 digits")
    if not 1980 <= heat_year <= date.today().year:
        raise ValidationError(f"Heat year must be between years 1980 and {date.today().year}")


def time_of_analysis_validator(
    mins: Optional[Dict[TimeOfAnalysis, float]] = None,
    maxes: Optional[Dict[TimeOfAnalysis, float]] = None,
):
    def validator(full_instance, attribute_type, value):
        if np.isnan(value):
            return

        time_of_analysis = full_instance.time_of_analysis
        attribute_name = attribute_type.name
        if not isinstance(value, float):
            raise ValidationError(f"{time_of_analysis} -> {attribute_name} is not float")
        if not isfinite(value):
            raise ValidationError(f"{time_of_analysis} -> {attribute_name} is not finite")
        if mins is None and maxes is None:
            return
        minimum = (
            mins.get(TimeOfAnalysis(time_of_analysis), mins.get(TimeOfAnalysis.FORALL, 0.0))
            if mins is not None
            else 0.0
        )
        maximum = (
            maxes.get(
                ## TODO change ChemAnalysis.time_of_analysis to TimeOfAnalysis type
                TimeOfAnalysis(time_of_analysis),
                maxes.get(TimeOfAnalysis.FORALL, 100.0),
            )
            if maxes is not None
            else 100.0
        )
        if value < minimum:
            raise ValidationError(
                f"{time_of_analysis} -> {attribute_name} is {value}"
                f" but it must be larger or equal than {minimum}"
            )
        if value > maximum:
            raise ValidationError(
                f"{time_of_analysis} -> {attribute_name} is {value}"
                f" but it must be smaller or equal than {maximum}"
            )

    return validator


def same_mn_c_final_validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    if TimeOfAnalysis(value.time_of_analysis) == TimeOfAnalysis.FINAL and value.C == value.Mn:
        raise ValidationError(f"In final chem. analysis C and Mn are the same value {value.C}")


def too_many_missing_or_zero_validator(
    full_instance, attribute_type, value
):  # pylint: disable=unused-argument
    with disabled_validation(value) as dis_value:
        is_missing_or_zero = [
            np.isnan(dis_value.C) or dis_value.C == 0.0,
            np.isnan(dis_value.Mn) or dis_value.Mn == 0.0,
            np.isnan(dis_value.Si) or dis_value.Si == 0.0,
            np.isnan(dis_value.P) or dis_value.P == 0.0,
            np.isnan(dis_value.S) or dis_value.S == 0.0,
            np.isnan(dis_value.Al) or dis_value.Al == 0.0,
            np.isnan(dis_value.N) or dis_value.N == 0.0,
            np.isnan(dis_value.Cu) or dis_value.Cu == 0.0,
            np.isnan(dis_value.Ni) or dis_value.Ni == 0.0,
            np.isnan(dis_value.Cr) or dis_value.Cr == 0.0,
            np.isnan(dis_value.As) or dis_value.As == 0.0,
            np.isnan(dis_value.Sn) or dis_value.Sn == 0.0,
            np.isnan(dis_value.Mo) or dis_value.Mo == 0.0,
            np.isnan(dis_value.Ti) or dis_value.Ti == 0.0,
            np.isnan(dis_value.V) or dis_value.V == 0.0,
            np.isnan(dis_value.Zr) or dis_value.Zr == 0.0,
            np.isnan(dis_value.Nb) or dis_value.Nb == 0.0,
        ]

    if sum(is_missing_or_zero) >= 8:
        raise ValidationError(
            f"Too many missing values or zeros in {value.time_of_analysis} chem analysis: "
            f"{sum(is_missing_or_zero)} > 7"
        )


def no_unknown_scrap(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    for scrap in value:
        if (scrap.kind == "XXX") and (scrap.weight > 0.0):
            raise ValidationError(f"Unknown scrap with weight {scrap.weight} in heat")


def time_of_analysis_converter(value: Any) -> str:
    if isinstance(value, TimeOfAnalysis):
        return value.value
    return str(value)


def heat_key_converter(value: Any) -> HeatKey:
    return int(value[0]), int(value[1])


def scrap_code_converter(value: Any) -> str:
    return value.split("_")[0] if isinstance(value, str) and "_" in value else value


def reblow_cause_converter(value: Any) -> bool:
    return bool(num_or_zero(value) == 1.0)


@attr.s(slots=True, frozen=True)
class ChemAnalysis(OnAccessValidated):
    C: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(
                    {TimeOfAnalysis.FORALL: 0.00001}, {TimeOfAnalysis.AFTERDESULF: 8.0}
                )
            ]
        },
        converter=float_or_nan,
    )
    Mn: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(
                    {TimeOfAnalysis.FORALL: 0.00001}, {TimeOfAnalysis.AFTERDESULF: 4.0}
                )
            ]
        },
        converter=float_or_nan,
    )
    Si: float = attr.ib(metadata={VALIDATORS: [time_of_analysis_validator()]}, converter=float_or_nan)
    P: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(
                    {TimeOfAnalysis.FORALL: 0.00001}, {TimeOfAnalysis.AFTERDESULF: 0.4}
                )
            ]
        },
        converter=float_or_nan,
    )
    S: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(
                    {TimeOfAnalysis.FORALL: 0.00001},
                    {TimeOfAnalysis.AFTERDESULF: 0.1, TimeOfAnalysis.EOB: 10.0, TimeOfAnalysis.FINAL: 0.04},
                )
            ]
        },
        converter=float_or_nan,
    )
    Al: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.4, TimeOfAnalysis.EOB: 1.0})
            ]
        },
        converter=float_or_nan,
    )
    N: float = attr.ib(metadata={VALIDATORS: [time_of_analysis_validator()]}, converter=float_or_nan)
    Cu: float = attr.ib(
        metadata={VALIDATORS: [time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.2})]},
        converter=float_or_nan,
    )
    Ni: float = attr.ib(
        metadata={VALIDATORS: [time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.04})]},
        converter=float_or_nan,
    )
    Cr: float = attr.ib(metadata={VALIDATORS: [time_of_analysis_validator({}, {})]}, converter=float_or_nan)
    As: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.04, TimeOfAnalysis.EOB: 0.04})
            ]
        },
        converter=float_or_nan,
    )
    Sn: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(
                    maxes={TimeOfAnalysis.AFTERDESULF: 0.02, TimeOfAnalysis.FINAL: 1.0}
                )
            ]
        },
        converter=float_or_nan,
    )
    Mo: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.2, TimeOfAnalysis.EOB: 0.6})
            ]
        },
        converter=float_or_nan,
    )
    Ti: float = attr.ib(metadata={VALIDATORS: [time_of_analysis_validator()]}, converter=float_or_nan)
    V: float = attr.ib(metadata={VALIDATORS: [time_of_analysis_validator()]}, converter=float_or_nan)
    Zr: float = attr.ib(
        metadata={VALIDATORS: [time_of_analysis_validator(maxes={TimeOfAnalysis.EOB: 1.0})]},
        converter=float_or_nan,
    )
    Nb: float = attr.ib(
        metadata={
            VALIDATORS: [
                time_of_analysis_validator(maxes={TimeOfAnalysis.AFTERDESULF: 0.2, TimeOfAnalysis.EOB: 0.2})
            ]
        },
        converter=float_or_nan,
    )
    time_of_analysis: str = attr.ib(
        converter=time_of_analysis_converter,
        metadata={VALIDATORS: [attr.validators.in_(["after_desulf", "eob", "after_reblow", "final"])]},
    )

    def get_chem(self, chem: Chem) -> float:
        if hasattr(self, chem):
            return getattr(self, chem)
        raise AttributeError(f"Chem {chem} does not exist.")


def find_missed_chems(analysis: ChemAnalysis, grade: Grade) -> Tuple[Tuple[Chem, ...], Tuple[Chem, ...]]:
    missed: List[Chem] = []
    unknown: List[Chem] = []
    for limit in grade.limits:
        try:
            measurement = getattr(analysis, limit.chem)
        except AttributeError:
            log.exception(f"Unknown attribute {limit.chem}")
            measurement = None

        if measurement is None:
            unknown.append(limit.chem)

        elif not limit.minimum <= measurement <= limit.maximum:
            missed.append(limit.chem)
    return tuple(missed), tuple(unknown)


@attr.s(slots=True, frozen=True)
class ScrapInput(OnAccessValidated):
    # TODO change type to ScrapType - need to create structure hook for cattr
    kind: str = attr.ib(
        converter=scrap_code_converter,
        metadata={VALIDATORS: [attr.validators.in_(SUPPORTED_SCRAP_TYPES)]},
    )
    weight: float = attr.ib(converter=float)


@attr.s(slots=True, frozen=True)
class Heat(OnAccessValidated):
    heat_key: HeatKey = attr.ib(converter=heat_key_converter, metadata={VALIDATORS: [heat_key_validator]})
    heat_datetime: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    furnace: int = attr.ib(metadata={VALIDATORS: [attr.validators.in_([1, 2, 3, 4, 5])]}, converter=int)
    reblow_cause_p: bool = attr.ib(converter=reblow_cause_converter)
    reblow_cause_s: bool = attr.ib(converter=reblow_cause_converter)
    slag_s: float = attr.ib(converter=float_or_nan, metadata={VALIDATORS: [positive_finite]})
    raw_fe_weight: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(125000.0, 185000.0)]}
    )
    o2_pureness: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    main_o2: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    extra_o2: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    final_steel_weight: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(155000.0, 191000.0)]}
    )
    steel_weight_from_stand_without_slag: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(155000.0, 191000.0)]}
    )
    steel_weight_from_stand_with_slag: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(155000.0, 200000.0)]}
    )
    temperature_after_desulf: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(1000.0, 2000.0)]}
    )
    desulf_slag_weight: float = attr.ib(
        converter=float, metadata={VALIDATORS: [get_validator_between(0.0, 6000.0)]}
    )
    grade_planned: Grade = attr.ib(validator=attr.validators.instance_of(Grade))
    grade_final: Grade = attr.ib(validator=attr.validators.instance_of(Grade))
    synt_slag: float = attr.ib(converter=float, metadata={VALIDATORS: [get_validator_between(0.0, 10000.0)]})
    lime: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    magn: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    dolo: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    coke: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    pellets_weight: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    briquets_weight: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    tap_alloys_weight: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    yield_corrected_tap_alloys_weight: float = attr.ib(
        converter=float, metadata={VALIDATORS: [positive_finite]}
    )
    returned_steel_weight: float = attr.ib(converter=float, metadata={VALIDATORS: [positive_finite]})
    vacuum_heat: bool = attr.ib(converter=bool)
    scrap: Tuple[ScrapInput, ...] = attr.ib(
        validator=attr.validators.instance_of(tuple), metadata={VALIDATORS: [no_unknown_scrap]}
    )
    after_desulf: ChemAnalysis = attr.ib(
        validator=attr.validators.instance_of(ChemAnalysis),
        metadata={VALIDATORS: [too_many_missing_or_zero_validator]},
    )
    eob: ChemAnalysis = attr.ib(
        validator=attr.validators.instance_of(ChemAnalysis),
        metadata={VALIDATORS: [too_many_missing_or_zero_validator]},
    )
    final: ChemAnalysis = attr.ib(
        validator=attr.validators.instance_of(ChemAnalysis),
        metadata={VALIDATORS: [too_many_missing_or_zero_validator, same_mn_c_final_validator]},
    )
    after_reblow: Optional[ChemAnalysis] = attr.ib(
        default=None,
        validator=attr.validators.optional(attr.validators.instance_of(ChemAnalysis)),
    )

    def get_scrap_weight(self, scrap_type: ScrapType) -> float:
        for scrap in self.scrap:
            if scrap.kind == scrap_type:
                return scrap.weight
        return 0.0

    def get_scrap_map(self) -> Map[ScrapType, float]:
        # TODO remove type ignore when kind will be ScrapType
        return Map({row.kind: row.weight for row in self.scrap})  # type: ignore

    def get_last_known_analysis_before_alloying(self) -> ChemAnalysis:
        if self.after_reblow is not None:
            return self.after_reblow
        return self.eob

    @property
    def steelshop(self) -> int:
        return 1 if self.furnace in (1, 3) else 2


# TODO later in some other PR merge this with Heat class
# It is not solved in this PR as it will require more changes in many places
@attr.s(slots=True, frozen=True)
class HeatDataFromScada(OnAccessValidated):
    heat_key: HeatKey = attr.ib(converter=heat_key_converter, metadata={VALIDATORS: [heat_key_validator]})
    steelshop: int = attr.ib(converter=int, metadata={VALIDATORS: [between(1, 2)]})
    basket_ids: Tuple[int, ...] = attr.ib(
        converter=tuple, metadata={VALIDATORS: [all_values_validator(between(1, 1000))]}
    )
    operator_id: Optional[int] = attr.ib(
        converter=optional_converter(int),  # type: ignore
        metadata={VALIDATORS: [attr.validators.optional(between(0, 1000))]},
    )

    planned_grade_id: Optional[int] = attr.ib(
        converter=optional_converter(int), metadata={VALIDATORS: [not_none, between(1, 1000)]}  # type: ignore
    )

    final_grade_id: Optional[int] = attr.ib(
        converter=optional_converter(int), metadata={VALIDATORS: [not_none, between(1, 1000)]}  # type: ignore
    )
    # TODO how is this number calculated ? can it be calculated from final_steel_weight ?
    fe_yield: Optional[float] = attr.ib(
        converter=optional_converter(float),  # type: ignore
        metadata={VALIDATORS: [not_none, positive_finite, between(0.0, 100.0)]},
    )

    s_max: Optional[float] = attr.ib(
        converter=optional_converter(float), metadata={VALIDATORS: [positive_finite]}  # type: ignore
    )

    s_eob: Optional[float] = attr.ib(
        converter=optional_converter(float), metadata={VALIDATORS: [positive_finite]}  # type: ignore
    )

    extra_o2: float = attr.ib(
        converter=float,
        metadata={VALIDATORS: [positive_finite]},
    )

    synt_slag: float = attr.ib(
        converter=float,
        metadata={VALIDATORS: [positive_finite]},
    )

    heat_datetime: datetime.datetime = attr.ib()

    scrap_charge: ScrapCharge = attr.ib(metadata={VALIDATORS: [not_none]})


@attr.s(slots=True, frozen=True)
class PlannedHeat:
    zpo_timestamp: int = attr.ib(converter=int, validator=[positive_finite])  # UTC
    grade_id: int = attr.ib(converter=int, validator=[positive_finite])
    weight: int = attr.ib(converter=int, validator=[positive_finite])
    # 0 is a placeholder for missing order number (ID vyroby)
    order_num: int = attr.ib(converter=int, validator=[positive_finite], default=0)


def load_heats_from_file(file_path: str) -> List[Heat]:
    with jsonlines.open(file_path, mode="r") as reader:
        return [converter.structure(raw_heat, Heat) for raw_heat in reader]
