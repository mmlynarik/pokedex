from sqlalchemy.engine import create_engine, URL


class OracleHook:
    def __init__(self, conf):
        self.__url = URL.create("oracle+cx_oracle", **conf)
        self.engine = create_engine(self.__url, pool_pre_ping=True)

    def __del__(self):
        self.engine.dispose()

    @property
    def host(self):
        return self.__url.host

    @property
    def port(self):
        return self.__url.port
