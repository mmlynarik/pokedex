import datetime as dt
import logging
import os
from math import isfinite
from typing import (
    Any,
    Callable,
    Collection,
    Dict,
    Iterable,
    Optional,
    SupportsFloat,
    Tuple,
    TypedDict,
    Union,
)

import pandas as pd
import pymssql
from dateutil.tz import tzoffset
from sqlalchemy.engine import URL, create_engine
from usskssgrades.steel_grades_protocol import SteelGrades

from attr_runtime_validation.validators import ValidationError

from .. import TMS_ID_MAPPING, HeatKey, ScrapType
from .model import ChemAnalysis, Heat, ScrapInput

logger = logging.getLogger(__name__)


with open(os.path.join(os.path.dirname(__file__), "load_full_heat_from_oko.sql")) as f:
    LOAD_FULL_HEAT_FROM_OKO_SQL = f.read()


def num_or_zero(num: Optional[float]) -> float:
    if num is None:
        return 0.0
    if not isfinite(num):
        return 0.0
    return num


def num_or_throw(num: Optional[float]) -> float:
    if num is None:
        return 0.0
    converted = float(num)
    if not isfinite(converted):
        raise Exception("Num is not finite")
    return converted


class OkoDB(TypedDict):
    host: str
    port: int
    username: str
    password: str
    database: str


# All this is just to satisfy python typesystem
def validate_oko_env_config(env_config: Dict[str, Optional[str]]) -> OkoDB:
    oko_db: OkoDB = {"host": "", "username": "", "password": "", "database": "", "port": 0}

    # Loop cannot be used here as python typesystem only allows string literals as key for typeddict
    env_host = env_config.get("host")
    if env_host is None:
        raise Exception("Missing host information")
    oko_db["host"] = env_host

    env_port = env_config.get("port")
    if env_port is None:
        raise Exception("Missing port information")
    if not env_port.isdigit():
        raise Exception("Port must be digit value")
    oko_db["port"] = int(env_port)

    env_user = env_config.get("username")
    if env_user is None:
        raise Exception("Missing user information")
    oko_db["username"] = env_user

    env_password = env_config.get("password")
    if env_password is None:
        raise Exception("Missing password information")
    oko_db["password"] = env_password

    env_database = env_config.get("database")
    if env_database is None:
        raise Exception("Missing database name information")
    oko_db["database"] = env_database

    return oko_db


def get_tap_alloys_weight(data) -> float:
    return float(
        num_or_zero(data.ocp_chlad_srot)
        + num_or_zero(data.oct_niva)
        + num_or_zero(data.ocp_niva)
        + num_or_zero(data.oct_feal)
        + num_or_zero(data.ocp_feal)
        + num_or_zero(data.oct_feco)
        + num_or_zero(data.ocp_feco)
        + num_or_zero(data.oct_fesi_mpr)
        + num_or_zero(data.oct_fesi_dof)
        + num_or_zero(data.oct_fecu)
        + num_or_zero(data.oct_feb)
        + num_or_zero(data.ocp_feb)
        + num_or_zero(data.oct_few)
        + num_or_zero(data.ocp_few)
        + num_or_zero(data.oct_fecr)
        + num_or_zero(data.ocp_fecr)
        + num_or_zero(data.oct_feni)
        + num_or_zero(data.ocp_feni)
        + num_or_zero(data.oct_mnsi)
        + num_or_zero(data.ocp_mnsi)
        + num_or_zero(data.oct_casi)
        + num_or_zero(data.ocp_casi)
        + num_or_zero(data.oct_simn)
        + num_or_zero(data.ocp_simn)
        + num_or_zero(data.oct_fece)
        + num_or_zero(data.ocp_fece)
        + num_or_zero(data.oct_fesi)
        + num_or_zero(data.ocp_fesi)
        + num_or_zero(data.oct_fesi75)
        + num_or_zero(data.ocp_fesi75)
        + num_or_zero(data.ocp_fep)
        + num_or_zero(data.oct_fep)
        + num_or_zero(data.oct_femo)
        + num_or_zero(data.ocp_femo)
        + num_or_zero(data.oct_fenb)
        + num_or_zero(data.ocp_fenb)
        + num_or_zero(data.oct_fev)
        + num_or_zero(data.ocp_fev)
        + num_or_zero(data.oct_feti)
        + num_or_zero(data.ocp_feti)
        + num_or_zero(data.oct_fezr)
        + num_or_zero(data.ocp_fezr)
        + num_or_zero(data.oct_al_bloky)
        + num_or_zero(data.ocp_al_bloky)
        + num_or_zero(data.oct_al_vhanany)
        + num_or_zero(data.ocp_al_vhanany)
        + num_or_zero(data.ocp_al_granulovany)
        + num_or_zero(data.oct_al_granulovany)
        + num_or_zero(data.oct_al_tycovy)
        + num_or_zero(data.ocp_al_tycovy)
        + num_or_zero(data.oct_al_sekany)
        + num_or_zero(data.ocp_al_sekany)
        + num_or_zero(data.oct_al_stery)
        + num_or_zero(data.ocp_al_stery)
        + num_or_zero(data.oct_femn)
        + num_or_zero(data.ocp_femn)
        + num_or_zero(data.oct_femn_aff)
        + num_or_zero(data.ocp_femn_aff)
        + num_or_zero(data.vak_00_nezadane)
        + num_or_zero(data.vak_01_fev)
        + num_or_zero(data.vak_02_fenb_65)
        + num_or_zero(data.vak_03_koks_hrasok)
        + num_or_zero(data.vak_04_feti_70)
        + num_or_zero(data.vak_05_al_sekany)
        + num_or_zero(data.vak_06_femnc)
        + num_or_zero(data.vak_07_femn_affine_80)
        + num_or_zero(data.vak_08_fep_20)
        + num_or_zero(data.vak_09_feb)
        + num_or_zero(data.vak_10_srot)
        + num_or_zero(data.vak_11_fesi_75_dynamo)
        + num_or_zero(data.vak_12_fesi_65)
        + num_or_zero(data.vak_13_al_drot)
        + num_or_zero(data.vak_14_koks)
        + num_or_zero(data.vak_15_fesi_75_trafo)
        + num_or_zero(data.vak_16_fesica)
        + num_or_zero(data.vak_17_fesi_90)
        + num_or_zero(data.vak_18_femn_kov)
        + num_or_zero(data.vak_19_femnn)
        + num_or_zero(data.vak_20_mnel)
        + num_or_zero(data.vak_21_sb)
        + num_or_zero(data.vak_22_fecr)
        + num_or_zero(data.vak_23_fesi_75_dynamo)
        + num_or_zero(data.vak_24_fesi_75_granul)
        + num_or_zero(data.vak_25_fesb)
        + num_or_zero(data.vak_26_femo)
        + num_or_zero(data.vak_27_cu_hutna)
        + num_or_zero(data.vak_28_sn)
        + num_or_zero(data.vak_29_sira)
    )


# TODO move to yieldmodel
def get_yield_corrected_tap_alloys_weight(data) -> float:
    return float(
        num_or_zero(data.ocp_chlad_srot)
        + num_or_zero(data.oct_niva)
        + num_or_zero(data.ocp_niva)
        + num_or_zero(data.oct_feal)
        + num_or_zero(data.ocp_feal)
        + num_or_zero(data.oct_feco)
        + num_or_zero(data.ocp_feco)
        + (num_or_zero(data.oct_fesi_mpr) * 0.9)
        + (num_or_zero(data.oct_fesi_dof) * 0.9)
        + num_or_zero(data.oct_fecu)
        + (num_or_zero(data.oct_feb) * 0.95)
        + (num_or_zero(data.ocp_feb) * 0.95)
        + num_or_zero(data.oct_few)
        + num_or_zero(data.ocp_few)
        + (num_or_zero(data.oct_fecr) * 0.95)
        + (num_or_zero(data.ocp_fecr) * 0.95)
        + num_or_zero(data.oct_feni)
        + num_or_zero(data.ocp_feni)
        + num_or_zero(data.oct_mnsi)
        + num_or_zero(data.ocp_mnsi)
        + num_or_zero(data.oct_casi)
        + num_or_zero(data.ocp_casi)
        + num_or_zero(data.oct_simn)
        + num_or_zero(data.ocp_simn)
        + num_or_zero(data.oct_fece)
        + num_or_zero(data.ocp_fece)
        + (num_or_zero(data.oct_fesi) * 0.9)
        + (num_or_zero(data.ocp_fesi) * 0.9)
        + (num_or_zero(data.oct_fesi75) * 0.95)
        + (num_or_zero(data.ocp_fesi75) * 0.95)
        + (num_or_zero(data.ocp_fep) * 0.9)
        + (num_or_zero(data.oct_fep) * 0.9)
        + num_or_zero(data.oct_femo)
        + num_or_zero(data.ocp_femo)
        + (num_or_zero(data.oct_fenb) * 0.9)
        + (num_or_zero(data.ocp_fenb) * 0.9)
        + (num_or_zero(data.oct_fev) * 0.9)
        + (num_or_zero(data.ocp_fev) * 0.9)
        + (num_or_zero(data.oct_feti) * 0.95)
        + (num_or_zero(data.ocp_feti) * 0.95)
        + num_or_zero(data.oct_fezr)
        + num_or_zero(data.ocp_fezr)
        + (num_or_zero(data.oct_al_bloky) * 0.6)
        + (num_or_zero(data.ocp_al_bloky) * 0.6)
        + (num_or_zero(data.oct_al_vhanany) * 0.65)
        + (num_or_zero(data.ocp_al_vhanany) * 0.65)
        + (num_or_zero(data.ocp_al_granulovany) * 0.5)
        + (num_or_zero(data.oct_al_granulovany) * 0.5)
        + (num_or_zero(data.oct_al_tycovy) * 0.5)
        + (num_or_zero(data.ocp_al_tycovy) * 0.5)
        + (num_or_zero(data.oct_al_sekany) * 0.5)
        + (num_or_zero(data.ocp_al_sekany) * 0.5)
        + (num_or_zero(data.oct_al_stery) * 0.5)
        + (num_or_zero(data.ocp_al_stery) * 0.5)
        + (num_or_zero(data.oct_femn) * 0.95)
        + (num_or_zero(data.ocp_femn) * 0.95)
        + (num_or_zero(data.oct_femn_aff) * 0.95)
        + (num_or_zero(data.ocp_femn_aff) * 0.95)
        + num_or_zero(data.vak_00_nezadane)
        + num_or_zero(data.vak_01_fev)
        + (num_or_zero(data.vak_02_fenb_65) * 0.95)
        + num_or_zero(data.vak_03_koks_hrasok)
        + (num_or_zero(data.vak_04_feti_70) * 0.95)
        + (num_or_zero(data.vak_05_al_sekany) * 0.65)
        + num_or_zero(data.vak_06_femnc)
        + num_or_zero(data.vak_07_femn_affine_80)
        + num_or_zero(data.vak_08_fep_20)
        + num_or_zero(data.vak_09_feb)
        + num_or_zero(data.vak_10_srot)
        + num_or_zero(data.vak_11_fesi_75_dynamo)
        + num_or_zero(data.vak_12_fesi_65)
        + (num_or_zero(data.vak_13_al_drot) * 0.65)
        + num_or_zero(data.vak_14_koks)
        + num_or_zero(data.vak_15_fesi_75_trafo)
        + num_or_zero(data.vak_16_fesica)
        + num_or_zero(data.vak_17_fesi_90)
        + num_or_zero(data.vak_18_femn_kov)
        + num_or_zero(data.vak_19_femnn)
        + num_or_zero(data.vak_20_mnel)
        + num_or_zero(data.vak_21_sb)
        + num_or_zero(data.vak_22_fecr)
        + num_or_zero(data.vak_23_fesi_75_dynamo)
        + num_or_zero(data.vak_24_fesi_75_granul)
        + num_or_zero(data.vak_25_fesb)
        + num_or_zero(data.vak_26_femo)
        + num_or_zero(data.vak_27_cu_hutna)
        + num_or_zero(data.vak_28_sn)
        + num_or_zero(data.vak_29_sira)
    )


def defined_positive_finite(number: Optional[SupportsFloat]) -> bool:
    if number is None:
        return False
    converted = float(number)
    if not isfinite(converted):
        return False
    return converted > 0.0


def scrap_code_to_scrap_type(scrap_code: Any) -> ScrapType:
    try:
        return TMS_ID_MAPPING[int(scrap_code)]
    except Exception:  # pylint: disable=broad-except
        logger.warning(f"Unknown scrap code while parsing data from oko db: {scrap_code}")
        return "XXX"


def sum_same_scraps(scraps: Collection[ScrapInput]) -> Collection[ScrapInput]:
    return [
        ScrapInput(kind=scrap_type, weight=sum([x.weight for x in scraps if x.kind == scrap_type]))
        for scrap_type in {x.kind for x in scraps}
    ]


def parse_one_heat(
    data_for_one_heat: pd.DataFrame, steel_grades: SteelGrades, validation: bool = True
) -> Tuple[Optional[Heat], Optional[str]]:
    try:
        if len(data_for_one_heat) == 0:
            return None, "No data from oko"
        chem_row = data_for_one_heat.iloc[0]
        heat_key = (chem_row.oct_cis_tavby, chem_row.oct_rok_vyroby_tavby)
    except Exception as e:  # pylint: disable=broad-except
        return None, f"General error for unknown heat: {e}"

    try:
        processed_scraps = []
        total_scrap_weight = data_for_one_heat.hmotnost.values.sum()
        if defined_positive_finite(total_scrap_weight):
            scrap_weight_dividor = 1.0 if total_scrap_weight < 100000 else 100.0
            processed_scraps = [
                ScrapInput(
                    kind=scrap_code_to_scrap_type(scrap_data.kod_srotu),
                    weight=scrap_data.hmotnost / scrap_weight_dividor,
                )
                for _, scrap_data in data_for_one_heat.iterrows()
            ]
        one_heat_data = create_heat(heat_key, chem_row, processed_scraps, steel_grades)
        if validation:
            one_heat_data.validate_all()
        return one_heat_data, None
    except ValidationError as e:
        return None, f"Validation error for heat {heat_key}: {e}"
    except TypeError as e:
        return None, f"Type error for heat {heat_key}: {e}"
    except ValueError as e:
        return None, f"Value error for heat {heat_key}: {e}"
    except Exception as e:  # pylint: disable=broad-except
        return None, f"General error for heat {heat_key}: {e}"


def create_heat(
    index: HeatKey,
    data: pd.Series,
    processed_scraps: list,
    steel_grades: SteelGrades,
) -> Heat:
    heat_datetime = dt.datetime.strptime(str(data.oc_zac_vsadz), "%Y-%m-%d %H:%M:%S").replace(
        tzinfo=tzoffset("UTC+1", 3600)
    )

    if pd.isna(data.oct_cas_analyzy_predsk_2):
        analysis_after_reblow = None
    else:
        analysis_after_reblow = ChemAnalysis(
            As=data.oct_as_predsk_2,
            C=data.oct_c_predsk_2,
            Cr=data.oct_cr_predsk_2,
            Cu=data.oct_cu_predsk_2,
            Mn=data.oct_mn_predsk_2,
            Mo=data.oct_mo_predsk_2,
            N=data.oct_n2_predsk_2,
            Nb=data.oct_nb_predsk_2,
            Ni=data.oct_ni_predsk_2,
            P=data.oct_p_predsk_2,
            S=data.oct_s_predsk_2,
            Si=data.oct_si_predsk_2,
            Sn=data.oct_sn_predsk_2,
            Al=data.oct_tal_predsk_2,
            Ti=data.oct_ti_predsk_2,
            V=data.oct_v_predsk_2,
            Zr=data.oct_zr_predsk_2,
            time_of_analysis="after_reblow",
        )

    return Heat(
        heat_key=index,
        heat_datetime=heat_datetime.timestamp(),
        furnace=index[0] // 10000,
        slag_s=data.oct_s_obsah_trosky,
        raw_fe_weight=data.oct_hmotn_sur_zel * 10,
        o2_pureness=data.oct_cist_kysl,
        reblow_cause_p=data.oc_dofuk_p,
        reblow_cause_s=data.oc_dofuk_s,
        main_o2=data.oct_spotr_kysl_do_prer,
        extra_o2=data.oct_spotr_kyslika_dofuk,
        grade_planned=steel_grades.get_grade_from_id(int(data.akost_vyrabana), when=heat_datetime.date()),
        grade_final=steel_grades.get_grade_from_id(int(data.akost_uvolnena), when=heat_datetime.date()),
        final_steel_weight=data.oct_hmotn_tek_ocel,
        steel_weight_from_stand_without_slag=data.ocl_hmotn_oc_zo_st_bez_tros,
        steel_weight_from_stand_with_slag=data.ocl_hmotn_oc_zo_st_tros,
        temperature_after_desulf=data.oct_t_sur_fe,
        desulf_slag_weight=data.ocs_hmotnost_trosky,
        synt_slag=float(
            num_or_zero(data.oct_syntet_troska)
            + num_or_zero(data.oct_syntet_troska_r)
            + num_or_zero(data.oct_krycia_troska)
            + num_or_zero(data.hmotnost_prisady)
        ),
        lime=data.oct_hmotn_vapno,
        magn=data.oct_hmotn_magnezit_tav,
        dolo=data.oct_hmotn_dol_vap_tav,
        coke=data.oct_hmotn_koks_konv,
        pellets_weight=data.oct_pelety,
        briquets_weight=data.oct_brikety,
        tap_alloys_weight=get_tap_alloys_weight(data),
        yield_corrected_tap_alloys_weight=get_yield_corrected_tap_alloys_weight(data),
        returned_steel_weight=data.oct_hmotn_preliev_oc,
        vacuum_heat=not pd.isna(data.oc_zac_vak),
        after_desulf=ChemAnalysis(
            C=data.oct_c_sur_fe,
            Mn=data.oct_mn_sur_fe,
            Si=data.oct_si_sur_fe,
            P=data.oct_p_sur_fe,
            S=data.s_po_odsireni,
            Al=data.oct_tal_sur_fe,
            N=data.oct_n2_sur_fe,
            Cu=data.oct_cu_sur_fe,
            Ni=data.oct_ni_sur_fe,
            Cr=data.oct_cr_sur_fe,
            As=data.oct_as_sur_fe,
            Sn=data.oct_sn_sur_fe,
            Mo=data.oct_mo_sur_fe,
            Ti=data.oct_ti_sur_fe,
            V=data.oct_v_sur_fe,
            Zr=data.oct_zr_sur_fe,
            Nb=data.oct_nb_sur_fe,
            time_of_analysis="after_desulf",
        ),
        eob=ChemAnalysis(
            C=data.oct_c_predsk_1,
            Mn=data.oct_mn_predsk_1,
            Si=data.oct_si_predsk_1,
            P=data.oct_p_predsk_1,
            S=data.oct_s_predsk_1,
            Al=data.oct_tal_predsk_1,
            N=data.oct_n2_predsk_1,
            Cu=data.oct_cu_predsk_1,
            Ni=data.oct_ni_predsk_1,
            Cr=data.oct_cr_predsk_1,
            As=data.oct_as_predsk_1,
            Sn=data.oct_sn_predsk_1,
            Mo=data.oct_mo_predsk_1,
            Ti=data.oct_ti_predsk_1,
            V=data.oct_v_predsk_1,
            Zr=data.oct_zr_predsk_1,
            Nb=data.oct_nb_predsk_1,
            time_of_analysis="eob",
        ),
        after_reblow=analysis_after_reblow,
        final=ChemAnalysis(
            C=data.ocl_c_uvol_an,
            Mn=data.ocl_mn_uvol_an,
            Si=data.ocl_si_uvol_an,
            P=data.ocl_p_uvol_an,
            S=data.ocl_s_uvol_an,
            Al=data.ocl_tal_uvol_an,
            N=data.ocl_n2_uvol_an,
            Cu=data.ocl_cu_uvol_an,
            Ni=data.ocl_ni_uvol_an,
            Cr=data.ocl_cr_uvol_an,
            As=data.ocl_as_uvol_an,
            Sn=data.ocl_sn_uvol_an,
            Mo=data.ocl_mo_uvol_an,
            Ti=data.ocl_ti_uvol_an,
            V=data.ocl_v_uvol_an,
            Zr=data.ocl_zr_uvol_an,
            Nb=data.ocl_nb_uvol_an,
            time_of_analysis="final",
        ),
        scrap=tuple(sum_same_scraps(processed_scraps)),
    )


def load_db_data_from_oko(where_clause: str, oko_db: OkoDB) -> pd.DataFrame:
    engine = create_engine(URL.create("mssql+pymssql", **oko_db))
    with engine.begin() as conn:
        return pd.read_sql(" ".join([LOAD_FULL_HEAT_FROM_OKO_SQL, where_clause]), conn)


def get_heat_where_clause(heat_year: int, heat_id: int) -> str:
    # casting to int is important here as it protect us from sql injection attacks
    return (
        f"WHERE ds_tavba.oct_cis_tavby={int(heat_id)} AND "
        + f"ds_tavba.oct_rok_vyroby_tavby={int(heat_year)}"
    )


HeatResult = Tuple[Optional[Heat], Optional[str]]


def load_heat_from_oko(
    heat_year: int, heat_id: int, oko_db: OkoDB, steel_grades: SteelGrades, validation=True
) -> HeatResult:
    return parse_one_heat(
        load_db_data_from_oko(
            get_heat_where_clause(heat_year, heat_id),
            oko_db,
        ),
        steel_grades,
        validation,
    )


def group_by_heat(data: pd.DataFrame) -> Iterable[Tuple[HeatKey, Any]]:
    return data.groupby(["oct_cis_tavby", "oct_rok_vyroby_tavby"])


def load_data_from_oko_for_time(start: dt.datetime, end: dt.datetime, oko_db: OkoDB) -> pd.DataFrame:
    date_format = "%Y%m%d %X.000"
    start_formatted = start.strftime(date_format)
    end_formatted = end.strftime(date_format)
    load_heat_filter = f"WHERE datum_hut >= '{start_formatted}' AND datum_hut < '{end_formatted}'"
    engine = create_engine(URL.create("mssql+pymssql", **oko_db))
    with engine.begin() as conn:
        db_data = pd.read_sql(" ".join([LOAD_FULL_HEAT_FROM_OKO_SQL, load_heat_filter]), conn)
    if len(db_data) == 0:
        return None
    return db_data


def load_heats_from_oko_for_time_range(  # pylint: disable=too-many-arguments
    start: dt.datetime,
    end: dt.datetime,
    oko_db: OkoDB,
    steel_grades: SteelGrades,
    heat_loaded_callback: Callable[[Heat], int],
    error_callback: Callable[[HeatKey, str], int],
    validation: bool = True,
) -> None:
    data = load_data_from_oko_for_time(start, end, oko_db)
    if data is None:
        return
    for key, data_from_one_heat in group_by_heat(data):
        heat, error = parse_one_heat(data_from_one_heat, steel_grades, validation)
        if heat is not None:
            if not validation:
                heat.disable_on_access_validation()
            heat_loaded_callback(heat)
        if error is not None:
            error_callback(key, error)


def get_weeks(start_date: dt.datetime, stop_date: dt.datetime):
    actual_start = start_date
    while actual_start < stop_date:
        week_stop = actual_start + dt.timedelta(weeks=1)
        if week_stop < stop_date:
            yield (actual_start, week_stop)
        else:
            yield (actual_start, stop_date)
        actual_start = week_stop
