SELECT TOP {num_of_heats} DISTINCT
    a.id_vyroby,
    a.p_dat,
    a.c_sek,
    a.c_pol,
    a.cis_tavby,
    a.por_tavby,
    b.p_akost,
    b.p_akost_us,
    SUM(a.hmotn_bram) AS hmot_tavby
FROM
    p_zpo{zpo_id}_bramy a,
    p_zpo{zpo_id} b
WHERE
    a.id_vyroby = b.id_vyroby
AND
    -- planned heats with valid heat ID are already being processed
    -- somewhere between KK and ZPO, hence they are not relevant
    -- for scrap charge planning
    a.cis_tavby < 10000
GROUP BY
    a.id_vyroby,
    a.p_dat,
    a.c_sek,
    a.c_pol,
    a.cis_tavby,
    a.por_tavby,
    b.p_akost,
    b.p_akost_us
ORDER BY
    a.p_dat;
