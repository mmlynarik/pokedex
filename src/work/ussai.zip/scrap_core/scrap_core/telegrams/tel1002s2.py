from datetime import datetime
from typing import Optional, ClassVar, Tuple

import attr

from ussklevel2.components.base_telegram import BaseTelegram
from ussklevel2.components.converters import (
    int_or_none,
    bool_from_str,
    str_or_none,
)
from ussklevel2.components.fields import datetime_field
from ussklevel2.components.validators import equal

from scrap_core.telegrams.blocks import (
    ScrapCodes,
    ScrapWeight,
    Analysis,
)
from scrap_core.telegrams.tel1002s1 import TelegramHeaderS1


@attr.s(frozen=True, kw_only=True)
class TelegramHeaderS2(TelegramHeaderS1):
    """
    Remark:
        TelLen is not an attribute of telegram,
        rather it is calculated during telegram encoding/decoding
    """

    _field_order: ClassVar[Tuple[str, ...]] = (
        "tel_idx",
        "sender_num",
        "operator_id",
        "header_reserve",
        "blend_id",
        "order_num",
        "order_seq",
        "heat_num",
        "heat_year",
    )

    # fmt: off
    tel_idx: Optional[int] = attr.field(converter=int_or_none, default=None)    # TelIndex
    order_seq: Optional[int] = attr.field(converter=int_or_none, default=None)  # OrderSequ
    # fmt: on


@attr.s(frozen=True, kw_only=True)
class Telegram1002s2(BaseTelegram):
    _field_order = (
        "tel_no",
        "header",
        "selectivity",
        "num_of_scraps",
        "scrap_codes",
        "num_of_cars",
        "car_no_1",
        "car_no_2",
        "car_no_3",
        "car_no_4",
        "scrap_weight_1",
        "scrap_weight_2",
        "scrap_weight_3",
        "scrap_weight_4",
        "timestamp",
        "flag",
        "data_str",
        "spare_1",
        "order_selected",
        "blend_completed",
        "scrap_recipe",
        "spare_2",
        "ordered_grade",
        "ordered_bundle",
        "ordered_pit",
        "analysis_1",
        "analysis_2",
        "analysis_3",
        "is_wet_scrap",
        "scale_id",
        "spare_bytes",
    )
    # fmt: off
    header: TelegramHeaderS2 = attr.ib()
    num_of_scraps: int = attr.field(converter=int)                                          # NumberOfScraps
    num_of_cars: int = attr.ib(converter=int)                                               # NumberOfCars
    timestamp: datetime = datetime_field()                                                  # TimeStamp
    ordered_grade: str = attr.ib(converter=str)                                             # OrderedGrade
    selectivity: int = attr.field(converter=int)                                            # Selectivity
    ordered_bundle: Optional[int] = attr.ib(converter=int_or_none, default=None)            # OrderedBundle
    ordered_pit: Optional[int] = attr.ib(converter=int_or_none, default=None)               # OrderedPit
    is_wet_scrap: bool = attr.ib(converter=bool_from_str)                                   # IsWetScrap
    scale_id: Optional[int] = attr.field(converter=int_or_none, default=None)               # ScaleID
    tel_no: int = attr.ib(converter=int, default=1002, validator=equal(1002))               # TelNo
    scrap_codes: ScrapCodes = attr.ib()
    car_no_1: int = attr.ib(converter=int_or_none)                                          # CarNo1
    car_no_2: int = attr.ib(converter=int_or_none, default=None)                            # CarNo2
    car_no_3: int = attr.ib(converter=int_or_none, default=None)                            # CarNo3
    car_no_4: int = attr.ib(converter=int_or_none, default=None)                            # CarNo4
    scrap_weight_1: ScrapWeight = attr.ib()
    scrap_weight_2: ScrapWeight = attr.ib(default=ScrapWeight())
    scrap_weight_3: ScrapWeight = attr.ib(default=ScrapWeight())
    scrap_weight_4: ScrapWeight = attr.ib(default=ScrapWeight())
    flag: Optional[int] = attr.ib(converter=int_or_none, default=None)                      # Flag
    data_str: Optional[str] = attr.ib(converter=str_or_none, default=None)                  # DataStr
    spare_1: Optional[str] = attr.ib(converter=str_or_none, default=None)                   # Spare1
    order_selected: Optional[datetime] = datetime_field(is_optional=True)                   # OrderSelected
    blend_completed: Optional[datetime] = datetime_field(is_optional=True)                  # BlendCompleted
    scrap_recipe: ScrapWeight = attr.ib(default=ScrapWeight())
    spare_2: Optional[str] = attr.ib(converter=str_or_none, default=None)                   # Spare2
    analysis_1: Analysis = attr.ib(default=Analysis())
    analysis_2: Analysis = attr.ib(default=Analysis())
    analysis_3: Analysis = attr.ib(default=Analysis())
    spare_bytes: Optional[str] = attr.field(converter=int_or_none, default=None)            # SpareBytes
    # fmt: on
