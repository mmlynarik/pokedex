from scrap_core.telegrams.tel1002s1 import TelegramHeaderS1, Telegram1002s1
from scrap_core.telegrams.tel1002s2 import TelegramHeaderS2, Telegram1002s2


# TODO
# - [ ] add telegram validations                                (new task - scrap_core)
#           - check if sum of car scrap weights == scrap weight
#           - check that every positive scrap weight has its corresponding scrap code
#           - etc.
# - [ ] identify required attributes                            (new task - scrap_core)
