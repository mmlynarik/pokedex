from typing import Optional, Tuple, ClassVar

import attr

from ussklevel2.components.base_telegram import BaseTelegram
from ussklevel2.components.block import TelegramBlock
from ussklevel2.components.converters import (
    int_or_none,
    bool_from_str,
    str_or_none,
)
from ussklevel2.components.validators import equal

from scrap_core.telegrams.blocks import (
    Car,
    ScrapCodes,
    ScrapWeight,
)


@attr.s(frozen=True, kw_only=True)
class TelegramHeaderS1(TelegramBlock):
    """
    Remark:
        TelLen is not an attribute of telegram,
        rather it is calculated during telegram encoding/decoding
    """

    _field_order: ClassVar[Tuple[str, ...]] = (
        "order_num",
        "sender_num",
        "operator_id",
        "header_reserve",
        "blend_id",
        "heat_num",
        "heat_year",
    )

    # fmt: off
    blend_id: int = attr.field(converter=int)                                           # BlendID
    operator_id: int = attr.field(converter=int_or_none)                                # OperatorID
    order_num: Optional[int] = attr.field(converter=int_or_none, default=None)          # OrderNumber/OrderNo
    sender_num: Optional[int] = attr.field(converter=int_or_none, default=None)         # SenderNumber
    header_reserve: Optional[str] = attr.field(converter=str_or_none, default=None)     # Header_Reserve
    heat_num: Optional[int] = attr.field(converter=int_or_none, default=None)           # HeatNumber
    heat_year: Optional[int] = attr.field(converter=int_or_none, default=None)          # Year
    # fmt: on


@attr.s(frozen=True, kw_only=True)
class Telegram1002s1(BaseTelegram):
    _field_order = (
        "tel_no",
        "header",
        "trim_weight",
        "num_of_scraps",
        "scrap_codes",
        "scrap_weight",
        "num_of_cars",
        "car_1",
        "car_2",
        "car_3",
        "car_4",
        "undefined",
        "is_wet_scrap",
        "scale_id",
        "spare_bytes",
    )
    # fmt: off
    tel_no: int = attr.ib(converter=int, default=1002, validator=equal(1002))               # TelNo
    header: TelegramHeaderS1 = attr.ib()
    scale_id: int = attr.field(converter=int)                                               # ScaleID
    num_of_cars: int = attr.ib(converter=int)                                               # NumberOfCars
    num_of_scraps: int = attr.field(converter=int)                                          # NumberOfScraps
    is_wet_scrap: bool = attr.ib(converter=bool_from_str)                                   # IsWetScrap
    scrap_codes: ScrapCodes = attr.ib()
    scrap_weight: ScrapWeight = attr.ib()
    trim_weight: Optional[int] = attr.field(converter=int_or_none, default=None)            # TrimWeight
    car_1: Car = attr.ib()
    car_2: Car = attr.ib(default=Car())
    car_3: Car = attr.ib(default=Car())
    car_4: Car = attr.ib(default=Car())
    undefined: Optional[str] = attr.field(converter=str_or_none, default=None)              # Undefined
    spare_bytes: Optional[str] = attr.field(converter=str_or_none, default=None)            # SpareBytes
    # fmt: on
