import logging
import socket
from typing import Optional


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def send_data(data: bytes, url: str, timeout: Optional[int] = None) -> None:
    """Send data to given url"""

    host, port = url.split(":")
    address = (host, int(port))

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(timeout)
        sock.connect(address)
        sock.sendall(data)

    log.info(
        "%s bytes sent to %s:%s",
        len(data),
        host,
        port,
    )
