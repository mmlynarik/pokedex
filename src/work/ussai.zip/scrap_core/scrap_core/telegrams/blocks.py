from typing import Optional

import attr

from ussklevel2.components.block import TelegramBlock
from ussklevel2.components.converters import float_or_none, int_or_none, str_or_none


@attr.s(frozen=True)
class ScrapCodes(TelegramBlock):
    # fmt: off
    code_1: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode1
    code_2: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode2
    code_3: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode3
    code_4: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode4
    code_5: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode5
    code_6: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode6
    code_7: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode7
    code_8: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode8
    code_9: Optional[int] = attr.field(converter=int_or_none, default=None)                 # ScrapCode9
    code_10: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode1
    code_11: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode11
    code_12: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode12
    code_13: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode13
    code_14: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode14
    code_15: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode15
    code_16: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode16
    code_17: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode17
    code_18: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode18
    code_19: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode19
    code_20: Optional[int] = attr.field(converter=int_or_none, default=None)                # ScrapCode20
    # fmt: on

    def __len__(self):
        return sum(item is not None for item in attr.astuple(self))

    def to_seq(self) -> tuple:
        def to_level2_code(code: int) -> str:
            if not code:
                return ""
            else:
                return {942: "94_2", 962: "96_2", 912: "91_2", 913: "91_3"}.get(code, str(code)).rjust(2, "0")

        return tuple(map(to_level2_code, attr.astuple(self)))


# TODO consider default 0 instead of None
@attr.s(frozen=True)
class ScrapWeight(TelegramBlock):
    # fmt: off
    weight_1: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt1
    weight_2: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt2
    weight_3: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt3
    weight_4: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt4
    weight_5: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt5
    weight_6: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt6
    weight_7: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt7
    weight_8: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt8
    weight_9: Optional[int] = attr.field(converter=int_or_none, default=None)               # Scrap(Recipe)Wt9
    weight_10: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt1
    weight_11: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt11
    weight_12: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt12
    weight_13: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt13
    weight_14: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt14
    weight_15: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt15
    weight_16: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt16
    weight_17: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt17
    weight_18: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt18
    weight_19: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt19
    weight_20: Optional[int] = attr.field(converter=int_or_none, default=None)              # Scrap(Recipe)Wt20
    # fmt: on


@attr.s(frozen=True, kw_only=True)
class Car(TelegramBlock):
    """Basket"""

    _field_order = (
        "car_no",
        "blend_id",
        "order_no",
        "order_seq",
        "grade_corporate_code",
        "selectivity",
        "scrap_weight",
    )
    # fmt: off
    car_no: Optional[int] = attr.field(converter=int_or_none, default=None)                 # CarNo
    blend_id: Optional[int] = attr.field(converter=int_or_none, default=None)               # Blend_ID_Car
    order_no: Optional[int] = attr.field(converter=int_or_none, default=None)               # OrderNo_Car
    order_seq: Optional[int] = attr.field(converter=int_or_none, default=None)              # OrderSequ_Car
    grade_corporate_code: Optional[str] = attr.field(converter=str_or_none, default=None)   # SteelGrade_Car
    selectivity: Optional[int] = attr.field(converter=int_or_none, default=None)            # Selectivity_Car
    scrap_weight: ScrapWeight = attr.ib(default=ScrapWeight())
    # fmt: on


@attr.s(frozen=True, kw_only=True)
class Analysis(TelegramBlock):
    # fmt: off
    s: float = attr.ib(converter=float_or_none, default=None)                               # S
    p: float = attr.ib(converter=float_or_none, default=None)                               # P
    cu: float = attr.ib(converter=float_or_none, default=None)                              # Cu
    cr: float = attr.ib(converter=float_or_none, default=None)                              # Cr
    ni: float = attr.ib(converter=float_or_none, default=None)                              # Ni
    mo: float = attr.ib(converter=float_or_none, default=None)                              # Mo
    mn: float = attr.ib(converter=float_or_none, default=None)                              # Mn
    sn: float = attr.ib(converter=float_or_none, default=None)                              # Sn
    # fmt: on
