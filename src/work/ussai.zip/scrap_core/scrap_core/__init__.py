from functools import lru_cache
import logging
from math import isfinite
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Collection,
    List,
    Set,
    Literal,
    Mapping,
    Hashable,
    NewType,
    Optional,
    Sequence,
    Tuple,
    TypeVar,
    Union,
    cast,
)

import torch
from immutables import Map
import pandas as pd


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# Heat Id, Heat Year
HeatKey = Tuple[int, int]


MIN_LOADABLE_SCRAP_WEIGHT_DEFAULT = 1500.0

PRIME_GROUP_NAME = "Prime"
CUT_GROUP_NAME = "Cut"
HOME_GROUP_NAME = "Home"

ScrapTypeGroup = Literal[
    "Prime",
    "Cut",
    "Home",
]

DOMESTIC_SCRAP_ZONES = (
    "1",
    "2",
    "3",
    "4",
)

ScrapType = Literal[
    "HSA",
    "HSCA",
    "HSR",
    "HSR Cr",
    "HSZ",
    "HSB",
    "HSB COOL",
    "HDS",
    "HSK",
    "HSD",
    "HS",
    "PAS",
    "2HM",
    "1HM",
    "MCE",
    "1BC",
    "HST",
    "TBS",
    "ZBS",
    "SBS",
    "2BC",
    "1IB",
    "1DB",
    "1TB",
    "2DB",
    "1SH",
    "2SH",
    "1RR",
    "TBC",
    "1SR",
    "STS",
    "1BBC",
    "2BBC",
    "TBBC",
    "XXX",
    "HB",
    "1BS",
    "SHS",
    "DSI",
    "SRB",
    "PIG IRON",
    "1PIT",
    "BPIT",
    "2PIT",
    "TRM",
    "1PIT A2",
    "2PIT A2",
    "DSI A1 2",
    "DSI A1 3",
]

ScrapMix = NewType("ScrapMix", str)
ScrapCharge = Map[ScrapMix, float]
ScrapBounds = Map[ScrapMix, float]
ScrapMixMapping = Map[ScrapMix, Map[ScrapType, float]]

T = TypeVar("T")
K = TypeVar("K", bound=Hashable)

Chem = Literal[
    "Cr",
    "Cu",
    "Mo",
    "Ni",
    "S",
    "Sn",
    "Si",
    "C",
    "Mn",
    "P",
    "Al",
    "N",
    "As",
    "Ti",
    "V",
    "Zr",
    "Nb",
    "Pb",
    "Al",
    "Al/N",
    "As",
    "B",
    "B/N",
    "C",
    "C+",
    "C++",
    "C+1/6 Mn",
    "C+N+C+M+S",
    "CE",
    "Ca",
    "Ca/S",
    "Ceq",
    "Cequ",
    "Co",
    "Cr",
    "Cr+Cu+Mo",
    "Cr+Mo",
    "Cr+N+M+A+S",
    "Cr+Ni",
    "Cr+Ni+Cu",
    "Cr+Ni+Mo",
    "Cu",
    "Cu+6Sn",
    "Cu+Ni",
    "Cu+Ni+Cr+M",
    "Cu+Ni+Cr+Mo",
    "Cu+Ni+Cr+Sn",
    "H2",
    "Mn",
    "Mn/S",
    "Mn/Si",
    "Mo",
    "Mo+",
    "N",
    "Nb",
    "Nb+Ti",
    "Nb+Ti+V+Zr",
    "Nb+V+Ti",
    "Nb,V,Ti,Cu",
    "Ni",
    "O",
    "O2",
    "P",
    "Pb",
    "Pcm",
    "S",
    "Sb",
    "Si",
    "Si+2,5P",
    "Si+Al",
    "Si+P",
    "Sn",
    "Ta",
    "Ti",
    "Ti+",
    "Ti++",
    "Ti/N",
    "V",
    "V+Nb",
    "V+Ti+Nb+B+Zr",
    "W",
    "Zn",
    "Zr",
    "P_blow",  # frontend.scrap.dash.components.blend_results_table:149
    "Tavba",  # frontend.scrap.dash.components.blend_results_table:181
]
SUPPORTED_CHEMS: Tuple[Chem, ...] = ("Cr", "Cu", "Mo", "Ni", "P", "S", "Sn", "Si")
ScrapOrder = Tuple[ScrapType, ...]
ScrapMixOrder = Tuple[ScrapMix, ...]
ScrapMixes = Collection[ScrapMix]


SUPPORTED_SCRAP_TYPES: ScrapOrder = (
    # Each row contains SCRAP TYPE, INDEX of SCRAP TYPE in blend model input names list and TMS description
    "HSA",  # 04        TMS ID: 01, Home Scrap - Alloyed
    "HSCA",  # 05       TMS ID: 02, Home Scrap - Castings Cr
    "HSR",  # 06        TMS ID: 03, Home Scrap - Rolls
    "HSR Cr",  # 07     TMS ID: 04, Home Scrap - Rolls Cr
    "HSZ",  # 08        TMS ID: 05, Home Scrap - Tundish skulls
    "HSB",  # 09        TMS ID: 06, Home Scrap - Heavy slabs
    "HSB COOL",  # 10   TMS ID: 110, Home Scrap - Heavy slabs - added in SS1
    "HDS",  # 11        TMS ID: 07, Home Scrap - Dynamo scrap (Name changed: HDS[1] -> HDS)
    "HSK",  # 12        TMS ID: 08, Home Scrap - Old cast mold iron
    "HSD",  # 13        TMS ID: 09, Home Scrap - From demolations
    "HS",  # 14         TMS ID: 10, Home Scrap - Mill revert
    "PAS",  # 15        TMS ID: 11, Plate and structural
    "2HM",  # 16        TMS ID: 12, No.2 Heavy melting scrap
    "1HM",  # 17        TMS ID: 13, No.1 Heavy melting scrap
    "MCE",  # 18        TMS ID: 14, Mill crop ends
    "1BC",  # 19        TMS ID: 21, No.1 Bailing clips
    "HST",  # 20        TMS ID: 23, Home Scrap - Tin
    "TBS",  # 21        TMS ID: 24, Tin busheling scrap
    "ZBS",  # 22        TMS ID: 25, Zinc busheling scrap
    "SBS",  # 23        TMS ID: 26, Silicon busheling scrap
    "2BC",  # 24        TMS ID: 27, No.2 Bailing clips
    "1IB",  # 25        TMS ID: 31, No.1 Industrial bundles
    "1DB",  # 26        TMS ID: 33, No.1 Dealer bundles
    "1TB",  # 27        TMS ID: 34, No.1 Tin bundles
    "2DB",  # 28        TMS ID: 36, No.2 Dealer bundles
    "1SH",  # 29        TMS ID: 41, No.1 Sheared material
    "2SH",  # 30        TMS ID: 42, No.2 Sheared material
    "1RR",  # 31        TMS ID: 44, No.1 Rail road scrap
    "TBC",  # 32        TMS ID: 45, Tin bailing clips
    "1SR",  # 33        TMS ID: 46, No.1 Sheared rebars
    "STS",  # 34        TMS ID: 51, Steel turnings
    "1BBC",  # 35       TMS ID: 59, No.1 Bailing clips bundeled in USSK
    "2BBC",  # 36       TMS ID: 60, No.2 Bailing clips bundeled in USSK
    "TBBC",  # 37       TMS ID: 61, Tin bailing clips bundeled in USSK (Name changed: 1BBS -> TBBC)
    "HB",  # 38         TMS ID: 63, Home scrap - mill revert bundled
    "1BS",  # 39        TMS ID: 74, No.1 Busheling scrap
    "SHS",  # 40        TMS ID: 77, Shredded scrap
    "DSI",  # 41        TMS ID: 91, Desulf skimmer iron (Name changed: PIT -> DSI)
    "SRB",  # 42        TMS ID: 92, PIT Scrap - Serbia
    "PIG IRON",  # 43   TMS ID: 93, Pig iron - USSK
    "1PIT",  # 44       TMS ID: 94, PIT scrap - product A - skulls revert
    "BPIT",  # 45       TMS ID: 95, B PIT
    "2PIT",  # 46       TMS ID: 96, PIT scrap - slag heaps
    "TRM",  # 47        TMS ID: 80, Trial code for recycled materials
    "1PIT A2",  # 48    TMS ID: 94_2, PIT scrap - product A2 - skulls revert
    "2PIT A2",  # 49    TMS ID: 96_2, PIT scrap - slag heaps - fraction A2
    "DSI A1 2",  # 50   TMS ID: 91_2, Desulf skimmer iron fraction A1/2
    "DSI A1 3",  # 51   TMS ID: 91_3,
    "XXX",  # 52        Unknown scrap
)
SUPPORTED_SCRAP_TYPES_SET = set(SUPPORTED_SCRAP_TYPES)
SUPPORTED_SCRAP_TYPES_AS_MIXES: ScrapMixOrder = tuple(
    ScrapMix(scrap_type) for scrap_type in SUPPORTED_SCRAP_TYPES
)

SCRAP_GROUP_MAPPING: Mapping[ScrapType, ScrapTypeGroup] = Map(
    {  # type: ignore
        "HSA": "Home",
        "HSCA": "Home",
        "HSR": "Home",
        "HSR Cr": "Home",
        "HSZ": "Home",
        "HSB": "Home",
        "HSB COOL": "Home",
        "HDS": "Home",
        "HSK": "Home",
        "HSD": "Home",
        "HS": "Home",
        "PAS": "Cut",
        "2HM": "Cut",
        "1HM": "Cut",
        "MCE": "Cut",
        "1BC": "Prime",
        "HST": "Home",
        "TBS": "Cut",
        "ZBS": "Prime",
        "SBS": "Prime",
        "2BC": "Cut",
        "1IB": "Prime",
        "1DB": "Prime",
        "1TB": "Cut",
        "2DB": "Cut",
        "1SH": "Cut",
        "2SH": "Cut",
        "1RR": "Cut",
        "TBC": "Cut",
        "1SR": "Cut",
        "STS": "Cut",
        "1BBC": "Home",
        "2BBC": "Home",
        "TBBC": "Home",
        "XXX": "Home",
        "HB": "Home",
        "1BS": "Prime",
        "SHS": "Cut",
        "DSI": "Home",
        "SRB": "Home",
        "PIG IRON": "Home",
        "1PIT": "Home",
        "BPIT": "Home",
        "2PIT": "Home",
        "TRM": "Home",
        "1PIT A2": "Home",
        "2PIT A2": "Home",
        "DSI A1 2": "Home",
        "DSI A1 3": "Home",
    }
)


PRIME_SCRAP = tuple(scrap_type for scrap_type, group in SCRAP_GROUP_MAPPING.items() if group == "Prime")


CUT_SCRAP = tuple(scrap_type for scrap_type, group in SCRAP_GROUP_MAPPING.items() if group == "Cut")


TMS_ID_MAPPING: Mapping[int, ScrapType] = Map(
    {  # type: ignore
        1: "HSA",
        2: "HSCA",
        3: "HSR",
        4: "HSR Cr",
        5: "HSZ",
        6: "HSB",
        7: "HDS",
        8: "HSK",
        9: "HSD",
        10: "HS",
        11: "PAS",
        12: "2HM",
        13: "1HM",
        14: "MCE",
        21: "1BC",
        23: "HST",
        24: "TBS",
        25: "ZBS",
        26: "SBS",
        27: "2BC",
        31: "1IB",
        33: "1DB",
        34: "1TB",
        36: "2DB",
        41: "1SH",
        42: "2SH",
        44: "1RR",
        45: "TBC",
        46: "1SR",
        51: "STS",
        59: "1BBC",
        60: "2BBC",
        61: "TBBC",
        63: "HB",
        74: "1BS",
        77: "SHS",
        91: "DSI",
        92: "SRB",
        93: "PIG IRON",
        94: "1PIT",
        95: "BPIT",
        96: "2PIT",
        80: "TRM",
        110: "HSB COOL",
        942: "1PIT A2",
        962: "2PIT A2",
        912: "DSI A1 2",
        913: "DSI A1 3",
    }
)

SPAREPARTS_ID_MAPPING: Mapping[int, ScrapType] = Map(
    {  # type: ignore
        5350: "1PIT",
        5351: "2PIT",
        5352: "1IB",
        5353: "2SH",
        5354: "1BC",
        5355: "1BS",
        5356: "1DB",
        5357: "1HM",
        5358: "1RR",
        5359: "1SR",
        5360: "1TB",
        5361: "1SH",
        5362: "2BC",
        5363: "2DB",
        5364: "2HM",
        5365: "MCE",
        5366: "PAS",
        5367: "SBS",
        5368: "SHS",
        5369: "STS",
        5370: "TBC",
        5371: "TBS",
        5372: "ZBS",
        5373: "SVa 2000",
        5374: "TVa 2000",
        5375: "ZHD",
        5376: "ZHD1",
        5377: "ODPAD ZUSLACHTOVNE",
        5378: "ODPAD NEPODARKY",
        5379: "ODPAD ZLIATKY",
        5380: "ODREZ Z BRAM",
        5381: "-PAS",
        5382: "-OC2",
        5383: "NA",
        5384: "NA",
        5385: "NA",
        5386: "NA",
        5387: "NA",
    }
)

TMS_ID_REVERSE_MAPPING = Map({v: k for k, v in TMS_ID_MAPPING.items()})
SPAREPARTS_ID_REVERSE_MAPPING = Map({v: k for k, v in SPAREPARTS_ID_MAPPING.items()})


# Attr validator
def has_no_duplicates(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    duplicates = [v for v in value if value.count(v) > 1]

    if duplicates:
        raise ValueError(f"Sequence {attribute_type.name} contains duplicates: {duplicates}.")


def is_subset_of(scope: Iterable):
    def validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
        out_of_scope = set(value) - set(scope)

        if out_of_scope:
            raise ValueError(
                f"Attribute {attribute_type.name} contains elements {out_of_scope}"
                f"that are not listed in {tuple(scope)} ."
            )

    return validator


def keys_are_scrap_types(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    unsupported_scrap_types = set(value.keys()) - SUPPORTED_SCRAP_TYPES_SET

    if unsupported_scrap_types:
        raise ValueError(
            f"Scrap map {attribute_type.name} constains unsupported scrap types: {unsupported_scrap_types}."
        )


def values_are_finite(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    infinite_values = {key: v for key, v in value.items() if not isfinite(v)}

    if infinite_values:
        raise ValueError(f"Scrap map {attribute_type.name} contains infinite values: {infinite_values}.")


def values_are_non_negative(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    negative_values = {key: v for key, v in value.items() if v < 0}

    if negative_values:
        raise ValueError(f"Scrap map {attribute_type.name} contains negative values: {negative_values}.")


def values_are_between(lower_bound: float, upper_bound: float):
    def validator(full_instance, attribute_type, value):  # pylint: disable=unused-argument
        invalid = {key: v for key, v in value.items() if not lower_bound <= v <= upper_bound}

        if invalid:
            raise ValueError(
                f"Map {attribute_type.name} contains values {invalid} "
                f"that are not within given bounds {lower_bound} and {upper_bound}."
            )

    return validator


def positive_finite(full_instance, attribute_type, value):  # pylint: disable=unused-argument
    if not isfinite(value):
        raise ValueError(f"{attribute_type.name} is not finite")
    if value < 0.0:
        raise ValueError(f"{attribute_type.name} is negative")


def reverse_vectorize(scrap_order: Sequence[K], vectorized: Sequence[T], default_value: T) -> Dict[K, T]:
    items_count, scrap_order_length = len(vectorized), len(scrap_order)

    if items_count != scrap_order_length:
        raise ValueError(
            f"Cannot reverse vectorization - invalid number of items {items_count} - "
            + f"must be {scrap_order_length}"
        )
    mapping_values = {
        scrap_type: value for scrap_type, value in zip(scrap_order, vectorized) if value != default_value
    }
    return mapping_values


def vectorize_values_dynamic(
    scrap_order: Sequence[ScrapType], value_getter: Callable[[ScrapType], T]
) -> List[T]:
    return [value_getter(scrap_type) for scrap_type in scrap_order]


def vectorize_values(
    scrap_order: Sequence[ScrapType], values: Mapping[ScrapType, T], default_value: T
) -> List[T]:
    if not set(scrap_order).issuperset(values):
        raise ValueError(
            f"Cannot vectorize values: {values} - there are unsupported scrap types."
            + f" Supported scrap types are: {scrap_order}"
        )
    return vectorize_values_dynamic(scrap_order, lambda scrap_type: values.get(scrap_type, default_value))


def vectorize_values_total(scrap_order: Sequence[ScrapType], values: Mapping[ScrapType, T]) -> List[T]:
    return vectorize_values_dynamic(scrap_order, lambda scrap_type: values[scrap_type])


@lru_cache(maxsize=1024)
def vectorize_scrap_weights(
    scrap_order: Sequence[ScrapType], scrap_weights: Map[ScrapType, float]
) -> List[float]:
    return vectorize_values(scrap_order, scrap_weights, 0.0)


def scrap_mix_to_scrap_type_set(scrap_mix_mapping: ScrapMixMapping, scrap_mix: ScrapMix) -> Set[ScrapType]:
    if scrap_mix in scrap_mix_mapping:
        return set(scrap_mix_mapping[scrap_mix])
    if scrap_mix in SUPPORTED_SCRAP_TYPES_AS_MIXES:
        return set([cast(ScrapType, scrap_mix)])
    raise ValueError(
        f"Invalid scrap mix: {scrap_mix} -  "
        + "scrap mix must be valid scrap type or included in scrap mix mapping"
    )


def get_affected_scrap_mixes(
    scrap_mix_order: ScrapMixOrder, scrap_mix_mapping: ScrapMixMapping, scrap_types: Tuple[ScrapType, ...]
) -> ScrapMixOrder:
    """Affected mixes are all that contain any scrap type from `scrap_types`."""
    return tuple(
        scrap_mix
        for scrap_mix in scrap_mix_order
        if scrap_mix_to_scrap_type_set(scrap_mix_mapping, scrap_mix).intersection(scrap_types)
    )


def must_be_value(input_value: Any):
    def validator(_, attribute_type, value):
        if input_value != value:
            raise ValueError(f"{attribute_type.name} is {value} but it must be {input_value}")

    return validator


def all_values_validator(orig_validator):
    def validator(full_instance, attribute_type, value):
        for item in value:
            orig_validator(full_instance, attribute_type, item)

    return validator


def between(minimum: Any, maximum: Any):
    def validator(_, attribute_type, value):
        if value < minimum:
            raise ValueError(
                f"{attribute_type.name} is {value} but it must be larger or equal than {minimum}"
            )
        if value > maximum:
            raise ValueError(
                f"{attribute_type.name} is {value} but it must be smaller or equal than {maximum}"
            )

    return validator


def greater_than(input_value: Any):
    def validator(_, attribute_type, value):
        if value < input_value:
            raise ValueError(f"{attribute_type.name} is {value} but it must be larger than {input_value}")

    return validator


def not_none(_, attribute_type, value):
    if value is None:
        raise ValueError(f"{attribute_type.name} is not filled in")


C = TypeVar("C")


def optional_converter(original_converter: Callable[[Any], C]) -> Callable[[Any], Optional[C]]:
    def converter(value: Any) -> Optional[C]:
        try:
            return None if pd.isna(value) else original_converter(value)
        except (TypeError, ValueError):
            log.exception(
                f"Optional converter - converter {original_converter} can't convert invalid value {value}"
            )
            return None

    return converter


# Attr converter
def create_to_scrap_map_converter(default_value: float) -> Callable[[Any], Map[ScrapType, float]]:
    def converter(value: Any) -> Map[ScrapType, float]:
        if isinstance(value, dict):
            return Map(value)
        if isinstance(value, Map):
            return value
        scrap_order, scrap_vector = value
        return Map(reverse_vectorize(scrap_order, scrap_vector, default_value))

    return converter


scrap_weights_converter = create_to_scrap_map_converter(0.0)
loadable_scrap_weights_converter = create_to_scrap_map_converter(float("nan"))


def scrap_mix_mapping_converter(mapping: Map[ScrapMix, Dict[ScrapType, float]]):
    return Map({k: Map(v) for k, v in mapping.items()})


def scrap_weights_to_scrap_string(
    scrap_loaded_weights: Optional[Mapping[ScrapMix, Union[float, int]]]
) -> str:
    if scrap_loaded_weights is None:
        return ""
    tuples = [f"{scrap_mix}:{int(weight)}" for scrap_mix, weight in sorted(scrap_loaded_weights.items())]
    return " ".join(tuples)


IT = TypeVar("IT")


def filter_out_nones(data: List[Optional[IT]]) -> List[IT]:
    return [x for x in data if x is not None]


DT = TypeVar("DT")
RT = TypeVar("RT")
OT = TypeVar("OT")


# pylint: disable=no-member
def run_by_group(
    grouping_vector: torch.LongTensor,
    selector: Callable[[torch.LongTensor], DT],
    func: Callable[[int, DT], RT],
    aggregate: Callable[[List[RT], torch.LongTensor], OT],
) -> OT:
    sorted_groups, sorted_groups_indices = torch.sort(grouping_vector)
    delta = sorted_groups[1:] - sorted_groups[:-1]
    cutpoints = [0] + (delta.nonzero().flatten() + 1).tolist() + [len(grouping_vector)]
    results = []
    for start, end in zip(cutpoints[:-1], cutpoints[1:]):
        selected_indexes = sorted_groups_indices[start:end]
        results.append(func(int(sorted_groups[start]), selector(selected_indexes)))  # type: ignore
    return aggregate(results, torch.argsort(sorted_groups_indices))  # type: ignore


def get_sequence_of_tensors_to_tensor_selector(
    tensor_sequence: Sequence[torch.Tensor],
) -> Callable[[torch.LongTensor], torch.Tensor]:
    def selector(selected_indexes: torch.LongTensor) -> torch.Tensor:
        return torch.vstack([tensor_sequence[i] for i in selected_indexes])

    return selector


def aggregate_tensor_results(results: Sequence[torch.Tensor], orig_order: torch.LongTensor) -> torch.Tensor:
    return torch.cat(results)[orig_order]  # type: ignore
