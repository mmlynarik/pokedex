"""
TODO add option to read grade chem data from ISPV database (see steel_grades_ispv.py and ispv_hook.py modules)
"""

import argparse
import os
import datetime as dt

import cattr
import jsonlines
from tqdm import tqdm

from usskssgrades import SteelGradesHardcoded
from scrap_core.datamodel.oko import validate_oko_env_config, get_weeks, load_heats_from_oko_for_time_range
from scrap_core import SUPPORTED_CHEMS


def parse_args():
    parser = argparse.ArgumentParser(description="Generate blendmodel training data")
    parser.add_argument(
        "-s",
        "--startdate",
        help="The Start Date - format YYYY-MM-DD",
        required=True,
        type=lambda s: dt.datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-e",
        "--enddate",
        help="The End Date format YYYY-MM-DD=",
        required=True,
        type=lambda s: dt.datetime.strptime(s, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-u",
        "--user",
        help="User for database connection",
        required=True,
        type=str,
    )
    parser.add_argument(
        "-p",
        "--password",
        help="Password for database connection",
        required=True,
        type=str,
    )
    parser.add_argument(
        "-n", "--name", help="Database name for database connection", required=False, type=str, default="oko"
    )
    parser.add_argument(
        "-d",
        "--host",
        help="Database name for database connection",
        required=False,
        type=str,
        default="VSQLOKO.sk.uss.com",
    )
    parser.add_argument(
        "-o",
        "--omitvalidation",
        help="After this flag, validators will be omitted",
        default=False,
        action="store_true",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    if args.enddate <= args.startdate:
        print("Start date must be earlier date as end date")
        return
    db_oko = validate_oko_env_config(
        {
            "host": f"{args.host}",
            "username": f"{args.user}",
            "password": f"{args.password}",
            "database": f"{args.name}",
            "port": "1433",
        }
    )
    run_timestamp_name = str(int(dt.datetime.timestamp(dt.datetime.now())))

    if args.omitvalidation:
        run_timestamp_name = run_timestamp_name + "_validation_omitted"

    if not os.path.isdir("./data"):
        os.mkdir("./data")

    with jsonlines.open(f"./data/parse_heat_errors_{run_timestamp_name}.jsonl", mode="w") as error_writer:
        with jsonlines.open(f"./data/heatdata_{run_timestamp_name}.jsonl", mode="w") as heat_writer:
            for week in tqdm(list(get_weeks(args.startdate, args.enddate)), desc="Loading data", unit="week"):
                load_heats_from_oko_for_time_range(
                    week[0],
                    week[1],
                    db_oko,
                    SteelGradesHardcoded(SUPPORTED_CHEMS),
                    lambda heat: heat_writer.write(cattr.unstructure(heat)),  # pylint: disable=no-member
                    lambda key, error: error_writer.write(  # pylint: disable=no-member
                        (int(key[0]), int(key[1]), error)
                    ),
                    not args.omitvalidation,
                )


if __name__ == "__main__":
    main()
