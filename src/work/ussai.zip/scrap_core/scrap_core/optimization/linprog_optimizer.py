# pylint: disable=too-many-lines
import itertools
import logging
from functools import lru_cache
from itertools import islice
from typing import (
    Callable,
    Collection,
    Sequence,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
    cast,
)

import attr
import numpy as np
from immutables import Map
from scipy.linalg import block_diag, norm
from scipy.optimize import linprog
from scipy.optimize._optimize import OptimizeResult
from usskssgrades.grade import Grade

from scrap_core import (
    SUPPORTED_SCRAP_TYPES_AS_MIXES,
    Chem,
    ScrapBounds,
    ScrapCharge,
    ScrapMix,
    ScrapMixOrder,
    ScrapOrder,
    ScrapType,
    ScrapMixMapping,
    reverse_vectorize,
    vectorize_scrap_weights,
    get_affected_scrap_mixes,
)
from scrap_core.blendmodel.datamodel import ScrapBlendModelInput
from scrap_core.blendmodel.utils import chem_in_scrap_approx_from_blend_model_result_diff
from scrap_core.correctiontechnologiesmodel import get_corr_tech_model
from scrap_core.correctiontechnologiesmodel.corr_tech_model import CorrectionTechnologiesModel
from scrap_core.correctiontechnologiesmodel.correction_technologies import remaining_chem_weights
from scrap_core.correctiontechnologiesmodel.datamodel import CorrectionTechnologiesModelInput
from scrap_core.modelutils import expected_ct_risk_deviation, get_ct_risk
from scrap_core.optimization import get_all_models_from_model_settings
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    HeatInputs,
    ModelSettings,
    MultipleHeatsOptimizationInput,
    MultipleHeatsOptimizationOutput,
    ScrapExclusiveGroup,
    ScrapExclusiveGroups,
    ScrapMixLimit,
)
from scrap_core.optimization.limitrelaxation import Relaxers, get_relaxable_limits_relaxers
from scrap_core.optimization.expected_risk import get_expected_risk_levels
from scrap_core.optimization.relaxable_limits import (
    RELAXATION_SCHEDULE,
    RelaxableUpperSummingLimit,
    RelaxableLowerSummingLimit,
    RelaxableRiskLimit,
)
from scrap_core.optimization.validations import validate_scrap_limits
from scrap_core.utils import union, powerset, omit_zeros, get_simple_integer_approximations

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


CHEM_UNIT_WEIGHT_APPROX_PERCENTILE: float = 0.5
CHEM_UNIT_WEIGHT_APPROX_WEIGHT: float = 10000.0
MAX_TESTED_COMBINATIONS_POSTPROCESSING = 256

"""
Constraints used (or should be used)
1.  Per heat ordered weight                      [y]
2.  Global upper limits                          [y]
3.  Global lower limits                          [n] currently not used
4.  Per heat lower limits                        [y] lower bounds are automatically included
5.  Per heat upper limits                        [y]
6.  Per heat used scrap upper limit              [n] currently not implemented
7.  Per heat upper H meltability limit           [y]
8.  Per heat lower H meltability limit           [n] deprecated
9.  Per heat upper L meltability limit           [y]
10. Per heat lower L meltability limit           [n] deprecated
11. Per heat Min loadable limit                  [y] postprocessing
12. Per heat Super H (HSB, HSR, HSZ) scrap limit [y]
13. Per heat Max undesirable corr tech limit     [y] very relaxed and linearized
14. Loadability limits                           [y]

Price components
1. Total sulphur placed                          [y]
"""


@attr.s(slots=True)
class Constraint:
    coef_matrix: np.ndarray = attr.ib()
    values_vector: np.ndarray = attr.ib()


# Available scrap mixes are scrap mixes that can be used (upper bound > 0) in scrap mix order
@lru_cache(maxsize=32)
def get_available_scrap_mixes(input_data: MultipleHeatsOptimizationInput) -> ScrapMixOrder:
    all_potential_mixes: ScrapMixOrder = SUPPORTED_SCRAP_TYPES_AS_MIXES + tuple(
        input_data.model_settings.optimizer_settings.scrap_mix_mapping
    )
    upper_bounds = input_data.upper_bounds
    return tuple(scrap_mix for scrap_mix in all_potential_mixes if upper_bounds.get(scrap_mix, 0.0) > 0.0)


def scrap_mixes_to_scrap_types(mix_mapping: ScrapMixMapping, scrap_mixes: ScrapMixOrder) -> ScrapOrder:
    all_scrap_types: List[ScrapType] = []
    for mix in scrap_mixes:
        if mix in mix_mapping:
            all_scrap_types.extend(mix_mapping[mix].keys())
        else:
            all_scrap_types.append(cast(ScrapType, mix))
    return tuple(set(all_scrap_types))


# FIXME not used, remove
@lru_cache(maxsize=32)
def get_available_scrap_types(input_data: MultipleHeatsOptimizationInput) -> ScrapOrder:
    "Break down available scrap mixes to constituent scrap types."
    return scrap_mixes_to_scrap_types(
        input_data.model_settings.optimizer_settings.scrap_mix_mapping, get_available_scrap_mixes(input_data)
    )


@lru_cache(maxsize=32)
def first_heat_forced_scrap_mixes(input_data: MultipleHeatsOptimizationInput) -> ScrapMixOrder:
    """Tuple of scrap mixes forced by user-defined lower limits for the first heat."""
    if not input_data.heats:
        return tuple()
    return tuple(scrap_mix for scrap_mix, weight in input_data.heats[0].lower_bounds.items() if weight > 0)


@lru_cache(maxsize=32)
def get_available_scrap_mix_count(input_data: MultipleHeatsOptimizationInput) -> int:
    return len(get_available_scrap_mixes(input_data))


@lru_cache(maxsize=32)
def optimization_mode_best(input_data: MultipleHeatsOptimizationInput) -> bool:
    return input_data.model_settings.optimizer_settings.optimization_mode.lower() == "best"


def get_best_mode_chem_importances_by_grade(
    grade: Grade, model_settings: ModelSettings, base_chem: Chem = "Cr"
) -> Map[Chem, float]:
    """The lower the grade chem maximum limit, the more important chem for best mode optimization."""
    grade_chem_limits: Dict[Chem, float] = {}
    for chem in model_settings.supported_chems:
        limit = grade.get_limit(chem)
        if limit is not None:
            grade_chem_limits[chem] = limit.maximum
    base_chem_limit = grade_chem_limits[base_chem]
    return Map({chem: round(base_chem_limit / limit, 2) for chem, limit in grade_chem_limits.items()})


def get_weighted_chem_vector_for_one_heat(
    model_settings: ModelSettings, heat: HeatInputs, scrap_mixes: ScrapMixOrder
) -> np.ndarray:
    """
    Chem scores for each available scrap constitute weighted chem vector for one heat
    Scrap score calculated as a weighted sum of unit chem weights and best-mode importances
    """
    scores = []
    unit_chem_weights = get_unit_chem_weights(model_settings, heat, scrap_mixes)
    best_mode_importances = get_best_mode_chem_importances_by_grade(heat.grade_planned, model_settings)
    for scrap_mix in scrap_mixes:
        scores.append(
            sum(
                unit_chem_weights[chem][scrap_mix] * best_mode_importances[chem]
                for chem in model_settings.supported_chems
            )
        )
    return np.array(scores)


def get_best_mode_objective_function(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    model_settings = input_data.model_settings
    optimization_scrap_mix_order = get_available_scrap_mixes(input_data)
    price_vector: List[float] = []
    for heat in input_data.heats:
        price_vector.extend(
            get_weighted_chem_vector_for_one_heat(model_settings, heat, optimization_scrap_mix_order)
        )
    return np.array(price_vector)


def get_min_max_scrap_unit_chem_weights() -> Dict[Chem, Dict[str, float]]:
    """Value unit_chem_weight["S"]["HS"] is weight of sulphur in 1 kg of HS scrap."""
    # Values are calculated in non_best_mode_optimization.ipynb jupyter notebook
    return {
        "Cr": {"min": 0, "max": 0.00023435377966143315},
        "Cu": {"min": 0, "max": 0.0025537177074713},
        "Mo": {"min": 0, "max": 3.0529405118777085e-05},
        "Ni": {"min": 0, "max": 0.00048007575736926523},
        "S": {"min": 0, "max": 0.0026906507271804727},
        "Sn": {"min": 0, "max": 0.0015630146139525311},
        "Si": {"min": 0, "max": 5.948108800518153e-05},
    }


def get_min_max_grade_chem_maxima() -> Dict[Chem, Dict[str, float]]:
    # Values are calculated in non_best_mode_optimization.ipynb jupyter notebook
    return {
        "Cr": {"min": 0, "max": 1.15},
        "Cu": {"min": 0, "max": 0.554},
        "Mo": {"min": 0, "max": 0.354},
        "Ni": {"min": 0, "max": 0.55},
        "S": {"min": 0, "max": 0.025},
        "Sn": {"min": 0, "max": 0.11},
        "Si": {"min": 0, "max": 3.305},
    }


def minmax_zero_one_chem_scaler(
    minmax_chem_dict: Dict[Chem, Dict[str, float]], chem: Chem, x: float
) -> float:
    """Scale value into interval [0, 1] using a dict of precalculated `min` and `max` values per chem."""
    xmin, xmax = minmax_chem_dict[chem]["min"], minmax_chem_dict[chem]["max"]
    return (min(x, xmax) - xmin) / (xmax - xmin)


def grade_chem_maximum_scaler(x: float, chem: Chem) -> float:
    """Minmax scaler applied to grade chem maximum, calculated from all grades for each chem."""
    min_max_grade_chem_maxima = get_min_max_grade_chem_maxima()
    return minmax_zero_one_chem_scaler(min_max_grade_chem_maxima, chem, x)


def unit_chem_weight_scaler(x: float, chem: Chem) -> float:
    """Minmax scaler applied to scrap unit chem weight, calculated from nearly all scraps and for each chem"""
    min_max_unit_chem_weights = get_min_max_scrap_unit_chem_weights()
    return minmax_zero_one_chem_scaler(min_max_unit_chem_weights, chem, x)


def get_worst_mode_price_vector_as_dict(input_data: MultipleHeatsOptimizationInput) -> Dict[str, float]:
    return dict(zip(get_available_scrap_mixes(input_data), get_worst_mode_objective_function(input_data)))


def get_worst_mode_objective_function(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    coef_matrix = get_chem_constraints(input_data, scaled=True).coef_matrix
    optimization_scrap_mixes = get_available_scrap_mixes(input_data)

    # collect chem limits per grade/heat
    grade_chem_coef_matrix = block_diag(
        *[
            np.array(
                [  # type: ignore
                    [
                        grade_chem_maximum_scaler(heat.grade_planned.get_limit(chem).maximum, chem)  # type: ignore
                        for chem in input_data.model_settings.supported_chems
                    ]
                    for _ in optimization_scrap_mixes
                ]
            ).T
            / idx  # to put higher importance/weight on early heats and save good scrap for later heats.
            for idx, heat in enumerate(input_data.heats, start=1)
        ]
    )
    # grade_chem_coef_matrix[grade_chem_coef_matrix == 0] = 1

    # Coef_matrix.sum(axis=0) contains information about total sum of trace elements contained in 1kg of scrap
    # Using multiplication by chem limits defined per grade, we encourage selection of high-limit chems in
    # optimization objective function which we originaly want to maximize.
    # print(input_data.model_settings.supported_chems)
    # print(f"{coef_matrix[:, 1]=}")
    # print(f"{grade_chem_coef_matrix[:, 1]=}")
    return (coef_matrix * grade_chem_coef_matrix).sum(axis=0) * (-1)


def get_objective_function(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    """Calculate linprog's linear objective function as numpy array."""
    if optimization_mode_best(input_data):
        return get_best_mode_objective_function(input_data)
    return get_worst_mode_objective_function(input_data)


@lru_cache(maxsize=32)
def get_per_heat_lower_bounds_vector(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    optimization_scrap_mix_order = get_available_scrap_mixes(input_data)
    all_lower_bounds = []
    for heat in input_data.heats:
        for scrap_mix in optimization_scrap_mix_order:
            all_lower_bounds.append(heat.lower_bounds.get(scrap_mix, 0.0))
    return np.array(all_lower_bounds)


def get_per_heat_coef_matrix(heat_count: int, heat_vector: np.ndarray) -> np.ndarray:
    available_scrap_mix_count = len(heat_vector)
    return np.array(
        [
            np.concatenate(
                [
                    np.zeros(available_scrap_mix_count * i),
                    heat_vector,
                    np.zeros(available_scrap_mix_count * (heat_count - 1 - i)),
                ]
            )
            for i in range(heat_count)
        ]
    )


@lru_cache(maxsize=1024)
def get_per_heat_ordered_weight_coef_matrix(heat_count: int, available_scrap_mix_count: int) -> np.ndarray:
    return get_per_heat_coef_matrix(heat_count, np.ones(available_scrap_mix_count))


def get_per_heat_ordered_weight_constraint(input_data: MultipleHeatsOptimizationInput) -> Constraint:
    heats = input_data.heats
    coef_matrix = get_per_heat_ordered_weight_coef_matrix(
        len(heats), get_available_scrap_mix_count(input_data)
    )
    values_vector = np.array([heat.total_scrap_weight for heat in heats])
    lower_bounds = coef_matrix.dot(get_per_heat_lower_bounds_vector(input_data))
    return Constraint(coef_matrix, (values_vector - lower_bounds))


@lru_cache(maxsize=1024)
def get_global_scrap_coef_matrix(heat_count: int, available_scrap_mix_count: int) -> np.ndarray:
    all_selectors = []
    for i in range(available_scrap_mix_count):
        scrap_mix_selector = np.zeros(available_scrap_mix_count)
        scrap_mix_selector[i] = 1.0
        all_selectors.append(np.concatenate([scrap_mix_selector] * heat_count))
    return np.array(all_selectors)


def get_global_scrap_upper_bounds(optimization_input: MultipleHeatsOptimizationInput) -> Constraint:
    optimization_scrap_mix_order = get_available_scrap_mixes(optimization_input)
    upper_bounds = optimization_input.upper_bounds
    coef_matrix = get_global_scrap_coef_matrix(
        len(optimization_input.heats), len(optimization_scrap_mix_order)
    )
    values_vector = np.array([upper_bounds[scrap_mix] for scrap_mix in optimization_scrap_mix_order])
    lower_bounds = coef_matrix.dot(get_per_heat_lower_bounds_vector(optimization_input))
    return Constraint(coef_matrix, values_vector - lower_bounds)


def get_active_upper_bound(
    total_weight: int,
    lower_bounds: ScrapBounds,
    upper_bounds: Collection[ScrapBounds],
    scrap_mix: ScrapMix,
) -> float:
    active_upper_bound = min(total_weight, min([b.get(scrap_mix, total_weight) for b in upper_bounds]))
    lower_bound = lower_bounds.get(scrap_mix, 0.0)
    if active_upper_bound < lower_bound:
        return lower_bound
    return active_upper_bound


def get_active_upper_bound_calculator(
    optimization_input: MultipleHeatsOptimizationInput,
) -> Callable[[HeatInputs, ScrapMix], float]:
    global_upper_bounds = optimization_input.upper_bounds

    def calculator(heat: HeatInputs, scrap_mix: ScrapMix) -> float:
        return get_active_upper_bound(
            heat.total_scrap_weight,
            heat.lower_bounds,
            [heat.upper_bounds, global_upper_bounds],
            scrap_mix,
        )

    return calculator


def get_dummy_constraint(scrap_mix_order: ScrapMixOrder) -> Constraint:
    return Constraint(np.array([np.zeros_like(scrap_mix_order, dtype=int)]), np.array([0]))


def get_constraint_row(scrap_mix_order: ScrapMixOrder, affected_scrap_mixes: ScrapMixOrder) -> np.ndarray:
    return np.array([sm in affected_scrap_mixes for sm in scrap_mix_order]).astype(int)


def get_upper_bound_constraint_weight(
    weight_limit: float, lower_bounds: ScrapBounds, affected_scrap_mixes: ScrapMixOrder
) -> int:
    value = weight_limit - sum(lower_bounds.get(scrap_mix, 0) for scrap_mix in affected_scrap_mixes)
    return int(max(value, 0))


# TODO normalize user defined lower bounds and global lower bounds - use only one type of resolving
def get_user_defined_upper_bound(
    heat: HeatInputs, scrap_mix_order: ScrapMixOrder, scrap_mix: ScrapMix
) -> Constraint:
    row = get_constraint_row(scrap_mix_order, (scrap_mix,))
    value = get_upper_bound_constraint_weight(
        heat.upper_bounds.get(scrap_mix, heat.total_scrap_weight), heat.lower_bounds, (scrap_mix,)
    )
    # value = heat.upper_bounds.get(scrap_type, heat.total_scrap_weight) - heat.lower_bounds.get(scrap_type, 0)
    return Constraint(np.array(row), np.array([value]))


def get_user_defined_upper_bounds(heat: HeatInputs, scrap_mix_order: ScrapMixOrder) -> Constraint:
    # One inequality per each scrap mix mentioned in local limits
    return join_constraints(
        [
            get_user_defined_upper_bound(heat, scrap_mix_order, scrap_mix)
            for scrap_mix in sorted(set(heat.lower_bounds) | set(heat.upper_bounds))
        ]
    )


def get_summing_limit_constraint(
    heat: HeatInputs,
    scrap_mix_order: ScrapMixOrder,
    limit: Union[RelaxableUpperSummingLimit, RelaxableLowerSummingLimit],
    affected_scrap_mixes: ScrapMixOrder,
) -> Constraint:
    constraint_orientation = 1 if isinstance(limit, RelaxableUpperSummingLimit) else -1
    row = get_constraint_row(scrap_mix_order, affected_scrap_mixes)
    value = get_upper_bound_constraint_weight(
        limit.get_effective_weight_limit(heat.total_scrap_weight), heat.lower_bounds, affected_scrap_mixes
    )
    return Constraint(np.array(row) * constraint_orientation, np.array([value]) * constraint_orientation)


def get_summing_limit_constraints(
    heat: HeatInputs,
    scrap_mix_order: ScrapMixOrder,
    mix_mapping: ScrapMixMapping,
) -> Constraint:
    all_constraints = []
    # One inequality per every applicable summing scrap limit
    for limit_cfg in heat.relaxable_upper_summing_limits + heat.relaxable_lower_summing_limits:
        affected_scrap_mixes = get_affected_scrap_mixes(scrap_mix_order, mix_mapping, limit_cfg.scrap_types)
        # skip limits that don't affect any available scrap mix
        if not affected_scrap_mixes:
            continue
        all_constraints.append(
            get_summing_limit_constraint(heat, scrap_mix_order, limit_cfg, affected_scrap_mixes)
        )

    return join_constraints(all_constraints)


@lru_cache(maxsize=64)
def get_optimization_upper_bounds_for_one_heat(
    heat: HeatInputs,
    scrap_mix_order: ScrapMixOrder,
    mix_mapping: ScrapMixMapping,
) -> Constraint:
    """Upper bounds for given heat altered with lower bounds as needed"""
    # We use dummy constraint (0 <= 0) so that each heat contributes with equal number of columns to overall
    # coeff matrix. This is needed as user and summing limits constraints can together yield empty constraints
    dummy_constraint = get_dummy_constraint(scrap_mix_order)
    user_defined = get_user_defined_upper_bounds(heat, scrap_mix_order)
    summing_limits = get_summing_limit_constraints(heat, scrap_mix_order, mix_mapping)

    return join_constraints([dummy_constraint, user_defined, summing_limits])


@lru_cache(maxsize=32)
def get_optimization_upper_bounds_for_all_heats(input_data: MultipleHeatsOptimizationInput) -> Constraint:
    """
    In optimization, i.e. in the `core_optimization` function we use upper bounds
    subtracted with lower bounds, thus throughout the optimization we use 2 types of upper bounds
    - one type of upper bounds are provided by user or defined in settings and the other type,
    "altered" upper bounds are used in optimization.
    """
    settings = input_data.model_settings.optimizer_settings

    blocks = []
    vectors = []

    scrap_mix_order = get_available_scrap_mixes(input_data)
    for heat in input_data.heats:
        heat_constraints = get_optimization_upper_bounds_for_one_heat(
            heat,
            scrap_mix_order,
            settings.scrap_mix_mapping,
        )
        blocks.append(heat_constraints.coef_matrix)
        vectors.append(heat_constraints.values_vector)

    return Constraint(block_diag(*blocks), np.concatenate(vectors))


def add_weight_to_blend_model_input(
    reference: ScrapBlendModelInput,
    weight_to_add: float,
    scrap_mix: ScrapMix,
    scrap_mix_mapping: ScrapMixMapping,
) -> ScrapBlendModelInput:
    if scrap_mix not in scrap_mix_mapping and scrap_mix not in SUPPORTED_SCRAP_TYPES_AS_MIXES:
        raise ValueError(
            f"Scrap mix: {scrap_mix} is neither valid scrap type nor is not in scrap mix mapping."
        )
    new_weights = {**reference.scrap_weights, scrap_mix: weight_to_add}
    return attr.evolve(reference, scrap_weights=new_weights)


def get_reference_blend_model_input(
    heat_input: HeatInputs, scrap_mix_mapping: ScrapMixMapping
) -> ScrapBlendModelInput:
    reference = ScrapBlendModelInput(
        heat_input.pig_iron_weight, heat_input.pig_iron_chem, {}, 0, 0, scrap_mix_mapping  # type: ignore
    )
    for scrap_mix, weight in heat_input.lower_bounds.items():
        reference = add_weight_to_blend_model_input(reference, weight, scrap_mix, scrap_mix_mapping)
    return reference


@lru_cache(maxsize=1024)
def get_unit_chem_weights(
    settings: ModelSettings, heat_input: HeatInputs, scrap_mixes: ScrapMixOrder
) -> Dict[Chem, Dict[ScrapMix, float]]:
    blend_model, _, _, _ = get_all_models_from_model_settings(settings)
    zero_input = get_reference_blend_model_input(heat_input, settings.optimizer_settings.scrap_mix_mapping)

    approx_constant = min(
        CHEM_UNIT_WEIGHT_APPROX_WEIGHT, heat_input.total_scrap_weight - zero_input.scrap_weight
    )
    constant_inputs = [
        add_weight_to_blend_model_input(
            zero_input, approx_constant, scrap_mix, settings.optimizer_settings.scrap_mix_mapping
        )
        for scrap_mix in scrap_mixes
    ]
    blend_model_outputs = blend_model.calculate_batch(constant_inputs + [zero_input])
    constant_outputs, zero_output = blend_model_outputs[:-1], blend_model_outputs[-1]

    all_chems = {}
    for chem in blend_model.SUPPORTED_CHEMS:
        all_chems[chem] = {
            scrap_mix: chem_in_scrap_approx_from_blend_model_result_diff(
                zero_output,
                constant_output,
                zero_input.total_input_weight,
                approx_constant,
                CHEM_UNIT_WEIGHT_APPROX_PERCENTILE,
                chem,
            )
            for constant_output, scrap_mix in zip(constant_outputs, scrap_mixes)
        }

    return all_chems


@lru_cache(maxsize=1024)
def get_remaining_chem_weights(
    settings: ModelSettings,
    heat_input: HeatInputs,
    approx_percentile: float,
) -> Dict[Chem, float]:
    blend_model, _, _, _ = get_all_models_from_model_settings(settings)
    reference_input = get_reference_blend_model_input(
        heat_input, settings.optimizer_settings.scrap_mix_mapping
    )
    reference_output = blend_model.calculate(reference_input)
    final_wanted_weight = heat_input.pig_iron_weight + heat_input.total_scrap_weight

    return remaining_chem_weights(
        reference_output,
        reference_input.total_input_weight,
        final_wanted_weight,
        heat_input.grade_planned,
        blend_model.SUPPORTED_CHEMS,
        approx_percentile,
    )


@lru_cache(maxsize=1024)
def get_chem_constraints(input_data: MultipleHeatsOptimizationInput, scaled: bool = False) -> Constraint:
    settings = input_data.model_settings
    available_scrap_mixes = get_available_scrap_mixes(input_data)
    available_scrap_mixes_count = len(available_scrap_mixes)
    heat_count = len(input_data.heats)

    all_coefs = []
    all_values = []
    for i, heat in enumerate(input_data.heats):
        chems_approx = get_unit_chem_weights(settings, heat, available_scrap_mixes)
        remaining_weights = get_remaining_chem_weights(settings, heat, CHEM_UNIT_WEIGHT_APPROX_PERCENTILE)
        for chem in settings.supported_chems:
            chem_approx = chems_approx[chem]
            all_coefs.append(
                np.concatenate(
                    [
                        np.zeros(i * available_scrap_mixes_count),
                        np.array(
                            [
                                (
                                    unit_chem_weight_scaler(chem_approx[scrap_mix], chem)
                                    if scaled
                                    else chem_approx[scrap_mix]
                                )
                                for scrap_mix in available_scrap_mixes
                            ]
                        ),
                        np.zeros((heat_count - 1 - i) * available_scrap_mixes_count),
                    ]
                )
            )
            all_values.append(remaining_weights[chem])
    return Constraint(np.array(all_coefs), np.array(all_values))


def join_constraints(constraints: Collection[Constraint]) -> Constraint:
    if not constraints:
        return Constraint(np.array([]), np.array([]))
    non_empty_constraints = [c for c in constraints if len(c.values_vector) > 0]
    return Constraint(
        np.vstack([c.coef_matrix for c in non_empty_constraints]),
        np.concatenate([c.values_vector for c in non_empty_constraints]),
    )


def get_first_heat_weight_penalty_calculator(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[ScrapCharge], float]:
    first_heat = input_data.heats[0]
    total_scrap_weight = first_heat.total_scrap_weight
    settings = input_data.model_settings.optimizer_settings
    available_scrap_mixes = get_available_scrap_mixes(input_data)
    summing_limits = first_heat.relaxable_upper_summing_limits + first_heat.relaxable_lower_summing_limits
    upper_bound_calculator = get_active_upper_bound_calculator(input_data)
    upper_bounds = {
        scrap_mix: upper_bound_calculator(first_heat, scrap_mix) for scrap_mix in available_scrap_mixes
    }
    lower_bounds = {
        scrap_mix: first_heat.lower_bounds.get(scrap_mix, 0.0) for scrap_mix in available_scrap_mixes
    }
    min_loadable = {
        scrap_mix: settings.get_minimal_loadable_scrap_mix_weight(scrap_mix)
        for scrap_mix in available_scrap_mixes
    }

    def lower_bounds_penalty(result: ScrapCharge) -> float:
        return sum(max(0, lower_bounds.get(scrap_mix, 0) - weight) for scrap_mix, weight in result.items())

    def upper_bounds_penalty(result: ScrapCharge) -> float:
        return sum(
            max(0, weight - upper_bounds.get(scrap_mix, total_scrap_weight))
            for scrap_mix, weight in result.items()
        )

    def min_loadable_penalty(result: ScrapCharge) -> float:
        return sum(
            max(0, min_loadable.get(scrap_mix, 0) - weight)
            for scrap_mix, weight in result.items()
            if weight > 0
        )

    def relaxable_summing_limit_penalty(result: ScrapCharge) -> float:
        summing_limit_count = len(summing_limits)
        if summing_limit_count == 0:
            return 0.0

        penalty_sum = 0.0
        for limit in summing_limits:
            scrap_mixes = get_affected_scrap_mixes(
                available_scrap_mixes, settings.scrap_mix_mapping, limit.scrap_types
            )
            applicable_scrap_weight = sum(result.get(scrap_mix, 0.0) for scrap_mix in scrap_mixes)
            weight_limit = limit.get_effective_weight_limit(total_scrap_weight)
            if isinstance(limit, RelaxableUpperSummingLimit):
                penalty_sum += max(0, applicable_scrap_weight - weight_limit)
            else:
                penalty_sum += max(0, weight_limit - applicable_scrap_weight)

        return penalty_sum / summing_limit_count

    def weight_penalty(result: ScrapCharge) -> float:
        return (
            lower_bounds_penalty(result)
            + upper_bounds_penalty(result)
            + min_loadable_penalty(result)
            + relaxable_summing_limit_penalty(result)
        )

    return weight_penalty


def get_first_heat_ct_risk_calculator(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[ScrapCharge], float]:
    first_heat = input_data.heats[0]
    model_settings = input_data.model_settings
    limit = first_heat.relaxable_risk_limit
    ct_risk_allowed_limits = np.array(
        [getattr(limit, chem).allowed for chem in model_settings.supported_chems]
    )

    def ct_risk_penalty(result: ScrapCharge) -> float:
        expected_risk = np.array(
            [get_ct_risk(result, chem, first_heat, model_settings) for chem in model_settings.supported_chems]
        )
        return max(0, max(expected_risk - ct_risk_allowed_limits))

    return ct_risk_penalty


def get_postprocessor(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[ScrapCharge], ScrapCharge]:
    precision = input_data.model_settings.optimizer_settings.precision_step
    first_heat_penalty_calculator = get_first_heat_weight_penalty_calculator(input_data)
    first_heat_ct_risk_calculator = get_first_heat_ct_risk_calculator(input_data)

    def postprocess_first_heat_result(result: ScrapCharge) -> ScrapCharge:
        scrap_order = tuple(result.keys())

        result_vec = np.array(vectorize_scrap_weights(scrap_order, Map(result)))
        # Potentially we can have too many combinations here what can lead to long optimization
        # therefore we limit them to first n values
        potential_results = islice(
            get_simple_integer_approximations(result_vec, precision), MAX_TESTED_COMBINATIONS_POSTPROCESSING
        )
        best_result = min(
            potential_results,
            key=lambda vec: (
                first_heat_ct_risk_calculator(Map(reverse_vectorize(scrap_order, tuple(vec), 0))),
                first_heat_penalty_calculator(Map(reverse_vectorize(scrap_order, tuple(vec), 0))),
                norm(abs(vec - result_vec)),
            ),
        )

        return Map(
            {
                scrap_type: weight
                for scrap_type, weight in reverse_vectorize(scrap_order, tuple(best_result), 0).items()
                if weight > 0
            }
        )

    return postprocess_first_heat_result


@lru_cache(maxsize=32)
def get_result_processor(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[np.ndarray], List[ScrapCharge]]:
    lower_bound_vector = get_per_heat_lower_bounds_vector(input_data)
    available_scrap_mixes = get_available_scrap_mixes(input_data)
    available_scrap_mixes_count = len(available_scrap_mixes)

    def processor(result: np.ndarray) -> List[ScrapCharge]:
        scrap_matrix = (result + lower_bound_vector).reshape(-1, available_scrap_mixes_count)
        return [Map(reverse_vectorize(available_scrap_mixes, scrap, 0.0)) for scrap in scrap_matrix]

    return processor


# Step is approximated minimal weight [kg] of chem when removing one ton of scrap
CHEM_STEP_VALUES = {"Cr": 0.1, "Cu": 0.05, "Mo": 0.01, "Ni": 0.05, "S": 0.05, "Sn": 0.02, "Si": 0.02}


@lru_cache(maxsize=1024)
def get_core_chem_step_vector(settings: ModelSettings) -> np.ndarray:
    return np.array([CHEM_STEP_VALUES.get(chem, 0.01) for chem in settings.supported_chems])


@lru_cache(maxsize=1024)
def get_chem_step_vector(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    return np.concatenate([get_core_chem_step_vector(input_data.model_settings)] * input_data.heat_count)


# TODO think about moving this to model settings
@lru_cache(maxsize=1024)
def get_core_max_undesirable_corr_tech_proba_vector(
    relaxable_risk_limit: RelaxableRiskLimit, settings: ModelSettings
) -> np.ndarray:
    return np.array([relaxable_risk_limit.get_relaxed_value(chem) for chem in settings.supported_chems])


@lru_cache(maxsize=1024)
def get_max_undesirable_corr_tech_proba_vector(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    return np.concatenate(
        [
            get_core_max_undesirable_corr_tech_proba_vector(
                heat.relaxable_risk_limit, input_data.model_settings
            )
            for heat in input_data.heats
        ]
    )


@lru_cache(maxsize=1024)
def get_ignored_limits_vector_for_grade(grade: Grade, settings: ModelSettings) -> np.ndarray:
    ignored_chems = settings.get_ignored_chems(grade)
    return np.array([chem in ignored_chems for chem in settings.supported_chems])


@lru_cache(maxsize=1024)
def get_ignored_limits_vector(input_data: MultipleHeatsOptimizationInput) -> np.ndarray:
    return np.concatenate(
        [
            get_ignored_limits_vector_for_grade(heat.grade_planned, input_data.model_settings)
            for heat in input_data.heats
        ]
    )


@attr.s(frozen=True)
class OptimizationResultEvaluation:
    full_undesirable_ct_probas: np.ndarray = attr.ib()
    per_chem_undesirable_ct_probas: np.ndarray = attr.ib()
    total_chem_weight: np.ndarray = attr.ib()
    total_sulphur: float = attr.ib()
    result = attr.ib()

    def biggest_violator(self, max_undesirable_vector: np.ndarray) -> float:
        return (self.per_chem_undesirable_ct_probas - max_undesirable_vector).max()

    def is_valid(
        self, max_undesirable_vector: np.ndarray, ignored_limits: np.ndarray, tolerance: float = 0.001
    ) -> bool:
        lower_than_limit = self.per_chem_undesirable_ct_probas < (max_undesirable_vector + tolerance)
        return (lower_than_limit | ignored_limits).all()

    def is_better_than(
        self, other: Optional["OptimizationResultEvaluation"], input_data: MultipleHeatsOptimizationInput
    ) -> bool:
        if other is None:
            return True
        max_undesirable_vector = get_max_undesirable_corr_tech_proba_vector(input_data)
        ignored_limits = get_ignored_limits_vector(input_data)
        other_valid = other.is_valid(max_undesirable_vector, ignored_limits)
        self_valid = self.is_valid(max_undesirable_vector, ignored_limits)
        if self_valid and not other_valid:
            return True
        if not self_valid and other_valid:
            return False
        if not self_valid and not other_valid:
            return self.biggest_violator(max_undesirable_vector) < other.biggest_violator(
                max_undesirable_vector
            )
        if not optimization_mode_best(input_data):
            return self.total_sulphur > other.total_sulphur
        raise ValueError(
            "Best mode optimization is a simple LP task and should not be dependent on iterative result evaluation."
        )


def get_corr_tech_model_input_creator(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[np.ndarray], List[CorrectionTechnologiesModelInput]]:
    blend_model, _, _, _ = get_all_models_from_model_settings(input_data.model_settings)
    mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping
    processor = get_result_processor(input_data)
    heats = input_data.heats

    def ctmi_creator(scrap_matrix: np.ndarray) -> List[CorrectionTechnologiesModelInput]:
        bmis = [
            ScrapBlendModelInput(
                heat.pig_iron_weight,
                heat.pig_iron_chem,
                scrap_weights=scrap,
                pellets_weight=0,
                briquetes_weight=0,
                scrap_mix_mapping=mix_mapping,  # type: ignore
            )
            for heat, scrap in zip(heats, processor(scrap_matrix))
        ]
        return [
            CorrectionTechnologiesModelInput(heat.grade_planned, bmo)
            for heat, bmo in zip(heats, blend_model.calculate_batch(bmis))
        ]

    return ctmi_creator


def get_undesirable_ct_probas(
    model: CorrectionTechnologiesModel, inputs: List[CorrectionTechnologiesModelInput]
) -> List[float]:
    return [cmo.undesirable_corr_tech_proba for cmo in model.calculate_batch_for_multiple_grades(inputs)]


@lru_cache(maxsize=128)
def get_optimization_result_evaluator(
    input_data: MultipleHeatsOptimizationInput,
) -> Callable[[OptimizeResult], OptimizationResultEvaluation]:
    chem_matrix = get_chem_constraints(input_data).coef_matrix
    cmi_creator = get_corr_tech_model_input_creator(input_data)
    _, _, _, corr_tech_model = get_all_models_from_model_settings(input_data.model_settings)
    corr_tech_settings = input_data.model_settings.correction_technologies_settings
    used_chems = input_data.model_settings.supported_chems
    corr_tech_models_per_chem = [
        get_corr_tech_model(corr_tech_settings.version, (chem,)) for chem in used_chems
    ]

    def evaluate_result(result: OptimizeResult) -> OptimizationResultEvaluation:
        total_chem = chem_matrix.dot(result.x)
        total_sulphur = -1 * result.fun
        cmis = cmi_creator(result.x)
        full_undesirable_ct_probas = np.array(get_undesirable_ct_probas(corr_tech_model, cmis))
        per_chem_undesirable_ct_probas = np.array(
            [get_undesirable_ct_probas(model, cmis) for model in corr_tech_models_per_chem]
        ).T.reshape(-1)
        return OptimizationResultEvaluation(
            full_undesirable_ct_probas,
            per_chem_undesirable_ct_probas,
            total_chem,
            total_sulphur,
            result,
        )

    return evaluate_result


@attr.s(slots=True, frozen=True)
class StandardOptimizationState:
    best_evaluation: Optional[OptimizationResultEvaluation] = attr.ib()
    best_result: Optional[OptimizeResult] = attr.ib()
    last_working_evaluation: Optional[OptimizationResultEvaluation] = attr.ib()
    last_working_limits: np.ndarray = attr.ib()
    current_limits: np.ndarray = attr.ib()
    # Iterations from optimization start
    optimization_step: int = attr.ib()
    state_type: str = attr.ib()


def update_limits_by_grad(
    input_data: MultipleHeatsOptimizationInput,
    state: StandardOptimizationState,
    new_evaluation: OptimizationResultEvaluation,
) -> np.ndarray:
    max_undesirable_vector = get_max_undesirable_corr_tech_proba_vector(input_data)
    chem_step_vector = get_chem_step_vector(input_data)
    ignored_chem_limits = get_ignored_limits_vector(input_data)
    max_step = 32 * chem_step_vector

    not_used_limits = np.isposinf(state.last_working_limits)
    used_limits = ~not_used_limits
    better_than_limit = (new_evaluation.per_chem_undesirable_ct_probas <= max_undesirable_vector) | (
        ignored_chem_limits
    )
    worse_than_limit = ~better_than_limit

    chem_minus_step = new_evaluation.total_chem_weight - chem_step_vector
    chem_plus_step = state.current_limits + chem_step_vector

    if state.last_working_evaluation is not None:
        weight_change = state.last_working_evaluation.total_chem_weight - new_evaluation.total_chem_weight
        uct_probas_change = (
            state.last_working_evaluation.per_chem_undesirable_ct_probas
            - new_evaluation.per_chem_undesirable_ct_probas
        )
        needed_probas_change = max_undesirable_vector - new_evaluation.per_chem_undesirable_ct_probas
        # replace 0s with non-zero small value
        uct_probas_change[uct_probas_change == 0] = 1e-10
        grad = (weight_change * needed_probas_change) / uct_probas_change
        calculated_change = np.select(
            [grad < -max_step, (grad >= -max_step) & (grad <= max_step), grad > max_step],
            # calculate change as combination of grad and max_step to make sure,
            # that convergence is fast enough even in case when grad >> max_step
            [grad * 0.2 - max_step * 0.8, grad, max_step * 0.8 + grad * 0.2],
        )
    else:
        calculated_change = -chem_step_vector

    new_limits_worse = new_evaluation.total_chem_weight + calculated_change
    new_limits_better = state.current_limits + calculated_change

    grad_less_than_zero = calculated_change < 0

    return np.select(
        [
            better_than_limit & not_used_limits,
            worse_than_limit & not_used_limits,
            better_than_limit & used_limits,
            worse_than_limit & used_limits,
        ],
        [
            state.current_limits,
            chem_minus_step,
            np.select([grad_less_than_zero, ~grad_less_than_zero], [chem_plus_step, new_limits_better]),
            np.select([grad_less_than_zero, ~grad_less_than_zero], [new_limits_worse, chem_minus_step]),
        ],
    )


def evolve_state_with_new_best_result(
    input_data: MultipleHeatsOptimizationInput,
    old_state: StandardOptimizationState,
    new_best_result: OptimizeResult,
    new_best_evaluation: OptimizationResultEvaluation,
) -> StandardOptimizationState:
    return attr.evolve(
        old_state,
        best_evaluation=new_best_evaluation,
        best_result=new_best_result,
        last_working_evaluation=new_best_evaluation,
        last_working_limits=old_state.current_limits,
        current_limits=update_limits_by_grad(input_data, old_state, new_best_evaluation),
        optimization_step=old_state.optimization_step + 1,
        state_type="New best",
    )


def evolve_state_without_best_result(
    input_data: MultipleHeatsOptimizationInput,
    old_state: StandardOptimizationState,
    new_evaluation: OptimizationResultEvaluation,
) -> StandardOptimizationState:
    return attr.evolve(
        old_state,
        last_working_evaluation=new_evaluation,
        last_working_limits=old_state.current_limits,
        current_limits=update_limits_by_grad(input_data, old_state, new_evaluation),
        optimization_step=old_state.optimization_step + 1,
        state_type="Without best",
    )


def evolve_state_without_result(old_state: StandardOptimizationState) -> StandardOptimizationState:
    if old_state.last_working_limits is not None:
        new_chem_limits = (old_state.last_working_limits + old_state.current_limits) / 2
    else:
        new_chem_limits = old_state.current_limits
    return attr.evolve(
        old_state,
        current_limits=new_chem_limits,
        optimization_step=old_state.optimization_step + 1,
        state_type="Without result",
    )


ProgressCallback = Callable[[float, str], None]
RelaxerProgressCallback = Callable[[int, str], None]
DebugCallback = Callable[[StandardOptimizationState, Optional[OptimizationResultEvaluation]], None]


def get_initial_optimization_state(input_data: MultipleHeatsOptimizationInput) -> StandardOptimizationState:
    # TODO remove chem constraints
    chem_constraints = get_chem_constraints(input_data).values_vector
    mean_scrap_weight = input_data.heats[0].total_scrap_weight
    return StandardOptimizationState(
        None,
        None,
        None,
        np.ones_like(chem_constraints) * mean_scrap_weight * input_data.heat_count,
        np.ones_like(chem_constraints) * mean_scrap_weight * input_data.heat_count,
        0,
        "Initial",
    )


def remove_infinites(constraint: Constraint) -> Constraint:
    # TODO change to posinf only
    not_infinites = np.isfinite(constraint.values_vector)
    return Constraint(constraint.coef_matrix[not_infinites, :], constraint.values_vector[not_infinites])


# TODO one heat mode when everything fails
# TODO find best constants
def core_optimization(
    input_data: MultipleHeatsOptimizationInput, state: StandardOptimizationState
) -> OptimizeResult:
    objective_function = get_objective_function(input_data)
    eq_constraints = get_per_heat_ordered_weight_constraint(input_data)
    lt_constraints = remove_infinites(
        join_constraints(
            [
                get_global_scrap_upper_bounds(input_data),
                get_optimization_upper_bounds_for_all_heats(input_data),
                attr.evolve(get_chem_constraints(input_data), values_vector=state.current_limits),
            ]
        )
    )
    return linprog(
        objective_function,
        A_ub=lt_constraints.coef_matrix,
        b_ub=lt_constraints.values_vector,
        A_eq=eq_constraints.coef_matrix,
        b_eq=eq_constraints.values_vector,
        # options={"disp": True},
        method="highs",
    )


def is_final(state: StandardOptimizationState, input_data: MultipleHeatsOptimizationInput) -> bool:
    if state.optimization_step == 0:
        return False
    min_step_size = get_chem_step_vector(input_data) / 2
    optimization_mode = input_data.model_settings.optimizer_settings.optimization_mode
    limit_change = np.nan_to_num(
        abs(state.last_working_limits - state.current_limits), nan=0.0, posinf=np.inf, neginf=np.inf
    )
    return (
        (limit_change < min_step_size).all()
        or (state.optimization_step > 100)
        or (
            optimization_mode == "Best" and state.optimization_step == 1
        )  # Best mode optimization is a single-optimization-step LP task without any custom gradient update
    )


def iterative_optimization(
    input_data: MultipleHeatsOptimizationInput,
    state: StandardOptimizationState,
    debug_callback: DebugCallback,
) -> StandardOptimizationState:
    if is_final(state, input_data):
        debug_callback(state, None)
        return state
    result = core_optimization(input_data, state)
    if result.success:
        evaluation = get_optimization_result_evaluator(input_data)(result)
        debug_callback(state, evaluation)
        if evaluation.is_better_than(state.best_evaluation, input_data):
            return iterative_optimization(
                input_data,
                evolve_state_with_new_best_result(input_data, state, result, evaluation),
                debug_callback,
            )
        return iterative_optimization(
            input_data, evolve_state_without_best_result(input_data, state, evaluation), debug_callback
        )
    debug_callback(state, None)
    return iterative_optimization(input_data, evolve_state_without_result(state), debug_callback)


def one_heat_worst_mode_relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
    return attr.evolve(
        input_data,
        heats=(input_data.heats[0],),
        model_settings=attr.evolve(
            input_data.model_settings,
            optimizer_settings=attr.evolve(
                input_data.model_settings.optimizer_settings, optimization_mode="Worst"
            ),
        ),
    )


def best_mode_relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
    return attr.evolve(
        input_data,
        model_settings=attr.evolve(
            input_data.model_settings,
            optimizer_settings=attr.evolve(
                input_data.model_settings.optimizer_settings, optimization_mode="Best"
            ),
        ),
    )


def get_relaxation_progress_callback(
    total_relaxers_count: int, orig_callback: Optional[ProgressCallback]
) -> RelaxerProgressCallback:
    def progress_callback(remaining_relaxers_count: int, relaxer_name: str):
        if orig_callback is not None:
            orig_callback(
                ((total_relaxers_count - remaining_relaxers_count) / (total_relaxers_count + 1)) * 100,
                relaxer_name,
            )

    return progress_callback


def get_debug_callback(maybe_callback: Optional[DebugCallback]) -> DebugCallback:
    if maybe_callback is not None:
        return maybe_callback

    def dummy_callback(
        state: StandardOptimizationState,  # pylint: disable=unused-argument
        evaluation: Optional[OptimizationResultEvaluation],  # pylint: disable=unused-argument
    ):
        pass

    return dummy_callback


def has_valid_result(input_data: MultipleHeatsOptimizationInput, state: StandardOptimizationState) -> bool:
    if state.best_evaluation is None:
        return False
    return state.best_evaluation.is_valid(
        get_max_undesirable_corr_tech_proba_vector(input_data), get_ignored_limits_vector(input_data)
    )


# TODO refactor code so that `relaxed_input_data` are not needed anymore
def optim_state_to_optim_output(
    orig_input_data: MultipleHeatsOptimizationInput,
    relaxed_input_data: MultipleHeatsOptimizationInput,
    state: StandardOptimizationState,
) -> MultipleHeatsOptimizationOutput:
    settings = orig_input_data.model_settings
    fh = orig_input_data.heats[0]

    if state.best_result is None:
        return MultipleHeatsOptimizationOutput("Cannot find result with current limits")
    postprocessor = get_postprocessor(orig_input_data)
    scrap_dicts = get_result_processor(relaxed_input_data)(state.best_result.x)
    post_processed_scraps = postprocessor(scrap_dicts[0])
    final_dicts = [
        post_processed_scraps,
    ] + scrap_dicts[1:]
    return MultipleHeatsOptimizationOutput(
        error=None,
        first_heat_expected_risk=get_expected_risk_levels(post_processed_scraps, fh, settings),
        scrap_weights_per_heat=tuple(Map(x) for x in final_dicts),
    )


def optimize_with_relaxation(
    input_data: MultipleHeatsOptimizationInput,
    remaining_relaxers: Relaxers,
    progress_callback: RelaxerProgressCallback,
    debug_callback: DebugCallback,
) -> Tuple[MultipleHeatsOptimizationInput, StandardOptimizationState]:
    final_state = iterative_optimization(
        input_data, get_initial_optimization_state(input_data), debug_callback
    )

    if not has_valid_result(input_data, final_state) and remaining_relaxers:
        next_relaxer = remaining_relaxers[0]
        progress_callback(len(remaining_relaxers) - 1, next_relaxer.__name__)
        return optimize_with_relaxation(
            next_relaxer(input_data), remaining_relaxers[1:], progress_callback, debug_callback
        )
    return input_data, final_state


def validate_first_heat_scrap_bounds(input_data: MultipleHeatsOptimizationInput) -> None:
    available_scraps = tuple(
        [
            AvailableScrap(scrap_type=scrap_type, weight=weight)
            for scrap_type, weight in input_data.upper_bounds.items()
        ]
    )
    available_scrap_types = list(input_data.upper_bounds)
    first_heat = input_data.heats[0]
    relaxable_lower_summing_limits = first_heat.relaxable_lower_summing_limits
    relaxable_upper_summing_limits = first_heat.relaxable_upper_summing_limits
    errors, _ = validate_scrap_limits(
        tuple(
            ScrapMixLimit(
                scrap_type=scrap_type,
                minimum=first_heat.lower_bounds.get(scrap_type, 0),
                maximum=first_heat.upper_bounds.get(scrap_type, first_heat.total_scrap_weight),
            )
            for scrap_type in available_scrap_types
        ),
        first_heat.total_scrap_weight,
        available_scraps,
        relaxable_lower_summing_limits,
        relaxable_upper_summing_limits,
        first_heat.grade_planned.grade_id,
        input_data.model_settings.optimizer_settings.scrap_mix_mapping,
    )
    if errors:
        raise ValueError(str(errors))


def validate_scrap_bounds(input_data: MultipleHeatsOptimizationInput) -> None:
    for idx, heat in enumerate(input_data.heats[1:]):
        invalid = [
            scrap_type
            for scrap_type in set(heat.lower_bounds) | set(heat.upper_bounds) | set(input_data.upper_bounds)
            if min(
                heat.upper_bounds.get(scrap_type, heat.total_scrap_weight),
                input_data.upper_bounds.get(scrap_type, 0),
            )
            < heat.lower_bounds.get(scrap_type, 0)
        ]
        if invalid:
            raise ValueError(f"Heat ({idx}) has invalid bounds for following scrap types: {invalid}")


ScrapMixExclusiveGroup = Tuple[ScrapMix, ...]


def expand_tupled_derived_group(group: Sequence[Union[ScrapMix, ScrapMixOrder]]) -> List[ScrapMixOrder]:
    """Expand derived group with tuples into multiple groups without tuples."""
    single_scrap_mixes = tuple(scrap_mix for scrap_mix in group if isinstance(scrap_mix, str))
    composite_scrap_mixes = [scrap_mix for scrap_mix in group if isinstance(scrap_mix, tuple)]
    composite_scrap_mixes_combinations = list(itertools.product(*composite_scrap_mixes))
    return [
        tuple(sorted(combination + single_scrap_mixes)) for combination in composite_scrap_mixes_combinations
    ]


def get_derived_groups(
    mix_mapping: ScrapMixMapping,
    group: ScrapExclusiveGroup,
    available_composite_scrap_mix_combination: ScrapMixOrder,
) -> List[ScrapMixOrder]:
    mix_mapping_for_combination = {
        k: tuple(v.keys()) for k, v in mix_mapping.items() if k in available_composite_scrap_mix_combination
    }
    tupled_derived_group: List[Union[ScrapMix, ScrapMixOrder]] = []
    for group_scrap_mix in group.scrap_types:
        affected_available_composite_scrap_mixes = tuple(
            mix for mix, mapping in mix_mapping_for_combination.items() if group_scrap_mix in mapping
        )
        if not affected_available_composite_scrap_mixes:
            tupled_derived_group.append(group_scrap_mix)
        else:
            tupled_derived_group.append(affected_available_composite_scrap_mixes)
    if set(tupled_derived_group) != set(group.scrap_types):
        expanded_derived_groups = expand_tupled_derived_group(tupled_derived_group)
        return expanded_derived_groups
    return []


def get_active_derived_scrap_exclusive_groups(
    input_data: MultipleHeatsOptimizationInput,
) -> ScrapExclusiveGroups:
    """
    For each active original exclusive group which does not have any composite mix member (user-defined groups cannot include composite mixes), calculation of derived groups is as follows:
    1. Take one available composite scrap mixes combination
    2. Check each member of given exclusive group and replace it with the subset of composite scrap
       mixes combination affected by the member. If the subset is empty, given member of exclusive group is left unchanged. This results in so-called tupled derived group as some of its members are tuples.
    3. Expand tupled derived group into proper derived exclusive groups (see expand_tupled_derived_group func)
    4. Repeat until all composite scrap mixes combinations are processed
    """
    available_scrap_mixes = get_available_scrap_mixes(input_data)
    active_original_scrap_exclusive_groups = get_active_original_scrap_exclusive_groups(input_data)
    mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping
    available_composite_scrap_mixes = tuple(mix for mix in available_scrap_mixes if mix in mix_mapping)
    available_composite_scrap_mixes_combinations = powerset(available_composite_scrap_mixes, empty=False)

    output_groups: List[ScrapMixOrder] = []
    for group in active_original_scrap_exclusive_groups:
        if group.has_composite_mix(mix_mapping):
            continue
        for available_composite_scrap_mix_combination in available_composite_scrap_mixes_combinations:
            derived_groups = get_derived_groups(mix_mapping, group, available_composite_scrap_mix_combination)
            output_groups.extend(derived_groups)
    return tuple(ScrapExclusiveGroup("Derived:" + "-".join(group), group) for group in set(output_groups))


def get_active_original_scrap_exclusive_groups(
    input_data: MultipleHeatsOptimizationInput,
) -> ScrapExclusiveGroups:
    available_scrap_mixes = get_available_scrap_mixes(input_data)
    forced_scrap_mixes = first_heat_forced_scrap_mixes(input_data)
    mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping
    original_exclusive_groups = input_data.model_settings.optimizer_settings.scrap_exclusive_groups

    return tuple(
        group
        for group in original_exclusive_groups
        if group.is_active(available_scrap_mixes, forced_scrap_mixes, mix_mapping)
    )


ConditionedScrapOptimizationOutputs = List[
    Tuple[MultipleHeatsOptimizationInput, MultipleHeatsOptimizationOutput]
]


def evaluate_conditioned_scrap_optimization_outputs(
    outputs: ConditionedScrapOptimizationOutputs,
) -> MultipleHeatsOptimizationOutput:
    if not all(res.error is not None for _, res in outputs):
        _, best_res = min(
            ((input_data, res) for input_data, res in outputs if res.error is None),
            key=lambda item: expected_ct_risk_deviation(item[0], item[1].scrap_weights_per_heat),
        )
        return best_res
    else:
        return MultipleHeatsOptimizationOutput(
            error="Every optimization with conditioned scrap types failed: "
            + "; ".join(str(res.error) for _, res in outputs)
        )


def validate_bound_scrap_group(group: Collection[ScrapType], exclusive_groups: ScrapExclusiveGroups) -> bool:
    """
    This checks that each exclusive group is represented with exactly one member in scrap types group

    F.E.
    Exclusive 1:
    1PIT, 2PIT

    Exclusive 2:
    1PIT, MCE

    combination 1PIT, 2PIT would not be valid
    """
    # check that group have at most 1 element in common with every exclusive group
    return not any(
        len(set(exclusive_group.scrap_types) & set(group)) > 1 for exclusive_group in exclusive_groups
    )


def are_disjoint(
    scrap: Collection[ScrapMix], limit: RelaxableLowerSummingLimit, mix_mapping: ScrapMixMapping
) -> bool:
    return all(
        not (set(mix_mapping.get(scrap_mix, {scrap_mix})) & set(limit.scrap_types)) for scrap_mix in scrap
    )


# FIXME exclusive groups are not calculated per heat
# TODO create separate module - e.g. exclusive_group_utils.py - where all logic related to exclusive groups is defined
#   refactor the code to be readable (at the moment, it is not)
def get_exclusive_scrap_space(
    input_data: MultipleHeatsOptimizationInput,
) -> Tuple[ScrapMixOrder, Tuple[ScrapMixOrder, ...]]:
    """Exclusive scrap space of available scrap consists of two subspaces:
    Free  - if scrap mix is NOT present in any ACTIVE exclusive scrap group. This effectively means
            either not being present in any group at all, or present in INACTIVE exclusive scrap group
    Bound - if scrap mix is at least in one ACTIVE exclusive scrap group.

    From bound subspace, only ACTIVE scrap mixes are used for return value, along with whole free subspace
    """
    available_scrap = get_available_scrap_mixes(input_data)
    active_groups = get_active_scrap_exclusive_groups(input_data)
    forced_scrap = first_heat_forced_scrap_mixes(input_data)
    mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping

    # TODO find out why do we need forced scrap here. It is already used in get_active_scrap_exclusive_groups.
    restricted_active_groups = [
        group.get_active_scrap_mixes(available_scrap, forced_scrap, mix_mapping) for group in active_groups
    ]

    # FIXME as hotfix lower limits from the first heat are considered only
    #   refactor the code so that exclusive scrap groups (and selectors) are calculated per heat
    first_heat = input_data.heats[0]
    first_heat_lower_limits = {
        limit
        for limit in first_heat.relaxable_lower_summing_limits
        # check only relevant limits
        if not are_disjoint(first_heat.upper_bounds, limit, mix_mapping)
        and limit.get_effective_weight_limit(first_heat.total_scrap_weight) > 0
    }

    free_scrap_space = tuple(set(available_scrap) - set(union(group.scrap_types for group in active_groups)))

    bound_active_scrap_space = tuple(
        set(
            tuple(sub_selector)
            for selector in itertools.product(*restricted_active_groups)
            for sub_selector in powerset(set(selector), empty=False)
            if validate_bound_scrap_group(sub_selector, active_groups)
            # skip space (its bound sub-selector part)
            # that is not superset of user-defined lower limits
            and set(omit_zeros(first_heat.lower_bounds)).issubset(sub_selector + free_scrap_space)
            # or is disjoint with all lower limits (if there is some),
            # i.e. we do our best to fulfill at least 1 lower limit,
            # because it is not possible to fulfill 2 different lower limits about 2 exclusive scrap types
            and (
                not first_heat_lower_limits
                or not all(
                    are_disjoint(sub_selector + free_scrap_space, limit, mix_mapping)
                    for limit in first_heat_lower_limits
                )
            )
        )
    )

    return free_scrap_space, bound_active_scrap_space


def get_active_scrap_exclusive_groups(input_data: MultipleHeatsOptimizationInput) -> ScrapExclusiveGroups:
    original_active_scrap_exclusive_groups = get_active_original_scrap_exclusive_groups(input_data)
    derived_active_exclusive_groups = get_active_derived_scrap_exclusive_groups(input_data)
    return original_active_scrap_exclusive_groups + derived_active_exclusive_groups


def optimize_multiple_heats_many(
    input_data: MultipleHeatsOptimizationInput,
    progress_callback: Optional[ProgressCallback] = None,
    debug_callback: Optional[DebugCallback] = None,
) -> MultipleHeatsOptimizationOutput:
    """This is called only when at least one available scrap exclusive group for given input data exists."""
    # TODO transformation
    outputs: ConditionedScrapOptimizationOutputs = []

    free_scrap_space, bound_active_scrap_space = get_exclusive_scrap_space(input_data)
    active_groups = get_active_scrap_exclusive_groups(input_data)

    bound_space_size = len(bound_active_scrap_space)
    if bound_space_size < 32:
        log.info(f"Number of conditioned scrap mixes groups: {bound_space_size}")
    else:
        log.warning(f"Number of conditioned scrap mixes groups is too high ({bound_space_size})")

    for selector in bound_active_scrap_space:
        # collect exclusive groups and corresponding scrap types that are affecting selector
        affected_exclusive_groups = Map(
            {
                # selector and active group have at most 1 element in common
                group.name: (set(group.scrap_types) & set(selector)).pop()
                for group in active_groups
                if set(group.scrap_types) & set(selector)
            }
        )

        conditioned_scrap_types = selector + free_scrap_space
        upper_bounds = Map(
            {scrap: input_data.upper_bounds.get(scrap, 0) for scrap in conditioned_scrap_types}
        )
        conditioned_input_data = attr.evolve(input_data, upper_bounds=upper_bounds)

        output = optimize_multiple_heats_once(conditioned_input_data, progress_callback, debug_callback)
        conditioned_output_data = attr.evolve(output, conditioned_scrap_types_group=affected_exclusive_groups)
        outputs.append((conditioned_input_data, conditioned_output_data))
    return evaluate_conditioned_scrap_optimization_outputs(outputs)


def optimize_multiple_heats_once(
    input_data: MultipleHeatsOptimizationInput,
    progress_callback: Optional[ProgressCallback] = None,
    debug_callback: Optional[DebugCallback] = None,
) -> MultipleHeatsOptimizationOutput:
    try:
        validate_first_heat_scrap_bounds(input_data)
        validate_scrap_bounds(input_data)

        if input_data.heat_count == 0:
            return MultipleHeatsOptimizationOutput(error=None, scrap_weights_per_heat=())
        # TODO solve better if sum of lower limits in any heat is equal to ordered weight
        # intermediate hack for the first heat following
        first_heat = input_data.heats[0]
        if sum(first_heat.lower_bounds.values()) >= first_heat.total_scrap_weight:
            return MultipleHeatsOptimizationOutput(
                error=None,
                first_heat_expected_risk=get_expected_risk_levels(
                    first_heat.lower_bounds, first_heat, input_data.model_settings
                ),
                scrap_weights_per_heat=(first_heat.lower_bounds,),
            )

        relaxers: Relaxers = [  # type: ignore
            one_heat_worst_mode_relaxer,  # type: ignore
            *get_relaxable_limits_relaxers(relaxation_schedule=RELAXATION_SCHEDULE),
            best_mode_relaxer,  # type: ignore
        ]
        relaxation_progress_callback = get_relaxation_progress_callback(len(relaxers), progress_callback)
        relaxed_input_data, final_state = optimize_with_relaxation(
            input_data,
            relaxers,
            relaxation_progress_callback,
            get_debug_callback(debug_callback),
        )
        return optim_state_to_optim_output(input_data, relaxed_input_data, final_state)
    except Exception as e:  # pylint: disable=broad-except
        log.exception("Multiple heats optimization failed")
        return MultipleHeatsOptimizationOutput(error=str(e), scrap_weights_per_heat=())


def optimize_multiple_heats(
    input_data: MultipleHeatsOptimizationInput,
    progress_callback: Optional[ProgressCallback] = None,
    debug_callback: Optional[DebugCallback] = None,
) -> MultipleHeatsOptimizationOutput:
    active_original_scrap_exclusive_groups = get_active_original_scrap_exclusive_groups(input_data)
    # TODO maybe it is enough to use just many variant
    if active_original_scrap_exclusive_groups:
        return optimize_multiple_heats_many(input_data, progress_callback, debug_callback)
    else:
        return optimize_multiple_heats_once(input_data, progress_callback, debug_callback)


def get_s_max_str(heat: HeatInputs) -> str:
    s_limit = heat.grade_planned.get_limit("S")
    return str(s_limit.maximum) if s_limit is not None else "UNK"


def optimization_input_summary(input_data: MultipleHeatsOptimizationInput) -> str:
    lower_bounds = [{k: v for k, v in heat.lower_bounds.items() if v > 0.0} for heat in input_data.heats]
    upper_bounds = [
        {
            k: v
            for k, v in heat.upper_bounds.items()
            if v < heat.total_scrap_weight and input_data.upper_bounds.get(k, 0.0) > v
        }
        for heat in input_data.heats
    ]
    grade_ids = "\n".join(
        [
            f"{heat.grade_planned.grade_id} - S max: {get_s_max_str(heat)} "
            + f"- scrap weight: {heat.total_scrap_weight} - pig iron weight {heat.pig_iron_weight} "
            + f"- lb: {lb} ub: {ub}"
            for heat, lb, ub in zip(input_data.heats, lower_bounds, upper_bounds)
        ]
    )
    price_vector = sorted(
        reverse_vectorize(
            get_available_scrap_mixes(input_data),
            tuple(get_objective_function(input_data)[: get_available_scrap_mix_count(input_data)]),
            0.0,
        ).items(),
        key=lambda x: -x[1],
    )
    available_scrap = "\n".join(
        [
            f"{scrap_type.rjust(10)}:{price:.4f} / {input_data.upper_bounds[scrap_type]}"
            for scrap_type, price in price_vector
        ]
    )
    rows = [
        f"Heat count: {input_data.heat_count}",
        f"Grades:\n{grade_ids}\n",
        f"Scraps:\n{available_scrap}",
    ]
    return "\n".join(rows)
