# TODO Move code related to exclusive scrap groups from `linprog_optimizer.py` here
#   see https://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/517
