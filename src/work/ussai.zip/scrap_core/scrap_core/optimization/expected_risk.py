from typing import Tuple
from scrap_core import Chem, ScrapCharge
from scrap_core.modelutils import get_ct_risks
from scrap_core.optimization.datamodel import ChemRiskLevels, HeatInputs, ModelSettings
from scrap_core.optimization.relaxable_limits import RelaxableRiskLimit
from immutables import Map


def get_ct_risk_limits(
    settings: ModelSettings, limit: RelaxableRiskLimit
) -> Tuple[Map[Chem, float], Map[Chem, float]]:
    ct_risk_aim_limits = {chem: getattr(limit, chem).aim for chem in settings.supported_chems}
    ct_risk_allowed_limits = {chem: getattr(limit, chem).allowed for chem in settings.supported_chems}

    return Map(ct_risk_aim_limits), Map(ct_risk_allowed_limits)


def select_chems_by_risk(
    settings: ModelSettings, heat: HeatInputs, expected_ct_risks: Map[Chem, float]
) -> Tuple[Tuple[Chem, ...], Tuple[Chem, ...]]:
    ct_risk_aim_limits, ct_risk_allowed_limits = get_ct_risk_limits(settings, heat.relaxable_risk_limit)

    medium_risk = tuple(
        chem
        for chem in settings.supported_chems
        if ct_risk_aim_limits[chem] <= expected_ct_risks[chem] < ct_risk_allowed_limits[chem]
        and chem not in settings.get_ignored_chems(heat.grade_planned)
    )

    high_risk = tuple(
        chem
        for chem in settings.supported_chems
        if ct_risk_allowed_limits[chem] <= expected_ct_risks[chem]
        and chem not in settings.get_ignored_chems(heat.grade_planned)
    )

    return medium_risk, high_risk


def get_expected_risk_levels(
    scrap_charge: ScrapCharge, heat_data: HeatInputs, settings: ModelSettings
) -> ChemRiskLevels:
    expected_ct_risks = get_ct_risks(scrap_charge, heat_data, settings)
    return ChemRiskLevels(*select_chems_by_risk(settings, heat_data, expected_ct_risks))
