from typing import (
    Mapping,
    Protocol,
    Sequence,
    Tuple,
    ClassVar,
)
import attr

from scrap_core import ScrapType, ScrapMix, Chem, ScrapMixMapping, ScrapCharge, ScrapMixOrder
from scrap_core import get_affected_scrap_mixes


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RelaxationStep:
    risk_limits: bool
    summing_limits: bool
    # TODO will be added later
    # heat_count: bool
    # lower_limits: bool
    # exclusivity: bool


RelaxationSchedule = Tuple[RelaxationStep, ...]
SingleRelaxationSchedule = Sequence[bool]

RELAXATION_SCHEDULE: RelaxationSchedule = (
    RelaxationStep(False, True),
    RelaxationStep(False, True),
    RelaxationStep(True, True),
    RelaxationStep(True, True),
    RelaxationStep(True, False),
    RelaxationStep(True, False),
)

ACTIVE_RELAXATION_STEPS = 4

TOTAL_RELAXATION_STEPS = 2 + len(RELAXATION_SCHEDULE)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RelaxableValue:
    aim: float
    allowed: float

    def get_relaxed_value(self, relaxation_ratio: float) -> float:
        if not 0 <= relaxation_ratio <= 1:
            raise ValueError("Relaxation ratio must be between 0 and 1")
        diff = self.allowed - self.aim
        return self.aim + (diff * relaxation_ratio)


def relaxable_value_aim_minimum_validator(minimum: float):
    def validator(_, attribute_type, value):
        if value.aim < minimum:
            raise ValueError(
                f"{attribute_type.name} aim is {value} but it must be larger or equal than {minimum}"
            )

    return validator


def relaxable_value_aim_maximum_validator(maximum: float):
    def validator(_, attribute_type, value):
        if value.aim > maximum:
            raise ValueError(
                f"{attribute_type.name} aim is {value} but it must be smaller or equal than {maximum}"
            )

    return validator


def relaxable_value_allowed_minimum_validator(minimum: float):
    def validator(_, attribute_type, value):
        if value.allowed < minimum:
            raise ValueError(
                f"{attribute_type.name} allowed is {value} but it must be larger or equal than {minimum}"
            )

    return validator


def relaxable_value_allowed_maximum_validator(maximum: float):
    def validator(_, attribute_type, value):
        if value.allowed > maximum:
            raise ValueError(
                f"{attribute_type.name} allowed is {value} but it must be smaller or equal than {maximum}"
            )

    return validator


def relaxable_value_order_validator(lower_is_better: bool):
    def validator(_, attribute_type, value):
        if lower_is_better:
            if value.aim > value.allowed:
                raise ValueError(f"{attribute_type.name} aim is larger than allowed but lower is better")
        else:
            if value.aim < value.allowed:
                raise ValueError(f"{attribute_type.name} aim is smalled than allowed but higher is better")

    return validator


def relaxable_value_disabled_validator(instance, attribute, value):
    if value.aim < value.allowed and 1 <= value.allowed:
        raise ValueError(
            f"{attribute.name} - disabled relaxable value must have both aim and allowed set to 1"
        )


def relaxation_step_between_zero_and_n_steps(instance, _, value):
    if value > instance.n_steps:
        raise ValueError("Relaxation step can't be greater than n_steps.")
    if value < 0:
        raise ValueError("Relaxation step can't be negative.")


RELAXABLE_VALUE_BETWEEN_0_1_VALIDATOR = [
    relaxable_value_aim_minimum_validator(0),
    relaxable_value_aim_maximum_validator(1),
    relaxable_value_allowed_minimum_validator(0),
    relaxable_value_allowed_maximum_validator(1),
]

RELAXABLE_CHEM_RISK_VALIDATOR = RELAXABLE_VALUE_BETWEEN_0_1_VALIDATOR + [
    relaxable_value_order_validator(True),
    relaxable_value_disabled_validator,
]

RELAXABLE_UPPER_LIMIT_WEIGHT_VALIDATOR = [
    relaxable_value_aim_minimum_validator(0),
    relaxable_value_allowed_minimum_validator(0),
    relaxable_value_order_validator(True),
]

RELAXABLE_LOWER_LIMIT_WEIGHT_VALIDATOR = [
    relaxable_value_aim_minimum_validator(0),
    relaxable_value_allowed_minimum_validator(0),
    relaxable_value_order_validator(False),
]

RELAXABLE_UPPER_LIMIT_RATIO_VALIDATOR = RELAXABLE_VALUE_BETWEEN_0_1_VALIDATOR + [
    relaxable_value_order_validator(True)
]

RELAXABLE_LOWER_LIMIT_RATIO_VALIDATOR = RELAXABLE_VALUE_BETWEEN_0_1_VALIDATOR + [
    relaxable_value_order_validator(False)
]


def calc_relaxation_ratio(total_steps: int, actual_step: int) -> float:
    return 0.0 if total_steps == 0 else actual_step / total_steps


class RelaxableLimit(Protocol):
    n_steps: ClassVar[int]
    step: int
    name: str

    @property
    def relaxation_ratio(self) -> float: ...

    def get_next_relaxation_step(self) -> "RelaxableLimit": ...

    def get_last_relaxation_step(self) -> "RelaxableLimit": ...


class RelaxableSummingLimit(Protocol):
    ratio: RelaxableValue
    weight_limit: RelaxableValue
    scrap_types: Tuple[ScrapType, ...]
    name: str
    n_steps: int

    def get_effective_weight_limit(self, total_scrap_weight: float, step: int = 0) -> float: ...

    def get_last_relaxation_step(self) -> "RelaxableSummingLimit": ...

    def is_current_step_ok(
        self, scrap_map: Mapping[ScrapMix, float], mix_mapping: ScrapMixMapping
    ) -> bool: ...

    def is_active(self, scrap_map: Mapping[ScrapMix, float], mix_mapping: ScrapMixMapping) -> bool: ...

    def has_violated_aim_only(
        self, scrap_map: Mapping[ScrapMix, float], mix_mapping: ScrapMixMapping
    ) -> bool: ...

    def has_violated_allowed(
        self, scrap_map: Mapping[ScrapMix, float], mix_mapping: ScrapMixMapping
    ) -> bool: ...

    def get_penalty(self, scrap_map: Mapping[ScrapType, float]) -> float: ...


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RelaxableRiskLimit:
    """
    Probability of undesirable correction technology after blowing due to {chem} must be at most
    self.{chem}.get_relaxed_value(self.relaxation_ratio)
    """

    n_steps: ClassVar[int] = ACTIVE_RELAXATION_STEPS
    name: str
    Cr: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    Cu: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    Mo: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    Ni: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    S: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    Sn: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    Si: RelaxableValue = attr.ib(validator=RELAXABLE_CHEM_RISK_VALIDATOR)
    step: int = attr.ib(default=0, validator=relaxation_step_between_zero_and_n_steps, converter=int)

    @property
    def relaxation_ratio(self) -> float:
        """Ratio to be used when calculating limit values at current relaxation level."""
        return calc_relaxation_ratio(self.n_steps, self.step)

    def get_next_relaxation_step(self) -> "RelaxableRiskLimit":
        """Increment relaxation step to allow calculation of limit values at next relaxation level."""
        return attr.evolve(self, step=self.step + 1)

    def get_last_relaxation_step(self) -> "RelaxableRiskLimit":
        """Set last relaxation step to allow calculation of limit values at "allowed" relaxation level."""
        return attr.evolve(self, step=self.n_steps)

    def get_relaxed_value(self, chem: Chem) -> float:
        return getattr(self, chem).get_relaxed_value(self.relaxation_ratio)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RelaxableUpperSummingLimit:
    """
    Total weight of scrap types listed in `scrap_types` attribute in one heat must be at most
        min(`weight_limit`, `ratio * total_scrap_weight`).
    """

    n_steps: ClassVar[int] = ACTIVE_RELAXATION_STEPS
    name: str
    scrap_types: Tuple[ScrapType, ...]
    weight_limit: RelaxableValue = attr.ib(validator=RELAXABLE_UPPER_LIMIT_WEIGHT_VALIDATOR)
    ratio: RelaxableValue = attr.ib(validator=RELAXABLE_UPPER_LIMIT_RATIO_VALIDATOR)
    step: int = attr.ib(default=0, validator=relaxation_step_between_zero_and_n_steps, converter=int)

    @property
    def relaxation_ratio(self) -> float:
        """Ratio to be used when calculating limit values at current relaxation level."""
        return calc_relaxation_ratio(self.n_steps, self.step)

    def get_next_relaxation_step(self) -> "RelaxableUpperSummingLimit":
        """Increment relaxation step to allow calculation of limit values at next relaxation level."""
        return attr.evolve(self, step=self.step + 1)

    def get_last_relaxation_step(self) -> "RelaxableUpperSummingLimit":
        """Get new limit to allow calculation of limit values at "allowed" relaxation level."""
        return attr.evolve(self, step=self.n_steps)

    def get_first_relaxation_step(self) -> "RelaxableUpperSummingLimit":
        """Get new limit to allow calculation of limit values at "aim" relaxation level."""
        return attr.evolve(self, step=0)

    def get_effective_weight_limit(self, total_scrap_weight: float) -> float:
        return min(
            self.ratio.get_relaxed_value(self.relaxation_ratio) * total_scrap_weight,
            self.weight_limit.get_relaxed_value(self.relaxation_ratio),
        )

    def get_affected_scrap_charge_mixes(
        self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping
    ) -> ScrapMixOrder:
        scrap_mixes = tuple(scrap_map.keys())
        return get_affected_scrap_mixes(scrap_mixes, mix_mapping, self.scrap_types)

    def is_current_step_ok(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return True
        return sum(
            weight for mix, weight in scrap_map.items() if mix in affected_scrap_mixes
        ) <= self.get_effective_weight_limit(sum(scrap_map.values()))

    def has_violated_aim_only(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        return not self.get_first_relaxation_step().is_current_step_ok(
            scrap_map, mix_mapping
        ) and not self.has_violated_allowed(scrap_map, mix_mapping)

    def has_violated_allowed(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        return not self.get_last_relaxation_step().is_current_step_ok(scrap_map, mix_mapping)

    def is_active(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        actual = sum(weight for mix, weight in scrap_map.items() if mix in affected_scrap_mixes)
        aim = self.get_first_relaxation_step().get_effective_weight_limit(sum(scrap_map.values()))
        return aim <= actual


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RelaxableLowerSummingLimit:
    """
    Total weight of scrap types listed in `scrap_types` attribute in one heat must be at least
        max(`weight_limit`, `ratio * total_scrap_weight`).
    """

    n_steps: ClassVar[int] = ACTIVE_RELAXATION_STEPS
    name: str
    scrap_types: Tuple[ScrapType, ...]
    weight_limit: RelaxableValue = attr.ib(validator=RELAXABLE_LOWER_LIMIT_WEIGHT_VALIDATOR)
    ratio: RelaxableValue = attr.ib(validator=RELAXABLE_LOWER_LIMIT_RATIO_VALIDATOR)
    step: int = attr.ib(default=0, validator=relaxation_step_between_zero_and_n_steps, converter=int)

    @property
    def relaxation_ratio(self) -> float:
        """Ratio to be used when calculating limit values at current relaxation level."""
        return calc_relaxation_ratio(self.n_steps, self.step)

    def get_next_relaxation_step(self) -> "RelaxableLowerSummingLimit":
        """Increment relaxation step to allow calculation of limit values at next relaxation level."""
        return attr.evolve(self, step=self.step + 1)

    def get_last_relaxation_step(self) -> "RelaxableLowerSummingLimit":
        """Get new limit to allow calculation of limit values at "allowed" relaxation level."""
        return attr.evolve(self, step=self.n_steps)

    def get_first_relaxation_step(self) -> "RelaxableLowerSummingLimit":
        """Get new limit to allow calculation of limit values at "aim" relaxation level."""
        return attr.evolve(self, step=0)

    def get_effective_weight_limit(self, total_scrap_weight: float) -> float:
        return max(
            self.ratio.get_relaxed_value(self.relaxation_ratio) * total_scrap_weight,
            self.weight_limit.get_relaxed_value(self.relaxation_ratio),
        )

    def get_affected_scrap_charge_mixes(
        self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping
    ) -> ScrapMixOrder:
        scrap_mixes = tuple(scrap_map.keys())
        return get_affected_scrap_mixes(scrap_mixes, mix_mapping, self.scrap_types)

    def is_current_step_ok(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return True
        return sum(
            weight for mix, weight in scrap_map.items() if mix in affected_scrap_mixes
        ) >= self.get_effective_weight_limit(sum(scrap_map.values()))

    def has_violated_aim_only(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        return not self.get_first_relaxation_step().is_current_step_ok(
            scrap_map, mix_mapping
        ) and not self.has_violated_allowed(scrap_map, mix_mapping)

    def has_violated_allowed(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        return not self.get_last_relaxation_step().is_current_step_ok(scrap_map, mix_mapping)

    def is_active(self, scrap_map: ScrapCharge, mix_mapping: ScrapMixMapping) -> bool:
        affected_scrap_mixes = self.get_affected_scrap_charge_mixes(scrap_map, mix_mapping)
        if not affected_scrap_mixes:
            return False
        actual = sum(weight for mix, weight in scrap_map.items() if mix in affected_scrap_mixes)
        aim = self.get_first_relaxation_step().get_effective_weight_limit(sum(scrap_map.values()))
        return actual <= aim

    def get_penalty(self, scrap_map: Mapping[ScrapType, float]) -> float:
        total_scrap_weight = sum(scrap_map.get(scrap_type, 0) for scrap_type in self.scrap_types)
        weight_limit = self.get_effective_weight_limit(sum(scrap_map.values()))
        return max(0, weight_limit - total_scrap_weight)
