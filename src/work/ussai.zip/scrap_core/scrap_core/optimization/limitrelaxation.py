from typing import Callable, Iterable, List, Sequence, Tuple

import attr
from scrap_core.optimization.datamodel import MultipleHeatsOptimizationInput, HeatInputs
from scrap_core.optimization.relaxable_limits import (
    ACTIVE_RELAXATION_STEPS,
    RelaxationSchedule,
    SingleRelaxationSchedule,
)


Relaxer = Callable[[MultipleHeatsOptimizationInput], MultipleHeatsOptimizationInput]
Relaxers = List[Relaxer]


def update_heats_with_new_heat(
    heats: Tuple[HeatInputs, ...], new_heat: HeatInputs, idx: int
) -> Tuple[HeatInputs, ...]:
    return heats[:idx] + (new_heat,) + heats[idx + 1 :]


def create_relaxable_risk_limit_relaxer_for_one_heat(idx: int) -> Relaxer:
    def relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
        """Relax relaxable risk limit on given heat in input data."""
        heat = input_data.heats[idx]
        new_relaxable_risk_limit = heat.relaxable_risk_limit.get_next_relaxation_step()
        new_heat = attr.evolve(heat, relaxable_risk_limit=new_relaxable_risk_limit)
        new_heats = update_heats_with_new_heat(input_data.heats, new_heat, idx)
        return attr.evolve(input_data, heats=new_heats)

    return relaxer


def create_relaxable_risk_limit_relaxer() -> Relaxer:
    def relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
        """Relax relaxable risk limit on each heat in input data."""
        relaxers = [
            create_relaxable_risk_limit_relaxer_for_one_heat(idx) for idx, _ in enumerate(input_data.heats)
        ]
        return join_relaxers(relaxers)(input_data)

    return relaxer


def create_relaxable_summing_limits_relaxer_for_one_heat(idx: int) -> Relaxer:
    def relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
        """Relax relaxable summing limits on given heat in input data."""
        heat = input_data.heats[idx]
        new_lower_limits = tuple(
            limit.get_next_relaxation_step() for limit in heat.relaxable_lower_summing_limits
        )
        new_upper_limits = tuple(
            limit.get_next_relaxation_step() for limit in heat.relaxable_upper_summing_limits
        )
        new_heat = attr.evolve(
            heat,
            relaxable_lower_summing_limits=new_lower_limits,
            relaxable_upper_summing_limits=new_upper_limits,
        )
        new_heats = update_heats_with_new_heat(input_data.heats, new_heat, idx)
        return attr.evolve(input_data, heats=new_heats)

    return relaxer


def create_relaxable_summing_limits_relaxer() -> Relaxer:
    def relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
        """Relax relaxable summing limits on each heat in input data."""
        relaxers = [
            create_relaxable_summing_limits_relaxer_for_one_heat(idx)
            for idx, _ in enumerate(input_data.heats)
        ]
        return join_relaxers(relaxers)(input_data)

    return relaxer


def identity_relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
    return input_data


def join_relaxers(relaxers: Iterable[Relaxer]) -> Relaxer:
    def joint_relaxer(input_data: MultipleHeatsOptimizationInput) -> MultipleHeatsOptimizationInput:
        new_data = input_data
        for relaxer in relaxers:
            new_data = relaxer(new_data)
        return new_data

    return joint_relaxer


def create_single_schedule_selector(limit_type: str):
    def schedule_selector(relaxation_schedule: RelaxationSchedule) -> Sequence[bool]:
        if limit_type == "risk":
            return [step.risk_limits for step in relaxation_schedule]
        elif limit_type == "summing":
            return [step.summing_limits for step in relaxation_schedule]
        raise ValueError(f"Type {limit_type} is not supported.")

    return schedule_selector


def get_relaxers_by_schedule(
    single_relaxation_schedule: SingleRelaxationSchedule, relaxer_factory: Callable[[], Relaxer]
) -> Relaxers:
    """
    Function that generates a list of relaxers according to the relaxation schedule, using the relaxer factory and identity relaxer. Number of created relaxers is equal to length of relaxation schedule.
    """
    relaxation_steps = sum(single_relaxation_schedule)
    if relaxation_steps != ACTIVE_RELAXATION_STEPS:
        raise ValueError("Relaxation schedule contains more or less relaxation steps than is configured.")
    all_relaxers = []
    for step in single_relaxation_schedule:
        all_relaxers.append(relaxer_factory() if step else identity_relaxer)
    return all_relaxers


def get_relaxable_limits_relaxers(relaxation_schedule: RelaxationSchedule) -> Relaxers:
    risk_relaxers = get_relaxers_by_schedule(
        single_relaxation_schedule=create_single_schedule_selector("risk")(relaxation_schedule),
        relaxer_factory=create_relaxable_risk_limit_relaxer,
    )
    summing_relaxers = get_relaxers_by_schedule(
        single_relaxation_schedule=create_single_schedule_selector("summing")(relaxation_schedule),
        relaxer_factory=create_relaxable_summing_limits_relaxer,
    )
    return [join_relaxers(relaxers) for relaxers in zip(risk_relaxers, summing_relaxers)]
