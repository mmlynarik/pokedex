from functools import lru_cache
from typing import Optional, Tuple

import numpy as np
from scipy.stats import truncnorm

from scrap_core import ScrapOrder
from scrap_core.blendmodel import ScrapBlendModel, get_blend_model
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologiesModel, get_corr_tech_model
from scrap_core.meltabilitymodel import ScrapMeltabilityModel, get_meltability_model
from scrap_core.yieldmodel import ScrapYieldModel, get_yield_model
from scrap_core.optimization.datamodel import ModelSettings

Bounds = np.ndarray
Individual = np.ndarray


def get_truncnorm(mean: float, std: float, low: int, upp: int):
    return truncnorm((low - mean) / std, (upp - mean) / std, loc=mean, scale=std)


@lru_cache(maxsize=1024)
def get_all_models_from_model_settings(
    settings: ModelSettings,
) -> Tuple[ScrapBlendModel, ScrapYieldModel, ScrapMeltabilityModel, CorrectionTechnologiesModel]:
    blend_model = get_blend_model(settings.blend_model_settings.version)
    yield_model = get_yield_model(settings.yield_model_settings.version)
    meltability_model = get_meltability_model(settings.meltability_model_settings.version)
    corr_techs_model = get_corr_tech_model(
        settings.correction_technologies_settings.version,
        settings.correction_technologies_settings.chems_for_correction_technologies,
        full_binning_map=blend_model.full_binning_map,  # type: ignore
    )
    return blend_model, yield_model, meltability_model, corr_techs_model


@lru_cache(maxsize=1024)
def validate_scrap_order_for_settings(model_settings: ModelSettings) -> Optional[str]:
    (
        blend_model,
        yield_model,
        meltability_model,
        _,
    ) = get_all_models_from_model_settings(model_settings)
    if blend_model.scrap_order != yield_model.scrap_order:
        return (
            "Blend and yield model not compatible - "
            + f"bm: {blend_model.scrap_order} ym: {yield_model.scrap_order}"
        )

    if blend_model.scrap_order != meltability_model.scrap_order:
        return (
            "Blend and meltability model not compatible - "
            + f"bm: {blend_model.scrap_order} mm: {meltability_model.scrap_order}"
        )

    return None


@lru_cache(maxsize=1024)
def get_scrap_order_from_model_settings(model_settings: ModelSettings) -> ScrapOrder:
    error = validate_scrap_order_for_settings(model_settings)
    if error is not None:
        raise ValueError(error)
    blend_model, _, _, _ = get_all_models_from_model_settings(model_settings)
    return blend_model.scrap_order
