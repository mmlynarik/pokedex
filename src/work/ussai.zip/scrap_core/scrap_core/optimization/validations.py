from datetime import date
from functools import lru_cache
from itertools import chain
from typing import Optional, Sequence, Tuple, Iterable
from immutables import Map

from scrap_core import ScrapMix, ScrapMixOrder, ScrapMixMapping, get_affected_scrap_mixes, ScrapBounds
from usskssgrades.steel_grades_protocol import SteelGrades
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization import validate_scrap_order_for_settings
from scrap_core.optimization.datamodel import (
    AvailableScraps,
    HeatPlan,
    ModelSettings,
    ScrapMixLimit,
    ScrapMixLimits,
)
from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit, RelaxableLowerSummingLimit
from scrap_core.utils import convert_kilograms_to_tons, to_mixes

ChargeInfoValidationErrors = Tuple[str, ...]
ChargeInfoValidationWarnings = Tuple[str, ...]
ChargeInfoValidationResult = Tuple[ChargeInfoValidationErrors, ChargeInfoValidationWarnings]
NO_VALIDATION_PROBLEMS: ChargeInfoValidationResult = ((), ())

SCRAP_AVAILABILITY_RATIO = 0.8


def has_errors(validation_result: ChargeInfoValidationResult) -> bool:
    return len(validation_result[0]) > 0


def get_total_available_scrap(available_scraps: AvailableScraps) -> float:
    return sum([x.weight for x in available_scraps])


def get_capped_available_scrap(available_scraps: AvailableScraps, optimized_heats: int) -> float:
    return sum([min(x.weight, 20000.0 * (optimized_heats + 1)) for x in available_scraps])


def warning_to_validation_result(warning: str) -> ChargeInfoValidationResult:
    return ((), (warning,))


def error_to_validation_result(error: str) -> ChargeInfoValidationResult:
    return ((error,), ())


def join_validation_results(
    all_validations: Sequence[ChargeInfoValidationResult],
) -> ChargeInfoValidationResult:
    errors, warnings = list(zip(*all_validations))
    return tuple(chain.from_iterable(errors)), tuple(chain.from_iterable(warnings))


def is_min_max_invalid(limit: ScrapMixLimit) -> bool:
    if limit.maximum is None or limit.minimum is None:
        return False
    return limit.maximum < limit.minimum


def validate_scrap_limits_min_max(scrap_limits: ScrapMixLimits) -> ChargeInfoValidationResult:
    errors = [
        f"Pre typ šrotu {limit.scrap_type} je minimálne {int(convert_kilograms_to_tons(limit.minimum))} "
        + f"množstvo väčšie ako maximálne {int(convert_kilograms_to_tons(limit.maximum))}"
        for limit in scrap_limits
        if limit.minimum is not None and limit.maximum is not None and is_min_max_invalid(limit)
    ]
    return (tuple(errors), ())


def validate_scrap_limits_positive(scrap_limits: ScrapMixLimits) -> ChargeInfoValidationResult:
    errors_min = [
        f"Pre typ šrotu {limit.scrap_type} je hodnota minima {convert_kilograms_to_tons(limit.minimum)} menšia ako 0"
        for limit in scrap_limits
        if limit.minimum is not None and limit.minimum < 0
    ]
    errors_max = [
        f"Pre typ šrotu {limit.scrap_type} je hodnota maxima {convert_kilograms_to_tons(limit.maximum)} menšia ako 0"
        for limit in scrap_limits
        if limit.maximum is not None and limit.maximum < 0
    ]
    return (tuple(errors_min + errors_max), ())


def validate_scrap_limits_min_sum(
    scrap_limits: ScrapMixLimits, total_scrap_weight: int
) -> ChargeInfoValidationResult:
    min_sum = sum([limit.minimum if limit.minimum is not None else 0.0 for limit in scrap_limits])
    if min_sum > total_scrap_weight:
        return error_to_validation_result("Suma miním pre šroty je vačšia ako objednaná hmotnosť šrotu")
    return NO_VALIDATION_PROBLEMS


def validate_scrap_limits_max_sum(
    scrap_limits: ScrapMixLimits, total_scrap_weight: int
) -> ChargeInfoValidationResult:
    max_sum = sum(
        [limit.maximum if limit.maximum is not None else total_scrap_weight for limit in scrap_limits]
    )
    if max_sum < total_scrap_weight:
        return error_to_validation_result("Suma maxím pre šroty je menšia ako objednaná hmotnosť šrotu")
    return NO_VALIDATION_PROBLEMS


def validation_minimum_scrap_limit(
    scrap_limits: ScrapMixLimits, available_scraps: AvailableScraps
) -> ChargeInfoValidationResult:
    error_msg = []
    for scrap_limit in scrap_limits:
        for available_scrap in available_scraps:
            if available_scrap.scrap_type == scrap_limit.scrap_type:
                if scrap_limit.minimum is not None:
                    if available_scrap.weight < scrap_limit.minimum:
                        error_msg.append(
                            f"Pre naloženie {convert_kilograms_to_tons(float(scrap_limit.minimum))}t "
                            + f"{scrap_limit.scrap_type} nemáte dostatok šrotu."
                        )
                        break
    if not error_msg:
        return NO_VALIDATION_PROBLEMS
    return error_to_validation_result("\n".join(error_msg))


# TODO check if those float conversions are necessary
def scrap_limits_to_dicts(
    scrap_limits: ScrapMixLimits, available_scrap_mixes: ScrapMixOrder, total_scrap_weight: int
) -> Tuple[Map[ScrapMix, float], Map[ScrapMix, float]]:
    # Convert ScrapTypeLimit to Dictionaries
    upper_limits_tmp = {lim.scrap_type: float(lim.maximum) for lim in scrap_limits if lim.maximum is not None}
    lower_limits_tmp = {lim.scrap_type: float(lim.minimum) for lim in scrap_limits if lim.minimum is not None}
    # Extend domain to available scraps types
    upper_limits = {
        scrap_mix: upper_limits_tmp.get(scrap_mix, float(total_scrap_weight))
        for scrap_mix in available_scrap_mixes
    }
    lower_limits = {scrap_type: lower_limits_tmp.get(scrap_type, 0.0) for scrap_type in available_scrap_mixes}
    return (Map(lower_limits), Map(upper_limits))


def get_minimal_from_relaxable_upper_summing_limits_or_total(
    relaxable_upper_summing_limits: Tuple[RelaxableUpperSummingLimit, ...],
    available_scrap: AvailableScraps,
    total_scrap_weight: int,
    mix_mapping: ScrapMixMapping,
) -> Map[ScrapMix, float]:
    return Map(
        {
            scrap.scrap_type: min(
                (
                    limit.get_effective_weight_limit(float(total_scrap_weight))
                    for limit in relaxable_upper_summing_limits
                    if scrap.scrap_type
                    in get_affected_scrap_mixes(to_mixes(scrap.scrap_type), mix_mapping, limit.scrap_types)
                ),
                default=float(total_scrap_weight),
            )
            for scrap in available_scrap
        }
    )


def get_active_scrap_upper_limits(
    available_scrap: AvailableScraps,
    user_defined_upper_limits: Map[ScrapMix, float],
    active_lower_limits: Map[ScrapMix, float],
    lowest_summing_limit: Map[ScrapMix, float],
    total_scrap_weight: int,
) -> Map[ScrapMix, float]:
    """Calculates minimal of `max weight in setting`, `available scrap` and `total scrap weight` for a scrap type.
    `total_scrap_weight` must be converted to kilograms.
    """
    available_scrap_dict = {scrap.scrap_type: scrap.weight for scrap in available_scrap}
    return Map(
        {
            scrap_mix: float(
                max(
                    min(
                        available_scrap_dict[scrap_mix],
                        user_defined_upper_limits.get(scrap_mix, total_scrap_weight),
                        lowest_summing_limit.get(scrap_mix, total_scrap_weight),
                    ),
                    active_lower_limits.get(scrap_mix, 0.0),
                )
            )
            for scrap_mix in available_scrap_dict
        }
    )


def get_active_effective_weight_limit(
    relaxable_upper_summing_limit: RelaxableUpperSummingLimit,
    active_lower_limits: Map[ScrapMix, float],
    total_scrap_weight: float,
    mix_mapping: ScrapMixMapping,
) -> float:
    scrap_weight_forced_by_lower_limit = sum(
        weight
        for scrap_mix, weight in active_lower_limits.items()
        if scrap_mix
        in get_affected_scrap_mixes(
            to_mixes(scrap_mix), mix_mapping, relaxable_upper_summing_limit.scrap_types
        )
    )
    return max(
        scrap_weight_forced_by_lower_limit,
        relaxable_upper_summing_limit.get_effective_weight_limit(total_scrap_weight),
    )


def validate_relaxable_upper_summing_limit(
    active_lower_limits: Map[ScrapMix, float],
    active_upper_limits: Map[ScrapMix, float],
    relaxable_upper_summing_limit: RelaxableUpperSummingLimit,
    available_scrap_mixes: Tuple[ScrapMix, ...],
    total_scrap_weight: float,
    mix_mapping: ScrapMixMapping,
) -> ChargeInfoValidationResult:
    """Calculates sum of available scrap type weights and compares with limit."""
    affected_scrap_mixes = get_affected_scrap_mixes(
        available_scrap_mixes, mix_mapping, relaxable_upper_summing_limit.scrap_types
    )
    if not affected_scrap_mixes:
        return NO_VALIDATION_PROBLEMS
    active_effective_weight_limit = get_active_effective_weight_limit(
        relaxable_upper_summing_limit, active_lower_limits, total_scrap_weight, mix_mapping
    )
    scrap_weight_forced_by_upper_limit = total_scrap_weight - sum(
        [
            active_limit
            for scrap_mix, active_limit in active_upper_limits.items()
            if scrap_mix
            not in get_affected_scrap_mixes(
                to_mixes(scrap_mix), mix_mapping, relaxable_upper_summing_limit.scrap_types
            )
        ]
    )
    complement_scrap_mixes = set(available_scrap_mixes) - set(
        get_affected_scrap_mixes(
            available_scrap_mixes, mix_mapping, relaxable_upper_summing_limit.scrap_types
        )
    )
    complement_lower_bound = max(
        total_scrap_weight - active_effective_weight_limit,
        sum(active_lower_limits[scrap_mix] for scrap_mix in complement_scrap_mixes),
    )
    complement_upper_bound = sum(active_upper_limits[scrap_mix] for scrap_mix in complement_scrap_mixes)

    if scrap_weight_forced_by_upper_limit > active_effective_weight_limit:
        return error_to_validation_result(
            f"[{relaxable_upper_summing_limit.name}] Potrebná hmotnosť šrotu {' + '.join(complement_scrap_mixes)} >= {convert_kilograms_to_tons(complement_lower_bound)} je vyššia než dovoľujú nastavené horné ohraničenia pre tieto typy šrotu: {convert_kilograms_to_tons(complement_upper_bound)}."
        )
    return NO_VALIDATION_PROBLEMS


def validate_summing_scrap_lower_limit(
    active_lower_limits: Map[ScrapMix, float],
    relaxable_upper_summing_limit: RelaxableUpperSummingLimit,
    total_scrap_weight: int,
    mix_mapping: ScrapMixMapping,
) -> ChargeInfoValidationResult:
    """Checks a max weight of all lower scraps bounds in limit."""
    min_sum = sum(
        [
            weight
            for scrap_mix, weight in active_lower_limits.items()
            if scrap_mix
            in get_affected_scrap_mixes(
                to_mixes(scrap_mix), mix_mapping, relaxable_upper_summing_limit.scrap_types
            )
        ]
    )
    effective_weight_limit = relaxable_upper_summing_limit.get_effective_weight_limit(
        float(total_scrap_weight)
    )
    if min_sum > effective_weight_limit:
        return warning_to_validation_result(
            f"[{relaxable_upper_summing_limit.name}] Suma minimálnych limitov pre šroty {relaxable_upper_summing_limit.scrap_types} je väčšia ako povolené maximum {convert_kilograms_to_tons(effective_weight_limit)} t."
        )
    return NO_VALIDATION_PROBLEMS


# TODO remove relaxable_lower_summing_limit (it is redundant, yet)
def validate_scrap_limits(
    scrap_limits: ScrapMixLimits,
    total_scrap_weight: int,
    available_scraps: AvailableScraps,
    relaxable_lower_summing_limits: Iterable[RelaxableLowerSummingLimit],
    relaxable_upper_summing_limits: Iterable[RelaxableUpperSummingLimit],
    # TODO usage of grade_id parameter in this function is very unfortunate, remove it
    grade_id: Optional[int],
    mix_mapping: ScrapMixMapping = Map(),
) -> ChargeInfoValidationResult:

    # Relax all limits as much as possible, because we need to validate their weakest variants
    # last_relaxable_lower_summing_limits = (
    #     tuple(lim.get_last_relaxation_step() for lim in relaxable_lower_summing_limits),
    # )
    last_relaxable_upper_summing_limits = tuple(
        lim.get_last_relaxation_step() for lim in relaxable_upper_summing_limits
    )

    grade_id_dependant_validations = []
    if grade_id is not None:
        active_lower_limits, user_defined_upper_limits = scrap_limits_to_dicts(
            scrap_limits,
            tuple([scrap.scrap_type for scrap in available_scraps]),
            total_scrap_weight,
        )

        active_upper_limits = get_active_scrap_upper_limits(
            available_scraps,
            user_defined_upper_limits,
            active_lower_limits,
            get_minimal_from_relaxable_upper_summing_limits_or_total(
                last_relaxable_upper_summing_limits, available_scraps, total_scrap_weight, mix_mapping
            ),
            total_scrap_weight,
        )
        available_scrap_mixes = tuple([scrap.scrap_type for scrap in available_scraps])
        grade_id_dependant_validations = [
            validate_summing_scrap_lower_limit(active_lower_limits, limit, total_scrap_weight, mix_mapping)
            for limit in last_relaxable_upper_summing_limits
        ] + [
            validate_relaxable_upper_summing_limit(
                active_lower_limits,
                active_upper_limits,
                limit,
                available_scrap_mixes,
                float(total_scrap_weight),
                mix_mapping,
            )
            for limit in last_relaxable_upper_summing_limits
        ]
    return join_validation_results(
        [
            validate_scrap_limits_positive(scrap_limits),
            validate_scrap_limits_max_sum(scrap_limits, total_scrap_weight),
            validate_scrap_limits_min_sum(scrap_limits, total_scrap_weight),
            validate_scrap_limits_min_max(scrap_limits),
            validation_minimum_scrap_limit(scrap_limits, available_scraps),
        ]
        + grade_id_dependant_validations
    )


def validate_scrap_mix_ratios(
    scrap_mix_mapping: ScrapMixMapping, available_scraps: ScrapMixOrder
) -> ChargeInfoValidationResult:
    for mix, mapping in scrap_mix_mapping.items():
        if sum(mapping.values()) != 1 and mix in available_scraps:
            return error_to_validation_result(
                f"Súčet pomerov šrotov v definícii hromady {mix} je rôzny od 1. Ak si želáte pokračovať, "
                f"odstráňte prosím hromadu zo zoznamu dostupných šrotov."
            )
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_heat_id(heat_id: Optional[int], steelshop: Optional[int]) -> ChargeInfoValidationResult:
    if steelshop == 1:
        return NO_VALIDATION_PROBLEMS
    if (heat_id is not None) and ((heat_id < 10000) or (20000 <= heat_id < 30000) or (heat_id >= 60000)):
        return warning_to_validation_result(f"Podozrivé číslo tavby {heat_id}")
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_basket_ids_count(basket_ids: Tuple[int, ...]) -> ChargeInfoValidationResult:
    if not basket_ids:
        return warning_to_validation_result("Informácia o číslach korýt nevyplnená")
    if len(basket_ids) > 2:
        return warning_to_validation_result(
            "Podozrivý počet korýt - ak sa jedná viac ako dvojkorytovú vsádzku ignorujte toto upozornenie"
        )
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_switched_basket_ids_count(switched_basket_ids: Tuple[int, ...]) -> ChargeInfoValidationResult:
    if len(switched_basket_ids) > 2:
        return warning_to_validation_result("Podozrivý počet točených korýt.")
    return NO_VALIDATION_PROBLEMS


def validate_basket_id_value(basket_id: int) -> ChargeInfoValidationResult:
    if not 1 <= basket_id <= 200:
        return warning_to_validation_result(f"Podozrivé číslo koryta {basket_id}")
    return NO_VALIDATION_PROBLEMS


def validate_basket_ids_duplicity(basket_ids: Tuple[int, ...]) -> ChargeInfoValidationResult:
    if len(basket_ids) != len(set(basket_ids)):
        return warning_to_validation_result("Podozrivé čísla korýt - jedno číslo koryta použité viackrát")
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_basket_ids_values(basket_ids: Tuple[int, ...]) -> ChargeInfoValidationResult:
    return join_validation_results(
        [*[validate_basket_id_value(bid) for bid in basket_ids], validate_basket_ids_duplicity(basket_ids)]
    )


@lru_cache()
def validate_switched_basket_ids_values(
    switched_basket_ids: Tuple[int, ...], basket_ids: Tuple[int, ...]
) -> ChargeInfoValidationResult:
    value_warnings = validate_basket_ids_values(switched_basket_ids)
    missing_warnings = [
        warning_to_validation_result(f"Točené koryto {sbid} sa nenachádza v zozname korýt.")
        for sbid in switched_basket_ids
        if sbid not in basket_ids
    ]

    return join_validation_results([value_warnings, *missing_warnings])


@lru_cache()
def validate_basket_ids(basket_ids: Tuple[int, ...]) -> ChargeInfoValidationResult:
    return join_validation_results(
        [validate_basket_ids_count(basket_ids), validate_basket_ids_values(basket_ids)]
    )


@lru_cache()
def validate_switched_basket_ids(
    switched_basket_ids: Tuple[int, ...], basket_ids: Tuple[int, ...]
) -> ChargeInfoValidationResult:
    return join_validation_results(
        [
            validate_switched_basket_ids_count(switched_basket_ids),
            validate_switched_basket_ids_values(switched_basket_ids, basket_ids),
        ]
    )


def validate_heat_plan(heat_plan: Optional[HeatPlan]) -> ChargeInfoValidationResult:
    if heat_plan is None:
        return warning_to_validation_result("Plán tavieb nenačítaný - optimalizácia prebehne pre jednu tavbu")
    return NO_VALIDATION_PROBLEMS


def validate_total_scrap_weight_value(total_scrap_weight: Optional[int]) -> ChargeInfoValidationResult:
    if total_scrap_weight is None:
        return NO_VALIDATION_PROBLEMS
    if total_scrap_weight < 0:
        return error_to_validation_result("Objednaná hmotnosť šrotu musí byť väčšia ako 0")
    if (total_scrap_weight <= 10000) or (total_scrap_weight > 60000):
        return warning_to_validation_result(
            f"Podozrivá hmotnosť šrotu {convert_kilograms_to_tons(float(total_scrap_weight))}"
        )
    return NO_VALIDATION_PROBLEMS


# TODO check this
def validate_total_scrap_weight_step(
    total_scrap_weight: Optional[int], precision_step: int
) -> ChargeInfoValidationResult:
    if total_scrap_weight is None:
        return NO_VALIDATION_PROBLEMS
    if total_scrap_weight % precision_step != 0:
        return error_to_validation_result(
            f"Objednaná hmotnosť šrotu v tonách musí byť násobok {convert_kilograms_to_tons(precision_step)}"
        )
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_total_scrap_weight(total_scrap_weight: Optional[int], precision_step: int):
    return join_validation_results(
        [
            validate_total_scrap_weight_value(total_scrap_weight),
            validate_total_scrap_weight_step(total_scrap_weight, precision_step),
        ]
    )


@lru_cache()
def validate_pig_iron_weight(pig_iron_weight: Optional[int]) -> ChargeInfoValidationResult:
    if pig_iron_weight is None:
        return NO_VALIDATION_PROBLEMS
    if pig_iron_weight <= 0:
        return error_to_validation_result("Hmotnosť surového železa musí byť vačšia ako 0")
    if (0 < pig_iron_weight <= 100000) or (pig_iron_weight > 180000):
        return warning_to_validation_result(
            f"Podozrivá hmotnosť surového železa {convert_kilograms_to_tons(pig_iron_weight)}"
        )
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_raw_fe_chem(raw_fe_chem: RawFeChem) -> ChargeInfoValidationResult:
    limits = {
        "S": (0.002, 0.030),
        "Cu": (0.0, 0.1),
        "Ni": (0.0, 0.1),
        "Cr": (0.0, 0.1),
        "Mo": (0.0, 0.1),
        "Sn": (0.0, 0.1),
        "Si": (0.0, 1.0),
    }
    warnings = [
        f"Podozrivé chemické zloženie surového železa pre prvok {chem}"
        for chem in RawFeChem.all_chems()
        if not (limits[chem][0] <= raw_fe_chem.get_chem(chem) <= limits[chem][1])
    ]
    return ((), tuple(warnings))


@lru_cache()
def get_max_optimizable_heats(
    available_scraps: AvailableScraps, optimized_heats: int, total_scrap_weight: int
) -> int:
    for i in range(optimized_heats, 0, -1):
        if (get_capped_available_scrap(available_scraps, i) * SCRAP_AVAILABILITY_RATIO) > (
            total_scrap_weight * i
        ):
            return i
    if get_total_available_scrap(available_scraps) >= total_scrap_weight:
        return 1
    return 0


@lru_cache()
def validate_available_scraps(
    available_scraps: AvailableScraps,
    total_scrap_weight: int,
    optimized_heats: int,
) -> ChargeInfoValidationResult:
    max_optimized_heats = get_max_optimizable_heats(available_scraps, optimized_heats, total_scrap_weight)
    if max_optimized_heats == 0:
        return error_to_validation_result("Nedostatok šrotu: nemožno optimalizovať")
    if max_optimized_heats < optimized_heats:
        return warning_to_validation_result(
            f"Nízke zásoby šrotu - Optimalizácia prebehne na menšom počte tavieb {max_optimized_heats}"
        )
    return NO_VALIDATION_PROBLEMS


@lru_cache()
def validate_model_settings(model_settings: ModelSettings) -> ChargeInfoValidationResult:
    error = validate_scrap_order_for_settings(model_settings)
    if error is None:
        return NO_VALIDATION_PROBLEMS
    return error_to_validation_result(error)


def validate_grade_id(grade_id: Optional[int], steel_grades: SteelGrades) -> ChargeInfoValidationResult:
    if grade_id is None:
        return error_to_validation_result("Pre optimalizáciu je nutné vybrať grade")
    if not steel_grades.grade_id_exists(grade_id, date.today()):
        return error_to_validation_result(f"Grade {grade_id} nenájdený")
    return NO_VALIDATION_PROBLEMS


def validate_total_scrap_weight_and_weighted_scrap_bounds(
    weighted_scrap_lower_bounds: ScrapBounds, total_scrap_weight: int
) -> ChargeInfoValidationResult:

    if sum(weighted_scrap_lower_bounds.values()) > total_scrap_weight:
        return error_to_validation_result(
            "Hmotnosť naloženého šrotu je vyššia než cieľová hmotnosť šrotu pre túto vsádzku"
        )

    return NO_VALIDATION_PROBLEMS
