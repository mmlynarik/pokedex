import collections
import json
from functools import lru_cache
from typing import Any, Callable, Literal, Optional, Set, Tuple, Type, TypeVar, Dict

import attr
import cattr
from immutables import Map
from returns.result import Failure, Result, Success
from scrap_core import (
    MIN_LOADABLE_SCRAP_WEIGHT_DEFAULT,
    Chem,
    ScrapBounds,
    ScrapCharge,
    ScrapMix,
    ScrapMixOrder,
    ScrapMixes,
    ScrapMixMapping,
    ScrapType,
    between,
    keys_are_scrap_types,
    loadable_scrap_weights_converter,
    must_be_value,
    positive_finite,
    values_are_between,
    scrap_mix_mapping_converter,
    values_are_finite,
    values_are_non_negative,
    scrap_mix_to_scrap_type_set,
)
from scrap_core.blendmodel import BlendModelSettings
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologiesModelSettings
from scrap_core.datamodel import RawFeChem
from usskssgrades import Grade
from scrap_core.datamodel.model import PlannedHeat
from scrap_core.meltabilitymodel import MeltabilityModelSettings
from scrap_core.optimization.default_settings import (
    CALCULATED_MINIMAL_LOADABLE_SCRAP_WEIGHTS,
    DEFAULT_MAX_USED_LIMITS,
)
from scrap_core.optimization.relaxable_limits import (
    RelaxableValue,
    RelaxableRiskLimit,
    RelaxableLowerSummingLimit,
    RelaxableUpperSummingLimit,
)
from scrap_core.serialization import serializable
from scrap_core.yieldmodel import YieldModelSettings


# TODO move converter to some scrap_core source file called converter.py
converter = cattr.GenConverter()


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapMixLimit:
    scrap_type: ScrapMix
    minimum: Optional[float] = None
    maximum: Optional[float] = None

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


@attr.s(auto_attribs=True)
class ChemRiskLevels:
    medium: Tuple[str, ...]
    high: Tuple[str, ...]


ScrapMixLimits = Tuple[ScrapMixLimit, ...]

OUTDOOR_SCRAP_NAME = "OUTDOOR"
INDOOR_SCRAP_NAME = "INDOOR"

SCRAP_LOCATION = [OUTDOOR_SCRAP_NAME, INDOOR_SCRAP_NAME]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class AvailableScrap:
    scrap_type: ScrapMix = attr.ib()
    weight: float = attr.ib()  # in kgs
    location: str = attr.ib(default=INDOOR_SCRAP_NAME)

    @location.validator
    def check_location_name(self, attribute, location_name):
        if location_name not in SCRAP_LOCATION:
            raise ValueError(f"Location name should be {OUTDOOR_SCRAP_NAME} or {INDOOR_SCRAP_NAME}")

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "AvailableScrap":
        return deserialize_available_scrap(serialized)


@lru_cache()
def deserialize_available_scrap(serialized: str) -> AvailableScrap:
    return converter.structure(json.loads(serialized), AvailableScrap)


AvailableScraps = Tuple[AvailableScrap, ...]


def available_scraps_to_upper_bound_map(
    available_scraps: AvailableScraps, transfer_capacity: int
) -> Map[ScrapMix, float]:
    outdoor_scrap_mixes = tuple(
        scrap.scrap_type for scrap in available_scraps if scrap.location == OUTDOOR_SCRAP_NAME
    )
    return Map(
        {
            scrap.scrap_type: (
                scrap.weight
                if scrap.scrap_type not in outdoor_scrap_mixes
                else min(max(transfer_capacity, 0), scrap.weight)
            )
            for scrap in available_scraps
        }
    )


@attr.s(auto_attribs=True, slots=True, frozen=True)
class HeatPlan:
    timestamp: int = attr.ib(converter=int, validator=[positive_finite])  # UTC
    heats: Tuple[PlannedHeat, ...]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


def ratio_validator(full_instance, attribute_type, value):
    if (value < 0) or (value > 1):
        raise ValueError(f"{attribute_type.name} is {value} but must be between 0 and 1")
    if full_instance.h_min_ratio > full_instance.h_max_ratio:
        raise ValueError("h_min_ratio must be smaller than h_max_ratio")
    if full_instance.l_min_ratio > full_instance.l_max_ratio:
        raise ValueError("l_min_ratio must be smaller than l_max_ratio")


@attr.s(auto_attribs=True, frozen=True, slots=True)
class ScrapExclusiveGroup:
    name: str
    scrap_types: ScrapMixOrder

    def _get_available_members(self, available_scrap: ScrapMixes) -> Set[ScrapMix]:
        return set(self.scrap_types).intersection(available_scrap)

    def _get_forced_members(self, forced_scrap: ScrapMixes) -> Set[ScrapMix]:
        return set(forced_scrap).intersection(self.scrap_types)

    def is_active(
        self,
        available_scrap: ScrapMixes,
        forced_scrap: ScrapMixes,
        mix_mapping: ScrapMixMapping,
    ) -> bool:
        """
        Active group must have:
        - at most one forced member AND
        - at most one member in each composite available scrap mix AND
        - at least one member in available scraps
        """
        for scrap_mix in available_scrap:
            if scrap_mix in mix_mapping:
                if len(set(mix_mapping[scrap_mix]).intersection(self.scrap_types)) > 1:
                    return False
        if len(self._get_forced_members(forced_scrap)) > 1:
            return False
        if not self._get_available_members(available_scrap):
            return False
        return True

    def has_composite_mix(self, mix_mapping: ScrapMixMapping) -> bool:
        return any(scrap in mix_mapping for scrap in self.scrap_types)

    def get_active_scrap_mixes(
        self, available_scrap: ScrapMixes, forced_scrap: ScrapMixes, mix_mapping: ScrapMixMapping
    ) -> ScrapMixOrder:
        """
        Active scrap mixes are only defined for active group and are either all available scrap mixes or the only one forced scrap mix.
        """
        if not self.is_active(available_scrap, forced_scrap, mix_mapping):
            return tuple()

        forced_members = self._get_forced_members(forced_scrap)
        if forced_members:
            return tuple(forced_members)

        available_members = self._get_available_members(available_scrap)
        return tuple(available_members)


ScrapExclusiveGroups = Tuple[ScrapExclusiveGroup, ...]


def scrap_exclusive_groups_validator(full_instance, attribute_type, value):
    # groups should have unique names
    groups = collections.defaultdict(list)
    for group in value:
        groups[group.name].append(group)

    invalid_keys = [key for key, group in groups.items() if len(group) > 1]

    if invalid_keys:
        raise ValueError("There are 2+ exclusive groups with the same `name`: %s", invalid_keys)


@attr.s(slots=True, frozen=True)
class OptimizerSettings:
    version: int = attr.ib(default=1, validator=must_be_value(1), converter=int)
    h_min_ratio: float = attr.ib(default=0.3, validator=ratio_validator, converter=float)
    h_max_ratio: float = attr.ib(default=0.5, validator=ratio_validator, converter=float)
    l_min_ratio: float = attr.ib(default=0.0, validator=ratio_validator, converter=float)
    l_max_ratio: float = attr.ib(default=0.5, validator=ratio_validator, converter=float)
    precision_step: int = attr.ib(default=100, converter=int, validator=between(1, 10**6))
    minimal_loadable_scrap_weights: Map[ScrapType, float] = attr.ib(
        default=Map(),
        converter=loadable_scrap_weights_converter,  # type: ignore
        validator=[keys_are_scrap_types, values_are_finite, values_are_non_negative],
    )
    # TODO deprecated, used in historical `MultipleHeatsOptimizationResult` only
    max_undesirable_corr_tech_probability: float = attr.ib(
        default=0.45, validator=between(0.0, 1.0), converter=float
    )
    heat_plan_offset: int = attr.ib(default=2, converter=int, validator=between(0, 100))
    heat_plan_optimized_heats: int = attr.ib(default=10, converter=int, validator=between(0, 100))
    # TODO validation
    optimization_mode: str = attr.ib(default="Worst", converter=str)
    max_used_limits: Map[str, float] = attr.ib(
        default=Map(),
        converter=Map,
        validator=[values_are_between(0.0, 1.0)],
    )
    scrap_exclusive_groups: ScrapExclusiveGroups = attr.ib(
        default=(), validator=[scrap_exclusive_groups_validator]
    )
    scrap_mix_mapping: ScrapMixMapping = attr.ib(default=Map(), converter=scrap_mix_mapping_converter)

    def get_max_used_limit(self, chem: Chem) -> float:
        return self.max_used_limits.get(chem, DEFAULT_MAX_USED_LIMITS[chem])

    def get_minimal_loadable_scrap_weight(self, scrap_type: ScrapType) -> float:
        if scrap_type in self.minimal_loadable_scrap_weights:
            return self.minimal_loadable_scrap_weights[scrap_type]
        return CALCULATED_MINIMAL_LOADABLE_SCRAP_WEIGHTS.get(scrap_type, MIN_LOADABLE_SCRAP_WEIGHT_DEFAULT)

    def get_minimal_loadable_scrap_mix_weight(self, scrap_mix: ScrapMix) -> float:
        return max(
            [
                self.get_minimal_loadable_scrap_weight(scrap_type)
                for scrap_type in scrap_mix_to_scrap_type_set(self.scrap_mix_mapping, scrap_mix)
            ]
        )


@attr.s(slots=True, frozen=True, cache_hash=True)
class ModelSettings:
    blend_model_settings: BlendModelSettings = attr.ib(default=BlendModelSettings())
    yield_model_settings: YieldModelSettings = attr.ib(default=YieldModelSettings())
    meltability_model_settings: MeltabilityModelSettings = attr.ib(default=MeltabilityModelSettings())
    optimizer_settings: OptimizerSettings = attr.ib(default=OptimizerSettings())
    correction_technologies_settings: CorrectionTechnologiesModelSettings = attr.ib(
        default=CorrectionTechnologiesModelSettings()
    )

    @property
    def supported_chems(self) -> Tuple[Chem, ...]:
        return self.correction_technologies_settings.chems_for_correction_technologies

    def get_ignored_chems(self, grade: Grade) -> Tuple[Chem, ...]:
        def get_limit_maximum(grade_: Grade, chem: Chem) -> float:
            limit = grade_.get_limit(chem)
            if limit is None:
                return float("inf")

            return limit.maximum

        return tuple(
            chem
            for chem in self.supported_chems
            if get_limit_maximum(grade, chem) > self.optimizer_settings.get_max_used_limit(chem)
        )

    def serialize(self, pretty: bool = False) -> str:
        unstructured = converter.unstructure(self)
        if pretty:
            return json.dumps(unstructured, sort_keys=True, indent=2)
        return json.dumps(unstructured, sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "ModelSettings":
        return deserialize_model_settings(serialized)

    # HACK HACK HACK
    # This needs to be here so that field with this class is well shown in django admin
    # TODO solve better on django side
    def __str__(self) -> str:
        return self.serialize(True)


@lru_cache()
def deserialize_model_settings(serialized: str) -> ModelSettings:
    return converter.structure(json.loads(serialized), ModelSettings)


def get_default_relaxable_risk_limit() -> RelaxableRiskLimit:
    return RelaxableRiskLimit(
        name="default",
        Cr=RelaxableValue(0.01, 0.02),
        Cu=RelaxableValue(0.01, 0.02),
        Mo=RelaxableValue(0.01, 0.02),
        Ni=RelaxableValue(0.01, 0.02),
        S=RelaxableValue(0.15, 0.291),
        Si=RelaxableValue(0.01, 0.02),
        Sn=RelaxableValue(0.01, 0.02),
    )


# TODO: Delete defaults after completion of relaxable limits migration!
@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class HeatInputs:
    grade_planned: Grade
    total_scrap_weight: int
    pig_iron_weight: int
    pig_iron_chem: RawFeChem
    lower_bounds: ScrapBounds
    upper_bounds: ScrapBounds
    relaxable_risk_limit: RelaxableRiskLimit = get_default_relaxable_risk_limit()
    relaxable_lower_summing_limits: Tuple[RelaxableLowerSummingLimit, ...] = ()
    relaxable_upper_summing_limits: Tuple[RelaxableUpperSummingLimit, ...] = ()

    @property
    def total_lower_bounds(self) -> float:
        return sum(self.lower_bounds.values())


@serializable(converter)
@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class MultipleHeatsOptimizationInput:
    model_settings: ModelSettings
    lower_bounds: ScrapBounds
    upper_bounds: ScrapBounds
    heats: Tuple[HeatInputs, ...]

    @property
    def heat_count(self) -> int:
        return len(self.heats)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class MultipleHeatsOptimizationOutput:
    error: Optional[str]
    first_heat_expected_risk: Optional[ChemRiskLevels] = None
    scrap_weights_per_heat: Tuple[ScrapCharge, ...] = ()
    conditioned_scrap_types_group: Map[str, ScrapType] = Map({})

    @property
    def first_heat_scrap_weights(self) -> ScrapCharge:
        if self.error is None:
            return self.scrap_weights_per_heat[0]
        raise ValueError(
            f"Cannot get first heat scrap weights multiple heat optimization error -> {self.error}"
        )

    # TODO use only one version of these methods - now there will be two for backwards compatibility
    @property
    def first_heat_scrap_weights_result(self) -> Result[ScrapCharge, str]:
        if self.error is None:
            if not self.scrap_weights_per_heat:
                return Failure("Optimization was run for zero heats")
            return Success(self.scrap_weights_per_heat[0])
        return Failure(self.error)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), sort_keys=True)

    @classmethod
    def deserialize(cls, serialized: str) -> "MultipleHeatsOptimizationOutput":
        return deserialize_multiple_heats_optimization_output(serialized)


@lru_cache()
def deserialize_multiple_heats_optimization_output(serialized: str) -> MultipleHeatsOptimizationOutput:
    return converter.structure(json.loads(serialized), MultipleHeatsOptimizationOutput)


T = TypeVar("T")
S = TypeVar("S")


def register_constructor_conversion(
    converter: cattr.Converter, source_type: Type[S], to_target: Callable[[S], T], to_source: Callable[[T], S]
) -> cattr.Converter:
    def unstructure_fn(data: S) -> Any:
        return converter.unstructure(to_target(data))

    def structure_fn(data: T, _: Any) -> S:
        return to_source(data)

    converter.register_unstructure_hook(source_type, unstructure_fn)
    converter.register_structure_hook(source_type, structure_fn)
    return converter


converter = register_constructor_conversion(converter, Map, dict, Map)
converter = register_constructor_conversion(converter, frozenset, tuple, frozenset)
converter = register_constructor_conversion(converter, ScrapMix, str, ScrapMix)
