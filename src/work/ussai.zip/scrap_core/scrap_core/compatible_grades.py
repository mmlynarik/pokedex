from datetime import date
from typing import Collection, Mapping, Tuple, Union

from immutables import Map

from scrap_core import Chem, ScrapType, ScrapMix, ScrapMixMapping
from scrap_core.blendmodel import get_blend_model
from scrap_core.blendmodel.datamodel import ScrapBlendModelInput
from scrap_core.correctiontechnologiesmodel import get_corr_tech_model
from scrap_core.correctiontechnologiesmodel.corr_tech_model import CorrectionTechnologiesModel
from scrap_core.correctiontechnologiesmodel.datamodel import CorrectionTechnologiesModelInput
from usskssgrades.grade import Grade
from usskssgrades.steel_grades_common import ChemLimitsError
from usskssgrades.steel_grades_protocol import SteelGrades
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.datamodel import ModelSettings
from scrap_core.optimization.relaxable_limits import (
    RelaxableRiskLimit,
    RelaxableSummingLimit,
)


def check_scrap_charge_grade_compatibility(
    scrap_charge: Map[ScrapMix, float],
    pig_iron_weight: float,
    pig_iron_chem: RawFeChem,
    steel_grade: Grade,
    model_settings: ModelSettings,
    risk_limits: Map[Chem, float],
) -> bool:
    ct_model: Mapping[Chem, CorrectionTechnologiesModel] = {
        chem: get_corr_tech_model(model_settings.correction_technologies_settings.version, (chem,))
        for chem in model_settings.supported_chems
    }
    blend_model = get_blend_model(model_settings.blend_model_settings.version)
    mix_mapping = model_settings.optimizer_settings.scrap_mix_mapping
    blend_model_input = ScrapBlendModelInput(
        pig_iron_weight, pig_iron_chem, scrap_charge, 0, 0, mix_mapping  # type: ignore
    )
    blend_model_output = blend_model.calculate(blend_model_input)
    corr_techs_model_input = CorrectionTechnologiesModelInput(steel_grade, blend_model_output)
    corr_tech_risks: Mapping[Chem, float] = {
        chem: model.calculate(corr_techs_model_input).undesirable_corr_tech_proba
        for chem, model in ct_model.items()
    }
    return not any(risk_limits[chem] < risk_value for chem, risk_value in corr_tech_risks.items())


def check_grade_compatibility(
    scrap_charge: Map[ScrapMix, float],
    pig_iron_weight: float,
    pig_iron_chem: RawFeChem,
    model_settings: ModelSettings,
    steel_grades: SteelGrades,
    grade_id: int,
    relaxable_risk_limit: RelaxableRiskLimit,
) -> bool:
    try:
        grade = steel_grades.get_grade_from_id(grade_id, date.today())
        ct_risk_allowed_limits = Map(
            {chem: getattr(relaxable_risk_limit, chem).allowed for chem in model_settings.supported_chems}
        )
        return check_scrap_charge_grade_compatibility(
            scrap_charge,
            pig_iron_weight,
            pig_iron_chem,
            grade,
            model_settings,
            ct_risk_allowed_limits,
        )
    except ChemLimitsError:  # No sulfur in risk limits
        # print(f'{grade} | {err}')
        return False


def is_scrap_charge_compatible_with_summing_limits(
    scrap_charge: Map[ScrapMix, float],
    summing_limits: Collection[RelaxableSummingLimit],
    mix_mapping: ScrapMixMapping,
) -> bool:
    return all(
        limit.get_last_relaxation_step().is_current_step_ok(scrap_charge, mix_mapping)
        for limit in summing_limits
    )
