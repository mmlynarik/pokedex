from typing import Any

import attr
from immutables import Map

from .. import values_are_non_negative
from ..blendmodel import ScrapBlendModelOutput, convert_heat_to_scrap_blend_model_output
from ..datamodel import Heat
from usskssgrades import Grade
from .correction_technologies import CorrTechRank, CorrectionTechnologyType


def corr_tech_map_converter(value: Any) -> Map[CorrTechRank, float]:
    return Map({ct_rank: float(val) for ct_rank, val in value.items()})


@attr.s(slots=True, frozen=True)
class CorrectionTechnologiesModelInput:
    grade: Grade = attr.ib()
    eob_chem: ScrapBlendModelOutput = attr.ib()


@attr.s(slots=True, frozen=True)
class CorrectionTechnologiesModelOutput:
    correction_technologies_probas: Map[CorrTechRank, float] = attr.ib(
        converter=corr_tech_map_converter, validator=[values_are_non_negative]
    )

    @property
    def reblow_proba(self) -> float:
        return self.correction_technologies_probas.get((CorrectionTechnologyType.REBLOW, 1.0), 0.0)

    @property
    def reclass_proba(self) -> float:
        return self.correction_technologies_probas.get((CorrectionTechnologyType.RECLASSIFICATION, 1.0), 0.0)

    @property
    def ok_proba(self) -> float:
        return self.correction_technologies_probas.get((CorrectionTechnologyType.NO_CORRECTION, 1.0), 0.0)

    @property
    def synt_slag_proba(self) -> float:
        return 1 - self.ok_proba - self.reblow_proba - self.reclass_proba

    @property
    def undesirable_corr_tech_proba(self) -> float:
        return self.correction_technologies_probas.get(
            (CorrectionTechnologyType.REBLOW, 1.0), 0.0
        ) + self.correction_technologies_probas.get((CorrectionTechnologyType.RECLASSIFICATION, 1.0), 0.0)


def convert_heat_to_corr_tech_model_input(heat: Heat) -> CorrectionTechnologiesModelInput:
    return CorrectionTechnologiesModelInput(
        grade=heat.grade_planned, eob_chem=convert_heat_to_scrap_blend_model_output(heat)
    )


def convert_heat_to_corr_tech_model_output(heat: Heat) -> CorrectionTechnologiesModelOutput:
    return CorrectionTechnologiesModelOutput(
        {
            (CorrectionTechnologyType.SYNT_SLAG, heat.synt_slag): 1.0,
            (CorrectionTechnologyType.REBLOW, float(heat.extra_o2 > 0)): 1.0,
            (CorrectionTechnologyType.RECLASSIFICATION, float(heat.grade_planned != heat.grade_final)): 1.0,
        }
    )
