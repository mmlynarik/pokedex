from enum import Enum, unique
from typing import Dict, Iterable, Iterator, List, Tuple, Optional
from functools import lru_cache, total_ordering

import attr
from scrap_core import Chem

from ..blendmodel import ScrapBlendModelOutput
from usskssgrades import Grade


@unique
@total_ordering
class CorrectionTechnologyType(Enum):
    """
    IMPORTANT: Order of correction technology types below is crucial
    for code in `corr_tech_probabilities.py` to work. Types are sorted
    according to desirability - NO_CORRECTION with index 0 is the most
    desirable correction technology, RECLASSIFICATION with index 3 is
    the worst.
    """

    NO_CORRECTION = "NO_CORRECTION"
    SYNT_SLAG = "SYNT_SLAG"
    REBLOW = "REBLOW"
    RECLASSIFICATION = "RECLASSIFICATION"

    @classmethod
    def index(cls, corr_tech_type) -> int:
        return list(cls).index(corr_tech_type)

    def __lt__(self, other) -> bool:
        return self.__class__.index(self) <= self.__class__.index(other)


# Correction Technology rank is just a tuple of the form (corr tech type, corr tech value).
# This way we can combine corresponding correction technologies originated from different chems.
CorrTechRank = Tuple[CorrectionTechnologyType, float]


def correction_technology_limit_converter(value) -> float:
    return round(value, 5)


# We need to use rounding for numerical stability
@attr.s(auto_attribs=True, slots=True, frozen=True)
class CorrectionTechnology:
    reason: Chem = attr.ib(converter=str)
    lower_limit: float = attr.ib(converter=correction_technology_limit_converter)
    upper_limit: float = attr.ib(converter=correction_technology_limit_converter)
    type: CorrectionTechnologyType = attr.ib()
    value: float = attr.ib(default=1.0, converter=float)

    def get_probability(self, model_output: ScrapBlendModelOutput) -> float:
        estimate = model_output.get_chem_estimate(self.reason)
        return estimate.cdf(self.upper_limit) - estimate.cdf(self.lower_limit)

    @property
    def rank(self) -> CorrTechRank:
        return (self.type, self.value)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class CorrectionTechnologies:
    S: Tuple[CorrectionTechnology, ...]
    Cu: Tuple[CorrectionTechnology, ...]
    Ni: Tuple[CorrectionTechnology, ...]
    Cr: Tuple[CorrectionTechnology, ...]
    Mo: Tuple[CorrectionTechnology, ...]
    Sn: Tuple[CorrectionTechnology, ...]
    Si: Tuple[CorrectionTechnology, ...]

    def get_chem(self, chem: Chem) -> Tuple[CorrectionTechnology, ...]:
        chem_lower = chem.lower()
        if chem_lower == "s":
            return self.S
        if chem_lower == "cu":
            return self.Cu
        if chem_lower == "ni":
            return self.Ni
        if chem_lower == "cr":
            return self.Cr
        if chem_lower == "mo":
            return self.Mo
        if chem_lower == "sn":
            return self.Sn
        if chem_lower == "si":
            return self.Si
        raise Exception(f"Unknown chem {chem}")

    def get_corr_tech_ranks(self, predicted_chems: Iterable[Chem]) -> List[CorrTechRank]:
        """
        Return corr tech ranks for all correction technologies for given predicted chems
        in increasing order. The order is crucial for vectorized operations to works as expected.
        """
        return sorted(set(ct.rank for chem in predicted_chems for ct in self.get_chem(chem)))

    def get_no_correction_ct_for_chem(self, chem: Chem) -> Optional[CorrectionTechnology]:
        for ct in self.get_chem(chem):
            if ct.type == CorrectionTechnologyType.NO_CORRECTION:
                return ct
        return None

    def get_reblow_ct_for_chem(self, chem: Chem) -> Optional[CorrectionTechnology]:
        for ct in self.get_chem(chem):
            if ct.type == CorrectionTechnologyType.REBLOW:
                return ct
        return None

    def get_reclass_ct_for_chem(self, chem: Chem) -> Optional[CorrectionTechnology]:
        for ct in self.get_chem(chem):
            if ct.type == CorrectionTechnologyType.RECLASSIFICATION:
                return ct
        return None


SI_DOPED_1_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s,
    upper_limit=max_s + 0.001,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=800.0,
)
SI_DOPED_2_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.001,
    upper_limit=max_s + 0.002,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=1300.0,
)
SI_DOPED_3_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.002,
    upper_limit=max_s + 0.003,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=1700.0,
)
SI_DOPED_4_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.003,
    upper_limit=max_s + 0.004,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=2000.0,
)
NOT_SI_DOPED_1_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s,
    upper_limit=max_s + 0.001,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=1000.0,
)
NOT_SI_DOPED_2_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.001,
    upper_limit=max_s + 0.002,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=1500.0,
)
NOT_SI_DOPED_3_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.002,
    upper_limit=max_s + 0.003,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=1800.0,
)
NOT_SI_DOPED_4_POINT_S_ERROR = lambda max_s: CorrectionTechnology(
    reason="S",
    lower_limit=max_s + 0.003,
    upper_limit=max_s + 0.004,
    type=CorrectionTechnologyType.SYNT_SLAG,
    value=2100.0,
)
REBLOW_S_ERROR = lambda min_s, max_s: CorrectionTechnology(
    reason="S",
    lower_limit=min_s,
    upper_limit=max_s,
    type=CorrectionTechnologyType.REBLOW,
)
REBLOW_ERROR = lambda reason, min_value: CorrectionTechnology(
    reason=reason,
    lower_limit=min_value,
    upper_limit=float("inf"),
    type=CorrectionTechnologyType.REBLOW,
)
RECLASSIFICATION_ERROR = lambda reason, min_value: CorrectionTechnology(
    reason=reason,
    lower_limit=min_value,
    upper_limit=float("inf"),
    type=CorrectionTechnologyType.RECLASSIFICATION,
)


# SEE OPrP-AE-0037 page 18
CASTING_SPEED_S_CORRECTIONS: List[CorrectionTechnology] = [
    CorrectionTechnology(
        reason="S", lower_limit=0.015, upper_limit=0.017, type=CorrectionTechnologyType.SYNT_SLAG, value=800
    ),
    CorrectionTechnology(
        reason="S", lower_limit=0.017, upper_limit=0.018, type=CorrectionTechnologyType.SYNT_SLAG, value=1000
    ),
    CorrectionTechnology(
        reason="S", lower_limit=0.018, upper_limit=0.02, type=CorrectionTechnologyType.SYNT_SLAG, value=1800
    ),
    CorrectionTechnology(
        reason="S",
        lower_limit=0.02,
        upper_limit=float("inf"),
        type=CorrectionTechnologyType.SYNT_SLAG,
        value=2000,
    ),
]


def refine_synt_slag_corrections(
    corrections: List[CorrectionTechnology], upper_bound: float = float("inf")
) -> Iterator[CorrectionTechnology]:
    """
    Helper function that converts overlapping synt slag corrections into
    list of disjoint corrections. Moreover, it is possible to exclude some
    corrections from result using `upper_bound` parameter.
    """
    # For simplicity, the function does not support other correction technologies than SYNT_SLAG.
    # However, it would not be difficult to extend its logic to support other types if needed,
    # provided that some precedence of correction technologies is given. For example
    # NO_CORRECTION < SYNT_SLAG < REBLOW < RECLASSIFICATION. By the way, this precedence is
    # already assumed (implemented) in `combine_correction_technologies` function.
    unsupported_corrs = [corr for corr in corrections if corr.type != CorrectionTechnologyType.SYNT_SLAG]
    if unsupported_corrs:
        raise ValueError(f"Only `SYNT_SLAG` corrections are supported, got {unsupported_corrs}.")

    # Put all limit points together.
    all_points = set(corr.lower_limit for corr in corrections) | set(corr.upper_limit for corr in corrections)

    # Notice that `upper_bound` may not be included in `points` list.
    points = sorted(p for p in all_points if p <= upper_bound)

    for idx in range(len(points) - 1):
        left = points[idx]
        right = points[idx + 1]
        # For given interval (left, right) gather all corrections which cover this interval.
        covering_corrections = (
            corr for corr in corrections if corr.lower_limit <= left and right <= corr.upper_limit
        )
        refined_correction = CorrectionTechnology(
            reason="S",
            lower_limit=left,
            upper_limit=right,
            type=CorrectionTechnologyType.SYNT_SLAG,
            value=sum(corr.value for corr in covering_corrections),
        )
        yield refined_correction


def get_synt_slag_correction_for_grade(grade: Grade) -> List[CorrectionTechnology]:
    if not grade.is_calmed:
        return []

    max_s = grade.max_s
    if max_s <= 0:
        raise Exception(f"Invalid grade {grade}")

    if grade.is_si_doped:
        if 0.0 < max_s <= 0.0124:
            desufl_corrections = [SI_DOPED_1_POINT_S_ERROR(max_s), SI_DOPED_2_POINT_S_ERROR(max_s)]
        else:
            desufl_corrections = [
                SI_DOPED_1_POINT_S_ERROR(max_s),
                SI_DOPED_2_POINT_S_ERROR(max_s),
                SI_DOPED_3_POINT_S_ERROR(max_s),
                SI_DOPED_4_POINT_S_ERROR(max_s),
            ]
    else:
        if 0.0 < max_s <= 0.0064:
            desufl_corrections = [NOT_SI_DOPED_1_POINT_S_ERROR(max_s)]
        elif 0.0064 < max_s <= 0.0124:
            desufl_corrections = [NOT_SI_DOPED_1_POINT_S_ERROR(max_s), NOT_SI_DOPED_2_POINT_S_ERROR(max_s)]
        else:
            desufl_corrections = [
                NOT_SI_DOPED_1_POINT_S_ERROR(max_s),
                NOT_SI_DOPED_2_POINT_S_ERROR(max_s),
                NOT_SI_DOPED_3_POINT_S_ERROR(max_s),
            ]

    synt_slag_corrections = desufl_corrections + CASTING_SPEED_S_CORRECTIONS
    # Since NO_CORRECTION < SYNT_SLAG < REBLOW < RECLASSIFICATION, and we don't want to
    # use synt slag for speed when REBLOW or RECLASSIFICATION should be applied,
    # we narrow the interval where SYNT_SLAG is applicable with `upper_bound` parameter.
    upper_bound = max(corr.upper_limit for corr in desufl_corrections)
    refined_corrections = refine_synt_slag_corrections(synt_slag_corrections, upper_bound)

    return list(refined_corrections)


def get_s_reblow_correction_for_grade(grade: Grade) -> CorrectionTechnology:
    max_s = grade.max_s
    if grade.is_calmed:
        if grade.is_si_doped:
            if 0.0 < max_s <= 0.0124:
                return REBLOW_S_ERROR(max_s + 0.002, max_s + 0.004)
            if max_s > 0.0124:
                return REBLOW_S_ERROR(max_s + 0.004, max_s + 0.008)
        else:
            if 0.0 < max_s <= 0.0064:
                return REBLOW_S_ERROR(max_s + 0.001, max_s + 0.003)
            if 0.0064 < max_s <= 0.0124:
                return REBLOW_S_ERROR(max_s + 0.002, max_s + 0.004)
            if max_s > 0.0124:
                return REBLOW_S_ERROR(max_s + 0.003, max_s + 0.007)
    else:
        if 0.0 < max_s <= 0.0064:
            return REBLOW_S_ERROR(max_s, max_s + 0.002)
        if 0.0064 < max_s <= 0.0124:
            return REBLOW_S_ERROR(max_s, max_s + 0.003)
        if max_s > 0.0124:
            return REBLOW_S_ERROR(max_s, max_s + 0.004)
    raise Exception(f"Invalid grade {grade}")


def get_s_reclassification_correction_for_grade(grade: Grade) -> CorrectionTechnology:
    max_s = grade.max_s
    if grade.is_calmed:
        if grade.is_si_doped:
            if 0.0 < max_s <= 0.0124:
                if grade.has_reblow_disallowed:
                    return RECLASSIFICATION_ERROR("S", max_s + 0.002)
                return RECLASSIFICATION_ERROR("S", max_s + 0.004)
            if max_s > 0.0124:
                if grade.has_reblow_disallowed:
                    return RECLASSIFICATION_ERROR("S", max_s + 0.004)
                return RECLASSIFICATION_ERROR("S", max_s + 0.008)
        else:
            if 0.0 < max_s <= 0.0064:
                if grade.has_reblow_disallowed:
                    return RECLASSIFICATION_ERROR("S", max_s + 0.001)
                return RECLASSIFICATION_ERROR("S", max_s + 0.003)
            if 0.0064 < max_s <= 0.0124:
                if grade.has_reblow_disallowed:
                    return RECLASSIFICATION_ERROR("S", max_s + 0.002)
                return RECLASSIFICATION_ERROR("S", max_s + 0.004)
            if max_s > 0.0124:
                if grade.has_reblow_disallowed:
                    return RECLASSIFICATION_ERROR("S", max_s + 0.003)
                return RECLASSIFICATION_ERROR("S", max_s + 0.007)
    else:
        if grade.has_reblow_disallowed:
            return RECLASSIFICATION_ERROR("S", max_s)
        if 0.0 < max_s <= 0.0064:
            return RECLASSIFICATION_ERROR("S", max_s + 0.002)
        if 0.0064 < max_s <= 0.0124:
            return RECLASSIFICATION_ERROR("S", max_s + 0.003)
        if max_s > 0.0124:
            return RECLASSIFICATION_ERROR("S", max_s + 0.004)
    raise Exception(f"Invalid grade {grade}")


def get_s_correction_technologies_for_grade(grade: Grade) -> Tuple[CorrectionTechnology, ...]:
    s_limit = grade.get_limit("S")
    if s_limit is None:
        raise Exception(f"Cannot calculate correction technologies for S for grade without S limit. {grade}")
    s_max = s_limit.maximum

    # Get all synt slag corrections - desulf and speed.
    synt_slag_corrections = get_synt_slag_correction_for_grade(grade)
    # Since we may want to use synt slag for speed even in case when no other correction is needed,
    # we must alter `no_correction_upper_limit` a bit.
    no_correction_upper_limit = min((corr.lower_limit for corr in synt_slag_corrections), default=s_max)
    if grade.has_reblow_disallowed:
        return (
            CorrectionTechnology(
                reason="S",
                lower_limit=float("-inf"),
                upper_limit=no_correction_upper_limit,
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
            *synt_slag_corrections,
            get_s_reclassification_correction_for_grade(grade),
        )
    return (
        CorrectionTechnology(
            reason="S",
            lower_limit=float("-inf"),
            upper_limit=no_correction_upper_limit,
            type=CorrectionTechnologyType.NO_CORRECTION,
        ),
        *synt_slag_corrections,
        get_s_reblow_correction_for_grade(grade),
        get_s_reclassification_correction_for_grade(grade),
    )


def get_p_correction_technologies_for_grade(
    grade: Grade,
) -> Tuple[CorrectionTechnology, CorrectionTechnology]:
    p_limit = grade.get_limit("P_blow")
    if p_limit is None:
        raise Exception(
            f"Cannot calculate correction technologies for P for grade without P_blow limit. {grade}"
        )
    p_max = p_limit.maximum
    return (
        CorrectionTechnology(
            reason="P",
            lower_limit=float("-inf"),
            upper_limit=p_max,
            type=CorrectionTechnologyType.NO_CORRECTION,
        ),
        REBLOW_ERROR("P", p_max),
    )


def get_cr_correction_technologies_for_grade(
    grade: Grade,
) -> Tuple[CorrectionTechnology, ...]:
    cr_limit = grade.get_limit("Cr")
    if cr_limit is None:
        return (
            CorrectionTechnology(
                reason="Cr",
                lower_limit=float("-inf"),
                upper_limit=float("inf"),
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
        )
    cr_max = cr_limit.maximum - 0.005  # OPrP-AE-0037, p. 14, section 6.5

    if grade.has_reblow_disallowed:
        return (
            CorrectionTechnology(
                reason="Cr",
                lower_limit=float("-inf"),
                upper_limit=cr_max,
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
            RECLASSIFICATION_ERROR("Cr", cr_max),
        )
    return (
        CorrectionTechnology(
            reason="Cr",
            lower_limit=float("-inf"),
            upper_limit=cr_max,
            type=CorrectionTechnologyType.NO_CORRECTION,
        ),
        REBLOW_ERROR("Cr", cr_max),
    )


def get_no_correction_technologies_for_grade(grade: Grade, chem: Chem) -> Tuple[CorrectionTechnology, ...]:
    chem_limit = grade.get_limit(chem)
    if chem_limit is None:
        return (
            CorrectionTechnology(
                reason=chem,
                lower_limit=float("-inf"),
                upper_limit=float("inf"),
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
        )
    chem_max = chem_limit.maximum
    return (
        CorrectionTechnology(
            reason=chem,
            lower_limit=float("-inf"),
            upper_limit=chem_max,
            type=CorrectionTechnologyType.NO_CORRECTION,
        ),
        RECLASSIFICATION_ERROR(chem, chem_max),
    )


def get_reblow_correction_technologies_for_grade(
    grade: Grade, chem: Chem
) -> Tuple[CorrectionTechnology, ...]:
    chem_limit = grade.get_limit(chem)
    if chem_limit is None:
        return (
            CorrectionTechnology(
                reason=chem,
                lower_limit=float("-inf"),
                upper_limit=float("inf"),
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
        )
    chem_max = chem_limit.maximum
    if grade.has_reblow_disallowed:
        return (
            CorrectionTechnology(
                reason=chem,
                lower_limit=float("-inf"),
                upper_limit=chem_max,
                type=CorrectionTechnologyType.NO_CORRECTION,
            ),
            RECLASSIFICATION_ERROR(chem, chem_max),
        )
    return (
        CorrectionTechnology(
            reason=chem,
            lower_limit=float("-inf"),
            upper_limit=chem_max,
            type=CorrectionTechnologyType.NO_CORRECTION,
        ),
        REBLOW_ERROR(chem, chem_max),
    )


@lru_cache(maxsize=10000)
def get_correction_technologies_for_grade(grade: Grade) -> CorrectionTechnologies:
    return CorrectionTechnologies(
        S=get_s_correction_technologies_for_grade(grade),
        Cu=get_no_correction_technologies_for_grade(grade, "Cu"),
        Ni=get_no_correction_technologies_for_grade(grade, "Ni"),
        Cr=get_cr_correction_technologies_for_grade(grade),
        Mo=get_no_correction_technologies_for_grade(grade, "Mo"),
        Sn=get_no_correction_technologies_for_grade(grade, "Sn"),
        Si=get_reblow_correction_technologies_for_grade(grade, "Si"),
    )


@lru_cache(maxsize=1024)
def get_undesirable_max(grade: Grade, chems: Tuple[Chem, ...]) -> Dict[Chem, float]:
    all_corr_techs = get_correction_technologies_for_grade(grade)
    all_maxes = {}
    for chem in chems:
        ctts = all_corr_techs.get_chem(chem)
        reblow = [x.lower_limit for x in ctts if x.type == CorrectionTechnologyType.REBLOW]
        reclass = [x.lower_limit for x in ctts if x.type == CorrectionTechnologyType.RECLASSIFICATION]
        all_maxes[chem] = max(reblow) if reblow else max(reclass)
    return all_maxes


def remaining_chem_weights(
    reference: ScrapBlendModelOutput,
    reference_input_weight: float,
    final_wanted_weight: float,
    grade: Grade,
    chems: Tuple[Chem, ...],
    approx_percentile: float,
) -> Dict[Chem, float]:
    """
    This function tries to approximate total weight of chem that can be added from scrap
    before we hit undesirable correction technology
    """
    undesirable_maxes = get_undesirable_max(grade, chems)

    all_remaining_weights = {}
    for chem in chems:
        zero_w = reference.get_chem_estimate(chem).total_chem_weight(
            reference_input_weight, approx_percentile
        )
        all_remaining_weights[chem] = ((undesirable_maxes[chem] / 100) * final_wanted_weight) - zero_w

    return all_remaining_weights
