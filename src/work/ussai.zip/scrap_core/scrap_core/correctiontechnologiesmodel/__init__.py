from functools import lru_cache

from scrap_core.correctiontechnologiesmodel.corr_tech_model import (
    CorrectionTechnologiesModel,
    CorrectionTechnologiesModelSettings,
)
from scrap_core.correctiontechnologiesmodel.correction_technologies import CorrectionTechnologyType
from scrap_core.correctiontechnologiesmodel.datamodel import (
    CorrectionTechnologiesModelInput,
    CorrectionTechnologiesModelOutput,
    convert_heat_to_corr_tech_model_input,
)


@lru_cache(maxsize=32)
def get_corr_tech_model(version: int, *args, **kwargs) -> CorrectionTechnologiesModel:
    if version == 1:
        return CorrectionTechnologiesModel(*args, **kwargs)
    raise Exception(f"Invalid model version {version} - valid versions are: [1]")
