"""
FYI cdf and pmf are abbreviations for cumulative distribution function and probability mass function,
 respectively. For more info see
    - https://en.wikipedia.org/wiki/Probability_mass_function
    - https://en.wikipedia.org/wiki/Cumulative_distribution_function

Assumptions:
    - We assume that ammounts of different chems in heat are independent. Consequently,
     correction technologies needed for different chems are independent too,
     and we can calculate "joint" probabilities as products.

        P(CT_Cu <= ct, ..., CT_S <= ct) == P(CT_Cu <= ct) *  ... * P(CT_S <= ct),

    where CT_<chem> <= ct means that correction technology needed for <chem> is at most ct.

    - We assume that correction technologies can be linearly ordered based on their desirability.
    For example, 500 kg of synthetic slag is better than 1000 kg of synthetic slag
    and "every" amount of synthetic slag is better than reblow.

Pseudocode (for 1 model output only):
    1. Calculate pmfs for all chems.
    2. Extend pmfs so they have the same domain.
    3. Convert pmfs to cdfs.
    4. Calculate "joint"-like diagonal cdf for model output as product of cdfs for chems
     (thanks to independence assumption).
    5. Convert cdf for model output to pmf.
    6. Add minimal synth slag, if needed.

Example (for 1 model output only, steps are the same as in pseudocode above, the last one is ommited):
    For symplicity suppose that we estimate 2 chemicals - Cu and S - and there are
    3 different correction technologies NO_CORRECTION < SYNT_SLAG < REBLOW available.

    S estimate  | >= 0          | >= 0.01   | >= 0.05 |
    corr_tech   | NO_CORRECTION | SYNT_SLAG | REBLOW  |

    Cu estimate | >= 0          | >= 0.07   |
    corr_tech   | NO_CORRECTION | REBLOW    |

    Step 1: (calculate pmfs) Let's suppose that S and Cu estimates are such that
    the corresponding pmfs are the following

    pmf_S = {NO_CORRECTION: 0.5, SYNT_SLAG: 0.4, REBLOW: 0.1}
    pmf_Cu = {NO_CORRECTION: 0.6, REBLOW: 0.4}

    Step 2: (extend pmfs) Augmented correction technologies have probability 0.

    pmf_S = {NO_CORRECTION: 0.5, SYNT_SLAG: 0.4, REBLOW: 0.1}
    pmf_Cu = {NO_CORRECTION: 0.6, SYNT_SLAG: 0, REBLOW: 0.4}

    Step 3: (pmfs -> cdfs) cdf[ct] = sum(pmf[x] for x <= ct)

    cdf_S = {NO_CORRECTION: 0.5, SYNT_SLAG: 0.9, REBLOW: 1}
    cdf_Cu = {NO_CORRECTION: 0.6, SYNT_SLAG: 0.6, REBLOW: 1}

    Step 4: (calculate diagonal cdf) cdf[ct] = cdf_S[ct] * cdf_Cu[ct]

    cdf = {NO_CORRECTION: 0.3, SYNT_SLAG: 0.54, REBLOW: 1}

    Step 5: (cdf -> pmf) pmf[ct] = cdf[ct] - cdf[prev ct]

    pmf = {NO_CORRECTION: 0.3, SYNT_SLAG: 0.24, REBLOW: 0.46}
"""

from typing import Dict, Iterable, List, Optional, Union

import numpy as np
from scrap_core import Chem
import torch

from ..blendmodel import ScrapBlendModelOutput
from .correction_technologies import (
    CorrTechRank,
    get_correction_technologies_for_grade,
    CorrectionTechnologies,
)
from usskssgrades import Grade


def extend_pmf(pmf: dict, domain: Iterable) -> dict:
    """Add items from `domain` parameter to `pmf` function. All new items will have probability 0."""
    return {**{x: 0 for x in domain}, **pmf}


def cdf_to_pmf_vectorized(cdfs: Union[np.ndarray, torch.Tensor]) -> Union[np.ndarray, torch.Tensor]:
    """Convert cumulative distribution functions to probability mass functions."""
    # Remove the last column and prepend new column with 0s.
    previous = np.insert(cdfs[:, :-1], 0, 0, axis=1)  # type: ignore[call-overload]
    # Calculate differences between consecutive columns in cdfs matrix, i.e.
    # cdfs[:, j] - previous[:, j] = cdfs[:, j] - cdfs[:, j - 1].
    return cdfs - previous


def pmf_to_cdf_vectorized(
    pmfs: Union[np.ndarray, torch.Tensor], axis: Optional[int] = None
) -> Union[np.ndarray, torch.Tensor]:
    """Convert probability mass functions to cumulative distribution functions."""
    return np.cumsum(pmfs, axis)


def get_corr_tech_pmf_for_chem(
    chem: Chem,
    model_output: ScrapBlendModelOutput,
    corr_techs: CorrectionTechnologies,
) -> Dict[CorrTechRank, float]:
    """
    Get probability mass function of corr tech ranks for given model output and chem, i.e.

    pmf[ct] == P(corr tech ct is applied).
    """
    corr_techs_for_chem = corr_techs.get_chem(chem)
    chem_estimate = model_output.get_chem_estimate(chem)

    # Calculate probability mass function for given correction technologies and given chem estimate.
    lower_limits = torch.Tensor([ct.lower_limit for ct in corr_techs_for_chem])
    upper_limits = torch.Tensor([ct.upper_limit for ct in corr_techs_for_chem])
    values = chem_estimate.cdf_unsafe(upper_limits) - chem_estimate.cdf_unsafe(lower_limits)
    pmf = dict(zip(corr_techs_for_chem, values))

    # Replace correction technology keys with their ranks.
    pmf_with_ranks = {ct.rank: prob for ct, prob in pmf.items()}

    return pmf_with_ranks


def get_corr_tech_probabilities(
    model_outputs: List[ScrapBlendModelOutput], grade: Grade, predicted_chems: Iterable[Chem]
) -> List[Dict[CorrTechRank, float]]:
    """
    Get "joint"-like diagonal distributions of corr tech ranks for given model outputs and grade.

    Each member of `cdfs_per_model_output` list is a "diagonal" cdf, i.e.

    cdf[ct] == P(CT_Cu <= ct, ..., CT_S <= ct),

    where CT_<chem> is corr tech applied to given model output.
    """
    corr_techs = get_correction_technologies_for_grade(grade)
    ct_ranks = sorted(corr_techs.get_corr_tech_ranks(predicted_chems))

    pmfs_per_chem_per_model_output = []

    for model_output in model_outputs:
        pmfs = [get_corr_tech_pmf_for_chem(chem, model_output, corr_techs) for chem in predicted_chems]

        # Extend pmfs to common domain.
        extended_pmfs = [extend_pmf(pmf, ct_ranks) for pmf in pmfs]

        # Drop keys in order to be able to do vectorized calculations.
        # Since `ct_ranks` are ordered, we will be able to add them back later.
        # See `pmfs_as_dicts` below.
        pmfs_vectorized = [[pmf[ct_rank] for ct_rank in ct_ranks] for pmf in extended_pmfs]

        pmfs_per_chem_per_model_output.append(pmfs_vectorized)

    # Convert pmfs to distributions,
    # where `pmfs_per_chem_per_model_output` is 3 dimensional matrix
    # of the form [[pmf_Cu, ..., pmf_S] for each model output].
    cdfs_per_chem_per_model_output = pmf_to_cdf_vectorized(np.array(pmfs_per_chem_per_model_output), axis=2)
    # Here `cdfs_per_chem_per_model_output`is 3 dimensional matrix
    # of the form [[cdf_Cu, ..., cdf_S] for each model output].

    # Calculate products of chem distributions per each model output.
    cdfs_per_model_output = np.prod(cdfs_per_chem_per_model_output, axis=1)
    # Here `cdfs_per_model_output` is 2 dimensional matrix of the form
    # [cdf for each model output], where cdf = cdf_Cu * ... * cdf_S, for each model output.

    # Convert distributions to pmfs.
    pmfs_per_model_output = cdf_to_pmf_vectorized(cdfs_per_model_output)

    # Join ranks and pmfs.
    pmfs_as_dicts = [dict(zip(ct_ranks, pmf)) for pmf in pmfs_per_model_output]

    return pmfs_as_dicts
