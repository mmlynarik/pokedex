# pylint: disable=no-member
from collections import defaultdict
from typing import Callable, Iterable, List, Mapping, Optional, Sequence, Tuple

import attr
import torch
from scrap_core import (
    SUPPORTED_CHEMS,
    Chem,
    aggregate_tensor_results,
    get_sequence_of_tensors_to_tensor_selector,
    has_no_duplicates,
    is_subset_of,
    must_be_value,
    run_by_group,
)
from scrap_core.correctiontechnologiesmodel.corr_tech_probabilities_v2 import (
    get_corr_tech_probabilities,
    get_corr_tech_probabilities_fast,
)
from scrap_core.correctiontechnologiesmodel.datamodel import (
    CorrectionTechnologiesModelInput,
    CorrectionTechnologiesModelOutput,
)
from usskssgrades import Grade

EobProba = Mapping[Chem, torch.Tensor]


@attr.s(slots=True, frozen=True)
class CorrectionTechnologiesModelSettings:
    chems_for_correction_technologies: Tuple[Chem, ...] = attr.ib(
        # When "Si" is removed from default optimization starts to act wierdly
        # TODO find out why and fix probable bug
        default=("Cr", "Cu", "Mo", "Ni", "S", "Sn", "Si"),
        converter=tuple,
        validator=[has_no_duplicates, is_subset_of(SUPPORTED_CHEMS)],
    )
    version: int = attr.ib(default=1, validator=must_be_value(1), converter=int)


# TODO when v2 of blend model is approved, and hence all version 1 functionality is removed,
#   then make the `fill_binning_map` attribute required
class CorrectionTechnologiesModel:
    def __init__(
        self, predicted_chems: Iterable[Chem], full_binning_map: Optional[Mapping[Chem, torch.Tensor]] = None
    ):
        # Remove duplicates, if any.
        self.predicted_chems = tuple(frozenset(predicted_chems))
        self.full_binning_map = full_binning_map

    def calculate(self, input_data: CorrectionTechnologiesModelInput) -> CorrectionTechnologiesModelOutput:
        probas = get_corr_tech_probabilities([input_data.eob_chem], input_data.grade, self.predicted_chems)

        return CorrectionTechnologiesModelOutput(probas[0])

    def calculate_batch(
        self, input_data: List[CorrectionTechnologiesModelInput]
    ) -> List[CorrectionTechnologiesModelOutput]:
        model_outputs = [one_heat.eob_chem for one_heat in input_data]

        grades = set(one_heat.grade for one_heat in input_data)

        # We expect all heats in `input_data` batch to have the same grade.
        if len(grades) != 1:
            if not grades:
                # Whenever input is empty, the output is empty, too.
                return []

            raise ValueError(
                f"Batch with multiple grades is not supported. "
                f"Expected 1 common grade, got {grades} instead."
            )

        grade = input_data[0].grade

        results = get_corr_tech_probabilities(model_outputs, grade, self.predicted_chems)

        return [CorrectionTechnologiesModelOutput(probas) for probas in results]

    def calculate_batch_for_multiple_grades(
        self, input_data: List[CorrectionTechnologiesModelInput]
    ) -> List[CorrectionTechnologiesModelOutput]:
        groups = defaultdict(list)
        for cmi in input_data:
            groups[cmi.grade].append(cmi.eob_chem)
        results = {
            grade: get_corr_tech_probabilities(chems, grade, self.predicted_chems)
            for grade, chems in groups.items()
        }
        return [CorrectionTechnologiesModelOutput(results[cmi.grade].pop(0)) for cmi in input_data]

    def calculate_batch_fast(self, eob_proba_matrix_map: EobProba, grade: Grade) -> torch.Tensor:
        if self.full_binning_map is None:
            raise ValueError("In order to use fast calculations you need to provide `full_binning_map`")

        corr_tech_pmfs = get_corr_tech_probabilities_fast(
            eob_proba_matrix_map, self.full_binning_map, grade, self.predicted_chems
        )

        return corr_tech_pmfs

    def calculate_batch_fast_for_multiple_grades(
        self, eob_proba_matrix_map: EobProba, grade_ids: torch.LongTensor, grades_mapping: Mapping[int, Grade]
    ) -> Sequence[torch.Tensor]:
        return run_by_group(
            grade_ids,
            get_eob_proba_matrix_map_selector(eob_proba_matrix_map),
            get_corr_tech_calculator(self, grades_mapping),
            different_sizes_tensor_aggregation,
        )


def get_undesirable_corr_tech_proba_for_multiple_grades(
    corr_techs: Sequence[torch.Tensor],
    grade_ids: torch.LongTensor,
    undesirable_cols_mapping: Mapping[int, torch.LongTensor],
) -> torch.Tensor:
    return run_by_group(
        grade_ids,
        get_sequence_of_tensors_to_tensor_selector(corr_techs),
        get_undesirable_corr_tech_calculator(undesirable_cols_mapping),
        aggregate_tensor_results,
    )


def different_sizes_tensor_aggregation(
    results: List[torch.Tensor], orig_order: torch.LongTensor
) -> List[torch.Tensor]:
    decomposed_results = []
    for result in results:
        decomposed_results.extend(list(result))
    return [decomposed_results[i] for i in orig_order]


def get_eob_proba_matrix_map_selector(
    eob_proba_matrix_map: EobProba,
) -> Callable[[torch.LongTensor], EobProba]:
    def eob_proba_matrix_map_selector(selected_indexes: torch.LongTensor) -> EobProba:
        return {chem: probas[selected_indexes] for chem, probas in eob_proba_matrix_map.items()}

    return eob_proba_matrix_map_selector


def get_corr_tech_calculator(
    model: CorrectionTechnologiesModel, grades_mapping: Mapping[int, Grade]
) -> Callable[[int, EobProba], torch.Tensor]:
    def calculator(grade_id: int, eob_probas: EobProba) -> torch.Tensor:
        return model.calculate_batch_fast(eob_probas, grades_mapping[grade_id])

    return calculator


def get_undesirable_corr_tech_calculator(
    undesirable_cols_mapping: Mapping[int, torch.LongTensor]
) -> Callable[[int, torch.Tensor], torch.Tensor]:
    def calculator(grade_id: int, corr_techs: torch.Tensor) -> torch.Tensor:
        undiserable_corr_tech_cols = undesirable_cols_mapping[grade_id]
        return corr_techs[:, undiserable_corr_tech_cols].sum(axis=1)  # type: ignore

    return calculator
