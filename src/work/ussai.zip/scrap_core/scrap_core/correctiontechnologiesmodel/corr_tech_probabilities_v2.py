# pylint: disable=no-member
"""
IMPORTANT: Due to vectorized operations on data order of elements in input lists and tuples is crucial.
"""
import functools
from typing import Dict, List, Mapping, Tuple

import numpy as np
from scrap_core import Chem
import torch

from ..blendmodel import ScrapBlendModelOutput
from ..blendmodel.datamodel import cdf_batch, get_full_binning
from usskssgrades import Grade
from .corr_tech_probabilities import cdf_to_pmf_vectorized
from .correction_technologies import (
    CorrectionTechnology,
    CorrTechRank,
    get_correction_technologies_for_grade,
)

# Utility functions


def generalized_hadamard_product(vectors: List[torch.Tensor]) -> torch.Tensor:
    """
    Element-wise product of batches of vectors.
    """
    operands = ",".join("bi" for _ in range(len(vectors)))
    return torch.einsum(f"{operands} -> bi", *vectors)


# Corr Tech functions


@functools.lru_cache(maxsize=2**8)
def get_extended_corr_techs_for_chem(
    grade: Grade, predicted_chems: Tuple[Chem, ...], chem: Chem
) -> Tuple[CorrectionTechnology, ...]:
    """
    Return tuple of correction technologies for given chem
    such that corresponding ranks are the same as all ranks
    for all correction technologies for given grade together.
    """
    corr_techs_all = get_correction_technologies_for_grade(grade)
    corr_techs_for_chem = corr_techs_all.get_chem(chem)

    ct_ranks_all = sorted(corr_techs_all.get_corr_tech_ranks(predicted_chems))
    ct_ranks_for_chem = corr_techs_all.get_corr_tech_ranks([chem])

    extended_corr_techs_for_chem = []  # type: List[CorrectionTechnology]

    for rank in ct_ranks_all:
        if rank not in ct_ranks_for_chem:
            # Add dummy correction technology (with probability 0)
            # so that CDFs for all chems will have the same domain
            limit = extended_corr_techs_for_chem[-1].upper_limit
            extended_corr_techs_for_chem.append(CorrectionTechnology(chem, limit, limit, rank[0], rank[1]))
        else:
            # Otherwise, just pick the corresponding correction technology
            extended_corr_techs_for_chem.append(next(ct for ct in corr_techs_for_chem if ct.rank == rank))

    # IMPORTANT: ordering on result tuple is crucial,
    # it is the same as ordering on the list `ct_ranks_all`.
    # See `CorrectionTechnologies.get_corr_tech_ranks` for more info.
    return tuple(extended_corr_techs_for_chem)


def get_corr_tech_cdfs(
    model_outputs: List[ScrapBlendModelOutput], grade: Grade, predicted_chems: Tuple[Chem, ...], chem: Chem
) -> torch.Tensor:

    full_binning = get_full_binning(model_outputs[0].get_chem_estimate(chem).binning)  # type: ignore

    probas_matrix = torch.stack(  # pylint: disable=no-member
        [torch.Tensor(mo.get_chem_estimate(chem).probas) for mo in model_outputs]  # type: ignore
    )

    corr_techs = get_extended_corr_techs_for_chem(grade, predicted_chems, chem)

    return torch.stack([cdf_batch(ct.upper_limit, probas_matrix, full_binning) for ct in corr_techs]).T


def get_corr_tech_probabilities(
    model_outputs: List[ScrapBlendModelOutput], grade: Grade, predicted_chems: Tuple[Chem, ...]
) -> List[Dict[CorrTechRank, float]]:

    joint_cdfs_per_model_output = generalized_hadamard_product(
        [get_corr_tech_cdfs(model_outputs, grade, predicted_chems, chem) for chem in predicted_chems]
    )

    pmfs_per_model_output = cdf_to_pmf_vectorized(joint_cdfs_per_model_output)

    # IMPORTANT: due to vectorized operations ordering on `ct_ranks` list must be fixed
    corr_techs = get_correction_technologies_for_grade(grade)
    ct_ranks = sorted(corr_techs.get_corr_tech_ranks(predicted_chems))

    # Join ranks and pmfs, cast pmfs to numpy arrays so that resulting dictionaries
    # have float values (instead of tensors)
    pmfs_as_dicts = [dict(zip(ct_ranks, np.array(pmf))) for pmf in pmfs_per_model_output]

    return pmfs_as_dicts


# pylint: disable=no-member
def get_corr_tech_cdfs_fast(
    probas_matrix: torch.Tensor, full_binning: torch.Tensor, corr_techs: Tuple[CorrectionTechnology, ...]
) -> torch.Tensor:
    return torch.stack([cdf_batch(ct.upper_limit, probas_matrix, full_binning) for ct in corr_techs]).T


# pylint: disable=no-member
def get_corr_tech_probabilities_fast(
    eob_proba_matrix_map: Mapping[Chem, torch.Tensor],
    full_binning_map: Mapping[Chem, torch.Tensor],
    grade: Grade,
    predicted_chems: Tuple[Chem, ...],
) -> torch.Tensor:
    joint_cdfs_per_model_output = generalized_hadamard_product(
        [
            get_corr_tech_cdfs_fast(
                eob_proba_matrix_map[chem],
                full_binning_map[chem],
                get_extended_corr_techs_for_chem(grade, predicted_chems, chem),
            )
            for chem in predicted_chems
        ]
    )
    return torch.Tensor(cdf_to_pmf_vectorized(joint_cdfs_per_model_output))
