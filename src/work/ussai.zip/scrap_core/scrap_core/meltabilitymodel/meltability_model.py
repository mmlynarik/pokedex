from typing import Dict, List, Literal, Tuple

import attr
import numpy as np
import torch
from scrap_core import ScrapOrder, ScrapType, between, vectorize_scrap_weights, vectorize_values_total
from scrap_core.meltabilitymodel.datamodel import MeltabilityModelInput, MeltabilityModelOutput

# L is easily meltable scraps
# S is medium meltable scraps
# T is hardly meltable scraps
MeltabilityType = Literal["L", "S", "T"]

MELTABILITY_L = np.array([1.0, 0.0, 0.0])
MELTABILITY_S = np.array([0.0, 1.0, 0.0])
MELTABILITY_T = np.array([0.0, 0.0, 1.0])

SCRAP_MELTABILITY_V1: Dict[ScrapType, MeltabilityType] = {
    "HSR": "T",
    "HSA": "S",
    "HSCA": "T",
    "HSR Cr": "T",
    "HSZ": "T",
    "HSB": "T",
    "HDS": "T",
    "HSK": "S",
    "HSD": "L",
    "HS": "S",
    "PAS": "S",
    "2HM": "T",
    "1HM": "T",
    "MCE": "T",
    "1BC": "L",
    "HST": "S",
    "TBS": "L",
    "ZBS": "L",
    "SBS": "L",
    "2BC": "L",
    "1IB": "S",
    "1DB": "S",
    "1TB": "S",
    "2DB": "S",
    "1SH": "L",
    "2SH": "L",
    "1RR": "T",
    "TBC": "L",
    "1SR": "L",
    "STS": "L",
    "1BBC": "S",
    "2BBC": "S",
    "TBBC": "S",
    "XXX": "S",
    "HB": "S",
    "1BS": "L",
    "SHS": "L",
    "DSI": "T",
    "DSI A1 3": "T",
    "SRB": "T",
    "PIG IRON": "T",
    "1PIT": "T",
    "BPIT": "T",
    "2PIT": "T",
    "TRM": "T",
}

SCRAP_MELTABILITY_V2: Dict[ScrapType, MeltabilityType] = {
    **SCRAP_MELTABILITY_V1,
    "HSB COOL": SCRAP_MELTABILITY_V1["HSB"],
    "1PIT A2": SCRAP_MELTABILITY_V1["1PIT"],
    "2PIT A2": SCRAP_MELTABILITY_V1["2PIT"],
    "DSI A1 2": SCRAP_MELTABILITY_V1["DSI"],
}


def meltability_one_hot_vector(meltability_type: MeltabilityType) -> np.ndarray:
    if meltability_type == "L":
        return MELTABILITY_L
    if meltability_type == "S":
        return MELTABILITY_S
    if meltability_type == "T":
        return MELTABILITY_T
    raise ValueError(f"Invaild meltability type {meltability_type} valid are: L, S, T")


def calculate_meltability_weights(
    scrap_order: ScrapOrder, meltabilities: Dict[ScrapType, MeltabilityType]
) -> np.ndarray:
    return np.stack(
        [meltability_one_hot_vector(x) for x in vectorize_values_total(scrap_order, meltabilities)], axis=1
    )


@attr.s(slots=True, frozen=True)
class MeltabilityModelSettings:
    version: int = attr.ib(default=2, validator=between(1, 2), converter=int)


class ScrapMeltabilityModel:
    def __init__(self, scrap_order: ScrapOrder, meltabilities: Dict[ScrapType, MeltabilityType]):
        self.scrap_order = scrap_order
        self.weights = calculate_meltability_weights(scrap_order, meltabilities)
        self.l_fast_weights = torch.Tensor(self.weights[0, :])
        self.h_fast_weights = torch.Tensor(self.weights[2, :])
        self.h_scraps = tuple(
            [scrap_type for scrap_type in scrap_order if meltabilities.get(scrap_type, None) == "T"]
        )
        self.l_scraps = tuple(
            [scrap_type for scrap_type in scrap_order if meltabilities.get(scrap_type, None) == "L"]
        )

    def calculate(self, input_data: MeltabilityModelInput) -> MeltabilityModelOutput:
        vectorized_weights = np.array(vectorize_scrap_weights(self.scrap_order, input_data.scrap_weights))
        weight_sum_by_type = (self.weights * vectorized_weights).sum(axis=1)
        return MeltabilityModelOutput(*weight_sum_by_type)

    def calculate_batch(self, input_data: List[MeltabilityModelInput]) -> List[MeltabilityModelOutput]:
        return [self.calculate(one_heat) for one_heat in input_data]

    def calculate_batch_fast(self, scrap_matrix: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        total_weight = scrap_matrix.sum(axis=1)  # type: ignore
        l_ratio = (self.l_fast_weights * scrap_matrix).sum(axis=1) / total_weight  # type: ignore
        h_ratio = (self.h_fast_weights * scrap_matrix).sum(axis=1) / total_weight  # type: ignore
        return l_ratio, h_ratio
