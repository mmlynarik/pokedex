import attr
from immutables import Map

from .. import positive_finite, scrap_weights_converter
from ..datamodel import Heat


@attr.s(slots=True, frozen=True)
class MeltabilityModelInput:
    scrap_weights: Map = attr.ib(
        validator=attr.validators.instance_of(Map), converter=scrap_weights_converter  # type: ignore
    )


@attr.s(slots=True, frozen=True)
class MeltabilityModelOutput:
    easily_meltable_scrap: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    medium_meltable_scrap: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    hardly_meltable_scrap: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )

    def hardly_meltable_scrap_ratio(self) -> float:
        return self.hardly_meltable_scrap / (
            self.easily_meltable_scrap + self.medium_meltable_scrap + self.hardly_meltable_scrap
        )

    def easily_meltable_scrap_ratio(self) -> float:
        return self.easily_meltable_scrap / (
            self.easily_meltable_scrap + self.medium_meltable_scrap + self.hardly_meltable_scrap
        )

    def not_hardly_meltable_scrap_ratio(self) -> float:
        return (self.easily_meltable_scrap + self.medium_meltable_scrap) / (
            self.easily_meltable_scrap + self.medium_meltable_scrap + self.hardly_meltable_scrap
        )


def convert_heat_to_scrap_meltability_model_input(heat: Heat) -> MeltabilityModelInput:
    return MeltabilityModelInput(scrap_weights=heat.get_scrap_map())
