from functools import lru_cache

from .. import SUPPORTED_SCRAP_TYPES
from .datamodel import (
    MeltabilityModelInput,
    MeltabilityModelOutput,
    convert_heat_to_scrap_meltability_model_input,
)
from .meltability_model import (
    SCRAP_MELTABILITY_V1,
    SCRAP_MELTABILITY_V2,
    MeltabilityModelSettings,
    ScrapMeltabilityModel,
)


@lru_cache(maxsize=1)
def get_meltability_model(version: int = 2) -> ScrapMeltabilityModel:
    if version == 2:
        return ScrapMeltabilityModel(SUPPORTED_SCRAP_TYPES, SCRAP_MELTABILITY_V2)
    raise Exception(f"Invalid model version {version} - valid versions are: [2]")
