# pylint: skip-file

"""
The code in this package is copied from https://github.com/khornlund/pytorch-balanced-sampler.

Even though it is very unlikely, the only reason why it is copied instead of downloaded and imported
is due to risk that the owner of repository may decide to remove it.
"""
from .sampler import SamplerFactory, WeightedRandomBatchSampler, WeightedFixedBatchSampler
