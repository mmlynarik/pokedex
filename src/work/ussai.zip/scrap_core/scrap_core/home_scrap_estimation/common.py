import datetime
import functools
import json
import logging
import pathlib
import re
from typing import Dict, List

import numpy as np
import pandas as pd
from cattr import unstructure
from usskscadaocclient import HeatData

from scrap_core import TMS_ID_MAPPING, ScrapType
from scrap_core.home_scrap_estimation.scrap_supplies import get_scrap_supplies_data

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


SCRIPT_DIR = pathlib.Path(__file__).resolve()
MODEL_DIR = SCRIPT_DIR.parent.joinpath("estimators")
DEFAULT_CONFIG_ENV = SCRIPT_DIR.parents[3].joinpath("config.env")
DEFAULT_SCRAP_TYPE_MAP_NAME = "scrap_type_map.json"
SCADA_SCRAP_COL_PATTERN = re.compile(r"^scrap_(?P<code_1>\d\d)(?:_(?P<code_2>\d))?$")

# list of home scrap types with their equivalents
HOME_SCRAP: Dict[ScrapType, List[ScrapType]] = {
    "HSR": [],
    "HSR Cr": [],
    "HSZ": [],
    "HSB": ["HSB COOL"],
    "HSK": [],
    "HSD": [],
    "HS": ["HB"],
    "HST": [],
    "HDS": [],
    "DSI": ["DSI A1 2"],
    "1PIT": ["1PIT A2"],
    "2PIT": ["2PIT A2"],
    "BPIT": [],
    "SRB": [],
    "PIG IRON": [],
}

SCARCE_SCRAP: List[ScrapType] = ["HDS", "HSK", "HSR Cr", "HSR", "BPIT", "SRB"]

DEPENDENT_SCRAP: List[ScrapType] = ["HS", "HSZ", "DSI", "1PIT", "HSB", "HST"]

INDEPENDENT_SCRAP: List[ScrapType] = ["2PIT", "HSD", "PIG IRON"]


class LinearModel:
    def __init__(self, intercept: float, slope: float):
        self.intercept = intercept
        self.slope = slope

    def predict(self, x: float) -> float:
        return self.intercept + self.slope * x


def decode_scrap_column_name(col_name: str) -> str:
    m_obj = SCADA_SCRAP_COL_PATTERN.match(col_name)

    if m_obj:
        code_1 = m_obj.group("code_1")
        code_2 = m_obj.group("code_2") or ""
        code = int(f"{code_1}{code_2}")
        return TMS_ID_MAPPING.get(code, col_name)

    return col_name


@functools.lru_cache()
def get_model(model_dir: pathlib.Path, scrap_type: ScrapType) -> LinearModel:
    with open(model_dir.joinpath(f"{scrap_type}.json")) as f:
        model_data = json.load(f)

    return LinearModel(**model_data["params"])


def estimate_dependent_home_scrap(scrap_type: ScrapType, weekly_steel_production: float) -> float:
    if scrap_type not in DEPENDENT_SCRAP:
        raise ValueError(f"Supported scrap types are {DEPENDENT_SCRAP}, got {scrap_type}")

    model = get_model(MODEL_DIR, scrap_type)

    return max(0.0, model.predict(weekly_steel_production))


def estimate_independent_home_scrap(scrap_type: ScrapType, scada_db: HeatData, dt_at: datetime.date) -> float:
    """
    Estimate production of home scrap that does not depend on steel production
    in week starting at dt_at based on data from previous 12 weeks.
    """
    if scrap_type not in INDEPENDENT_SCRAP:
        raise ValueError(f"Supported scrap types are {INDEPENDENT_SCRAP}, got {scrap_type}")

    df_consumption = get_home_scrap_consumption_data(
        scada_db, dt_at - datetime.timedelta(weeks=12), dt_at
    ).copy()

    return df_consumption[scrap_type].median()


def estimate_weekly_home_scrap_production(
    scada_db: HeatData, dt_at: datetime.date, expected_weekly_steel_production: float
) -> Dict[ScrapType, float]:
    """
    Estimate weekly home scrap production at week starting at `dt_at`
    based on `expected_weekly_steel_production`.
    """
    # Expected production of scarce scrap is 0
    scarce_scrap = {scrap_type: 0 for scrap_type in SCARCE_SCRAP}

    dependent_scrap = {
        scrap_type: estimate_dependent_home_scrap(scrap_type, expected_weekly_steel_production)
        for scrap_type in DEPENDENT_SCRAP
    }
    independent_scrap = {
        scrap_type: estimate_independent_home_scrap(scrap_type, scada_db, dt_at)
        for scrap_type in INDEPENDENT_SCRAP
    }

    return {**scarce_scrap, **dependent_scrap, **independent_scrap}


def get_home_scrap_consumption_data(
    scada_db: HeatData, dt_from: datetime.date, dt_to: datetime.date
) -> pd.DataFrame:
    log.info("Reading scrap consumption data from scada db ...")
    heats = scada_db.get_heat_data(dt_from, dt_to)
    df_data = pd.DataFrame.from_records(data=[unstructure(x) for x in heats])

    if heats:
        # unpack scrap_weights col(contains dict of scrap_type: weight) to columns
        df_scrap_weights = pd.json_normalize(df_data["scrap_weights"])
        df_scrap_weights = df_scrap_weights.rename(columns=decode_scrap_column_name)
        df_data = df_data.join(df_scrap_weights)

    # drop irrelevant columns
    df_data = df_data[["heat_datetime", "final_steel_w"] + list(HOME_SCRAP)]

    # aggregate equivalent scrap types
    for scrap_type in HOME_SCRAP:
        for equivalent in HOME_SCRAP[scrap_type]:
            if equivalent in df_data.columns:
                df_data[scrap_type] += df_data[equivalent]
                df_data = df_data.drop(columns=equivalent)

    # TODO think about using rolling window instead of groupby
    #   i.e. groupby by days, then 1 week rolling window
    # group consumption data by heat week, remove first and last (potentially) incomplete weeks
    df = df_data.groupby(pd.Grouper(key="heat_datetime", freq="1W", sort=True)).sum().iloc[1:-1]
    # convert datetime index to date
    df.index = df.index.date
    return df


def get_home_scrap_and_steel_production_data(
    workdir: pathlib.Path,
    scrap_type_map_name: str,
    scada_db: HeatData,
    dt_from: datetime.date,
    dt_to: datetime.date,
) -> pd.DataFrame:
    df_consumption = get_home_scrap_consumption_data(scada_db, dt_from, dt_to)
    log.info("Scrap consumption data and steel production data processed successfully.")

    df_supplies = get_scrap_supplies_data(workdir, scrap_type_map_name)
    log.info("Scrap supplies data processed successfully.")

    # remove rows with no data
    df_consumption = df_consumption.dropna(how="all")
    df_supplies = df_supplies.dropna(how="all")

    # fill in missing values with 0s, i.e. no value means 0 supply/consumption
    df_consumption = df_consumption.fillna(0)
    df_supplies = df_supplies.fillna(0)

    # keep relevant columns only - home scrap types and final steel weight
    df_consumption = df_consumption.filter(["final_steel_w"] + list(HOME_SCRAP), axis=1)
    df_supplies = df_supplies.filter(list(HOME_SCRAP), axis=1)

    # align columns - scrap types and replace missing values with 0s,
    # no value means 0 supply/consumption, because rows with no data have been already removed above
    df_supplies, df_consumption = df_supplies.align(df_consumption, join="outer", axis=1, fill_value=0)

    # align indexes - weeks
    full_index = pd.date_range(dt_from, dt_to, freq="1W")
    df_consumption = df_consumption.reindex(full_index)
    df_supplies = df_supplies.reindex(full_index)

    df_previous = df_supplies.shift(freq="1W")

    df_decrease = np.maximum(df_previous - df_supplies, 0).reindex(full_index)
    # we add 1 week to each side to take into account inaccuracy and shift due to week aggregation
    df_max_consumption = df_consumption.rolling(window=3, center=True, min_periods=1).max()
    expected_decrease = df_decrease <= df_max_consumption
    # if `decrease in supplies > consumption`, then either data are inaccurate/corrupted,
    # or we sold some scrap (DSI only). Hence, we drop such records.
    df_production = (df_consumption + (df_supplies - df_previous)).where(expected_decrease, None)

    # remove rows with no data - if either consumption or supplies do not have data for given week
    # or decrease of scrap supplies is higher than consumption
    return df_production.dropna(how="all").fillna(0).astype(float)
