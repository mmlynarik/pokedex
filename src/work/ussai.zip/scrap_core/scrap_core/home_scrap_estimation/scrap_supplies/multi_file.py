import datetime
import json
import logging
import re
import pathlib
from typing import List, Dict

import openpyxl
import pandas as pd
from tqdm.auto import tqdm

from scrap_core import SUPPORTED_SCRAP_TYPES, ScrapType
from scrap_core.home_scrap_estimation.scrap_supplies.single_file import (
    get_col_map,
    read_scrap_supplies_data,
)


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def get_sheet_names(excel_path: pathlib.Path) -> List[str]:
    """Glen Thompson's solution here https://stackoverflow.com/questions/12250024/"""
    wb = openpyxl.load_workbook(excel_path, read_only=True, keep_links=False)
    return wb.sheetnames


def sheet_name_to_date(sheet_name: str) -> datetime.date:
    try:
        return datetime.datetime.strptime(sheet_name.strip(), "%d.%m.%y").date()
    except ValueError:
        return datetime.datetime.strptime(sheet_name.strip(), "%d.%m.%Y").date()


def find_scrap_supplies_xlsx_files(workdir: pathlib.Path) -> List[pathlib.Path]:
    return [
        path
        for path in workdir.glob("**/*")
        if re.match(r"^Evidencia hromad \d{1,2}\-202\d.xlsx$", path.name)
    ]


def read_scrap_type_map(filepath: pathlib.Path) -> Dict[str, ScrapType]:
    if not filepath.exists():
        # if source file does not exist, return empty map
        log.warning("Scrap type map not found.")
        return {}

    with open(filepath, encoding="utf8") as f:
        scrap_type_map = json.load(f)

    unmapped_keys = {key for key, value in scrap_type_map.items() if value not in SUPPORTED_SCRAP_TYPES}

    if unmapped_keys:
        raise SystemExit(
            f"There are keys not mapped to scrap types {unmapped_keys}. Please update file {filepath}"
            f" accordingly and rerun the script."
        )

    return scrap_type_map


def write_scrap_type_map(filepath: pathlib.Path, scrap_map: Dict[str, ScrapType]) -> None:
    with open(filepath, "w", encoding="utf8") as f:
        json.dump(scrap_map, f, sort_keys=True, indent=2, ensure_ascii=False)


# TODO automatically update cached file, when new data are available
def get_scrap_supplies_data(
    workdir: pathlib.Path, scrap_type_map_name: str, cache: str = "scrap_supplies_data.csv"
) -> pd.DataFrame:
    cache_path = workdir.joinpath(cache)
    if cache_path.exists():
        df_data = pd.read_csv(cache_path, parse_dates=["timestamp"])
        log.info("Supplies data read from cached file '%s'.", cache_path)
    else:
        scrap_type_map_path = workdir.joinpath(scrap_type_map_name)
        scrap_type_map = read_scrap_type_map(scrap_type_map_path)

        data = {}

        for filepath in tqdm(find_scrap_supplies_xlsx_files(workdir)):
            for sheet_name in get_sheet_names(filepath):
                try:
                    dt = sheet_name_to_date(sheet_name)
                    df_tmp = read_scrap_supplies_data(filepath, sheet_name, scrap_type_map, get_col_map(dt))
                    df_supplies_data = (
                        df_tmp.rename(columns={"actual_weight": "weight"})
                        .groupby("scrap_type")["weight"]
                        .sum()
                        .reset_index()
                    )
                    data[dt] = df_supplies_data
                except Exception:
                    log.exception("Can't process sheet '%s' in file '%s'.", sheet_name, filepath)
                    raise

                unknown_scrap_types_tmp = set(df_supplies_data["scrap_type"]) - set(SUPPORTED_SCRAP_TYPES)
                if unknown_scrap_types_tmp:
                    log.warning(
                        f"File {filepath} - sheet {sheet_name}: unknown scrap types found: {unknown_scrap_types_tmp}"
                    )

        log.info("All files in '%s' processed successfully.", workdir)

        unknown_scrap_types = set(st for df in data.values() for st in df["scrap_type"]) - set(
            SUPPORTED_SCRAP_TYPES
        )

        if unknown_scrap_types:
            new_scrap_type_map = {**scrap_type_map, **{key: "?" for key in unknown_scrap_types}}
            write_scrap_type_map(scrap_type_map_path, new_scrap_type_map)
            log.info("Scrap type map '%s' updated.", scrap_type_map_path)
            raise SystemExit(
                f"Unknown scrap types found {unknown_scrap_types}. Please update file {scrap_type_map_path}"
                f" accordingly and rerun the script"
            )

        df_data = pd.DataFrame(
            {ts: pd.Series(df.set_index("scrap_type")["weight"]) for ts, df in data.items()}
        ).T

        df_data = df_data.reset_index().rename(columns={"index": "timestamp"})

        df_data.to_csv(cache_path, index=False)
        log.info("Pre-processed supply data saved as '%s'", cache_path)

    # TODO maybe a different aggregation (other than mean) would be better
    df_data["timestamp"] = pd.to_datetime(df_data["timestamp"])
    df_data = df_data.groupby(pd.Grouper(key="timestamp", freq="1W", sort=True)).mean()

    return df_data
