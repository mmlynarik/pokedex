import datetime
from typing import Dict, Any, Optional
import pathlib
import re

import pandas as pd

from scrap_core import SUPPORTED_SCRAP_TYPES, ScrapType
from scrap_core.utils import convert_tons_to_kilograms


LOCATION = ["STARÝ ŠROT", "LIS", "KOĽAJ 350", "OC 2"]

# Due to format change we need 2 different column maps
COL_MAP_V1 = {0: "heap_name", 1: "heap_type", 3: "actual_weight", 5: "heap_no", 6: "detail", 7: "heap_date"}
COL_MAP_V2 = {0: "heap_name", 1: "heap_type", 3: "actual_weight", 4: "heap_no", 2: "detail", 7: "heap_date"}


def get_col_map(dt: datetime.date) -> Dict[int, str]:
    if dt <= datetime.date(2023, 4, 24):
        return COL_MAP_V1
    else:
        return COL_MAP_V2


class ColumnError(Exception):
    pass


def sanitize_dataframe(dataframe: pd.DataFrame) -> pd.DataFrame:
    # remove trailing whitespace and unify case
    df_san_1 = dataframe.applymap(lambda val: val.strip().upper() if isinstance(val, str) else val)

    # replace whitespace characters with blanks
    df_san_2 = df_san_1.applymap(lambda val: re.sub(r"\s", " ", val) if isinstance(val, str) else val)

    # squash consecutive blanks
    df_san_3 = df_san_2.applymap(lambda val: re.sub(r" {2,}", " ", val) if isinstance(val, str) else val)

    return df_san_3


def preprocess_dataframe(dataframe: pd.DataFrame, col_map: Dict[int, str]) -> pd.DataFrame:
    def fix_heat_no(val: Any) -> Optional[str]:
        if pd.isna(val):
            return None

        if isinstance(val, float):
            val = str(int(val))

        if isinstance(val, str) and len(val) == 5:
            return val

        return None

    df = dataframe.rename(columns=col_map)[col_map.values()]

    df["heap_name"] = df["heap_name"].apply(lambda val: val if isinstance(val, str) else None)

    df["heap_no"] = df["heap_no"].apply(fix_heat_no)

    df["detail"] = df["detail"].apply(
        lambda val: val if (isinstance(val, str) and not val.isdigit()) else None
    )

    # drop records with missing "indicator" values
    df = df.dropna(subset={"heap_name", "heap_date"}, how="any").reset_index(drop=True)

    df["heap_name"] = df["heap_name"].str.strip().str.replace(r" {2,}", " ", regex=True)

    df["adjusted_heap_name"] = df["heap_name"].str.replace(" ", "")

    return df


def parse_single_location_data(dataframe: pd.DataFrame, scrap_type_map: Dict[str, ScrapType]) -> pd.DataFrame:
    def lookup_scrap_type(val: Any) -> Optional[str]:
        try:
            if set(val.split(",")).issubset(SUPPORTED_SCRAP_TYPES):
                return val
            else:
                return None
        except AttributeError:
            return None

    dataframe = dataframe.copy().reset_index(drop=True)

    # extract location from the first row
    dataframe["heap_location"] = dataframe.loc[0, "heap_name"]

    # discard the first row
    dataframe = dataframe.drop(index=0)

    # derive scrap type for single scrap heats
    dataframe["derived_scrap_type"] = dataframe["adjusted_heap_name"].apply(
        lambda val: val if val in SUPPORTED_SCRAP_TYPES else scrap_type_map.get(val, val)
    )

    # read scrap types from detail column, if possible
    dataframe["scrap_type"] = dataframe["detail"].apply(lookup_scrap_type)

    # combine known and derived scrap types
    dataframe["scrap_type"] = dataframe["scrap_type"].combine_first(dataframe["derived_scrap_type"])

    # convert scrap types to lists
    dataframe["scrap_type"] = dataframe["scrap_type"].str.split(",")

    # store number of scrap types per heat
    dataframe["scrap_factor"] = dataframe["scrap_type"].apply(len)

    # split composite heaps into multiple rows
    df_flat = dataframe.explode("scrap_type")

    # adjust actual weight according to scrap factor
    df_flat["actual_weight"] = df_flat["actual_weight"] / df_flat["scrap_factor"]

    # sanity check, if sum of weights is preserved
    if abs(df_flat["actual_weight"].sum() - dataframe["actual_weight"].sum()) >= 1:
        raise ValueError(
            f"Actual weight sum mismatch: o"
            f"rig {dataframe['actual_weight'].sum()} != flat {df_flat['actual_weight'].sum()}"
        )

    df_flat["actual_weight"] = df_flat["actual_weight"].apply(convert_tons_to_kilograms)

    return df_flat


def validate_data(dataframe: pd.DataFrame) -> None:

    # check if heap_no values are as expected
    if not dataframe["heap_no"].apply(lambda val: len(val) == 5 and val.isdigit()).all():
        raise ColumnError(f"Invalid values in 'heap_no' column: {dataframe['heap_no']}")


def read_scrap_supplies_data(
    excel_path: pathlib.Path,
    sheet_name: str,
    scrap_type_map: Dict[str, ScrapType],
    col_name_map: Dict[int, str],
) -> pd.DataFrame:
    """Function to parse 'Evidencia hromad'-like files"""

    df = pd.read_excel(excel_path, sheet_name=sheet_name, skiprows=2, header=None, engine="openpyxl")

    df_sanitized = sanitize_dataframe(df)

    df_preprocessed = preprocess_dataframe(df_sanitized, col_name_map)

    location_separators = sorted(df_preprocessed[df_preprocessed["heap_name"].isin(LOCATION)].index)

    data = []

    for start, end in zip(location_separators, location_separators[1:] + [len(df_preprocessed)]):
        df_tmp = parse_single_location_data(df_preprocessed.loc[start : end - 1], scrap_type_map)
        data.append(df_tmp)

    df_res = pd.concat(data)

    validate_data(df_res)

    return df_res
