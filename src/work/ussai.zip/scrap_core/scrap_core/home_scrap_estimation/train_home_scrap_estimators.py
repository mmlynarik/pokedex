import argparse
import datetime
import json
import logging
import os
import pathlib

import dotenv
import numpy as np
import pandas as pd
import statsmodels.api as sm
from usskscadaocclient import ScadaConnector

from scrap_core.home_scrap_estimation.common import (
    DEFAULT_CONFIG_ENV,
    DEFAULT_SCRAP_TYPE_MAP_NAME,
    DEPENDENT_SCRAP,
    MODEL_DIR,
    get_home_scrap_and_steel_production_data,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def train_and_save_linear_models(
    df_production: pd.DataFrame, output_dir: pathlib.Path, metadata: dict
) -> None:
    output_dir.mkdir(exist_ok=True)

    # TODO remove outliers - negative values, percentiles
    x = np.array(df_production["final_steel_w"])

    for scrap_type in DEPENDENT_SCRAP:
        y = np.array(df_production[scrap_type])

        res = sm.OLS(y, sm.add_constant(x)).fit()

        intercept, slope = res.params
        model_data = {"params": {"intercept": intercept, "slope": slope}, "metadata": metadata}

        model_path = output_dir.joinpath(f"{scrap_type}.json")
        with open(model_path, "w") as f:
            json.dump(model_data, f)

        log.info("Model '%s' - updated", model_path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train linear models to estimate home scrap production "
        "of scrap types that depend on steel production"
    )

    parser.add_argument(
        "-c",
        "--config",
        help=f"Path to 'config.env'-like file with Scada OC credentials, default is '{DEFAULT_CONFIG_ENV}'",
        default=DEFAULT_CONFIG_ENV,
        type=str,
    )
    parser.add_argument(
        "-w",
        "--workdir",
        help="Directory with supply data files called 'Evidencia hromad \\d{1,2}\\-202\\d.xlsx'",
        required=True,
        type=str,
    )
    parser.add_argument(
        "-s",
        "--start",
        help="Training data start date (format YYYY-MM-DD)",
        required=True,
        type=lambda dt: datetime.datetime.strptime(dt, "%Y-%m-%d"),
    )

    parser.add_argument(
        "-e",
        "--end",
        help="Training data end date (format YYYY-MM-DD)",
        required=True,
        type=lambda dt: datetime.datetime.strptime(dt, "%Y-%m-%d"),
    )
    parser.add_argument(
        "-m",
        "--map",
        help=f"Name of scrap type map file stored in 'workdir', default is '{DEFAULT_SCRAP_TYPE_MAP_NAME}'",
        default=DEFAULT_SCRAP_TYPE_MAP_NAME,
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.DEBUG,
    )
    dotenv.load_dotenv(args.config)

    scada_cfg = {
        "host": os.environ.get("SCADA_DB_HOST"),
        "port": os.environ.get("SCADA_DB_PORT"),
        "database": os.environ.get("SCADA_DB_SID"),
        "username": os.environ.get("SCADA_DB_USER"),
        "password": os.environ.get("SCADA_DB_PASSWORD"),
    }

    df_production = get_home_scrap_and_steel_production_data(
        pathlib.Path(args.workdir), args.map, ScadaConnector(scada_cfg), args.start, args.end
    )
    log.info("Training data processed successfully")

    train_and_save_linear_models(
        df_production,
        MODEL_DIR,
        metadata={
            "training_start": args.start.date().isoformat(),
            "training_end": args.end.date().isoformat(),
        },
    )
    log.info("All models updated successfully")


if __name__ == "__main__":
    main()
