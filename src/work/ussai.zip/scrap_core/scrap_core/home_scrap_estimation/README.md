# Home scrap production estimation

Script to train linear models for estimation of home scrap production dependent on steel production. Training data consists of steel production and scrap
consumption read from Scada db and scrap supplies data provided in excel files called "Evidencia hromad". Models are stored in directory `./estimators`.

Model validation can be found in notebook `UssAi/notebooks/Show Home Scrap Estimation.ipynb`.

## Versions

| Version | Date       | Change Description                                                                                  |
|---------|------------|-----------------------------------------------------------------------------------------------------|
| 0.0.1   | 2022-07-19 | OLS models trained on supply and consumption data between 2020-01-01 and 2022-07-01                 |
| 0.0.2   | 2022-07-26 | Store linear model params in json format instead of pickle, move notebooks to `notebooks` directory |

## TODO

- [ ] move HSD to scarce scrap group
- [ ] add warning if we do not have supply data (excel files) for selected period
- [ ] consider using scrap supply map from `SupportedScrapTypeMapping` django table/model
- [ ] independent scrap is estimated based on consumption data only, as there all almost no supplies of these scrap types 
- [ ] add HSA scrap type