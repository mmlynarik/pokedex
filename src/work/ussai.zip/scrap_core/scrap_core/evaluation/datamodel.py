from functools import lru_cache
from statistics import mean
from typing import List, Optional, Set, Tuple

from immutables import Map
from scrap_core import ScrapMix


def and_optional(*flags: Optional[bool]) -> Optional[bool]:
    for flag in flags:
        if flag is None:
            return None
        if not flag:
            return False
    return True


@lru_cache(maxsize=1024)
def get_loading_diff(
    reality: Map[ScrapMix, float], model_recommendation: Map[ScrapMix, float]
) -> List[float]:
    all_scraps_used: Set[ScrapMix] = set([*reality.keys(), *model_recommendation.keys()])
    return [
        abs(reality.get(scrap_type, 0.0) - model_recommendation.get(scrap_type, 0.0))
        for scrap_type in all_scraps_used
    ]


def get_used_scraps_count(scraps: Map[ScrapMix, float]) -> int:
    return len([scrap_mix for scrap_mix, weight in scraps.items() if weight > 0.0])


def total_loading_error(reality: Map[ScrapMix, float], model_recommendation: Map[ScrapMix, float]) -> float:
    return sum(get_loading_diff(reality, model_recommendation))


def max_loading_error(reality: Map[ScrapMix, float], model_recommendation: Map[ScrapMix, float]) -> float:
    return max(get_loading_diff(reality, model_recommendation))


def average_loading_error(reality: Map[ScrapMix, float], model_recommendation: Map[ScrapMix, float]) -> float:
    return mean(get_loading_diff(reality, model_recommendation))


def calculate_effective_lower_bound(bounds_and_results: List[Tuple[int, int]]) -> int:
    if not bounds_and_results:
        return 0
    last_lower_bound, last_result = bounds_and_results[-1]
    if last_result > last_lower_bound:
        return 0

    previous_efflb = calculate_effective_lower_bound(bounds_and_results[:-1])
    # why do we need this (at the first sight redundant) operation, I don't know
    current_efflb = min(last_lower_bound, last_result)

    if len(bounds_and_results) > 1:
        previous_result = bounds_and_results[-2][1]
        if (previous_efflb < current_efflb) and (previous_result == last_result):
            return previous_efflb

    return current_efflb


def calculate_effective_upper_bound(bounds_and_results: List[Tuple[int, int]], total: int) -> int:

    if not bounds_and_results:
        return total

    last_upper_bound, last_result = bounds_and_results[-1]
    if last_result < last_upper_bound:
        return total

    previous_eff_ub = calculate_effective_upper_bound(bounds_and_results[:-1], total)

    if len(bounds_and_results) > 1:
        previous_result = bounds_and_results[-2][1]
        if (previous_eff_ub > last_upper_bound) and (previous_result == last_result):
            return previous_eff_ub

    return last_upper_bound
