import collections
from itertools import chain, combinations
from math import ceil, floor
from typing import (
    Any,
    Dict,
    Iterable,
    List,
    TypeVar,
    Tuple,
    Hashable,
    Mapping,
    Collection,
    Callable,
    Generator,
    Sequence,
)

import attr
import numpy as np
import pandas as pd
from immutables import Map

from scrap_core import ScrapMix, ScrapMixOrder


T = TypeVar("T")
H = TypeVar("H", bound=Hashable)
N = TypeVar("N", int, float)


MEAN_HEAT_WEIGHT = 190000  # Extracted from data between 2018-01-01 and 2022-03-01
MEAN_SCRAP_WEIGHT = 38000  # 20% of MEAN_HEAT_WEIGHT
MEAN_SCRAP_RATIO = MEAN_SCRAP_WEIGHT / MEAN_HEAT_WEIGHT


def convert_tons_to_kilograms(weight: float) -> int:
    return int(weight * 1000)


def convert_kilograms_to_tons(weight: float) -> float:
    return float(weight / 1000)


def steel_to_heat(
    steel_weight: float, pig_iron_yield: float, scrap_yield: float, scrap_ratio: float
) -> float:
    return steel_weight / (pig_iron_yield * (1 - scrap_ratio) + scrap_yield * scrap_ratio)


def heat_to_steel(heat_weight: float, pig_iron_yield: float, scrap_yield: float, scrap_ratio: float) -> float:
    return heat_weight * (pig_iron_yield * (1 - scrap_ratio) + scrap_yield * scrap_ratio)


def steel_to_scrap(
    steel_weight: float, pig_iron_yield: float, scrap_yield: float, scrap_ratio: float
) -> float:
    return steel_to_heat(steel_weight, pig_iron_yield, scrap_yield, scrap_ratio) * scrap_ratio


def scrap_to_steel(
    scrap_weight: float, pig_iron_yield: float, scrap_yield: float, scrap_ratio: float
) -> float:
    return heat_to_steel(scrap_weight / scrap_ratio, pig_iron_yield, scrap_yield, scrap_ratio)


def replace_attribute(obj: T, attribute_path: List[str], new_value: Any) -> T:
    if len(attribute_path) == 1:
        return attr.evolve(obj, **{attribute_path[0]: new_value})

    return attr.evolve(
        obj,
        **{
            attribute_path[0]: replace_attribute(
                getattr(obj, attribute_path[0]), attribute_path[1:], new_value
            )
        },
    )


def floor_with_precision(value: float, precision: int) -> int:
    return floor(value / precision) * precision


def ceil_with_precision(value: float, precision: int) -> int:
    return ceil(value / precision) * precision


# TODO remove, since we finally have pandas 1.4.*
def create_empty_dataframe(columns: Iterable[str]) -> pd.DataFrame:
    """In pandas version 1.0.1 the code `pd.DataFrame(columns=[...])` does not work."""
    df_empty = pd.DataFrame()
    for col in columns:
        df_empty[col] = []
    return df_empty


def union(groups: Iterable[Iterable[H]]) -> Tuple[H, ...]:
    """
    Apply set-union to given containers. Result is a tuple
    containing all items from given groups (deduplicated).
    """
    return tuple(set(chain.from_iterable(groups)))


def normalize_mapping(mapping: Dict[H, N], domain: Sequence[H], default: N) -> Dict[H, N]:
    """Extend mapping to the given domain."""
    return {key: mapping.get(key, default) for key in domain}


def maximum(*mappings: Dict[H, N]) -> Dict[H, N]:
    """Calculate maximum mapping from given mappings."""
    return {key: max(item[key] for item in mappings) for key in union(mappings)}


def elementwise_sum(*mappings: Dict[H, N]) -> Dict[H, N]:
    """Calculate elementwise sum from given mappings."""
    domain = union(mappings)
    return {key: sum(item.get(key, 0) for item in mappings) for key in domain}


def omit_values_above(mapping: Mapping[H, N], cutoff: N) -> Mapping[H, N]:
    return {key: val for key, val in mapping.items() if val < cutoff}


def omit_zeros(mapping: Mapping[H, N]) -> Dict[H, N]:
    return {key: val for key, val in mapping.items() if val != 0}


def powerset(elements: Collection[T], empty: bool = True) -> List[Tuple[T, ...]]:
    return list(chain.from_iterable(combinations(elements, r) for r in range(1 - empty, len(elements) + 1)))


def to_mixes(*scrap_types: str) -> ScrapMixOrder:
    return tuple(ScrapMix(st) for st in scrap_types)


def group_by(items: Iterable[T], key_getter: Callable[[T], H]) -> Map[H, Tuple[T, ...]]:
    groups = collections.defaultdict(list)

    for item in items:
        groups[key_getter(item)].append(item)

    return Map({key: tuple(val) for key, val in groups.items()})


def get_simple_integer_approximations(vec: np.ndarray, precision: int) -> Generator[np.ndarray, None, None]:
    """
    For every approximation approx yielded by this generator 3 conditions are fulfilled:
     - sum(approx) == sum(vec)
     - every element in approx is divisible by precision
     - approx and vec are close to each other, in particular max(abs(approx - vec)) <= precision
    """
    if not round(sum(vec)) % precision == 0:
        raise ValueError(f"Input {vec} is invalid, its sum is not divisible by {precision}")

    base, remainder = divmod(vec, precision)

    num_of_ones = round(sum(remainder) / precision)
    for indexes in combinations(range(len(vec)), num_of_ones):
        tmp = base.copy()
        tmp[list(indexes)] += 1
        yield tmp * precision
