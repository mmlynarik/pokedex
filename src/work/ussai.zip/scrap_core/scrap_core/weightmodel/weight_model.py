from typing import Tuple

import attr


@attr.s(auto_attribs=True, slots=True, frozen=True)
class WeightModelSettings:
    """Following (default) values are extracted from data between 2018-01-01 and 2021-09-22."""

    mean_steel_weight: float = attr.ib(default=174139.906030)
    # steel_yield = steel_w / heat_w
    mean_steel_yield: float = attr.ib(default=0.90185876)
    # scrap_ratio = total_scrap_w / heat_w
    mean_scrap_ratio: float = attr.ib(default=0.194734)
    # pig_iron_ratio = pig_iron_w / heat_w
    mean_pig_iron_ratio: float = attr.ib(default=0.790095)


# TODO add get_weight_model function to follow standard "get_model API"
class ScrapWeightModel:
    def __init__(self, settings=WeightModelSettings()):
        self.mean_steel_weight = settings.mean_steel_weight
        self.mean_steel_yield = settings.mean_steel_yield
        self.mean_scrap_ratio = settings.mean_scrap_ratio
        self.mean_pig_iron_ratio = settings.mean_pig_iron_ratio

    def __calculate_expected_scrap_weight(self, steel_weight: float):
        return steel_weight / self.mean_steel_yield * self.mean_scrap_ratio

    def __calculate_expected_pig_iron_weight(self, steel_weight: float):
        return steel_weight / self.mean_steel_yield * self.mean_pig_iron_ratio

    @property
    def mean_scrap_weight(self):
        return self.__calculate_expected_scrap_weight(self.mean_steel_weight)

    @property
    def mean_pig_iron_weight(self):
        return self.__calculate_expected_pig_iron_weight(self.mean_steel_weight)

    def calculate(self, steel_weight: float) -> Tuple[float, float]:
        return (
            self.__calculate_expected_pig_iron_weight(steel_weight),
            self.__calculate_expected_scrap_weight(steel_weight),
        )
