import attr
from immutables import Map
from ..datamodel import Heat
from .. import positive_finite, scrap_weights_converter


@attr.s(slots=True, frozen=True)
class ScrapYieldModelInput:
    raw_fe_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    scrap_weights: Map = attr.ib(
        validator=attr.validators.instance_of(Map), converter=scrap_weights_converter  # type: ignore
    )
    pellet_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    briquetes_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    # TODO replace with separate tap alloys weights and make separate correction model
    corrected_tap_alloys_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )


@attr.s(slots=True, frozen=True)
class ScrapYieldModelOutput:
    final_steel_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )


def convert_heat_to_scrap_yield_model_input(heat: Heat) -> ScrapYieldModelInput:
    return ScrapYieldModelInput(
        raw_fe_weight=heat.raw_fe_weight,
        scrap_weights=heat.get_scrap_map(),
        pellet_weight=heat.pellets_weight,
        briquetes_weight=heat.briquets_weight,
        corrected_tap_alloys_weight=heat.yield_corrected_tap_alloys_weight,
    )


def convert_heat_to_scrap_yield_model_output(heat: Heat) -> ScrapYieldModelOutput:
    return ScrapYieldModelOutput(final_steel_weight=heat.steel_weight_from_stand_without_slag)
