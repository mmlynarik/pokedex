import math
from typing import Any, Collection, Dict, List, Sequence, Tuple
import pandas as pd
import attr
import numpy as np
import statsmodels.api as sm
from attr_runtime_validation.validators import ValidationError
from immutables import Map
from statsmodels.regression.linear_model import RegressionResults

from scrap_core import vectorize_values_total, vectorize_values
from scrap_core.yieldmodel.yield_model_filter import is_heat_valid

from .. import (
    SUPPORTED_SCRAP_TYPES,
    Chem,
    ScrapOrder,
    ScrapType,
    between,
    positive_finite,
    reverse_vectorize,
    scrap_weights_converter,
    vectorize_scrap_weights,
)
from ..datamodel import Heat
from .datamodel import ScrapYieldModelOutput, convert_heat_to_scrap_yield_model_output

UNSUPPORTED_SCRAP_WARNING_SUFFIX = "is not a supported scrap - heat skipped."

# These percentages are assumptions about Fe (and usable alloys) content in scrap
# TODO these values are used in L2 system -> maybe we can load them from there
SCRAP_FE_COEFS: Dict = {
    "1PIT": 0.9,
    "2PIT": 0.8,
    "1PIT A2": 0.85,
    "2PIT A2": 0.8,
    "DSI": 0.85,
    "DSI A1 2": 0.8,
    "DSI A1 3": 0.85,
    "STS": 0.5,
    "SRB": 0.7,
    "PIG IRON": 0.85,
    "BPIT": 0.7,
}

FE_COEFS_DICT: Dict = dict(
    zip(SUPPORTED_SCRAP_TYPES, vectorize_values(SUPPORTED_SCRAP_TYPES, SCRAP_FE_COEFS, 1.0))
)
FE_COEFS_DICT.update({"pellets": 0.6, "briquettes": 0.6})


# TODO merge with RawFeChem and use everywhere
@attr.s(slots=True, frozen=True)
class PigIronBurningChems:
    C: float = attr.ib(validator=[attr.validators.instance_of(float), positive_finite], converter=float)
    P: float = attr.ib(validator=[attr.validators.instance_of(float), positive_finite], converter=float)
    Si: float = attr.ib(validator=[attr.validators.instance_of(float), positive_finite], converter=float)
    Mn: float = attr.ib(validator=[attr.validators.instance_of(float), positive_finite], converter=float)

    def get_chem(self, chem: Chem) -> float:
        chem_lower = chem.lower()
        if chem_lower == "c":
            return self.C
        if chem_lower == "p":
            return self.P
        if chem_lower == "si":
            return self.Si
        if chem_lower == "mn":
            return self.Mn
        raise Exception(f"Unknown chem {chem}")

    @classmethod
    def all_chems(cls) -> List[str]:
        return ["C", "P", "Si", "Mn"]


@attr.s(slots=True, frozen=True)
class PreciseScrapYieldModelInput:
    raw_fe_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    scrap_weights: Map = attr.ib(
        validator=attr.validators.instance_of(Map), converter=scrap_weights_converter  # type: ignore
    )
    pellet_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    briquetes_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    # TODO replace with separate tap alloys weights and make separate correction model
    corrected_tap_alloys_weight: float = attr.ib(
        validator=[attr.validators.instance_of(float), positive_finite], converter=float
    )
    after_desulf: PigIronBurningChems = attr.ib()
    eob: PigIronBurningChems = attr.ib()


def input_data_to_input_vector(
    scrap_order: ScrapOrder, input_data: PreciseScrapYieldModelInput
) -> np.ndarray:
    scrap_weights = vectorize_scrap_weights(scrap_order, input_data.scrap_weights)
    pig_iron_wo_chem = get_steel_weight_from_pig_iron(input_data)
    return np.array([*scrap_weights, pig_iron_wo_chem, input_data.pellet_weight, input_data.briquetes_weight])


# TODO save model parameters to file and load them
class PreciseScrapYieldModel:
    def __init__(self, scrap_order: ScrapOrder, weights):
        self.weights = weights
        self.scrap_order = scrap_order

    def calculate(self, input_data: PreciseScrapYieldModelInput) -> ScrapYieldModelOutput:
        input_vector = input_data_to_input_vector(self.scrap_order, input_data)
        return ScrapYieldModelOutput(
            (self.weights * input_vector).sum() + input_data.corrected_tap_alloys_weight
        )

    def calculate_batch(self, input_data: List[PreciseScrapYieldModelInput]) -> List[ScrapYieldModelOutput]:
        return [self.calculate(one_heat) for one_heat in input_data]


def get_steel_weight_from_pig_iron(input_data: PreciseScrapYieldModelInput) -> float:
    # TODO bad percentage loss calculation - we cannot subtract percentages from different weights
    percentage_losses = (
        (input_data.after_desulf.C - input_data.eob.C)
        + (input_data.after_desulf.P - input_data.eob.P)
        + (input_data.after_desulf.Si - input_data.eob.Si)
        + (input_data.after_desulf.Mn - input_data.eob.Mn)
    )
    real_losses = input_data.raw_fe_weight * (percentage_losses / 100)
    return input_data.raw_fe_weight - real_losses


def training_data_to_output_vector(
    input_data: PreciseScrapYieldModelInput, output_data: ScrapYieldModelOutput
) -> np.ndarray:
    return np.array([output_data.final_steel_weight - input_data.corrected_tap_alloys_weight])


def vectorize_heats(
    scrap_order: ScrapOrder,
    training_data: Sequence[Tuple[PreciseScrapYieldModelInput, ScrapYieldModelOutput]],
) -> Tuple[np.ndarray, np.ndarray]:
    X = np.array([input_data_to_input_vector(scrap_order, input_data) for input_data, _ in training_data])
    y = np.array(
        [training_data_to_output_vector(input_data, output_data) for input_data, output_data in training_data]
    )
    return X, y


def train_precise_scrap_yield_model_with_results(
    scrap_order: ScrapOrder,
    training_data: Sequence[Tuple[PreciseScrapYieldModelInput, ScrapYieldModelOutput]],
) -> Tuple[PreciseScrapYieldModel, RegressionResults]:
    x, y = vectorize_heats(scrap_order, training_data)
    ols_model = sm.OLS(y, x)
    results = ols_model.fit()
    return PreciseScrapYieldModel(scrap_order, results.params), results


def train_precise_scrap_yield_model(
    scrap_order: ScrapOrder,
    training_data: Sequence[Tuple[PreciseScrapYieldModelInput, ScrapYieldModelOutput]],
) -> PreciseScrapYieldModel:
    return train_precise_scrap_yield_model_with_results(scrap_order, training_data)[0]


def train_precise_scrap_yield_model_from_heats(
    scrap_order: ScrapOrder,
    heats: List[Heat],
) -> Tuple[PreciseScrapYieldModel, RegressionResults]:
    training_data = [
        (
            heat_to_precise_scrap_yield_model_input(heat),
            convert_heat_to_scrap_yield_model_output(heat),
        )
        for heat in heats
    ]
    return train_precise_scrap_yield_model_with_results(scrap_order, training_data)


def prepare_heats(heats: List[Heat], heat_db_data: pd.DataFrame) -> Tuple[List[Heat], List[str]]:
    list_of_heats = []
    list_of_errors = []
    for heat in heats:
        try:
            list_of_heats.append(
                validate_heat_for_yieldmodel_training(heat, heat_db_data.loc[heat.heat_key].fillna(0))
            )
        # TODO TypeError is needed due to invalid value passed to indexer,
        #   this bug is present somewhere in data from 2020-01-01 to 2021-09-01
        #   and is visible e.g. on heats (19002, 2021), (19003, 2021), (19004, 2021), (19005, 2021)
        except (ValueError, ValidationError, KeyError, TypeError) as e:
            list_of_errors.append(f"{heat.heat_key}: {e}")
    return list_of_heats, list_of_errors


def heat_to_precise_scrap_yield_model_input(heat: Heat) -> PreciseScrapYieldModelInput:
    return PreciseScrapYieldModelInput(
        heat.raw_fe_weight,
        heat.get_scrap_map(),
        heat.pellets_weight,
        heat.briquets_weight,
        heat.yield_corrected_tap_alloys_weight,
        PigIronBurningChems(
            heat.after_desulf.C, heat.after_desulf.P, heat.after_desulf.Si, heat.after_desulf.Mn
        ),
        PigIronBurningChems(
            heat.get_last_known_analysis_before_alloying().C,
            heat.get_last_known_analysis_before_alloying().P,
            heat.get_last_known_analysis_before_alloying().Si,
            heat.get_last_known_analysis_before_alloying().Mn,
        ),
    )


def yield_converter(value: Any) -> float:
    return max(min(float(value), 1.0), 0.0)


def std_converter(value: Any) -> float:
    new_value = float(value)
    if not math.isfinite(new_value):
        return 100.0
    return new_value


@attr.s(slots=True, frozen=True)
class YieldEstimate:
    yield_mean: float = attr.ib(validator=between(0.0, 1.0), converter=yield_converter)
    yield_std: float = attr.ib(validator=positive_finite, converter=std_converter)

    def get_lower_bound(self, std_multiplier: float) -> float:
        return self.yield_mean - (self.yield_std * std_multiplier)

    def get_upper_bound(self, std_multiplier: float) -> float:
        return self.yield_mean + (self.yield_std * std_multiplier)


def training_results_to_scrap_yields(
    scrap_order: ScrapOrder, results: RegressionResults
) -> Dict[ScrapType, YieldEstimate]:
    scrap_count = len(scrap_order)
    return reverse_vectorize(
        scrap_order,
        [
            YieldEstimate(mean, std)
            for mean, std in zip(results.params[:scrap_count], results.bse[:scrap_count])
        ],
        YieldEstimate(0.0, 1000.0),
    )


# Max yield is optimistic yield estimate - if we get more than that it's suspicious
# Optimistic estimate for scrap yield is 100%
# Optimistic estimate for pig iron yield is everything but chems that burned
# Optimistic estimate for briquets and pellets is 60% - expert estimate
# - top pellets have 65% Fe but we will never get everything to steel
# Tap alloys are already yield corrected with table values - we know precise values for them
def max_yield(heat: Heat) -> float:
    return heat.steel_weight_from_stand_without_slag / (
        sum(heat.get_scrap_map().values())
        + get_steel_weight_from_pig_iron(heat_to_precise_scrap_yield_model_input(heat))
        + (heat.pellets_weight * 0.6)
        + (heat.briquets_weight * 0.6)
        + heat.yield_corrected_tap_alloys_weight
    )


def validate_heat_for_yieldmodel_training(heat: Heat, df_row: pd.Series) -> Heat:
    # Remove heats with returned steel-
    # There is only small number of heats with returned steel there is little benefit of including these
    if heat.returned_steel_weight != 0.0:
        raise ValueError("Return steel weight is not 0.")

    # Remove heats which use large DSI weights
    if heat.get_scrap_weight("DSI") >= 10000.0:
        raise ValueError("Uses too large DSI weight.")
    # Remove heats with unrealistically high or low yields - probably wrong data
    if not is_heat_valid(heat, df_row, 0.15):  # TODO find best coef
        raise ValueError(f"{heat.heat_key} too low or high Fe content - heat is suspicious")

    # TODO this is a hack - find a more natural way how to validate all data needed
    _ = heat_to_precise_scrap_yield_model_input(heat)  # this accesses all attributes that we need to be valid
    _ = convert_heat_to_scrap_yield_model_output(heat)

    for scrap in heat.scrap:
        if scrap.kind not in SUPPORTED_SCRAP_TYPES:
            raise ValueError(f"{scrap.kind} {UNSUPPORTED_SCRAP_WARNING_SUFFIX}")
        if scrap.kind == "XXX" or scrap.kind == "TRM":
            raise ValueError(f"We do not have Fe chemistry for {scrap.kind}")
    return heat


def get_scrap_usages(
    scrap_order: ScrapOrder, scraps_per_heat: Collection[Map[ScrapType, float]]
) -> np.ndarray:
    weights = [vectorize_scrap_weights(scrap_order, scrap_map) for scrap_map in scraps_per_heat]
    return np.array(weights).sum(axis=0)


def get_yield_estimates(heats: List[Heat]) -> Dict[ScrapType, YieldEstimate]:
    training_data = heats_to_training_data(heats)
    unknown_fe_loss, unknown_rest_loss = get_losses(training_data)
    results_wo_pigiron = train_ols_lin_regression(
        unknown_rest_loss,
        np.array(
            [
                input_data_to_input_vector_wo_pigiron(SUPPORTED_SCRAP_TYPES, input_data)
                for input_data, _ in training_data
            ]
        ),
    )
    results_w_pigiron = train_ols_lin_regression(
        unknown_fe_loss,
        np.array([np.array([get_steel_weight_from_pig_iron(x)]) for x in heats]),
    )

    weights, stds = get_final_weights_and_stds(results_wo_pigiron, results_w_pigiron, SUPPORTED_SCRAP_TYPES)
    return model_weights_and_stds_to_scrap_yield_estimates(SUPPORTED_SCRAP_TYPES, weights, stds)


def get_weighted_average_estimates(
    heats: List[Heat], yield_estimates: Dict[ScrapType, YieldEstimate]
) -> Tuple[float, float]:
    scrap_usages = get_scrap_usages(SUPPORTED_SCRAP_TYPES, [h.get_scrap_map() for h in heats]).reshape(-1, 1)
    return get_weighted_mean_std(
        [(yield_estimates[scrap_type], weight) for scrap_type, weight in zip(yield_estimates, scrap_usages)]
    )


def get_weighted_mean_std(
    estimates_and_weights: Collection[Tuple[YieldEstimate, float]]
) -> Tuple[float, float]:
    weights_sum = sum([weight for _, weight in estimates_and_weights])
    if weights_sum == 0.0:
        return np.NaN, np.NaN
    avg = sum([weight / weights_sum * estimate.yield_mean for estimate, weight in estimates_and_weights])
    var = sum(
        [(weight / weights_sum * estimate.yield_std) ** 2 for estimate, weight in estimates_and_weights]
    )
    return float(avg), float(var ** (1 / 2))


def adjust_scrap_weight(scrap_type: str, weight: float) -> float:
    return weight * FE_COEFS_DICT[scrap_type]


def adjust_scrap_loss(scrap_type: str, loss: float) -> float:
    return loss + (1 - FE_COEFS_DICT[scrap_type])


def heats_to_training_data(
    heats: List[Heat],
) -> Sequence[Tuple[PreciseScrapYieldModelInput, ScrapYieldModelOutput]]:
    return [
        (
            heat_to_precise_scrap_yield_model_input(heat),
            convert_heat_to_scrap_yield_model_output(heat),
        )
        for heat in heats
    ]


def get_losses(
    training_data: Sequence[Tuple[PreciseScrapYieldModelInput, ScrapYieldModelOutput]]
) -> Tuple[np.ndarray, np.ndarray]:
    raw_fe_weights = np.array([x[0].raw_fe_weight for x in training_data])
    scrap_weights = np.array([sum(x[0].scrap_weights.values()) for x in training_data])
    briquetes_weight = np.array([x[0].briquetes_weight for x in training_data])
    pellets_weight = np.array([x[0].pellet_weight for x in training_data])
    tap_alloys = np.array([x[0].corrected_tap_alloys_weight for x in training_data])
    total_weight = raw_fe_weights + scrap_weights + tap_alloys + briquetes_weight + pellets_weight

    known_fe_loss = np.array(
        [-(get_steel_weight_from_pig_iron(x[0]) - x[0].raw_fe_weight) for x in training_data]
    )
    known_other_loss = get_known_other_loss([x[0] for x in training_data])
    steel_weight = np.array([x[1].final_steel_weight for x in training_data])
    unknown_loss = np.array(total_weight - tap_alloys - known_fe_loss - known_other_loss - steel_weight)
    unknown_fe_loss = np.array(
        (raw_fe_weights - known_fe_loss)
        / (
            raw_fe_weights
            + scrap_weights
            + briquetes_weight
            + pellets_weight
            - known_fe_loss
            - known_other_loss
        )
        * unknown_loss
    )
    unknown_rest_loss = np.array(
        (scrap_weights + briquetes_weight + pellets_weight - known_other_loss)
        / (
            raw_fe_weights
            + scrap_weights
            + briquetes_weight
            + pellets_weight
            - known_fe_loss
            - known_other_loss
        )
        * unknown_loss
    )
    return unknown_fe_loss, unknown_rest_loss


def get_known_other_loss(training_data_inputs: Sequence[PreciseScrapYieldModelInput]) -> np.ndarray:
    scrap_losses = []
    for x in training_data_inputs:
        current_scrap_loss = (x.briquetes_weight * (1 - FE_COEFS_DICT["briquettes"])) + (
            x.pellet_weight * (1 - FE_COEFS_DICT["pellets"])
        )
        for key, value in x.scrap_weights.items():
            current_scrap_loss += value * (1 - FE_COEFS_DICT[key])
        scrap_losses.append(current_scrap_loss)
    return np.array(scrap_losses)


def input_data_to_input_vector_wo_pigiron(
    scrap_order: ScrapOrder, input_data: PreciseScrapYieldModelInput
) -> np.ndarray:
    new_scrap_weights: Map = Map({k: adjust_scrap_weight(k, v) for k, v in input_data.scrap_weights.items()})
    new_input_data = attr.evolve(
        input_data,
        pellet_weight=input_data.pellet_weight * FE_COEFS_DICT["pellets"],
        briquetes_weight=input_data.briquetes_weight * FE_COEFS_DICT["briquettes"],
        scrap_weights=new_scrap_weights,
    )

    scrap_weights = vectorize_scrap_weights(scrap_order, new_input_data.scrap_weights)
    return np.array([*scrap_weights, new_input_data.pellet_weight, new_input_data.briquetes_weight])


def train_ols_lin_regression(y: np.ndarray, x: np.ndarray) -> RegressionResults:
    ols_model = sm.OLS(y, x)
    return ols_model.fit()


def get_final_weights_and_stds(
    results_wo_pigiron: RegressionResults, results_w_pigiron: RegressionResults, scrap_order: ScrapOrder
) -> Tuple[np.ndarray, np.ndarray]:
    scrap_losses = {
        scrap_type: adjust_scrap_loss(scrap_type, loss)
        for scrap_type, loss in zip(scrap_order, results_wo_pigiron.params[:-2])
    }
    weights = np.array(
        vectorize_values_total(scrap_order, scrap_losses)
        + list(results_w_pigiron.params)
        + [
            results_wo_pigiron.params[-2] + (1 - FE_COEFS_DICT["pellets"]),
            results_wo_pigiron.params[-1] + (1 - FE_COEFS_DICT["briquettes"]),
        ]
    )
    stds = np.array(
        list(results_wo_pigiron.bse[:-2]) + list(results_w_pigiron.bse) + list(results_wo_pigiron.bse[-2:])
    )
    return 1 - weights, stds


def model_weights_and_stds_to_scrap_yield_estimates(
    scrap_order: ScrapOrder, weights: np.ndarray, stds: np.ndarray
) -> Dict[ScrapType, YieldEstimate]:
    scrap_count = len(scrap_order)
    return reverse_vectorize(
        scrap_order,
        [YieldEstimate(mean, std) for mean, std in zip(weights[:scrap_count], stds[:scrap_count])],
        YieldEstimate(0.0, 1000.0),
    )
