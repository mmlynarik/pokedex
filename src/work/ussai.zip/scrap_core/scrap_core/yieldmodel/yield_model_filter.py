from datetime import date

import numpy as np
import pandas as pd
import pymssql
from sqlalchemy.engine import create_engine, URL
from typing import Callable
from scrap_core.datamodel.model import ChemAnalysis, Heat
from scrap_core.datamodel.oko import OkoDB


def sum_chems(analysis: ChemAnalysis) -> float:
    return (
        analysis.C
        + analysis.Mn
        + analysis.Si
        + analysis.P
        + analysis.S
        + analysis.Al
        + analysis.N
        + analysis.Cu
        + analysis.Ni
        + analysis.Cr
        + analysis.As
        + analysis.Sn
        + analysis.Mo
        + analysis.Ti
        + analysis.V
        + analysis.Zr
        + analysis.Nb
    )


def kg_fe_in_final_steel(heat: Heat) -> float:
    return heat.final_steel_weight * (100 - sum_chems(heat.final)) / 100


def kg_fe_in_pig_iron(heat: Heat) -> float:
    return heat.raw_fe_weight * (100 - sum_chems(heat.after_desulf)) / 100


def total_scrap_weight(heat: Heat) -> float:
    return sum(scrap.weight for scrap in heat.scrap)


# mean scrap Fe content according to our yield_model
MEAN_SCRAP_YIELD = {
    "1BBC": 0.949,
    "1BC": 0.949,
    "1BS": 0.926,
    "1DB": 0.925,
    "1HM": 0.973,
    "1IB": 0.936,
    "1PIT": 0.862,
    "1PIT A2": 0.853,
    "1RR": 0.969,
    "1SH": 0.944,
    "1SR": 0.999,
    "1TB": 0.936,
    "2BBC": 0.949,
    "2BC": 0.949,
    "2DB": 0.925,
    "2HM": 0.973,
    "2PIT": 0.874,
    "2PIT A2": 0.874,
    "2SH": 0.907,
    "BPIT": 0.896,
    "DSI": 0.808,
    "DSI A1 2": 0.808,
    "HB": 0.942,
    "HDS": 0.942,
    "HS": 0.942,
    "HSB": 0.931,
    "HSB COOL": 0.931,
    "HSD": 0.925,
    "HSK": 0.896,
    "HSR": 0.985,
    "HSR Cr": 1,
    "HST": 0.956,
    "HSZ": 0.908,
    "MCE": 0.975,
    "PAS": 0.931,
    "PIG IRON": 0.896,
    "SBS": 0.932,
    "SHS": 0.925,
    "SRB": 0.808,
    "STS": 0.999,
    "TBBC": 0.946,
    "TBC": 0.946,
    "TBS": 0.918,
    "ZBS": 0.946,
}


def get_kg_fe_in_scrap(heat: Heat, coef: float) -> float:
    total_weight = 0
    for scrap in heat.scrap:
        total_weight += scrap.weight * np.clip(MEAN_SCRAP_YIELD[scrap.kind] + coef, a_min=0, a_max=1)
    return total_weight


def kg_c_burned_lower(heat: Heat) -> float:
    c_in_raw_fe = (heat.after_desulf.C - heat.eob.C) / 100 * heat.raw_fe_weight
    c_in_scrap = 0.005 * total_scrap_weight(heat)
    # Briquets and Pellets %C content according to VIU model for March 2021
    c_in_pellets = 0.0002 * heat.pellets_weight
    c_in_briquets = 0.0017 * heat.briquets_weight
    return c_in_raw_fe + c_in_scrap + c_in_pellets + c_in_briquets


def kg_c_burned_upper(heat: Heat) -> float:
    c_in_raw_fe = (heat.after_desulf.C - heat.eob.C) / 100 * heat.raw_fe_weight
    c_in_scrap = 0.01 * total_scrap_weight(heat)
    # Briquets and Pellets %C content according to VIU model for March 2021
    c_in_pellets = 0.0015 * heat.pellets_weight
    c_in_briquets = 0.0634 * heat.briquets_weight
    return c_in_raw_fe + c_in_scrap + c_in_pellets + c_in_briquets


def is_heat_valid(heat: Heat, heat_extended_data: pd.DataFrame, coef: float) -> bool:
    output_lower = kg_fe_in_final_steel(heat) + get_fe_in_slag(heat, heat_extended_data, kg_c_burned_upper)
    output_upper = kg_fe_in_final_steel(heat) + get_fe_in_slag(heat, heat_extended_data, kg_c_burned_lower)
    upper_tap_alloy = get_tap_alloys_fe_weight_upper(heat_extended_data)
    lower_tap_alloy = get_tap_alloys_fe_weight_lower(heat_extended_data)
    input_lower = (
        kg_fe_in_pig_iron(heat)
        + get_kg_fe_in_scrap(heat, -coef)
        # Briquets and pellets have 60%Fe (lower guess according to DTP pre KK Oc2)
        + heat.briquets_weight * 0.6
        + heat.pellets_weight * 0.6
        + lower_tap_alloy
    )
    input_upper = (
        kg_fe_in_pig_iron(heat)
        + get_kg_fe_in_scrap(heat, coef)
        # Briquets and pellets have 65%Fe (upper guess according to DTP pre KK Oc2)
        + heat.briquets_weight * 0.65
        + heat.pellets_weight * 0.65
        + upper_tap_alloy
    )
    return not (output_upper < input_lower or output_lower > input_upper)


def get_tap_alloys_fe_weight_upper(heat_extended_data: pd.DataFrame) -> float:
    tap_alloys = (
        # Tap alloys Fe % content (upper guess according to DTP pre KK Oc2)
        heat_extended_data.oct_casi * 0.2
        + heat_extended_data.ocp_casi * 0.2
        + heat_extended_data.oct_feb * 0.79
        + heat_extended_data.ocp_feb * 0.79
        + heat_extended_data.oct_fecr * 0.368
        + heat_extended_data.ocp_fecr * 0.368
        + heat_extended_data.oct_mnsi * 0.118
        + heat_extended_data.ocp_mnsi * 0.118
        + heat_extended_data.oct_fesi * 0.338
        + heat_extended_data.ocp_fesi * 0.338
        + heat_extended_data.oct_fesi75 * 0.245
        + heat_extended_data.ocp_fesi75 * 0.245
        + heat_extended_data.oct_fep * 0.748
        + heat_extended_data.ocp_fep * 0.748
        + heat_extended_data.oct_femo * 0.35
        + heat_extended_data.ocp_femo * 0.35
        + heat_extended_data.oct_fenb * 0.316
        + heat_extended_data.ocp_fenb * 0.316
        + heat_extended_data.oct_fev * 0.21
        + heat_extended_data.ocp_fev * 0.21
        + heat_extended_data.oct_feti * 0.247
        + heat_extended_data.ocp_feti * 0.247
        + heat_extended_data.oct_al_bloky * 0.017
        + heat_extended_data.ocp_al_bloky * 0.017
        + heat_extended_data.oct_al_sekany * 0.013
        + heat_extended_data.ocp_al_sekany * 0.013
        + heat_extended_data.oct_al_vhanany * 0.013
        + heat_extended_data.ocp_al_vhanany * 0.013
        + heat_extended_data.oct_femn * 0.1645
        + heat_extended_data.ocp_femn * 0.1645
        + heat_extended_data.oct_femn_aff * 0.2245
        + heat_extended_data.ocp_femn_aff * 0.2245
    )
    try:
        vac_alloys = (
            heat_extended_data.vak_02_fenb_65 * 0.316
            + heat_extended_data.vak_03_koks_hrasok * 0
            + heat_extended_data.vak_04_feti_70 * 0.247
            + heat_extended_data.vak_05_al_sekany * 0.013
            + heat_extended_data.vak_07_femn_affine_80 * 0.2245
            + heat_extended_data.vak_08_fep_20 * 0.748
            + heat_extended_data.vak_15_fesi_75_trafo * 0.2556
            + heat_extended_data.vak_18_femn_kov * 0.044
            + heat_extended_data.vak_23_fesi_75_dynamo * 0.245
        )
    except AttributeError:
        vac_alloys = 0
    return tap_alloys + vac_alloys


def get_tap_alloys_fe_weight_lower(heat_extended_data: pd.DataFrame) -> float:
    tap_alloys = (
        # Tap alloys Fe % content (lower guess according to DTP pre KK Oc2)
        heat_extended_data.oct_casi * 0.12
        + heat_extended_data.ocp_casi * 0.12
        + heat_extended_data.oct_feb * 0.75
        + heat_extended_data.ocp_feb * 0.75
        + heat_extended_data.oct_fecr * 0.328
        + heat_extended_data.ocp_fecr * 0.328
        + heat_extended_data.oct_mnsi * 0.118
        + heat_extended_data.ocp_mnsi * 0.118
        + heat_extended_data.oct_fesi * 0.288
        + heat_extended_data.ocp_fesi * 0.288
        + heat_extended_data.oct_fesi75 * 0.195
        + heat_extended_data.ocp_fesi75 * 0.195
        + heat_extended_data.oct_fep * 0.708
        + heat_extended_data.ocp_fep * 0.708
        + heat_extended_data.oct_femo * 0.35
        + heat_extended_data.ocp_femo * 0.35
        + heat_extended_data.oct_fenb * 0.286
        + heat_extended_data.ocp_fenb * 0.286
        + heat_extended_data.oct_fev * 0.17
        + heat_extended_data.ocp_fev * 0.17
        + heat_extended_data.oct_feti * 0.197
        + heat_extended_data.ocp_feti * 0.197
        + heat_extended_data.oct_al_bloky * 0
        + heat_extended_data.ocp_al_bloky * 0
        + heat_extended_data.oct_al_sekany * 0
        + heat_extended_data.ocp_al_sekany * 0
        + heat_extended_data.oct_al_vhanany * 0
        + heat_extended_data.ocp_al_vhanany * 0
        + heat_extended_data.oct_femn * 0.0945
        + heat_extended_data.ocp_femn * 0.0945
        + heat_extended_data.oct_femn_aff * 0.1745
        + heat_extended_data.ocp_femn_aff * 0.1745
    )
    try:
        vac_alloys = (
            heat_extended_data.vak_02_fenb_65 * 0.286
            + heat_extended_data.vak_03_koks_hrasok * 0
            + heat_extended_data.vak_04_feti_70 * 0.197
            + heat_extended_data.vak_05_al_sekany * 0
            + heat_extended_data.vak_07_femn_affine_80 * 0.1745
            + heat_extended_data.vak_08_fep_20 * 0.708
            + heat_extended_data.vak_15_fesi_75_trafo * 0.2156
            + heat_extended_data.vak_18_femn_kov * 0.004
            + heat_extended_data.vak_23_fesi_75_dynamo * 0.195
        )
    except AttributeError:
        vac_alloys = 0
    return tap_alloys + vac_alloys


def get_fe_in_slag(heat: Heat, heat_extended_data: pd.DataFrame, burned_c: Callable[[Heat], float]):
    alloys = (
        heat_extended_data.oct_koks
        + heat_extended_data.ocp_koks
        + heat_extended_data.oct_feb
        + heat_extended_data.ocp_feb
        + heat_extended_data.oct_femn
        + heat_extended_data.ocp_femn
        + heat_extended_data.oct_femn_aff
        + heat_extended_data.ocp_femn_aff
        + heat_extended_data.oct_fesi
        + heat_extended_data.ocp_fesi
        + heat_extended_data.oct_fesi75
        + heat_extended_data.ocp_fesi75
        + heat_extended_data.oct_casi
        + heat_extended_data.ocp_casi
        + heat_extended_data.oct_mnsi
        + heat_extended_data.ocp_mnsi
        + heat_extended_data.oct_fep
        + heat_extended_data.ocp_fep
        + heat_extended_data.oct_femo
        + heat_extended_data.ocp_femo
        + heat_extended_data.oct_fenb
        + heat_extended_data.ocp_fenb
        + heat_extended_data.oct_fev
        + heat_extended_data.ocp_fev
        + heat_extended_data.oct_feti
        + heat_extended_data.ocp_feti
        + heat_extended_data.oct_fezr
        + heat_extended_data.ocp_fezr
        + heat_extended_data.oct_few
        + heat_extended_data.ocp_few
        + heat_extended_data.oct_fece
        + heat_extended_data.ocp_fece
        + heat_extended_data.oct_fecr
        + heat_extended_data.ocp_fecr
        + heat_extended_data.oct_feni
        + heat_extended_data.ocp_feni
        + heat_extended_data.oct_feco
        + heat_extended_data.ocp_feco
    )
    aluminium = (
        heat_extended_data.oct_al_bloky
        + heat_extended_data.ocp_al_bloky
        + heat_extended_data.oct_al_vhanany
        + heat_extended_data.ocp_al_vhanany
        + heat_extended_data.oct_al_granulovany
        + heat_extended_data.ocp_al_granulovany
        + heat_extended_data.oct_al_sekany
        + heat_extended_data.ocp_al_sekany
        + heat_extended_data.oct_al_tycovy
        + heat_extended_data.ocp_al_tycovy
        + heat_extended_data.oct_al_stery
        + heat_extended_data.ocp_al_stery
    )
    non_fe_addition = (
        heat_extended_data.oct_hmotn_vapno
        + heat_extended_data.oct_hmotn_magnezit_tav
        + heat_extended_data.oct_hmotn_dol_vap_tav
        + heat_extended_data.oct_hmotn_koks_konv
        + heat_extended_data.oct_slagmag
    )
    heat_input_weight = (
        heat.raw_fe_weight
        + total_scrap_weight(heat)
        + non_fe_addition
        + heat_extended_data.oct_syntet_troska
        + heat_extended_data.vak_leg_sum
        + alloys
        + heat.pellets_weight
        + heat.briquets_weight
        + aluminium
    )
    slag_weight = (
        heat_input_weight
        - heat_extended_data.ocl_hmotn_tros_p
        - heat_extended_data.oct_hmotn_tek_ocel
        - burned_c(heat)
    )
    return slag_weight / 100 * heat_extended_data.oct_fe_obsah_trosky


def get_extended_heats_data(dt_from: date, dt_to: date, oko_db: OkoDB) -> pd.DataFrame:
    heats_data_extended_query = """WITH tap_alloys_for_vacuumed_heats AS (
    SELECT
        h_cis_tavby ,
        h_rok,
        vak_00_nezadane,
        vak_01_fev,
        vak_02_fenb_65,
        vak_03_koks_hrasok,
        vak_04_feti_70,
        vak_05_al_sekany,
        vak_06_femnc,
        vak_07_femn_affine_80,
        vak_08_fep_20,
        vak_09_feb,
        vak_10_srot,
        vak_11_fesi_75_dynamo,
        vak_12_fesi_65,
        vak_13_al_drot,
        vak_14_koks,
        vak_15_fesi_75_trafo,
        vak_16_fesica,
        vak_17_fesi_90,
        vak_18_femn_kov,
        vak_19_femnn,
        vak_20_mnel,
        vak_21_sb,
        vak_22_fecr,
        vak_23_fesi_75_dynamo,
        vak_24_fesi_75_granul,
        vak_25_fesb,
        vak_26_femo,
        vak_27_cu_hutna,
        vak_28_sn,
        vak_29_sira
    FROM (
        SELECT
            h_cis_tavby ,
            h_rok,
            ocv_hmotn_leg,
            'vak_' + FORMAT(kod_legury, 'D2') + '_'
            + CONVERT(varchar, LOWER(REPLACE(REPLACE(popis, '%', ''), ' ', '_'))) COLLATE SQL_Latin1_General_Cp1251_CS_AS AS tap_alloy
        FROM oko.dbo.ds_tavba_vaku_leg dtvl
        JOIN oko.dbo.dim_vaku_leg dvl ON dtvl.ocv_kod_leg = dvl.kod_legury
        WHERE ocv_dat_cas_zasypu IS NOT NULL
        ) AS source_table
    PIVOT
    (
        SUM(ocv_hmotn_leg)
            FOR tap_alloy IN (
                vak_00_nezadane,
                vak_01_fev,
                vak_02_fenb_65,
                vak_03_koks_hrasok,
                vak_04_feti_70,
                vak_05_al_sekany,
                vak_06_femnc,
                vak_07_femn_affine_80,
                vak_08_fep_20,
                vak_09_feb,
                vak_10_srot,
                vak_11_fesi_75_dynamo,
                vak_12_fesi_65,
                vak_13_al_drot,
                vak_14_koks,
                vak_15_fesi_75_trafo,
                vak_16_fesica,
                vak_17_fesi_90,
                vak_18_femn_kov,
                vak_19_femnn,
                vak_20_mnel,
                vak_21_sb,
                vak_22_fecr,
                vak_23_fesi_75_dynamo,
                vak_24_fesi_75_granul,
                vak_25_fesb,
                vak_26_femo,
                vak_27_cu_hutna,
                vak_28_sn,
                vak_29_sira
            )
    ) AS pivot_table
    )
    SELECT
        oct_koks,
        ocp_koks,
        oct_casi,
        ocp_casi,
        oct_feb,
        ocp_feb,
        oct_fecr,
        ocp_fecr,
        oct_mnsi,
        ocp_mnsi,
        oct_fesi,
        ocp_fesi,
        oct_fesi75,
        ocp_fesi75,
        oct_feni,
        ocp_feni,
        oct_fep,
        ocp_fep,
        oct_fece,
        ocp_fece,
        oct_feco,
        ocp_feco,
        oct_femo,
        ocp_femo,
        oct_fenb,
        ocp_fenb,
        oct_fev,
        ocp_fev,
        oct_feti,
        ocp_feti,
        oct_fezr,
        ocp_fezr,
        oct_al_bloky,
        ocp_al_bloky,
        oct_al_sekany,
        ocp_al_sekany,
        oct_al_vhanany,
        ocp_al_vhanany,
        oct_al_granulovany,
        ocp_al_granulovany,
        oct_al_stery,
        ocp_al_stery,
        oct_femn,
        ocp_femn,
        oct_al_tycovy,
        ocp_al_tycovy,
        oct_fe_obsah_trosky,
        oct_few,
        ocp_few,
        oct_femn_aff,
        ocp_femn_aff,
        ocl_hmotn_tros_p,
        oct_hmotn_tek_ocel,
        oct_hmotn_vapno,
        oct_hmotn_magnezit_tav,
        oct_hmotn_dol_vap_tav,
        oct_hmotn_koks_konv,
        oct_slagmag,
        oct_syntet_troska,
        oct_hmotn_sur_zel * 10 AS pig_iron_w,
        oct_cis_tavby as heat_no,
        oct_rok_vyroby_tavby as heat_year,
        tavh.*

    FROM oko.dbo.ds_tavba dt
    LEFT JOIN tap_alloys_for_vacuumed_heats tavh on dt.oct_cis_tavby = tavh.h_cis_tavby and dt.oct_rok_vyroby_tavby = tavh.h_rok
    WHERE dt.oc_zac_vsadz >= %(dt_from)s AND dt.oc_zac_vsadz < %(dt_to)s
    """
    engine = create_engine(URL.create("mssql+pymssql", **oko_db))
    with engine.begin() as conn:
        heat_extended_df = pd.read_sql(
            heats_data_extended_query, conn, params={"dt_from": dt_from, "dt_to": dt_to}
        )
        heat_extended_df["vak_leg_sum"] = heat_extended_df[
            [col for col in heat_extended_df.columns if col.startswith("vak")]
        ].sum(axis=1)
        heat_extended_df["heat_no"] = heat_extended_df["heat_no"].astype(int)
        heat_extended_df["heat_year"] = heat_extended_df["heat_year"].astype(int)
        heat_extended_df = heat_extended_df.set_index(["heat_no", "heat_year"])
    return heat_extended_df
