from functools import lru_cache

from .. import SUPPORTED_SCRAP_TYPES
from .datamodel import ScrapYieldModelInput, ScrapYieldModelOutput, convert_heat_to_scrap_yield_model_input
from .yield_model import (
    BRIQUETES_YIELD_V1,
    BRIQUETES_YIELD_V2,
    PELLETS_YIELD_V1,
    PELLETS_YIELD_V2,
    PIG_IRON_YIELD_V1,
    PIG_IRON_YIELD_V2,
    SCRAP_TYPE_YIELDS_V1,
    SCRAP_TYPE_YIELDS_V2,
    ScrapYieldModel,
    YieldModelSettings,
)


@lru_cache(maxsize=1)
def get_yield_model(version: int = 2) -> ScrapYieldModel:
    if version == 2:
        return ScrapYieldModel(
            SUPPORTED_SCRAP_TYPES,
            SCRAP_TYPE_YIELDS_V2,
            PIG_IRON_YIELD_V2,
            PELLETS_YIELD_V2,
            BRIQUETES_YIELD_V2,
        )
    raise Exception(f"Invalid model version {version} - valid versions are: [2]")
