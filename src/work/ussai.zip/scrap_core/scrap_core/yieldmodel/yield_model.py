from typing import Dict, List, Mapping

import attr
import numpy as np
import torch

from scrap_core import ScrapOrder, ScrapType, between, vectorize_scrap_weights, vectorize_values_total
from scrap_core.yieldmodel.datamodel import ScrapYieldModelInput, ScrapYieldModelOutput

SCRAP_TYPE_YIELDS_V1: Dict[ScrapType, float] = {
    "HSR": 0.94,
    "HSR Cr": 0.96,
    "HSZ": 0.93571399,
    "HSB": 0.89531722,
    "HDS": 0.98,
    "HSK": 0.92988228,
    "HSD": 0.8657072,
    "HS": 0.89104219,
    "PAS": 0.91330234,
    "2HM": 0.88118659,
    "1HM": 0.90048671,
    "MCE": 0.92453217,
    "1BC": 0.91278082,
    "HST": 0.91191033,
    "TBS": 0.91992411,
    "ZBS": 0.88736886,
    "SBS": 0.90313011,
    "2BC": 0.93,
    "1IB": 0.89088145,
    "1DB": 0.88342377,
    "1TB": 0.91318868,
    "2DB": 0.88,
    "1SH": 0.89053283,
    "2SH": 0.85918593,
    "1RR": 0.90728088,
    "TBC": 0.9155285,
    "1SR": 0.94870741,
    "STS": 0.86313878,
    "1BBC": 0.90196508,
    "2BBC": 0.91,
    "TBBC": 0.93,
    "XXX": 0.95,
    "HB": 0.90576934,
    "1BS": 0.89064789,
    "SHS": 0.88756393,
    "DSI": 0.74526938,
    "SRB": 0.6,
    "PIG IRON": 0.80074303,
    "1PIT": 0.803311,
    "BPIT": 0.60601805,
    "2PIT": 0.81746133,
    "TRM": 0.80022972,
}

PIG_IRON_YIELD_V1 = 0.91511894
PELLETS_YIELD_V1 = 0.25
BRIQUETES_YIELD_V1 = 0.31728747

SCRAP_TYPE_YIELDS_V2: Dict[ScrapType, float] = {
    "HSR": 0.9199468690359691,
    "HSA": 0.9274557238965337,  # temp solution copied from HS
    "HSCA": 0.9128246059132386,  # temp solution copied from HSR Cr
    "HSR Cr": 0.9128246059132386,
    "HSZ": 0.9137846251398762,
    "HSB": 0.939854123235178,
    "HSB COOL": 0.939854123235178,
    "HDS": 0.9274557238965337,
    "HSK": 0.7580285039162207,
    "HSD": 0.9077972300388861,
    "HS": 0.9274557238965337,
    "PAS": 0.9097692499477573,
    "2HM": 0.95738568196435,
    "1HM": 0.95738568196435,
    "MCE": 0.9468175447134202,
    "1BC": 0.9256039001147687,
    "HST": 0.9427983452245264,
    "TBS": 0.8969940165977468,
    "ZBS": 0.9262907576716093,
    "SBS": 0.929979885622596,
    "2BC": 0.9256039001147687,
    "1IB": 0.9292330777325399,
    "1DB": 0.936425565464339,
    "1TB": 0.9440974994907761,
    "2DB": 0.936425565464339,
    "1SH": 0.928576339917221,
    "2SH": 0.8916735426196278,
    "1RR": 0.9407648699612153,
    "TBC": 0.9375904578499781,
    "1SR": 0.9687264100903402,
    "STS": 0.9687264100903402,
    "1BBC": 0.9256039001147687,
    "2BBC": 0.9256039001147687,
    "TBBC": 0.9375904578499781,
    "HB": 0.9994653034107146,
    "1BS": 0.913169143297463,
    "SHS": 0.9066629768366203,
    "DSI": 0.8299209377983056,
    "SRB": 0.8299209377983056,
    "PIG IRON": 0.8877674287863918,
    "1PIT": 0.8446975185928878,
    "BPIT": 0.8877674287863918,
    "2PIT": 0.8580764191085463,
    "TRM": 1.0,
    "1PIT A2": 0.8310130573518011,
    "2PIT A2": 0.8580764191085463,
    "DSI A1 2": 0.7359492109580925,
    "DSI A1 3": 0.7359492109580925,  # temp solution copied from DSI A1 2
    "XXX": 0.0,
}

PIG_IRON_CORRECTION_V2 = 0.94646
PIG_IRON_YIELD_V2 = 0.9550770334464658 * PIG_IRON_CORRECTION_V2
PELLETS_YIELD_V2 = 0.39517611637707456
BRIQUETES_YIELD_V2 = 0.5096781633072601


@attr.s(slots=True, frozen=True)
class YieldModelSettings:
    version: int = attr.ib(default=2, validator=between(1, 2), converter=int)


class ScrapYieldModel:
    def __init__(
        self,
        scrap_order: ScrapOrder,
        scrap_yields: Mapping[ScrapType, float],
        pig_iron_yield: float,
        pellets_yield: float,
        briquetes_yield: float,
    ):
        self.scrap_order = scrap_order
        self.weights = np.array(
            vectorize_values_total(scrap_order, scrap_yields)
            + [pig_iron_yield, pellets_yield, briquetes_yield]
        )
        self.fast_weights = torch.Tensor(vectorize_values_total(scrap_order, scrap_yields))

    def get_input_vector_for_yield_calculation(self, input_data: ScrapYieldModelInput) -> np.ndarray:
        return np.array(
            [
                *vectorize_scrap_weights(self.scrap_order, input_data.scrap_weights),
                input_data.raw_fe_weight,
                input_data.pellet_weight,
                input_data.briquetes_weight,
            ]
        )

    def calculate(self, input_data: ScrapYieldModelInput) -> ScrapYieldModelOutput:
        return ScrapYieldModelOutput(
            (self.weights * self.get_input_vector_for_yield_calculation(input_data)).sum()
            + input_data.corrected_tap_alloys_weight
        )

    def calculate_batch(self, input_data: List[ScrapYieldModelInput]) -> List[ScrapYieldModelOutput]:
        return [self.calculate(one_heat) for one_heat in input_data]

    def calculate_batch_fast(self, scrap_matrix: torch.Tensor) -> torch.Tensor:
        return torch.matmul(scrap_matrix, self.fast_weights)  # pylint: disable=no-member
