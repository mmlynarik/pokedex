from typing import Tuple, Optional

import numpy as np
from immutables import Map

from scrap_core import Chem, ScrapCharge
from scrap_core.blendmodel import ScrapBlendModelInput, get_blend_model
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    get_corr_tech_model,
    CorrectionTechnologyType,
)
from scrap_core.optimization.datamodel import HeatInputs, ModelSettings, MultipleHeatsOptimizationInput


def get_ct_risk(
    scrap_charge: ScrapCharge,
    chem: Optional[Chem],
    heat: HeatInputs,
    model_settings: ModelSettings,
    pellets_weight: int = 0,
    briquetes_weight: int = 0,
    ct_type: Optional[CorrectionTechnologyType] = None,
    joint: bool = False,
) -> float:
    """Calculates marginal or joint ct risk"""
    blend_model = get_blend_model(model_settings.blend_model_settings.version)
    supported_chems = model_settings.correction_technologies_settings.chems_for_correction_technologies
    chems = supported_chems if joint else (chem,)
    corr_tech_model = get_corr_tech_model(model_settings.correction_technologies_settings.version, chems)
    mix_mapping = model_settings.optimizer_settings.scrap_mix_mapping
    input_data = ScrapBlendModelInput(
        heat.pig_iron_weight,
        heat.pig_iron_chem,
        scrap_weights=scrap_charge,
        pellets_weight=pellets_weight,
        briquetes_weight=briquetes_weight,
        scrap_mix_mapping=mix_mapping,  # type: ignore
    )

    bmo = blend_model.calculate(input_data)
    ctmo = corr_tech_model.calculate(CorrectionTechnologiesModelInput(heat.grade_planned, bmo))
    if ct_type is None:
        return ctmo.undesirable_corr_tech_proba
    elif ct_type == CorrectionTechnologyType.REBLOW:
        return ctmo.reblow_proba
    elif ct_type == CorrectionTechnologyType.RECLASSIFICATION:
        return ctmo.reclass_proba
    else:
        raise ValueError(f"CT type {ct_type} is not supported for ct risk calculation.")


def get_ct_risks(
    scrap_charge: ScrapCharge,
    heat: HeatInputs,
    settings: ModelSettings,
    pellets_weight: int = 0,
    briquetes_weight: int = 0,
    risk_type: Optional[CorrectionTechnologyType] = None,
) -> Map[Chem, float]:
    """Calculates marginal ct risks for all supported chems"""
    return Map(
        {
            chem: get_ct_risk(scrap_charge, chem, heat, settings, pellets_weight, briquetes_weight, risk_type)
            for chem in settings.supported_chems
        }
    )


# TODO Please remove this comment, when it is no longer true :)
#  At the moment this function is not used anywhere,
#  but it (or its variant) may be useful in some reports, so I kept it here
def expected_mean_ct_risk(
    input_data: MultipleHeatsOptimizationInput, scrap_charges: Tuple[ScrapCharge, ...]
) -> float:
    if not scrap_charges:
        raise AttributeError(f"Can't calculate mean ct risk for empty list of scrap charges: {scrap_charges}")

    model_settings = input_data.model_settings

    blend_model = get_blend_model(model_settings.blend_model_settings.version)
    corr_tech_chems = model_settings.correction_technologies_settings.chems_for_correction_technologies
    corr_tech_model = get_corr_tech_model(
        model_settings.correction_technologies_settings.version,
        corr_tech_chems,
    )

    ct_risk = []
    for heat, scrap_charge in zip(input_data.heats, scrap_charges):
        mix_mapping = model_settings.optimizer_settings.scrap_mix_mapping
        blend_model_input = ScrapBlendModelInput(
            heat.pig_iron_weight, heat.pig_iron_chem, scrap_charge, 0.0, 0.0, mix_mapping  # type: ignore
        )
        blend_model_output = blend_model.calculate(blend_model_input)
        corr_tech_model_output = corr_tech_model.calculate(
            CorrectionTechnologiesModelInput(heat.grade_planned, blend_model_output)
        )
        ct_risk.append(corr_tech_model_output.undesirable_corr_tech_proba)

    return float(np.mean(ct_risk))


def expected_ct_risk_deviation(
    input_data: MultipleHeatsOptimizationInput, scrap_charges: Tuple[ScrapCharge, ...]
) -> float:
    if not scrap_charges:
        raise AttributeError(f"Can't calculate mean ct risk for empty list of scrap charges: {scrap_charges}")

    model_settings = input_data.model_settings

    ct_risk_deviations = []
    for heat, scrap_charge in zip(input_data.heats, scrap_charges):
        expected_ct_risk_per_chem = np.array(
            [get_ct_risk(scrap_charge, chem, heat, model_settings) for chem in model_settings.supported_chems]
        )
        limit = heat.relaxable_risk_limit
        target_ct_risk_per_chem = np.array(
            [getattr(limit, chem).aim for chem in model_settings.supported_chems]
        )
        ct_risk_deviations.append(abs(sum(target_ct_risk_per_chem - expected_ct_risk_per_chem)))

    return float(np.mean(ct_risk_deviations))
