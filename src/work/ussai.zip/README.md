# Value in use

## Table of contents

- [Value in use](#value-in-use)
  - [Table of contents](#table-of-contents)
  - [Components overview](#components-overview)
  - [Beware of proxy (USS network and VPN only)](#beware-of-proxy-uss-network-and-vpn-only)
    - [Docker](#docker)
  - [How to setup dev environment](#how-to-setup-dev-environment)
  - [How to update environment from yml](#how-to-update-environment-from-yml)
  - [How to build docker image](#how-to-build-docker-image)
    - [In USS](#in-uss)
  - [How to install Python package directly from GitHub](#how-to-install-python-package-directly-from-github)
  - [How to run](#how-to-run)
    - [DB Connections](#db-connections)
      - [DB account is locked](#db-account-is-locked)
      - [Oracle Instant Client](#oracle-instant-client)
    - [Web (django)](#web-django)
      - [Gunicorn (Unix only)](#gunicorn-unix-only)
    - [Message Queue (redis)](#message-queue-redis)
    - [Workers (dramatiq)](#workers-dramatiq)
      - [CPU intensive tasks](#cpu-intensive-tasks)
      - [`dramatiq` remarks](#dramatiq-remarks)
    - [Periodic tasks (periodiq)](#periodic-tasks-periodiq)
      - [`periodiq` remarks](#periodiq-remarks)
      - [Possible improvements](#possible-improvements)
    - [Docker](#docker-1)
    - [Remarks](#remarks)
  - [Django dash caveats](#django-dash-caveats)
    - [Django dash static files hack](#django-dash-static-files-hack)
  - [Creating tests](#creating-tests)
    - [Exporting data for selenium tests](#exporting-data-for-selenium-tests)
  - [Running tests](#running-tests)
    - [Unit tests](#unit-tests)
    - [UI tests](#ui-tests)
  - [Logs](#logs)
  - [Version control](#version-control)
  - [Database (data) migration](#database-data-migration)
  - [Versions](#versions)
  - [Todo](#todo)

In the text below we expect the current working directory to be `<some path>/UssAi`.

## Components overview

- web (django, gunicorn)
- workers (dramatiq)

- message queue (redis)

## Beware of proxy (USS network and VPN only)

Communication between USS network and outside world goes through proxy server `proxy.intranet.usske.sk:4128`.
Consequently, multiple commands such as `conda install`, `pip install`or `docker build` do not work as expected.
You must provide some sort of corresponding "proxy parameter" in order to fix it. For example

```shell
pip install --proxy=https://{username}:{password}@proxy.intranet.usske.sk:4128 {package_name}
```

Or, you can set `HTTP_PROXY` and `HTTPS_PROXY` environment variables to handle both `conda` and `pip` cases at once.
For example, you can create `.uss_proxy.ps1` script (do not add to `git`, so you don't accidentally share your secrets)
with the following content:

```shell
$username = "<your AD username>"
$password = "<your AD password>"

$command = $args[0]

if ($command -eq "on") {
    $env:http_proxy = "http://${username}:${password}@proxy.intranet.usske.sk:4128"
    $env:https_proxy = "http://${username}:${password}@proxy.intranet.usske.sk:4128"
    $env:HTTP_PROXY = "http://${username}:${password}@proxy.intranet.usske.sk:4128"
    $env:HTTPS_PROXY = "http://${username}:${password}@proxy.intranet.usske.sk:4128"
}
else {
    $env:http_proxy = ""
    $env:https_proxy = ""
    $env:HTTP_PROXY = ""
    $env:HTTPS_PROXY = ""
}
```

Afterwards, you just run `.uss_proxy.ps1 on` in powershell and "proxy" environment variables
will be created (for this terminal session only). You can "turn off" these variables with `.uss_proxy.ps1 off`.

### Docker

So far the only solution known to me that works for VPN, is to set proxy URLs
in Docker UI (Settings > Resources > Proxies > Manual proxy configuration) together with AD username and password
as in `HTTP_PROXY` and `HTTPS_PROXY` environment variables above.

## How to setup dev environment

To set up virtual environment and install all Python dependencies run the following 4 commands.

```
conda env create -f environment_without_local.yml
conda activate viu
pip install -e viu_core
pip install -e attr_runtime_validation
pip install -e scrap_core
pip install -e scalesingest
```

## How to update environment from yml

```
conda env update -f environment_yml_file.yml
pip install -e scrap_core
pip install -e attr_runtime_validation
pip install -e viu_core
pip install -e scalesingest
pip install -e scalecore
```

## How to build docker image

```
docker build -t viu:latest -f ./docker/viu-base/dockerfile .
```

or

```
docker-compose -f ./docker-compose/docker-compose.base.yml -f ./docker-compose/docker-compose.prod.yml build
```

### In USS

In USS https proxy needs to be setup.

```
docker build -t viu:latest --build-arg HTTPS_PROXY=http://[USERNAME]:[PASSWORD]@proxy.intranet.usske.sk:4128 -f ./docker/dockerfile .
```

or

```
docker-compose {paths to docker-compose yml files} build --build-arg HTTPS_PROXY=http://[USERNAME]:[PASSWORD]@proxy.intranet.usske.sk:4128
```

**Remark**: If adding of `HTTPS_PROXY` build argument does not help, see the section **Beware of proxy** above.

## How to install Python package directly from GitHub

For example, if you would like to install the package `pytorch-balanced-sampler` from GitHub
with url https://github.com/khornlund/pytorch-balanced-sampler.git make sure you have `git` installed
and use the following command:

```commandline
pip install git+https://github.com/khornlund/pytorch-balanced-sampler.git#egg=pytorch-balanced-sampler
```

More information (e.g. how to select specific branch, version, etc.) can be found [here](https://pip.pypa.io/en/stable/cli/pip_install/).

## How to run

### DB Connections

File `config.env` contains environment variables (except for secrets) with DB connections configuration.
To set these environment variables locally (for the current session),
it is enough to run `setupenv.ps1` powershell script.

#### DB account is locked

If the DB account is locked, its necessary to wait 5 minutes (it is automatically unlocked after this time).
Please **make sure, you enter correct data**, while running `setupenv.ps1` powershell script.

#### Oracle Instant Client

1. Download client from [oracle website](https://www.oracle.com/database/technologies/instant-client/winx64-64-downloads.html)
2. Unzip
3. Add unzipped folder to PATH

To use the database locally, you need:
1. running container with (empty) oracle database - [tutorial here](wiki/setup_oracle_db_in_docker.md)
2. database backup from the test/prod environment (e.g.: xml/xml.gz/json format)

Then, you have to run these commands (note - make sure to use correct settings):

```python
# Apply new (structural) migrations, if any.
python manage.py migrate 

# empty your local DB
python manage.py flush 

# Load data from backup to your local database.
python manage.py loaddata
```


To create a new SQLite db that is used by Django internally, run

```shell
cd frontend
python manage.py migrate
```

Afterwards, you have to create the first super user. To do so, run

```shell
cd frontend
python manage.py createsuperuser
```

Usually, it is enough to run the above 2 commands just once.

To run Django server (without production static files, e.g. CSS files) just run

```shell
cd frontend
python manage.py runserver
```

In case you want to include all static files, you need to run the following command first

```shell
cd frontend
python manage.py collectstatic
```

See
[stackoverflow](https://stackoverflow.com/questions/34586114/whats-the-point-of-djangos-collectstatic)
for more info.

#### Gunicorn (Unix only)

In production instead of default `django` WSGI HTTP server the `gunicorn` server is used. Except that development
server is not suitable for production, `gunicorn` server is faster, more reliable and more secure.

```shell
cd frontend
gunicorn -w 4 -b :8050 vsadzka.wsgi:application
```

### Message Queue (redis)

It is very difficult to run `redis` directly on Windows. Common workarounds
are either [linux subsystem](https://docs.microsoft.com/en-us/windows/wsl/install-win10) or docker.

```shell
docker run -d -p 6379:6379 ussai_redis
```

Optionally, you can use

```shell
docker-compose -f ./docker-compose/docker-compose.base.yml -f ./docker-compose/docker-compose.prod.yml run -d redis
```

however, you have to have `docker` volume `viu-db-data` already created (see **Docker** section below).

### Workers (dramatiq)

Make sure that `redis` is running.

The command `python manage.py rundramatiq` looks for `dramatiq` executable in the directory
where `python` executable is located. To make sure it finds it, we add a new symbolic link (Windows only).

At first find where `dramatiq.exe` and `python.exe` executables are located (multiple results are possible):

Shell:

```shell
where dramatiq
where python
```

Powershell:

```shell
Get-Command dramatiq
Get-Command python
```

(In powershell) add a symbolic link to the directory where `python.exe` is located that points to `dramatiq.exe` file.
It should be your `conda` virtual environment (usually called `viu_win`).

```shell
New-Item -ItemType SymbolicLink -Path "{path to 'python.exe' directory}/dramatiq.exe" -Target "{path to 'dramatiq.exe' file}"
```

Afterwards, you can run `dramatiq` as follows:

```shell
cd frontend
python manage.py rundramatiq
```

Or you can just run `dramatiq` manually.

```shell
$env:DJANGO_SETTINGS_MODULE="vsadzka.settings"
cd frontend
dramatiq --path . --processes 8 --threads 8 django_dramatiq.setup django_dramatiq.tasks data.tasks scrap.tasks
```

#### CPU intensive tasks

If you want to run multiple CPU intensive tasks with `dramatiq`, you have to run `dramatiq` with different settings.
At first you have to create environment variable

```shell
$env:dramatiq_queue_prefetch=1
```

It tells `dramatiq` workers how many messages from queue to prefetch (to improve I/O). With setting
this variable to `1` each worker picks only message it is going to process right now, and consequently
all messages are split among as many workers as available. Afterwards, just run `dramatiq` with `1` thread per process, i.e.

```shell
cd frontend
python manage.py rundramatiq --processes 8 --threads 1
```

#### `dramatiq` remarks

- command `python manage.py rundramatiq` looks for `dramatiq` tasks in modules called `tasks` only, hence **no other file name to store tasks is supported**.

### Periodic tasks (periodiq)

To schedule periodic tasks we use `dramatiq` "addon" called [`periodiq`](https://gitlab.com/bersace/periodiq).

#### `periodiq` remarks

- `periodiq` does not run under Windows
- if you want to add a new periodic task do the following:
  - add standard `dramatiq` task with `periodic` parameter to any existing `tasks` module (or create a new `tasks.py` file - the file name is important, see [`dramatiq` remarks](#dramatiq-remarks) above)
  - add altered `tasks` module to `periodiq` entrypoint command in `docker-compose/docker-compose.base.yml` file, if not already listed there
- `periodiq_setup` script listed first in the `periodiq` entrypoint command is necessary to initialize "connection" settings (e.g. to `redis` message queue)

#### Possible improvements

A standalone `django` application such as [`django_periodiq`](https://github.com/Sovetnikov/django_periodiq) may simplify task lookup. However, limitations forced by `rundramatiq` command (i.e. `tasks.py` file names) still need to be taken into account.

### Docker

Create `docker` volume with db data:

```shell
docker volume create --name viu-db-data --opt type=none --opt device={PATH TO FOLDER WITH DB DATA} --opt o=bind
```

**Remark**: You should pass the path to folder with Django SQLite db (see the **Web** section above) to `device` argument of `docker volume create` command.

Run all services:

```shell
docker-compose -f ./docker-compose/docker-compose.base.yml -f ./docker-compose/docker-compose.prod.yml up [-d]
```

### Remarks

Sections **Web**, **Workers** and **Redis** above correspond to docker services / containers
with the same names (see `yml` files in `docker-compose` directory).

## Django dash caveats

Combining `django` with `dash` is not very straightforward. Currently, dash is imported to the page as an iframe
(hopefully direct html include will work soon - `django-plotly-dash` library has this option, however
it is not working properly with initial data).

### Django dash static files hack

Other big issue are static files. django-plotly-dash library comes with its own way of gathering static files. While this is working ok in develop settings and even with collectstatic command it is not working in tests. To overcome this issue we need to do following hack.

For each django app that uses dash do:

1. Delete dash folder from static folder in the app
1. Run collectstatic command
1. Copy STATIC_ROOT/dash folder to static folder in the app
1. Commit

This needs to be done everytime dash components version will be updated.

## Creating tests

### Exporting data for selenium tests

`python ./manage.py dumpdata [APP NAME] > [OUTPUT_FILE_NAME]`

for example:

`python ./manage.py dumpdata data > test_data.json`

python ./manage.py dumpdata generate json with UTF-16 LE encoding.
After using exported database in django test is neccessery convert test_data.json to UTF-8 encoding.

1. Open test_data.json in VS code
2. Click on UTF-16 in left bottom corner of VS code
3. From open dropdown choose "Save with encoding"
4. Choose "UTF-8" file encoding

## Running tests

There are 2 types of tests:

- unit tests (backend)

- Selenium tests (UI / frontend)

### Unit tests

Unit tests can be found in the directory `./tests`. To run them all use the following commands:

```shell
python -m unittest discover -s tests -t .
```

If you would like to run just a few tests, various switches/flags can be utilized.
See [realpython](https://realpython.com/python-testing/#executing-your-first-test) for more info.
If you would like to run specific test:

```
python -m unittest tests.path_to_script_with_test.TestClass.specific_test
#example python -m unittest tests.scrap_core.test_scrap_optimization.TestAddableIndexes.test_two_addable_indexes
```

### UI tests

Selenium (and other frontend) tests are located in `./frontend/tests` directory. There are 2 requirements that need to
be provided first:

- Chrome browser
- chromedriver
  - [download](https://sites.google.com/a/chromium.org/chromedriver/home) and extract `chromedriver.exe`, e.g. into `~/.webdriver` directory
  - add chromedriver directory to the `PATH` environment variable (user)

To execute these tests run the following commands:

```shell
cd frontend
python manage.py test --settings=tests.settings_chrome
```

**Remark**: There is some policy that blocks installation of Chrome browser on USS notebooks. Hence there is another `settings_firefox` file
you can use together with Firefox browser and geckodriver (https://github.com/mozilla/geckodriver/releases). However,
at the moment it is not expected that all Selenium tests pass when run in Firefox. Internet Explorer is still not supported.

## Logs

To view production or test logs connect to the desired server first (use standard password for _SK\vbofoc_ account).

```shell
# test
ssh vbofoc@vsafe.aa.sk.uss.com

# production
ssh vbofoc@worker1.aa.sk.uss.com
```

Afterwards you can view logs for particular container with

```shell
docker logs -f {container_name}
```

## Version control

- repository URL (VPN only):
  - http://vdevops.sk.uss.com/Esten/UssAi
- common branch names:
  - `feature/{name}`
  - `bugfix/{name}`

## Database (data) migration

Let's suppose we want to migrate data from `dbA` to `dbB`.

```shell
# !!! Make sure to use correct settings, where dbA database is selected.

# Generate new (structural) migrations, if needed.
python manage.py makemigrations --settings vsadzka.settings_dbA

# Dump data from database dbA to json file.
python manage.py dumpdata --natural-foreign --natural-primary > dbA_dump.json
```

Next either update `vsadzka/settings.py` module to use `dbB` database, or just use dedicated settings.

```shell
# !!! Make sure to use correct settings, where dbB database is selected.

# Apply new (structural) migrations, if any.
python manage.py migrate --settings vsadzka.settings_dbB

# !!! In case you want to delete all data in the database dbB, use the following command.
# !!! It will truncate all tables except for AUTH_PERMISSION and DJANGO_CONTENT_TYPE.
python manage.py flush --settings vsadzka.settings_dbB

# Load data from dbA json file to dbB database.
python manage.py loaddata dbA_dump.json --settings vsadzka.settings_dbB
```

**Remark**: If for whatever reason you need to delete records in AUTH_PERMISSION and DJANGO_CONTENT_TYPE tables too,
start the `django` shell with `python manage.py shell` and run the following command(s):

```python
from django.contrib.contenttypes.models import ContentType

ContentType.objects.all().delete()
```

## Versions

| Version | Date       | Change Description                                                                  |
|---------|------------|-------------------------------------------------------------------------------------|
| n/a     | 2021-05-14 | Change production `django` database to Oracle AZVP                                  |
| n/a     | 2021-05-10 | Add option to select `django` db - either Oracle or SQLite                          |
| n/a     | 2021-05-03 | Add `periodiq` service to run periodic tasks                                        |
| n/a     | 2021-01-18 | Update `README.md` file                                                             |
| n/a     | 2021-02-04 | Separate Django settings for testing from production `vsadzka/settings.py` file     |
| n/a     | 2021-09-18 | Updated binning for EOB Cr model reflecting -0.005 rule for reblow - `eob_model_v3` |
| n/a     | 2021-09-29 | Altered binning for EOB Sn model - `eob_model_v4`                                   |
| n/a     | 2023-04-21 | Update `scipy` version due to "highs" method error in optimization 62002            |

## Todo

- code
  - make sure that all tests are runnable (locally) and passing :)
- this file (`README.md`)

  - improve the section **Version control**
  - improve the section **Django dash static files hack**
    - brief rationale
    - where are `STATIC_ROOT` directories (see `frontend/vsadzka/settings.py` file) located
  - elaborate the section **Exporting data for selenium tests**

    - add motivation and simple explanation

  - add/discuss how to add versions to the repository, e.g. `__version__.py` file

[oracle instant client]: #
