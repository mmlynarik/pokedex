#!/bin/bash

echo "Checking js code formatting with prettier (https://prettier.io/)"

cd ./scrap_dash_components

npx prettier --check . || exit $?

cd ..
