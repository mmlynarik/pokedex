#!/bin/bash
echo "Checking code formatting"
black -l 110 --exclude '(migrations/*|experimental/*|pytorch_balanced_sampler/*)' --check . || exit $?

echo "Linting frontend"

#pylint --rcfile .pylintrc frontend || exit $?

echo "Linting tests"

#pylint --rcfile .pylintrc tests || exit $?

echo "Linting VIU core"

cd viu_core

#pylint --rcfile ../.pylintrc setup.py || exit $?
#pylint --rcfile ../.pylintrc viu_core || exit $?

cd ..

echo "Linting Scrap core"

cd scrap_core

#pylint --rcfile ../.pylintrc setup.py || exit $?
#pylint --rcfile ../.pylintrc scrap_core || exit $?

cd ..

echo "mypy version"
mypy --version


echo "Typechecking VIU core"

mypy --config-file=./mypy.ini viu_core || exit $?

echo "Typechecking Scrap core"

mypy --config-file=./mypy.ini scrap_core || exit $?

echo "Typechecking Coke core"

mypy --config-file=./mypy.ini cokecore || exit $?

echo "Typechecking Scales ingest"

mypy --config-file=./mypy.ini scalesingest || exit $?

echo "Typechecking Attr runtime validation"

mypy --config-file=./mypy.ini attr_runtime_validation || exit $?

