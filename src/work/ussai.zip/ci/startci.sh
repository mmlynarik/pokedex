#!/bin/bash
source activate viu && source $1