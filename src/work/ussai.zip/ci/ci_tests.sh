#!/bin/bash
mkdir coverage-data

echo "Running backend unittests"
coverage run -m unittest discover -s tests -t . || exit $?

mv .coverage ./coverage-data/.coverage.unittest

echo "Running frontend tests"

cd frontend
coverage run --source '.' ./manage.py test --settings=tests.settings_chrome || exit $?
mv .coverage ../coverage-data/.coverage.frontend
cd ..

coverage combine ./coverage-data

echo "Generating coverage report XML"
coverage xml -o ./coverage-reports/coverage-report.xml

sonar-scanner