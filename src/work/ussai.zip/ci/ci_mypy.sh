#!/bin/bash
echo "mypy version"
mypy --version

echo "Typechecking tests"

mypy --config-file=./mypy.ini tests # || exit $?

echo "Typechecking frontend"

cd frontend
mypy --config-file=./mypy.ini --explicit-package-bases . # || exit $?
cd ..
