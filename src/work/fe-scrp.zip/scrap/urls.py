from django.urls import include, path

from . import views
from .api_rest import view_sets, views_get, views_post


urlpatterns = [
    path("api/available_grades/", views_get.available_grades),
    path("api/available_orders/", views_get.available_orders),
    path("api/optimizations/", views_post.optimize_scrap_charge),
    path("api/validate_bounds/", views_post.validate_user_defined_bounds),
    path("api/close_charge/", views_post.close_scrap_charge),
    path("api/optimizations/<int:pk>/", views.read_scrap_charge_optimization),
    path("calculate", views.calculate, name="calculate"),
    path("calculate/<int:loading_station_id>", views.calculate, name="calculate"),
    path("yieldmodel", views.YieldModelIndex.as_view(), name="yieldmodel"),
    path(
        "yieldmodel/status/<int:yield_calculation_id>",
        views.yield_calculation_status,
        name="yieldmodelstatus",
    ),
    path("results/detail/<int:result_id>", views.result_detail, name="result_detail"),
    path("results/export/<int:result_id>", views.result_export, name="result_export"),
    path(
        "calculate/<int:loading_station_id>/<str:entity_type>/<int:year>/<int:entity_id>",
        views.show_heat,
        name="calculateoko",
    ),
    path("scrap_loading", views.choose_loading_station, name="choose_scrap_loading"),
    path("delete_old_tasks/<int:max_task_age>", views.delete_old_tasks, name="delete_old_tasks"),
    # supported query parameters are ?dt_from=YYYY-MM-DD [ &dt_to=YYYY-MM-DD &force_refresh=true|false ]
    path("evaluate_scrap_charge/", views.scrap_charges_evaluation, name="evaluate_scrap_charge"),
    path("scrap_loading/station/<int:input_id>/v2", views.scrap_loading_station_2, name="loading_station_v2"),
    path(
        "scrap_loading/station/<int:loading_station_id>", views.scrap_loading_station, name="loading_station"
    ),
    path("purchase", views.choose_scrap_purchase_record, name="choose_scrap_purchase_record"),
    path(
        "purchase/<int:scrap_purchase_record_id>/",
        views.scrap_purchase_record,
        name="scrap_purchase_record_detail",
    ),
    path("create_scrap_purchase", views.create_scrap_purchase, name="create_scrap_purchase"),
    path(
        "update_scrap_purchase/<int:scrap_purchase_record_id>",
        views.update_scrap_purchase,
        name="update_scrap_purchase",
    ),
    path(
        "purchase_app/<int:scrap_purchase_record_id>/",
        views.scrap_purchase_record_app,
        name="scrap_purchase_record_detail_app",
    ),
    path(
        "purchase/<int:scrap_purchase_record_id>/realized_offers/export",
        views.export_realized_offers_to_excel,
        name="export_realized_offers_to_excel",
    ),
    # supported query parameters are ?page_id=<int>
    path(
        "scrap_loading/station/<int:loading_station_id>/analysis/export",
        views.export_loading_station_analysis,
        name="export_loading_station_analysis",
    ),
    path(
        "scrap_loading/station/<int:loading_station_id>/analysis/export",
        views.export_loading_station_analysis,
        name="export_loading_station_analysis",
    ),
    path(
        "scrap_loading/station/settings",
        views.scrap_loading_station_settings,
        name="loading_station_settings",
    ),
    path(
        "scrap_loading/station/<int:loading_station_id>/basket_compatibility",
        views.loaded_basket_compatibility,
        name="loaded_basket_compatibility",
    ),
    path(
        "refresh_auto_grade_groups",
        views.refresh_automatic_grade_groups_view,
        name="refresh_auto_grade_groups_view",
    ),
    path(
        "scale_monitor/steelshop/<int:steelshop>/scale_id/<str:scale_id>",
        views.scale_monitor,
        name="scale_monitor",
    ),
    # Wire up our API using automatic URL routing.
    # Additionally, we include login URLs for the browsable API.
    path("models/", include(view_sets.router.urls)),
    path("models/api-auth/", include("rest_framework.urls", namespace="rest_framework")),
]
