from datetime import date

from django import forms

from .models import (
    LoadingStation,
    RelaxableLowerSummingLimitSetting,
    RelaxableRiskLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScrapExclusiveGroupSetting,
    ScrapPurchaseRecord,
    ScrapSupplierMapping,
    WeightedScrap,
)

ENTITY_CHOICES = [("heat_id", "Tavba"), ("evaluation_id", "Report ID")]


class GoToHeatFromOkoForm(forms.Form):
    entity_id = forms.IntegerField(required=True, widget=forms.NumberInput(attrs={"class": "form-control"}))
    # Every year we need a restart - not great not terrible
    year = forms.IntegerField(
        min_value=1980,
        max_value=date.today().year,
        required=True,
        initial=date.today().year,
        label="Rok tavby",
        widget=forms.NumberInput(attrs={"class": "form-control"}),
    )
    entity_type = forms.CharField(widget=forms.Select(choices=ENTITY_CHOICES))


class DatePicker(forms.DateInput):
    input_type = "date"


class SavedYieldModels(forms.Form):
    window_size = forms.IntegerField(
        required=True, widget=forms.NumberInput(attrs={"class": "form-control", "min": 1})
    )
    data_from = forms.DateField(required=True, widget=DatePicker, label="Data from")
    data_to = forms.DateField(required=True, widget=DatePicker, label="Data to")


class LoadingStationForm(forms.ModelForm):
    class Meta:
        model = LoadingStation
        fields = [
            "name",
            "debug",
            "level_2",
            "scrap_yard_api",
            "scale_control",
            "printer",
            "steelshop",
            "base_model_settings",
            "user_in_control",
            "authorized_users",
            "relaxable_risk_limit_settings",
            "relaxable_upper_summing_limit_settings",
            "relaxable_lower_summing_limit_settings",
            "scrap_exclusive_group_settings",
            "scrap_facilities",
        ]


class ScrapSupplierMappingAdminForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(ScrapSupplierMappingAdminForm, self).__init__(*args, **kwargs)
        self.fields["input_scrap_supplier"].strip = False

    class Meta:
        model = ScrapSupplierMapping
        fields = "__all__"


class ExcelUploadForm(forms.Form):
    excel_file = forms.FileField()


class ScrapPurchaseRecordForm(forms.ModelForm):
    class Meta:
        model = ScrapPurchaseRecord
        fields = ["name", "user_in_control", "debug", "finished", "optimization_settings", "authorized_users"]


class ScrapExclusiveGroupSettingForm(forms.ModelForm):
    class Meta:
        model = ScrapExclusiveGroupSetting
        fields = ("name", "scrap_types", "comment")


class RelaxableRiskLimitSettingForm(forms.ModelForm):
    class Meta:
        model = RelaxableRiskLimitSetting
        fields = (
            "name",
            "grade_ids",
            "Cr_aim",
            "Cr_allowed",
            "Cu_aim",
            "Cu_allowed",
            "Mo_aim",
            "Mo_allowed",
            "Ni_aim",
            "Ni_allowed",
            "S_aim",
            "S_allowed",
            "Si_aim",
            "Si_allowed",
            "Sn_aim",
            "Sn_allowed",
            "comment",
        )


class RelaxableUpperSummingLimitSettingForm(forms.ModelForm):
    class Meta:
        model = RelaxableUpperSummingLimitSetting
        fields = (
            "name",
            "grade_ids",
            "scrap_types",
            "comment",
            "weight_aim",
            "weight_allowed",
            "ratio_aim",
            "ratio_allowed",
        )


class RelaxableLowerSummingLimitSettingForm(forms.ModelForm):
    class Meta:
        model = RelaxableLowerSummingLimitSetting
        fields = (
            "name",
            "grade_ids",
            "scrap_types",
            "comment",
            "weight_aim",
            "weight_allowed",
            "ratio_aim",
            "ratio_allowed",
        )


class WeightedScrapForm(forms.ModelForm):
    class Meta:
        model = WeightedScrap
        fields = (
            "start",
            "end",
            "scale_id",
            "scrap",
            "weight",
            "invalid_record",
            "baskets",
        )
