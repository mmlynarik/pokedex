import datetime
import logging
import math
import zoneinfo

import attr

from scrap.api_rest.serializers import ClosingClientData
from scrap.dash.components.available_scraps.model.available_scraps.api import send_loaded_scrap_mixes_to_api
from scrap.dash.components.telegram_utils import compose_telegram
from scrap.models import Basket, LOADED_CHARGE_OPERATOR_DECISION, ScrapCharge, ScrapMixDefinition
from scrap_core import ScrapBounds
from scrap_core.optimization.datamodel import AvailableScraps, ScrapMixLimits, ScrapMixLimit
from scrap_core.telegrams.client import send_data
from vsadzka.settings import SCALE_PRECISION, LEVEL_2_URL

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class ScrapYardAPIError(Exception):
    pass


def bounds_to_limits(
    low_bounds: ScrapBounds,
    upp_bounds: ScrapBounds,
    available_scraps: AvailableScraps,
    total_scrap_weight: int,
) -> ScrapMixLimits:
    # we need to add default values because validation functions does not assume implicit sane defaults
    return tuple(
        ScrapMixLimit(
            item.scrap_type,
            low_bounds.get(item.scrap_type, 0),
            upp_bounds.get(item.scrap_type, total_scrap_weight),
        )
        for item in available_scraps
    )


def update_weighted_scrap_steelshop_1(charge: ScrapCharge, scale_to_basket_map: dict) -> None:
    """each scale has (or should have) associated basket"""
    if not scale_to_basket_map:
        raise ValueError(f"Scrap charge {charge.pk} - empty scale to basket map at steelshop 1 not allowed")

    if not set(scale_to_basket_map.values()).issuperset(
        baskets := [b.basket_id for b in charge.baskets.all()]
    ):
        raise ValueError(
            f"Scrap charge {charge.pk} - invalid scale to basket map {scale_to_basket_map}, "
            f"unassigned baskets found {baskets}"
        )

    for scale_id, basket_id in scale_to_basket_map.items():

        if basket_id is None:
            raise ValueError(f"Basket id for scale {scale_id} not set")

        for weighted_scrap in charge.weightedscrap_set.filter(scale_id=scale_id):
            weighted_scrap.baskets.set(Basket.objects.filter(basket_id=basket_id))
            weighted_scrap.save()


def update_weighted_scrap_steelshop_2(charge: ScrapCharge) -> None:
    """both baskets are weighted at once, hence tuple of baskets is associated with given weighted scrap"""
    for weighted_scrap in charge.weightedscrap_set.all():
        weighted_scrap.baskets.set(Basket.objects.filter(basket_id__in=charge.basket_ids))
        weighted_scrap.save()


def update_charge_initial_db_data(
    charge: ScrapCharge, grade_id: int, total_scrap_weight: int, pig_iron_weight: int
) -> None:
    charge.grade_id = grade_id
    charge.total_scrap_weight = total_scrap_weight
    charge.pig_iron_weight = pig_iron_weight
    charge.optimization_start_clicked = True
    charge.save()


def update_charge_final_db_data(charge: ScrapCharge, client_data: ClosingClientData) -> None:
    charge.is_wet = client_data.is_wet
    charge.is_reserve = client_data.is_reserve
    charge.operator = charge.loading_station.user_in_control.operator
    charge.operator_comment = client_data.operator_comment
    charge.operator_decision = LOADED_CHARGE_OPERATOR_DECISION
    charge.closed_at = datetime.datetime.now(tz=zoneinfo.ZoneInfo("UTC"))

    charge.save()


def send_telegram(charge: ScrapCharge) -> None:
    station = charge.loading_station
    operator_id = station.user_in_control.operator.operator_id
    precision = math.gcd(station.model_settings.optimizer_settings.precision_step, SCALE_PRECISION)

    telegram = compose_telegram(charge, operator_id, ScrapMixDefinition.get_scrap_mix_mapping(), precision)

    log.info(f"Telegram raw - {attr.asdict(telegram)}")
    log.info(f"Telegram encoded - {telegram.to_bytes()}")

    log_msg = f"Scrap Charge {charge.pk} - " + f"telegram {telegram.tel_no}/{telegram.header.blend_id}"
    if station.level_2:
        send_data(telegram.to_bytes(), LEVEL_2_URL[station.steelshop], timeout=5)
        log.info(log_msg + " sent successfully")
    else:
        log.warning(log_msg + " not sent. Level 2 telegrams are disabled for this loading station")


def update_scrap_yard_data(charge: ScrapCharge) -> None:
    station = charge.loading_station

    if station.scrap_yard_api:

        username = station.user_in_control.username

        if not send_loaded_scrap_mixes_to_api(charge, username):
            raise ScrapYardAPIError("Communication with scrap yard API encountered an error")

        log.info(f"Scrap charge {charge.pk} - scrap yard data updated")
    else:
        log.warning(f"Scrap yard API disabled for loading station {station}")
