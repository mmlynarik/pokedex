import datetime
import logging
import zoneinfo

from rest_framework.decorators import api_view
from rest_framework.status import HTTP_200_OK
from rest_framework.response import Response
from usskssgrades.grade import NORMAL_HEAT_WEIGHT_DEFAULT
from usskssgrades.grade_chem_limits import HEAT_WEIGHT_CORRECTION

from scrap.dash.database_api import steel_grades, db_iars
from scrap.models import (
    converter,
    LoadingStation,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# at steelshop we usually need to know about 10 future heats, thus 32 is a reasonable safe default
DEFAULT_SHORT_TERM_HORIZON = 32


# temporary solution to improve `available_grades` endpoint response time
# move it to usskssgrades package
def calc_normal_heat_weight(grade_id: int) -> int:
    return NORMAL_HEAT_WEIGHT_DEFAULT - HEAT_WEIGHT_CORRECTION.get(grade_id, 0)


@api_view(["GET"])
def available_grades(*args, **kwargs) -> Response:
    today = datetime.date.today()

    grade_ids = steel_grades.get_available_grade_ids(today)

    content = [
        {
            "grade_id": grade_id,
            "display_name": steel_grades.get_display_name(grade_id, today),
            "normal_heat_weight": calc_normal_heat_weight(grade_id),
        }
        for grade_id in grade_ids
    ]

    return Response(content, status=HTTP_200_OK)


@api_view(["GET"])
def available_orders(request, *args, **kwargs) -> Response:
    """api/available_orders/?steelshop={int}[&horizon={int}]"""
    steelshop = int(request.query_params.get("steelshop"))
    horizon = int(request.query_params.get("horizon", DEFAULT_SHORT_TERM_HORIZON))

    orders = db_iars.get_next_planned_heats(steelshop=steelshop, num_of_heats=horizon) or []

    content = [
        {
            "zpo_timestamp": datetime.datetime.fromtimestamp(item.zpo_timestamp, zoneinfo.ZoneInfo("UTC")),
            "grade_id": item.grade_id,
            "weight": item.weight,
            "order_num": item.order_num,
        }
        for item in orders
    ]

    return Response(content, status=HTTP_200_OK)
