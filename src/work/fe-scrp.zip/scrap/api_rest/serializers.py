""" Serializers define the API representation."""

import json

import attr
from rest_framework import serializers
from scrap.models import (
    AvailableScrap,
    Basket,
    MultipleHeatsOptimizationOutputField,
    MultipleHeatsOptimizationResult,
    ScrapCharge,
    WeightedScrap,
    converter,
)
from scrap.serializers import positive_finite
from scrap_core.blendmodel import ScrapBlendModelOutput
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologiesModelOutput


class BaseAttrSerializer(serializers.BaseSerializer):

    def to_representation(self, instance):
        return converter.unstructure(instance)


class CorrTechModelOutputSerializer(BaseAttrSerializer):

    def to_internal_value(self, data):
        return converter.structure(json.loads(data), CorrectionTechnologiesModelOutput)


class BlendModelOutputSerializer(BaseAttrSerializer):

    def to_internal_value(self, data):
        return converter.structure(json.loads(data), ScrapBlendModelOutput)


class OptimizationResultSerializer(BaseAttrSerializer):

    def to_internal_value(self, data):
        return converter.structure(json.loads(data), MultipleHeatsOptimizationOutputField)


class ScrapLimitsSerializer(BaseAttrSerializer):

    def to_internal_value(self, data):
        return converter.structure(json.loads(data), ScrapCharge.scrap_limits)


class AvailableScrapSerializer(serializers.ModelSerializer):
    class Meta:
        model = AvailableScrap
        fields = "__all__"


class BasketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Basket
        fields = "__all__"


class MultipleHeatsOptimizationResultSerializer(serializers.ModelSerializer):
    corr_tech_model_output = CorrTechModelOutputSerializer()
    blend_model_output = BlendModelOutputSerializer()
    result = OptimizationResultSerializer()

    class Meta:
        model = MultipleHeatsOptimizationResult
        fields = "__all__"


class ScrapChargeSerializer(serializers.ModelSerializer):
    scrap_limits = ScrapLimitsSerializer()

    class Meta:
        model = ScrapCharge
        fields = [
            "id",
            "loading_station",
            "closed_at",
            "grade_id",
            "order_num",
            "baskets",
            "switched_baskets",
            "total_scrap_weight",
            "pig_iron_weight",
            "optimization_start_clicked",
            "optimization_results",
            "scrap_limits",
        ]


class WeightedScrapSerializer(serializers.ModelSerializer):
    class Meta:
        model = WeightedScrap
        fields = "__all__"


@attr.s(auto_attribs=True)
class ClientData:
    charge_id: int
    grade_id: int
    total_scrap_weight: int
    user_low_bounds: dict
    user_upp_bounds: dict


class ClientDataSerializer(serializers.Serializer):
    charge_id = serializers.IntegerField()
    grade_id = serializers.IntegerField()
    total_scrap_weight = serializers.IntegerField(validators=[positive_finite])
    user_low_bounds = serializers.DictField(child=serializers.IntegerField(), allow_empty=True, default={})
    user_upp_bounds = serializers.DictField(child=serializers.IntegerField(), allow_empty=True, default={})

    def create(self, validated_data):
        return ClientData(**validated_data)


@attr.s(auto_attribs=True)
class OptimizationClientData(ClientData):
    pig_iron_weight: int
    transfer_capacity: int


class OptimizationClientDataSerializer(ClientDataSerializer):
    pig_iron_weight = serializers.IntegerField(validators=[positive_finite])
    transfer_capacity = serializers.IntegerField(allow_null=True, default=0)

    def create(self, validated_data):
        return OptimizationClientData(**validated_data)


@attr.s(auto_attribs=True)
class ClosingClientData:
    charge_id: int
    is_wet: bool
    is_reserve: bool
    operator_comment: str
    scale_to_basket_map: dict


class ClosingClientDataSerializer(serializers.Serializer):
    charge_id = serializers.IntegerField()
    is_wet = serializers.BooleanField()
    is_reserve = serializers.BooleanField()
    operator_comment = serializers.CharField(default="")
    scale_to_basket_map = serializers.DictField(
        child=serializers.IntegerField(), allow_empty=True, default={}
    )

    def create(self, validated_data):
        return ClosingClientData(**validated_data)
