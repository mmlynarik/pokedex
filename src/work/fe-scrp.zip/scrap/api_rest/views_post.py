import logging

import attr
from django.db import transaction
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from scrap.api_rest.serializers import (
    OptimizationClientDataSerializer,
    ClientDataSerializer,
    ClosingClientDataSerializer,
)
from scrap.api_rest.utils import (
    bounds_to_limits,
    update_charge_initial_db_data,
    update_charge_final_db_data,
    update_weighted_scrap_steelshop_1,
    update_weighted_scrap_steelshop_2,
    send_telegram,
    update_scrap_yard_data,
    ScrapYardAPIError,
)
from scrap.dash.components.one_heat_optimizer_v2 import validate_charge_info, create_optimization_input
from scrap.dash.components.telegram_utils import InvalidSteelshopError
from scrap.models import (
    ScrapCharge,
    ScrapMixDefinition,
    MultipleHeatsOptimizationResult,
    GradeGroup,
    GradeDefinition,
)
from scrap.tasks import multiple_heats_scrap_optimization, print_and_save_weighting_ticket
from scrap_core.optimization.validations import validate_scrap_limits


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@api_view(["POST"])
def close_scrap_charge(request, *args, **kwargs) -> Response:
    # deserialize client data
    ser = ClosingClientDataSerializer(data=request.data)

    # validate client data
    ser.is_valid(raise_exception=True)

    client_data = ser.save()

    try:
        # lookup charge object
        charge = ScrapCharge.objects.get(pk=client_data.charge_id)
    except ScrapCharge.DoesNotExist as e:
        return Response({"error": str(e)}, status.HTTP_404_NOT_FOUND)

    with transaction.atomic():
        # add basket information to weighted scrap
        match charge.loading_station.steelshop:
            case 1:
                try:
                    update_weighted_scrap_steelshop_1(charge, client_data.scale_to_basket_map)
                except ValueError as e:
                    log.exception(f"Scrap Charge {charge.pk} - can't update weighted scrap")
                    return Response({"error": str(e)}, status.HTTP_400_BAD_REQUEST)
            case 2:
                update_weighted_scrap_steelshop_2(charge)
            case _:
                raise InvalidSteelshopError(
                    f"Loading Station {charge.loading_station} - unsupported "
                    f"or unknown steelshop: {charge.loading_station.steelshop}"
                )

        update_charge_final_db_data(charge, client_data)

    log.info(f"Scrap charge {charge.pk} - db data updated")

    errors = []

    try:
        send_telegram(charge)
    except (ConnectionError, TimeoutError, InvalidSteelshopError):
        telegram_error_msg = f"Scrap Charge {charge.pk} - telegram not sent"
        errors.append(telegram_error_msg)
        log.exception(telegram_error_msg)

    try:
        update_scrap_yard_data(charge)
    except ScrapYardAPIError:
        scrap_yard_error = f"Scrap Charge {charge.pk} - scrap yard data not updated"
        errors.append(scrap_yard_error)
        log.exception(scrap_yard_error)

    print_and_save_weighting_ticket.send(charge.pk)
    log.info(f"Scrap Charge {charge.pk} - weighting ticket saved and sent to printer")

    return Response({"charge_id": charge.pk, "errors": errors}, status.HTTP_200_OK)


@api_view(["POST"])
def optimize_scrap_charge(request, *args, **kwargs) -> Response:
    # deserialize client data
    ser = OptimizationClientDataSerializer(data=request.data)

    # validate client data
    ser.is_valid(raise_exception=True)

    client_data = ser.save()

    try:
        # lookup charge object
        charge = ScrapCharge.objects.get(pk=client_data.charge_id)
    except ScrapCharge.DoesNotExist as e:
        return Response({"error": str(e)}, status.HTTP_404_NOT_FOUND)

    update_charge_initial_db_data(
        charge, client_data.grade_id, client_data.total_scrap_weight, client_data.pig_iron_weight
    )

    unallocated_scrap = charge.get_unallocated_scrap()

    station = charge.loading_station

    model_settings = attr.evolve(
        station.model_settings,
        optimizer_settings=attr.evolve(
            station.model_settings.optimizer_settings,
            scrap_mix_mapping=ScrapMixDefinition.get_scrap_mix_mapping(),
        ),
    )

    user_defined_limits = bounds_to_limits(
        client_data.user_low_bounds,
        client_data.user_upp_bounds,
        unallocated_scrap,
        client_data.total_scrap_weight,
    )

    errors, warnings = validate_charge_info(
        charge,
        station.relaxable_lower_summing_limit_settings.all(),
        station.relaxable_upper_summing_limit_settings.all(),
        unallocated_scrap,
        model_settings,
        user_defined_limits=user_defined_limits,
    )

    if errors:
        return Response(errors, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    opt_input = create_optimization_input(
        charge,
        unallocated_scrap,
        model_settings,
        client_data.transfer_capacity,
        user_defined_limits=user_defined_limits,
    )

    opt_res = MultipleHeatsOptimizationResult(scrap_charge=charge, warnings=warnings)
    opt_res.save()

    opt_input.optimization_result = opt_res
    opt_input.save()

    # trigger optimization
    multiple_heats_scrap_optimization.send(opt_res.pk)

    # return optimization id
    return Response(
        {"result_id": opt_res.pk, "warnings": warnings},
        status.HTTP_201_CREATED,
    )


@api_view(["POST"])
def validate_user_defined_bounds(request, *args, **kwargs) -> Response:
    # deserialize client data
    ser = ClientDataSerializer(data=request.data)

    # validate client data
    ser.is_valid(raise_exception=True)

    client_data = ser.save()

    try:
        # lookup charge object
        charge = ScrapCharge.objects.get(pk=client_data.charge_id)
    except ScrapCharge.DoesNotExist as e:
        return Response({"error": str(e)}, status.HTTP_404_NOT_FOUND)

    unallocated_scrap = charge.get_unallocated_scrap()

    station = charge.loading_station

    user_defined_limits = bounds_to_limits(
        client_data.user_low_bounds,
        client_data.user_upp_bounds,
        unallocated_scrap,
        client_data.total_scrap_weight,
    )

    relevant_grade_groups = GradeGroup.objects.filter(
        grade_ids=GradeDefinition.objects.get(grade_id=client_data.grade_id)
    )

    lower_limit_settings = [
        lim.to_relaxable_limit()
        for lim in station.relaxable_lower_summing_limit_settings.filter(grade_ids__in=relevant_grade_groups)
    ]

    upper_limit_settings = [
        lim.to_relaxable_limit()
        for lim in station.relaxable_upper_summing_limit_settings.filter(grade_ids__in=relevant_grade_groups)
    ]

    errors, warnings = validate_scrap_limits(
        user_defined_limits,
        client_data.total_scrap_weight,
        unallocated_scrap,
        lower_limit_settings,
        upper_limit_settings,
        client_data.grade_id,
        ScrapMixDefinition.get_scrap_mix_mapping(),
    )

    return Response({"errors": errors, "warnings": warnings}, status.HTTP_200_OK)
