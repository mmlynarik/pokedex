views.py
- [x] GET grade-y
- [x] info o dostupnom srote - GET + len filter na nakladciu stanicu ?stationId=...
- [x] GET order num
- [x] GET/POST validacia (user defined limits vs. relaxable limits)
- [x] POST vypocitat vsadzku
- [x] POST uzavriet vsadzku

view_sets.py
- [x] GET na scrap charge model 
- [x] GET na optization result pre danu vsadzku ?chargeId=...
- [x] GET na weighted scrap pre danu vsadzku ?chargeId=...
- [x] GET koryta


| feature                 | implemented | tested | comment |
|-------------------------|-------------|--------|---------|
| GET charge              | Y           | Y      |         |
| GET opt res             | Y           | Y      |         |
| GET weighted scrap      | Y           | Y      |         |
| GET baskets             | Y           | Y      |         |
| GET available grades    | Y           | Y      |         |
| GET available scraps    | Y           | Y      |         |
| GET available order num | Y           | Y      |         |
| POST validate           | Y           | Y      |         |
| POST optimize charge    | Y           | Y      |         |
| POST close charge       | Y           | Y      |         |

TODO join/reorganize rest api urls, in particular api/ and models/
TODO add logging
TODO handle invalid query parameters, e.g. non-existent loading station