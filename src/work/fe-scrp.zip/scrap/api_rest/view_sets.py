"""ViewSets define the view behavior."""

from rest_framework import pagination, routers, viewsets
from scrap.api_rest.serializers import (
    AvailableScrapSerializer,
    BasketSerializer,
    MultipleHeatsOptimizationResultSerializer,
    ScrapChargeSerializer,
    WeightedScrapSerializer,
)
from scrap.models import AvailableScrap, Basket, MultipleHeatsOptimizationResult, ScrapCharge, WeightedScrap


class CustomPagination(pagination.PageNumberPagination):
    """Page size modifiable by user."""

    page_size_query_param = "pageSize"
    page_size = 100
    max_page_size = 1000


class NoPagination(pagination.PageNumberPagination):
    """Effectively no pagination, since upper bounds are very large."""

    page_size = 10**6
    max_page_size = 10**6


class BasketViewSet(viewsets.ReadOnlyModelViewSet):
    """scrap/models/baskets/"""

    pagination_class = NoPagination
    queryset = Basket.objects.all()
    serializer_class = BasketSerializer


class MultipleHeatsOptimizationResultViewSet(viewsets.ReadOnlyModelViewSet):
    """scrap/models/optimization_results/?chargeId={int}[&latestOnly={true|false}]"""

    serializer_class = MultipleHeatsOptimizationResultSerializer

    def get_queryset(self):
        charge_id = self.request.query_params.get("chargeId", "")
        latest_only = self.request.query_params.get("latestOnly", "false").lower() == "true"

        if not charge_id:
            return MultipleHeatsOptimizationResult.objects.none()

        queryset = MultipleHeatsOptimizationResult.objects.filter(scrap_charge_id=charge_id)

        return queryset.order_by("-created_at")[:1] if latest_only else queryset


class ScrapChargeViewSet(viewsets.ModelViewSet):
    queryset = ScrapCharge.objects.all()
    serializer_class = ScrapChargeSerializer


class WeightedScrapApiView(viewsets.ModelViewSet):
    """scrap/models/weighted_scraps/?chargeId={int}[&pageSize={int}]"""

    pagination_class = CustomPagination
    serializer_class = WeightedScrapSerializer

    def get_queryset(self):
        charge_id = self.request.query_params.get("chargeId", "")

        if not charge_id:
            return WeightedScrap.objects.none()

        return WeightedScrap.objects.filter(scrap_charge_id=charge_id)


class AvailableScrapApiView(viewsets.ModelViewSet):
    """scrap/models/available_scraps/?stationId={int}[&pageSize=<int>]"""

    pagination_class = CustomPagination
    serializer_class = AvailableScrapSerializer

    def get_queryset(self):
        station_id = self.request.query_params.get("stationId")

        if not station_id:
            return AvailableScrap.objects.none()

        return AvailableScrap.objects.filter(loading_station_id=station_id, weight__gt=0)


# Routers provide an easy way of automatically determining the URL conf.
router = routers.DefaultRouter()
router.register(r"baskets", BasketViewSet)
router.register(
    r"optimization_results",
    MultipleHeatsOptimizationResultViewSet,
    basename="MultipleHeatsOptimizationResult",
)
router.register(r"scrap_charges", ScrapChargeViewSet)
router.register(r"weighted_scraps", WeightedScrapApiView, "WeightedScrap")
router.register(r"available_scraps", AvailableScrapApiView, "AvailableScrap")
