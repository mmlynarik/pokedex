import io
import logging

from borb.pdf import Document
from pyx import bitmap, canvas

from scrap.models import FtpConnection
from scrap.weightingticket.ticket import to_images


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


A4_PAPER_SIZE = 21  # in cm
BYTES_FILE = "weighting_ticket"
FTP_PRINT_COMMAND = "STOR toprint.ps"


def send_print_job(ftp_printer_conn: FtpConnection, document: Document) -> None:
    for page_idx, page_as_image in enumerate(to_images(document), start=1):
        bitmap_bw = bitmap.bitmap(0, 0, page_as_image, width=A4_PAPER_SIZE, compressmode=None)

        c = canvas.canvas()
        c.insert(bitmap_bw)

        with io.BytesIO() as page_buffer, ftp_printer_conn.get_ftp_conn as ftp:
            c.writePSfile(page_buffer)
            page_buffer.seek(0)
            ftp.storbinary(FTP_PRINT_COMMAND, page_buffer)

        c.clear()

        log.info(f"Page {page_idx} sent to printer {ftp_printer_conn.host}")
