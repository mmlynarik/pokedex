import datetime
import logging
from typing import Callable, Iterable, List, Optional, Tuple, TypeVar

import cachetools
import numpy as np
import pandas as pd
from usskssgrades import Grade
from usskssgrades.steel_grades_common import ChemLimitsError

from attr_runtime_validation.on_access_validation import (
    OnAccessValidated,
    enabled_validation,
)
from cattr import unstructure
from immutables import Map
from pandera.typing import DataFrame
from returns.converters import maybe_to_result
from returns.curry import partial
from returns.interfaces.bindable import BindableN
from returns.io import IOFailure, IOResult, IOSuccess
from returns.maybe import Maybe
from returns.pipeline import is_successful
from returns.result import Failure, Result, Success
from scrap_core import (
    SUPPORTED_SCRAP_TYPES_AS_MIXES,
    TMS_ID_MAPPING,
    HeatKey,
    ScrapBounds,
    ScrapCharge as ScrapCoreScrapCharge,
    ScrapMix,
    ScrapType,
)
from scrap_core.datamodel.model import HeatDataFromScada
from scrap_core.evaluation.datamodel import calculate_effective_lower_bound, calculate_effective_upper_bound
from scrap_core.heat_matching import AppData, DbData, find_matching
from scrap_core.utils import omit_values_above, omit_zeros
from usskscadaocclient import HeatData
from usskscadaocclient.scrap_data import ScrapWeights

from scrap.dash.database_api import db_scada, steel_grades
from scrap.models import ClosedHeatEvaluationV2, ScrapCharge, MultipleHeatsOptimizationResult

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# TODO Better implementation would be through ApplicativeN as below but curry method is now too slow
# TODO Also curry method has potentially bug in it - id does not correctly work with IOResult
# TODO Better typing when PEP-0677 will be implemented
def lift(orig_func: Callable):
    def lifted(*args: BindableN):
        f = Success(orig_func)
        for arg in args:
            f = arg.bind(lambda val: f.map(lambda actual_f: partial(actual_f, val)))  # type: ignore
        return f.map(lambda actual_f: actual_f())

    return lifted


# def lift(orig_func: Callable[..., ReturnType]):
#     def lifted(*args: ApplicativeN) -> None:
#         partial_application = Success(curry(orig_func))
#         for arg in args:
#             partial_application = arg.apply(partial_application)

#     return lifted


ResultType = TypeVar("ResultType")
ValueType = TypeVar("ValueType", bound=OnAccessValidated)


def with_validated(
    heat: ValueType, func: Callable[[ValueType], Result[ResultType, str]]
) -> Result[ResultType, str]:
    try:
        with enabled_validation(heat) as validated:
            return func(validated)
    # TODO when on access validation will throw some better uniform exception catch just it
    except Exception as e:
        log.exception(f"{heat}, {func.__name__}")
        return Failure(e).alt(str)


def get_optimization_results(
    scrap_charge: ScrapCharge,
) -> IOResult[List[MultipleHeatsOptimizationResult], str]:
    results = list(scrap_charge.optimization_results.all().order_by("created_at"))

    if not results:
        return IOFailure(f"No optimization result for scrap charge {scrap_charge.pk} found")

    return IOSuccess(results)


def get_last_optimization_result(scrap_charge: ScrapCharge) -> IOResult[MultipleHeatsOptimizationResult, str]:
    result = scrap_charge.last_optimization_result

    if result is None:
        return IOFailure(f"No optimization result for scrap charge {scrap_charge.pk} found")

    return IOSuccess(result)


def get_s_max_scada(scada_data: HeatDataFromScada) -> Result[float, str]:
    maybe_s_max = Maybe.from_optional(scada_data.s_max)
    s_max_result = maybe_to_result(maybe_s_max).alt(lambda _: f"Missing S limit")
    return s_max_result.bind(
        lambda s_max: Success(s_max) if np.isfinite(s_max) else Failure("Invalid S limit")
    )


def get_s_eob_scada(scada_data: HeatDataFromScada) -> Result[float, str]:
    s = scada_data.s_eob
    if s is not None and np.isfinite(s):
        if s == 0.0:
            return Failure("S value was measured as 0")
        return Success(s)
    return Failure("S value was not measured")


def get_available_scrap(optimization_result: MultipleHeatsOptimizationResult) -> ScrapBounds:
    return Map(omit_zeros(optimization_result.optimization_input.upper_bounds))


def get_grade_from_id_safe(grade_id: int, when: datetime.date) -> Optional[Grade]:
    try:
        return steel_grades.get_grade_from_id(grade_id, when)
    except ChemLimitsError:
        log.exception(f"Invalid (or unavailable) data for grade {grade_id} at {when}")
        return None


def evaluate_recommendation_adherence(
    evaluation: ClosedHeatEvaluationV2, scada_data: HeatDataFromScada
) -> ClosedHeatEvaluationV2:
    real_charge = with_validated(scada_data, lambda heat: Success(heat.scrap_charge))
    real_charge.map(evaluation.add_real_charge_data).lash(evaluation.add_data_error)

    last_optimization_result = get_last_optimization_result(evaluation.scrap_charge)

    model_recommendation = last_optimization_result.bind_result(lambda res: res.model_output).bind_result(
        lambda res: res.first_heat_scrap_weights_result
    )
    model_recommendation.map(evaluation.add_model_recommendation_data).lash(evaluation.add_data_error)

    lift(evaluation.add_recommendation_adherence_data)(real_charge, model_recommendation)
    return evaluation


def extract_bounds_and_results_for_scrap_type(
    scrap_mix: ScrapMix, optims: List[Tuple[ScrapBounds, ScrapCoreScrapCharge]], default=0
) -> List[Tuple[int, int]]:
    return [
        (int(bounds.get(scrap_mix, default)), int(final_weights.get(scrap_mix, 0)))
        for bounds, final_weights in optims
    ]


def calculate_effective_lower_bounds(
    optimization_results: List[MultipleHeatsOptimizationResult],
) -> ScrapBounds:
    bounds_and_results = [res.first_heat_lower_bounds_and_model_result for res in optimization_results]
    successful_optimizations = [res.unwrap() for res in bounds_and_results if is_successful(res)]
    effective_lower_bounds = {
        scrap_mix: calculate_effective_lower_bound(
            extract_bounds_and_results_for_scrap_type(scrap_mix, successful_optimizations)
        )
        for scrap_mix in SUPPORTED_SCRAP_TYPES_AS_MIXES
    }
    return Map(omit_zeros(effective_lower_bounds))


def calculate_effective_upper_bounds(
    optimization_results: List[MultipleHeatsOptimizationResult],
) -> ScrapBounds:
    bounds_and_results = [res.first_heat_upper_bounds_and_model_result for res in optimization_results]
    successful_optimizations = [res.unwrap() for res in bounds_and_results if is_successful(res)]
    total = optimization_results[-1].scrap_charge.total_scrap_weight
    effective_upper_bounds = {
        scrap_mix: calculate_effective_upper_bound(
            extract_bounds_and_results_for_scrap_type(scrap_mix, successful_optimizations, total), total
        )
        for scrap_mix in SUPPORTED_SCRAP_TYPES_AS_MIXES
    }
    return Map(omit_values_above(effective_upper_bounds, cutoff=total))


def evaluate_bounds(evaluation: ClosedHeatEvaluationV2) -> ClosedHeatEvaluationV2:
    scrap_charge = evaluation.scrap_charge
    optimization_results = get_optimization_results(scrap_charge)
    optimization_results.lash(evaluation.add_data_error)

    effective_lower_bounds = optimization_results.map(calculate_effective_lower_bounds)
    effective_lower_bounds.map(evaluation.add_lower_bounds_data)

    effective_upper_bounds = optimization_results.map(calculate_effective_upper_bounds)
    effective_upper_bounds.map(evaluation.add_upper_bounds_data)

    total_scrap_weight = get_last_optimization_result(scrap_charge).map(lambda r: r.first_heat_total_weight)
    lift(evaluation.add_lower_bounds_percentage_data)(effective_lower_bounds, total_scrap_weight)

    return evaluation


def evaluate_available_scrap(evaluation: ClosedHeatEvaluationV2) -> ClosedHeatEvaluationV2:
    last_optimization_result = get_last_optimization_result(evaluation.scrap_charge)
    last_optimization_result.lash(evaluation.add_data_error)

    available_scrap = last_optimization_result.map(get_available_scrap)
    available_scrap.map(evaluation.add_available_scrap)

    return evaluation


def get_planned_grade_id_scada(scada_data: HeatDataFromScada) -> Result[int, str]:
    s = scada_data.planned_grade_id
    if s is not None and np.isfinite(s):
        return Success(s)
    return Failure("Planned grade id is missing")


def get_final_grade_id_scada(scada_data: HeatDataFromScada) -> Result[int, str]:
    s = scada_data.final_grade_id
    if s is not None and np.isfinite(s):
        return Success(s)
    return Failure("Final grade id is missing")


def evaluate_steel_quality(
    evaluation: ClosedHeatEvaluationV2, scada_data: HeatDataFromScada
) -> ClosedHeatEvaluationV2:
    s_max = with_validated(scada_data, get_s_max_scada)
    evaluation.s_max = s_max.value_or(None)

    eob_s = with_validated(scada_data, get_s_eob_scada)
    lift(evaluation.add_s_over)(eob_s, s_max)

    extra_o2 = with_validated(scada_data, lambda heat: Success(heat.extra_o2))
    evaluation.extra_o2 = extra_o2.value_or(None)

    synt_slag = with_validated(scada_data, lambda heat: Success(heat.synt_slag))
    min_synt_slag = with_validated(
        scada_data,
        lambda heat: Success(
            steel_grades.get_grade_from_id(
                heat.planned_grade_id, scada_data.heat_datetime.date()
            ).min_synt_slag
        ),
    )
    lift(evaluation.add_extra_synt_slag)(synt_slag, min_synt_slag)

    planned_grade_id = with_validated(scada_data, get_planned_grade_id_scada)
    final_grade_id = with_validated(scada_data, get_final_grade_id_scada)
    lift(evaluation.add_reclassification)(planned_grade_id, final_grade_id)

    for source_data in [s_max, eob_s, extra_o2, synt_slag, min_synt_slag, planned_grade_id, final_grade_id]:
        source_data.lash(evaluation.add_data_error)

    return evaluation


def evaluate_app_data(evaluation: ClosedHeatEvaluationV2) -> ClosedHeatEvaluationV2:
    evaluation.set_heat_year()

    scrap_charge: ScrapCharge = evaluation.scrap_charge

    opt_res = scrap_charge.last_optimization_result

    if opt_res is None:
        evaluation.add_data_error("No optimization was run yet")

    evaluation.comment = scrap_charge.operator_comment

    # TODO review this comment
    # This is strange because without grade id we cannot do any optimization, but currently we have problem
    # that ClosedHeatV2 is using frontend classes for serialization so for now we need to handle also this
    # possiblity
    grade_id_app: Result[int, str] = maybe_to_result(Maybe.from_optional(scrap_charge.grade_id)).alt(
        lambda _: "Grade id was not set in application"
    )
    evaluation.grade_id_app = grade_id_app.value_or(None)  # type: ignore
    grade_id_app.lash(evaluation.add_data_error)

    if evaluation.grade_id_app is not None:
        grade = get_grade_from_id_safe(evaluation.grade_id_app, scrap_charge.closed_at.date())
        if grade is not None:
            evaluation.selectivity_app = grade.selectivity

    evaluation.recalculation_count = scrap_charge.recalculation_count
    evaluation.add_basket_ids_app(scrap_charge.baskets.all())
    evaluation.add_switched_basket_ids_app(scrap_charge.switched_baskets.all())

    return evaluation


def evaluate_misc(
    evaluation: ClosedHeatEvaluationV2, scada_data: HeatDataFromScada
) -> ClosedHeatEvaluationV2:
    heat_key = with_validated(scada_data, lambda s: Success(s.heat_key))
    evaluation.heat_no = heat_key.value_or((None, None))[0]  # type: ignore

    operator_id = with_validated(scada_data, lambda s: Success(s.operator_id))
    evaluation.operator_id = operator_id.value_or(None)  # type: ignore

    baskets = with_validated(scada_data, lambda s: Success(s.basket_ids))
    baskets.map(evaluation.add_basket_ids)

    planned_grade_id = with_validated(scada_data, lambda s: Success(s.planned_grade_id))
    evaluation.planned_grade_id = planned_grade_id.value_or(None)  # type: ignore

    scrap_charge_date = evaluation.scrap_charge.closed_at.date()

    if evaluation.planned_grade_id is not None:
        grade = get_grade_from_id_safe(evaluation.planned_grade_id, scrap_charge_date)
        if grade is not None:
            evaluation.selectivity_planned = grade.selectivity

    final_grade_id = with_validated(scada_data, lambda s: Success(s.final_grade_id))
    evaluation.final_grade_id = final_grade_id.value_or(None)  # type: ignore

    if evaluation.final_grade_id is not None:
        grade = get_grade_from_id_safe(evaluation.final_grade_id, scrap_charge_date)
        if grade is not None:
            evaluation.selectivity_final = grade.selectivity

    evaluation.selectivity_app_planned = f"{evaluation.selectivity_app} -> {evaluation.selectivity_planned}"

    fe_yield = with_validated(scada_data, lambda s: Success(s.fe_yield))
    evaluation.heat_yield = fe_yield.value_or(None)  # type: ignore

    all_inputs: List[Result] = [
        operator_id,
        baskets,
        planned_grade_id,
        final_grade_id,
        fe_yield,
        heat_key,
    ]
    for source_data in all_inputs:
        source_data.lash(evaluation.add_data_error)

    return evaluation


def evaluate_scrap_charge(scrap_charge: ScrapCharge, scada_data: Result[HeatDataFromScada, str]) -> None:
    evaluation, created = ClosedHeatEvaluationV2.objects.get_or_create(
        scrap_charge=scrap_charge, heat_date=scrap_charge.closed_at
    )

    # skip already (successfully) evaluated scrap charge
    if not created and (evaluation.data_errors is None or not evaluation.data_errors):
        log.info(f"Skipping scrap charge {scrap_charge.pk}, already evaluated")
        return

    elif created:
        log.info(f"New evaluation for closed scrap charge {scrap_charge.pk} created")

    elif evaluation.data_errors:
        log.info(
            f"Scrap charge {scrap_charge.pk} will be reevaluated due to data errors during previous evaluation"
        )
        # remove data errors, so that if new evaluation is successful,
        # it does not have any errors from the previous one
        evaluation.data_errors = None

    evaluation = evaluate_app_data(evaluation)

    scada_data.lash(evaluation.add_data_error)

    evaluation = evaluate_bounds(evaluation)
    evaluation = evaluate_available_scrap(evaluation)

    if is_successful(scada_data):
        scada_data_inner_value = scada_data.unwrap()
        evaluation = evaluate_recommendation_adherence(evaluation, scada_data_inner_value)
        evaluation = evaluate_steel_quality(evaluation, scada_data_inner_value)
        evaluation = evaluate_misc(evaluation, scada_data_inner_value)

        log.info(
            f"Scrap charge {scrap_charge.pk} evaluated with data for heat {scada_data_inner_value.heat_key}"
        )

    evaluation.set_heat_ok()
    evaluation.save()


def scrap_charges_to_df(scrap_charges: Iterable[ScrapCharge]) -> DataFrame[AppData]:
    def get_heat_key(scrap_charge: ScrapCharge) -> Optional[HeatKey]:
        try:
            evaluation = scrap_charge.closedheatevaluationv2
        except ClosedHeatEvaluationV2.DoesNotExist:
            return None

        if evaluation is None or evaluation.heat_no is None or evaluation.heat_year is None:
            return None

        return evaluation.heat_no, evaluation.heat_year

    def get_steelshop(scrap_charge: ScrapCharge) -> int:
        station_name = scrap_charge.loading_station.name.upper()
        return {"OC1": 1, "OC2": 2}.get(station_name, -1)

    rows = []

    for charge in scrap_charges:
        try:
            record = {
                AppData.scrap_charge_id: charge.pk,
                AppData.closed_at: charge.closed_at,
                AppData.scrap_weight: charge.total_scrap_weight,
                AppData.planned_grade_id: charge.grade_id,
                AppData.baskets: [b.basket_id for b in charge.baskets.all()],
                AppData.heat_key: get_heat_key(charge),
                AppData.steelshop: get_steelshop(charge),
                AppData.scrap_charge: dict(charge.recommended_scrap_charge),
            }

            rows.append(record)

        except:
            log.exception(f"Something is wrong with app data for scrap charge {charge.pk} - hence skipped")

    # add expected columns to follow `AppData` schema even in case the dataframe is empty
    return pd.DataFrame(
        rows,
        columns=[AppData.scrap_charge_id] + AppData.get_columns(),
    ).set_index(AppData.scrap_charge_id)


def to_scrap_charge(scrap: ScrapWeights) -> ScrapCoreScrapCharge:
    def from_tms_code(field_name: str) -> ScrapType:
        """scrap_94_2 -> 942 -> 1PIT A2"""
        code = field_name.split("_", 1)[1]
        return TMS_ID_MAPPING.get(int(code), "XXX")

    return Map(
        omit_zeros({from_tms_code(field_name): weight for field_name, weight in unstructure(scrap).items()})
    )


def get_db_data(dt_from: datetime, dt_to: datetime, conn: HeatData) -> List[HeatDataFromScada]:

    return [
        HeatDataFromScada(
            heat_key=heat.heat_key,
            steelshop=heat.steelshop,
            basket_ids=tuple(int(b) for b in (heat.basket_1, heat.basket_2) if pd.notna(b)),
            operator_id=heat.operator_id,
            planned_grade_id=heat.planned_grade_id,
            final_grade_id=heat.final_grade_id,
            fe_yield=heat.heat_yield,
            s_max=heat.s_max,
            s_eob=heat.eob_s,
            extra_o2=heat.extra_o2,
            synt_slag=heat.synt_slag,
            heat_datetime=heat.heat_datetime,
            scrap_charge=to_scrap_charge(heat.scrap_weights),
        )
        for heat in conn.get_heat_data(dt_from, dt_to)
    ]


def scada_data_to_df(heat_data: Iterable[HeatDataFromScada]) -> DataFrame[DbData]:

    rows = []

    for heat in heat_data:

        try:
            record = {
                DbData.heat_key: heat.heat_key,
                DbData.baskets: heat.basket_ids,
                DbData.steelshop: heat.steelshop,
                DbData.heat_datetime: heat.heat_datetime,
                DbData.planned_grade_id: heat.planned_grade_id,
                DbData.scrap_weight: sum(heat.scrap_charge.values()),
                DbData.scrap_charge: dict(heat.scrap_charge),
            }

            rows.append(record)

        except:
            try:
                log.exception(f"Something is wrong with scada data for heat {heat.heat_key} - hence skipped")
            except:
                log.exception(f"Some heat record in scada has invalid heat key - hence skipped")

    return pd.DataFrame(rows)


def evaluate_scrap_charges(
    dt_from: datetime.datetime,  # UTC
    dt_to: datetime.datetime,  # UTC
    *,
    time_tolerance: datetime.timedelta,
    force_refresh: bool,
) -> None:
    log.info(
        f"Evaluating scrap charges between {dt_from} and {dt_to} "
        f"with time_tolerance={time_tolerance} and force_refresh={force_refresh}"
    )

    scrap_charges = ScrapCharge.objects.filter(closed_at__gte=dt_from, closed_at__lte=dt_to)

    # if force refresh is set, remove all related evaluations
    if force_refresh:
        evaluations_to_delete = ClosedHeatEvaluationV2.objects.filter(scrap_charge__in=scrap_charges)
        num_of_evaluations_to_delete = len(evaluations_to_delete)
        evaluations_to_delete.delete()
        log.info(f"{num_of_evaluations_to_delete} evaluations have been removed due to forced refresh")

    data_app = {scrap_charge.pk: scrap_charge for scrap_charge in scrap_charges}
    df_app = scrap_charges_to_df(scrap_charges)

    log.info(f"Found {len(data_app)} scrap charges in App db for selected time interval")

    data_db = get_db_data(dt_from, dt_to + time_tolerance, db_scada)
    df_db = scada_data_to_df(data_db)

    log.info(f"Found {len(data_db)} scrap charges in Scada db for selected time interval")

    matching = find_matching(df_app, df_db, time_tolerance=time_tolerance)

    data_db_dict = {heat.heat_key: heat for heat in data_db}

    for scrap_charge_id, scrap_charge in data_app.items():
        maybe_heat_scada_data = data_db_dict.get(matching.get(scrap_charge_id))
        heat_scada_data = (
            Success(maybe_heat_scada_data)
            if maybe_heat_scada_data is not None
            else Failure("Scrap charge not matched")
        )
        evaluate_scrap_charge(scrap_charge, heat_scada_data)
