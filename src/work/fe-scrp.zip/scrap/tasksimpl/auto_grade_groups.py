import logging
from collections import defaultdict
from datetime import date
from decimal import ROUND_DOWN, Decimal
from typing import List, Mapping, Hashable, Callable, Optional

from scrap.dash.database_api import steel_grades
from scrap.models import GradeDefinition, GradeGroup

from usskssgrades.steel_grades_common import ChemLimitsError
from usskssgrades.grade import DUMMY_CASTING_GROUP

THREE_DECIMAL_PLACES = Decimal("0.001")

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


DEFAULT_FALLBACK_VALUE = "na"


def round_down_to_3_decimal_places(max_s: float) -> Decimal:
    """
    Rounding requested by Henrich Luzak and Stanislav Peregrin as USS is certified only to
    3 decimal places - other grades f.e. (0.0035) are copied from customer request and we should
    produce them to three decimal places f.e. (0.003)
    """
    # Convert float to string first, as for example Decimal(0.015) is equal to
    # Decimal('0.01499999999999999944488848768742172978818416595458984375')
    return Decimal(str(max_s)).quantize(THREE_DECIMAL_PLACES, rounding=ROUND_DOWN)


def apply_max_ni_bin(max_chem_method: Callable):
    """Categorize grades into two bins based on max Ni < 0.06."""
    return "<0.06" if max_chem_method("Ni") < 0.06 else ">=0.06"


def apply_max_p_bin(max_chem_method: Callable):
    """Categorize grades into two bins based on max P <= 0.015."""
    return "<=0.015" if max_chem_method("P") <= 0.015 else ">0.015"


def group_grades_by_grade_attr(
    name: str,
    fallback: Hashable,
    postprocessor: Optional[Callable],
    when: date,
) -> Mapping[Hashable, List[int]]:
    """Group grades by given attribute or property of Grade class."""
    all_grade_ids = steel_grades.get_available_grade_ids(when)
    grouped_grades = defaultdict(list)
    for grade_id in all_grade_ids:
        try:
            grade = steel_grades.get_grade_from_id(grade_id, when)
        except ChemLimitsError as e:
            if e.no_limits:
                continue
            final_value = fallback
        else:
            value = getattr(grade, name)
            final_value = postprocessor(value) if postprocessor is not None else value
        grouped_grades[final_value].append(grade_id)
    return grouped_grades


def save_grade_groups_by_grade_attr(
    when: date, name: str, fallback: Hashable, postprocesor: Optional[Callable], name_sk: str
):
    grouped_grades = group_grades_by_grade_attr(name, fallback, postprocesor, when)
    for group in grouped_grades:
        grade_group, _ = GradeGroup.objects.update_or_create(
            group_name=f"[A] {name_sk} {group}",
            defaults={
                "comment": f"Generovaná skupina podľa hodnoty parametra {name_sk}: {group}. Obnovená: {when}."
            },
        )
        grade_group.grade_ids.set(
            GradeDefinition.objects.get_or_create(grade_id=gid)[0] for gid in grouped_grades[group]
        )
    log.info(f"Refreshed {len(grouped_grades)} grade groups derived from {name} ({name_sk}).")


def save_grade_groups_by_max_s(when: date) -> None:
    save_grade_groups_by_grade_attr(when, "max_s", Decimal("100"), round_down_to_3_decimal_places, "Sira max")


def save_grade_groups_by_casting_group(when: date) -> None:
    save_grade_groups_by_grade_attr(when, "casting_group", DUMMY_CASTING_GROUP, None, "Skupina liatia")


def save_grade_groups_by_max_ni(when: date) -> None:
    save_grade_groups_by_grade_attr(when, "max_chem", DEFAULT_FALLBACK_VALUE, apply_max_ni_bin, "Nikel max")


def save_grade_groups_by_max_p(when: date) -> None:
    save_grade_groups_by_grade_attr(when, "max_chem", DEFAULT_FALLBACK_VALUE, apply_max_p_bin, "Fosfor max")
