import datetime
import logging
import numpy as np
from collections import Counter
from itertools import chain
from typing import Dict, List, Tuple

import pandas as pd
from attr_runtime_validation.on_access_validation import enabled_validation
from attr_runtime_validation.validators import ValidationError
from scrap_core import ScrapType
from scrap_core.datamodel import Heat
from scrap_core.datamodel.oko import OkoDB, get_weeks, load_heats_from_oko_for_time_range
from scrap_core.yieldmodel.yield_model_precise import (
    UNSUPPORTED_SCRAP_WARNING_SUFFIX,
    YieldEstimate,
    get_weighted_average_estimates,
    get_yield_estimates,
)

from ..dash.database_api import steel_grades
from ..models import YieldCalculationModelResult

MonthYear = Tuple[int, int]
TimeWindow = List[MonthYear]
TimeWindows = List[TimeWindow]


def get_month_year_for_heat(heat: Heat) -> MonthYear:
    time = datetime.datetime.fromtimestamp(heat.heat_datetime)
    return (time.month, time.year)


def get_all_year_months_between(first, last):
    for year in range(first[1], last[1] + 1):
        first_month, last_month = 1, 12
        if year == first[1]:
            first_month = first[0]
        if year == last[1]:
            last_month = last[0]
        for month in range(first_month, last_month + 1):
            yield (month, year)


def create_results_for_windows(heats: List[Heat], window_size: int) -> pd.DataFrame:
    windows = get_windows(heats, window_size)
    results_per_window = {
        months_in_window[0]: recalculate([h for h in heats if get_month_year_for_heat(h) in months_in_window])
        for months_in_window in windows
    }

    return pd.concat(results_per_window)


def get_windows(heats: List[Heat], window_size: int) -> TimeWindows:
    sorted_heats = sorted(heats, key=lambda heat: heat.heat_datetime)
    all_months = list(
        get_all_year_months_between(
            get_month_year_for_heat(sorted_heats[0]), get_month_year_for_heat(sorted_heats[-1])
        )
    )
    windows = [all_months[x : x + window_size] for x in range(0, len(all_months) - window_size + 1)]
    return windows


def get_heats_with_valid_scraps(heats: List[Heat]) -> List[Heat]:
    valid_heats = []
    for heat in heats:
        with enabled_validation(heat) as heat_with_validation:
            try:
                _ = heat_with_validation.scrap
            except ValidationError:
                continue
            else:
                valid_heats.append(heat)
    return valid_heats


def get_weighted_avg_estimates_for_all_windows(
    heats: List[Heat], yield_estimates: Dict[ScrapType, YieldEstimate], windows: TimeWindows
) -> Dict[MonthYear, Tuple[float, float]]:
    return {
        months_in_window[0]: get_weighted_average_estimates(
            [h for h in heats if get_month_year_for_heat(h) in months_in_window], yield_estimates
        )
        for months_in_window in windows
    }


def get_results_for_weighted_avg_graph(
    valid_heats_for_training: List[Heat], all_heats: List[Heat], window_size: int
) -> pd.DataFrame:
    windows = get_windows(all_heats, window_size)
    yield_estimates = get_yield_estimates(valid_heats_for_training)
    all_heats_with_valid_scraps = get_heats_with_valid_scraps(all_heats)

    results_per_window = get_weighted_avg_estimates_for_all_windows(
        all_heats_with_valid_scraps, yield_estimates, windows
    )
    results_per_window_oc1 = get_weighted_avg_estimates_for_all_windows(
        [h for h in all_heats_with_valid_scraps if h.steelshop == 1], yield_estimates, windows
    )
    results_per_window_oc2 = get_weighted_avg_estimates_for_all_windows(
        [h for h in all_heats_with_valid_scraps if h.steelshop == 2], yield_estimates, windows
    )

    data = pd.DataFrame.from_dict(results_per_window, orient="index")
    data_oc1 = pd.DataFrame.from_dict(results_per_window_oc1, orient="index")
    data_oc2 = pd.DataFrame.from_dict(results_per_window_oc2, orient="index")
    result_data = pd.concat([data, data_oc1, data_oc2], axis=1)
    result_data.columns = ["mean", "std", "mean_oc1", "std_oc1", "mean_oc2", "std_oc2"]
    return result_data


def count_scrap_usage(heats: List[Heat]) -> Dict[ScrapType, int]:
    return dict(Counter(chain.from_iterable([list(heat.get_scrap_map()) for heat in heats])))


def recalculate(heats: List[Heat]) -> pd.DataFrame:
    yield_estimates = get_yield_estimates(heats)

    return pd.DataFrame(
        {
            "Yields": {scrap_type: estimate.yield_mean for scrap_type, estimate in yield_estimates.items()},
            "Stds": {scrap_type: estimate.yield_std for scrap_type, estimate in yield_estimates.items()},
            "Counts": count_scrap_usage(heats),
        }
    ).fillna(0.0)


def save_with_progress(db_result: YieldCalculationModelResult, progress: float):
    if progress < 100.0:
        db_result.status = YieldCalculationModelResult.ResultStatus.RUNNING
        db_result.progress = progress
    else:
        db_result.status = YieldCalculationModelResult.ResultStatus.FINISHED
        db_result.progress = 100.0
    db_result.save()


def load_heats_from_oko(
    db_result: YieldCalculationModelResult, oko_db: OkoDB, validation: bool
) -> List[Heat]:
    weeks_to_load = list(get_weeks(db_result.data_from, db_result.data_to))
    progress_tick = 90 / len(weeks_to_load)

    heats: List[Heat] = []
    for i, week in enumerate(weeks_to_load):
        logging.info(f"Yield calculation {db_result.pk} - loading week {i + 1}/{len(weeks_to_load)}")
        load_heats_from_oko_for_time_range(
            week[0],
            week[1],
            oko_db,
            steel_grades,
            heat_loaded_callback=heats.append,
            error_callback=lambda key, error: None,
            validation=validation,
        )
        save_with_progress(db_result, db_result.progress + progress_tick)
    return heats


def get_scrap_warnings(errors: List[str]) -> List[str]:
    return list(filter(lambda x: UNSUPPORTED_SCRAP_WARNING_SUFFIX in x, errors))


def get_average_graph_data_warnings(data: pd.DataFrame) -> List[str]:
    r_index, c_index = np.where(data.isna())
    return [
        f"Missing data for {data.iloc[r_index[i]].name} in {data.T.iloc[c_index[i]].name}"
        for i in range(0, len(r_index))
    ]


def get_frontend_warnings_df(avg_graph_data: pd.DataFrame, errors: List[str]) -> pd.DataFrame:
    avg_graph_warnings = get_average_graph_data_warnings(avg_graph_data)
    scrap_warnings = get_scrap_warnings(errors)
    return pd.DataFrame(avg_graph_warnings + scrap_warnings, columns=["warning"])
