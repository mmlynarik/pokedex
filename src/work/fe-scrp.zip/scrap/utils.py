from datetime import date, datetime
from typing import Any, Callable, Dict, Optional, Type, TypeVar

import cattr
import zoneinfo
from immutables import Map
from usskssgrades import Grade, SteelGrades
from vsadzka.settings import TIME_ZONE

from scrap_core import DOMESTIC_SCRAP_ZONES, ScrapMix
from scrap_core.blendmodel import ScrapBlendModelInput, get_blend_model
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    get_corr_tech_model,
)
from scrap_core.datamodel import RawFeChem
from scrap_core.optimization import ModelSettings

T = TypeVar("T")

TZ_UTC = zoneinfo.ZoneInfo(TIME_ZONE)


def is_zone_domestic(zone: str) -> bool:
    return zone in DOMESTIC_SCRAP_ZONES


class TableRowMixin:
    def to_table_row(self) -> Dict:
        return cattr.unstructure(self)

    @classmethod
    def from_table_row(cls: Type[T], table_row) -> T:
        return cattr.structure(table_row, cls)


def get_pig_iron_s_for_grade(steel_grades: SteelGrades, grade_id: Optional[int]) -> float:
    if grade_id is None:
        return 0.002
    if not steel_grades.grade_id_exists(grade_id, date.today()):
        return 0.002
    grade = steel_grades.get_grade_from_id(grade_id, date.today())
    return grade.desulf_s


def to_milliseconds(dt: datetime) -> int:
    return int(dt.timestamp() * 1000)


def from_milliseconds(timestamp: int) -> datetime:
    return datetime.fromtimestamp(timestamp / 1000, tz=TZ_UTC)


def from_timestamp(timestamp: float) -> datetime:
    return datetime.fromtimestamp(timestamp, tz=TZ_UTC)


def get_submodel_results_calculator(
    pig_iron_weight: int, grade: Grade, raw_fe_chem: RawFeChem, model_settings: ModelSettings
) -> Callable[[Map[ScrapMix, float]], Dict[str, Any]]:
    def calculate_submodel_results(scrap_weights: Map[ScrapMix, float]) -> Dict[str, Any]:
        blend_model = get_blend_model(model_settings.blend_model_settings.version)
        mix_mapping = model_settings.optimizer_settings.scrap_mix_mapping
        corr_tech_chems = model_settings.correction_technologies_settings.chems_for_correction_technologies
        corr_tech_model = get_corr_tech_model(
            model_settings.correction_technologies_settings.version,
            corr_tech_chems,
        )
        blend_model_input = ScrapBlendModelInput(
            pig_iron_weight, raw_fe_chem, scrap_weights, 0.0, 0.0, mix_mapping
        )
        blend_model_output = blend_model.calculate(blend_model_input)
        corr_tech_model_output = corr_tech_model.calculate(
            CorrectionTechnologiesModelInput(grade, blend_model_output)
        )
        return {
            "corr_tech_model_output": corr_tech_model_output,
            "blend_model_output": blend_model_output,
            "used_predicted_chems": corr_tech_chems,
        }

    return calculate_submodel_results
