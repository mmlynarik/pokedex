import logging
from typing import Dict, Optional, Union

import attr
from asgiref.sync import sync_to_async
from channels.generic.websocket import AsyncJsonWebsocketConsumer
from scalecore.processor import StartAction, StopAction, StopStartAction, UpdateAction
from scrap.models.various_models import ScaleCurrentState
from scrap.scales.weighting_backend import DjangoWeightingBackend, apply_action_with_db_lock
from scrap.weighting import MESSAGING_PROCESSORS, WEIGHTING_BACKENDS
from vsadzka.settings import SCALE_SS1_V1, SCALE_SS1_V2, SCALE_SS2_V8, SCALE_SS2_V9

LOGGER = logging.getLogger(__name__)

START_EVENT_KEY = "start_weighting"
STOP_EVENT_KEY = "stop_weighting"
SUPPORTED_EVENT_KEYS = (START_EVENT_KEY, STOP_EVENT_KEY)

Payload = Dict[str, Union[str, int]]


def scale_id_exist(instance, attribute, value):
    if value not in [SCALE_SS1_V1, SCALE_SS1_V2, SCALE_SS2_V8, SCALE_SS2_V9]:
        raise ValueError(f"{value} is not valid scale id.")


@attr.frozen
class BaseWeightingPayload:
    scale_id: str = attr.ib(validator=scale_id_exist)


@attr.frozen
class StartWeightingPayload(BaseWeightingPayload):
    scrap: str
    scrap_charge_id: int
    weighting_id: Optional[int]


@attr.frozen
class StopWeightingPayload(BaseWeightingPayload):
    weighting_id: int


async def get_current_state(scale_id: str) -> ScaleCurrentState:
    current_state = await ScaleCurrentState.objects.select_related("weighted_scrap").aget(scale_id=scale_id)
    LOGGER.info(
        f"Current db state: state = {current_state.state}, scale_id = {current_state.scale_id}, "
        f"time = {current_state.time}, scrap = {current_state.scrap}"
    )
    return current_state


async def start_weighting(raw_payload: Payload) -> None:
    LOGGER.info(f"Starting event -> payload: {raw_payload}")
    payload = StartWeightingPayload(**raw_payload)

    backend = WEIGHTING_BACKENDS[payload.scale_id]
    messaging_processor = MESSAGING_PROCESSORS[payload.scale_id]

    action_to_execute: Union[StartAction, StopStartAction]
    action_to_execute = start_action = StartAction(payload.scrap, payload.scrap_charge_id)

    current_state = await get_current_state(payload.scale_id)
    if current_state.state == ScaleCurrentState.ScaleState.WEIGHTING:
        action_to_execute = StopStartAction(
            stop_action=StopAction(weighting_id=current_state.weighted_scrap.pk),
            start_action=start_action,
        )
    LOGGER.info(f"Action to execute: {action_to_execute}")

    await sync_to_async(apply_action_with_db_lock, thread_sensitive=True)(
        backend,
        action_to_execute,
        messaging_processor,
    )

    await sync_to_async(apply_action_with_db_lock, thread_sensitive=True)(
        backend, UpdateAction(), messaging_processor
    )
    LOGGER.info(f"Event - start_weighting - done (with data {raw_payload})")


async def stop_weighting(raw_payload: Payload) -> None:
    LOGGER.info(f"Stop event -> payload: {raw_payload}")
    payload = StopWeightingPayload(**raw_payload)

    backend: DjangoWeightingBackend = WEIGHTING_BACKENDS[payload.scale_id]
    messaging_processor = MESSAGING_PROCESSORS[payload.scale_id]

    await sync_to_async(apply_action_with_db_lock, thread_sensitive=True)(
        backend, StopAction(payload.weighting_id), messaging_processor
    )
    # StopAction changes the state of the processor from Weighting state to the stopping state.
    # If a stopping state is set up, it's necessary to call an update action to move to the stopped state.
    await sync_to_async(apply_action_with_db_lock, thread_sensitive=True)(
        backend, UpdateAction(), messaging_processor
    )
    LOGGER.info(f"Event - stop_weighting - done (with data {raw_payload} done)")


HANDLERS = {
    START_EVENT_KEY: start_weighting,
    STOP_EVENT_KEY: stop_weighting,
}


async def handle_event(event: str, payload: Payload) -> None:
    if event not in SUPPORTED_EVENT_KEYS:
        return None

    LOGGER.info(f"Calling event {event} with data: {payload} ...")
    handler = HANDLERS[event]
    await handler(payload)


class ScaleControllerConsumer(AsyncJsonWebsocketConsumer):
    GROUP_NAME = "scale-controller-{scale_id}"

    def get_group_name(self, scale_id: str) -> str:
        return self.GROUP_NAME.format(scale_id=scale_id)

    async def connect(self):
        self.group_name = self.get_group_name(self.scope["url_route"]["kwargs"]["scale_id"])
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()
        LOGGER.info(f"WebSocket connection was accepted for group {self.group_name}")

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)
        LOGGER.info(f"WebSocket connection was disconnected with code {close_code} for {self.group_name}")

    async def receive_json(self, content: Payload, **kwargs) -> None:
        if not content:
            return

        LOGGER.info(f"Content received to group: {self.group_name}, content: {content}")
        for event, event_data in content.items():
            await handle_event(event, event_data)

    async def forward_message(self, message: Payload) -> None:
        await self.send_json(content=message.get("content"))
        LOGGER.info(f"Event - forward_message: {message.get('content')}")
