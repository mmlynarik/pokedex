import logging
from typing import Any, Dict

from channels.generic.websocket import AsyncJsonWebsocketConsumer

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class ActualScaleDataConsumer(AsyncJsonWebsocketConsumer):
    GROUP_NAME = "actualscaleweight{scale_id}"

    def get_group_name(self, scale_id: str) -> str:
        return self.GROUP_NAME.format(scale_id=scale_id)

    async def connect(self) -> None:
        self.group_name = self.get_group_name(self.scope["url_route"]["kwargs"]["scale_id"])
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()
        log.info(f"WebSocket connection was accepted for group name: {self.group_name}")

    async def disconnect(self, close_code) -> None:
        await self.channel_layer.group_discard(self.group_name, self.channel_name)
        log.info(
            f"WebSocket connection was disconnected with code {close_code} for group name: {self.group_name}"
        )

    async def actual_data(self, data: Dict[str, Any]) -> None:
        await self.send_json(content=data)
