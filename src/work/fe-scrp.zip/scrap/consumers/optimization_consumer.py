import asyncio
import logging
from typing import Any, Dict

from channels.generic.websocket import AsyncJsonWebsocketConsumer

from scrap.models import MultipleHeatsOptimizationResult


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


SUPPORTED_EVENTS = ("get_optimization_status",)
PUSHING_TIMEOUT = 1  # sec
OPTIMIZATION_ID_FRONTEND_KEY = "optimization_id"
SCRAP_CHARGE_ID_FRONTEND_KEY = "scrap_charge_id"


class OptimizationProgressConsumer(AsyncJsonWebsocketConsumer):
    GROUP_NAME = "optimization-progress"

    async def connect(self):
        await self.channel_layer.group_add(self.GROUP_NAME, self.channel_name)
        await self.accept()
        log.info(f"WebSocket connection was accepted for group name: {self.GROUP_NAME}")

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.GROUP_NAME, self.channel_name)
        log.info(
            f"WebSocket connection was disconnected with code {close_code} for group name: {self.GROUP_NAME}"
        )

    async def receive_json(self, content: Dict[str, Any]) -> None:
        if not content:
            return
        events_collection = tuple(content.keys())
        for event in events_collection:
            if event in SUPPORTED_EVENTS:
                await self.channel_layer.group_send(self.GROUP_NAME, {"type": event, **content[event]})

    async def get_optimization_status(self, data: Dict[str, str]) -> None:

        optimization_id = data.get(OPTIMIZATION_ID_FRONTEND_KEY)
        scrap_charge_id = data.get(SCRAP_CHARGE_ID_FRONTEND_KEY)

        if optimization_id is None or scrap_charge_id is None:
            return

        optimization = await MultipleHeatsOptimizationResult.objects.aget(pk=optimization_id)

        while optimization.status == MultipleHeatsOptimizationResult.ResultStatus.RUNNING:

            await optimization.arefresh_from_db()

            await self.send_json(content={"progress": optimization.progress})

            await asyncio.sleep(PUSHING_TIMEOUT)

        # send final update, in case previous progress < 100%
        await self.send_json(content={"progress": optimization.progress})
