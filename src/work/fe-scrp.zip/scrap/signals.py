import logging

from django.db import transaction
from django.db.models.signals import pre_delete
from django.dispatch import receiver
from tenacity import Retrying, stop_after_attempt, wait_random, RetryError

from scalecore.processor import StopAction, UpdateAction
from scrap.management.commands.scrap_weight_update import WEIGHTING_SLEEP_SEC
from scrap.models import WeightedScrap
from scrap.scales.weighting_backend import apply_action_with_db_lock
from scrap.weighting import WEIGHTING_BACKENDS, MESSAGING_PROCESSORS


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@receiver(pre_delete, sender=WeightedScrap, dispatch_uid="stop_weighting_when_deleting")
def stop_weighting_when_deleting(sender, instance, **kwargs):
    if instance.scalecurrentstate_set.all():

        log.warning(
            f"Instance {instance} to be deleted is linked to current scale state, StopAction will be called"
        )

        backend = WEIGHTING_BACKENDS[instance.scale_id]
        messaging_processor = MESSAGING_PROCESSORS[instance.scale_id]

        try:
            for attempt in Retrying(
                stop=stop_after_attempt(3),
                wait=wait_random(min=WEIGHTING_SLEEP_SEC / 5, max=WEIGHTING_SLEEP_SEC / 3),
            ):

                with attempt:

                    with transaction.atomic():

                        stop_error = apply_action_with_db_lock(
                            backend, StopAction(weighting_id=instance.id), messaging_processor
                        )

                        if stop_error is not None:
                            log.error(f"Attempt {attempt} failed due to error: {stop_error}")
                            raise stop_error

                        update_error = apply_action_with_db_lock(backend, UpdateAction(), messaging_processor)

                        if update_error is not None:
                            log.error(f"Attempt {attempt} failed due to error: {update_error}")
                            raise update_error

            log.info(f"Weighting on scale {instance.scale_id} stopped successfully")

        except RetryError:
            log.exception(f"StopAction on scale {instance.scale_id} failed")
