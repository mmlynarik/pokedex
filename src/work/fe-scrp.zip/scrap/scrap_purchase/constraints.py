from typing import Tuple, Dict

import numpy as np
from pandera.typing import DataFrame, Series

from scrap.models import ProductionPlanData
from scrap_core import Chem
from scrap_core.blendmodel.eob_config import EOB_MODEL_SUPPORTED_CHEMS
from scrap_core.meltabilitymodel import SCRAP_MELTABILITY_V2
from scrap_core.meltabilitymodel.meltability_model import MeltabilityType
from scrap_core.optimization import ModelSettings
from scrap_core.optimization.linprog_optimizer import Constraint

from scrap.scrap_purchase.utils import (
    calc_scrap_yield_vector,
    calc_minimal_total_steel_weight_from_scrap,
    get_scrap_unit_chem_weight,
    get_max_chem_weight_in_scrap,
    ScrapData,
)


LIGHT_MELTABILITY_CONSTRAINT = "light_melt"
HARD_MELTABILITY_CONSTRAINT = "hard_melt"
SCRAP_WEIGHT_CONSTRAINT = "scrap_weight"


def calculate_scrap_weight_constraint(
    scrap_type_vector: Series[str],
    expected_steel_production,
    scrap_stock_objective_in_kgs: int,
    mean_scrap_ratio: float,
) -> Constraint:
    scrap_yield_vector = calc_scrap_yield_vector(scrap_type_vector)

    minimal_total_steel_weight_from_scrap = calc_minimal_total_steel_weight_from_scrap(
        expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )

    scrap_w_constraint = Constraint(
        (-1) * scrap_yield_vector.reshape(1, -1), np.array([-minimal_total_steel_weight_from_scrap])
    )

    return scrap_w_constraint


def calculate_meltability_constraints(
    scrap_type_vector: Series[str], meltability_type: MeltabilityType, min_ratio: float, max_ratio: float
) -> Tuple[Constraint, Constraint]:

    meltability_vector = np.array(
        scrap_type_vector.apply(lambda st: SCRAP_MELTABILITY_V2[st] == meltability_type.upper())
    ).astype(int)

    zero = np.array([0])

    low_meltability_constraint = Constraint(
        (np.ones_like(meltability_vector) * min_ratio - meltability_vector).reshape(1, -1), zero
    )

    upp_meltability_constraint = Constraint(
        (meltability_vector - np.ones_like(meltability_vector) * max_ratio).reshape(1, -1), zero
    )

    return low_meltability_constraint, upp_meltability_constraint


def calculate_chem_constraints(
    scrap_type_vector: Series[str],
    model_settings: ModelSettings,
    production_plan: ProductionPlanData,
    mean_scrap_ratio: float,
) -> Dict[Chem, Constraint]:

    scrap_unit_chem_weight = get_scrap_unit_chem_weight(model_settings)

    scrap_yield_vector = calc_scrap_yield_vector(scrap_type_vector)

    constraints = {}

    for chem in EOB_MODEL_SUPPORTED_CHEMS - {"Si"}:

        scrap_chem_w_vector = np.array(scrap_type_vector.apply(scrap_unit_chem_weight[chem].get).fillna(1))

        # Alter chem weight vector with reasonable upper bound,
        # e.g. Cr content of HSR Cr is estimated as 10
        scrap_chem_w_vector = np.minimum(scrap_chem_w_vector, 1 - scrap_yield_vector)

        max_chem_w = get_max_chem_weight_in_scrap(chem, production_plan, mean_scrap_ratio)

        constraints[chem] = Constraint(scrap_chem_w_vector.reshape(1, -1), np.array([max_chem_w]))

    return constraints


def verify_scrap_weight_constraint(
    df_scrap: DataFrame[ScrapData],
    expected_steel_production,
    scrap_stock_objective_in_kgs,
    mean_scrap_ratio,
):
    available_scrap_vector = np.array(df_scrap[ScrapData.weight])
    coefficients = calc_scrap_yield_vector(df_scrap[ScrapData.scrap_type])

    minimal_total_steel_weight_from_scrap = calc_minimal_total_steel_weight_from_scrap(
        expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )

    return minimal_total_steel_weight_from_scrap <= np.dot(coefficients, available_scrap_vector)


def collect_scrap_purchase_constraints(input_data) -> Tuple[Dict[str, Constraint], Dict[str, Constraint]]:

    scrap_type_vector = input_data.to_dataframe_grouped()[ScrapData.scrap_type]

    settings = input_data.optimization_settings.model_settings.optimizer_settings

    low_light_meltability_constraint, upp_light_meltability_constraint = calculate_meltability_constraints(
        scrap_type_vector,
        meltability_type="L",
        min_ratio=settings.l_min_ratio,
        max_ratio=settings.l_max_ratio,
    )
    low_hard_meltability_constraint, upp_hard_meltability_constraint = calculate_meltability_constraints(
        scrap_type_vector,
        meltability_type="T",  # T as Tazko
        min_ratio=settings.h_min_ratio,
        max_ratio=settings.h_max_ratio,
    )

    chem_constraints = calculate_chem_constraints(
        scrap_type_vector,
        input_data.optimization_settings.model_settings,
        input_data.corrected_production_plan,
        input_data.mean_scrap_ratio,
    )

    scrap_weight_constraint = calculate_scrap_weight_constraint(
        scrap_type_vector,
        input_data.expected_steel_production,
        input_data.scrap_stock_objective_in_kgs,
        input_data.mean_scrap_ratio,
    )

    low_constraints = {
        LIGHT_MELTABILITY_CONSTRAINT: low_light_meltability_constraint,
        HARD_MELTABILITY_CONSTRAINT: low_hard_meltability_constraint,
        SCRAP_WEIGHT_CONSTRAINT: scrap_weight_constraint,
    }

    upp_constraints = {
        LIGHT_MELTABILITY_CONSTRAINT: upp_light_meltability_constraint,
        HARD_MELTABILITY_CONSTRAINT: upp_hard_meltability_constraint,
        **chem_constraints,
    }

    return low_constraints, upp_constraints
