"""
Relaxation strategy in this module is not complete in a sense, that there may be examples
we can't relax. On the other hand, the sharpest constraint is the one for sulphur,
so I believe that ability to relax single constraint is more than sufficient.
"""

import logging
from typing import Optional, Dict, Sequence, Tuple

import numpy as np
from scipy.optimize import OptimizeResult

from scrap.scrap_purchase.common import ScrapPurchaseRelaxationError, find_solution
from scrap_core.optimization.linprog_optimizer import Constraint


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# relaxation starts with coefficient 1 - no relaxation
RELAXATION_MIN = 1
# maximal relaxation is 2 times standard bound, there is no rationale for selection of value 2,
# but it seems to me that relaxation with coefficient > 2 is too much and shall not be allowed
RELAXATION_MAX = 2
# this step is a trade-off between speed and precision and works well
RELAXATION_STEP = 1000


def find_infeasible_upper_constraints(
    price_vector: np.ndarray,
    bounds: Sequence[Tuple[float, float]],
    low_constraints: Dict[str, Constraint],
    upp_constraints: Dict[str, Constraint],
) -> Dict[str, Constraint]:
    infeasible_constraints = {}

    for name, cons in upp_constraints.items():
        res = find_solution(price_vector, bounds, [cons] + list(low_constraints.values()))

        if not res.success:
            infeasible_constraints[name] = cons

    return infeasible_constraints


def find_relaxation_coefficient(
    price_vector: np.ndarray,
    bounds: Sequence[Tuple[float, float]],
    feasible_constraints: Dict[str, Constraint],
    infeasible_constraint: Constraint,
) -> Optional[float]:
    for alpha in np.linspace(RELAXATION_MIN, RELAXATION_MAX, RELAXATION_STEP):
        new_cons = Constraint(infeasible_constraint.coef_matrix, infeasible_constraint.values_vector * alpha)

        res = find_solution(price_vector, bounds, [new_cons] + list(feasible_constraints.values()))

        if res.success:
            return alpha

    return None


def find_relaxed_solution(
    price_vector: np.ndarray,
    bounds: Sequence[Tuple[float, float]],
    feasible_constraints: Dict[str, Constraint],
    infeasible_upp_constraints: Dict[str, Constraint],
) -> OptimizeResult:

    relaxed_constraints = {}

    for name, cons in infeasible_upp_constraints.items():

        alpha = find_relaxation_coefficient(
            price_vector, bounds, {**feasible_constraints, **relaxed_constraints}, cons
        )
        log.info(f"Relaxation coefficient for constraint {name} = {alpha}")

        if alpha is None:
            raise ScrapPurchaseRelaxationError(f"Constraint '{name}' failed to relax")

        relaxed_constraints.update({name: Constraint(cons.coef_matrix, cons.values_vector * alpha)})

    return find_solution(price_vector, bounds, {**feasible_constraints, **relaxed_constraints}.values())
