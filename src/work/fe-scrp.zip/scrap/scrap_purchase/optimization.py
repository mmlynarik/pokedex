"""
TODO move scrap purchase related tasks here,
  when this functionality is available in the latest django-dramatiq version,
  see `DRAMATIQ_AUTODISCOVER_MODULES` in the vsadzka.settings module

FIXME find out how the price of scrap should be calculated, at the moment if user add override price,
  our price + delta is recalculated such that the result is override price + delta
"""

import logging
from typing import Dict, Tuple

import numpy as np
from immutables import Map
from scipy.optimize import linprog

from scrap.models import ScrapOfferData, ScrapPurchaseOptimizationInput
from scrap.scrap_purchase.constraints import collect_scrap_purchase_constraints
from scrap.scrap_purchase.relaxation import find_infeasible_upper_constraints, find_relaxed_solution
from scrap.scrap_purchase.common import find_solution, ScrapPurchaseOptimizationError
from scrap.scrap_purchase.utils import calc_price_vector
from scrap_core import ScrapType
from scrap_core.utils import convert_tons_to_kilograms, omit_zeros

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# TODO simplify inputs
# pylint:disable=too-many-locals
def estimate_needed_scrap(
    input_data: ScrapPurchaseOptimizationInput,
) -> Tuple[Map[ScrapType, float], Tuple[str, ...]]:
    """Estimate needed scrap based on production plan and actual scrap supplies."""
    df_grouped = input_data.to_dataframe_grouped()

    price_vector = calc_price_vector(df_grouped)

    upp_bounds = np.array(df_grouped["weight"])
    low_bounds = np.zeros_like(upp_bounds)
    bounds = list(zip(low_bounds, upp_bounds))

    low_constraints, upp_constraints = collect_scrap_purchase_constraints(input_data)
    all_constraints = {**low_constraints, **upp_constraints}

    res = find_solution(price_vector, bounds, all_constraints.values())

    infeasible_constraint_names = tuple()

    if not res.success:
        infeasible_constraints = find_infeasible_upper_constraints(
            price_vector, bounds, low_constraints, upp_constraints
        )
        infeasible_constraint_names = tuple(infeasible_constraints.keys())

        feasible_constraints = {
            name: cons for name, cons in all_constraints.items() if name not in infeasible_constraint_names
        }

        res = find_relaxed_solution(price_vector, bounds, feasible_constraints, infeasible_constraints)

    if not res.success:
        raise ScrapPurchaseOptimizationError(res)

    df_grouped["res"] = res.x
    estimate = df_grouped.groupby("scrap_type").sum()["res"].to_dict()

    return estimate, infeasible_constraint_names


def calculate_available_scrap(input_data: ScrapPurchaseOptimizationInput) -> Map[ScrapType, float]:
    """Return mapping of all available scrap types and their weights"""
    return Map(
        input_data.to_dataframe()[["scrap_type", "weight"]].groupby("scrap_type").sum()["weight"].to_dict()
    )


def calculate_scrap_supplies(input_data: ScrapPurchaseOptimizationInput) -> Dict[ScrapType, float]:
    """Return mapping of all owned scrap types and their weights"""
    df_scrap = input_data.to_dataframe()
    scrap_supplies = (
        df_scrap.loc[
            df_scrap["record_type"].isin(
                ("scrap_pile", "on_the_way", "realized_offer", "expected_home_scrap")
            )
        ][["scrap_type", "weight"]]
        .groupby("scrap_type")
        .sum()["weight"]
        .to_dict()
    )
    return scrap_supplies


def find_cheapest_solution(low: np.ndarray, upp: np.ndarray, prices: np.ndarray, total: float) -> np.ndarray:
    """
    Find `sol` vector such that
     bounds.lb <= sol <= bounds.ub,
     sol.sum() == total,
     price of sol (~ np.dot(sol, prices)) is minimal
    """
    res = linprog(
        prices,
        bounds=list(zip(low, upp)),
        A_eq=np.array([np.ones_like(upp)]),
        b_eq=np.array([total]),
        # options={"disp": True},
        method="highs",
    )

    if res.success:
        return res.x

    raise ScrapPurchaseOptimizationError(res)


def find_optimal_purchase(offers: ScrapOfferData, total_scrap_weight: float) -> Dict[str, float]:
    low = np.zeros(len(offers))
    upp = np.array([convert_tons_to_kilograms(offer.weight) for offer in offers])  # type: ignore

    prices = np.array([offer.purchase_price / 1000 for offer in offers])

    solution = find_cheapest_solution(low, upp, prices, total_scrap_weight)

    return dict(zip([offer.uuid for offer in offers], solution))


# TODO simplify inputs
def calculate_recommendations(
    input_data: ScrapPurchaseOptimizationInput,
) -> Tuple[Dict[str, float], Tuple[str, ...]]:
    needed_scrap, infeasible_constraint_names = estimate_needed_scrap(input_data)
    log.info(
        "Estimated needed scrap derived from production plan"
        f" - total {sum(needed_scrap.values())}:\n{omit_zeros(needed_scrap)}"
    )

    # collect scrap that we already have and remove it from (corrected) needed scrap
    scrap_supplies = calculate_scrap_supplies(input_data)
    log.info(
        f"Available scrap supplies - total {sum(scrap_supplies.values())}:\n{omit_zeros(scrap_supplies)}"
    )

    scrap_to_buy = {}
    for scrap_type in needed_scrap:
        scrap_to_buy[scrap_type] = needed_scrap[scrap_type] - scrap_supplies.get(scrap_type, 0)
    log.info(f"Scrap to buy - total {sum(scrap_to_buy.values())}:\n{omit_zeros(scrap_to_buy)}")

    recommendations = {}

    for scrap_type, total_weight in scrap_to_buy.items():
        if total_weight <= 0:
            continue

        relevant_offers = tuple(
            offer for offer in input_data.available_offers if offer.scrap_type == scrap_type
        )
        if not relevant_offers:
            # TODO either remove or update exception
            raise Exception(
                "It should not be possible, but there are no relevant offers"
                f" for optimization with input data {input_data}. Very likely there is a bug."
            )

        weight_to_buy = find_optimal_purchase(relevant_offers, total_weight)
        log.info(
            f"{scrap_type} - recommended offers are "
            f"- total {sum(weight_to_buy.values())}:\n{omit_zeros(weight_to_buy)}"
        )

        # convert recommended weight to "recommendation ratio"
        for offer in relevant_offers:
            try:
                weight_in_kg = convert_tons_to_kilograms(offer.weight)  # type: ignore
                recommendations[offer.uuid] = get_recommendation(weight_in_kg, weight_to_buy[offer.uuid])
            except ValueError:
                # TODO this happens when offer.weight == 0, so we should probably omit such offers
                recommendations[offer.uuid] = 0

    return recommendations, infeasible_constraint_names


def calculate_buy_all_recommendations(available_offers: ScrapOfferData) -> Dict[str, float]:
    return {offer.uuid: 1 for offer in available_offers}


def get_recommendation(weight: float, weight_to_buy: float) -> float:
    return weight_to_buy / weight


def get_remainder_recommendation(
    remainder_weight: float, original_weight: float, original_recommendation: float
) -> float:
    """Derived from `get_recommendation` function"""
    if remainder_weight <= 0:
        return 0

    return max(1 - (1 - original_recommendation) * original_weight / remainder_weight, 0)
