import math
from typing import Callable, Collection

import numpy as np
from pandera.typing import DataFrame

from scrap.scrap_purchase.constraints import (
    ScrapData,
    LIGHT_MELTABILITY_CONSTRAINT,
    HARD_MELTABILITY_CONSTRAINT,
)
from scrap.scrap_purchase.utils import calc_scrap_yield_vector, calc_minimal_total_steel_weight_from_scrap
from scrap_core import SUPPORTED_CHEMS
from scrap_core.utils import convert_kilograms_to_tons


def argmax(f: Callable[[float], float], y: float, low: float, upp: float, tol: float) -> float:
    """
    Return maximal `x` between `low` and `upp` such that `0 <= f(x) <= y`.
    Function `f` must be continuous and increasing with respect to `x` in order to get expected result.
    """
    if not (f(low) <= y <= f(upp)):
        raise ValueError(
            f"Incompatible inputs low = {low}, upp = {upp}, y = {y} and f = {f}, "
            f"expected `f(low) <= y <= f(upp)`, got f(low) = {f(low)} and f(upp) = {f(upp)}"
        )

    mid = (low + upp) / 2

    while upp - low >= tol:

        if f(mid) <= y:
            low = mid
        else:
            upp = mid

        mid = (low + upp) / 2

    return mid - tol / 2 if f(mid) > y else mid


def approx_expected_steel_production_max(
    df_scrap: DataFrame[ScrapData], scrap_stock_objective_in_kgs: int, mean_scrap_ratio: float
) -> float:
    available_scrap_vector = np.array(df_scrap[ScrapData.weight])
    coefficients = calc_scrap_yield_vector(df_scrap[ScrapData.scrap_type])

    result = argmax(
        f=lambda x: calc_minimal_total_steel_weight_from_scrap(
            x, scrap_stock_objective_in_kgs, mean_scrap_ratio
        ),
        y=np.dot(coefficients, available_scrap_vector),
        low=1,  # due to division by 0 we start with 1
        upp=10**9,
        tol=1,
    )
    return result


def approx_scrap_stock_objective_max(
    df_scrap: DataFrame[ScrapData], expected_steel_production: int, mean_scrap_ratio: float
) -> float:
    available_scrap_vector = np.array(df_scrap[ScrapData.weight])
    coefficients = calc_scrap_yield_vector(df_scrap[ScrapData.scrap_type])

    return argmax(
        f=lambda x: calc_minimal_total_steel_weight_from_scrap(
            expected_steel_production, x, mean_scrap_ratio
        ),
        y=np.dot(coefficients, available_scrap_vector),
        low=1,  # due to division by 0 we start with 1
        upp=10**8,
        tol=1,
    )


def approx_missing_available_scrap(
    df_scrap: DataFrame[ScrapData],
    expected_steel_production: int,
    scrap_stock_objective_in_kgs: int,
    mean_scrap_ratio: float,
) -> float:
    minimal_steel_weight_from_scrap = calc_minimal_total_steel_weight_from_scrap(
        expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )
    scrap_yield_vector = calc_scrap_yield_vector(df_scrap[ScrapData.scrap_type])

    return (
        minimal_steel_weight_from_scrap - np.dot(scrap_yield_vector, df_scrap[ScrapData.weight])
    ) / scrap_yield_vector.mean()


def get_not_enough_scrap_warning(
    df_scrap: DataFrame[ScrapData],
    expected_steel_production: int,
    scrap_stock_objective_in_kgs: int,
    mean_scrap_ratio: float,
) -> str:
    def convert_and_round(value: float) -> int:
        return math.ceil(convert_kilograms_to_tons(value) / 100) * 100

    scrap_stock_objective_max = approx_scrap_stock_objective_max(
        df_scrap, expected_steel_production, mean_scrap_ratio
    )

    expected_steel_production_max = approx_expected_steel_production_max(
        df_scrap, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )

    missing_scrap_weight = approx_missing_available_scrap(
        df_scrap, expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )

    return (
        f"Pre danú očakávanú výrobu ocele {convert_and_round(expected_steel_production)} ton a plánovanú cieľovú "
        f"zásobu šrotu {convert_and_round(scrap_stock_objective_in_kgs)} ton nemáte dostatok šrotu. Preto model "
        "odporúča nakúpiť VŠETOK DOSTUPNÝ ŠROT. Aby mohla optimalizácia prebehnúť štandardným spôsobom pridajte "
        f"aspoň {convert_and_round(missing_scrap_weight)} ton šrotu medzi dostupné ponuky, alebo znížte očakávanú "
        f"výrobu ocele na {convert_and_round(expected_steel_production_max)} ton, alebo znížte plánovanú cieľovú "
        f"zásobu šrotu na {convert_and_round(scrap_stock_objective_max)} ton."
    )


def get_infeasible_constraints_warning(infeasible_constraint_names: Collection[str]):
    warning_suffix = (
        "optimalizácia prebehla v relaxovanom režime. Aby mohla optimalizácia prebehnúť "
        "štandardným spôsobom rozšírte ponuku dostupného šrotu alebo upravte vstupy."
    )

    if set(SUPPORTED_CHEMS) & set(infeasible_constraint_names):
        return "Nedostatok kvalitného šrotu s nízkym obsahom stopových prvkov, " + warning_suffix

    if LIGHT_MELTABILITY_CONSTRAINT in infeasible_constraint_names:
        return "Nedostatok ľahko taviteľného šrotu, " + warning_suffix

    if HARD_MELTABILITY_CONSTRAINT in infeasible_constraint_names:
        return "Nedostatok ťažko taviteľného šrotu, " + warning_suffix

    return "Ak vidíte toto varovanie, kontaktujte prosím IT."
