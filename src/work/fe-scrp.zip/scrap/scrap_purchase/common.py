from typing import Collection, Tuple

import numpy as np
from scipy.optimize import linprog, OptimizeResult

from scrap_core.optimization.linprog_optimizer import join_constraints, Constraint


class ScrapPurchaseOptimizationError(Exception):
    pass


class ScrapPurchaseRelaxationError(Exception):
    pass


def find_solution(
    price_vector: np.ndarray, bounds: Collection[Tuple[float, float]], constraints: Collection[Constraint]
) -> OptimizeResult:

    lt_constraints = join_constraints(constraints)

    res = linprog(
        price_vector,
        bounds=bounds,
        A_ub=lt_constraints.coef_matrix,
        b_ub=lt_constraints.values_vector,
        method="highs",
    )

    return res
