import logging
from datetime import date
from typing import Dict

import numpy as np
from immutables import Map
import pandera as pa
from pandera.typing import DataFrame, Series
from usskssgrades import Grade
from usskssgrades.steel_grades_common import ChemLimitsError

from scrap.dash.database_api import steel_grades
from scrap.models import ProductionPlanData, calc_scrap_stock_objective_correction, MEAN_SCRAP_YIELD
from scrap_core import Chem, ScrapType, SUPPORTED_SCRAP_TYPES_AS_MIXES
from scrap_core.datamodel import RawFeChem
from scrap_core.optimization import ModelSettings
from scrap_core.optimization.datamodel import HeatInputs
from scrap_core.optimization.linprog_optimizer import get_unit_chem_weights
from scrap_core.utils import steel_to_scrap, steel_to_heat
from scrap_core.yieldmodel import SCRAP_TYPE_YIELDS_V2, PIG_IRON_YIELD_V2


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# The most common grade between 2018-01-01 and 2021-09-22
MOST_COMMON_GRADE_ID = 684


class ScrapData(pa.SchemaModel):
    scrap_type: Series[str]
    weight: Series[int]
    price: Series[float]


def calc_scrap_yield_vector(scrap_type_vector: Series[str]) -> np.ndarray:
    return np.array(scrap_type_vector.apply(SCRAP_TYPE_YIELDS_V2.get).fillna(0))


def calc_price_vector(df_scrap: DataFrame[ScrapData]) -> np.ndarray:
    return np.array(df_scrap[ScrapData.price]) / calc_scrap_yield_vector(df_scrap[ScrapData.scrap_type])


def calc_minimal_total_steel_weight_from_scrap(
    expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
) -> float:
    scrap_stock_objective_correction = calc_scrap_stock_objective_correction(
        expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
    )

    corrected_steel_production = expected_steel_production * scrap_stock_objective_correction

    # To calculate lower bound for steel from scrap we use scrap yield == 1,
    # thus steel in scrap weight == scrap weight.
    minimal_total_steel_weight_from_scrap = steel_to_scrap(
        steel_weight=corrected_steel_production,
        pig_iron_yield=PIG_IRON_YIELD_V2,
        scrap_yield=1,
        scrap_ratio=mean_scrap_ratio,
    )
    return minimal_total_steel_weight_from_scrap


def get_pig_iron_chem_ratio_for_grade(chem: Chem, grade: Grade) -> float:
    if chem.title() == "S":
        return grade.desulf_s

    return RawFeChem().get_chem(chem)


def get_max_chem_weight_in_scrap(
    chem: Chem, production_plan: ProductionPlanData, mean_scrap_ratio: float
) -> float:
    max_chem_w: float = 0

    for item in production_plan:
        target_steel_w = item.scrap_amount
        heat_w = steel_to_heat(target_steel_w, PIG_IRON_YIELD_V2, MEAN_SCRAP_YIELD, mean_scrap_ratio)
        try:
            grade = steel_grades.get_grade_from_id(item.grade_id, date.today())
        except (ChemLimitsError, KeyError):
            grade = steel_grades.get_grade_from_id(MOST_COMMON_GRADE_ID, date.today())

        if grade.get_limit(chem) is None:
            msg = (
                f"Unsupported chem - grade with ID {grade.grade_id}"
                f" does not have limit for '{chem}' specified"
            )
            log.error(msg)
            raise ValueError(msg)

        chem_in_steel_w = target_steel_w * grade.get_limit(chem).maximum / 100  # type: ignore
        chem_in_pig_iron_w = (
            get_pig_iron_chem_ratio_for_grade(chem, grade) / 100 * heat_w * (1 - mean_scrap_ratio)
        )

        max_chem_w += chem_in_steel_w - chem_in_pig_iron_w

    return max_chem_w


def get_scrap_unit_chem_weight(model_settings: ModelSettings) -> Dict[Chem, Dict[ScrapType, float]]:
    """Value unit_chem_weight["S"]["HS"] is weight of sulphur in 1 kg of HS scrap."""
    heat = HeatInputs(
        grade_planned=steel_grades.get_grade_from_id(MOST_COMMON_GRADE_ID, date.today()),
        total_scrap_weight=38000,
        pig_iron_weight=155000,
        pig_iron_chem=RawFeChem(),
        lower_bounds=Map({}),
        upper_bounds=Map({}),
    )

    unit_chem_weight = get_unit_chem_weights(model_settings, heat, SUPPORTED_SCRAP_TYPES_AS_MIXES)
    return unit_chem_weight  # type: ignore
