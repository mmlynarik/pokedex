from ast import literal_eval
from datetime import datetime

import pandas as pd
import pytz
import xlsxwriter
from scrap_core import TMS_ID_REVERSE_MAPPING

from .config import (
    SCER_HEADER_FORMAT,
    SCER_EN_TO_SK_COLUMN_MAP,
    SCER_COLUMN_DESCRIPTION_MAP,
    SCER_COLUMN_ORDER,
)


TZ_CENTRAL_EUROPE = pytz.timezone("Europe/Bratislava")


def format_df_for_excel(data: pd.DataFrame) -> pd.DataFrame:
    data["Yield"] = data.Yields
    data["Lower"] = (data.Yields - (2 * data.Stds)).clip(lower=0.0, upper=1.0)
    data["Upper"] = (data.Yields + (2 * data.Stds)).clip(lower=0.0, upper=1.0)
    data["Heat count with scrap"] = data.Counts
    data["TMS ID"] = [int(TMS_ID_REVERSE_MAPPING.get(x, -1)) for x in data.index]
    data = data.drop(["Yields", "Stds", "Counts"], axis=1)
    return data


def format_graph_data(
    data: pd.DataFrame, window_size: int, data_from: datetime, data_to: datetime
) -> pd.DataFrame:
    # Due to serialization, index is changed to str, we need literal_eval to get to values
    tmp = [literal_eval(x) for x in data.index]
    data["Month"] = [x[0] for x in tmp]
    data["Year"] = [x[1] for x in tmp]
    data["scrap"] = [x[2] for x in tmp]
    data = data.set_index("scrap")

    data["Data from"] = data.apply(lambda row: datetime(int(row["Year"]), int(row["Month"]), 1), axis=1)

    data["Data to"] = data["Data from"] + pd.DateOffset(months=window_size) - pd.DateOffset(days=1)

    first_month = (data["Data from"].dt.year == data_from.year) & (
        data["Data from"].dt.month == data_from.month
    )
    data.loc[first_month, "Data from"] = data.loc[first_month, "Data from"].apply(
        lambda dt: dt.replace(day=data_from.day)
    )

    last_month = (data["Data to"].dt.year == data_to.year) & (data["Data to"].dt.month == data_to.month)
    data.loc[last_month, "Data to"] = data.loc[last_month, "Data to"].apply(
        lambda dt: dt.replace(day=data_to.day)
    )

    data["Data from"] = data["Data from"].dt.strftime("%d-%m-%Y")
    data["Data to"] = data["Data to"].dt.strftime("%d-%m-%Y")
    data.index.name = None
    return data


def format_average_graph_data(
    data: pd.DataFrame, window_size: int, data_from: datetime, data_to: datetime
) -> pd.DataFrame:
    data["Error"] = data["std"] * 2
    data["Error_OC1"] = data["std_oc1"] * 2
    data["Error_OC2"] = data["std_oc2"] * 2

    data["Min_estimate"] = (data["mean"] - data["Error"]).clip(lower=0.0, upper=1.0)
    data["Max_estimate"] = (data["mean"] + data["Error"]).clip(lower=0.0, upper=1.0)

    data["Min_estimate_OC1"] = (data["mean_oc1"] - data["Error_OC1"]).clip(lower=0.0, upper=1.0)
    data["Max_estimate_OC1"] = (data["mean_oc1"] + data["Error_OC1"]).clip(lower=0.0, upper=1.0)

    data["Min_estimate_OC2"] = (data["mean_oc2"] - data["Error_OC2"]).clip(lower=0.0, upper=1.0)
    data["Max_estimate_OC2"] = (data["mean_oc2"] + data["Error_OC2"]).clip(lower=0.0, upper=1.0)

    data = data.drop(["std"], axis=1)
    data = data.drop(["std_oc1"], axis=1)
    data = data.drop(["std_oc2"], axis=1)

    data.index = [literal_eval(x) for x in data.index]
    data = data.reset_index().rename(columns={"index": "Data from"})

    data["Data from"] = data["Data from"].apply(lambda row: datetime(row[1], row[0], 1))
    data["Data to"] = data["Data from"] + pd.DateOffset(months=window_size) - pd.DateOffset(days=1)

    data["Data from"].iloc[0] = data["Data from"].iloc[0].replace(day=data_from.day)
    data["Data to"].iloc[-1] = data["Data to"].iloc[-1].replace(day=data_to.day)

    data["Data from"] = data["Data from"].dt.strftime("%d-%m-%Y")
    data["Data to"] = data["Data to"].dt.strftime("%d-%m-%Y")
    data = data.set_index("Data from")
    data = data.rename(columns={"mean": "Mean"})
    data = data.rename(columns={"mean_oc1": "Mean_OC1"})
    data = data.rename(columns={"mean_oc2": "Mean_OC2"})

    data = data[
        [
            "Data to",
            "Mean",
            "Error",
            "Min_estimate",
            "Max_estimate",
            "Mean_OC1",
            "Error_OC1",
            "Min_estimate_OC1",
            "Max_estimate_OC1",
            "Mean_OC2",
            "Error_OC2",
            "Min_estimate_OC2",
            "Max_estimate_OC2",
        ]
    ]
    return data


def format_evaluation_df_for_excel(data: pd.DataFrame) -> pd.DataFrame:
    # sort data so that the newest heats (with the highest ids) are at the top
    data = data.sort_values("scrap_charge_id", ascending=False)[SCER_COLUMN_ORDER]
    # convert datetimes to CET and remove timezone, as excel does not support datetimes with timezones
    data["heat_date"] = data["heat_date"].dt.tz_convert("Europe/Bratislava").dt.tz_localize(None)
    data["last_update"] = data["last_update"].dt.tz_convert("Europe/Bratislava").dt.tz_localize(None)
    return data.rename(columns=SCER_EN_TO_SK_COLUMN_MAP)


def get_closed_heats_explanations_df_for_excel() -> pd.DataFrame:
    data = pd.DataFrame(
        [(SCER_EN_TO_SK_COLUMN_MAP[col], SCER_COLUMN_DESCRIPTION_MAP[col]) for col in SCER_COLUMN_ORDER],
        columns=["Stĺpec", "Vysvetlenie"],
    )

    return data


def generate_export_name_for_loading_station(loading_station_name: str, page_id: str) -> str:
    export_name = "attachment; filename="
    export_name += f'{loading_station_name.replace(" ", "_")}'
    export_name += f"_uzavrete_tavby_{datetime.now(TZ_CENTRAL_EUROPE):%Y%m%d_%H%M}_{page_id}.xlsx"
    return export_name


def add_styling_to_evaluation_table(writer: xlsxwriter, data: pd.DataFrame) -> None:
    workbook = writer.book
    worksheet = writer.sheets["Vyhodnotenie uzavretých tavieb"]

    header_format = workbook.add_format(SCER_HEADER_FORMAT)
    true_format = workbook.add_format({"bold": True, "font_color": "green"})
    false_format = workbook.add_format({"bold": True, "font_color": "red"})

    for val in ("true", "false"):
        worksheet.conditional_format(
            1,  # start_row
            0,  # start_col
            len(data),  # end_row
            len(SCER_COLUMN_ORDER),  # end_col
            {
                "type": "cell",
                "criteria": "equal to",
                "value": val.upper(),
                "format": true_format if val == "true" else false_format,
            },
        )

    for col_num, value in enumerate(data.columns.values):
        worksheet.write(0, col_num, value, header_format)
