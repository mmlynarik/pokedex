from datetime import datetime, date
import logging

import pandas as pd
from django.http import HttpResponse

from scrap_core.utils import create_empty_dataframe

from . import TZ_CENTRAL_EUROPE
from ..models import ScrapPurchaseRecord


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def realized_offers_to_dataframe(scrap_purchase_record: ScrapPurchaseRecord) -> pd.DataFrame:
    base_columns = ["scrap_type", "zone", "weight", "supplier", "price", "note"]

    if scrap_purchase_record.current_data.realized_scrap_offer_data:
        df_realized_offers = pd.DataFrame(
            (offer.to_dict() for offer in scrap_purchase_record.current_data.realized_scrap_offer_data)
        ).drop(columns="scrap_offer_uuid_list")

        df_realized_offers = df_realized_offers[base_columns]

        df_realized_offers["total_price"] = df_realized_offers["weight"] * df_realized_offers["price"]
    else:
        df_realized_offers = create_empty_dataframe(base_columns + ["total_price"])

    df_realized_offers = df_realized_offers.rename(
        columns={
            "scrap_type": "Typ šrotu",
            "zone": "Zóna",
            "weight": "Objem",
            "supplier": "Dodávateľ",
            "price": "Realizovaná cena",
            "total_price": "Celková cena",
            "note": "Poznámka",
        }
    )

    return df_realized_offers


def realized_offers_export_name(scrap_purchase_record_name: str) -> str:
    filename = f'{scrap_purchase_record_name.replace(" ", "_")}_realizovane_ponuky'
    timestamp = f"{datetime.now(TZ_CENTRAL_EUROPE):%Y%m%d_%H%M}.xlsx"
    return f"attachment; filename={filename}_{timestamp}.xlsx"


def realized_offers_dataframe_to_response(
    df_realized_offers: pd.DataFrame, purchase_record_name: str, purchase_record_date: date
) -> HttpResponse:
    response = HttpResponse(content_type="application/ms-excel")
    response["Content-Disposition"] = realized_offers_export_name(purchase_record_name)

    with pd.ExcelWriter(  # pylint: disable=abstract-class-instantiated
        response, engine="xlsxwriter"
    ) as writer:
        df_realized_offers.to_excel(writer, f"Realizované ponuky - {purchase_record_date}", index=False)

    return response
