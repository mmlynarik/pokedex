from django.core.management.base import BaseCommand, CommandParser
from ...imports import parse_scrap_purchase_history_excel_file
from ...models import ScrapPurchase
import os
import io


class Command(BaseCommand):
    help = "Import scrap purchase history from excel file"

    def add_arguments(self, parser: CommandParser) -> None:
        parser.add_argument("path_to_file", type=str, help="Path to excel file with scrap purchase data")
        parser.add_argument("-d", "--delete", action="store_true", help="!!!DELETE ALL RECORDS FROM DB!!!")

    def handle(self, *args, **options):
        delete = options["delete"]
        if delete:
            confirmation = input("Are you sure you want to delete all scrap purchase records? y/n ")
            while len(confirmation) < 1 or confirmation[0].lower() not in "yn":
                confirmation = input("y/n?: ")
            if confirmation[0].lower() == "y":
                ScrapPurchase.objects.all().delete()
            return

        path_to_file = options["path_to_file"]
        if not path_to_file:
            print("Add path to excel file with data\n")
            return

        if not os.path.isfile(path_to_file):
            print("File not found\n")
            return

        print("Starting importing scrap purchase data...\n")
        file_handle = io.open(path_to_file, mode="rb")
        bytes_file_data = io.BytesIO(file_handle.read())
        parsed_scrap_purchase_tuple = parse_scrap_purchase_history_excel_file(bytes_file_data)
        try:
            ScrapPurchase.objects.bulk_create(parsed_scrap_purchase_tuple)
        except Exception:  # pylint: disable=broad-except
            print("Error while writing to DB.\n")
        print("...finished.\n")
