import logging

from django.core.management import BaseCommand

from scrap.data_migrations import copy_scrap_charge_optimizations_data


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class Command(BaseCommand):
    help = (
        "Copy data from (obsolete) ScrapCharge.optimizations attribute "
        "to corresponding MultiHeatOptimizationResult objects"
    )

    def handle(self, *args, **options):
        log.info("Command 'cpoptdata' calls dramatiq to copy optimizations data")
        copy_scrap_charge_optimizations_data.send()
