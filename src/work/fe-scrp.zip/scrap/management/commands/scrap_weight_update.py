import logging
from time import sleep
from typing import Dict, Union

import attrs
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.conf import settings
from django.core.management.base import BaseCommand, CommandParser
from redis import Redis

from scalecore.processor import UpdateAction
from scrap.consumers.actual_weight import ActualScaleDataConsumer
from scrap.models.various_models import ScaleCurrentState
from scrap.scales import scale_processors
from scrap.scales.weighting_backend import apply_action_with_db_lock
from scrap.weighting import WEIGHTING_BACKENDS, get_message_processor, MESSAGING_PROCESSORS

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


WEIGHTING_SLEEP_SEC = 1.5
OUT_OF_WEIGHTING_SLEEP_SEC = 3.0

SerializedData = Dict[str, Union[str, int]]


def call_update_action(scale_id: str, mp_version: int = 1) -> None:
    backend = WEIGHTING_BACKENDS[scale_id]

    if mp_version == 2:
        messaging_processor = get_message_processor(scale_id)
    else:
        messaging_processor = MESSAGING_PROCESSORS[scale_id]

    apply_action_with_db_lock(backend, UpdateAction(), messaging_processor)


def get_state_machine_current_state(scale_id: str) -> ScaleCurrentState:
    return ScaleCurrentState.objects.get(scale_id=scale_id)


def send_current_state_to_client(group_name: str, data_to_send: SerializedData) -> None:
    if not data_to_send:
        return

    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(group_name, {"type": "actual.data", **data_to_send})


def get_timeout_duration(scale_state: ScaleCurrentState) -> float:
    return (
        WEIGHTING_SLEEP_SEC
        if scale_state.state == ScaleCurrentState.ScaleState.WEIGHTING
        else OUT_OF_WEIGHTING_SLEEP_SEC
    )


class Command(BaseCommand):
    def add_arguments(self, parser: CommandParser) -> None:
        scale_ids = [
            settings.SCALE_SS1_V1,
            settings.SCALE_SS1_V2,
            settings.SCALE_SS2_V8,
            settings.SCALE_SS2_V9,
        ]
        parser.add_argument(
            "scale_id", type=str, choices=scale_ids, help="Scale id -> same as scale key in ingest"
        )
        parser.add_argument(
            "--mp_version",
            type=int,
            choices=[1, 2],
            default=1,
            required=False,
            help="Message processor mapping version",
        )

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.redis = Redis.from_url(settings.REDIS_URL)

    def handle(self, *args, **options):
        scale_id = options["scale_id"]
        mp_version = options["mp_version"]

        logger.info(f"Command `scrap_weight_update` with arguments {options} is running ...")

        scale_processor = scale_processors[scale_id]
        websocket_group_name = ActualScaleDataConsumer.GROUP_NAME.format(scale_id=scale_id)

        while True:
            state = get_state_machine_current_state(scale_id)

            if state.state != ScaleCurrentState.ScaleState.STOPPED_WEIGHTING:
                logger.info(f"Calling update action on state {state} ...")
                call_update_action(scale_id, mp_version)

            is_operational = scale_processor.is_operational
            status = scale_processor.get_scale_status()

            scale_info = {"is_operational": is_operational, **attrs.asdict(status)}

            send_current_state_to_client(websocket_group_name, scale_info)
            logger.info(f"Send current scale data to client: {scale_info}")

            sleep_for_sec = get_timeout_duration(state)
            sleep(sleep_for_sec)
