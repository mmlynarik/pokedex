import datetime
import re
from warnings import warn

from django.conf import settings
import logging
from datetime import date
from http import HTTPStatus
from typing import Any, Dict, Sequence

import pandas as pd
import pytz
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.generic import FormView, ListView, View
from django_dramatiq.tasks import delete_old_tasks as delete_old_dramatiq_tasks
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from returns.pipeline import is_successful
from returns.result import Failure, Result, Success
from scrap_core.datamodel.oko import load_heat_from_oko
from scrap_core.optimization.datamodel import MultipleHeatsOptimizationOutput
from scrap.dash.create_scrap_purchase import CREATE_SCRAP_PURCHASE_APP

from scrap.models import MultipleHeatsOptimizationResult

from .api import (
    get_errors_from_validation_results,
    get_expected_risk_summary,
    get_multiple_heats_optimization_input_from_req,
    get_warnings_from_validation_results,
    has_valid_charges,
    optimize_multiple_heats_api,
    validate_all_charges_info,
)

# type: ignore # pylint: disable=unused-import
from .dash.calculate import ScrapBlendModelInitialData
from .dash.database_api import get_oko_db, steel_grades
from .dash.loaded_basket_app import (
    loaded_basket_compatibility_app,
)  # type: ignore # pylint: disable=unused-import
from .dash.scrap_loading_station import scrap_loading_station_app
from .dash.scrap_loading_station_2 import (
    loading_scrap_station_app_2,
)  # type: ignore # pylint: disable=unused-import
from .dash.scrap_purchase import (  # type: ignore # pylint: disable=unused-import
    scrap_purchase_app,
    scrap_purchase_input_data_app,
    scrap_purchase_read_only_app,
)
from .dash.scrap_purchase_app import SCRAP_PURCHASE_APP
from .dash.settings_app import NAME_APP as SCRAP_SETTINGS_APP_NAME
from .dash.yieldmodel import YieldModelData
from .exports import (
    add_styling_to_evaluation_table,
    format_average_graph_data,
    format_df_for_excel,
    format_evaluation_df_for_excel,
    format_graph_data,
    generate_export_name_for_loading_station,
    get_closed_heats_explanations_df_for_excel,
)
from .exports.realized_offers import realized_offers_dataframe_to_response, realized_offers_to_dataframe
from .forms import GoToHeatFromOkoForm, SavedYieldModels
from .models import ClosedHeatEvaluationV2, LoadingStation, ScrapPurchaseRecord, YieldCalculationModelResult
from .serializers import MultipleHeatsOptimizationInputSerializer
from .tasks import calculate_scrap_charge_evaluations, refresh_automatic_grade_groups, yield_calculation

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


DEFAULT_EXPORT_HEAT_COUNT = 2000

PATH_MESSAGES = "scrap/messages.html"

YIELD_CALC_VERSION = 2  # 18.11.2021 changed calculation


def process_oko_heat_redirect(request):
    form = GoToHeatFromOkoForm(request.POST)
    if form.is_valid():
        params = {
            "year": form.cleaned_data["year"],
            "entity_id": form.cleaned_data["entity_id"],
            "entity_type": form.cleaned_data["entity_type"],
        }
        loading_station_id = request.resolver_match.kwargs.get("loading_station_id", None)
        if loading_station_id is not None:
            params["loading_station_id"] = loading_station_id
        return redirect("scrap:calculateoko", **params)
    return None


@login_required
def calculate(request, loading_station_id: int = None):
    if request.method == "POST":
        processed = process_oko_heat_redirect(request)
        if processed:
            return processed

    initial_data = ScrapBlendModelInitialData(None, None, loading_station_id)
    return render(
        request,
        "scrap/calculate_scrap.html",
        {"data": initial_data.to_context_data(), "form": GoToHeatFromOkoForm()},
    )


@login_required
def show_heat(request, year: int, entity_id: int, entity_type: str, loading_station_id: int = None):
    if request.method == "POST":
        processed = process_oko_heat_redirect(request)
        if processed:
            return processed

    initial_data = ScrapBlendModelInitialData(None, None, loading_station_id)
    if entity_type == "heat_id":
        heat, _ = load_heat_from_oko(year, entity_id, get_oko_db(), steel_grades, False)
        if heat is not None:
            heat = heat.disable_on_access_validation()
            initial_data = ScrapBlendModelInitialData(heat, None, loading_station_id)
    elif entity_type == "evaluation_id":
        evaluation = ClosedHeatEvaluationV2.objects.filter(pk=entity_id).first()
        if evaluation is not None:
            initial_data = ScrapBlendModelInitialData(None, entity_id, loading_station_id)

    return render(
        request,
        "scrap/calculate_scrap.html",
        {
            "data": initial_data.to_context_data(),
            "form": GoToHeatFromOkoForm(
                initial={"year": year, "entity_id": entity_id, "entity_type": entity_type}
            ),
        },
    )


@login_required
def yield_calculation_status(request, yield_calculation_id: int):
    data = get_object_or_404(YieldCalculationModelResult, pk=yield_calculation_id)
    status_data = {"status": data.status, "progress": data.progress}
    return JsonResponse(status_data)


@method_decorator(login_required, name="dispatch")
class YieldModelResultList(ListView):
    model = YieldCalculationModelResult
    paginate_by = 10
    template_name = "scrap/yield_model_calculations.html"

    def get_queryset(self):
        return self.model.objects.all().order_by("-created_at")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["form"] = SavedYieldModels()
        return context


@method_decorator(login_required, name="dispatch")
class YieldModelTaskCreate(FormView):
    model = YieldCalculationModelResult
    form_class = SavedYieldModels
    template_name = "scrap/yield_model_calculations.html"
    success_url = reverse_lazy("scrap:yieldmodel")

    def form_valid(self, form):
        data = YieldCalculationModelResult(  # type: ignore
            progress=0,
            status=YieldCalculationModelResult.ResultStatus.CREATED,
            window_size=form.cleaned_data["window_size"],
            data_from=form.cleaned_data["data_from"],
            data_to=form.cleaned_data["data_to"],
        )
        data.save()
        yield_calculation.send(data.id)
        return super().form_valid(form)


@method_decorator(login_required, name="dispatch")
class YieldModelIndex(View):
    def get(self, request, *args, **kwargs):
        view = YieldModelResultList.as_view()
        return view(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        view = YieldModelTaskCreate.as_view()
        return view(request, *args, **kwargs)


@login_required
def result_detail(request, result_id: int):
    result_data = get_object_or_404(YieldCalculationModelResult, pk=result_id)
    yield_model_data = YieldModelData(
        result_data.comparison_graph_data,
        result_data.graph_data,
        result_data.window_size,
        result_data.average_graph_data,
        result_data.frontend_warnings,
    )
    return render(request, "scrap/results.html", {"data": yield_model_data.to_context_data()})


@login_required
def result_export(request, result_id: int):
    result_data = get_object_or_404(YieldCalculationModelResult, pk=result_id)
    response = HttpResponse(content_type="application/ms-excel")
    export_name = f'attachment; filename="YieldModel_{result_data.data_from.strftime("%Y%m%d")}'
    export_name += f'_{result_data.data_to.strftime("%Y%m%d")}'
    export_name += f"_win-size-{result_data.window_size}_v{YIELD_CALC_VERSION}.xlsx"
    response["Content-Disposition"] = export_name

    df_comparison = format_df_for_excel(result_data.comparison_graph_data)
    df_comparison = df_comparison[["TMS ID", "Upper", "Lower", "Yield", "Heat count with scrap"]]

    df_graph = result_data.graph_data
    df_graph = format_graph_data(
        df_graph, result_data.window_size, result_data.data_from, result_data.data_to
    )
    df_graph = format_df_for_excel(df_graph)
    df_graph = df_graph[
        ["Data from", "Data to", "TMS ID", "Upper", "Lower", "Yield", "Heat count with scrap"]
    ]

    df_weighted = format_average_graph_data(
        result_data.average_graph_data,
        result_data.window_size,
        result_data.data_from,
        result_data.data_to,
    )

    with pd.ExcelWriter(  # pylint: disable=abstract-class-instantiated
        response, engine="xlsxwriter"
    ) as writer:
        df_comparison.to_excel(writer, "Výťažky šrotov")
        df_weighted.to_excel(writer, "Vážený priemer výťažkov šrotov")
        df_graph.to_excel(writer, "Model výťažku šrotov")
    return response


### Scrap Loading station
@login_required
def choose_loading_station(request):
    loading_stations = LoadingStation.objects.all()
    return render(request, "scrap/choose_loading_station.html", {"loading_stations": loading_stations})


@login_required
def scrap_loading_station_2(request, input_id: int):
    loading_station = get_object_or_404(LoadingStation, pk=input_id)
    read_only = request.user != loading_station.user_in_control

    dash_context = request.session.get("django_plotly_dash", dict())
    dash_context["loading_station_id"] = input_id
    request.session["django_plotly_dash"] = dash_context

    context = {
        "request": request,
        "read_only": read_only,
    }
    return render(request, "scrap/scrap_loading_station_2.html", context)


@login_required
def delete_old_tasks(request, max_task_age: int):
    if max_task_age < 3600:
        message = (
            "As a precaution, it is not possible to remove tasks younger than 3600 seconds. "
            "Please select bigger maximum task age."
        )
        return HttpResponse(message, status=HTTPStatus.FORBIDDEN)

    delete_old_dramatiq_tasks.send(max_task_age)
    message = (
        f"All tasks older than {max_task_age} seconds "
        f"were removed from the table <strong>django_dramatiq_task</strong>"
    )
    return HttpResponse(message, status=HTTPStatus.OK)


@login_required
def scrap_charges_evaluation(request):
    def parse_dt(dt: str) -> datetime.datetime:
        dt_fmt = "%Y-%m-%dT%H:%M:%S" if "T" in dt else "%Y-%m-%d"
        return pytz.utc.localize(datetime.datetime.strptime(dt, dt_fmt))

    context = {"msg": "", "error": ""}

    dt_from_str = request.GET.get("dt_from")
    if dt_from_str is None:
        log.error("Missing 'dt_from' query parameter")
        context["error"] = (
            "Missing 'dt_from' query parameter, "
            "supported format for query parameters is\n"
            "?dt_from=YYYY-MM-DD [ &dt_to=YYYY-MM-DD &force_refresh=true|false ]"
        )

    else:
        try:
            dt_from = parse_dt(dt_from_str)
            log.info(f"Parameter 'dt_from' set to {dt_from}")

            dt_to_str = request.GET.get("dt_to")
            if dt_to_str is not None:
                dt_to = parse_dt(dt_to_str)
                log.info(f"Parameter 'dt_to' set to {dt_to}")

            else:
                dt_to = datetime.datetime.now(tz=pytz.utc)
                log.info(f"Parameter 'dt_to' not set, hence set automatically to {dt_to}")

            force_refresh_str = request.GET.get("force_refresh", "")
            force_refresh = force_refresh_str.lower() == "true"

            context["msg"] = (
                f"Scrap charge evaluation triggered for charges between {dt_from} and {dt_to}"
                + (", with force refresh set" if force_refresh else "")
            )

            calculate_scrap_charge_evaluations.send(dt_from.isoformat(), dt_to.isoformat(), force_refresh)

        except ValueError as e:
            # catch conversion error
            log.exception("Invalid date query parameter")
            context["error"] = str(e)

    return render(request, PATH_MESSAGES, context)


@login_required
def choose_scrap_purchase_record(request):
    if request.method == "POST":
        dash_context = request.session.get("django_plotly_dash", dict())
        request.session["django_plotly_dash"] = dash_context
        return redirect("scrap:create_scrap_purchase")
    scrap_purchase_records = ScrapPurchaseRecord.objects.all().order_by("-purchase_date", "-created_at")
    return render(
        request, "scrap/choose_scrap_purchase_record.html", {"scrap_purchase_records": scrap_purchase_records}
    )


@login_required
def scrap_purchase_record(request, scrap_purchase_record_id: int):
    scrap_purchase_record_obj = get_object_or_404(ScrapPurchaseRecord, pk=scrap_purchase_record_id)
    read_only = request.user != scrap_purchase_record_obj.user_in_control
    if scrap_purchase_record_obj.finished:
        read_only = True

    dash_context = request.session.get("django_plotly_dash", dict())
    dash_context["scrap_purchase_record_id"] = scrap_purchase_record_id
    request.session["django_plotly_dash"] = dash_context

    context = {
        "request": request,
        "title": scrap_purchase_record_obj.name,
        "read_only": read_only,
    }
    return render(request, "scrap/scrap_purchase.html", context)


@login_required
def create_scrap_purchase(request):
    # clear dash_context/session_data to make sure, that `scrap_purchase_record_id` is not present
    request.session["django_plotly_dash"] = {}
    context = {"request": request, "app_name": CREATE_SCRAP_PURCHASE_APP}
    return render(request, "scrap/create_scrap_purchase.html", context)


@login_required
def update_scrap_purchase(request, scrap_purchase_record_id: int):
    _ = get_object_or_404(ScrapPurchaseRecord, pk=scrap_purchase_record_id)
    dash_context = {"scrap_purchase_record_id": scrap_purchase_record_id}
    request.session["django_plotly_dash"] = dash_context
    context = {
        "request": request,
        "app_name": CREATE_SCRAP_PURCHASE_APP,
    }
    return render(request, "scrap/create_scrap_purchase.html", context)


@login_required
def scrap_purchase_record_app(request, scrap_purchase_record_id: int):
    scrap_purchase_record_obj = get_object_or_404(ScrapPurchaseRecord, pk=scrap_purchase_record_id)
    user_in_control_id = scrap_purchase_record_obj.user_in_control.pk
    read_only = scrap_purchase_record_obj.finished or (
        request.user != scrap_purchase_record_obj.user_in_control
    )
    dash_context = request.session.get("django_plotly_dash", dict())
    dash_context["scrap_purchase_record_id"] = scrap_purchase_record_id
    dash_context["purchase_date"] = str(scrap_purchase_record_obj.purchase_date)
    dash_context["user_in_control_id"] = user_in_control_id
    dash_context["scrap_purchase_info"] = (
        f"Nákup šrotu - {scrap_purchase_record_obj.name} - {datetime.datetime.strftime(scrap_purchase_record_obj.purchase_date, '%m.%Y')}"
    )
    request.session["django_plotly_dash"] = dash_context
    context = {"request": request, "app_name": SCRAP_PURCHASE_APP, "read_only": read_only}
    return render(request, "scrap/scrap_purchase_app.html", context)


def loading_station_analysis_to_excel_response(
    analysis: pd.DataFrame, loading_station_name: str, page_id: str
) -> HttpResponse:
    response = HttpResponse(content_type="application/ms-excel")
    response["Content-Disposition"] = generate_export_name_for_loading_station(loading_station_name, page_id)
    with pd.ExcelWriter(  # pylint: disable=abstract-class-instantiated
        response, engine="xlsxwriter"
    ) as writer:
        analysis.to_excel(writer, "Vyhodnotenie uzavretých tavieb", index=False)
        add_styling_to_evaluation_table(writer, analysis)
        get_closed_heats_explanations_df_for_excel().to_excel(writer, "Vysvetlivky", index=False)
    return response


def create_loading_station_analysis_dataframe(
    loading_station_id: int, page_id: str
) -> Result[pd.DataFrame, str]:
    # Store related data (in this case `closed_heat`) in cache.
    # Otherwise iteration over closed heat data (list comprehension `optimization_ids = [...]` below)
    # will produce separate query for each record. To avoid it, we use `prefetch_related("closed_heat")`.
    # See https://docs.djangoproject.com/en/4.0/ref/models/querysets/ for more info.
    try:
        page_id_int = int(page_id)
    except Exception:  # pylint: disable=broad-except
        return Failure(
            f"Pre nakladaciu stanicu s id={loading_station_id} sa nepodarilo vytvorit export.\n"
            + "Pouzite kladne cislo stranky pre najstarsie tavby alebo zaporne pre najnovsie"
        )
    if page_id_int <= 0:
        order_by = "-pk"
    else:
        order_by = "pk"
    evaluations: Sequence[ClosedHeatEvaluationV2] = (
        Paginator(
            ClosedHeatEvaluationV2.objects.filter(scrap_charge__loading_station__pk=loading_station_id)
            .order_by(order_by)
            .all(),
            DEFAULT_EXPORT_HEAT_COUNT,
        )
        .get_page(abs(page_id_int))
        .object_list
    )

    if len(evaluations) == 0:
        return Failure(
            f"Pre nakladaciu stanicu s id={loading_station_id} neboli najdené žiadne uzavreté tavby."
        )

    df_closed_heats = pd.DataFrame(list(evaluations.values()))

    df_closed_heats["basket_ids_app"] = [heat.basket_ids_app for heat in evaluations]
    df_closed_heats["basket_ids"] = [heat.basket_ids_db for heat in evaluations]
    df_closed_heats["switched_basket_ids"] = [heat.switched_basket_ids_app for heat in evaluations]
    df_closed_heats["medium_risk"] = [
        evaluation.expected_risk.bind_optional(lambda risk: risk.medium).value_or(None)
        for evaluation in evaluations
    ]
    df_closed_heats["high_risk"] = [
        evaluation.expected_risk.bind_optional(lambda risk: risk.high).value_or(None)
        for evaluation in evaluations
    ]
    return Success(format_evaluation_df_for_excel(df_closed_heats))


@login_required
def export_loading_station_analysis(request: HttpRequest, loading_station_id: int) -> HttpResponse:
    page_id = request.GET.get("page_id", "-1")

    if not re.match(r"^-?\d+$", page_id):
        return render(
            request,
            PATH_MESSAGES,
            {
                "msg": "Pri exporte vyhodnotenia nakladacej stanice došlo k chybe.",
                "error": f"Neplatný parameter `page_id`, očakávame celé číslo, na vstupe je {page_id}",
            },
        )

    loading_station = get_object_or_404(LoadingStation, pk=loading_station_id)
    log.info("Closed heat evaluation report export started.")

    analysis_df = create_loading_station_analysis_dataframe(loading_station_id, page_id)

    if not is_successful(analysis_df):
        return render(
            request,
            PATH_MESSAGES,
            {
                "msg": "Pri exporte vyhodnotenia nakladacej stanice došlo k chybe.",
                "error": analysis_df.failure(),
            },
        )

    response = loading_station_analysis_to_excel_response(analysis_df.unwrap(), loading_station.name, page_id)
    log.info("Closed heat evaluation report export successful.")
    return response


@login_required
def export_realized_offers_to_excel(request: HttpRequest, scrap_purchase_record_id: int) -> HttpResponse:
    scrap_purchase_record_obj = get_object_or_404(ScrapPurchaseRecord, pk=scrap_purchase_record_id)

    try:
        df_realized_offers = realized_offers_to_dataframe(scrap_purchase_record_obj)

        response = realized_offers_dataframe_to_response(
            df_realized_offers,
            # name or purchase date may not be available during scrap purchase record creation,
            # but it is clear that it makes no sense to export any table of realized offers in this phase
            # so dummy name and purchase date are more than sufficient
            scrap_purchase_record_obj.name or "record_with_no_name",
            scrap_purchase_record_obj.purchase_date or date(1970, 1, 1),
        )
    except Exception as e:
        log.exception(
            f"Scrap purchase record {scrap_purchase_record_obj.pk}: "
            f"realized offers export to excel failed"
        )

        return render(
            request,
            PATH_MESSAGES,
            {
                "msg": "Pri exporte tabuľky uzavretých ponúk došlo k chybe, kontaktujte prosím IT.",
                "error": str(e),
            },
        )

    log.info(
        f"Scrap purchase record {scrap_purchase_record_obj.pk}: "
        f"realized offers export generated successfully"
    )
    return response


@login_required
def scrap_loading_station_settings(request):
    context = {
        "request": request,
        "app_name": SCRAP_SETTINGS_APP_NAME,
    }
    return render(request, "scrap/scrap_loading_station_settings.html", context)


@login_required
def loaded_basket_compatibility(request, loading_station_id: int):
    dash_context = request.session.get("django_plotly_dash", dict())
    dash_context["loading_station_id"] = loading_station_id
    request.session["django_plotly_dash"] = dash_context

    context = {"request": request}
    return render(request, "scrap/loaded_basket_compatibility.html", context)


@api_view(["POST"])
def create_scrap_charge_optimization(request, *args, **kwargs) -> Response:
    """Django REST Framework api view for scrap charge optimization"""
    warn("This view is deprecated", DeprecationWarning, stacklevel=2)
    # Syntactic validation
    input_serializer = MultipleHeatsOptimizationInputSerializer(data=request.data)
    if input_serializer.is_valid(raise_exception=True):
        req = input_serializer.validated_data
        loading_station_id = req["loading_station_id"]
        station = LoadingStation.objects.filter(pk=loading_station_id).first()
        if station is None:
            return Response(
                {"loading_station_id": [f"{loading_station_id=} does not exist."]},
                status.HTTP_400_BAD_REQUEST,
            )
        model_settings = station.model_settings

        # Semantic and pragmatic validation
        validation_results = validate_all_charges_info(
            req,
            model_settings,
            tuple(station.relaxable_lower_summing_limit_settings.all()),
            tuple(station.relaxable_upper_summing_limit_settings.all()),
        )
        if not has_valid_charges(validation_results):
            return Response(
                {
                    "errors": get_errors_from_validation_results(validation_results),
                    "warnings": get_warnings_from_validation_results(validation_results),
                },
                status.HTTP_400_BAD_REQUEST,
            )

        input_data = get_multiple_heats_optimization_input_from_req(req, model_settings)
        result = optimize_multiple_heats_api(input_data)
        return Response(
            {"result_id": result, "warnings": get_warnings_from_validation_results(validation_results)},
            status.HTTP_201_CREATED,
        )


@api_view(["GET"])
def read_scrap_charge_optimization(request, pk: int, *args, **kwargs) -> Response:
    warn("This view is deprecated", DeprecationWarning, stacklevel=2)
    db_result = get_object_or_404(MultipleHeatsOptimizationResult, pk=pk)
    result: MultipleHeatsOptimizationOutput = db_result.result
    if result.error is not None:
        return Response({"error": result.error}, status.HTTP_400_BAD_REQUEST)

    response: Dict[str, Any] = {
        "error": "",
        "expected_risk": get_expected_risk_summary(result),
        "scrap_weights": result.scrap_weights_per_heat,
        "conditioned_scrap_types_group": result.conditioned_scrap_types_group,
    }
    return Response(response, status.HTTP_200_OK)


@login_required
def scrap_loading_station(request, loading_station_id: int) -> HttpResponse:
    loading_station = get_object_or_404(LoadingStation, pk=loading_station_id)
    read_only = request.user != loading_station.user_in_control

    dash_context = request.session.get("django_plotly_dash", dict())
    dash_context["loading_station_id"] = loading_station_id
    dash_context["logged_username"] = request.user.username
    dash_context["read_only"] = read_only
    dash_context["scrap_yard_api"] = loading_station.scrap_yard_api
    dash_context["scale_control"] = loading_station.scale_control
    request.session["django_plotly_dash"] = dash_context

    context = {"request": request, "read_only": read_only, "loading_station_name": loading_station.name}
    return render(request, "scrap/scrap_loading_station.html", context)


@login_required
def refresh_automatic_grade_groups_view(request):
    refresh_automatic_grade_groups.send()
    return HttpResponse("Auto groups are being regenerated", status=HTTPStatus.OK)


def scale_monitor(request, steelshop: int, scale_id: str) -> HttpResponse:
    if steelshop not in settings.STEELSHOPS:
        return Response(
            f"Steelshop {steelshop} not exist",
            status=status.HTTP_400_BAD_REQUEST,
        )

    scale_ids = settings.SCALE_PER_STEELSHOP[steelshop]
    if scale_id not in scale_ids:
        return Response(
            f"Scale id {scale_id} not exist",
            status=status.HTTP_400_BAD_REQUEST,
        )

    context = {
        "steelshop": steelshop,
        "scale_id": scale_id,
        "ws_port": settings.APP_PORT,
        "ws_hostname": settings.APP_HOST,
    }
    return render(request, "scrap/scale_monitor.html", context)
