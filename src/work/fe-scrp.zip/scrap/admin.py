import io
from typing import Any, Dict, Optional, Tuple

from django.contrib import admin, messages
from django.db.models import Model
from django.http import HttpRequest
from django.shortcuts import redirect
from django.template.response import TemplateResponse
from django.urls import path, reverse
from django.utils.html import escape, mark_safe
from simple_history.admin import SimpleHistoryAdmin

from .forms import (
    ExcelUploadForm,
    LoadingStationForm,
    RelaxableLowerSummingLimitSettingForm,
    RelaxableRiskLimitSettingForm,
    RelaxableUpperSummingLimitSettingForm,
    ScrapExclusiveGroupSettingForm,
    ScrapPurchaseRecordForm,
    ScrapSupplierMappingAdminForm,
    WeightedScrapForm,
)
from .imports import parse_scrap_purchase_history_excel_file
from .models import (
    AvailableScrap,
    Basket,
    BasketWaggonWeight,
    ChargeInput,
    ClosedHeatEvaluationV2,
    GradeDefinition,
    GradeGroup,
    LoadingStation,
    LoadingStationDisplayDataV2,
    MultipleHeatsOptimizationResult,
    Operator,
    OptimizationInput,
    PigIronAnalysisResult,
    Printer,
    RelaxableLowerSummingLimitSetting,
    RelaxableRiskLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScaleCurrentState,
    ScrapCharge,
    ScrapDefinition,
    ScrapExclusiveGroupSetting,
    ScrapFacility,
    ScrapGroup,
    ScrapMixDefinition,
    ScrapMixRatio,
    ScrapPurchase,
    ScrapPurchaseOptimizationResult,
    ScrapPurchaseRecord,
    ScrapSupplier,
    ScrapSupplierMapping,
    SupportedScrapTypeMapping,
    WeightedScrap,
    YieldCalculationModelResult,
)

LOAFING_STATION_APP = [
    {"app_name": "loadingscrapstation", "slug": "loading-station"},
    {"app_name": "loadingscrapstationreadonly", "slug": "loading-station-readonly"},
]

STATELESS_APP_VERSION = [
    1,
    2,
]


class AlmightyAdmin(admin.ModelAdmin):
    """With great power comes great responsibility"""

    def has_view_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request):
        return True

    def has_change_permission(self, request, obj=None):
        return True

    def has_delete_permission(self, request, obj=None):
        return True


class ReadAndDeleteAdmin(admin.ModelAdmin):
    def has_view_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return True


class ReadOnlyAdmin(admin.ModelAdmin):
    def has_view_permission(self, request, obj=None):
        return True

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class ClosedHeatEvaluationAdminV2(AlmightyAdmin):
    readonly_fields = ("last_update",)


class SupportedScrapTypeMappingAdmin(AlmightyAdmin):
    list_display = ("scrap_type", "input_scrap_type")


class ScrapSupplierMappingAdmin(AlmightyAdmin):
    list_display = ("scrap_supplier", "input_scrap_supplier")
    form = ScrapSupplierMappingAdminForm


class ScrapSupplierAdmin(AlmightyAdmin):
    list_display = ("name",)
    ordering = ("name",)


class LoadingStationAdmin(AlmightyAdmin):
    list_display = ("name", "steelshop", "user_in_control", "scrap_yard_api", "scale_control")
    form = LoadingStationForm
    list_filter = ["steelshop"]
    actions = ["reset_current_data_v2"]
    filter_horizontal = (
        "authorized_users",
        "relaxable_risk_limit_settings",
        "relaxable_upper_summing_limit_settings",
        "relaxable_lower_summing_limit_settings",
        "scrap_exclusive_group_settings",
        "scrap_facilities",
    )

    def get_actions(self, request):
        actions = super().get_actions(request)
        if "delete_selected" in actions:
            del actions["delete_selected"]
        return actions

    # pylint: disable=no-self-use
    def reset_current_data_v2(self, request, queryset):
        queryset.update(current_data_v2=LoadingStationDisplayDataV2())
        messages.success(request, "Current data v2 reset was successful")


class ExcelUploadAdmin(AlmightyAdmin):
    change_list_template = "scrap/scrap_purchase_list.html"

    def get_urls(self):
        urls = super().get_urls()
        additional_urls = [
            path("upload-scrap-purchase-excel", self.upload_scrap_purchase_excel),
        ]
        return additional_urls + urls

    def changelist_view(
        self, request: HttpRequest, extra_context: Optional[Dict[str, Any]] = None
    ) -> TemplateResponse:
        extra = extra_context or dict()
        extra["excel_upload_form"] = ExcelUploadForm()
        return super(ExcelUploadAdmin, self).changelist_view(request, extra_context=extra)

    def upload_scrap_purchase_excel(self, request: HttpRequest):
        if request.method == "POST":
            form = ExcelUploadForm(request.POST, request.FILES)
            if form.is_valid():
                if request.FILES["excel_file"].name.endswith("xlsx"):
                    try:
                        file_bytes = request.FILES["excel_file"].file
                        parsed_scrap_purchase_tuple = parse_scrap_purchase_history_excel_file(
                            io.BytesIO(file_bytes.read())
                        )
                        ScrapPurchase.objects.bulk_create(parsed_scrap_purchase_tuple)
                        self.message_user(request, "Dáta boli úspešne naimportované", level=messages.SUCCESS)
                    except Exception:  # pylint: disable=broad-except
                        self.message_user(
                            request, "Vyskytla sa chyba pri spracovaní súboru.", level=messages.ERROR
                        )
                else:
                    self.message_user(
                        request,
                        "Nevhodný typ súboru: {}".format(request.FILES["excel_file"].name.split(".")[1]),
                        level=messages.ERROR,
                    )
            else:
                self.message_user(
                    request, "There was an error in the form {}".format(form.errors), level=messages.ERROR
                )
        return redirect(".")


class ScrapPurchaseAdmin(ExcelUploadAdmin):
    list_display = (
        "supplier",
        "scrap_type",
        "zone",
        "date",
        "quantity",
        "price",
        "note",
        "total_value",
        "entered_manually",
    )
    ordering = ("-date",)
    list_filter = (
        "supplier",
        "scrap_type",
        "zone",
    )


class ScrapPurchaseRecordAdmin(AlmightyAdmin):
    list_display = (
        "id",
        "name",
        "user_in_control",
    )
    readonly_fields = (
        "created_at",
        "updated_at",
        "purchase_date",
    )
    form = ScrapPurchaseRecordForm
    actions = None
    filter_horizontal = ("authorized_users",)


class ScrapExclusiveGroupSettingAdmin(SimpleHistoryAdmin):
    list_display = (
        "id",
        "name",
        "scrap_types",
        "comment",
        "affected_loading_stations",
    )
    history_list_display = list_display
    form = ScrapExclusiveGroupSettingForm
    actions = None

    def get_readonly_fields(self, request: HttpRequest, obj: Optional[Model] = None) -> Tuple[str, ...]:
        """Let all fields be non-editable after object is created"""
        if obj is not None:
            return (
                "name",
                "scrap_types",
                "comment",
                "created_at",
                "created_by",
            )

        return "created_at", "created_by"

    def save_model(
        self,
        request: HttpRequest,
        obj: ScrapExclusiveGroupSetting,
        form: ScrapExclusiveGroupSettingForm,
        change: bool,
    ) -> None:
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


class GradeGroupAdmin(AlmightyAdmin):
    list_display = ("group_name", "comment")
    search_fields = ("group_name__startswith", "grade_ids__grade_id__contains")
    filter_horizontal = ("grade_ids",)


class ScrapGroupAdmin(AlmightyAdmin):
    list_display = ("group_name", "comment")
    search_fields = ("group_name__startswith", "scrap_ids__tms_id__contains")
    filter_horizontal = ("scrap_ids",)


class ScrapMixRatioAdmin(AlmightyAdmin):
    list_display = ("scrap_mix_definition", "scrap_type", "ratio")


class ScrapMixDefinitionAdmin(AlmightyAdmin):
    list_display = ("name", "display_name", "exhausted")


class ScrapFacilityAdmin(AlmightyAdmin):
    list_display = ("name", "facility_id", "outdoor")


class RelaxableRiskLimitSettingAdmin(AlmightyAdmin, SimpleHistoryAdmin):
    list_display = (
        "name",
        "grade_ids",
        "Cr_aim",
        "Cr_allowed",
        "Cu_aim",
        "Cu_allowed",
        "Mo_aim",
        "Mo_allowed",
        "Ni_aim",
        "Ni_allowed",
        "S_aim",
        "S_allowed",
        "Si_aim",
        "Si_allowed",
        "Sn_aim",
        "Sn_allowed",
        "affected_loading_stations",
        "comment",
    )
    history_list_display = list_display
    form = RelaxableRiskLimitSettingForm
    actions = None


class RelaxableUpperSummingLimitSettingAdmin(AlmightyAdmin, SimpleHistoryAdmin):
    list_display = (
        "name",
        "grade_ids",
        "scrap_types",
        "weight_aim",
        "weight_allowed",
        "ratio_aim",
        "ratio_allowed",
        "affected_loading_stations",
        "comment",
    )
    history_list_display = list_display
    form = RelaxableUpperSummingLimitSettingForm
    actions = None


class RelaxableLowerSummingLimitSettingAdmin(AlmightyAdmin, SimpleHistoryAdmin):
    list_display = (
        "name",
        "grade_ids",
        "scrap_types",
        "weight_aim",
        "weight_allowed",
        "ratio_aim",
        "ratio_allowed",
        "affected_loading_stations",
        "comment",
    )
    history_list_display = list_display
    form = RelaxableLowerSummingLimitSettingForm
    actions = None


class WeightedScrapAdmin(AlmightyAdmin):
    list_display = (
        "id",
        "scrap_charge_id",
        "start",
        "end",
        "scale_id",
        "invalid_record",
    )
    form = WeightedScrapForm


class OperatorAdmin(AlmightyAdmin):
    list_display = ("user", "operator_id")


class MultipleHeatsOptimizationResultInline(admin.TabularInline):
    model = MultipleHeatsOptimizationResult
    show_change_link = True


class ScrapChargeAdmin(AlmightyAdmin):
    inlines = [
        MultipleHeatsOptimizationResultInline,
    ]
    list_display = (
        "pk",
        "closed_at",
        "loading_station",
    )
    list_filter = ("closed_at", "loading_station")


class ChargeInputInline(admin.TabularInline):
    model = ChargeInput
    show_change_link = True


class OptimizationInputAdmin(ReadAndDeleteAdmin):
    inlines = [
        ChargeInputInline,
    ]


# TODO try other inline
class OptimizationInputInline(admin.TabularInline):
    model = OptimizationInput
    show_change_link = True


class MultipleHeatsOptimizationResultAdmin(ReadAndDeleteAdmin):
    list_display = (
        "pk",
        "created_at",
        "last_updated",
        "progress",
        "status",
        "result",
        "link_to_optimization_input",
    )
    inlines = [
        OptimizationInputInline,
    ]

    def link_to_optimization_input(self, obj: MultipleHeatsOptimizationResult) -> str:
        link = reverse("admin:scrap_optimizationinput_change", args=[obj.optimization_input.pk])
        return mark_safe(f'<a href="{link}">{escape(obj.optimization_input.__str__())}</a>')

    link_to_optimization_input.short_description = "Optimization Input"
    link_to_optimization_input.admin_order_field = "optimization_input"  # Make row sortable


admin.site.register(YieldCalculationModelResult, ReadOnlyAdmin)
admin.site.register(LoadingStation, LoadingStationAdmin)
admin.site.register(ClosedHeatEvaluationV2, ClosedHeatEvaluationAdminV2)
admin.site.register(MultipleHeatsOptimizationResult, MultipleHeatsOptimizationResultAdmin)
admin.site.register(ScrapCharge, ScrapChargeAdmin)
admin.site.register(SupportedScrapTypeMapping, SupportedScrapTypeMappingAdmin)
admin.site.register(ScrapSupplierMapping, ScrapSupplierMappingAdmin)
admin.site.register(ScrapSupplier, ScrapSupplierAdmin)
admin.site.register(ScrapPurchase, ScrapPurchaseAdmin)
admin.site.register(ScrapPurchaseRecord, ScrapPurchaseRecordAdmin)
admin.site.register(PigIronAnalysisResult, ReadOnlyAdmin)
admin.site.register(ScrapPurchaseOptimizationResult, ReadOnlyAdmin)
admin.site.register(ScrapExclusiveGroupSetting, ScrapExclusiveGroupSettingAdmin)
admin.site.register(GradeGroup, GradeGroupAdmin)
admin.site.register(GradeDefinition, AlmightyAdmin)
admin.site.register(Operator, OperatorAdmin)
admin.site.register(ChargeInput, ReadAndDeleteAdmin)
admin.site.register(OptimizationInput, OptimizationInputAdmin)
admin.site.register(ScrapGroup, ScrapGroupAdmin)
admin.site.register(ScrapDefinition, AlmightyAdmin)
admin.site.register(ScrapMixRatio, ScrapMixRatioAdmin)
admin.site.register(ScrapMixDefinition, ScrapMixDefinitionAdmin)
admin.site.register(ScrapFacility, ScrapFacilityAdmin)
admin.site.register(RelaxableRiskLimitSetting, RelaxableRiskLimitSettingAdmin)
admin.site.register(RelaxableUpperSummingLimitSetting, RelaxableUpperSummingLimitSettingAdmin)
admin.site.register(RelaxableLowerSummingLimitSetting, RelaxableLowerSummingLimitSettingAdmin)
admin.site.register(WeightedScrap, WeightedScrapAdmin)
admin.site.register(Basket, AlmightyAdmin)
admin.site.register(BasketWaggonWeight, AlmightyAdmin)
admin.site.register(Printer, AlmightyAdmin)
admin.site.register(AvailableScrap, AlmightyAdmin)
admin.site.register(ScaleCurrentState, AlmightyAdmin)
