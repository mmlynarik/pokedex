ERORS = {
    "s_e1": {"code": "s_e1", "description": "Missing scrap state on client side"},
}
