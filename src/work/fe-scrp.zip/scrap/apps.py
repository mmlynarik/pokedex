from django.apps import AppConfig


class ScrapConfig(AppConfig):
    name = "scrap"

    def ready(self):
        # see https://docs.djangoproject.com/en/4.1/topics/signals/#connecting-receiver-functions
        import scrap.signals
