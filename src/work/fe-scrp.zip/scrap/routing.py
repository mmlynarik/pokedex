from django.urls import path, re_path

from scrap.consumers.actual_weight import ActualScaleDataConsumer
from scrap.consumers.optimization_consumer import OptimizationProgressConsumer
from scrap.consumers.scale_controller import ScaleControllerConsumer
from scrap.consumers.scale_controller_v2 import ScaleControllerConsumerV2


ws_urlpatterns = [
    path("ws/optimization_progress", OptimizationProgressConsumer.as_asgi()),
    re_path(r"(?P<scale_id>\w+)/scale_control$", ScaleControllerConsumer.as_asgi()),
    re_path(r"scales_stream/(?P<scale_id>\w+)$", ActualScaleDataConsumer.as_asgi()),
    re_path(r"(?P<steelshop>\d)/weighting$", ScaleControllerConsumerV2.as_asgi()),
]
