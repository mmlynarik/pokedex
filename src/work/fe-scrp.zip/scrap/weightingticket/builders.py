from decimal import Decimal
from typing import Any, List

from borb.pdf import Alignment, Paragraph, TableCell, TextField


def to_decimals(*floats: float) -> List[Decimal]:
    # Borb library requires to use decimals in column widths.
    return [Decimal(i) for i in floats]


def get_empty_cell(
    border_right: bool = False,
    border_left: bool = False,
    border_top: bool = False,
    border_bottom: bool = False,
) -> TableCell:
    return TableCell(
        Paragraph(""),
        border_left=border_left,
        border_bottom=border_bottom,
        border_right=border_right,
        border_top=border_top,
    )


def get_table_header_cell_builder(
    font: str,
    font_size: int,
    border_top: bool = False,
    border_bottom: bool = False,
    border_right: bool = False,
    border_left: bool = False,
):
    def table_header_cell_builder(text: str, halign: str = Alignment.CENTERED):
        return TableCell(
            Paragraph(text, font=font, font_size=font_size, horizontal_alignment=halign),
            border_top=border_top,
            border_right=border_right,
            border_left=border_left,
            border_bottom=border_bottom,
        )

    return table_header_cell_builder


def get_table_header_text_field_builder(
    font_size: int,
    border_right: bool = False,
    border_left: bool = False,
    border_top: bool = False,
    border_bottom: bool = False,
):
    def table_header_text_field_builder(name: str, default: str = "", halign: str = Alignment.LEFT):
        """Build editable text field identified by `name`."""
        return TableCell(
            TextField(
                field_name=name,
                value=default,
                font_size=font_size,
                border_left=False,
                border_right=False,
                border_top=False,
                border_bottom=False,
                horizontal_alignment=halign,
            ),
            border_right=border_right,
            border_left=border_left,
            border_top=border_top,
            border_bottom=border_bottom,
        )

    return table_header_text_field_builder


def get_table_body_text_field_builder(font_size: int):
    def table_body_text_field_builder(name: str, halign: str = Alignment.LEFT, default: str = ""):
        """Build editable text field identified by `name`."""
        return TableCell(
            TextField(
                field_name=name,
                font_size=font_size,
                value=default,
                border_left=False,
                border_right=False,
                border_top=False,
                border_bottom=False,
                horizontal_alignment=halign,
            ),
            border_right=False,
            border_left=False,
            border_bottom=False,
            border_top=False,
        )

    return table_body_text_field_builder


def get_table_body_cell_builder(font: str, font_size: int):
    def table_body_cell_builder(text: Any, halign: str = Alignment.CENTERED):
        text = f"{text:,.0f}" if isinstance(text, int) else str(text)
        return TableCell(
            Paragraph(text, font=font, font_size=font_size, horizontal_alignment=halign),
            border_top=False,
            border_right=False,
            border_left=False,
            border_bottom=False,
        )

    return table_body_cell_builder
