from functools import lru_cache
from typing import Any, List, Optional, Tuple, TypedDict

from borb.pdf import Alignment, DropDownList, FixedColumnWidthTable, Paragraph, Table, TableCell
from scrap.dash.components.telegram_utils import extend
from scrap.models import ScrapCharge, WeightedScrap
from scrap.weightingticket.builders import (
    get_empty_cell,
    get_table_body_cell_builder,
    get_table_body_text_field_builder,
    get_table_header_cell_builder,
    get_table_header_text_field_builder,
    to_decimals,
)
from scrap_core import TMS_ID_REVERSE_MAPPING, ScrapMix, ScrapMixOrder

AggID = Optional[str]

MAX_AGG_ID = 4  # at most 4 baskets/scales are used to load scrap


class LoadedScrapTableRow(TypedDict):
    id_: int
    scrap_mix: ScrapMix
    target: int
    agg_1: AggID
    agg_2: AggID
    agg_3: AggID
    agg_4: AggID
    loaded: int
    delta: int


LoadedScrapTableData = List[LoadedScrapTableRow]


def get_scale_ids(all_loaded_scraps: Tuple[WeightedScrap, ...]) -> List[str]:
    return list(sorted(set(ws.scale_id for ws in all_loaded_scraps)))


def get_aggregation_ids_for_scrap_charge(
    all_loaded_scraps: Tuple[WeightedScrap, ...], steelshop: int
) -> List[AggID]:
    """Basket_ids for steelshop #1, scale_ids for steelshop #2 used to aggregate weighted scrap."""
    if steelshop == 1:
        return list(sorted(set(str(ws.baskets.first().basket_id) for ws in all_loaded_scraps)))
    return get_scale_ids(all_loaded_scraps)


def get_total_loaded_scrap_weight_on_agg_id(
    all_loaded_scraps: Tuple[WeightedScrap, ...], scrap: str, agg_id: AggID, steelshop: int
) -> int:
    if agg_id is None:
        return 0
    if steelshop == 1:
        return sum(
            ws.weight
            for ws in all_loaded_scraps
            if ws.baskets.first().basket_id == int(agg_id) and ws.scrap == scrap
        )
    else:  # steelshop == 2
        return sum(ws.weight for ws in all_loaded_scraps if ws.scale_id == agg_id and ws.scrap == scrap)


def get_agg_ids_from_scrap_charge_data(
    all_loaded_scraps: Tuple[WeightedScrap, ...], steelshop: int
) -> List[AggID]:
    agg_ids = get_aggregation_ids_for_scrap_charge(all_loaded_scraps, steelshop)
    return extend(agg_ids, length=MAX_AGG_ID, default=None)


def get_loaded_scrap_table_footer_cell_builder(font: str, font_size: int):
    def loaded_scrap_table_footer_cell_builder(text: Any, halign: str = Alignment.CENTERED):
        text = f"{text:,.0f}" if isinstance(text, int) else str(text)
        return TableCell(
            Paragraph(text, font=font, font_size=font_size, horizontal_alignment=halign),
            border_bottom=False,
            border_right=False,
            border_left=False,
        )

    return loaded_scrap_table_footer_cell_builder


def get_loaded_scrap_table_footer_ddl_builder(font_size: int):
    def loaded_scrap_table_footer_ddl_builder(
        field_name: str, values: List[str], halign: str = Alignment.LEFT
    ):
        """Drop-down list builder for restricted text selection"""
        return TableCell(
            DropDownList(
                field_name=field_name,
                font_size=font_size,
                horizontal_alignment=halign,
                possible_values=values,
                border_top=False,
                border_bottom=False,
                border_left=False,
                border_right=False,
            ),
            border_bottom=False,
            border_right=False,
            border_left=False,
            border_top=False,
        )

    return loaded_scrap_table_footer_ddl_builder


def get_loaded_scrap_table_column_summer(loaded_scrap_table_data: LoadedScrapTableData):
    def column_summer(field: str) -> int:
        return sum(row[field] for row in loaded_scrap_table_data)

    return column_summer


def get_loaded_scrap_mixes(loaded_scraps: Tuple[WeightedScrap, ...]) -> ScrapMixOrder:
    return tuple(sorted(set(ScrapMix(ws.scrap) for ws in loaded_scraps)))


@lru_cache(maxsize=32)
def get_total_loaded_scrap_weight(all_loaded_scraps: Tuple[WeightedScrap, ...], scrap: ScrapMix) -> int:
    return sum(ws.weight for ws in all_loaded_scraps if ws.scrap == scrap)


def get_loaded_scrap_table_data(
    scrap_charge: ScrapCharge, all_loaded_scraps: Tuple[WeightedScrap, ...], steelshop: int
) -> LoadedScrapTableData:
    model_scrap = scrap_charge.recommended_scrap_charge
    loaded_scrap_mixes = get_loaded_scrap_mixes(all_loaded_scraps)
    agg_ids = get_agg_ids_from_scrap_charge_data(all_loaded_scraps, steelshop)
    all_scrap_mixes = tuple(set(loaded_scrap_mixes + tuple(mix for mix in model_scrap)))
    loaded_scrap_table_data = [
        LoadedScrapTableRow(
            id_=TMS_ID_REVERSE_MAPPING.get(scrap_mix, 0),
            scrap_mix=scrap_mix,
            target=int(model_scrap.get(scrap_mix, 0)),
            agg_1=get_total_loaded_scrap_weight_on_agg_id(
                all_loaded_scraps, scrap_mix, agg_ids[0], steelshop
            ),
            agg_2=get_total_loaded_scrap_weight_on_agg_id(
                all_loaded_scraps, scrap_mix, agg_ids[1], steelshop
            ),
            agg_3=get_total_loaded_scrap_weight_on_agg_id(
                all_loaded_scraps, scrap_mix, agg_ids[2], steelshop
            ),
            agg_4=get_total_loaded_scrap_weight_on_agg_id(
                all_loaded_scraps, scrap_mix, agg_ids[3], steelshop
            ),
            loaded=get_total_loaded_scrap_weight(all_loaded_scraps, scrap_mix),
            delta=int(model_scrap.get(scrap_mix, 0))
            - get_total_loaded_scrap_weight(all_loaded_scraps, scrap_mix),
        )
        for scrap_mix in all_scrap_mixes
    ]
    return sorted(loaded_scrap_table_data, key=lambda x: x["id_"])


def get_text_field_default(steelshop: int, agg_id: AggID):
    if agg_id is None:
        return "          ---"
    if steelshop == 1:
        return f"Koryto /{agg_id}"
    return f"    Váha {agg_id}"


def add_header_to_loaded_scrap_table(
    table: FixedColumnWidthTable, font: str, font_size: int, agg_ids: Tuple[AggID, ...], steelshop: int
) -> FixedColumnWidthTable:
    table_header_cell_builder = get_table_header_cell_builder(font, font_size, border_bottom=True)
    table_header_text_field_builder = get_table_header_text_field_builder(font_size, border_bottom=True)
    return (
        table.add(table_header_cell_builder("ID", halign=Alignment.LEFT))
        .add(table_header_cell_builder("Šrot", halign=Alignment.LEFT))
        .add(table_header_cell_builder("Poznámka", halign=Alignment.LEFT))
        .add(table_header_cell_builder("Ciel' \n (kg)", halign=Alignment.RIGHT))
        .add(table_header_text_field_builder("agg_1", default=get_text_field_default(steelshop, agg_ids[0])))
        .add(table_header_text_field_builder("agg_2", default=get_text_field_default(steelshop, agg_ids[1])))
        .add(table_header_text_field_builder("agg_3", default=get_text_field_default(steelshop, agg_ids[2])))
        .add(table_header_text_field_builder("agg_4", default=get_text_field_default(steelshop, agg_ids[3])))
        .add(table_header_cell_builder("Naložené (kg)", halign=Alignment.RIGHT))
        .add(table_header_cell_builder("Delta (kg)", halign=Alignment.RIGHT))
    )


def add_body_row_to_loaded_scrap_table(
    font: str, font_size: int, table: FixedColumnWidthTable, loaded_scrap_table_row: LoadedScrapTableRow
) -> FixedColumnWidthTable:
    table_body_cell_builder = get_table_body_cell_builder(font, font_size)
    table_body_text_field_builder = get_table_body_text_field_builder(font_size)
    return (
        table.add(table_body_cell_builder(loaded_scrap_table_row["id_"], halign=Alignment.LEFT))
        .add(table_body_cell_builder(loaded_scrap_table_row["scrap_mix"], halign=Alignment.LEFT))
        .add(table_body_text_field_builder(loaded_scrap_table_row["scrap_mix"]))
        .add(table_body_cell_builder(loaded_scrap_table_row["target"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["agg_1"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["agg_2"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["agg_3"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["agg_4"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["loaded"], halign=Alignment.RIGHT))
        .add(table_body_cell_builder(loaded_scrap_table_row["delta"], halign=Alignment.RIGHT))
    )


def add_body_to_loaded_scrap_table(
    table: FixedColumnWidthTable, font: str, font_size: int, loaded_scrap_table_data: LoadedScrapTableData
) -> FixedColumnWidthTable:
    for row in loaded_scrap_table_data:
        table = add_body_row_to_loaded_scrap_table(font, font_size, table, row)
    return table


def add_footer_to_loaded_scrap_table(
    table: FixedColumnWidthTable, font: str, font_size: int, loaded_scrap_table_data: LoadedScrapTableRow
) -> FixedColumnWidthTable:
    loaded_scrap_table_footer_cell_builder = get_loaded_scrap_table_footer_cell_builder(font, font_size)
    loaded_scrap_table_footer_ddl_builder = get_loaded_scrap_table_footer_ddl_builder(font_size - 2)
    column_summer = get_loaded_scrap_table_column_summer(loaded_scrap_table_data)
    return (
        table.add(get_empty_cell(border_top=True))
        .add(get_empty_cell(border_top=True))
        .add(get_empty_cell(border_top=True))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("target"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("agg_1"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("agg_2"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("agg_3"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("agg_4"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("loaded"), halign=Alignment.RIGHT))
        .add(loaded_scrap_table_footer_cell_builder(column_summer("delta"), halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(get_empty_cell())
        .add(get_empty_cell())
        .add(get_empty_cell())
        .add(loaded_scrap_table_footer_ddl_builder(field_name="scale_1", values=["Sadit' ako prvé !!!", " "]))
        .add(loaded_scrap_table_footer_ddl_builder(field_name="scale_2", values=["Sadit' ako prvé !!!", " "]))
        .add(loaded_scrap_table_footer_ddl_builder(field_name="scale_3", values=["Sadit' ako prvé !!!", " "]))
        .add(loaded_scrap_table_footer_ddl_builder(field_name="scale_4", values=["Sadit' ako prvé !!!", " "]))
        .add(get_empty_cell())
        .add(get_empty_cell())
    )


def get_loaded_scrap_table(
    font: str,
    font_size: int,
    scrap_charge: ScrapCharge,
    all_loaded_scraps: Tuple[WeightedScrap, ...],
    steelshop: int,
    padding: int = 1,
) -> Table:
    loaded_scrap_table_data = get_loaded_scrap_table_data(scrap_charge, all_loaded_scraps, steelshop)
    agg_ids = get_agg_ids_from_scrap_charge_data(all_loaded_scraps, steelshop)
    # TODO Remove magic numbers
    table = FixedColumnWidthTable(
        number_of_columns=10,
        number_of_rows=len(loaded_scrap_table_data) + 1 + 1 + 1,  # rows + 2 footer + 1 header
        column_widths=to_decimals(*[0.5] * 2 + [0.8] * 2 + [1] * 4 + [0.9, 0.7]),
    )
    table = add_header_to_loaded_scrap_table(table, font, font_size, agg_ids, steelshop)
    table = add_body_to_loaded_scrap_table(table, font, font_size, loaded_scrap_table_data)
    table = add_footer_to_loaded_scrap_table(table, font, font_size, loaded_scrap_table_data)
    return table.set_padding_on_all_cells(padding, padding, padding, padding)
