import io
import logging
import os
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Dict, Tuple, List

from borb.pdf import (
    PDF,
    Alignment,
    Document,
    FixedColumnWidthTable,
    HexColor,
    Image,
    Page,
    Paragraph,
    Table,
    MultiColumnLayout,
)
from pdf2image import convert_from_bytes
import PIL.Image
from pytz import timezone
from scrap.dash.components.telegram_utils import calc_blend_id, calc_seq_num
from scrap.dash.database_api import steel_grades
from scrap.models import ScrapCharge, WeightedScrap
from scrap.weightingticket.builders import (
    get_empty_cell,
    get_table_body_cell_builder,
    get_table_body_text_field_builder,
    get_table_header_cell_builder,
    to_decimals,
)
from scrap.weightingticket.loaded_scrap_table import get_loaded_scrap_table

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


IMG_DIR = Path(__file__).parent
TICKET_FILE = "ticket.pdf"

FONT_SIZE_NORMAL = 16
FONT_SIZE_TITLE = 20
FONT_SIZE_SUBTITLE = 14
FONT_NORMAL = "Times-Bold"
FONT_ITALICS = "Times-Italic"
FONT_BOLD_ITALICS = "Times-Bold-Italic"

A4_WIDTH = 794
A4_HEIGHT = 1123
CONTENT_WIDTH_MULTIPLIER = 0.9  # 0.5 = 50%, 1 = 100%
MARGIN_LR_MULTIPLIER = (1 - CONTENT_WIDTH_MULTIPLIER) / 2  # divided by 2 because 1 column has two edges
MARGIN_TB_PERCENTAGE = 0.05

DISPLAYED_CHEMS = ["S", "P", "Cu", "Cr", "Ni", "Mo", "Sn"]


def get_ticket_dir() -> Path:
    try:
        return Path(os.getenv("PDF_UPLOAD_FOLDER"))
    except TypeError:
        raise TypeError("PDF_UPLOAD_FOLDER env variable is not assigned.")


def get_blend_id(scrap_charge: ScrapCharge) -> str:
    seq_num = calc_seq_num(scrap_charge)
    blend_id = str(calc_blend_id(scrap_charge.loading_station.steelshop, scrap_charge.closed_at, seq_num))
    return f"{blend_id[0:1]}-{blend_id[1:7]}-{blend_id[7:]}"


def get_blend_id_with_label(scrap_charge: ScrapCharge) -> str:
    return "USS Blend ID:\n" + get_blend_id(scrap_charge)


def get_current_datetime_str() -> str:
    return (
        datetime.now(tz=timezone("UTC"))
        .astimezone(timezone("Europe/Bratislava"))
        .strftime("%d.%m.%Y %I:%M:%S %p")
    )


def get_usske_logo(halign: str = Alignment.CENTERED) -> Image:
    return Image(IMG_DIR / "usske.jpg", width=150, height=35, horizontal_alignment=halign)


def get_header_table(font: str, font_size: int, scrap_charge: ScrapCharge, padding: int = 1) -> Table:
    return (
        FixedColumnWidthTable(number_of_columns=3, number_of_rows=1, column_widths=to_decimals(1, 2, 1))
        .add(Paragraph(get_current_datetime_str(), font_size=font_size, font=font))
        .add(get_empty_cell())
        .add(
            Paragraph(
                get_blend_id_with_label(scrap_charge),
                font_size=font_size,
                font=font,
                horizontal_alignment=Alignment.RIGHT,
            )
        )
        .set_padding_on_all_cells(padding, padding, padding, padding)
        .no_borders()
    )


def get_title_table(
    font: str, font_size_title: int, font_size_subtitle: int, steelshop: int, padding: int = 1
) -> Table:
    return (
        FixedColumnWidthTable(number_of_columns=3, number_of_rows=2, column_widths=to_decimals(1, 1, 1))
        .add(get_usske_logo(halign=Alignment.LEFT))
        .add(
            Paragraph(
                f"Steel Shop #{steelshop}",
                font=font,
                font_size=font_size_title,
                vertical_alignment=Alignment.MIDDLE,
                horizontal_alignment=Alignment.CENTERED,
            )
        )
        .add(get_usske_logo(halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(
            Paragraph(
                "Powered by Advanced Analytics Team",
                font_size=font_size_subtitle,
                font=font,
                font_color=HexColor("#808080"),
                vertical_alignment=Alignment.TOP,
                horizontal_alignment=Alignment.CENTERED,
            )
        )
        .add(get_empty_cell())
        .set_padding_on_all_cells(padding, padding, padding, padding)
        .no_borders()
    )


def get_mill_order_heading(font: str, font_size: int):
    return Paragraph("Zákazka", font=font, font_size=font_size)


def add_body_to_mill_order_table(
    table: FixedColumnWidthTable, font: str, font_size: int, scrap_charge: ScrapCharge, operator_id: int
) -> FixedColumnWidthTable:
    grade = steel_grades.get_grade_from_id(scrap_charge.grade_id, date.today())
    table_body_cell_builder = get_table_body_cell_builder(font, font_size)
    table_body_text_field_builder = get_table_body_text_field_builder(font_size)
    return (
        table.add(table_body_cell_builder("Akost':", halign=Alignment.LEFT))
        .add(table_body_cell_builder(grade.display_name, halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(table_body_cell_builder("Selektivita:", halign=Alignment.LEFT))
        .add(table_body_cell_builder(grade.selectivity, halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(table_body_cell_builder("Objednávka (kg):", halign=Alignment.LEFT))
        .add(table_body_cell_builder(scrap_charge.total_scrap_weight, halign=Alignment.RIGHT))
        .add(table_body_cell_builder("Rok:", halign=Alignment.LEFT))
        .add(table_body_cell_builder(scrap_charge.closed_at.year, halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(table_body_cell_builder("Súprava:", halign=Alignment.LEFT))
        .add(table_body_text_field_builder("Suprava", halign=Alignment.RIGHT))
        .add(get_empty_cell())
        .add(table_body_cell_builder("Operátor:", halign=Alignment.LEFT))
        .add(table_body_cell_builder(str(operator_id), halign=Alignment.RIGHT))
    )


def get_mill_order_table(
    font: str, font_size: int, scrap_charge: ScrapCharge, operator_id: int, padding: int = 1
) -> Table:
    table = FixedColumnWidthTable(
        number_of_columns=8, number_of_rows=2, column_widths=to_decimals(*[1, 1, 0.5] * 2 + [1, 1])
    )
    table = add_body_to_mill_order_table(table, font, font_size, scrap_charge, operator_id)
    return table.set_padding_on_all_cells(padding, padding, padding, padding)


def get_heat_chem_analysis_heading(font: str, font_size: int):
    return Paragraph("Chemická analýza tavby", font=font, font_size=font_size)


def get_grade_chem_maxima(scrap_charge: ScrapCharge) -> Dict[str, float]:
    grade = steel_grades.get_grade_from_id(scrap_charge.grade_id, date.today())
    return {chem: grade.max_chem(chem) for chem in DISPLAYED_CHEMS}


def add_header_to_heat_residuals_table(
    table: FixedColumnWidthTable, font: str, font_size: int
) -> FixedColumnWidthTable:
    table_header_cell_builder = get_table_header_cell_builder(font, font_size)
    table = table.add(get_empty_cell())
    for chem in DISPLAYED_CHEMS:
        table = table.add(table_header_cell_builder(chem, halign=Alignment.CENTERED))
    return table


def add_body_to_heat_residuals_table(
    table: FixedColumnWidthTable, font: str, font_size: int, grade_chem_max: Dict[str, float]
) -> FixedColumnWidthTable:
    table_body_cell_builder = get_table_body_cell_builder(font, font_size)
    table = table.add(table_body_cell_builder("Akost' Max (%)", halign=Alignment.LEFT))
    for chem in DISPLAYED_CHEMS:
        table = table.add(table_body_cell_builder(grade_chem_max[chem], halign=Alignment.CENTERED))
    return table


def get_heat_chem_analysis_table(font: str, font_size: int, scrap_charge: ScrapCharge, padding: int = 1):
    grade_chem_max = get_grade_chem_maxima(scrap_charge)
    # TODO remove magic numbers
    table = FixedColumnWidthTable(
        number_of_columns=8,
        number_of_rows=1 + 1,  # rows + 1 header
        column_widths=to_decimals(*[2] + [1] * 7),
    )
    table = add_header_to_heat_residuals_table(table, font, font_size)
    table = add_body_to_heat_residuals_table(table, font, font_size, grade_chem_max)
    return table.set_padding_on_all_cells(padding, padding, padding, padding)


def get_wet_scrap_notice(font_size: int):
    return Paragraph(
        text=40 * " " + "UPOZORNENIE: MOKRÝ ŠROT",
        font=FONT_NORMAL,
        font_size=Decimal(font_size),
        horizontal_alignment=Alignment.CENTERED,
        margin_top=Decimal(75),
    )


def get_comment_table(font: str, font_size: int) -> Table:
    table = FixedColumnWidthTable(
        number_of_columns=2,
        number_of_rows=1,
        column_widths=to_decimals(1, 4),
        margin_top=Decimal(50),
    )
    table_body_cell_builder = get_table_body_cell_builder(font, font_size)
    table_body_text_field_builder = get_table_body_text_field_builder(font_size)
    return table.add(table_body_cell_builder("Komentár k vsádzke:", halign=Alignment.LEFT)).add(
        table_body_text_field_builder("Comment", halign=Alignment.LEFT)
    )


def create_document() -> Tuple[Document, MultiColumnLayout]:
    doc = Document()
    page = Page(width=Decimal(A4_WIDTH), height=Decimal(A4_HEIGHT))
    doc.add_page(page)
    margin_size = Decimal(A4_WIDTH * MARGIN_LR_MULTIPLIER)
    layout = MultiColumnLayout(
        page,
        column_widths=[Decimal(A4_WIDTH * CONTENT_WIDTH_MULTIPLIER)],
        margin_left=margin_size,
        margin_right=margin_size,
        margin_top=Decimal(A4_HEIGHT * MARGIN_TB_PERCENTAGE),
        margin_bottom=Decimal(A4_HEIGHT * MARGIN_TB_PERCENTAGE),
    )
    return doc, layout


def build_layout(
    layout: MultiColumnLayout,
    scrap_charge: ScrapCharge,
    all_loaded_scraps: Tuple[WeightedScrap, ...],
    steelshop: int,
    operator_id: int,
):
    layout.add(get_header_table(FONT_NORMAL, FONT_SIZE_NORMAL, scrap_charge))
    layout.add(get_title_table(FONT_NORMAL, FONT_SIZE_TITLE, FONT_SIZE_SUBTITLE, steelshop))
    layout.add(get_mill_order_heading(FONT_BOLD_ITALICS, FONT_SIZE_NORMAL))
    layout.add(get_mill_order_table(FONT_NORMAL, FONT_SIZE_SUBTITLE, scrap_charge, operator_id))
    layout.add(
        get_loaded_scrap_table(FONT_NORMAL, FONT_SIZE_SUBTITLE, scrap_charge, all_loaded_scraps, steelshop)
    )
    layout.add(get_heat_chem_analysis_heading(FONT_BOLD_ITALICS, FONT_SIZE_NORMAL))
    layout.add(get_heat_chem_analysis_table(FONT_NORMAL, FONT_SIZE_SUBTITLE, scrap_charge))
    layout.add(get_comment_table(FONT_NORMAL, FONT_SIZE_NORMAL))
    if scrap_charge.is_wet:
        layout.add(get_wet_scrap_notice(FONT_SIZE_TITLE))


def save_pdf(document: Document, scrap_charge: ScrapCharge) -> None:
    filepath = get_ticket_dir() / f"weighting-ticket-{get_blend_id(scrap_charge)}.pdf"
    with open(filepath, "wb") as f:
        PDF.dumps(f, document)

    log.info(f"PDF weighting ticket saved to {filepath}")


def generate_weighting_ticket_pdf(scrap_charge: ScrapCharge) -> Document:
    loading_station = scrap_charge.loading_station
    steelshop = loading_station.steelshop
    operator_id = loading_station.user_in_control.operator.operator_id
    all_loaded_scraps = tuple(scrap_charge.weightedscrap_set.filter(invalid_record=False))

    document, layout = create_document()
    build_layout(layout, scrap_charge, all_loaded_scraps, steelshop, operator_id)
    return document


def to_images(document: Document) -> List[PIL.Image.Image]:

    with io.BytesIO() as pdf_buffer:
        PDF.dumps(pdf_buffer, document)
        pdf_buffer.seek(0)
        images = convert_from_bytes(pdf_buffer.read(), size=(A4_WIDTH, A4_HEIGHT))

    return images
