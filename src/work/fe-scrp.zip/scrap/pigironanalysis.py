import cachetools as ct
from scrap_core.datamodel import RawFeChem

# from .models import PigIronAnalysisResult


@ct.cached(cache=ct.TTLCache(maxsize=1, ttl=3600))
def get_raw_fe_chem_from_db() -> RawFeChem:
    # TODO switch to real code when we will be sure results are OK
    return RawFeChem()

    # last_timestamp = PigIronAnalysisResult.objects.latest("timestamp")
    # results = PigIronAnalysisResult.objects.filter(timestamp=last_timestamp.timestamp)
    # return RawFeChem(**{item.chem: item.value for item in results})
