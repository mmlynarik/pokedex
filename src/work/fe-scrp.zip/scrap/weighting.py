from warnings import warn

import functools

from vsadzka.settings import SCALE_SS1_V1, SCALE_SS1_V2, SCALE_SS2_V8, SCALE_SS2_V9

from scrap.scales.weighting_backend import (
    DashMessagingProcessor,
    DjangoWeightingBackend,
)

WEIGHTING_BACKENDS = {
    SCALE_SS1_V1: DjangoWeightingBackend(SCALE_SS1_V1),
    SCALE_SS1_V2: DjangoWeightingBackend(SCALE_SS1_V2),
    SCALE_SS2_V8: DjangoWeightingBackend(SCALE_SS2_V8),
    SCALE_SS2_V9: DjangoWeightingBackend(SCALE_SS2_V9),
}


def get_deprecated_group_name(scale_id):
    warn("This function is deprecated, use `get_ws_group_name` instead.", DeprecationWarning, stacklevel=2)
    return f"scale-controller-{scale_id}"


MESSAGING_PROCESSORS = {
    SCALE_SS1_V1: DashMessagingProcessor(get_deprecated_group_name(SCALE_SS1_V1)),
    SCALE_SS1_V2: DashMessagingProcessor(get_deprecated_group_name(SCALE_SS1_V2)),
    SCALE_SS2_V8: DashMessagingProcessor(get_deprecated_group_name(SCALE_SS2_V8)),
    SCALE_SS2_V9: DashMessagingProcessor(get_deprecated_group_name(SCALE_SS2_V9)),
}


def get_ws_group_name(steelshop: int) -> str:
    return f"scale-controller-oc{steelshop}"


@functools.lru_cache(maxsize=4)
def get_processor(steelshop: int) -> DashMessagingProcessor:
    return DashMessagingProcessor(get_ws_group_name(steelshop))


def get_message_processor(scale_id: str) -> DashMessagingProcessor:

    scale_to_steelshop = {"v1": 1, "v2": 1, "v8": 2, "v9": 2}

    return get_processor(scale_to_steelshop[scale_id])
