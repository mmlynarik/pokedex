from typing import Iterable, Dict, Tuple

from scrap_core.utils import H, union

from scrap.models import GradeGroup, ScrapGroup


def get_or_create_grade_group_v2(apps, grade_ids: Iterable[int], create_name: str) -> GradeGroup:
    GradeDefinition = apps.get_model("scrap", "GradeDefinition")
    GradeGroup = apps.get_model("scrap", "GradeGroup")

    grade_ids = set(grade_ids)

    for group in GradeGroup.objects.all():
        if grade_ids == set(grade_def.grade_id for grade_def in group.grade_ids.all()):
            return group

    group = GradeGroup.objects.create(group_name=create_name)
    group.grade_ids.set(GradeDefinition.objects.get_or_create(grade_id=grade_id)[0] for grade_id in grade_ids)
    group.save()

    return group


def get_or_create_scrap_group_v2(apps, scrap_types: Iterable[str], create_name: str) -> ScrapGroup:
    ScrapDefinition = apps.get_model("scrap", "ScrapDefinition")
    ScrapGroup = apps.get_model("scrap", "ScrapGroup")

    scrap_types = set(scrap_types)

    for group in ScrapGroup.objects.all():
        if scrap_types == set(scrap_def.scrap_type for scrap_def in group.scrap_ids.all()):
            return group

    group = ScrapGroup.objects.create(group_name=create_name)
    group.scrap_ids.set(
        ScrapDefinition.objects.get_or_create(scrap_type=scrap_type)[0] for scrap_type in scrap_types
    )
    group.save()

    return group


def get_inverted_multimap(mapping: Dict[int, Tuple[H, ...]]) -> Dict[H, Tuple[int, ...]]:
    """
    Convert mapping M of the form
        {key1: (item11, item12, ...), key2: (item21, item22, ...), ...}
    to
        {item1: (key11, key12, ...), item2: (key21, key22, ...), ...}

    such that
        item1 in M[key11], item1 in M[key12], ...
        item2 in M[key21], ...
        ...
    """
    # group keys by items, i.e. item -> keys
    groups = {}
    for item in union(mapping.values()):
        groups[item] = tuple(sorted(key for key in mapping if item in mapping[key]))

    return groups
