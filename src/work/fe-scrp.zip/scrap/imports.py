# pylint: disable=too-many-locals
import base64
import datetime
import io
import logging
from typing import Any, List, Tuple, Optional, Callable

from django.core.exceptions import ObjectDoesNotExist
from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

from scrap_core import SUPPORTED_SCRAP_TYPES
from .models import (
    SupportedScrapTypeMapping,
    ScrapPurchase,
    ScrapSupplier,
    ScrapSupplierMapping,
    ScrapParsedData,
    ScrapOfferParsedRecord,
)


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


SCRAP_STATE_IMPORT_ROW_OFFSET = 2
SCRAP_STATE_SCRAP_TYPE_COL_IDX = 0
SCRAP_STATE_SCRAP_WEIGHT_COL_IDX = 3
SCRAP_STATE_GROUP_CHECK_COL_IDX = 1
SCRAP_STATE_GROUP_NAME_COL_IDX = 0

SCRAP_ON_THE_WAY_IMPORT_ROW_OFFSET = 1
SCRAP_ON_THE_WAY_SCRAP_TYPE_COL_IDX = 0
SCRAP_ON_THE_WAY_SCRAP_WEIGHT_COL_IDX = 1

SCRAP_OFFER_SUPPLIER_COL_IDX = 0
SCRAP_OFFER_SCRAP_TYPE_COL_IDX = 1
SCRAP_OFFER_QUANTITY_COL_IDX = 2
SCRAP_OFFER_PRICE_COL_IDX = 3
SCRAP_OFFER_ZONE_COL_IDX = 4
SCRAP_OFFER_STATION_COL_IDX = 5
SCRAP_OFFER_COUNTRY_COL_IDX = 6
SCRAP_OFFER_NOTE_COL_IDX = 7

SCRAP_PURCHASE_HISTORY_ROW_OFFSET = 1
SCRAP_PURCHASE_HISTORY_SUPPLIER_COL_IDX = 0
SCRAP_PURCHASE_HISTORY_GRADE_COL_IDX = 2
SCRAP_PURCHASE_HISTORY_ZONE_COL_IDX = 3
SCRAP_PURCHASE_HISTORY_MONTH_COL_IDX = 4
SCRAP_PURCHASE_HISTORY_DELIVERY_YEAR_COL_IDX = 5
SCRAP_PURCHASE_HISTORY_QUANTITY_COL_IDX = 6
SCRAP_PURCHASE_HISTORY_PRICE_COL_IDX = 7

DATA_NOT_FOUND_MSG = "Nepodarilo sa získať žiaden záznam. Skontrolujte či ste nahrali správny súbor."
NOT_NUMERIC_VALUE_MSG = "Riadok {row_num} - Uvedená {entity} {value} pre šrot {scrap} nie je numerická"
NOT_SUPPORTED_SCRAP_MSG = "Riadok: {row_num} - Uvedený typ šrotu {scrap} nie je podporovaný"
NOT_DEFINED_SCRAP_MSG = "Riadok: {row_num} - Typ šrotu musí byť uvedený (prázdna bunka pre typ šrotu)"
NOT_DEFINED_WEIGHT_MSG = "Riadok: {row_num} - Váha musí byť uvedená (prázdna bunka pre váhu šrotu)"
NOT_DEFINED_PRICE_MSG = "Riadok: {row_num} - Cena musí byť uvedená (prázdna bunka pre cenu šrotu)"


def decode_uploaded_file(contents: str) -> io.BytesIO:
    content_string = contents.split(",")[1]
    decoded = base64.b64decode(content_string)
    return io.BytesIO(decoded)


def preprocess_scrap_data(scrap: Any) -> Optional[str]:
    if scrap is None:
        return None
    scrap_str = str(scrap)
    return scrap_str.strip()


def parse_scrap_state_file(file_bytes: io.BytesIO) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
    work_book = load_workbook(filename=file_bytes)
    last_sheet_name = work_book.sheetnames[-1]
    sheet = work_book[last_sheet_name]
    inside_group = False
    parsed_data: List[ScrapParsedData] = []
    errors: List[str] = []
    group_name = None

    for row in sheet.iter_rows(
        min_row=SCRAP_STATE_IMPORT_ROW_OFFSET + 1, min_col=1, max_col=8, values_only=False
    ):
        first_cell_value = row[0].value
        if not first_cell_value:
            inside_group = False
            continue

        if inside_group and group_name:
            weight = row[SCRAP_STATE_SCRAP_WEIGHT_COL_IDX].value
            input_scrap_type = preprocess_scrap_data(row[SCRAP_STATE_SCRAP_TYPE_COL_IDX].value)
            if not isinstance(weight, (int, float)):
                if weight is None:
                    errors.append(NOT_DEFINED_WEIGHT_MSG.format(row_num=row[0].row))
                else:
                    errors.append(
                        NOT_NUMERIC_VALUE_MSG.format(
                            row_num=row[0].row, entity="váha", value=weight, scrap=input_scrap_type
                        )
                    )
                continue

            parsed_data.append(
                ScrapParsedData(input_scrap_type=input_scrap_type, weight=weight, scrap_type=None)
            )

        if isinstance(row[SCRAP_STATE_GROUP_CHECK_COL_IDX], MergedCell):
            group_name = row[SCRAP_STATE_GROUP_NAME_COL_IDX].value
            inside_group = True

    if not parsed_data:
        errors = [DATA_NOT_FOUND_MSG, *errors]

    return tuple(parsed_data), tuple(errors)


def parse_scrap_on_the_way_file(
    file_bytes: io.BytesIO,
) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
    work_book = load_workbook(filename=file_bytes)
    last_sheet_name = work_book.sheetnames[-1]
    sheet = work_book[last_sheet_name]
    parsed_data: List[ScrapParsedData] = list()
    errors: List[str] = []

    for row in sheet.iter_rows(
        min_row=SCRAP_ON_THE_WAY_IMPORT_ROW_OFFSET + 1, min_col=1, max_col=2, values_only=False
    ):
        scrap = preprocess_scrap_data(row[SCRAP_ON_THE_WAY_SCRAP_TYPE_COL_IDX].value)
        if scrap not in SUPPORTED_SCRAP_TYPES:
            if scrap is None:
                errors.append(NOT_DEFINED_SCRAP_MSG.format(row_num=row[0].row))
            else:
                errors.append(NOT_SUPPORTED_SCRAP_MSG.format(row_num=row[0].row, scrap=scrap))
            continue

        weight = row[SCRAP_ON_THE_WAY_SCRAP_WEIGHT_COL_IDX].value
        if not isinstance(weight, (int, float)):
            if weight is None:
                errors.append(NOT_DEFINED_WEIGHT_MSG.format(row_num=row[0].row))
            else:
                errors.append(
                    NOT_NUMERIC_VALUE_MSG.format(row_num=row[0].row, entity="váha", value=weight, scrap=scrap)
                )
            continue
        parsed_data.append(
            ScrapParsedData(input_scrap_type=str(scrap).strip(), weight=weight, scrap_type=None)
        )

    if not parsed_data:
        errors = [DATA_NOT_FOUND_MSG, *errors]

    return tuple(parsed_data), tuple(errors)


def parse_scrap_excel_file(
    file_bytes: io.BytesIO,
) -> Tuple[Tuple[ScrapOfferParsedRecord, ...], Tuple[str, ...]]:
    work_book = load_workbook(filename=file_bytes)
    last_sheet_name = work_book.sheetnames[-1]
    sheet = work_book[last_sheet_name]
    parsed_data: List[ScrapOfferParsedRecord] = list()
    errors: List[str] = []

    # find offset of table
    column_offset = sheet.min_column
    row_offset = sheet.min_row

    max_column = sheet.max_column
    max_row = sheet.max_row

    for row in sheet.iter_rows(
        min_row=row_offset + 1,
        min_col=column_offset,
        max_col=max_column,
        max_row=max_row,
        values_only=False,
    ):
        supplier = row[SCRAP_OFFER_SUPPLIER_COL_IDX].value
        note = row[SCRAP_OFFER_NOTE_COL_IDX].value
        station = row[SCRAP_OFFER_STATION_COL_IDX].value
        country = row[SCRAP_OFFER_COUNTRY_COL_IDX].value
        zone = row[SCRAP_OFFER_ZONE_COL_IDX].value
        scrap = preprocess_scrap_data(row[SCRAP_OFFER_SCRAP_TYPE_COL_IDX].value)
        if scrap not in SUPPORTED_SCRAP_TYPES:
            if scrap is None:
                errors.append(NOT_DEFINED_SCRAP_MSG.format(row_num=row[0].row))
            else:
                errors.append(NOT_SUPPORTED_SCRAP_MSG.format(row_num=row[0].row, scrap=scrap))
            continue

        quantity = row[SCRAP_OFFER_QUANTITY_COL_IDX].value
        if not isinstance(quantity, (int, float)):
            if quantity is None:
                errors.append(NOT_DEFINED_WEIGHT_MSG.format(row_num=row[0].row))
            else:
                errors.append(
                    NOT_NUMERIC_VALUE_MSG.format(
                        row_num=row[0].row, entity="váha", value=quantity, scrap=scrap
                    )
                )
            continue

        price = row[SCRAP_OFFER_PRICE_COL_IDX].value
        if not isinstance(price, (int, float)):
            if price is None:
                errors.append(NOT_DEFINED_PRICE_MSG.format(row_num=row[0].row))
            else:
                errors.append(
                    NOT_NUMERIC_VALUE_MSG.format(row_num=row[0].row, entity="cena", value=price, scrap=scrap)
                )
            continue

        if all(v is None for v in [supplier, scrap, quantity, price, zone, station, country, note]):
            continue

        parsed_data.append(
            ScrapOfferParsedRecord(
                input_supplier=supplier,
                supplier=None,
                input_scrap_type=scrap,
                scrap_type=None,
                quantity=quantity,
                price=price,
                zone=zone,
                station=station,
                country=country,
                note=note,
            )
        )

    if not parsed_data:
        errors = [DATA_NOT_FOUND_MSG, *errors]

    return tuple(parsed_data), tuple(errors)


def assign_scrap_supplier_to_scrap_offer_data(
    parsed_data: Tuple[ScrapOfferParsedRecord, ...]
) -> Tuple[ScrapOfferParsedRecord, ...]:
    assigned_data = list()
    for scrap_offer in parsed_data:
        input_scrap_supplier_name = scrap_offer.input_supplier
        scrap_supplier_obj: Optional[ScrapSupplier]
        try:
            scrap_supplier_obj = ScrapSupplier.objects.get(name=input_scrap_supplier_name)
        except Exception:  # pylint: disable=broad-except
            scrap_supplier_obj = None

        if scrap_supplier_obj is None:
            try:
                scrap_supplier_mapping_obj = ScrapSupplierMapping.objects.get(
                    input_scrap_supplier=input_scrap_supplier_name
                )
                scrap_supplier_obj = scrap_supplier_mapping_obj.scrap_supplier
            except Exception:  # pylint: disable=broad-except
                scrap_supplier_obj = None

        if scrap_supplier_obj is None:
            assigned_scrap_supplier_name = None
        else:
            assigned_scrap_supplier_name = scrap_supplier_obj.name
        assigned_data.append(scrap_offer.update_field(supplier=assigned_scrap_supplier_name))
    return tuple(assigned_data)


# method used when importing scrap purchase history using management command
def parse_scrap_purchase_history_excel_file(file_bytes: io.BytesIO) -> Tuple[ScrapPurchase, ...]:
    work_book = load_workbook(filename=file_bytes)
    sheet_with_data = work_book.sheetnames[0]
    sheet = work_book[sheet_with_data]

    # find offset of table
    column_offset = sheet.min_column
    row_offset = sheet.min_row

    max_column = sheet.max_column
    max_row = sheet.max_row

    parsed_scrap_purchase_list = list()
    for idx, row in enumerate(
        sheet.iter_rows(
            min_row=row_offset + SCRAP_PURCHASE_HISTORY_ROW_OFFSET,
            min_col=column_offset,
            max_col=max_column,
            max_row=max_row,
            values_only=False,
        )
    ):
        supplier = row[SCRAP_PURCHASE_HISTORY_SUPPLIER_COL_IDX].value
        grade = row[SCRAP_PURCHASE_HISTORY_GRADE_COL_IDX].value
        zone = row[SCRAP_PURCHASE_HISTORY_ZONE_COL_IDX].value
        purchased_month = row[SCRAP_PURCHASE_HISTORY_MONTH_COL_IDX].value
        purchased_year = row[SCRAP_PURCHASE_HISTORY_DELIVERY_YEAR_COL_IDX].value
        purchased_quantity = row[SCRAP_PURCHASE_HISTORY_QUANTITY_COL_IDX].value
        purchased_price = row[SCRAP_PURCHASE_HISTORY_PRICE_COL_IDX].value

        supplier = None if supplier is None else str(supplier).strip()
        grade = None if grade is None else str(grade).strip()
        zone = None if zone is None else str(zone).strip()
        purchased_month = None if purchased_month is None else purchased_month
        purchased_year = None if purchased_year is None else purchased_year
        purchased_quantity = None if purchased_quantity is None else float(purchased_quantity)
        purchased_price = None if purchased_price is None else float(purchased_price)

        if all(
            v is None
            for v in [
                supplier,
                grade,
                zone,
                purchased_month,
                purchased_year,
                purchased_quantity,
                purchased_price,
            ]
        ):
            continue

        supplier_obj: Optional[ScrapSupplier]
        try:
            supplier_obj = ScrapSupplier.objects.get(name=supplier)
        except ObjectDoesNotExist:
            supplier_obj = None

        if supplier_obj is None:
            try:
                supplier_mapping_obj = ScrapSupplierMapping.objects.get(input_scrap_supplier=supplier)
                supplier_obj = supplier_mapping_obj.scrap_supplier
            except ObjectDoesNotExist:
                pass

        if supplier_obj is None:
            record = (
                idx,
                supplier,
                grade,
                zone,
                purchased_month,
                purchased_year,
                purchased_quantity,
                purchased_price,
            )
            log.warning(
                f"Can't identify supplier for {record} record, "
                f"please add new supplier or update supplier mappings as needed"
            )
            continue

        purchase_date = datetime.date(
            year=purchased_year,
            month=purchased_month,
            day=1,
        )
        new_scrap_purchase_object = ScrapPurchase(
            supplier=supplier_obj,
            scrap_type=grade,
            zone=zone,
            date=purchase_date,
            quantity=purchased_quantity,
            price=purchased_price,
        )
        parsed_scrap_purchase_list.append(new_scrap_purchase_object)
    return tuple(parsed_scrap_purchase_list)


def assign_scrap_type_to_scrap_offers_data(
    parsed_data: Tuple[ScrapOfferParsedRecord, ...]
) -> Tuple[ScrapOfferParsedRecord, ...]:
    assigned_scrap_type_records = list()
    mapped_scrap_type: Optional[str]
    for parsed_record in parsed_data:
        mapped_scrap_type = get_supported_scrap_type(
            parsed_record.input_scrap_type, get_supported_scrap_type_from_db
        )
        assigned_scrap_type_records.append(parsed_record.update_field(scrap_type=mapped_scrap_type))
    return tuple(assigned_scrap_type_records)


def assign_scrap_type_to_scrap_state_data(
    parsed_data: Tuple[ScrapParsedData, ...]
) -> Tuple[ScrapParsedData, ...]:
    assigned_scrap_type_records = list()
    mapped_scrap_type: Optional[str]
    for parsed_record in parsed_data:
        mapped_scrap_type = get_supported_scrap_type(
            parsed_record.input_scrap_type, get_supported_scrap_type_from_db
        )
        assigned_scrap_type_records.append(
            ScrapParsedData(
                scrap_type=mapped_scrap_type,
                input_scrap_type=parsed_record.input_scrap_type,
                weight=parsed_record.weight,
            )
        )
    return tuple(assigned_scrap_type_records)


def get_supported_scrap_type(
    input_scrap_type: Optional[str], get_scrap_type: Callable[[str], Optional[str]]
) -> Optional[str]:
    if input_scrap_type is None:
        return None
    if input_scrap_type in SUPPORTED_SCRAP_TYPES:
        return input_scrap_type
    return get_scrap_type(input_scrap_type)


def get_supported_scrap_type_from_db(input_scrap_type: str) -> Optional[str]:
    scrap_type_mappings = SupportedScrapTypeMapping.objects.all().values()
    try:
        return scrap_type_mappings.get(input_scrap_type=input_scrap_type)["scrap_type"]
    except Exception:  # pylint: disable=broad-except
        return None
