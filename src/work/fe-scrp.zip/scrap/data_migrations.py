"""
Python module intended for data db migrations. A data migration is a (one time) dramatiq task.
The module contains some utility functions, too.
"""

import itertools
import logging
from typing import Iterable, Type, List, TypeVar

from django.db import models


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


DjangoModel = TypeVar("DjangoModel", bound=models.Model)


BATCH_SIZE_READ = 1024 * 4
BATCH_SIZE_WRITE = 1024 * 2

NEGLIGIBLE_LIMIT = 100


# copied from https://stackoverflow.com/questions/29082693/django-bulk-create-lead-to-memory-error
def bulk_create_iter(model: Type[DjangoModel], to_create: Iterable[DjangoModel], batch_size: int) -> int:
    """Bulk create supporting generators. Returns only count of created objects."""
    counter = 0

    while True:
        objects = model.objects.bulk_create(itertools.islice(to_create, batch_size))
        counter += len(objects)

        if not objects:
            break

    return counter


def bulk_update_iter(
    model: Type[DjangoModel], to_update: Iterable[DjangoModel], fields: List[str], batch_size: int
) -> int:
    """Bulk update supporting generators. Returns only count of updated objects."""
    counter = 0

    while True:
        updated_num = model.objects.bulk_update(itertools.islice(to_update, batch_size), fields)
        counter += updated_num

        if not updated_num:
            break

    return counter
