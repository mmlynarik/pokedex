import functools
import logging
from datetime import date, datetime, timedelta
from typing import List

import dramatiq
import pytz
from django.core import management
from django.db import transaction
from django_dramatiq.apps import RATE_LIMITER_BACKEND
from django_dramatiq.tasks import delete_old_tasks
from dramatiq.middleware import TimeLimitExceeded
from dramatiq.rate_limits import ConcurrentRateLimiter
from periodiq import cron

from scrap.models import (
    MultipleHeatsOptimizationResult,
    PigIronAnalysisResult,
    ScrapCharge,
    ScrapPurchaseOptimizationOutput,
    ScrapPurchaseOptimizationResult,
    YieldCalculationModelResult,
)
from scrap.tasksimpl.auto_grade_groups import (
    save_grade_groups_by_casting_group,
    save_grade_groups_by_max_ni,
    save_grade_groups_by_max_s,
    save_grade_groups_by_max_p,
)
from scrap.tasksimpl.print_job import send_print_job
from scrap.utils import get_submodel_results_calculator
from scrap.weightingticket.ticket import generate_weighting_ticket_pdf, save_pdf
from scrap_core.datamodel import Heat
from scrap_core.datamodel.oko import load_heats_from_oko_for_time_range
from scrap_core.optimization.datamodel import MultipleHeatsOptimizationOutput
from scrap_core.optimization.linprog_optimizer import optimize_multiple_heats
from scrap_core.pigironanalysis import (
    create_exponential_weighted_average_predictor,
    create_median_predictor,
    get_prediction_for_chem,
)
from scrap_core.yieldmodel.yield_model_filter import get_extended_heats_data
from scrap_core.yieldmodel.yield_model_precise import prepare_heats

from .dash.database_api import get_oko_db, steel_grades
from .scrap_purchase.common import (
    ScrapPurchaseOptimizationError,
    ScrapPurchaseRelaxationError,
)
from .scrap_purchase.constraints import verify_scrap_weight_constraint
from .scrap_purchase.optimization import (
    calculate_buy_all_recommendations,
    calculate_recommendations,
)
from .scrap_purchase.warning import (
    get_infeasible_constraints_warning,
    get_not_enough_scrap_warning,
)
from .tasksimpl.evaluation import (
    evaluate_scrap_charges,
)
from .tasksimpl.yieldmodel import (
    create_results_for_windows,
    get_frontend_warnings_df,
    get_results_for_weighted_avg_graph,
    load_heats_from_oko,
    recalculate,
    save_with_progress,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


# TODO In `django_dramatiq >= 0.10.0` rate limiter backend is probably accessible as
#    `DjangoDramatiqConfig.get_rate_limiter_backend()`, too
# Avoid running multiple instances of closed heat evaluation report task at once,
# see https://dramatiq.io/cookbook.html#rate-limiting for more info
SCRAP_CHARGE_EVALUATION_REPORT_MUTEX = ConcurrentRateLimiter(
    RATE_LIMITER_BACKEND, "closed-heat-evaluation-report-distributed-mutex", limit=1
)


@dramatiq.actor(
    time_limit=1000 * 60 * 60 * 3,  # 3 hours
    max_retries=3,
    min_backoff=1000 * 60,  # 1 minute
    max_backoff=1000 * 60 * 60,  # 60 minute
)
def yield_calculation(input_id: int):
    try:
        logging.info(f"Yield calculation {input_id} - Starting")
        oko_db = get_oko_db()
        db_result = YieldCalculationModelResult.objects.get(pk=input_id)
        save_with_progress(db_result, 0.0)
        logging.info(f"Yield calculation {input_id} - Loading data started")
        all_heats = load_heats_from_oko(db_result, oko_db, validation=False)
        db_data_for_heats = get_extended_heats_data(db_result.data_from, db_result.data_to, oko_db)
        logging.info(f"Yield calculation {input_id} - Loading data finished")

        logging.info(f"Yield calculation {input_id} - Enabling validation")
        for heat in all_heats:
            heat.enable_on_access_validation()
        logging.info(f"Yield calculation {input_id} - Preparing heats")
        valid_heats_for_training, errors = prepare_heats(all_heats, db_data_for_heats)

        for error in errors:
            logging.warning(f"Yield calculation {input_id} - Following heat is invalid: {error}")
        db_result.comparison_graph_data = recalculate(valid_heats_for_training)
        db_result.graph_data = create_results_for_windows(valid_heats_for_training, db_result.window_size)
        db_result.average_graph_data = get_results_for_weighted_avg_graph(
            valid_heats_for_training, all_heats, db_result.window_size
        )
        db_result.frontend_warnings = get_frontend_warnings_df(db_result.average_graph_data, errors)
        save_with_progress(db_result, 100.0)
        logging.info(f"Yield calculation {input_id} - Done")
    except (Exception, TimeLimitExceeded) as e:  # pylint: disable=broad-except
        logging.error(f"Yield calculation {input_id} - Failed - {e}")
        try:
            YieldCalculationModelResult.objects.filter(pk=input_id).update(
                status=YieldCalculationModelResult.ResultStatus.ERROR, progress=0.0
            )
        except Exception as db_e:  # pylint: disable=broad-except
            logging.exception(f"Yield calculation {input_id} - Failed to write error state to db - {db_e}")
        raise e


# -----
# Utils
# -----


# This is same as optimization tasks for BF
# TODO make common task framework
def set_starting_state_v2(input_id: int) -> MultipleHeatsOptimizationResult:
    log.info("Opt %d: starting multiple heats scrap optimization ...", input_id)
    db_result = MultipleHeatsOptimizationResult.objects.get(pk=input_id)
    db_result.status = MultipleHeatsOptimizationResult.ResultStatus.RUNNING
    db_result.progress = 0.0
    db_result.save()
    return db_result


def progress_callback_linprog(
    db_result: MultipleHeatsOptimizationResult,
    progress: float,
    info: str,
    save_progress: bool = True,
):
    log.info("Opt %d: progress %d msg: %s", db_result.pk, round(progress), info)
    if save_progress and (progress - db_result.progress) > 1.0:
        db_result.progress = progress
        db_result.save()


# -----
# Actor
# -----


def optimize_multiple_heats_in_current_worker(
    db_result: MultipleHeatsOptimizationResult,
) -> MultipleHeatsOptimizationOutput:
    log.info("Opt %d: running multiple heats optimization in current worker", db_result.pk)
    callback = functools.partial(progress_callback_linprog, db_result)

    return optimize_multiple_heats(db_result.input_data, callback)


def save_result_to_db_v2(
    db_result: MultipleHeatsOptimizationResult,
    result: MultipleHeatsOptimizationOutput,
) -> None:

    db_result.result = result  # type: ignore

    db_result.status = (
        db_result.ResultStatus.FINISHED if result.error is None else db_result.ResultStatus.ERROR
    )

    db_result.progress = 100.0

    if result.error is None:
        opt_input = db_result.optimization_input
        first_charge = opt_input.charge_inputs.get(order_index=0)

        submodel_calculator = get_submodel_results_calculator(
            first_charge.pig_iron_weight,
            steel_grades.get_grade_from_id(first_charge.grade_def.grade_id, db_result.created_at.date()),
            first_charge.pig_iron_chem,
            opt_input.model_settings,
        )

        submodel_results = submodel_calculator(db_result.result.first_heat_scrap_weights)

        db_result.corr_tech_chems = submodel_results["used_predicted_chems"]
        db_result.corr_tech_model_output = submodel_results["corr_tech_model_output"]
        db_result.blend_model_output = submodel_results["blend_model_output"]
    else:
        log.error("Opt %d: scrap charge optimization failed with error: %s", db_result.pk, result.error)

    db_result.save()
    log.info("Opt %d: scrap charge optimization finished.", db_result.pk)


@dramatiq.actor(
    time_limit=1000 * 60 * 3,  # 3 minutes
    max_retries=3,
    min_backoff=1000,  # 1 second
    max_backoff=1000 * 3,  # 3 seconds,
)
def multiple_heats_scrap_optimization(input_id: int):
    db_result = set_starting_state_v2(input_id)
    result = optimize_multiple_heats_in_current_worker(db_result)
    save_result_to_db_v2(db_result, result=result)


# time limit, retries and backoff are added
# due to unreliable handling of concurrent requests on `sqlite` side
@dramatiq.actor(
    periodic=cron("0 0 * * *"),
    time_limit=1000 * 60 * 3,  # 3 minutes
    max_retries=3,
    min_backoff=1000,  # 1 second
    max_backoff=1000 * 3,  # 3 seconds,
)
def delete_old_dramatiq_tasks():
    max_task_age = 24  # in hours
    delete_old_tasks.send(max_task_age * 3600)
    log.info(
        f"All records older than {max_task_age} hours were removed from the table 'django_dramatiq_task'."
    )


@dramatiq.actor(
    periodic=cron("0 0 * * *"),
    time_limit=1000 * 60 * 3,  # 3 minutes
    max_retries=3,
    min_backoff=1000,  # 1 second
    max_backoff=1000 * 3,  # 3 seconds,
)
def delete_expired_sessions():
    """
    Remove expired sessions on regular basis,
    see https://docs.djangoproject.com/en/5.1/topics/http/sessions/ - Clearing the session store
    """
    management.call_command("clearsessions")
    log.info("Expired sessions were removed successfully.")


@dramatiq.actor(
    periodic=cron("0 */4 * * *"),
    time_limit=1000 * 60 * 60 * 24,  # 12 hours (due to reevaluation of longer periods, e.g. 1 year)
    max_retries=3,
    min_backoff=1000 * 60 * 45,  # 5 minutes
    max_backoff=1000 * 60 * 60,  # 15 minutes,
)
def calculate_scrap_charge_evaluations(
    dt_from_iso: str = "", dt_to_iso: str = "", force_refresh: bool = False
) -> None:
    time_tolerance = timedelta(hours=24)

    # auto call by periodiq
    if not dt_from_iso and not dt_to_iso:

        # observe that this task is being triggered every 4th hour (see periodic parameter above),
        # hence together with 24 hours evaluation window [dt_from, dt_to) - see below,
        # each scrap charge with failed evaluation (not mapped, error, etc.)
        # has exactly 24 / 4 = 6 attempts to be evaluated
        dt_to = datetime.now(tz=pytz.utc)
        dt_from = dt_to - timedelta(hours=24)

        log.info(
            f"Scrap charge evaluation of data between {dt_from} "
            f"and {dt_to} has been triggered automatically by periodiq"
        )

    # manual call by user
    else:
        dt_from = datetime.fromisoformat(dt_from_iso)
        dt_to = datetime.fromisoformat(dt_to_iso)

        log.info(
            f"Scrap charge evaluation of data between {dt_from} "
            f"and {dt_to} has been triggered manually by user"
        )

    with SCRAP_CHARGE_EVALUATION_REPORT_MUTEX.acquire(raise_on_failure=False) as acquired:

        if not acquired:
            log.warning(
                "Can't trigger 'calculate_scrap_charge_evaluations' task, "
                "another instance is already running"
            )
            return

        evaluate_scrap_charges(
            dt_from,
            dt_to,
            force_refresh=force_refresh,
            time_tolerance=time_tolerance,
        )

        log.info("Scrap charge evaluation finished successfully")


@dramatiq.actor(
    periodic=cron("0 6 * * *"),  # run every day at 8AM (6 AM due to UTC)
    time_limit=1000 * 60 * 30,  # 30 minutes
    max_retries=3,
    min_backoff=1000 * 60 * 45,  # 45 minutes
    max_backoff=1000 * 60 * 60,  # 1 hour,
)
def pig_iron_analysis():
    log.info("Pig Iron analysis - Starting")
    heats: List[Heat] = []
    oko_db = get_oko_db()
    timestamp_now = datetime.utcnow()
    load_heats_from_oko_for_time_range(
        timestamp_now - timedelta(days=42),  # most we use is 1582 heats, should be within 6 weeks
        timestamp_now,
        oko_db,
        steel_grades,
        heat_loaded_callback=heats.append,
        error_callback=lambda key, error: None,
        validation=True,
    )

    with transaction.atomic():
        PigIronAnalysisResult(
            chem="Cr",
            value=get_prediction_for_chem(heats, create_exponential_weighted_average_predictor(265), "Cr"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Cr done")
        PigIronAnalysisResult(
            chem="Cu",
            value=get_prediction_for_chem(heats, create_exponential_weighted_average_predictor(265), "Cu"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Cu done")
        PigIronAnalysisResult(
            chem="Mo",
            value=get_prediction_for_chem(heats, create_median_predictor(265), "Mo"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Mo done")
        PigIronAnalysisResult(
            chem="Ni",
            value=get_prediction_for_chem(heats, create_median_predictor(751), "Ni"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Ni done")
        PigIronAnalysisResult(
            chem="Sn",
            value=get_prediction_for_chem(heats, create_median_predictor(544), "Sn"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Sn done")
        PigIronAnalysisResult(
            chem="Si",
            value=get_prediction_for_chem(heats, create_median_predictor(1582), "Si"),
            timestamp=timestamp_now,
        ).save()
        log.info("Pig Iron analysis - Si done")

    log.info("Pig Iron analysis - Finished")


@dramatiq.actor(
    **{"time_limit": 1000 * 60 * 10, "max_retries": 3, "min_backoff": 1000, "max_backoff": 1000 * 3}
)
def calculate_optimal_scrap_purchase(
    optimization_result_id: int,
) -> None:
    optimization_result = ScrapPurchaseOptimizationResult.objects.get(pk=optimization_result_id)

    try:
        # Set starting state
        optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.RUNNING
        optimization_result.progress = 0.0
        optimization_result.save()
        log.info(f"State of scrap purchase optimization with ID {optimization_result.pk} changed to RUNNING")
        df_agg = (
            optimization_result.input_data.to_dataframe()
            .groupby("record_type")
            .sum()
            .reset_index()[["record_type", "weight"]]
        )

        log.info(f"Aggregated optimization input:\n{df_agg}")

        error = None
        warning = None

        input_data = optimization_result.input_data

        df_grouped = input_data.to_dataframe_grouped()

        # make sure that we have enough scrap for optimization,
        # otherwise, return trivial recommendations (buy all)
        if verify_scrap_weight_constraint(
            df_grouped,
            input_data.expected_steel_production,
            input_data.scrap_stock_objective_in_kgs,
            input_data.mean_scrap_ratio,
        ):
            try:
                recommendations, infeasible_constraint_names = calculate_recommendations(
                    optimization_result.input_data
                )
                optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.FINISHED

                if infeasible_constraint_names:
                    log.warning(
                        f"Scrap Purchase Optimization {optimization_result.pk} failed in standard mode, "
                        f"but found recommendations using relaxed constraints {infeasible_constraint_names}"
                    )
                    warning = get_infeasible_constraints_warning(infeasible_constraint_names)

                log.info(f"Scrap Purchase Optimization {optimization_result.pk} successful")

            except ScrapPurchaseOptimizationError:
                recommendations = None
                optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.ERROR
                log.exception(
                    f"Scrap Purchase Optimization {optimization_result.pk} failed due to unexpected error"
                )
                error = f"Pri optimalizácii {optimization_result.pk} došlo k neočakávanej chybe, kontaktujte prosím IT"

            except ScrapPurchaseRelaxationError:
                recommendations = None
                optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.ERROR
                log.exception(
                    f"Scrap Purchase Optimization {optimization_result.pk} failed due to relaxation error"
                )
                error = (
                    f"Pri optimalizácii {optimization_result.pk} došlo k chybe, nie je možné nájsť odporúčanie "
                    f"ani za relaxovaných podmienok. Pridajte ďalšie ponuky s dostupným šrotom alebo upravte "
                    f"vstupné parametre ako očakávaná produkcia ocele, priemerná hmotnosť šrotovej vsádzky, "
                    f"a pod. a spustite optimalizáciu znova."
                )

        else:
            recommendations = calculate_buy_all_recommendations(input_data.scrap_offers)
            optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.FINISHED

            warning = get_not_enough_scrap_warning(
                df_scrap=df_grouped,
                expected_steel_production=input_data.expected_steel_production,
                scrap_stock_objective_in_kgs=input_data.scrap_stock_objective_in_kgs,
                mean_scrap_ratio=input_data.mean_scrap_ratio,
            )
            log.warning(f"Scrap Purchase Optimization {optimization_result.pk} - not enough scrap\n{warning}")

        optimization_result.output_data = ScrapPurchaseOptimizationOutput(
            error=error, warning=warning, recommendations=recommendations
        )

        # TODO add progress callback
        optimization_result.progress = 100.0
        optimization_result.save()

    except TimeLimitExceeded:
        error = (
            f"Optimalizácia {optimization_result.pk} neskončila "
            f"v rámci vyhradeného 10 minútového intervalu, kontaktujte prosím IT."
        )

        log.exception(error)

        optimization_result.output_data = ScrapPurchaseOptimizationOutput(error=error)
        optimization_result.status = ScrapPurchaseOptimizationResult.ResultStatus.ERROR
        optimization_result.save()


@dramatiq.actor(
    periodic=cron("0 5 * * *"),  # run every day at 5AM UTC
    time_limit=1000 * 60 * 10,  # 10 minutes
    max_retries=1,
    min_backoff=1000 * 60 * 5,  # 5 minutes
    max_backoff=1000 * 60 * 60,  # 1 hour,
)
def refresh_automatic_grade_groups():
    log.info("Automatic grade group calculation started")
    try:
        save_grade_groups_by_max_s(date.today())
        save_grade_groups_by_casting_group(date.today())
        save_grade_groups_by_max_ni(date.today())
        save_grade_groups_by_max_p(date.today())
    except TimeLimitExceeded:
        log.warning("Automatic grade group calculation timeouted")
        raise
    except Exception:
        log.exception("Automatic grade group calculation ended up with error")
        raise
    log.info("Automatic grade group calculation finished")


@dramatiq.actor(
    time_limit=1000 * 15,  # 15 seconds
    max_retries=3,
    min_backoff=1000 * 60,  # 1 minutes
    max_backoff=1000 * 60 * 3,  # 3 minutes,
)
def print_and_save_weighting_ticket(scrap_charge_id: int) -> None:
    log.info(f"Print and save ticket was started for scrap charge id: {scrap_charge_id}")
    try:
        scrap_charge = ScrapCharge.objects.get(id=scrap_charge_id)
    except ScrapCharge.DoesNotExist:
        log.exception("It's not possible to print and save ticket because scrap charge doesn't exist.")
        return

    log.info("Generate pdf document from scrap charge data.")
    document = generate_weighting_ticket_pdf(scrap_charge)

    printer_conn = scrap_charge.loading_station.printer_connection
    if printer_conn.is_valid:
        send_print_job(printer_conn, document)
    else:
        log.warning(
            f"Print job was not sent to printer because printer connection is invalid: {printer_conn}"
        )

    save_pdf(document, scrap_charge)
