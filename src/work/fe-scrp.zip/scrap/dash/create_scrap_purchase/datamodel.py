import logging
from datetime import date, datetime
from typing import Any, Dict, Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from django.contrib.auth.models import User
from django.forms.models import model_to_dict
from scrap_core.utils import convert_tons_to_kilograms

from scrap.dash.components.create_scrap_purchase_stepper.stepper import CreatePurchaseStepperVM
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_mapping.datasource import (
    ScrapStateTableDataSource,
)
from scrap.dash.create_scrap_purchase.datasource import CreateScrapPurchaseModels
from scrap.dash.create_scrap_purchase.parser import create_scrap_offer_data
from scrap.models import (
    ProductionPlan,
    ScrapOfferParsedRecord,
    ScrapParsedData,
    ScrapState,
    ScrapPurchaseRecordDisplayData,
    ScrapPurchaseRecord,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.frozen
class CreateScrapPurchaseVM:
    LOGGED_USER_ID = "logged-user-id"

    purchase_stepper: CreatePurchaseStepperVM = sdc.child_component(
        "create-purchase", factory=CreatePurchaseStepperVM
    )
    logged_user_unstructure: Dict[str, Any] = sdc.one_way_binding(
        LOGGED_USER_ID,
        "data",
        default={},
    )

    @classmethod
    def load_initial_data(cls, *args, **kwargs) -> "CreateScrapPurchaseVM":  # pylint: disable=unused-argument
        models = CreateScrapPurchaseModels()
        logged_user: Optional[User] = kwargs.get("user")
        if logged_user is None:
            raise Exception("It's necesery to have the user logged in")

        session_state = kwargs.get("session_state", {})

        if "scrap_purchase_record_id" not in session_state:
            return cls(
                purchase_stepper=CreatePurchaseStepperVM.create(
                    models.user.get_all(), [logged_user], for_date=date.today()
                ),
                logged_user_unstructure=model_to_dict(logged_user, fields=["id", "username"]),
            )

        record = ScrapPurchaseRecord.objects.get(pk=session_state["scrap_purchase_record_id"])

        view_model = cls(
            purchase_stepper=CreatePurchaseStepperVM.create(
                models.user.get_all(),
                record.authorized_users.all(),
                for_date=record.purchase_date,
                purchase_record=record,
            ),
            logged_user_unstructure=model_to_dict(logged_user, fields=["id", "username"]),
        )

        log.info(f"(Initial) data for Scrap Purchase Record {record} has been loaded")

        return view_model

    @classmethod
    def get_layout(cls) -> html.Div:
        return html.Main(
            dmc.MantineProvider(
                theme={"colorScheme": "dark"},
                children=[
                    sdc.get_child_layout("", cls.purchase_stepper),
                    dcc.Store(sdc.create_id("", cls.LOGGED_USER_ID)),
                ],
            ),
        )

    @property
    def logged_user(self) -> User:
        return User(**self.logged_user_unstructure)


class CreateScrapPurchaseCtx:
    def __init__(self, parent: CreateScrapPurchaseVM):
        self.parent = parent

    @property
    def models(self) -> CreateScrapPurchaseModels:
        return CreateScrapPurchaseModels()

    @property
    def logged_user(self) -> User:
        return self.parent.logged_user

    @property
    def authorized_user_ids(self) -> Tuple[int, ...]:
        return self.parent.purchase_stepper.base_info.auth_users.authorized_user_ids

    @property
    def purchase_id(self) -> Optional[int]:
        return self.parent.purchase_stepper.purchase_record_id

    @property
    def purchase_name(self) -> str:
        return self.parent.purchase_stepper.base_info.name

    @property
    def purchase_date(self) -> date:
        return self.parent.purchase_stepper.base_info.purchase_date

    @property
    def scrap_mapping(self) -> Tuple[ScrapStateTableDataSource, ...]:
        return self.parent.purchase_stepper.scrap_state.scrap_mapping.data

    @property
    def scrap_state_parsed_data(self) -> Tuple[ScrapParsedData, ...]:
        return self.parent.purchase_stepper.scrap_state.pile_evidence.file_content

    @property
    def scrap_on_the_way_parsed_data(self) -> Tuple[ScrapParsedData, ...]:
        return self.parent.purchase_stepper.scrap_state.scrap_on_the_way.file_content

    @property
    def scrap_state_filename(self) -> Optional[str]:
        return self.parent.purchase_stepper.scrap_state.pile_evidence.filename

    @property
    def scrap_on_the_way_filename(self) -> Optional[str]:
        return self.parent.purchase_stepper.scrap_state.scrap_on_the_way.filename

    @property
    def scrap_stock_objective(self) -> Optional[int]:
        return self.parent.purchase_stepper.scrap_state.scrap_stock_objective.weight

    @property
    def mean_scrap_weight(self) -> Optional[int]:
        return self.parent.purchase_stepper.scrap_state.mean_scrap.weight

    @property
    def scrap_state_data(self) -> Tuple[ScrapState, ...]:
        return tuple(
            d.as_scrap_state_data for d in self.parent.purchase_stepper.scrap_state.scrap_overall_table.data
        )

    @property
    def production_plan_data(self) -> Tuple[ProductionPlan, ...]:
        return tuple(d.as_production_plan for d in self.parent.purchase_stepper.production_plan.table.data)

    @property
    def scrap_offer_parsed_data(self) -> Tuple[ScrapOfferParsedRecord, ...]:
        return self.parent.purchase_stepper.scrap_offers.file_content

    @property
    def scrap_offers_filename(self) -> Optional[str]:
        return self.parent.purchase_stepper.scrap_offers.filename

    @property
    def production_plan_weeks(self) -> Optional[int]:
        return self.parent.purchase_stepper.production_plan.weeks

    @property
    def production_plan_date(self) -> Optional[datetime]:
        return self.parent.purchase_stepper.production_plan.production_plan_date

    @property
    def user_defined_expected_production(self) -> Optional[int]:
        expected_production = (
            self.parent.purchase_stepper.production_plan.expected_production.user_defined_expected_production
        )
        return convert_tons_to_kilograms(expected_production) if expected_production is not None else None

    @property
    def export_slabs_weight(self) -> int:
        return self.parent.purchase_stepper.production_plan.export_slabs_weight

    @property
    def scrap_purchase_record_display_data(self) -> ScrapPurchaseRecordDisplayData:
        return ScrapPurchaseRecordDisplayData(
            scrap_state_filename=self.scrap_state_filename,
            scrap_on_the_way_filename=self.scrap_on_the_way_filename,
            production_plan_date=self.production_plan_date,
            scrap_stock_objective=self.scrap_stock_objective,
            mean_scrap_weight=convert_tons_to_kilograms(self.mean_scrap_weight),
            scrap_offer_data=create_scrap_offer_data(self.purchase_date, self.scrap_offer_parsed_data),
            parsed_scrap_offers_data=self.scrap_offer_parsed_data,
            scrap_offers_filename=self.scrap_offers_filename,
            parsed_scrap_state_data=self.scrap_state_parsed_data,
            parsed_scrap_on_the_way_data=self.scrap_on_the_way_parsed_data,
            scrap_state_data=self.scrap_state_data,
            production_plan_data=self.production_plan_data,
            production_plan_nr_of_weeks=self.production_plan_weeks,
            user_defined_expected_steel_production=self.user_defined_expected_production,
            export_slabs_weight=self.export_slabs_weight,
        )
