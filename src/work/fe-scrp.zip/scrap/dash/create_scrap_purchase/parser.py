from datetime import date
import logging
from typing import Optional
import uuid

from dateutil.relativedelta import relativedelta
from scrap_core import ScrapType

from scrap.models import (
    ScrapOffer,
    ScrapSupplierMapping,
    ScrapOfferData,
    ScrapOfferParsedData,
    ScrapPurchase,
    ScrapSupplier,
)
from scrap.utils import is_zone_domestic


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def get_scrap_purchase_for_last_month(
    purchase_date: date,
    scrap_type: Optional[ScrapType],
    scrap_zone: Optional[str],
    scrap_supplier: Optional[str],
) -> Optional[ScrapPurchase]:
    def month_diff(dta: date, dtb: date) -> int:
        diff = relativedelta(dta.replace(day=1), dtb.replace(day=1))
        return 12 * diff.years + diff.months

    if scrap_type is None or scrap_zone is None:
        return None

    filter_kwargs = {"scrap_type": scrap_type, "zone": scrap_zone, "date__lt": purchase_date}
    if not is_zone_domestic(scrap_zone):
        if scrap_supplier is None:
            return None
        filter_kwargs["supplier__name"] = scrap_supplier

    try:
        scrap_purchase = ScrapPurchase.objects.filter(**filter_kwargs).latest("date")
        previous_price_age = month_diff(purchase_date, scrap_purchase.date)
        if scrap_purchase.price is None or previous_price_age > 1:
            return None
        return scrap_purchase
    except ScrapPurchase.DoesNotExist:
        return None


def create_scrap_offer_data(
    purchase_date: date, parsed_scrap_offer_data: ScrapOfferParsedData
) -> ScrapOfferData:
    data = []

    suppliers = set(ScrapSupplier.objects.all().values_list("name", flat=True))

    supplier_mapping = dict(
        ScrapSupplierMapping.objects.all()
        .select_related("scrap_supplier")
        .values_list("input_scrap_supplier", "scrap_supplier__name")
    )

    # Add identity mapping for (standard) supplier names
    extended_supplier_mapping = {**supplier_mapping, **{supplier: supplier for supplier in suppliers}}

    for parsed_data in parsed_scrap_offer_data:
        scrap_purchase = get_scrap_purchase_for_last_month(
            purchase_date=purchase_date,
            scrap_type=parsed_data.scrap_type,
            scrap_zone=parsed_data.zone,
            scrap_supplier=extended_supplier_mapping.get(parsed_data.input_supplier),
        )

        if scrap_purchase is None:
            log.warning(f"No equivalent offer from previous month for offer {parsed_data}")

        data.append(
            ScrapOffer(
                scrap_type=parsed_data.scrap_type,
                zone=parsed_data.zone,
                station=parsed_data.station,
                weight=parsed_data.quantity,
                supplier=parsed_data.input_supplier,
                supplier_price=parsed_data.price,
                price_with_delta=None,
                recommendation=None,
                scrap_purchased=False,
                base_delta_rules=[],
                added_by_user=True,
                note=parsed_data.note,
                override_price=None,
                uuid=str(uuid.uuid4()),
                generated_from=None,
                last_month_price=None if scrap_purchase is None else scrap_purchase.price,
                last_month_price_added_manually=scrap_purchase is None,
                scrap_purchase_pk=-1 if scrap_purchase is None else scrap_purchase.id,
            )
        )
    return tuple(data)
