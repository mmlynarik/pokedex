import logging
from datetime import date, datetime
from functools import lru_cache
from typing import Any, Dict, Optional, Protocol, Tuple

import attr
import pytz
from django.contrib.auth.models import User
from scrap.models import ScrapPurchaseRecord, ScrapPurchaseRecordDisplayData, SupportedScrapTypeMapping
from usskssgrades.ispv_hook import IspvHook, PlannedHeatWeek
from vsadzka.settings import ISPV_DB

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


### Protocols
class IspvDatasource(Protocol):
    def get_production_plan(self, start_date: date, weeks: int) -> Optional[Tuple[PlannedHeatWeek, ...]]: ...


class SupportedScrapTypeMappingDatasource(Protocol):
    def save_scrap_mapping(self, scrap_type_mappings: Tuple[SupportedScrapTypeMapping, ...]) -> None: ...


class UsersDatasource(Protocol):
    def get_all(self) -> Tuple[User, ...]: ...


class ScrapPurchaseRecordDatasource(Protocol):
    def create(
        self,
        purchase_name: str,
        purchase_date: date,
        current_data: ScrapPurchaseRecordDisplayData,
        user_in_control: User,
        authorized_user_ids: Tuple[int, ...],
    ) -> int: ...

    def update(self, purchase_id: int, current_data: ScrapPurchaseRecordDisplayData) -> int: ...


class CreateScrapPurchaseModelsDatasource(Protocol):
    ispv: IspvDatasource
    supported_scrap_mapping: SupportedScrapTypeMappingDatasource
    user: UsersDatasource
    scrap_purchase_record: ScrapPurchaseRecordDatasource


### Implementations


class IspvData:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.ispv_db = IspvHook(config)

    def get_production_plan(self, start_date: date, weeks: int) -> Optional[Tuple[PlannedHeatWeek, ...]]:
        return self.ispv_db.get_midterm_heat_plan(start_dt=start_date, num_of_weeks=weeks)


@lru_cache(maxsize=16)
def get_cached_ispv_datasource(timestamp: int) -> IspvData:
    return IspvData(ISPV_DB)


class SupportedScrapTypeMappingData:
    def save_scrap_mapping(self, scrap_type_mappings: Tuple[SupportedScrapTypeMapping, ...]) -> bool:
        try:
            SupportedScrapTypeMapping.objects.bulk_create(scrap_type_mappings)
            return True
        except Exception:  # pylint: disable=broad-except
            log.exception("New scrap mapping can't be saved")
            return False


class UserData:
    def get_all(self) -> Tuple[User, ...]:
        return tuple(User.objects.all())


class ScrapPurchaseRecordData:
    def create(
        self,
        purchase_name: str,
        purchase_date: date,
        current_data: ScrapPurchaseRecordDisplayData,
        user_in_control: User,
        authorized_user_ids: Tuple[int, ...],
    ) -> int:
        try:
            record = ScrapPurchaseRecord(
                name=purchase_name,
                current_data=current_data,
                purchase_date=purchase_date,
                user_in_control=user_in_control,
            )
            record.save()
            record.authorized_users.set(authorized_user_ids)
            return record.id
        except Exception:
            log.exception(f"Creating the ScrapPurchaseRecordData failed")
        return -1

    def update(self, purchase_id: int, current_data: ScrapPurchaseRecordDisplayData) -> int:
        record = ScrapPurchaseRecord.objects.get(pk=purchase_id)

        try:
            record.current_data = attr.evolve(
                record.current_data,
                scrap_stock_objective=current_data.scrap_stock_objective,
                mean_scrap_weight=current_data.mean_scrap_weight,
                user_defined_expected_steel_production=current_data.user_defined_expected_steel_production,
                export_slabs_weight=current_data.export_slabs_weight,
            )
            record.save()
            return record.id

        except Exception:
            log.exception(f"Cannot update ScrapPurchaseRecord {record}")

        return -1


class CreateScrapPurchaseModels:
    def __init__(self) -> None:
        self.timestamp = int(datetime.now(tz=pytz.UTC).timestamp())

    @property
    def ispv(self) -> IspvData:
        return get_cached_ispv_datasource(self.timestamp)

    @property
    def supported_scrap_mapping(self) -> SupportedScrapTypeMappingData:
        return SupportedScrapTypeMappingData()

    @property
    def user(self) -> UserData:
        return UserData()

    @property
    def scrap_purchase_record(self) -> ScrapPurchaseRecordData:
        return ScrapPurchaseRecordData()
