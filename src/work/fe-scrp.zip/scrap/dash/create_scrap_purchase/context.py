from ussksdc.core.datamodel import JsCode


def get_clientside_context() -> JsCode:
    return JsCode(
        """
        class Context {
            constructor(viewModel){
                this.purchaseName = viewModel.purchase_stepper.base_info.name;
                this.purchaseDate = viewModel.purchase_stepper.base_info.purchase_date_str;

                this.pileEvidenceFilename = viewModel.purchase_stepper.scrap_state.pile_evidence.filename;
                this.scrapOnTheWay = viewModel.purchase_stepper.scrap_state.scrap_on_the_way.filename;
                this.meanScrap = viewModel.purchase_stepper.scrap_state.mean_scrap.weight;
                this.scrapStock = viewModel.purchase_stepper.scrap_state.scrap_stock_objective.weight;

                this.productionPlanDate = viewModel.purchase_stepper.production_plan.plan_date;
                this.productionPlanWeeks = viewModel.purchase_stepper.production_plan.weeks;
                this.expectedProduction = viewModel.purchase_stepper.production_plan.expected_production.expected_production;
                this.productionPlanedCount = viewModel.purchase_stepper.production_plan.table.unstructured_data.length;
                this.exportSlabs = viewModel.purchase_stepper.production_plan.export_slabs_weight;

                this.scrapOfferFilename = viewModel.purchase_stepper.scrap_offers.filename;
                this.scrapOfferCount = viewModel.purchase_stepper.scrap_offers.table.data.length;
            }
        }
        """
    )
