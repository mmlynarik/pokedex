from pathlib import Path

import ussksdc as sdc
from common.dash import DjangoPlotlyDashCallbackContext
from django_plotly_dash import DjangoDash
from scrap.dash.create_scrap_purchase.context import get_clientside_context
from scrap.dash.create_scrap_purchase.datamodel import CreateScrapPurchaseCtx, CreateScrapPurchaseVM
from vsadzka.settings import STATIC_ROOT

SLUG_APP = "create-scrap-purchase"
CREATE_SCRAP_PURCHASE_APP = "CreateScrapPurchase"

create_scrap_purchase_app = DjangoDash(
    CREATE_SCRAP_PURCHASE_APP, serve_locally=True, add_bootstrap_links=True
)

sdc.sdc_initialize_app(  # type: ignore
    create_scrap_purchase_app,
    CreateScrapPurchaseVM,
    CreateScrapPurchaseCtx,
    callback_context_getter=DjangoPlotlyDashCallbackContext,
    clientside_context_factory=get_clientside_context,
    assets_dir=Path(STATIC_ROOT) / "scrap/create_scrap_purchase/assets",
)
