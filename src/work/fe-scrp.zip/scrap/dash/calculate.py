import json
from datetime import date
from functools import lru_cache
from typing import List, Optional, Tuple, Dict

import plotly.graph_objects as go
import attr
import dash_bootstrap_components as dbc
from dash import dcc, html
from django.db import transaction

from usskssgrades import Grade
from scrap_core import Chem, SUPPORTED_SCRAP_TYPES, SUPPORTED_CHEMS
from common.dash import (
    create_bootstrap_column_with_header,
    create_main_div,
    create_bootstrap_column_with_header_and_dropdown,
)
from django_plotly_dash import DjangoDash
from django.shortcuts import get_object_or_404
from immutables import Map
from scrap_core.blendmodel import ScrapBlendModelInput
from scrap_core.blendmodel.datamodel import (
    convert_heat_to_scrap_blend_model_input,
    convert_heat_to_scrap_blend_model_output,
)
from scrap_core.datamodel import RawFeChem
from scrap_core.datamodel.model import Heat
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologiesModelInput
from scrap_core.optimization import get_all_models_from_model_settings
from scrap_core.optimization.datamodel import converter, HeatInputs, ModelSettings
from dash.dependencies import Input, Output, State
from scrap.models import (
    ClosedHeatEvaluationV2,
    MultipleHeatsOptimizationResult,
    MultipleHeatsOptimizationInput,
    LoadingStation,
    ScrapMixDefinition,
)
from scrap.dash.scrap_loading_station_2 import get_scrap_list_for_add_scrap_dropdown
from scrap.dash.components import get_scrap_type_label
from scrap.dash.components.ct_risks_table import (
    get_ct_risks_free_table_data,
    CTRiskTableData,
    create_ct_risks_table,
)
from scrap.dash.components.active_scrap_limits_table import (
    ActiveScrapLimitsTableData,
    create_active_scrap_limits_table,
    get_active_scrap_limits_model_table_data,
    get_active_scrap_limits_loaded_table_data,
    get_active_scrap_limits_free_table_data,
)
from scrap.dash.components.active_risk_limits_table import (
    ActiveRiskLimitsTableData,
    get_active_risk_limits_model_table_data,
    get_active_risk_limits_loaded_table_data,
    get_active_risk_limits_free_table_data,
    create_active_risk_limits_table,
)
from scrap.dash.components.blend_results_table import (
    BlendResultsTableData,
    create_results_table,
    create_results_table_data,
)
from scrap.dash.components.blend_results_plot import get_results_histogram_for_chem
from scrap.dash.components.raw_fe_chem_table import create_raw_fe_chem_table, RawFeChemTableData
from scrap.dash.components.scrap_table import (
    ScrapTableData,
    create_scrap_table,
    get_scrap_charge_model_table_data,
    get_scrap_table_data,
    register_add_scrap_callback,
    get_available_scrap_table_data,
)
from scrap.dash.components.selectors import create_grade_selector
from scrap.dash.database_api import steel_grades

calculate_scrap_app = DjangoDash("CalculateScrap", serve_locally=True, add_bootstrap_links=True)

INITIAL_DATA_STORE_ID = "initial-data"
SAVED_DATA_STORE_ID = "saved-data"
MAIN_DIV_ID = "scrap-model"
RAW_FE_INPUT_ID = "raw-fe-input"
RAW_FE_FREE_INPUT_ID = "raw-fe-free-input"
TOTAL_SCRAP_INPUT_ID = "total-scrap-input"
TOTAL_SCRAP_FREE_INPUT_ID = "total-scrap-free-input"
PELLETS_MODEL_INPUT_ID = "pellets-model-input"
BRIQUETS_MODEL_INPUT_ID = "briquets-model-input"
PELLETS_LOADED_INPUT_ID = "pellets-loaded-input"
BRIQUETS_LOADED_INPUT_ID = "briquets-loaded-input"
PELLETS_FREE_INPUT_ID = "pellets-free-input"
BRIQUETS_FREE_INPUT_ID = "briquets-free-input"
RAW_FE_CHEM_TABLE_ID = "raw-fe-chem-table"
RAW_FE_CHEM_FREE_TABLE_ID = "raw-fe-chem-free-table"
ACTIVE_RISK_LIMITS_MODEL_TABLE_ID = "active-risk-limits-model-table"
ACTIVE_RISK_LIMITS_LOADED_TABLE_ID = "active-risk-limits-loaded-table"
ACTIVE_RISK_LIMITS_FREE_TABLE_ID = "active-risk-limits-free-table"
RESULTS_TABLE_ID = "results-table"
RESULTS_PLOT = "results-plot"
RESULTS_CHEM_SELECTOR_ID = "results-chem"
SCRAP_CHARGE_MODEL_TABLE_ID = "scrap-charge-model-table"
SCRAP_CHARGE_LOADED_TABLE_ID = "scrap-charge-loaded-table"
SCRAP_CHARGE_FREE_TABLE_ID = "scrap-charge-free-table"
AVAILABLE_SCRAP_TABLE_ID = "available-scrap-table"
ADD_SCRAP_BUTTON_ID = "add-scrap"
SCRAP_MIX_MODEL_DROPDOWN_ID = "scrap-mix-model-dropdown"
SCRAP_MIX_LOADED_DROPDOWN_ID = "scrap-mix-loaded-dropdown"
SCRAP_MIX_FREE_DROPDOWN_ID = "scrap-mix-free-dropdown"
SCRAP_MIX_AVAILABLE_DROPDOWN_ID = "scrap-mix-available-dropdown"
ACTIVE_SCRAP_LIMITS_MODEL_TABLE_ID = "active-scrap-limits-model-table"
ACTIVE_SCRAP_LIMITS_LOADED_TABLE_ID = "active-scrap-limits-loaded-table"
ACTIVE_SCRAP_LIMITS_FREE_TABLE_ID = "active-scrap-limits-free-table"
CT_RISKS_TABLE_ID = "ct-risks-table"
GRADE_SELECTOR_ID = "grade-selector"
GRADE_FREE_SELECTOR_ID = "grade-free-selector"
ERROR_MODAL_ID = "error-modal"
VERDICT_INPUT_ID = "verdict-input"
VERDICT_BUTTON_ID = "verdict-button"


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class ScrapBlendModelInitialData:
    heat: Optional[Heat]
    evaluation_id: Optional[int] = None
    loading_station_id: Optional[int] = None
    verdict: Optional[str] = None
    verdict_user: Optional[str] = None

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self))

    def to_context_data(self) -> dict:
        # Better will be to assign data directly to components
        # Unfortunatelly it does not work for dash tables now :( so we need to use this hack
        return {INITIAL_DATA_STORE_ID: {"children": self.serialize()}}

    @property
    def not_initialized(self) -> bool:
        return self.heat is None and self.evaluation_id is None


@lru_cache()
def deserialize(serialized: Optional[str]) -> Optional[ScrapBlendModelInitialData]:
    if serialized is None:
        return None
    # TODO more explicit exception handling
    try:
        data = converter.structure(json.loads(serialized), ScrapBlendModelInitialData)
        return data
    except Exception:  # pylint: disable=bare-except
        return None


def create_number_input(
    input_id: str,
    label: str,
    min_value: Optional[float] = 0.0,
    step: Optional[float] = 1,
    required: bool = False,
    max_value: Optional[float] = None,
    debounce: bool = False,
    div_style: Optional[Dict[str, str]] = None,
    **kwargs,
) -> html.Div:
    return html.Div(
        [
            dbc.Label(label),
            dbc.Input(
                id=input_id,
                type="number",
                min=min_value,
                max=max_value,
                step=step,
                value=0.0,
                required=required,
                debounce=debounce,
                **kwargs,
            ),
        ],
        style=div_style,
    )


def get_constrained_analysis_inputs_card_component() -> dbc.Col:
    return dbc.Col(
        dbc.Row(
            [
                create_bootstrap_column_with_header(
                    "1. Plánovaný grade",
                    dbc.Row([dbc.Col(create_grade_selector(GRADE_SELECTOR_ID, disabled=True, style=None))]),
                ),
                create_bootstrap_column_with_header(
                    "2. Dostupný šrot",
                    dbc.Row(
                        [
                            dbc.Col(
                                create_scrap_table(
                                    AVAILABLE_SCRAP_TABLE_ID,
                                    SCRAP_MIX_AVAILABLE_DROPDOWN_ID,
                                    True,
                                    True,
                                ),
                            )
                        ]
                    ),
                ),
                create_bootstrap_column_with_header(
                    "3. Kovonosná vsádzka",
                    dbc.Row(
                        [
                            dbc.Col(
                                create_number_input(RAW_FE_INPUT_ID, "Surové železo [kg]", disabled=True),
                                width=12,
                                style={"margin-bottom": "5px"},
                            ),
                            dbc.Col(
                                create_number_input(
                                    TOTAL_SCRAP_INPUT_ID, "Objednaný šrot [kg]", disabled=True
                                ),
                                width=12,
                                style={"margin-top": "5px", "margin-bottom": "5px"},
                            ),
                            dbc.Col(
                                create_raw_fe_chem_table(
                                    RAW_FE_CHEM_TABLE_ID,
                                    read_only=True,
                                    estimate=True,
                                ),
                                style={"margin-top": "5px", "margin-bottom": "5px"},
                            ),
                        ],
                    ),
                ),
            ]
        ),
        sm=12,
        md=2,
        lg=2,
        xl=2,
        style={"backgroundColor": "rgba(255,255,255,0.45)"},
    )


def get_free_analysis_inputs_card_component() -> dbc.Col:
    return dbc.Col(
        dbc.Row(
            [
                create_bootstrap_column_with_header(
                    "1. Plánovaný grade",
                    dbc.Row(
                        [dbc.Col(create_grade_selector(GRADE_FREE_SELECTOR_ID, disabled=False, style=None))]
                    ),
                ),
                create_bootstrap_column_with_header(
                    "2. Kovonosná vsádzka",
                    dbc.Row(
                        [
                            dbc.Col(
                                create_number_input(RAW_FE_FREE_INPUT_ID, "Surové železo [kg]"),
                                width=12,
                                style={"margin-bottom": "5px"},
                            ),
                            dbc.Col(
                                create_number_input(
                                    TOTAL_SCRAP_FREE_INPUT_ID, "Objednaný šrot [kg]", disabled=True
                                ),
                                width=12,
                                style={"margin-top": "5px", "margin-bottom": "5px"},
                            ),
                            dbc.Col(
                                create_raw_fe_chem_table(RAW_FE_CHEM_FREE_TABLE_ID),
                                style={"margin-top": "5px", "margin-bottom": "5px"},
                            ),
                        ],
                    ),
                ),
            ]
        ),
        sm=12,
        md=2,
        lg=2,
        xl=2,
        style={"backgroundColor": "rgba(255,255,255,0.45)"},
    )


def get_pellets_briquets_input(pellets_id: str, briquets_id: str, read_only: bool = True) -> dbc.Col:
    return dbc.Col(
        dbc.Row(
            [
                dbc.Col(
                    create_number_input(
                        pellets_id,
                        "Pelety [kg]",
                        disabled=read_only,
                        div_style={"margin": "0px"},
                        required=True,
                    ),
                    width=6,
                ),
                dbc.Col(
                    create_number_input(
                        briquets_id,
                        "Brikety [kg]",
                        disabled=read_only,
                        div_style={"margin": "0px"},
                        required=True,
                    ),
                    width=6,
                ),
            ],
        ),
        style={"margin": "5px"},
    )


def get_active_scrap_limits_table_with_header(table_id: str, header: str) -> dbc.Col:
    return create_bootstrap_column_with_header(
        header,
        dcc.Loading(dbc.Row([dbc.Col(create_active_scrap_limits_table(table_id), width=12)])),
        sm=12,
        md=6,
        lg=6,
        xl=6,
    )


def get_active_risk_limits_table_with_header(table_id: str, header: str) -> dbc.Col:
    return create_bootstrap_column_with_header(
        header,
        dcc.Loading(dbc.Row([dbc.Col(create_active_risk_limits_table(table_id), width=12)])),
        sm=12,
        md=3,
        lg=3,
        xl=3,
    )


def get_ct_risks_table_with_header(table_id: str, header: str) -> dbc.Col:
    return create_bootstrap_column_with_header(
        header,
        dcc.Loading(dbc.Row([dbc.Col(create_ct_risks_table(table_id), width=12)])),
        sm=12,
        md=3,
        lg=3,
        xl=3,
    )


def get_scrap_charge_table_with_addons(
    header: str,
    scrap_table_id: str,
    dropdown_id: str,
    pellets_id: str,
    briquets_id: str,
    table_read_only: bool = False,
    addons_read_only: bool = True,
    header_weight: str = "normal",
) -> dbc.Col:
    return dbc.Col(
        dbc.Row(
            [
                create_bootstrap_column_with_header(
                    header,
                    dbc.Row(
                        [
                            dbc.Col(
                                create_scrap_table(scrap_table_id, dropdown_id, True, table_read_only),
                                width=12,
                            )
                        ]
                    ),
                    font_weight=header_weight,
                ),
                get_pellets_briquets_input(pellets_id, briquets_id, addons_read_only),
            ]
        ),
        sm=12,
        md=3,
        lg=3,
        xl=3,
    )


def get_verdict_input_row(disabled: bool = True) -> html.Div:
    return html.Div(
        dbc.Row(
            [
                dbc.Col(
                    dbc.Input(
                        id=VERDICT_INPUT_ID,
                        type="text",
                        debounce=True,
                        placeholder="Zadaj verdikt k naloženej vsádzke",
                    ),
                    width=9,
                ),
                dbc.Col(
                    dbc.Button(
                        "Ulož verdikt do reportu",
                        color="success",
                        disabled=disabled,
                        id=VERDICT_BUTTON_ID,
                        className="btn-block",
                    ),
                    width=3,
                ),
            ],
        ),
    )


def get_layout() -> html.Div:
    return create_main_div(
        MAIN_DIV_ID,
        [
            html.Div(id=INITIAL_DATA_STORE_ID, children="", style={"display": "none"}),
            html.Div(id=SAVED_DATA_STORE_ID, children="", style={"display": "none"}),
            dbc.Modal(
                [
                    dbc.ModalHeader("Chyba"),
                    dbc.ModalBody(
                        "Chyba pri načítaní tavby z databázy. "
                        + "V databáze sú nekompletné údaje alebo tavba neexistuje."
                    ),
                ],
                id=ERROR_MODAL_ID,
                backdrop=False,
                size="xl",
            ),
            html.H5(
                "ANALÝZA VÝSLEDKU OPTIMALIZÁCIE A REÁLNE NALOŽENEJ VSÁDZKY",
                style={"font-weight": "bold", "margin-top": "8px", "margin-bottom": "24px"},
            ),
            dbc.Row(
                [
                    get_constrained_analysis_inputs_card_component(),
                    dbc.Col(
                        [
                            dbc.Row(
                                [
                                    get_scrap_charge_table_with_addons(
                                        "Odporúčanie modelu",
                                        SCRAP_CHARGE_MODEL_TABLE_ID,
                                        SCRAP_MIX_MODEL_DROPDOWN_ID,
                                        PELLETS_MODEL_INPUT_ID,
                                        BRIQUETS_MODEL_INPUT_ID,
                                        table_read_only=True,
                                        header_weight="bold",
                                    ),
                                    get_active_scrap_limits_table_with_header(
                                        ACTIVE_SCRAP_LIMITS_MODEL_TABLE_ID, "Hmotnostné limity"
                                    ),
                                    get_active_risk_limits_table_with_header(
                                        ACTIVE_RISK_LIMITS_MODEL_TABLE_ID, "Rizikové limity"
                                    ),
                                ],
                            ),
                            html.Hr(
                                style={"borderWidth": "0.05vh", "margin-top": "35px", "margin-bottom": "25px"}
                            ),
                            dbc.Row(
                                [
                                    get_scrap_charge_table_with_addons(
                                        "Naložená vsádzka",
                                        SCRAP_CHARGE_LOADED_TABLE_ID,
                                        SCRAP_MIX_LOADED_DROPDOWN_ID,
                                        PELLETS_LOADED_INPUT_ID,
                                        BRIQUETS_LOADED_INPUT_ID,
                                        header_weight="bold",
                                    ),
                                    get_active_scrap_limits_table_with_header(
                                        ACTIVE_SCRAP_LIMITS_LOADED_TABLE_ID, "Hmotnostné limity"
                                    ),
                                    get_active_risk_limits_table_with_header(
                                        ACTIVE_RISK_LIMITS_LOADED_TABLE_ID, "Rizikové limity"
                                    ),
                                ],
                            ),
                            html.Hr(
                                style={"borderWidth": "0.05vh", "margin-top": "35px", "margin-bottom": "25px"}
                            ),
                            html.H5(
                                "Verdikt procesného inžiniera",
                                style={"font-weight": "bold", "margin-top": "8px", "margin-bottom": "16px"},
                            ),
                            get_verdict_input_row(),
                        ],
                    ),
                ],
            ),
            html.Hr(style={"borderWidth": "0.05vh", "margin-top": "40px", "margin-bottom": "30px"}),
            html.H5(
                "ANALÝZA VSÁDZKY NEOBMEDZENEJ PARAMETRAMI TAVBY",
                style={"font-weight": "bold", "margin-top": "8px", "margin-bottom": "24px"},
            ),
            dbc.Row(
                [
                    get_free_analysis_inputs_card_component(),
                    dbc.Col(
                        [
                            dbc.Row(
                                [
                                    get_scrap_charge_table_with_addons(
                                        "Vsádzka na naloženie",
                                        SCRAP_CHARGE_FREE_TABLE_ID,
                                        SCRAP_MIX_FREE_DROPDOWN_ID,
                                        PELLETS_FREE_INPUT_ID,
                                        BRIQUETS_FREE_INPUT_ID,
                                        addons_read_only=False,
                                        header_weight="bold",
                                    ),
                                    get_active_scrap_limits_table_with_header(
                                        ACTIVE_SCRAP_LIMITS_FREE_TABLE_ID, "Hmotnostné limity"
                                    ),
                                    get_active_risk_limits_table_with_header(
                                        ACTIVE_RISK_LIMITS_FREE_TABLE_ID, "Rizikové limity"
                                    ),
                                ]
                            ),
                            html.Hr(
                                style={"borderWidth": "0.05vh", "margin-top": "35px", "margin-bottom": "25px"}
                            ),
                            dbc.Row(
                                [
                                    create_bootstrap_column_with_header(
                                        "Odhad chémie po hlavnom fukaní",
                                        dcc.Loading(
                                            dbc.Row(
                                                [dbc.Col(create_results_table(RESULTS_TABLE_ID), width=12)],
                                            )
                                        ),
                                        sm=12,
                                        md=9,
                                        lg=9,
                                        xl=9,
                                    ),
                                    get_ct_risks_table_with_header(
                                        CT_RISKS_TABLE_ID, "Riziko než. opr. tech."
                                    ),
                                ]
                            ),
                            html.Hr(
                                style={"borderWidth": "0.05vh", "margin-top": "35px", "margin-bottom": "25px"}
                            ),
                            create_bootstrap_column_with_header_and_dropdown(
                                "Histogram chémie po hlavnom fúkaní",
                                dcc.Graph(RESULTS_PLOT),
                                RESULTS_CHEM_SELECTOR_ID,
                                "Vyber chemicky prvok",
                                sm=12,
                                md=12,
                                lg=12,
                                xl=12,
                            ),
                        ]
                    ),
                ]
            ),
        ],
    )


calculate_scrap_app.layout = get_layout()


def get_loaded_scrap_charge_from_initial_data(initial_data: str) -> ScrapTableData:
    """Get scrap charge actually loaded by operator."""
    data = deserialize(initial_data)
    if data is None or data.heat is None:
        return []
    bmi = convert_heat_to_scrap_blend_model_input(data.heat)
    return get_scrap_table_data(bmi.scrap_weights)


def raw_fe_chem_to_table_data(
    raw_fe_chem: RawFeChem, supported_chems: Tuple[Chem, ...]
) -> RawFeChemTableData:
    return [{"name": chem, "value": raw_fe_chem.get_chem(chem)} for chem in supported_chems]


def raw_fe_chem_table_data_to_raw_fe_chem(table_data: List[dict]) -> RawFeChem:
    return RawFeChem(**{row["name"]: row["value"] for row in table_data})


def get_evaluation_from_initial_data(data: ScrapBlendModelInitialData) -> ClosedHeatEvaluationV2:
    if data.heat is not None:
        heat_no, heat_year = data.heat.heat_key
        return ClosedHeatEvaluationV2.objects.filter(heat_no=heat_no, heat_year=heat_year).first()
    else:
        # show_heat in views.py ensures there is always either evaluation_id or heat available in db
        return ClosedHeatEvaluationV2.objects.filter(pk=data.evaluation_id).first()


def get_optimization_result_from_initial_data(
    data: ScrapBlendModelInitialData,
) -> Optional[MultipleHeatsOptimizationResult]:
    evaluation = get_evaluation_from_initial_data(data)
    if evaluation is None:
        return None

    return evaluation.scrap_charge.last_optimization_result


@calculate_scrap_app.callback(
    [
        Output(RAW_FE_INPUT_ID, "value"),
        Output(RAW_FE_FREE_INPUT_ID, "value"),
        Output(TOTAL_SCRAP_INPUT_ID, "value"),
        Output(PELLETS_MODEL_INPUT_ID, "value"),
        Output(BRIQUETS_MODEL_INPUT_ID, "value"),
        Output(PELLETS_LOADED_INPUT_ID, "value"),
        Output(BRIQUETS_LOADED_INPUT_ID, "value"),
        Output(PELLETS_FREE_INPUT_ID, "value"),
        Output(BRIQUETS_FREE_INPUT_ID, "value"),
        Output(GRADE_SELECTOR_ID, "value"),
        Output(GRADE_FREE_SELECTOR_ID, "value"),
        Output(SCRAP_MIX_LOADED_DROPDOWN_ID, "options"),
        Output(SCRAP_MIX_FREE_DROPDOWN_ID, "options"),
        Output(AVAILABLE_SCRAP_TABLE_ID, "data"),
        Output(SCRAP_CHARGE_MODEL_TABLE_ID, "data"),
        Output(ERROR_MODAL_ID, "is_open"),
    ],
    [Input(INITIAL_DATA_STORE_ID, "children")],
)
def set_initial_data(
    initial_data_serialized: str,
) -> Tuple[
    float,
    float,
    float,
    float,
    float,
    float,
    float,
    float,
    float,
    int,
    int,
    List[Dict[str, str]],
    List[Dict[str, str]],
    ScrapTableData,
    ScrapTableData,
    bool,
]:
    data = deserialize(initial_data_serialized)
    # Display error modal when neither heat nor evaluation_id has been found in database
    if data is None:
        return 0, 0, 0, 0, 0, 0, 0, 0, 0, None, True, None, None, None, [], True
    free_dropdown_options = get_scrap_list_for_add_scrap_dropdown(SUPPORTED_SCRAP_TYPES)
    # Display basic data when no heat nor evaluation is selected
    if data.not_initialized:
        return (
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            None,
            None,
            None,
            free_dropdown_options,
            None,
            [],
            False,
        )
    result = get_optimization_result_from_initial_data(data)
    if result is None:
        return (
            0,
            data.heat.raw_fe_weight,
            0,
            0,
            0,
            0,
            0,
            data.heat.pellets_weight,
            data.heat.briquets_weight,
            None,
            data.heat.grade_planned.grade_id,
            None,
            free_dropdown_options,
            None,
            [],
            False,
        )
    input_data: MultipleHeatsOptimizationInput = result.input_data
    heat = input_data.heats[0]
    available_scraps = input_data.upper_bounds
    loaded_dropdown_options = [{"value": scr, "label": get_scrap_type_label(scr)} for scr in available_scraps]
    available_scrap_table_data = get_available_scrap_table_data(available_scraps)
    # When evaluation_id is used as identifier, Load optimization data only
    if data.evaluation_id is not None:
        return (
            heat.pig_iron_weight,
            heat.pig_iron_weight,
            heat.total_scrap_weight,
            0,
            0,
            0,
            0,
            0,
            0,
            heat.grade_planned.grade_id,
            heat.grade_planned.grade_id,
            loaded_dropdown_options,
            free_dropdown_options,
            available_scrap_table_data,
            get_scrap_charge_model_table_data(result),
            False,
        )
    # When heat_id is used as identifier, load optimization data and also OKO DB data when relevant
    return (
        heat.pig_iron_weight,
        data.heat.raw_fe_weight,
        heat.total_scrap_weight,
        0,
        0,
        0,
        0,
        data.heat.pellets_weight,
        data.heat.briquets_weight,
        heat.grade_planned.grade_id,
        data.heat.grade_planned.grade_id,
        loaded_dropdown_options,
        free_dropdown_options,
        available_scrap_table_data,
        get_scrap_charge_model_table_data(result),
        False,
    )


@calculate_scrap_app.callback(
    [
        Output(ACTIVE_SCRAP_LIMITS_MODEL_TABLE_ID, "data"),
        Output(ACTIVE_RISK_LIMITS_MODEL_TABLE_ID, "data"),
    ],
    [Input(INITIAL_DATA_STORE_ID, "children")],
)
def recalculate_active_limits_model_callback(
    initial_data_serialized: Optional[str],
) -> Tuple[ActiveScrapLimitsTableData, ActiveRiskLimitsTableData]:
    data = deserialize(initial_data_serialized)
    if data is None or data.not_initialized:
        return [], []

    result = get_optimization_result_from_initial_data(data)
    if result is None:
        return [], []
    return (
        get_active_scrap_limits_model_table_data(result),
        get_active_risk_limits_model_table_data(result),
    )


@calculate_scrap_app.callback(
    [
        Output(ACTIVE_SCRAP_LIMITS_LOADED_TABLE_ID, "data"),
        Output(ACTIVE_RISK_LIMITS_LOADED_TABLE_ID, "data"),
    ],
    [
        Input(PELLETS_LOADED_INPUT_ID, "value"),
        Input(BRIQUETS_LOADED_INPUT_ID, "value"),
        Input(SCRAP_CHARGE_LOADED_TABLE_ID, "data"),
    ],
    [State(INITIAL_DATA_STORE_ID, "children")],
)
def recalculate_active_limits_loaded_callback(
    pellets_weight: int,
    briquetes_weight: int,
    scrap_charge_data: ScrapTableData,
    initial_data_serialized: Optional[str],
) -> Tuple[ActiveScrapLimitsTableData, ActiveRiskLimitsTableData]:
    data = deserialize(initial_data_serialized)
    if data is None or data.not_initialized:
        return [], []

    result = get_optimization_result_from_initial_data(data)
    if result is None:
        return [], []

    scrap_charge = Map({scrap["scrap_mix"]: scrap["weight"] for scrap in scrap_charge_data})
    return (
        get_active_scrap_limits_loaded_table_data(result, scrap_charge),
        get_active_risk_limits_loaded_table_data(result, scrap_charge, pellets_weight, briquetes_weight),
    )


@calculate_scrap_app.callback(
    Output(TOTAL_SCRAP_FREE_INPUT_ID, "value"), Input(SCRAP_CHARGE_FREE_TABLE_ID, "data")
)
def recalculate_total_scrap_free_weight(scrap_charge_data: ScrapTableData) -> float:
    return sum(scrap["weight"] for scrap in scrap_charge_data)


@calculate_scrap_app.callback(
    [
        Output(ACTIVE_SCRAP_LIMITS_FREE_TABLE_ID, "data"),
        Output(ACTIVE_RISK_LIMITS_FREE_TABLE_ID, "data"),
    ],
    [
        Input(PELLETS_FREE_INPUT_ID, "value"),
        Input(BRIQUETS_FREE_INPUT_ID, "value"),
        Input(SCRAP_CHARGE_FREE_TABLE_ID, "data"),
        Input(RAW_FE_CHEM_FREE_TABLE_ID, "data"),
        Input(RAW_FE_FREE_INPUT_ID, "value"),
        Input(GRADE_FREE_SELECTOR_ID, "value"),
    ],
    [State(INITIAL_DATA_STORE_ID, "children")],
)
def recalculate_active_limits_free_callback(
    pellets_weight: int,
    briquetes_weight: int,
    scrap_charge_data: ScrapTableData,
    raw_fe_chem_data: RawFeChemTableData,
    raw_fe_weight: int,
    grade_id: int,
    initial_data_serialized: Optional[str],
) -> Tuple[ActiveScrapLimitsTableData, ActiveRiskLimitsTableData]:
    data = deserialize(initial_data_serialized)
    if data.not_initialized and grade_id is None:
        return [], []

    scrap_charge = Map({scrap["scrap_mix"]: scrap["weight"] for scrap in scrap_charge_data})
    raw_fe_chem = RawFeChem(**{row["name"]: row["value"] for row in raw_fe_chem_data})

    # if data.not_initialized and grade_id is not None:
    return (
        get_active_scrap_limits_free_table_data(scrap_charge, grade_id, data.loading_station_id),
        get_active_risk_limits_free_table_data(
            scrap_charge,
            pellets_weight or 0,
            briquetes_weight or 0,
            raw_fe_chem,
            raw_fe_weight,
            grade_id,
            data.loading_station_id,
        ),
    )

    # result = get_optimization_result_from_initial_data(data)
    # return (
    #     get_active_scrap_limits_free_table_data(result, scrap_charge),
    #     get_active_risk_limits_free_table_data(
    #         result, scrap_charge, pellets_weight, briquetes_weight, raw_fe_chem, raw_fe_weight, grade_id
    #     ),
    # )


@calculate_scrap_app.callback(
    Output(RAW_FE_CHEM_TABLE_ID, "data"),
    Input(INITIAL_DATA_STORE_ID, "children"),
)
# pylint: disable-msg=too-many-locals
def get_raw_fe_chem_constrained_from_initial_data(
    initial_data_serialized: Optional[str],
) -> RawFeChemTableData:
    data = deserialize(initial_data_serialized)
    if data is None or data.not_initialized:
        return []

    result = get_optimization_result_from_initial_data(data)
    if result is None:
        return []

    input_data: MultipleHeatsOptimizationInput = result.input_data
    supported_chems = input_data.model_settings.supported_chems
    raw_fe_chem = input_data.heats[0].pig_iron_chem
    return raw_fe_chem_to_table_data(raw_fe_chem, supported_chems)


@calculate_scrap_app.callback(
    Output(RAW_FE_CHEM_FREE_TABLE_ID, "data"),
    Input(GRADE_FREE_SELECTOR_ID, "value"),
    State(INITIAL_DATA_STORE_ID, "children"),
)
# pylint: disable-msg=too-many-locals
def recalculate_raw_fe_chem_free(
    grade_id: Optional[int], initial_data_serialized: Optional[str]
) -> RawFeChemTableData:
    data = deserialize(initial_data_serialized)
    if data.not_initialized and grade_id is None:
        return []
    if data.not_initialized and grade_id is not None:
        grade = steel_grades.get_grade_from_id(grade_id, date.today())
        model_settings = get_object_or_404(LoadingStation, pk=data.loading_station_id).model_settings
        supported_chems = model_settings.supported_chems
        raw_fe_chem = RawFeChem(S=grade.desulf_s)
    else:
        result = get_optimization_result_from_initial_data(data)
        if result is None:
            supported_chems = SUPPORTED_CHEMS
            raw_fe_chem = RawFeChem(
                **{chem: data.heat.after_desulf.get_chem(chem) for chem in supported_chems}
            )
            return raw_fe_chem_to_table_data(raw_fe_chem, supported_chems)

        input_data: MultipleHeatsOptimizationInput = result.input_data
        supported_chems = input_data.model_settings.supported_chems
        if data.heat is not None:
            # Actual chem after desulf
            raw_fe_chem = RawFeChem(
                **{chem: data.heat.after_desulf.get_chem(chem) for chem in supported_chems}
            )
        elif data.evaluation_id is not None:
            # Estimated chem at optimization
            raw_fe_chem = input_data.heats[0].pig_iron_chem

    return raw_fe_chem_to_table_data(raw_fe_chem, supported_chems)


# pylint: disable=too-many-arguments
@calculate_scrap_app.callback(
    Output(RESULTS_TABLE_ID, "data"),
    [
        Input(RAW_FE_FREE_INPUT_ID, "value"),
        Input(PELLETS_FREE_INPUT_ID, "value"),
        Input(BRIQUETS_FREE_INPUT_ID, "value"),
        Input(RAW_FE_CHEM_FREE_TABLE_ID, "data"),
        Input(SCRAP_CHARGE_FREE_TABLE_ID, "data"),
        Input(GRADE_FREE_SELECTOR_ID, "value"),
    ],
    [State(INITIAL_DATA_STORE_ID, "children")],
)
# pylint: disable-msg=too-many-locals
def recalculate_eob_chem_result_table_callback(
    raw_fe_weight: float,
    pellets_weight: float,
    briquets_weight: float,
    raw_fe_chem: List[dict],
    scrap_weights: ScrapTableData,
    selected_grade: Optional[int],
    initial_data_serialized: Optional[str],
) -> BlendResultsTableData:
    data = deserialize(initial_data_serialized)
    if data is None:
        return []

    if data.not_initialized:
        model_settings = get_object_or_404(LoadingStation, pk=data.loading_station_id).model_settings
    else:
        result = get_optimization_result_from_initial_data(data)
        if result is None:
            model_settings = ModelSettings()
        else:
            model_settings = result.input_data.model_settings

    blend_model, _, _, _ = get_all_models_from_model_settings(model_settings)
    scrap_weight_map = Map({row["scrap_mix"]: row["weight"] for row in scrap_weights})
    scrap_mix_mapping = Map(
        {
            scrap_mix: ScrapMixDefinition.objects.get(name=scrap_mix).get_scrap_type_mapping()
            for scrap_mix in scrap_weight_map
            if scrap_mix not in SUPPORTED_SCRAP_TYPES
        }
    )
    blend_model_output = blend_model.calculate(
        ScrapBlendModelInput(
            raw_fe_weight,
            raw_fe_chem_table_data_to_raw_fe_chem(raw_fe_chem),
            scrap_weight_map,
            pellets_weight or 0,
            briquets_weight or 0,
            scrap_mix_mapping,
        )
    )
    real_steel_chem_eob, real_steel_chem_final = None, None
    if data.heat is not None:
        real_steel_chem_eob = convert_heat_to_scrap_blend_model_output(data.heat, "eob")
        real_steel_chem_final = convert_heat_to_scrap_blend_model_output(data.heat, "final")

    return create_results_table_data(
        blend_model_output,
        model_settings.supported_chems,
        selected_grade,
        real_steel_chem_eob,
        real_steel_chem_final,
    )


@calculate_scrap_app.callback(
    Output(RESULTS_PLOT, "figure"),
    [
        Input(RAW_FE_FREE_INPUT_ID, "value"),
        Input(PELLETS_FREE_INPUT_ID, "value"),
        Input(BRIQUETS_FREE_INPUT_ID, "value"),
        Input(RAW_FE_CHEM_FREE_TABLE_ID, "data"),
        Input(SCRAP_CHARGE_FREE_TABLE_ID, "data"),
        Input(GRADE_FREE_SELECTOR_ID, "value"),
        Input(RESULTS_CHEM_SELECTOR_ID, "value"),
    ],
    [State(INITIAL_DATA_STORE_ID, "children")],
)
def recalculate_results_histogram_for_chem_callback(
    raw_fe_weight: float,
    pellets_weight: float,
    briquets_weight: float,
    raw_fe_chem: List[dict],
    scrap_weights: ScrapTableData,
    selected_grade: Optional[int],
    selected_chem: Chem,
    initial_data_serialized: Optional[str],
) -> go.Figure:
    if selected_grade is None:
        return go.Figure()
    data = deserialize(initial_data_serialized)
    if data is None:
        return None

    if data.not_initialized:
        model_settings = get_object_or_404(LoadingStation, pk=data.loading_station_id).model_settings
    else:
        result = get_optimization_result_from_initial_data(data)
        if result is None:
            model_settings = ModelSettings()
        else:
            model_settings = result.input_data.model_settings

    blend_model, _, _, corr_tech_model = get_all_models_from_model_settings(model_settings)
    scrap_weight_map = Map({row["scrap_mix"]: row["weight"] for row in scrap_weights})
    scrap_mix_mapping = Map(
        {
            scrap_mix: ScrapMixDefinition.objects.get(name=scrap_mix).get_scrap_type_mapping()
            for scrap_mix in scrap_weight_map
            if scrap_mix not in SUPPORTED_SCRAP_TYPES
        }
    )
    bmi = ScrapBlendModelInput(
        raw_fe_weight,
        raw_fe_chem_table_data_to_raw_fe_chem(raw_fe_chem),
        scrap_weight_map,
        pellets_weight or 0,
        briquets_weight or 0,
        scrap_mix_mapping,
    )
    bmo = blend_model.calculate(bmi)
    grade: Grade = steel_grades.get_grade_from_id(selected_grade, date.today())
    corr_tech_model.predicted_chems = (selected_chem,)
    ctmo = corr_tech_model.calculate(CorrectionTechnologiesModelInput(grade, bmo))

    actual_eob, actual_final = None, None
    if data.heat is not None:
        actual_eob = data.heat.eob.get_chem(selected_chem)
        actual_final = data.heat.final.get_chem(selected_chem)
    return get_results_histogram_for_chem(
        bmo, ctmo, selected_chem, actual_eob, actual_final, grade, last_bin_width=0.005
    )


@calculate_scrap_app.callback(
    Output(CT_RISKS_TABLE_ID, "data"),
    [
        Input(RAW_FE_FREE_INPUT_ID, "value"),
        Input(PELLETS_FREE_INPUT_ID, "value"),
        Input(BRIQUETS_FREE_INPUT_ID, "value"),
        Input(RAW_FE_CHEM_FREE_TABLE_ID, "data"),
        Input(SCRAP_CHARGE_FREE_TABLE_ID, "data"),
        Input(GRADE_FREE_SELECTOR_ID, "value"),
    ],
    [State(INITIAL_DATA_STORE_ID, "children")],
)
# pylint: disable-msg=too-many-locals
def recalculate_ct_risks_table_callback(
    raw_fe_weight: float,
    pellets_weight: float,
    briquets_weight: float,
    raw_fe_chem_data: List[dict],
    scrap_weights: ScrapTableData,
    selected_grade: Optional[int],
    initial_data_serialized: Optional[str],
) -> CTRiskTableData:
    data = deserialize(initial_data_serialized)
    if data is None or selected_grade is None:
        return []

    if data.not_initialized:
        model_settings = get_object_or_404(LoadingStation, pk=data.loading_station_id).model_settings
    else:
        result = get_optimization_result_from_initial_data(data)
        if result is None:
            model_settings = ModelSettings()
        else:
            model_settings = result.input_data.model_settings
    raw_fe_chem = RawFeChem(**{row["name"]: row["value"] for row in raw_fe_chem_data})
    grade = steel_grades.get_grade_from_id(selected_grade, date.today())
    scrap_weights_map = Map({row["scrap_mix"]: row["weight"] for row in scrap_weights})
    heat = HeatInputs(
        grade_planned=grade,
        pig_iron_chem=raw_fe_chem,
        pig_iron_weight=raw_fe_weight,
        total_scrap_weight=sum(scrap_weights_map.values()),
        lower_bounds=Map(),
        upper_bounds=Map(),
    )

    return get_ct_risks_free_table_data(
        scrap_weights_map, heat, model_settings, pellets_weight or 0, briquets_weight or 0
    )


# Callback populating/recalculating data for SCRAP_CHARGE_LOADED_TABLE_ID
register_add_scrap_callback(
    calculate_scrap_app,
    INITIAL_DATA_STORE_ID,
    SCRAP_CHARGE_LOADED_TABLE_ID,
    SCRAP_MIX_LOADED_DROPDOWN_ID,
    get_loaded_scrap_charge_from_initial_data,
)

# Callback populating/recalculating data for SCRAP_CHARGE_FREE_TABLE_ID
register_add_scrap_callback(
    calculate_scrap_app,
    INITIAL_DATA_STORE_ID,
    SCRAP_CHARGE_FREE_TABLE_ID,
    SCRAP_MIX_FREE_DROPDOWN_ID,
    get_loaded_scrap_charge_from_initial_data,
)


@calculate_scrap_app.callback(
    Output(VERDICT_BUTTON_ID, "disabled"),
    Input(VERDICT_INPUT_ID, "value"),
)
def switch_feedback_button_status_callback(comment: str):
    return not bool(comment)


@calculate_scrap_app.expanded_callback(
    Output(INITIAL_DATA_STORE_ID, "children"),
    Input(VERDICT_INPUT_ID, "value"),
    State(INITIAL_DATA_STORE_ID, "children"),
)
def update_initial_data_with_verdict_callback(
    verdict: str,
    initial_data_serialized: str,
    *args,
    **kwargs,
) -> str:
    user = kwargs["user"].username
    data = deserialize(initial_data_serialized)
    data = attr.evolve(data, verdict=verdict, verdict_user=user)
    return data.serialize()


@calculate_scrap_app.callback(
    [Output(SAVED_DATA_STORE_ID, "children"), Output(VERDICT_INPUT_ID, "value")],
    Input(VERDICT_BUTTON_ID, "n_clicks"),
    State(INITIAL_DATA_STORE_ID, "children"),
)
def save_verdict_to_evaluation(n_clicks: Optional[int], initial_data_serialized: str) -> Tuple[str, str]:
    if not n_clicks:
        return initial_data_serialized, ""
    data = deserialize(initial_data_serialized)
    with transaction.atomic():
        evaluation = get_evaluation_from_initial_data(data)
        evaluation.verdict = data.verdict
        evaluation.verdict_user = data.verdict_user
        evaluation.save()
    return data.serialize(), ""
