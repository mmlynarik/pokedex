import logging
from functools import lru_cache

from usskscadaocclient import ScadaConnector
from usskssgrades.steel_grades_hardcoded import SteelGradesHardcoded
from usskssgrades.steel_grades_ispv import SteelGradesIspv, SteelGradesIspvWithFallback
from vsadzka.settings import IARS_DB, ISPV_DB, OKO_DB, SCADA_DB

from scrap_core import SUPPORTED_CHEMS
from scrap_core.datamodel.iars_hook import IarsHook
from scrap_core.datamodel.oko import OkoDB, validate_oko_env_config

# TODO this whole submodule should be on top level
log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


if ISPV_DB["username"] is None or ISPV_DB["password"] is None:
    steel_grades = SteelGradesHardcoded(SUPPORTED_CHEMS)
    log.warning(
        "Username or password to ISPV database is not configured, "
        "thus falling back to hardcoded steel grades."
    )
else:
    steel_grades = SteelGradesIspvWithFallback(  # type: ignore
        primary=SteelGradesIspv(ISPV_DB, SUPPORTED_CHEMS), fallback=SteelGradesHardcoded(SUPPORTED_CHEMS)
    )

db_iars = IarsHook(conf=IARS_DB)

db_scada = ScadaConnector(conf=SCADA_DB)


@lru_cache
def get_oko_db() -> OkoDB:
    return validate_oko_env_config(OKO_DB)
