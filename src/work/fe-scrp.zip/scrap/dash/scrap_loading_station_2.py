# pylint: disable=too-many-lines
import base64
import logging
import time
import zlib
import zoneinfo
from datetime import date, datetime
from typing import Any, Callable, Dict, List, NamedTuple, Optional, Sequence, Tuple, TypeVar

import dash
import pytz
from dash.dependencies import Input, Output, State
from django.contrib.auth.models import User
from django.db import transaction
from django_plotly_dash import DjangoDash
from scrap.dash.components import get_scrap_type_label, multiple_callback_triggered_by_exact
from scrap.dash.components.blend_results_table import BlendResultsTableData, create_results_table_data
from scrap.dash.components.common_loading_station import (
    CONTROL_CHANGED_MODAL_ID,
    DEBUG_COLLAPSE_BTN_ID,
    DEBUG_COLLAPSE_ID,
    DEBUG_ELEMENT_ID,
    DISPLAY_DATA_STORE_ID,
    GLOBAL_ERROR_MODAL_ID_INPUT,
    GLOBAL_ERROR_MODAL_ID_OUTPUT,
    LOADING_STATION_ID_DIV_ID,
    OPTIMIZATION_PROGRESS_BAR_REFRESH_INTERVAL_ID,
    REFRESH_REQUEST_MODAL_ID,
    RELOAD_DATA_INTERVAL_ID,
    SCRAP_CHARGE_TABLE_ID,
    SCRAP_TABLE_ID,
    STATION_NAME_ID,
    STATUS_ID,
    USER_IN_CONTROL_NAME_ID,
    USER_NAME_ID,
    ScrapLoadingStationViewModelV2,
    deserialize_loading_station_view_model_v2,
    get_layout,
)
from scrap.dash.components.one_heat_optimizer_v2 import (
    ChargeInfoValidationResult,
    start_optimization,
    update_optimization_status,
    validate_charge_info,
)
from scrap.dash.components.raw_fe_chem_table import RawFeChemTableData, convert_table_data_to_raw_fe_chem
from scrap.dash.components.scrap_charge_limits_table import (
    ScrapChargeLimitsTableData,
    convert_table_data_to_scrap_limits,
)
from scrap.dash.components.scrap_charge_optimization_card_v2 import (
    BASKET_NUMBER_INPUT_ID,
    CALCULATE_OUTPUT_BUTTON_ID,
    CARD_HEADER_DELETE_CHARGE_BUTTON,
    CHARGE_CARD_ID,
    CHARGE_LIMITS_TABLE_ID,
    CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID,
    CHARGE_OPTIMIZATION_CARD_HEADER_ID,
    CLEAR_SCRAP_LIMITS_BUTTON_ID,
    COLLAPSE_ADVANCE_SETTINGS_ID,
    COLLAPSE_BUTTON_ID,
    COMMENT_INPUT_ID,
    CONFIRM_CHARGE_BUTTON_ID,
    CONFIRM_CHARGE_BUTTON_MSG_ID,
    DETAIL_OPTIMIZATION_BUTTON_RESULT_ID,
    DETAIL_OPTIMIZATION_RESULT_TABLE_ID,
    DETAIL_OPTIMIZATION_TABLE_RESULT_ID,
    GRADE_SELECTOR_ID,
    OPTIMIZATION_INPUT_DIV_ID,
    OPTIMIZATION_RESULT_PROBABILITY_INFO_MSG_ID,
    OPTIMIZATION_RESULTS_TABLE_ID,
    PIG_IRON_WEIGHT_INPUT_ID,
    PROGRESS_BAR_ID,
    RAW_FE_CHEM_TABLE_ID,
    READ_SCRAP_LIMITS_FROM_RESULT_BUTTON_ID,
    RECALCULATE_OUTPUT_BUTTON_ID,
    SWITCHED_BASKET_NUMBER_INPUT_ID,
    WEIGHT_INPUT_ID,
    ScrapOptimizationResultTableData,
    create_optimization_input_table_row,
)
from scrap.dash.components.scrap_charges_table import (
    NEW_HEAT_BUTTON_ID,
    ScrapChargeData,
    get_scrap_charge_row_v2,
)
from scrap.dash.components.scrap_table_ls import (
    APPEND_SCRAP_BTN_ID,
    APPEND_SCRAP_DROPDOWN_ID,
    APPEND_WEIGHT_INPUT_ID,
    CHANGE_WEIGHT_INPUT_ID,
    CHANGE_WEIGHT_SCRAP_DROPDOWN_ID,
    CHANGE_WEIGHT_UPDATE_BTN_ID,
    TRANSFER_CAPACITY_WEIGHT_INPUT_ID,
    ScrapTableData,
    get_scrap_map_from_scrap_table_data,
    get_scrap_table_data_with_weights,
)
from scrap.dash.components.selectors import GradeIdsSelectorViewModel
from scrap.dash.database_api import db_iars, steel_grades
from scrap.models import (
    LOADED_CHARGE_OPERATOR_DECISION,
    ScrapCharge,
    ScrapMixDefinition,
    LoadingStation,
    ScrapChargeDisplayDataV2,
    all_prefetched_loading_station_query_set,
)
from scrap.pigironanalysis import get_raw_fe_chem_from_db
from scrap.utils import get_pig_iron_s_for_grade
from usskssgrades.grade import NORMAL_HEAT_WEIGHT_DEFAULT

from scrap_core import ScrapMix, ScrapOrder, ScrapType, vectorize_values_dynamic
from scrap_core.optimization import get_scrap_order_from_model_settings
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    HeatPlan,
    ScrapMixLimit,
    ScrapMixLimits,
    INDOOR_SCRAP_NAME,
)
from scrap_core.optimization.validations import has_errors
from scrap_core.utils import convert_kilograms_to_tons, convert_tons_to_kilograms

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


loading_scrap_station_app_2 = DjangoDash(
    "LoadingScrapStation2",
    serve_locally=True,
    add_bootstrap_links=True,
)
loading_scrap_station_app_2.layout = get_layout(read_only=False)

loading_scrap_station_read_only_app_2 = DjangoDash(
    "LoadingScrapStationReadOnly2", serve_locally=True, add_bootstrap_links=True
)
loading_scrap_station_read_only_app_2.layout = get_layout(read_only=True)


class InputField(NamedTuple):
    component_name: str
    component_value: str
    update_display_data: Callable[[ScrapLoadingStationViewModelV2, Any], ScrapLoadingStationViewModelV2]


class OutputField(NamedTuple):
    component_name: str
    component_value: str
    sync_value: Callable[[ScrapLoadingStationViewModelV2], Any]


InputFields = Sequence[InputField]
OutputFields = Sequence[OutputField]


def compress(data: str) -> str:
    compressed = zlib.compress(data.encode("UTF8"), level=5)
    return base64.urlsafe_b64encode(compressed).decode("UTF8")


def decompress(data: str) -> str:
    decoded = base64.urlsafe_b64decode(data.encode("UTF8"))
    return zlib.decompress(decoded).decode("UTF8")


def create_process_input_callback(input_fields: InputFields):
    def process_input_callback(*args, **kwargs) -> Tuple[str, bool]:
        try:
            trigger = kwargs["callback_context"].triggered
            if not args[-1]:
                initial_callback = True
                display_data = load_initial_data(
                    kwargs["session_state"]["loading_station_id"], kwargs["user"].username
                )
            else:
                initial_callback = False
                display_data = deserialize_loading_station_view_model_v2(decompress(args[-1]))
            for i, field in enumerate(input_fields):
                if multiple_callback_triggered_by_exact(field.component_name, field.component_value, trigger):
                    start_time = time.time()
                    new_display_data = field.update_display_data(display_data, args[i])
                    end_time = time.time()
                    duration = end_time - start_time
                    if duration > 0.01:
                        logger.warning(
                            f"Slow input callback {i}: {field.component_name}, {field.component_value}"
                            + f"- duration: {duration}"
                        )
                    if new_display_data != display_data:
                        return compress(new_display_data.serialize()), False
            if initial_callback:
                return compress(display_data.serialize()), False
            return dash.no_update, False
        except Exception:  # pylint: disable=broad-except
            logger.exception("Loading station - input processing error ")
            return dash.no_update, True

    return process_input_callback


def create_process_output_callback(output_fields: OutputFields):
    def process_output_callback(*args, **kwargs):  # pylint: disable=unused-argument
        try:
            if not args[0]:
                return tuple([dash.no_update] * (len(output_fields) + 1))
            display_data = deserialize_loading_station_view_model_v2(decompress(args[0]))
            results = []
            for i, field in enumerate(output_fields):
                start_time = time.time()
                new_value = field.sync_value(display_data)
                end_time = time.time()
                duration = end_time - start_time
                if duration > 0.01:
                    logger.warning(
                        f"Slow output callback {i}: {field.component_name}, {field.component_value}"
                        + f"- duration: {duration}"
                    )
                results.append(new_value if (new_value != args[i + 1]) else dash.no_update)
            results.append(False)
            return tuple(results)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Loading station - output processing error ")
            return tuple(([dash.no_update] * len(output_fields)) + [True])

    return process_output_callback


def debug_output(data: ScrapLoadingStationViewModelV2) -> str:
    if data.debug:
        return data.serialize()
    return ""


def force_charge(data: ScrapLoadingStationViewModelV2) -> List[int]:
    if data.selected_row is None:
        return []
    return [data.selected_row]


def hide_charge_card(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.selected_row is None


def get_msg_from_validation_result(validation_result: ChargeInfoValidationResult) -> str:
    errors, warnings = validation_result
    if errors:
        return errors[0]
    if warnings:
        return warnings[0]
    return ""


def get_class_from_validation_result(validation_result: ChargeInfoValidationResult) -> str:
    errors, warnings = validation_result
    if errors:
        return "error-input"
    if warnings:
        return "warning-input"
    return ""  # valid-input


def get_friendly_heat_name(data: ScrapLoadingStationViewModelV2) -> str:
    maybe_heat_id = data.selected_heat_id
    return "Nová tavba" if maybe_heat_id is None else "Tavba " + str(maybe_heat_id)


def get_operator_comment(data: ScrapLoadingStationViewModelV2) -> str:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or maybe_optimization.comment is None:
        return ""
    return maybe_optimization.comment


FORBIDDEN_SCRAP_TYPES = {"HSB COOL", "XXX"}


def get_full_scrap_mix_order_with_labels(scrap_order: ScrapOrder) -> Tuple[Tuple[ScrapMix, str], ...]:
    """
    Get full scrap mix order with labels, using single scrap mixes [original scrap types strings] and not exhausted composite scrap mixes [user-defined instances of ScrapMixDefinition Django model].
    """
    scrap_order_labels = tuple(get_scrap_type_label(scrap_type) for scrap_type in scrap_order)
    scrap_order_with_labels = tuple(zip(scrap_order, scrap_order_labels))
    return scrap_order_with_labels + ScrapMixDefinition.get_identifiers(exclude_exhausted=True)


def get_scrap_list_for_add_scrap_dropdown(scrap_order: ScrapOrder) -> List[dict]:
    full_scrap_mix_order_with_labels = get_full_scrap_mix_order_with_labels(scrap_order)
    return vectorize_values_dynamic(
        [item for item in full_scrap_mix_order_with_labels if item[0] not in FORBIDDEN_SCRAP_TYPES],
        lambda item: {"label": item[1], "value": item[0]},
    )


def set_scrap_to_change_scrap_weight_dropdown(data: ScrapLoadingStationViewModelV2) -> List[dict]:
    if not data.display_data.available_scraps:
        return []
    scrap_list_for_dropdown = get_scrap_list_for_add_scrap_dropdown(data.available_scraps)
    available_scraps = [scrap.scrap_type for scrap in data.display_data.available_scraps]
    return [scrap for scrap in scrap_list_for_dropdown if scrap["value"] in available_scraps]


def set_all_available_scrap_types_to_dropdown(data: ScrapLoadingStationViewModelV2) -> List[dict]:
    return get_scrap_list_for_add_scrap_dropdown(data.available_scraps)


def set_grade_options(data: ScrapLoadingStationViewModelV2) -> List[Dict[str, Any]]:
    return data.available_grades


def get_scrap_mix_for_update(data: ScrapLoadingStationViewModelV2) -> Optional[ScrapMix]:
    return data.scrap_mix_for_update


def get_scrap_weight_for_update(data: ScrapLoadingStationViewModelV2) -> Optional[float]:
    return data.scrap_weight_for_update


def get_scrap_mix_for_append(data: ScrapLoadingStationViewModelV2) -> Optional[ScrapMix]:
    return data.scrap_mix_for_append


def get_scrap_weight_for_append(data: ScrapLoadingStationViewModelV2) -> Optional[float]:
    return data.scrap_weight_for_append


def get_transfer_capacity(data: ScrapLoadingStationViewModelV2) -> Optional[float]:
    return data.transfer_capacity


def do_not_have_scrap_for_weight_append(data: ScrapLoadingStationViewModelV2) -> bool:
    return (
        data.scrap_mix_for_append is None
        or data.scrap_weight_for_append is None
        or data.scrap_weight_for_append == 0
    )


def do_not_have_data_for_confirm_charge(data: ScrapLoadingStationViewModelV2) -> bool:
    data_is_missing = (
        not data.selected_basket_ids
        or data.selected_grade_id is None
        or data.selected_total_scrap_weight is None
        or data.selected_pig_iron_weight is None
    )

    if not data_is_missing:
        return (
            has_errors(data.selected_heat_id_validation_result)
            or has_errors(data.selected_basket_ids_validation_result)
            or has_errors(data.selected_grade_id_validation_result)
            or has_errors(data.selected_total_scrap_weight_validation_result)
            or has_errors(data.selected_pig_iron_weight_validation_result)
        )
    return True


def have_data_for_confirm_charge(data: ScrapLoadingStationViewModelV2) -> bool:
    return not do_not_have_data_for_confirm_charge(data)


def control_lost(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.control_lost


def control_gained(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.control_gained


def open_debug_data(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.debug_data_open


def change_name_debug_data_btn(data: ScrapLoadingStationViewModelV2) -> str:
    if data.debug_data_open:
        return "Skryť vývojárske dáta"
    return "Zobraziť vývojárske dáta"


def do_not_have_data_for_weight_update(data: ScrapLoadingStationViewModelV2) -> bool:
    if data.scrap_mix_for_update is None or data.scrap_weight_for_update is None:
        return True
    return False


def clear_scrap_limits(data: ScrapLoadingStationViewModelV2, n_clicks: int) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data

    cleared_limits = tuple(
        ScrapMixLimit(scrap_type=limit.scrap_type, minimum=None, maximum=None)
        for limit in data.selected_charge_limits
    )
    return data.update_selected_charge_field(scrap_limits=cleared_limits)


def set_scrap_limits_from_last_result(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data

    last_optimization = data.get_last_optimization_for_selected_charge()
    if last_optimization is None or not last_optimization.is_done():
        return data
    result = last_optimization.result
    if result is None:
        return data

    new_limits = []
    for limit in data.selected_charge_limits:
        if limit.scrap_type in result.first_heat_scrap_weights:
            new_limits.append(
                ScrapMixLimit(
                    scrap_type=limit.scrap_type,
                    minimum=result.first_heat_scrap_weights[limit.scrap_type],
                    maximum=limit.maximum,
                )
            )
        else:
            new_limits.append(limit)

    return data.update_selected_charge_field(scrap_limits=tuple(new_limits))


def optimization_not_running(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return True
    return not maybe_optimization.is_running()


def get_optimization_progress_value(data: ScrapLoadingStationViewModelV2) -> float:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return 0.0
    return maybe_optimization.percentage_done


def get_optimization_result(data: ScrapLoadingStationViewModelV2) -> ScrapOptimizationResultTableData:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or not maybe_optimization.is_done() or maybe_optimization.result is None:
        return []
    return [
        create_optimization_input_table_row(scrap_type, convert_kilograms_to_tons(weight))
        for scrap_type, weight in maybe_optimization.result.first_heat_scrap_weights.items()
    ]


def hide_disable_element_on_optimization_done(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return False
    if maybe_optimization.has_result_error():
        return False
    if maybe_optimization.percentage_done != 100:
        return True
    return False


def hide_element_on_optimization_done(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return False
    if maybe_optimization.has_result_error():
        return False
    return True


def disable_element_on_scrap_limit_validation_error(data: ScrapLoadingStationViewModelV2) -> bool:
    return has_errors(data.selected_charge_limits_validation_result)


def disable_advance_setting_table(data: ScrapLoadingStationViewModelV2) -> bool:
    return not hide_disable_element_on_optimization_done(data)


def hide_optimization_result(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or not maybe_optimization.is_done():
        return True
    return False


def do_not_have_comment(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or not maybe_optimization.is_done():
        return True
    maybe_comment = maybe_optimization.comment
    if maybe_comment is None:
        return True
    return maybe_comment.strip() == ""


def get_optimization_result_probability_text(data: ScrapLoadingStationViewModelV2) -> str:
    """for selected charge"""
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or maybe_optimization.result is None:
        return ""

    risks = maybe_optimization.result.first_heat_expected_risk
    if risks is None:
        return ""

    # low risk
    if not risks.medium and not risks.high:
        return "Nízka pravdepodobnosť nutnosti použitia nežiadúcej opravnej technológie"

    # medium risk
    if not risks.high:
        msg = "Stredná pravdepodobnosť nutnosti použitia nežiadúcej opravnej technológie"
        if data.debug:
            msg += " kvôli " + ", ".join(risks.medium)
        return msg

    # high risk
    msg = "Vysoká pravdepodobnosť nutnosti použitia nežiadúcej opravnej technológie"
    if data.debug:
        msg += " kvôli " + ", ".join(risks.high)
    return msg


def get_optimization_result_probability_style(data: ScrapLoadingStationViewModelV2) -> dict:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or maybe_optimization.result is None:
        return {}

    style = {
        "padding": "2px 10px",
        "margin": "0px 0px 16px 0px",
        "font-size": "1rem",
        "color": "#5cb85c",
        "font-weight": "300",
        "background-color": "#fff",  # Bootstrap success color in hex for css
    }

    risks = maybe_optimization.result.first_heat_expected_risk
    if risks is None:
        return {}

    # low risk
    if not risks.high and not risks.medium:
        return style

    # medium risk
    if not risks.high:
        style["color"] = "#f0ad4e"  # Bootstrap warning color in hex for css
        style["font-weight"] = "500"
        return style

    # high risk
    style["background-color"] = "#d9534f"  # Bootstrap danger color in hex for css
    style["color"] = "#fff"
    style["font-weight"] = "700"
    style["font-size"] = "1.2rem"
    return style


def get_optimization_detail(data: ScrapLoadingStationViewModelV2) -> BlendResultsTableData:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return []
    blend_model_output = maybe_optimization.blend_model_output
    if blend_model_output is None:
        return []
    return create_results_table_data(
        blend_model_output, maybe_optimization.used_predicted_chems, data.selected_grade_id
    )


def get_optimization_progress_text(data: ScrapLoadingStationViewModelV2) -> str:
    return f"{get_optimization_progress_value(data):.1f}%"


def open_advanced_settings(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.advanced_settings_open


def scrap_table_output(data: ScrapLoadingStationViewModelV2) -> ScrapTableData:
    return get_scrap_table_data_with_weights(data.display_data.available_scraps)


def charges_table_output(data: ScrapLoadingStationViewModelV2) -> ScrapChargeData:
    return [get_scrap_charge_row_v2(charge) for charge in data.display_data.scrap_charges]


def update_refresh_time(data: ScrapLoadingStationViewModelV2) -> str:  # pylint: disable=unused-argument
    tz_central_europe = pytz.timezone("Europe/Bratislava")
    return datetime.now(tz_central_europe).strftime("Aktualizované %H:%M:%S")


def update_user_name(data: ScrapLoadingStationViewModelV2) -> str:
    return data.user


def update_user_in_control_name(data: ScrapLoadingStationViewModelV2) -> str:
    return f"Prevziať kontrolu od {data.user_in_control}"


def hide_get_control_button(data: ScrapLoadingStationViewModelV2) -> bool:
    return (data.user == data.user_in_control) or (data.user not in data.authorized_users)


def update_station_name(data: ScrapLoadingStationViewModelV2) -> str:
    return data.loading_station_name


def hide_debug_element(data: ScrapLoadingStationViewModelV2) -> bool:
    return not data.debug


def hide_if_not_ss1(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.steelshop != 1


def show_scrap_location_on_ss1(data: ScrapLoadingStationViewModelV2) -> List[Optional[dict]]:
    return [] if data.steelshop == 1 else [{"if": {"column_id": "location"}, "display": "none"}]


def do_not_have_data_for_confirm_charge_msg(data: ScrapLoadingStationViewModelV2) -> str:
    missing_data = []
    if not data.selected_basket_ids:
        missing_data.append("čísla korýt")
    if data.selected_grade_id is None:
        missing_data.append("plánovanú akosť")
    if data.selected_total_scrap_weight is None:
        missing_data.append("hmotnosť šrotu")
    if data.selected_pig_iron_weight is None:
        missing_data.append("hmotnosť surového železa")
    if not missing_data:
        return ""
    return f"Pre uzavretie tavby je potrebné doplniť {', '.join(missing_data)}."


def get_scrap_limit_row(all_rows: ScrapMixLimits, scrap_mix: ScrapMix) -> ScrapMixLimit:
    for row in all_rows:
        if row.scrap_type == scrap_mix:
            return row
    return ScrapMixLimit(scrap_mix)


def save_current_data(data: ScrapLoadingStationViewModelV2) -> ScrapLoadingStationViewModelV2:
    with transaction.atomic():
        loading_station = (
            LoadingStation.objects.select_related("user_in_control")
            .select_for_update(nowait=True, of=("self", "user_in_control"))
            .get(pk=data.loading_station_id)
        )
        user_in_control = loading_station.user_in_control
        if (user_in_control is None) or (user_in_control.username != data.user):
            return data.update_field(control_lost=True)

        loading_station.current_data_v2 = data.display_data  # type: ignore
        loading_station.save()
    return data


def check_scrap_table_location(table_data: ScrapTableData) -> ScrapTableData:
    new_table_data = []
    for row in table_data:
        if row["location"] is None:
            row.update(location=INDOOR_SCRAP_NAME)
        new_table_data.append(row)
    return new_table_data


def scrap_table_input(
    data: ScrapLoadingStationViewModelV2, table_data: ScrapTableData
) -> ScrapLoadingStationViewModelV2:
    new_table_data = check_scrap_table_location(table_data)
    new_scrap_tuple = get_scrap_map_from_scrap_table_data(new_table_data)
    new_data = data.update_display_data_field(available_scraps=new_scrap_tuple)
    scrap_tuple_without_weight = tuple(scrap.scrap_type for scrap in new_scrap_tuple)
    for i, charge in enumerate(data.display_data.scrap_charges):
        new_data = new_data.update_charge_field(
            i,
            scrap_limits=tuple(
                [
                    get_scrap_limit_row(charge.scrap_limits, scrap_mix)
                    for scrap_mix in scrap_tuple_without_weight
                ]
            ),
        )
    return save_current_data(new_data)


def load_initial_data(loading_station_id: int, username: str) -> ScrapLoadingStationViewModelV2:
    loading_station = all_prefetched_loading_station_query_set().get(pk=loading_station_id)
    model_settings = loading_station.model_settings

    # read_only = request.user != loading_station.authorized_user
    read_only = False
    number_of_heats = len(loading_station.current_data_v2.scrap_charges)
    selected_row = None if (number_of_heats == 0) else (number_of_heats - 1)
    user_in_control = loading_station.user_in_control
    user_in_control_name = user_in_control.username if user_in_control is not None else ""
    grade_ids = GradeIdsSelectorViewModel()
    return ScrapLoadingStationViewModelV2(
        loading_station_id=loading_station.pk,
        loading_station_name=loading_station.name,
        user=username,
        user_in_control=user_in_control_name,
        authorized_users=tuple([user.username for user in loading_station.authorized_users.all()]),
        display_data=loading_station.current_data_v2,
        debug=loading_station.debug,
        level_2=loading_station.level_2,
        steelshop=loading_station.steelshop,
        read_only=read_only,
        selected_row=selected_row,
        advanced_settings_open=False,
        results_detail_open=False,
        error=False,
        scrap_mix_for_append=None,
        scrap_mix_for_update=None,
        scrap_weight_for_append=None,
        scrap_weight_for_update=None,
        debug_data_open=False,
        available_grades=grade_ids.to_dropdown_options(),
        available_scraps=get_scrap_order_from_model_settings(model_settings),
        control_gained=False,
        control_lost=False,
        transfer_capacity=None,
        model_settings=model_settings,
    )


def choose_scrap_for_update_weight(
    data: ScrapLoadingStationViewModelV2, scrap_type: Optional[ScrapType]
) -> ScrapLoadingStationViewModelV2:
    return data.update_field(scrap_mix_for_update=scrap_type)


def choose_scrap_for_append_weight(
    data: ScrapLoadingStationViewModelV2, scrap_type: Optional[ScrapType]
) -> ScrapLoadingStationViewModelV2:
    return data.update_field(scrap_mix_for_append=scrap_type)


def set_new_scrap_weight_for_update(
    data: ScrapLoadingStationViewModelV2, new_scrap_weight: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    if new_scrap_weight is not None:
        return data.update_field(scrap_weight_for_update=new_scrap_weight)
    return data


def set_new_scrap_weight_for_append(
    data: ScrapLoadingStationViewModelV2, new_scrap_weight: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    if new_scrap_weight is not None:
        return data.update_field(scrap_weight_for_append=new_scrap_weight)
    return data


def set_transfer_capacity(
    data: ScrapLoadingStationViewModelV2, new_weight: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    if new_weight is not None:
        return data.update_field(transfer_capacity=new_weight)
    return data


def update_weight_of_available_scrap(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    if data.scrap_mix_for_update is None or data.scrap_weight_for_update is None:
        return data
    updated_available_scrap = []
    for scrap in data.display_data.available_scraps:
        if scrap.scrap_type == data.scrap_mix_for_update:
            if data.scrap_weight_for_update == 0:
                continue
            updated_available_scrap.append(
                AvailableScrap(
                    scrap.scrap_type,
                    float(convert_tons_to_kilograms(data.scrap_weight_for_update)),
                    scrap.location,
                )
            )
        else:
            updated_available_scrap.append(scrap)
    new_data = data.update_display_data_field(available_scraps=tuple(updated_available_scrap))
    new_data = new_data.update_field(scrap_mix_for_update=None)
    new_data = new_data.update_field(scrap_weight_for_update=None)

    # Remove user scrap limit row from table, if respective available scrap is removed
    for i, scrap_charge in enumerate(new_data.display_data.scrap_charges):
        updated_scrap_limits = []
        for limit in scrap_charge.scrap_limits:
            if limit.scrap_type == data.scrap_mix_for_update and data.scrap_weight_for_update == 0:
                continue
            updated_scrap_limits.append(limit)
        new_data = new_data.update_charge_field(index=i, scrap_limits=updated_scrap_limits)

    return save_current_data(new_data)


def append_weight_of_new_scrap(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    if (
        data.scrap_mix_for_append is None
        or data.scrap_weight_for_append is None
        or data.scrap_weight_for_append == 0
    ):
        return data
    updated_available_scraps = []
    scrap_was_updated = False
    for scrap in data.display_data.available_scraps:
        if scrap.scrap_type == data.scrap_mix_for_append:
            scrap_was_updated = True
            updated_available_scraps.append(
                AvailableScrap(
                    scrap.scrap_type,
                    scrap.weight + float(convert_tons_to_kilograms(data.scrap_weight_for_append)),
                    scrap.location,
                )
            )
        else:
            updated_available_scraps.append(scrap)
    if not scrap_was_updated:
        updated_available_scraps.append(
            AvailableScrap(
                data.scrap_mix_for_append,
                float(convert_tons_to_kilograms(data.scrap_weight_for_append)),
                INDOOR_SCRAP_NAME,
            )
        )
    new_data = data.update_display_data_field(available_scraps=tuple(updated_available_scraps))
    new_data = new_data.update_field(scrap_mix_for_append=None)
    new_data = new_data.update_field(scrap_weight_for_append=None)

    for i, scrap_charge in enumerate(new_data.display_data.scrap_charges):
        updated_scrap_limits = scrap_charge.scrap_limits + (ScrapMixLimit(data.scrap_mix_for_append),)
        new_data = new_data.update_charge_field(index=i, scrap_limits=updated_scrap_limits)

    return save_current_data(new_data)


def add_new_heat(data: ScrapLoadingStationViewModelV2, n_clicks: int) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data

    if data.steelshop is None:
        logger.info(
            f"Loading station {data.loading_station_name} with ID {data.loading_station_id} "
            f"has empty 'steelshop' attribute, so heat plan is not available."
        )
        heat_plan = None
    else:
        expected_heats = db_iars.get_next_planned_heats(steelshop=data.steelshop, num_of_heats=20)
        if expected_heats is None:
            heat_plan = None
        else:
            heat_plan = HeatPlan(int(datetime.utcnow().timestamp()), expected_heats)

    new_charge = ScrapChargeDisplayDataV2(
        scrap_limits=tuple([ScrapMixLimit(scrap.scrap_type) for scrap in data.display_data.available_scraps]),
        heat_plan=heat_plan,
    )
    new_charges = [*data.display_data.scrap_charges, new_charge]
    new_data = data.update_display_data_field(scrap_charges=new_charges)
    new_data = new_data.update_field(selected_row=len(new_charges) - 1)
    grade_ids = GradeIdsSelectorViewModel()
    new_data = new_data.update_field(available_grades=grade_ids.to_dropdown_options())
    return save_current_data(new_data)


def set_operator_comment(
    data: ScrapLoadingStationViewModelV2, comment: str
) -> ScrapLoadingStationViewModelV2:
    return data.update_last_optimization_field(comment=comment)


def open_results_detail(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    return data.update_field(results_detail_open=not data.results_detail_open)


def reduce_weight_of_available_scrap(data: ScrapLoadingStationViewModelV2) -> ScrapLoadingStationViewModelV2:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    # TODO find out why is this check needed here and if possible
    #  move it to confirm_charge function
    if maybe_optimization is None or not maybe_optimization.is_done() or maybe_optimization.result is None:
        return data
    new_available_scraps = []
    for available_scrap in data.display_data.available_scraps:
        for loaded_scrap in maybe_optimization.result.first_heat_scrap_weights.items():
            if available_scrap.scrap_type == loaded_scrap[0]:
                result_weight = round(available_scrap.weight - loaded_scrap[1], 1)
                if result_weight > 0:
                    new_available_scraps.append(
                        AvailableScrap(available_scrap.scrap_type, result_weight, available_scrap.location)
                    )
                break
        else:
            new_available_scraps.append(available_scrap)
    new_data = data.update_display_data_field(available_scraps=new_available_scraps)
    return new_data


def confirm_charge(data: ScrapLoadingStationViewModelV2, n_clicks: int) -> ScrapLoadingStationViewModelV2:
    """Create ScrapCharge"""
    if n_clicks == 0:
        return data

    # check if we have at least one successful optimization
    maybe_charge = data.get_selected_charge_field(lambda charge: charge)

    if maybe_charge is None:
        return data

    # save scrap charge
    _ = ScrapCharge.from_scrap_charge_display_data(
        maybe_charge,
        loading_station=LoadingStation.objects.get(pk=data.loading_station_id),
        operator_decision=LOADED_CHARGE_OPERATOR_DECISION,
        closed_at=datetime.now(tz=zoneinfo.ZoneInfo("UTC")),
    )

    # FIXME code below is broken, because updating operator decision has no effect on corresponding ScrapCharge data;
    #   however, since this function is obsolete and won't be used with new version of Loading Station UI,
    #   I guess we may ignore this bug
    # update view model
    new_data = (
        reduce_weight_of_available_scrap(data)
        .update_last_optimization_field(operator_decision=LOADED_CHARGE_OPERATOR_DECISION)
        .delete_selected_charge_field()
    )
    return save_current_data(new_data)


def set_debug_data_open(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    return data.update_field(debug_data_open=not data.debug_data_open)


def choose_charge(
    data: ScrapLoadingStationViewModelV2, selected_rows: Optional[List[int]]
) -> ScrapLoadingStationViewModelV2:
    if not selected_rows:
        return data.update_field(selected_row=None)
    return data.update_field(selected_row=selected_rows[0])


def set_heat_number(
    data: ScrapLoadingStationViewModelV2, heat_id: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    return data.update_selected_charge_field(heat_id=heat_id)


def auto_set_pig_iron_weight(data: ScrapLoadingStationViewModelV2) -> ScrapLoadingStationViewModelV2:
    scrap_weight = data.selected_total_scrap_weight
    if scrap_weight is not None:
        normal_heat_weight = NORMAL_HEAT_WEIGHT_DEFAULT
        grade_id = data.selected_grade_id
        if grade_id is not None:
            grade = steel_grades.get_grade_from_id(grade_id, date.today())
            normal_heat_weight = grade.normal_heat_weight
        return data.update_selected_charge_field(pig_iron_weight=normal_heat_weight - scrap_weight)
    return data


def set_chems_and_grade(
    data: ScrapLoadingStationViewModelV2, grade_id: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    new_data = (
        data.update_selected_charge_field(raw_fe_chem=get_raw_fe_chem_from_db())
        .update_selected_charge_field(grade_id=grade_id)
        .update_selected_charge_pig_iron_chem_field(S=get_pig_iron_s_for_grade(steel_grades, grade_id))
    )
    return auto_set_pig_iron_weight(new_data)


def set_raw_fe_chem(
    data: ScrapLoadingStationViewModelV2, raw_fe_chem: RawFeChemTableData
) -> ScrapLoadingStationViewModelV2:
    return data.update_selected_charge_field(raw_fe_chem=convert_table_data_to_raw_fe_chem(raw_fe_chem))


def set_scrap_limits(
    data: ScrapLoadingStationViewModelV2, scrap_limits: ScrapChargeLimitsTableData
) -> ScrapLoadingStationViewModelV2:
    return data.update_selected_charge_field(scrap_limits=convert_table_data_to_scrap_limits(scrap_limits))


def remove_charge(data: ScrapLoadingStationViewModelV2, n_clicks: int) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    new_data = data.delete_selected_charge_field()
    return save_current_data(new_data)


def toggle_show_advanced_settings(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    return data.update_field(advanced_settings_open=not data.advanced_settings_open)


T = TypeVar("T")


def start_optimization_for_selected_charge(
    data: ScrapLoadingStationViewModelV2, n_clicks: int
) -> ScrapLoadingStationViewModelV2:
    if n_clicks == 0:
        return data
    new_data = data.update_selected_charge_field(optimization_start_clicked=True)
    charge_data = new_data.get_selected_charge_field(lambda charge: charge)
    if charge_data is None:
        return new_data.update_field(error=True)

    # We want to load new model settings from database in case they were changed
    station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=new_data.loading_station_id)
    model_settings = station.model_settings
    if model_settings is None:
        return new_data.update_field(error=True)
    new_data = new_data.update_field(model_settings=model_settings)

    relaxable_lower_summing_limits_settings = tuple(station.relaxable_lower_summing_limit_settings.all())
    relaxable_upper_summing_limits_settings = tuple(station.relaxable_upper_summing_limit_settings.all())

    if has_errors(
        validate_charge_info(
            charge_data,
            relaxable_lower_summing_limits_settings,
            relaxable_upper_summing_limits_settings,
            data.display_data.available_scraps,
            model_settings,
        )
    ):
        if has_errors(new_data.selected_charge_limits_validation_result):
            return new_data.update_field(advanced_settings_open=True)
        return new_data

    optimization = start_optimization(
        charge_data,
        data.display_data.available_scraps,
        model_settings,
        convert_tons_to_kilograms(data.transfer_capacity or 0),
        loading_station_id=station.pk,
    )
    new_data = new_data.update_selected_charge_field(optimizations=(*charge_data.optimizations, optimization))
    return save_current_data(new_data)


def set_optimization_status(data: ScrapLoadingStationViewModelV2, _: int) -> ScrapLoadingStationViewModelV2:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None:
        return data
    new_data = data.update_last_optimization_field(**update_optimization_status(maybe_optimization))
    return save_current_data(new_data)


def readonly_reload(data: ScrapLoadingStationViewModelV2, _: int) -> ScrapLoadingStationViewModelV2:
    db_data = load_initial_data(data.loading_station_id, data.user)
    charges_count = len(db_data.display_data.scrap_charges)
    if (data.selected_row is not None) and (charges_count <= data.selected_row):
        new_selected_row = charges_count - 1 if charges_count > 0 else None
    else:
        new_selected_row = data.selected_row
    return db_data.update_field(
        selected_row=new_selected_row,
        advanced_settings_open=data.advanced_settings_open,
        results_detail_open=data.results_detail_open,
        available_grades=data.available_grades,
    )


def change_control(data: ScrapLoadingStationViewModelV2, _: int) -> ScrapLoadingStationViewModelV2:
    with transaction.atomic():
        user = User.objects.get(username=data.user)
        LoadingStation.objects.select_for_update(nowait=True, of=("self", "user_in_control")).filter(
            pk=data.loading_station_id
        ).update(user_in_control=user)

    return data.update_field(control_gained=True)


def set_scrap_and_pig_iron_weight(
    data: ScrapLoadingStationViewModelV2, scrap_weight: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    new_data = data.update_selected_charge_field(
        total_scrap_weight=(
            convert_tons_to_kilograms(float(scrap_weight)) if scrap_weight is not None else None
        )
    )
    return auto_set_pig_iron_weight(new_data)


def set_pig_iron_weight(
    data: ScrapLoadingStationViewModelV2, pig_iron_weight: Optional[int]
) -> ScrapLoadingStationViewModelV2:
    if pig_iron_weight is None:
        return data
    return data.update_selected_charge_field(
        pig_iron_weight=convert_tons_to_kilograms(float(pig_iron_weight))
    )


def parse_basket_ids(basket_ids: Optional[str]) -> Tuple[int, ...]:
    if basket_ids:
        try:
            return tuple([int(val) for val in basket_ids.split(",")])
        except Exception as _:  # pylint: disable=broad-except
            pass
    return ()


def set_basket_ids(
    data: ScrapLoadingStationViewModelV2, basket_ids: Optional[str]
) -> ScrapLoadingStationViewModelV2:
    return data.update_selected_charge_field(basket_ids=parse_basket_ids(basket_ids))


def set_switched_basket_ids(
    data: ScrapLoadingStationViewModelV2, switched_basket_ids: Optional[str]
) -> ScrapLoadingStationViewModelV2:
    return data.update_selected_charge_field(switched_basket_ids=parse_basket_ids(switched_basket_ids))


def get_results_detail_button_text(data: ScrapLoadingStationViewModelV2) -> str:
    return " Skryť detailné výsledky" if data.results_detail_open else " Zobraziť detailné výsledky"


def hide_optimization_result_error(data: ScrapLoadingStationViewModelV2) -> bool:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or not maybe_optimization.has_result_error():
        return True
    return False


def get_optimization_result_error(data: ScrapLoadingStationViewModelV2) -> str:
    maybe_optimization = data.get_last_optimization_for_selected_charge()
    if maybe_optimization is None or not maybe_optimization.has_result_error():
        return ""
    return (
        f"Nastala chyba pri optimalizácií s identifikačným číslom {maybe_optimization.optimization_id}."
        + " Skontrolujte vstupy a skúste znova. V prípade opakovaných problémov kontaktujte IT "
        + "(JTkacik@sk.uss.com) a uveďte identifikačné číslo optimalizácie."
    )


def hide_results_detail_table(data: ScrapLoadingStationViewModelV2) -> bool:
    return not data.results_detail_open


def hide_if_ss1(data: ScrapLoadingStationViewModelV2) -> bool:
    return data.steelshop == 1


def generate_validated_field_outputs(
    component_name: str,
    component_value_field: str,
    value_getter: Callable[[ScrapLoadingStationViewModelV2], Any],
    validation_result_getter: Callable[[ScrapLoadingStationViewModelV2], ChargeInfoValidationResult],
) -> Tuple[OutputField, OutputField, OutputField]:
    return (
        OutputField(component_name, component_value_field, value_getter),
        OutputField(
            component_name + "-msg",
            "children",
            lambda data: get_msg_from_validation_result(validation_result_getter(data)),
        ),
        OutputField(
            component_name + "-group",
            "className",
            lambda data: get_class_from_validation_result(validation_result_getter(data)),
        ),
    )


def register_all_callbacks(app: DjangoDash, input_fields: InputFields, output_fields: OutputFields):
    app.expanded_callback(
        [Output(DISPLAY_DATA_STORE_ID, "children"), Output(GLOBAL_ERROR_MODAL_ID_INPUT, "is_open")],
        [Input(field.component_name, field.component_value) for field in input_fields],
        [State(LOADING_STATION_ID_DIV_ID, "children"), State(DISPLAY_DATA_STORE_ID, "children")],
    )(create_process_input_callback(input_fields))

    app.expanded_callback(
        [Output(field.component_name, field.component_value) for field in output_fields]
        + [Output(GLOBAL_ERROR_MODAL_ID_OUTPUT, "is_open")],
        [Input(DISPLAY_DATA_STORE_ID, "children")],
        [State(field.component_name, field.component_value) for field in output_fields],
    )(create_process_output_callback(output_fields))


common_input_fields = [
    InputField(SCRAP_CHARGE_TABLE_ID, "selected_rows", choose_charge),
    InputField(DETAIL_OPTIMIZATION_BUTTON_RESULT_ID, "n_clicks", open_results_detail),
    InputField(COLLAPSE_BUTTON_ID, "n_clicks", toggle_show_advanced_settings),
    InputField(DEBUG_COLLAPSE_BTN_ID, "n_clicks", set_debug_data_open),
]

common_output_fields = [
    OutputField(DEBUG_ELEMENT_ID, "children", debug_output),
    OutputField(SCRAP_TABLE_ID, "data", scrap_table_output),
    OutputField(SCRAP_CHARGE_TABLE_ID, "data", charges_table_output),
    OutputField(CHARGE_CARD_ID + "-div", "hidden", hide_charge_card),
    *generate_validated_field_outputs(
        WEIGHT_INPUT_ID,
        "value",
        ScrapLoadingStationViewModelV2.selected_total_scrap_weight_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_total_scrap_weight_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        PIG_IRON_WEIGHT_INPUT_ID,
        "value",
        ScrapLoadingStationViewModelV2.selected_pig_iron_weight_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_pig_iron_weight_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        BASKET_NUMBER_INPUT_ID,
        "value",
        ScrapLoadingStationViewModelV2.selected_basket_ids_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_basket_ids_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        SWITCHED_BASKET_NUMBER_INPUT_ID,
        "value",
        ScrapLoadingStationViewModelV2.selected_switched_basket_ids_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_switched_basket_ids_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        GRADE_SELECTOR_ID,
        "value",
        ScrapLoadingStationViewModelV2.selected_grade_id.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_grade_id_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        CHARGE_LIMITS_TABLE_ID,
        "data",
        ScrapLoadingStationViewModelV2.selected_charge_limits_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_charge_limits_validation_result.fget,  # type: ignore
    ),
    *generate_validated_field_outputs(
        RAW_FE_CHEM_TABLE_ID,
        "data",
        ScrapLoadingStationViewModelV2.selected_pig_iron_chem_display_value.fget,  # type: ignore
        ScrapLoadingStationViewModelV2.selected_pig_iron_chem_validation_result.fget,  # type: ignore
    ),
    OutputField(CHARGE_OPTIMIZATION_CARD_HEADER_ID, "children", get_friendly_heat_name),
    OutputField(COLLAPSE_ADVANCE_SETTINGS_ID, "is_open", open_advanced_settings),
    OutputField(COLLAPSE_BUTTON_ID, "outline", open_advanced_settings),
    OutputField(PROGRESS_BAR_ID + "-div", "hidden", optimization_not_running),
    OutputField(OPTIMIZATION_PROGRESS_BAR_REFRESH_INTERVAL_ID, "disabled", optimization_not_running),
    OutputField(PROGRESS_BAR_ID, "children", get_optimization_progress_text),
    OutputField(PROGRESS_BAR_ID, "value", get_optimization_progress_value),
    OutputField(OPTIMIZATION_RESULTS_TABLE_ID, "data", get_optimization_result),
    OutputField(OPTIMIZATION_INPUT_DIV_ID, "hidden", hide_optimization_result),
    OutputField(DETAIL_OPTIMIZATION_TABLE_RESULT_ID, "data", get_optimization_detail),
    OutputField(
        OPTIMIZATION_RESULT_PROBABILITY_INFO_MSG_ID, "children", get_optimization_result_probability_text
    ),
    OutputField(
        OPTIMIZATION_RESULT_PROBABILITY_INFO_MSG_ID, "style", get_optimization_result_probability_style
    ),
    OutputField(DETAIL_OPTIMIZATION_RESULT_TABLE_ID, "hidden", hide_results_detail_table),
    OutputField(DETAIL_OPTIMIZATION_BUTTON_RESULT_ID, "children", get_results_detail_button_text),
    OutputField(STATUS_ID, "children", update_refresh_time),
    OutputField(CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID + "-div", "hidden", hide_optimization_result_error),
    OutputField(CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID, "children", get_optimization_result_error),
    OutputField(SCRAP_CHARGE_TABLE_ID, "selected_rows", force_charge),
    OutputField(USER_NAME_ID, "children", update_user_name),
    OutputField(USER_IN_CONTROL_NAME_ID, "children", update_user_in_control_name),
    OutputField(USER_IN_CONTROL_NAME_ID + "-div", "hidden", hide_get_control_button),
    OutputField(STATION_NAME_ID, "children", update_station_name),
    OutputField(DEBUG_ELEMENT_ID + "-div", "hidden", hide_debug_element),
    OutputField(RAW_FE_CHEM_TABLE_ID + "-div", "hidden", hide_debug_element),
    OutputField(DETAIL_OPTIMIZATION_BUTTON_RESULT_ID + "-div", "hidden", hide_debug_element),
    OutputField(DEBUG_COLLAPSE_ID, "is_open", open_debug_data),
    OutputField(DEBUG_COLLAPSE_BTN_ID, "children", change_name_debug_data_btn),
    OutputField(SCRAP_TABLE_ID, "style_cell_conditional", show_scrap_location_on_ss1),
    OutputField(SWITCHED_BASKET_NUMBER_INPUT_ID + "-group", "hidden", hide_if_ss1),
]

register_all_callbacks(
    loading_scrap_station_app_2,
    [
        InputField(SCRAP_TABLE_ID, "data", scrap_table_input),
        InputField(NEW_HEAT_BUTTON_ID, "n_clicks", add_new_heat),
        InputField(WEIGHT_INPUT_ID, "value", set_scrap_and_pig_iron_weight),
        InputField(PIG_IRON_WEIGHT_INPUT_ID, "value", set_pig_iron_weight),
        InputField(BASKET_NUMBER_INPUT_ID, "value", set_basket_ids),
        InputField(SWITCHED_BASKET_NUMBER_INPUT_ID, "value", set_switched_basket_ids),
        InputField(GRADE_SELECTOR_ID, "value", set_chems_and_grade),
        InputField(CARD_HEADER_DELETE_CHARGE_BUTTON, "n_clicks", remove_charge),
        InputField(RAW_FE_CHEM_TABLE_ID, "data", set_raw_fe_chem),
        InputField(CHARGE_LIMITS_TABLE_ID, "data", set_scrap_limits),
        InputField(CLEAR_SCRAP_LIMITS_BUTTON_ID, "n_clicks", clear_scrap_limits),
        InputField(READ_SCRAP_LIMITS_FROM_RESULT_BUTTON_ID, "n_clicks", set_scrap_limits_from_last_result),
        InputField(CALCULATE_OUTPUT_BUTTON_ID, "n_clicks", start_optimization_for_selected_charge),
        InputField(RECALCULATE_OUTPUT_BUTTON_ID, "n_clicks", start_optimization_for_selected_charge),
        InputField(OPTIMIZATION_PROGRESS_BAR_REFRESH_INTERVAL_ID, "n_intervals", set_optimization_status),
        InputField(COMMENT_INPUT_ID, "value", set_operator_comment),
        InputField(CONFIRM_CHARGE_BUTTON_ID, "n_clicks", confirm_charge),
        InputField(APPEND_SCRAP_DROPDOWN_ID, "value", choose_scrap_for_append_weight),
        InputField(CHANGE_WEIGHT_SCRAP_DROPDOWN_ID, "value", choose_scrap_for_update_weight),
        InputField(CHANGE_WEIGHT_INPUT_ID, "value", set_new_scrap_weight_for_update),
        InputField(APPEND_WEIGHT_INPUT_ID, "value", set_new_scrap_weight_for_append),
        InputField(CHANGE_WEIGHT_UPDATE_BTN_ID, "n_clicks", update_weight_of_available_scrap),
        InputField(APPEND_SCRAP_BTN_ID, "n_clicks", append_weight_of_new_scrap),
        InputField(TRANSFER_CAPACITY_WEIGHT_INPUT_ID, "value", set_transfer_capacity),
    ]
    + common_input_fields,
    [
        OutputField(WEIGHT_INPUT_ID, "disabled", hide_disable_element_on_optimization_done),
        OutputField(PIG_IRON_WEIGHT_INPUT_ID, "disabled", hide_disable_element_on_optimization_done),
        OutputField(BASKET_NUMBER_INPUT_ID, "disabled", hide_disable_element_on_optimization_done),
        OutputField(GRADE_SELECTOR_ID, "disabled", hide_disable_element_on_optimization_done),
        OutputField(CALCULATE_OUTPUT_BUTTON_ID + "-div", "hidden", hide_element_on_optimization_done),
        OutputField(CALCULATE_OUTPUT_BUTTON_ID, "disabled", disable_element_on_scrap_limit_validation_error),
        OutputField(
            RECALCULATE_OUTPUT_BUTTON_ID, "disabled", disable_element_on_scrap_limit_validation_error
        ),
        OutputField(CHARGE_LIMITS_TABLE_ID, "editable", disable_advance_setting_table),
        OutputField(RAW_FE_CHEM_TABLE_ID, "editable", disable_advance_setting_table),
        OutputField(COMMENT_INPUT_ID, "value", get_operator_comment),
        OutputField(CHANGE_WEIGHT_SCRAP_DROPDOWN_ID, "options", set_scrap_to_change_scrap_weight_dropdown),
        OutputField(CHANGE_WEIGHT_SCRAP_DROPDOWN_ID, "value", get_scrap_mix_for_update),
        OutputField(CHANGE_WEIGHT_INPUT_ID, "value", get_scrap_weight_for_update),
        OutputField(CHANGE_WEIGHT_UPDATE_BTN_ID, "disabled", do_not_have_data_for_weight_update),
        OutputField(APPEND_SCRAP_DROPDOWN_ID, "options", set_all_available_scrap_types_to_dropdown),
        OutputField(APPEND_SCRAP_DROPDOWN_ID, "value", get_scrap_mix_for_append),
        OutputField(APPEND_WEIGHT_INPUT_ID, "value", get_scrap_weight_for_append),
        OutputField(APPEND_SCRAP_BTN_ID, "disabled", do_not_have_scrap_for_weight_append),
        OutputField(GRADE_SELECTOR_ID, "options", set_grade_options),
        OutputField(CONFIRM_CHARGE_BUTTON_ID, "disabled", do_not_have_data_for_confirm_charge),
        OutputField(CONFIRM_CHARGE_BUTTON_MSG_ID, "children", do_not_have_data_for_confirm_charge_msg),
        OutputField(CONFIRM_CHARGE_BUTTON_MSG_ID, "hidden", have_data_for_confirm_charge),
        OutputField(CONTROL_CHANGED_MODAL_ID, "is_open", control_lost),
        OutputField(TRANSFER_CAPACITY_WEIGHT_INPUT_ID, "value", get_transfer_capacity),
        OutputField(TRANSFER_CAPACITY_WEIGHT_INPUT_ID + "-div", "hidden", hide_if_not_ss1),
    ]
    + common_output_fields,
)


register_all_callbacks(
    loading_scrap_station_read_only_app_2,
    [
        InputField(RELOAD_DATA_INTERVAL_ID, "n_intervals", readonly_reload),
        InputField(USER_IN_CONTROL_NAME_ID, "n_clicks", change_control),
    ]
    + common_input_fields,
    [
        OutputField(REFRESH_REQUEST_MODAL_ID, "is_open", control_gained),
        OutputField(RELOAD_DATA_INTERVAL_ID, "disabled", control_gained),
    ]
    + common_output_fields,
)
