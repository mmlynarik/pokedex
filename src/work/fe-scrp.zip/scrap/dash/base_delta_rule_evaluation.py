from typing import Optional
from ..utils import is_zone_domestic

from ..models import BaseDeltaRule, ScrapOffer
from scrap_core import (
    PRIME_GROUP_NAME,
    CUT_GROUP_NAME,
    SCRAP_GROUP_MAPPING,
)


def evaluate_base_delta_rule(base_delta_rule: BaseDeltaRule, scrap_offer: ScrapOffer) -> bool:
    if not check_mandatory_fields_for_rule_evaluation(
        base_delta_rule=base_delta_rule, scrap_offer=scrap_offer
    ):
        return False

    scrap_type_comparison = base_delta_rule.scrap_type == scrap_offer.scrap_type
    zone_comparison = base_delta_rule.zone == scrap_offer.zone
    supplier_comparison = base_delta_rule.supplier == scrap_offer.supplier

    if is_rule_domestic(base_delta_rule=base_delta_rule):
        if not is_offer_domestic(scrap_offer=scrap_offer):
            return False
        supplier_comparison = True
    else:
        if None in (
            base_delta_rule.supplier,
            scrap_offer.supplier,
        ):
            return False

    if is_rule_prime_cut(base_delta_rule=base_delta_rule):
        if not is_scrap_type_in_right_group(
            base_delta_scrap_type=base_delta_rule.scrap_type,
            scrap_offer_scrap_type=scrap_offer.scrap_type,
        ):
            return False
        scrap_type_comparison = True

    return scrap_type_comparison and zone_comparison and supplier_comparison


def check_mandatory_fields_for_rule_evaluation(
    base_delta_rule: BaseDeltaRule, scrap_offer: ScrapOffer
) -> bool:
    return None not in (
        base_delta_rule.scrap_type,
        base_delta_rule.zone,
        scrap_offer.scrap_type,
        scrap_offer.zone,
    )


def is_rule_prime_cut(base_delta_rule: BaseDeltaRule) -> bool:
    return base_delta_rule.scrap_type in (
        PRIME_GROUP_NAME,
        CUT_GROUP_NAME,
    )


def is_scrap_type_in_right_group(
    base_delta_scrap_type: Optional[str], scrap_offer_scrap_type: Optional[str]
) -> bool:
    if None in (base_delta_scrap_type, scrap_offer_scrap_type):
        return False
    scrap_type_group = SCRAP_GROUP_MAPPING[str(scrap_offer_scrap_type)]  # type: ignore
    # FIXME base_delta_scrap_type is a ScrapType literal (or shall be with correct typing),
    #  but scrap_type_group is a ScrapTypeGroup literal. Consequently their comparison is always false
    #  and it hence it is either a bug or a useless code.
    return scrap_type_group == base_delta_scrap_type


def is_rule_domestic(base_delta_rule: BaseDeltaRule) -> bool:
    return is_zone_domestic(str(base_delta_rule.zone))


def is_offer_domestic(scrap_offer: ScrapOffer) -> bool:
    return is_zone_domestic(str(scrap_offer.zone))
