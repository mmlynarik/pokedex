from string import Template

from ussksdc.core.datamodel import JsCode
from vsadzka.settings import SCALE_SS1_V1, SCALE_SS1_V2, SCALE_SS2_V8, SCALE_SS2_V9


def get_loading_station_cs_ctx_factory() -> JsCode:
    return JsCode(
        Template(
            """
        class Context {
            #vm;

            constructor(viewModel){
                this.#vm = viewModel;
                this.models = sdc.models;
                this.debug = this.#vm.initial_state.raw_data.debug;
                this.steelshop = this.#vm.initial_state.raw_data.steelshop;
                this.useScrapYardApi = this.#vm.initial_state.raw_data.use_scrap_yard_api;
                this.readOnly = this.#vm.initial_state.raw_data.read_only;
                this.scaleControl = this.#vm.initial_state.raw_data.scale_control;
                this.messageDataClass = this.#vm.global_alert.Message();

                this.weightingSwitchedBasketModals = [
                    new this.#vm.scrap_charges.table.scrap_charges_cards.card.inputs.swiched_basket_ids.weighting_switched_basket.WeightingSwitchedBasketCtx(
                        this.#vm.scrap_charges.table.scrap_charges_cards.card.inputs.swiched_basket_ids.weighting_switched_basket,
                        this
                    ),
                    new this.#vm.scrap_charges.table.scrap_charges_cards.card_1.inputs.swiched_basket_ids.weighting_switched_basket.WeightingSwitchedBasketCtx(
                        this.#vm.scrap_charges.table.scrap_charges_cards.card_1.inputs.swiched_basket_ids.weighting_switched_basket,
                        this
                    ),
                ];
            }
            
            get parent(){
                return this.#vm;
            }

            get scrapChargeConfig(){
                return (this.parent.scrap_charges.table.scrap_charge_config || {});
            }

            // ---- Models ---- //
            selectedWeightedScrapsModel(idx){
                if (this.selectedScrapChargeId(idx) === -1)
                    return null;
                return this.models.weightedScrap.getFilteredData(this.selectedScrapChargeId(idx));
            }

            // ---- Scrap charges ---- //

            get switchedBasketsModal(){
                return {
                    "scrap_charges.table.scrap_charges_cards.card": this.weightingSwitchedBasketModals[0],
                    "scrap_charges.table.scrap_charges_cards.card_1": this.weightingSwitchedBasketModals[1],
                };
            }

            get scrapChargeCardComponent(){
                return {
                    "scrap_charges.table.scrap_charges_cards.card": this.parent.scrap_charges.table.scrap_charges_cards.card,
                    "scrap_charges.table.scrap_charges_cards.card_1": this.parent.scrap_charges.table.scrap_charges_cards.card_1
                };
            }

            getPathToScrapChargeCard(component){
                return component.path.slice(0, 4).join('.');
            }

            getSwitchedBasketsModal(component){
                const pathToScrapChargeCard = this.getPathToScrapChargeCard(component);
                return this.switchedBasketsModal[pathToScrapChargeCard];
            }

            getCard(component){
                const pathToScrapChargeCard = this.getPathToScrapChargeCard(component);
                return this.scrapChargeCardComponent[pathToScrapChargeCard];
            }

            getScrapChargeIdByCardIdx(cardIndex){
                const selected = (this.scrapChargeConfig.selectedScrapCharge || [null, null]);
                return selected.at(cardIndex);
            }

            getScrapChargeId(component){
                const cardComponent = this.getCard(component);
                const cardIdx = cardComponent.card_index;

                return this.getScrapChargeIdByCardIdx(cardIdx);
            }

            get scrapChargeIdToClose(){
                return this.parent.scrap_charges.table.scrap_charge_id;
            }

            getScrapCharge(component){
                const scrapChargeId = this.getScrapChargeId(component);
                if (!scrapChargeId){
                    return null;
                }

                return this.models.scrapCharges.get(scrapChargeId);
            }

            getScrapChargeById(scrapChargeId){
                if (!scrapChargeId){
                    return null;
                }
                return this.models.scrapCharges.get(scrapChargeId);
            }

            getWeightedScraps(scrapChargeId){
                if (!scrapChargeId){
                    return null;
                }
                return this.models.weightedScrap.getFilteredData(scrapChargeId);
            }

            getLastOptimization(scrapCharge){
                return (scrapCharge?.optimizations || []).at(-1);
            }

            selectedScrapChargeId(idx){
                // return this.#vm.scrap_charges.table.getScrapChargeId(idx);
                return null;
            }

            selectedScrapCharge(idx){
                const selectedScrapCharge = this.selectedScrapChargeId(idx);
                if (selectedScrapCharge === null)
                    return null;
                return this.models.scrapCharges.get(selectedScrapCharge);
            }

            updateSelectedScrapCharge(scrapChargeId, updatedFields){
                if (scrapChargeId !== null)
                    this.models.scrapCharges.update(scrapChargeId, updatedFields);
            }

            // ---- Inputs ---- //

            basketIds(component){
                const card = this.getCard(component);
                return card.inputs.basket_ids.basket_ids ?? [];
            }

            switchedBasketIds(component){
                const card = this.getCard(component);
                return card.inputs.swiched_basket_ids.switched_baskets ?? [];
            }

            grade(component){
                const card = this.getCard(component);
                return card.inputs.grade_and_weight_inputs.grade ?? null;
            }

            scrapWeight(component){
                return this.getCard(component)?.inputs.grade_and_weight_inputs.scrap_weight || null;
            }

            pigIronWeight(component){
                return this.getCard(component)?.inputs.grade_and_weight_inputs.pig_iron.weight || null;
            }

            isWetScrap(component){
                return this.getCard(component)?.decision.dry_or_wet.isWetScrap();
            }

            isLoadedToReserve(component){
                return this.getCard(component)?.decision.standard_or_reserve.isLoadedToReserve();
            }

            isInputsSameAsOptimSnapshot(scrapChargeId){
                if (scrapChargeId === null){
                    return false;
                }
                
                const lastOptim = this.selectedScrapChargeOptimization(scrapChargeId);
                if (lastOptim?.inputs_snapshot == null){
                    return true;
                }
                    
                const lastInputs = lastOptim.inputs_snapshot;
                const scrapCharge = this.getScrapChargeById(scrapChargeId);
                return [
                    this.areArraysSame(scrapCharge.scrap_limits.slice(), lastInputs.scrap_limits.slice()),
                    scrapCharge.grade_id === lastInputs.grade_id,
                    scrapCharge.total_scrap_weight === lastInputs.total_scrap_weight,
                    scrapCharge.pig_iron_weight === lastInputs.pig_iron_weight,
                ].every(Boolean);
            }

            // ---- Optimization ---- //

            selectedScrapChargeOptimization(scrapChargeId){
                if (!scrapChargeId){
                    return null;
                }
                const scrapCharge = this.models.scrapCharges.get(scrapChargeId);
                if (scrapCharge?.optimizations == null || scrapCharge.optimizations.length === 0)
                    return null
                return scrapCharge.optimizations.at(-1);
            }
            
            hasValidOptimizationResult(scrapChargeId){
                const lastOptimization = this.selectedScrapChargeOptimization(scrapChargeId);
                return (
                    lastOptimization === null ||
                    lastOptimization.result?.error != null
                );
            }

            // ---- Scales ---- //

            get scaleIds(){
                if (this.steelshop === 1)
                    return ["$ss1_v1", "$ss1_v2"];
                return ["$ss2_v8", "$ss2_v9"];
            }

            get selectedScaleIds(){
                const cards = Object.values(this.scrapChargeCardComponent);
                return cards.map(card => (card.result.scale_selector.active_scales ?? [])).flat();
            }

            selectedScales(component){
                const cardComponent = this.getCard(component);
                return (cardComponent.result.scale_selector.active_scales ?? []);
            }
            
            isScaleSelected(component){
                return (this.selectedScales(component).length !== 0)
            }
            
            isWeighingStopped(scrapChargeId){
                if (scrapChargeId === null){
                    return false;
                }
                const weightedScrapModel = this.getWeightedScraps(scrapChargeId);
                const notStoppedWeighting = (
                    Object.values(weightedScrapModel.getAll())
                    .find(val => val.end === null)
                );
                return (notStoppedWeighting === undefined);
            }
            
            isScaleBasketMapSet(component){
                const card = this.getCard(component);
                const baskets = card.inputs.basket_ids.basket_ids;
                               
                let scale_assigned_baskets = [
                    baskets[card.result.scale_weightning.basket.basket],
                    baskets[card.result.scale_weightning_2.basket.basket]
                ].filter(item => !!item);
                
                // check that all baskets are scale assigned
                return [...baskets].sort().toString() === scale_assigned_baskets.sort().toString();
            }
            
            get scaleData(){
                let data = [];
                
                let data_1 = this.#vm?.scale_data_1.scale_data?.data;

                (data_1 != null) ? data.push(JSON.parse(data_1)) : data.push(null);
                
                let data_2 = this.#vm?.scale_data_2.scale_data?.data;

                (data_2 != null) ? data.push(JSON.parse(data_2)) : data.push(null);               
                    
                return data;
            }
            
            scaleId(scaleIdx){
                return this.scaleIds[scaleIdx];
            }

            scaleDataFor(scaleId){
                return this.scaleData[this.scaleIds.indexOf(scaleId)];
            }
            
            getScaleState(scaleIdx){
                return Object.values(
                    this.models.scaleState.getAll()
                ).find(state => state.scale_id == this.scaleIds[scaleIdx])
            }

            /// Utils
            
            createClientSideMsg(msg, level = 'success'){
                return JSON.stringify(new this.messageDataClass(msg, level));
            }

            tonsToKgs(weight){
                return (Number(weight) === weight) ? weight * 1000 : weight;
            }

            kgsToTons(weight){
                return (Number(weight) === weight) ? weight / 1000 : weight;
            }

            sum(iterable){
                return iterable.reduce((partialSum, a) => partialSum + a, 0)
            }

            sortObject(unordered){
                if (typeof unordered === 'object' && unordered !== null){
                    return Object.keys(unordered).sort().reduce(
                        (obj, key) => { 
                            obj[key] = this.sortObject(unordered[key]); 
                            return obj;
                            }, 
                        {}
                    );
                }
                return unordered;
            }
                
            areArraysSame(arr1, arr2){
                const arr1_as_string = JSON.stringify(
                    arr1.map(
                        function(data){
                            this.sortObject(data)
                        }.bind(this)
                    ).map(
                        function(data){
                            JSON.stringify(data)
                        }.bind(this)
                    ).sort()
                );
                const arr2_as_string = JSON.stringify(
                    arr2.map(
                        function(data){
                            this.sortObject(data)
                        }.bind(this)
                    ).map(
                        function(data){
                            JSON.stringify(data)
                        }.bind(this)
                    ).sort()
                );
                return  arr1_as_string === arr2_as_string;
            } 
            
            syncClientSideChanges(){
                if (!this.models.availableScraps.isSynced)
                    this.models.availableScraps.save();

                if (!this.models.scrapCharges.isSynced)
                    this.models.scrapCharges.save();
                    
                if (!this.models.weightedScrap.isSynced)
                    this.models.weightedScrap.save();   
            }
            
            getAvailableScrap(){
                const all_scrap = this.models.availableScraps.getAll()
                // filter out available scrap with 0 weight, i.e. return "truly available scrap" only
                return Object.fromEntries(Object.entries(all_scrap).filter(([id, item]) => item["weight"] > 0));
            }
        }
        """
        ).substitute(ss1_v1=SCALE_SS1_V1, ss1_v2=SCALE_SS1_V2, ss2_v8=SCALE_SS2_V8, ss2_v9=SCALE_SS2_V9)
    )
