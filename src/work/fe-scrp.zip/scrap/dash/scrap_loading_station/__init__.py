import logging
from pathlib import Path

import ussksdc as sdc
from common.dash import DjangoPlotlyDashCallbackContext
from django_plotly_dash import DjangoDash
from scrap.dash.scrap_loading_station.context import get_loading_station_cs_ctx_factory
from scrap.dash.scrap_loading_station.datasource import js_datasource
from scrap.dash.scrap_loading_station.view_model import LoadingStationCtx, LoadingStationVM
from vsadzka.settings import APP_HOST, APP_PORT, STATIC_ROOT

logger = logging.getLogger(__name__)


class ScrapLoadingStationConf:
    def __init__(self, read_only: bool) -> None:
        self.read_only: bool = read_only
        self.host: str = APP_HOST
        self.port: int = APP_PORT


## Register app

NAME_APP = "LoadingScrapStation"
PATH_TO_ASSETS = "scrap/loading_station/assets"

config = ScrapLoadingStationConf(False)

scrap_loading_station_app = DjangoDash(NAME_APP, serve_locally=True, add_bootstrap_links=True)

sdc.sdc_initialize_app(  # type: ignore
    scrap_loading_station_app,
    LoadingStationVM,
    LoadingStationCtx,
    get_loading_station_cs_ctx_factory,
    DjangoPlotlyDashCallbackContext,
    Path(STATIC_ROOT) / PATH_TO_ASSETS,
    config,
    js_datasource,
)

## Register read only app

NAME_READ_ONLY_APP = "LoadingScrapStationReadOnly"
PATH_TO_ASSETS_READ_ONLY_APP = "scrap/loading_station/assets/read_only"

ro_config = ScrapLoadingStationConf(True)

scrap_loading_station_ro_app = DjangoDash(NAME_READ_ONLY_APP, serve_locally=True, add_bootstrap_links=True)

sdc.sdc_initialize_app(  # type: ignore
    scrap_loading_station_ro_app,
    LoadingStationVM,
    LoadingStationCtx,
    get_loading_station_cs_ctx_factory,
    DjangoPlotlyDashCallbackContext,
    Path(STATIC_ROOT) / PATH_TO_ASSETS_READ_ONLY_APP,
    ro_config,
    js_datasource,
)
