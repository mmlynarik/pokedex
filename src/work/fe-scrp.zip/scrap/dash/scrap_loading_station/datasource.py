import logging
from typing import Any, Collection, Dict, List, Optional, Protocol, Tuple

from django.contrib.auth.models import User
from django.forms.models import model_to_dict
from ussksdc.core.datamodel import JsCode, JsModel
from vsadzka.settings import SCALE_SS1_V1, SCALE_SS1_V2, SCALE_SS2_V8, SCALE_SS2_V9

from scrap.dash.components.available_scraps.model.available_scraps.datasource import (
    AvailableScrapAPI,
    AvailableScrapDatasource,
    AvailableScrapDb,
)
from scrap.dash.components.available_scraps.model.scrap_definitions.datasource import (
    AllScrapDefinitionsDatasource,
    AllScrapDefinitionsDb,
)
from scrap.dash.components.protocols import DebugModeSource, SteelShopSource
from scrap.dash.components.scrap_charges.model.basket_waggon_weight.datasource import (
    BasketWaggonWeightDb,
)
from scrap.dash.components.scrap_charges.model.basket_weight.datasource import (
    BasketWeightDb,
)
from scrap.dash.components.scrap_charges.model.grade_definitions.datasource import (
    GradeDefinitionsDatasource,
    GradeDefinitionsDb,
)
from scrap.dash.components.scrap_charges.model.optimizations.datasource import (
    MultipleHeatsOptimizationDb,
)
from scrap.dash.components.scrap_charges.model.scale_state.datasource import (
    ScrapCurrentStateDb,
)
from scrap.dash.components.scrap_charges.model.scrap_charge.datasource import (
    ScrapChargesDb,
)
from scrap.dash.components.scrap_charges.model.weighted_scrap.datasource import (
    ConditionalWeightedScrapDb,
    WeightedScrapDb,
)
from scrap.models import (
    LoadingStation,
    ModelSettings,
    Operator,
    RelaxableLowerSummingLimitSetting,
    RelaxableRiskLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScrapDefinition,
    all_prefetched_loading_station_query_set,
)

log = logging.getLogger(__name__)

ScrapTableData = Collection[Dict[str, Any]]


class RelaxableSummingLimitsDataSource(Protocol):
    relaxable_risk_limits_settings: Tuple[RelaxableRiskLimitSetting]
    relaxable_upper_summing_limits_settings: Tuple[RelaxableUpperSummingLimitSetting]
    relaxable_lower_summing_limits_settings: Tuple[RelaxableLowerSummingLimitSetting]


class ModelSettingsDataSource(Protocol):
    model_settings: Optional[ModelSettings]


class ScrapLoadingStationDataSource(
    SteelShopSource,
    RelaxableSummingLimitsDataSource,
    DebugModeSource,
    ModelSettingsDataSource,
):
    loading_station_id: int
    name: str
    user_in_control: User
    operator_in_control: Operator
    authorized_users: Collection[str]
    sending_telegram_required: bool
    use_scrap_yard_api: bool
    scale_control: bool
    level_2: bool
    scale_ids: Tuple[str, str]


def get_cached_loading_station(_id: int) -> LoadingStation:
    return all_prefetched_loading_station_query_set().get(id=_id)


class DbScrapLoadingStationDataSource:
    def __init__(self, loading_station_id: int) -> None:
        self.loading_station = get_cached_loading_station(loading_station_id)
        self.loading_station_id = loading_station_id

    @property
    def name(self) -> str:
        return self.loading_station.name

    @property
    def user_in_control(self) -> User:
        return self.loading_station.user_in_control

    @property
    def operator_in_control(self) -> Operator:
        return self.user_in_control.operator

    @property
    def authorized_users(self) -> Tuple[str, ...]:
        return tuple(user.username for user in self.loading_station.authorized_users.all())

    @property
    def relaxable_risk_limits_settings(self) -> Tuple[RelaxableRiskLimitSetting]:
        return tuple(self.loading_station.relaxable_risk_limit_settings.all())

    @property
    def relaxable_upper_summing_limits_settings(self) -> Tuple[RelaxableUpperSummingLimitSetting]:
        return tuple(self.loading_station.relaxable_upper_summing_limit_settings.all())

    @property
    def relaxable_lower_summing_limits_settings(self) -> Tuple[RelaxableUpperSummingLimitSetting]:
        return tuple(self.loading_station.relaxable_lower_summing_limit_settings.all())

    @property
    def model_settings(self) -> Optional[ModelSettings]:
        return self.loading_station.model_settings

    @property
    def steelshop(self) -> int:
        if self.loading_station.steelshop is None:
            return -1
        return self.loading_station.steelshop

    @property
    def debug(self) -> bool:
        return self.loading_station.debug

    @property
    def sending_telegram_required(self) -> bool:
        return self.loading_station.level_2

    @property
    def use_scrap_yard_api(self) -> bool:
        return self.loading_station.scrap_yard_api

    @property
    def scale_control(self) -> bool:
        return self.loading_station.scale_control

    @property
    def level_2(self) -> bool:
        return self.loading_station.level_2

    @property
    def scale_ids(self) -> Tuple[str, str]:
        return (SCALE_SS1_V1, SCALE_SS1_V2) if self.steelshop == 1 else (SCALE_SS2_V8, SCALE_SS2_V9)


class DbLoadingStationModels:
    def __init__(self, loading_station: LoadingStation, logged_user: str, use_scrap_yard_api: bool) -> None:
        self.ls_model = loading_station
        self.logged_user = logged_user
        self.use_scrap_yard_api = use_scrap_yard_api

    @property
    def loading_station(self) -> ScrapLoadingStationDataSource:
        return DbScrapLoadingStationDataSource(self.ls_model.id)

    @property
    def available_scraps(self) -> AvailableScrapDatasource:
        return (
            AvailableScrapAPI(self.ls_model.id)
            if self.use_scrap_yard_api
            else AvailableScrapDb(self.ls_model.id)
        )

    @property
    def scrap_definitions(self) -> AllScrapDefinitionsDatasource:
        return AllScrapDefinitionsDb()

    @property
    def scrap_charges(self) -> ScrapChargesDb:
        return ScrapChargesDb(self.ls_model.id, self.ls_model.steelshop, self.logged_user)

    @property
    def grade_definitions(self) -> GradeDefinitionsDatasource:
        return GradeDefinitionsDb()

    @property
    def optimizations(self) -> MultipleHeatsOptimizationDb:
        return MultipleHeatsOptimizationDb()

    @property
    def basket_weight(self) -> BasketWeightDb:
        return BasketWeightDb()

    @property
    def basket_waggon_weight(self) -> BasketWaggonWeightDb:
        return BasketWaggonWeightDb()

    @property
    def scale_state(self) -> ScrapCurrentStateDb:
        return ScrapCurrentStateDb(self.loading_station.steelshop)

    def weighted_scrap(self, scrap_charge_id: int) -> WeightedScrapDb:
        return ConditionalWeightedScrapDb().get_filtered_data(scrap_charge_id=scrap_charge_id)


js_datasource = (
    JsModel(
        JsCode(
            """
                class AvailableScrapsDatasource extends CRUDCache{
                    getAllScrapTypes(){
                        return Object.values(
                            this.getAll()
                        ).map(
                            s => s.scrap_type
                        );
                    }
                }
            """
        ),
        "AvailableScrapsDatasource",
        "availableScraps",
    ),
    JsModel(
        JsCode(
            """
                class ScrapDefinitionsDatasource extends CRUDCache{
                    getDisplayName(scrapType){
                        if (scrapType == null)
                            return "";

                        const scrap = Object.values(this.getAll()).find(
                            scrap => scrap.scrap_type === scrapType
                        );
                        if (scrap == null)
                            return "";
                        return `${scrapType} (${scrap.tms_id})`;
                    }
                }
            """
        ),
        "ScrapDefinitionsDatasource",
        "scrapDefinitions",
    ),
    JsModel(
        JsCode("class GradeDefinitionsDatasource extends CRUDCache{}"),
        "GradeDefinitionsDatasource",
        "gradeDefinitions",
    ),
    JsModel(
        JsCode(
            """
                class ScrapChargesDatasource extends CRUDCache{
                    getScrapCharge(scrapChargeId){
                        if (scrapChargeId === null)
                            return null;
                        return this.get(scrapChargeId) || null;
                    }

                    getLastOptimization(scrapChargeId){
                        const scrapCharge = this.getScrapCharge(scrapChargeId);
                        if (scrapCharge === null || !scrapCharge.optimizations.length)
                            return null
                        return scrapCharge.optimizations.at(-1);
                    }

                    updateLastOptimization(scrapChargeId, changes){
                        const scrapCharge = this.getScrapCharge(scrapChargeId);
                        if (scrapCharge == null || scrapCharge.optimizations.length === 0)
                            return;

                        var updatedOptimizations = scrapCharge.optimizations.slice(0, -1);
                        updatedOptimizations.push({
                            ...scrapCharge.optimizations.at(-1),
                            ...changes
                        });
                        this.update(
                            scrapChargeId,
                            {"optimizations": updatedOptimizations}
                        );
                    }
                }
            """
        ),
        "ScrapChargesDatasource",
        "scrapCharges",
    ),
    JsModel(
        JsCode(
            """
            class WeightedScrapDatasource extends CRUDCache{
                getWeightOfSwitchedBaskets(){
                    var weightedScraps = Object.assign({}, this.getAll());
                    for (let key of Object.keys(weightedScraps)){
                        if (weightedScraps[key].start !== weightedScraps[key].end)
                            delete weightedScraps[key];
                    }
                    return weightedScraps;
                }

                getScrapsWeightSummed(){
                    var scraps = {};
                    for (let scrap of Object.values(this.getAll())){
                        if (scrap.invalid)
                            continue;
                        let weight = scrap.weight;
                        if (scraps.hasOwnProperty(scrap.scrap))
                            weight = (scrap.weight + scraps[scrap.scrap])
                        scraps[scrap.scrap] = weight;
                    }
                    return scraps;
                }
            }
        """
        ),
        "WeightedScrapDatasource",
        "baseWeightedScrap",
    ),
    JsModel(
        JsCode(
            """
            class ConditionalWeightedScrapDatasource extends ConditionalCRUDCache{
                findScrapChargeId(weightedScrapId){
                    for (let cacheKey of this.cacheKeys){
                        let weightedScrapIds = Object.values(
                            this.getFilteredData(cacheKey).getAll()
                        ).map(obj => obj.id);
                        if (weightedScrapIds.includes(weightedScrapId)){
                            return cacheKey;
                        }
                    }
                    return null;
                }
            }
        """
        ),
        "ConditionalWeightedScrapDatasource",
        "weightedScrap",
        ("WeightedScrapDatasource",),
    ),
    JsModel(
        JsCode("class BasketWeightsDatasource extends CRUDCache{}"),
        "BasketWeightsDatasource",
        "basketWeights",
    ),
    JsModel(
        JsCode("class BasketWaggonWeightsDatasource extends CRUDCache{}"),
        "BasketWaggonWeightsDatasource",
        "basketWaggonWeights",
    ),
    JsModel(
        JsCode(
            """
        class ScaleCurrentStateDatasource extends CRUDCache{
            getStateByScaleId(scaleId){
                return Object.entries(
                    sdc.models.scaleState.getAll()
                ).find(
                    ([id, obj]) => obj.scale_id === scaleId
                );
            }
            
            applyState(stateId, changes){
                this.apply([[stateId, null, changes]], true);
            }
            
            applyStateForScaleId(scaleId, changes){
                const state = this.getStateByScaleId(scaleId);
                if (state === undefined){
                    console.error(`Trying to update the state for scale ${scaleId}. The scale state wasn't found.`);
                    return;
                }
                const [scaleStateId, scaleState] = state;
                this.applyState(scaleStateId, changes);
            }
        }
        """
        ),
        "ScaleCurrentStateDatasource",
        "scaleState",
    ),
)


class ScrapDefinitionsDatasource(Protocol):
    all: Collection[ScrapDefinition]

    @classmethod
    def serialize(cls, data: Collection[ScrapDefinition]) -> List[Dict[str, Any]]: ...


class ScrapDefinitionsDb:
    @property
    def all(self) -> Tuple[ScrapDefinition]:
        return tuple(ScrapDefinition.objects.all())

    @classmethod
    def serialize(cls, data: Collection[ScrapDefinition]) -> List[Dict[str, Any]]:
        return [model_to_dict(scrap) for scrap in data]
