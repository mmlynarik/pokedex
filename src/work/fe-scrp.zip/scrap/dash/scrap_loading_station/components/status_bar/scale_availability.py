from string import Template
from typing import Self, Tuple

import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from scrap.dash.components.protocols.scrap_loading_station import LoadingStationModels
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

AVAILABLE_CLASSNAME = "available"
UNAVAILABLE_CLASSNAME = "unavailable"
UNREACHABLE_CLASSNAME = "unreachable"


@frozen
class ScaleAvailabilityVM:
    # Component ids
    ID = "status-msg"
    STORE_SCALE_ID = "id"
    # User friendly msg
    SCALE_STATUS_MSG = "Váha"

    status_msg: str = sdc.one_way_binding(ID, "children", default=SCALE_STATUS_MSG)
    scale_id: str = sdc.binding(
        STORE_SCALE_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default="",
    )

    @classmethod
    def create_from_models(cls, models: LoadingStationModels, scale_idx: int) -> Self:
        scale_id = models.loading_station.scale_ids[scale_idx]
        return cls(
            scale_id=scale_id,
            status_msg=f"{cls.SCALE_STATUS_MSG} {scale_id}",
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                html.Div(
                    cls.SCALE_STATUS_MSG, id=sdc.create_id(parent_id, cls.ID), className=UNREACHABLE_CLASSNAME
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.STORE_SCALE_ID)),
            ],
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "className", *cls.set_class_name()),)

    @classmethod
    def set_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setClassName",
            ["viewModel", "ctx"],
            Template(
                """
            const scaleIdx = ctx.scaleIds.indexOf(viewModel.scale_id)
            
            const isOperational = ctx.scaleData[scaleIdx]?.is_operational; 

            if (isOperational === undefined)
                return '${unreachable}';

            return isOperational ? '${available}' : '${unavailable}';
            """
            ).substitute(
                unreachable=UNREACHABLE_CLASSNAME,
                unavailable=UNAVAILABLE_CLASSNAME,
                available=AVAILABLE_CLASSNAME,
            ),
        )
