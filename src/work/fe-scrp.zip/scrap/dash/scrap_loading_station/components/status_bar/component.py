from typing import Self

import ussksdc as sdc
from attr import frozen
from dash import html

from scrap.dash.components.protocols.scrap_loading_station import LoadingStationModels
from scrap.dash.scrap_loading_station.components.status_bar.scale_availability import (
    ScaleAvailabilityVM,
)

ENABLE_PROP_CLASSNAME = "enable"
DISABLE_PROP_CLASSNAME = "disable"


def bool_to_classname(prop: bool) -> str:
    return ENABLE_PROP_CLASSNAME if prop else DISABLE_PROP_CLASSNAME


@frozen
class LoadingStationStatusBarVM:
    # Component ids
    ID = "wrapper"
    DEBUG_PARTS_ID = "debug-only"
    DEBUG_ID = "debug-msg"
    LEVEL_2_ID = "level-2-msg"
    SCALE_CONTROL_ID = "scale-control-msg"
    SCRAP_YARD_API_ID = "scrap-yard-api-msg"
    # User friendly msg
    DEBUG_MSG = "Ladenie:"
    LEVEL_2_MSG = "Level 2:"
    SCALE_CONTROL_MSG = "Tarovanie váh:"
    SCRAP_YARD_API_MSG = "Pripojenie k evidencií šrotov:"

    is_hidden: bool = sdc.one_way_binding(DEBUG_PARTS_ID, "hidden", default=True)
    debug: str = sdc.one_way_binding(DEBUG_ID, "className", default=DISABLE_PROP_CLASSNAME)
    level_2: str = sdc.one_way_binding(LEVEL_2_ID, "className", default=DISABLE_PROP_CLASSNAME)
    scale_control: str = sdc.one_way_binding(SCALE_CONTROL_ID, "className", default=DISABLE_PROP_CLASSNAME)
    scrap_yard_api: str = sdc.one_way_binding(SCRAP_YARD_API_ID, "className", default=DISABLE_PROP_CLASSNAME)
    scale_1_availability: ScaleAvailabilityVM = sdc.child_component("scale-1", factory=ScaleAvailabilityVM)
    scale_2_availability: ScaleAvailabilityVM = sdc.child_component("scale-2", factory=ScaleAvailabilityVM)

    @classmethod
    def create_from_models(cls, models: LoadingStationModels) -> Self:
        debug = models.loading_station.debug
        return cls(
            is_hidden=not debug,
            level_2=bool_to_classname(models.loading_station.level_2),
            scale_control=bool_to_classname(models.loading_station.scale_control),
            scrap_yard_api=bool_to_classname(models.loading_station.use_scrap_yard_api),
            debug=bool_to_classname(debug),
            scale_1_availability=ScaleAvailabilityVM.create_from_models(models, 0),
            scale_2_availability=ScaleAvailabilityVM.create_from_models(models, 1),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                sdc.get_child_layout(parent_id, cls.scale_1_availability),
                sdc.get_child_layout(parent_id, cls.scale_2_availability),
                html.Div(
                    children=[
                        html.Div(cls.DEBUG_MSG, id=sdc.create_id(parent_id, cls.DEBUG_ID)),
                        html.Div(cls.LEVEL_2_MSG, id=sdc.create_id(parent_id, cls.LEVEL_2_ID)),
                        html.Div(cls.SCALE_CONTROL_MSG, id=sdc.create_id(parent_id, cls.SCALE_CONTROL_ID)),
                        html.Div(cls.SCRAP_YARD_API_MSG, id=sdc.create_id(parent_id, cls.SCRAP_YARD_API_ID)),
                    ],
                    id=sdc.create_id(parent_id, cls.DEBUG_PARTS_ID),
                ),
            ],
            id=sdc.create_id(parent_id, cls.ID),
        )
