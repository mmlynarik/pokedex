from typing import Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from dash import html
from django.contrib.auth.models import User
from django.db import transaction
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import (
    LoadingStationModels,
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.scrap_loading_station.components.navbar.refresh_modal_new_user_control import (
    RefreshModalVM,
)
from scrap.models import LoadingStation


@frozen
class LoadingStationNavBarVM:
    # Component ids
    NAVBAR_ID = "navbar"
    SAVE_BTN_ID = "save-btn"
    LOADING_STATION_NAME_ID = "loading-station-name"
    USER_IN_CONTROL_ID = "user-in-control"
    TAKE_A_CONTROL_ID = "take-a-control"
    LOGGED_USER_ID = "logged-user"
    REFRESH_MODAL_ID = "refresh"
    MENU_BTN_ID = "menu"
    # Component class names
    USER_CONTROL_WRAPPER_CLASSNAME = "user-control-wrapper"

    loading_station_name: str = sdc.one_way_binding(LOADING_STATION_NAME_ID, "children", default="")
    logged_user: str = sdc.binding(
        LOGGED_USER_ID,
        "children",
        cs_read=False,
        cs_write=False,
        cs_state=True,
        ss_read=False,
        ss_write=True,
        ss_state=True,
        default="",
    )
    user_in_control: str = sdc.binding(
        USER_IN_CONTROL_ID,
        "children",
        cs_read=False,
        cs_write=False,
        cs_state=True,
        ss_read=False,
        ss_write=True,
        ss_state=True,
        default="",
    )

    refresh_modal: RefreshModalVM = sdc.child_component(REFRESH_MODAL_ID, factory=RefreshModalVM)

    @classmethod
    def create_from_models(
        cls, models: LoadingStationModels, logged_username: str
    ) -> "LoadingStationNavBarVM":
        return cls(
            loading_station_name=models.loading_station.name,
            logged_user=logged_username,
            user_in_control=models.loading_station.user_in_control.username,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                html.Div("Nakladacia stanica", id=sdc.create_id(parent_id, cls.LOADING_STATION_NAME_ID)),
                html.Div(
                    dmc.TabsList(
                        [
                            dmc.Tab("Šrotová vsadzka", value="scrap-charge"),
                            dmc.Tab("Sklad šrotu", value="scrap-warehouse"),
                        ]
                    ),
                ),
                dmc.Menu(
                    [
                        dmc.MenuTarget(
                            dmc.Button(
                                "Menu",
                                variant="subtle",
                                compact=True,
                                id=sdc.create_id(parent_id, cls.MENU_BTN_ID),
                            )
                        ),
                        dmc.MenuDropdown(
                            [
                                dmc.MenuLabel("Prihlasený používateľ"),
                                dmc.MenuLabel(
                                    id=sdc.create_id(parent_id, cls.LOGGED_USER_ID),
                                ),
                                dmc.MenuLabel("Stanicu ovláda"),
                                dmc.MenuLabel(id=sdc.create_id(parent_id, cls.USER_IN_CONTROL_ID)),
                                dmc.MenuItem(
                                    "Prevziať kontrolu",
                                    id=sdc.create_id(parent_id, cls.TAKE_A_CONTROL_ID),
                                    n_clicks=0,
                                ),
                                dmc.MenuDivider(),
                                dmc.MenuLabel("Dáta aplikácie"),
                                dmc.MenuItem(
                                    "Aktuálne",
                                    id=sdc.create_id(parent_id, cls.SAVE_BTN_ID),
                                ),
                            ]
                        ),
                    ],
                ),
                sdc.get_child_layout(parent_id, cls.refresh_modal),
            ],
            id=sdc.create_id(parent_id, cls.NAVBAR_ID),
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return (sdc.InputField(cls.TAKE_A_CONTROL_ID, "n_clicks", cls.change_user_in_control),)
        return (sdc.InputFieldClientSide(cls.SAVE_BTN_ID, "n_clicks", *cls.save_client_changes()),)

    def change_user_in_control(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        with transaction.atomic():
            user = User.objects.get(username=ctx.logged_username)
            LoadingStation.objects.select_for_update(nowait=True, of=("self", "user_in_control")).filter(
                pk=ctx.loading_station_id
            ).update(user_in_control=user)
        return attr.evolve(self, refresh_modal=self.refresh_modal.open_modal())

    @classmethod
    def save_client_changes(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "saveClientChanges",
            ["viewModel", "nClicks", "ctx"],
            """
            ctx.syncClientSideChanges();
            return viewModel;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.SAVE_BTN_ID, "children", *cls.change_when_has_data_for_save()),
            sdc.OutputFieldClientSide(cls.TAKE_A_CONTROL_ID, "display", *cls.hide_take_a_control_btn()),
        )

    @classmethod
    def change_when_has_data_for_save(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasDataForSave",
            ["viewModel", "ctx"],
            """
            if (ctx.models.availableScraps.isSynced && ctx.models.scrapCharges.isSynced)
                return "Aktuálne";
            return "Uložiť zmeny";
            """,
        )

    @classmethod
    def hide_take_a_control_btn(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideTakeAControl",
            ["viewModel", "ctx"],
            "return viewModel.logged_user === viewModel.user_in_control ? 'none' : '';",
        )
