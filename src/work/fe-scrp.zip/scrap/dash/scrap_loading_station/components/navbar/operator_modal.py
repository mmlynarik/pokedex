import logging
from typing import Optional, Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from django.db import IntegrityError
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationCTX
from scrap.models import Operator

log = logging.getLogger(__name__)


@attr.frozen
class OperatorModalVM:
    # Component ids
    MODAL_ID = "modal"
    MODAL_BODY_ID = "modal-content"
    OPERATOR_ID = "input"

    CARD_TITLE = "Chýbajúce číslo operátora!"
    INPUT_LABEL = "Vaše číslo operátora"
    INPUT_DESCRIPTION = "Zvyčajne to býva trojmiestne číslo"

    SAVE_BTN_LABEL = "Ulož"
    SAVE_OPERATOR_ID_BTN_ID = "save"

    operator_id: Optional[int] = sdc.clientside_one_way_binding_with_both_states(
        OPERATOR_ID, "value", default=None
    )
    operator_id_error: Optional[str] = sdc.one_way_binding(OPERATOR_ID, "error", default=None)
    opened: bool = sdc.one_way_binding(MODAL_ID, "opened", default=False)

    @classmethod
    def create(cls, opened: bool) -> Self:
        return cls(opened=opened)

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Modal:
        return dmc.Modal(
            children=[
                dmc.NumberInput(
                    id=sdc.create_id(parent_id, cls.OPERATOR_ID),
                    debounce=700,
                    label=cls.INPUT_LABEL,
                    description=cls.INPUT_DESCRIPTION,
                    min=100,
                    step=1,
                    max=999,
                    withAsterisk=True,
                ),
                dmc.Space(h=20),
                dmc.Group(
                    [
                        dmc.Button(
                            cls.SAVE_BTN_LABEL,
                            id=sdc.create_id(parent_id, cls.SAVE_OPERATOR_ID_BTN_ID),
                            color="primary",
                        ),
                    ],
                    position="right",
                ),
            ],
            title=cls.CARD_TITLE,
            id=sdc.create_id(parent_id, cls.MODAL_ID),
            closeOnClickOutside=False,
            closeOnEscape=False,
            withCloseButton=False,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.SAVE_OPERATOR_ID_BTN_ID, "disabled", *cls.disable()),
            sdc.OutputFieldClientSide(cls.OPERATOR_ID, "disabled", *cls.disable()),
        )

    @classmethod
    def disable(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("disable", ["viewModel", "ctx"], "return ctx.readOnly")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.SAVE_OPERATOR_ID_BTN_ID, "n_clicks", cls.save_operator_id),)

    def save_operator_id(self, _: int, ctx: ScrapLoadingStationCTX):
        if not self.operator_id:
            return attr.evolve(self, operator_id_error="Zabudli ste zadať vaše číslo operátora.")

        operator = Operator(user=ctx.models.loading_station.user_in_control, operator_id=self.operator_id)

        try:
            operator.save()
        except IntegrityError:
            return attr.evolve(
                self,
                operator_id_error=(
                    "Zadané číslo operátora už bolo priradené. "
                    + "Skontrolujte číslo ak je v poriadku kontaktujte nadriadeného."
                ),
            )

        log.info(f"{operator} data saved successfully")
        return attr.evolve(self, opened=False)
