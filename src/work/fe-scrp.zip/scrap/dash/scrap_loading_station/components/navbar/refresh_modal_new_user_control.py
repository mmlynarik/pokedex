from typing import Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import dcc
from ussksdc.core.datamodel import JsCode


@attr.frozen
class RefreshModalVM:
    # Component ids
    MODAL_ID = "modal"
    MODAL_BODY_ID = "modal-content"
    REFRESH_INTERVAL_ID = "refresh-interval"

    is_open: bool = sdc.one_way_binding(MODAL_ID, "is_open", default=False)
    refresh_interval_disabled: bool = sdc.one_way_binding(REFRESH_INTERVAL_ID, "disabled", default=True)
    refresh_n_intervals: int = sdc.binding(
        REFRESH_INTERVAL_ID,
        "n_intervals",
        cs_read=True,
        cs_state=True,
        cs_write=False,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=0,
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            children=[
                dbc.ModalHeader(
                    "Prevzatie kontroly prebehlo úspešne",
                ),
                dbc.ModalBody(id=sdc.create_id(parent_id, cls.MODAL_BODY_ID)),
                dcc.Interval(
                    id=sdc.create_id(parent_id, cls.REFRESH_INTERVAL_ID), n_intervals=0, max_intervals=3
                ),
            ],
            id=sdc.create_id(parent_id, cls.MODAL_ID),
            centered=True,
            backdrop="static",
            keyboard=False,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.MODAL_BODY_ID, "children", *cls.get_modal_content()),)

    @classmethod
    def get_modal_content(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function getRefreshModalContent(viewModel, ctx){
                    var refreshAt = 3 - viewModel.refresh_n_intervals
                    if (refreshAt === 0){
                        setTimeout(() => {
                            window.location.reload()
                        }, 2000);
                        // Use the setTimeout due to waiting to end the running callbacks.
                    }
                    return `Stránka sa prenačíta o ${refreshAt} sek.`
                }
                """
            ),
            "getRefreshModalContent",
        )

    def open_modal(self) -> "RefreshModalVM":
        return attr.evolve(self, is_open=True, refresh_interval_disabled=False)
