import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationCTX


@attr.frozen
class ErrorModalVM:
    # Component ids
    MODAL_ID = "modal"
    MODAL_BODY_ID = "modal-content"

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            children=[
                dbc.ModalHeader("Nastala chyba"),
                dbc.ModalBody(id=sdc.create_id(parent_id, cls.MODAL_BODY_ID)),
            ],
            id=sdc.create_id(parent_id, cls.MODAL_ID),
            centered=True,
            backdrop="static",
            keyboard=False,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.MODAL_ID, "is_open", cls.open_model_on_error),
            sdc.OutputField(cls.MODAL_BODY_ID, "children", cls.get_error_msg),
        )

    def open_model_on_error(self, ctx: ScrapLoadingStationCTX) -> bool:
        return bool(ctx.error_msg)

    def get_error_msg(self, ctx: ScrapLoadingStationCTX) -> str:
        return " ".join(ctx.error_msg)
