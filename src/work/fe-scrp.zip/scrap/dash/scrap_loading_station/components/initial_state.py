from typing import Dict, Optional, Self, Union

import attr
import ussksdc as sdc
from dash import dcc
from scrap.dash.components.protocols.scrap_loading_station import LoadingStationModels


@attr.frozen
class InitialState:
    debug: bool = attr.ib(converter=bool)
    loading_station_id: int = attr.ib()
    logged_username: str = attr.ib()
    read_only: bool = attr.ib(converter=bool)
    use_scrap_yard_api: bool = attr.ib(converter=bool)
    scale_control: bool = attr.ib(converter=bool)
    steelshop: Optional[int] = attr.ib(default=None)


@attr.frozen
class InitialStateVM:
    ID = "store"

    raw_data: Dict[str, Union[str, int, bool]] = sdc.binding(
        ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default={},
    )

    @classmethod
    def create(cls, models: LoadingStationModels, logged_username: str, read_only: bool) -> Self:
        return cls(
            raw_data=attr.asdict(
                InitialState(
                    debug=models.loading_station.debug,
                    loading_station_id=models.loading_station.loading_station_id,
                    logged_username=logged_username,
                    read_only=read_only,
                    use_scrap_yard_api=models.loading_station.use_scrap_yard_api,
                    scale_control=models.loading_station.scale_control,
                    steelshop=models.loading_station.steelshop,
                )
            )
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Store:
        return dcc.Store(id=sdc.create_id(parent_id, cls.ID))

    @property
    def data(self) -> InitialState:
        return InitialState(**self.raw_data)
