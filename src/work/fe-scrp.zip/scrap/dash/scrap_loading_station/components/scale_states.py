from typing import Any, Dict, Self

import ussksdc as sdc
from attr import frozen
from dash_websocket_component.DashWebsocketComponent import DashWebsocketComponent


def create_url(host: str, port: int, scale_id: str) -> str:
    return f"ws://{host}:{port}/scales_stream/{scale_id}"


@frozen
class ScaleStateVM:
    # Component ids
    SCALE_ID = "scale"

    scale_data: Dict[str, Dict[str, Any]] = sdc.clientside_only_state_binding(SCALE_ID, "message", default={})
    scale_url: str = sdc.one_way_binding(SCALE_ID, "url", default="")

    @classmethod
    def create(cls, host: str, port: int, scale_id: str) -> Self:
        return cls(scale_url=create_url(host, port, scale_id))

    @classmethod
    def get_layout(cls, parent_id: str) -> DashWebsocketComponent:
        return DashWebsocketComponent(id=sdc.create_id(parent_id, cls.SCALE_ID))
