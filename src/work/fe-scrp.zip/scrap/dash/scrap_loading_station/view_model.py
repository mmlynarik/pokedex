import logging
from functools import lru_cache
from typing import Dict, Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from vsadzka.settings import (
    APP_HOST,
    APP_PORT,
    SCALE_SS1_V1,
    SCALE_SS1_V2,
    SCALE_SS2_V8,
    SCALE_SS2_V9,
)

from scrap.dash.components.available_scraps.component import AvailableScrapsVM
from scrap.dash.components.global_alert import GlobalAlertVM
from scrap.dash.components.protocols.scrap_loading_station import (
    LoadingStationModels,
    ScrapLoadingStationConfig,
)
from scrap.dash.components.scrap_charge_card.card import ScrapChargeCardVM
from scrap.dash.components.scrap_charge_card.content.result.weightning.component import (
    WeightingComponentVM,
)
from scrap.dash.components.scrap_charges.component import ScrapChargesVM
from scrap.dash.scrap_loading_station.components.initial_state import InitialStateVM
from scrap.dash.scrap_loading_station.components.navbar import (
    ErrorModalVM,
    LoadingStationNavBarVM,
    OperatorModalVM,
    RefreshModalOldUserInControlVM,
)
from scrap.dash.scrap_loading_station.components.scale_states import ScaleStateVM
from scrap.dash.scrap_loading_station.components.status_bar.component import (
    LoadingStationStatusBarVM,
)
from scrap.dash.scrap_loading_station.datasource import DbLoadingStationModels
from scrap.models import DEFAULT_SCRAP_WEIGHT, LoadingStation, ScrapCharge
from scrap_core.utils import convert_tons_to_kilograms

log = logging.getLogger(__name__)

# User friendly text used in fronted
APP_NAME = "Šrotový model Nastavenia"
LOADING_STATION = "Nakladacia stanica"
GRADE_IDS = "Akosť"
PRIORITY = "Priorita"
LIMITS = "Limity"
SCRAP_GROUP = "Skupiny šrotov"
GRADE_GROUP = "Skupiny akostí"

# Component class names
TABLE_WRAPPER_CLASSNAMES = "limits-table-wrapper"


@lru_cache(maxsize=16)
def get_loading_station_models(
    loading_station_id: int, logged_user: str, use_scrap_yard_api: bool
) -> DbLoadingStationModels:
    return DbLoadingStationModels(
        LoadingStation.objects.get(pk=loading_station_id), logged_user, use_scrap_yard_api
    )


@attr.frozen
class LoadingStationVM:
    ACTUAL_SCALE_DATA_WS = "actual-scale-data"
    SCALE_STATE_1_ID = "scale-state-1"
    SCALE_STATE_2_ID = "scale-state-2"
    CONTAINER_ID = "container"
    PANEL_CONTAINER_ID = "panel-container"
    CONTENT_SECTION_ID = "content"

    scale_data_1: ScaleStateVM = sdc.child_component(SCALE_STATE_1_ID, factory=ScaleStateVM)
    scale_data_2: ScaleStateVM = sdc.child_component(SCALE_STATE_2_ID, factory=ScaleStateVM)
    available_scraps: AvailableScrapsVM = sdc.child_component("", factory=AvailableScrapsVM)  # type: ignore
    scrap_charges: ScrapChargesVM = sdc.child_component("", factory=ScrapChargesVM)  # type: ignore
    navbar: LoadingStationNavBarVM = sdc.child_component("", factory=LoadingStationNavBarVM)
    refresh_modal: RefreshModalOldUserInControlVM = sdc.child_component(
        "refresh-modal", factory=RefreshModalOldUserInControlVM
    )
    # TODO je toto este potrebne?
    error_modal: ErrorModalVM = sdc.child_component("error", factory=ErrorModalVM)
    operator_modal: OperatorModalVM = sdc.child_component("operator", factory=OperatorModalVM)
    initial_state: InitialStateVM = sdc.child_component("initial-state", factory=InitialStateVM)
    status_bar: LoadingStationStatusBarVM = sdc.child_component(
        "status-bar", factory=LoadingStationStatusBarVM
    )
    global_alert: GlobalAlertVM = sdc.child_component("", factory=GlobalAlertVM)

    @classmethod
    def load_initial_data(cls, *args, **kwargs) -> "LoadingStationVM":  # pylint: disable=unused-argument
        loading_station_id = kwargs["session_state"]["loading_station_id"]
        logged_username = kwargs["session_state"]["logged_username"]
        read_only = kwargs["session_state"]["read_only"]
        use_scrap_yard_api = kwargs["session_state"]["scrap_yard_api"]
        models = get_loading_station_models(loading_station_id, logged_username, use_scrap_yard_api)
        scale_ids = models.loading_station.scale_ids
        return LoadingStationVM(  # type: ignore
            scale_data_1=ScaleStateVM.create(APP_HOST, APP_PORT, scale_ids[0]),
            scale_data_2=ScaleStateVM.create(APP_HOST, APP_PORT, scale_ids[1]),
            available_scraps=AvailableScrapsVM.create_from_models(models),
            scrap_charges=ScrapChargesVM.create(models, APP_HOST, APP_PORT, scale_ids),
            navbar=LoadingStationNavBarVM.create_from_models(models, logged_username),
            initial_state=InitialStateVM.create(models, logged_username, read_only),
            status_bar=LoadingStationStatusBarVM.create_from_models(models),
            operator_modal=OperatorModalVM.create(
                not hasattr(models.loading_station.user_in_control, "operator")
            ),
        )

    @classmethod
    def get_layout(cls, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                ### Visible ###
                dmc.Tabs(
                    [
                        sdc.get_child_layout("", cls.navbar),
                        html.Div(
                            [
                                dmc.TabsPanel(
                                    sdc.get_child_layout("", cls.scrap_charges, config), value="scrap-charge"
                                ),
                                dmc.TabsPanel(
                                    sdc.get_child_layout("", cls.available_scraps, config),
                                    value="scrap-warehouse",
                                ),
                            ],
                            id=sdc.create_id("", cls.CONTENT_SECTION_ID),
                        ),
                    ],
                    value="scrap-charge",
                ),
                sdc.get_child_layout("", cls.status_bar),
                ### Modals ###
                sdc.get_child_layout("", cls.refresh_modal),
                sdc.get_child_layout("", cls.error_modal),
                sdc.get_child_layout("", cls.operator_modal, config),
                sdc.get_child_layout("", cls.global_alert),
                ### Invisible ###
                sdc.get_child_layout("", cls.initial_state),
                sdc.get_child_layout("", cls.scale_data_1),
                sdc.get_child_layout("", cls.scale_data_2),
            ],
            id=sdc.create_id("", cls.CONTAINER_ID),
        )


class LoadingStationCtx:
    def __init__(self, parent: LoadingStationVM):
        self.parent = parent

    @property
    def models(self) -> LoadingStationModels:
        return get_loading_station_models(
            self.loading_station_id, self.logged_username, self.use_scrap_yard_api
        )

    @property
    def loading_station_id(self) -> int:
        return self.parent.initial_state.data.loading_station_id

    @property
    def steelshop(self) -> Optional[int]:
        return self.parent.initial_state.data.steelshop

    @property
    def logged_username(self) -> str:
        return self.parent.initial_state.data.logged_username

    @property
    def operator_id(self) -> int:
        return self.models.loading_station.user_in_control.operator.operator_id

    @property
    def use_scrap_yard_api(self) -> bool:
        return self.parent.initial_state.data.use_scrap_yard_api

    @property
    def scale_control(self) -> bool:
        return self.parent.initial_state.data.scale_control

    @property
    def read_only(self) -> bool:
        return self.parent.initial_state.data.read_only

    # TODO Toto je tu naco?
    @property
    def error_msg(self) -> Tuple[str, ...]:
        messages = (
            # self.parent.scrap_charges.table.scrap_charges_cards.card.decision.confirmation.confirm_close.error_msg,
            # self.parent.scrap_charges.table.scrap_charges_cards.card_1.decision.confirmation.confirm_close.error_msg
        )
        return tuple(msg for msg in messages if msg is not None)

    @property
    def transfer_capacity_or_zero(self) -> int:
        transfer_capacity = self.parent.available_scraps.transfer_capacity.weight
        return 0 if transfer_capacity is None else transfer_capacity

    @property
    def scale_ids(self) -> Tuple[str, str]:
        return (SCALE_SS1_V1, SCALE_SS1_V2) if self.steelshop == 1 else (SCALE_SS2_V8, SCALE_SS2_V9)

    def get_active_scales(self, card_idx: int) -> Tuple[str, ...]:
        scale_selector = self.get_card_component(card_idx).result.scale_selector
        return tuple(self.scale_ids[idx] for idx in scale_selector.active_scales)

    def get_scale_basket_map(self, card_idx: int) -> Dict[str, Optional[int]]:
        return {
            self.get_scale_id(card_idx, idx): self.get_basket_id(card_idx, idx)
            for idx in (1, 2)
            if self.get_scale_id(card_idx, idx) is not None
            and self.get_scale_id(card_idx, idx) in self.get_active_scales(card_idx)
        }

    def get_switched_basket_selected_scale_id(self, card_idx: int) -> Optional[int]:
        return self.get_card_component(
            card_idx
        ).inputs.swiched_basket_ids.weighting_switched_basket.scale_selector.active_scale

    def get_card_component(self, card_index: int) -> ScrapChargeCardVM:
        if card_index == 0:
            return self.parent.scrap_charges.table.scrap_charges_cards.card
        return self.parent.scrap_charges.table.scrap_charges_cards.card_1

    def get_grade_id(self, card_index: int) -> Optional[int]:
        card_component = self.get_card_component(card_index)
        return card_component.inputs.grade_and_weight_inputs.grade

    def get_scrap_weight(self, card_index: int) -> int:
        card_component = self.get_card_component(card_index)
        scrap_weight_tons = card_component.inputs.grade_and_weight_inputs.scrap_weight
        return None if scrap_weight_tons is None else convert_tons_to_kilograms(scrap_weight_tons)

    def get_scrap_weight_or_constant(self, card_index: int) -> int:
        return self.get_scrap_weight(card_index) or DEFAULT_SCRAP_WEIGHT

    def get_scrap_charge_id(self, card_idx: int) -> int:
        scrap_charge_config = self.parent.scrap_charges.table.get_scrap_charge_config()
        return scrap_charge_config.selected_scrap_charge[card_idx]

    def get_scrap_charge(self, card_idx: int) -> Optional[ScrapCharge]:
        scrap_charge_id = self.get_scrap_charge_id(card_idx)
        return None if scrap_charge_id is None else self.models.scrap_charges.get(scrap_charge_id)

    def get_scale_weighting(self, card_idx: int, weighting_idx: int) -> WeightingComponentVM:
        card = self.get_card_component(card_idx)
        return {1: card.result.scale_weightning, 2: card.result.scale_weightning_2}[weighting_idx]

    def get_scale_id(self, card_idx: int, weighting_idx: int) -> Optional[str]:
        scale_weighting = self.get_scale_weighting(card_idx, weighting_idx)
        scale_idx = scale_weighting.proposed_scraps.scale_idx

        if scale_idx is not None and 0 <= scale_idx < len(self.scale_ids):
            return self.scale_ids[scale_idx]

        return None

    def get_basket_id(self, card_idx: int, weighting_idx: int) -> Optional[int]:
        scale_weighting = self.get_scale_weighting(card_idx, weighting_idx)
        basket_ids = self.get_scrap_charge(card_idx).basket_ids
        basket_idx = scale_weighting.basket.basket

        if basket_idx is not None and 0 <= basket_idx < len(basket_ids):
            return basket_ids[basket_idx]

        return None
