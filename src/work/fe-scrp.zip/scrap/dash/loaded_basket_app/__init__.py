import logging
from pathlib import Path

from common.dash import DjangoPlotlyDashCallbackContext
from django_plotly_dash import DjangoDash
from scrap.dash.loaded_basket_app.datamodel import (
    LoadedBasketCompatibilityContext,
    LoadedBasketCompatibilityViewModel,
)
from vsadzka.settings import STATIC_ROOT

import ussksdc as sdc

NAME_APP = "LoadedBasketCompatibility"


logger = logging.getLogger(__name__)

loaded_basket_compatibility_app = DjangoDash(NAME_APP, serve_locally=True, add_bootstrap_links=True)

# TODO remove type ignore with valid context
sdc.sdc_initialize_app(  # type: ignore
    loaded_basket_compatibility_app,
    LoadedBasketCompatibilityViewModel,
    LoadedBasketCompatibilityContext,
    callback_context_getter=DjangoPlotlyDashCallbackContext,
    assets_dir=Path(STATIC_ROOT) / "scrap/loaded_basket_app/assets",
)
