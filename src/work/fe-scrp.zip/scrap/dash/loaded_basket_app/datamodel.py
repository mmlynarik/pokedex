import logging
from typing import List, Optional, Self

import attr
import ussksdc as sdc
from dash import html, dcc
from scrap.dash.components.layouts.sidebar import SideBar, create_sidebar_layout, get_input_wrapper
from scrap.dash.components.loaded_baskets.datasource import LoadedBasketsDataSource, get_datasource
from scrap.dash.components.loaded_baskets.deck import LoadedBasketsDeckViewModel
from scrap.dash.components.selectors.grade import GradeIdsSelectorViewModel
from dash.development.base_component import Component

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())

APP_NAME = "Kompatibilita naložených korýt"

# Component class names
FULLSCREEN_CLASSNAME = "fullscreen"
# User friendly msg
GRADE_IDS = "Akosť"

FULLSCREEN_CLASSNAME = "fullscreen"


@attr.frozen
class LoadedBasketCompatibilityViewModel:
    UPDATE_DATA_INTERVAL = 60000  # 60 000 ms = 60 sec
    # Component id
    LOADING_STATION_STORE_ID = "loading-station-id"

    loading_station_id: int = sdc.one_way_binding(LOADING_STATION_STORE_ID, "data", default=-1)
    grades_selector: GradeIdsSelectorViewModel = sdc.child_component(
        "grades-ids", default=GradeIdsSelectorViewModel()
    )
    deck: LoadedBasketsDeckViewModel = sdc.child_component(
        "loaded-baskets-deck", factory=LoadedBasketsDeckViewModel
    )

    @classmethod
    def load_initial_data(cls, *args, **kwargs) -> Self:  # pylint: disable=unused-argument
        return LoadedBasketCompatibilityViewModel(  # type: ignore
            deck=LoadedBasketsDeckViewModel.create(cls.UPDATE_DATA_INTERVAL),
            loading_station_id=kwargs["session_state"]["loading_station_id"],
        )

    @classmethod
    def get_sidebar_bottom_items(cls) -> List[Component]:
        return [dcc.Loading(dcc.Store(id=sdc.create_id("", cls.LOADING_STATION_STORE_ID)))]

    @classmethod
    def get_sidebar_inputs(cls) -> List[html.Div]:
        return [
            get_input_wrapper(
                GRADE_IDS,
                sdc.get_child_layout("", cls.grades_selector),
            ),
        ]

    @classmethod
    def get_layout(cls):
        return create_sidebar_layout(
            sidebar=SideBar(
                title=APP_NAME,
                main_content=cls.get_sidebar_inputs(),
                bottom_content=cls.get_sidebar_bottom_items(),
            ),
            page_content=html.Div(
                children=sdc.get_child_layout("", cls.deck),
                className=FULLSCREEN_CLASSNAME,
            ),
        )


class LoadedBasketCompatibilityContext:
    def __init__(self, parent: LoadedBasketCompatibilityViewModel) -> None:
        self.parent = parent

    @property
    def loading_station_id(self) -> int:
        return self.parent.loading_station_id

    @property
    def selected_grade_id(self) -> Optional[int]:
        return self.parent.grades_selector.selected_option  # type: ignore

    @property
    def datasource(self) -> LoadedBasketsDataSource:
        return get_datasource(self.loading_station_id, self.parent.deck.COMPATIBILITY_CARD_COUNT)
