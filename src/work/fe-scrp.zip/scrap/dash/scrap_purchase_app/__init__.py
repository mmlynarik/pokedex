import logging
from pathlib import Path

import ussksdc as sdc
from common.dash import DjangoPlotlyDashCallbackContext
from django_plotly_dash import DjangoDash
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig
from scrap.dash.scrap_purchase_app.datamodel import ScrapPurchaseAppViewModel, ScrapPurchaseAppCTX
from vsadzka.settings import STATIC_ROOT

SCRAP_PURCHASE_READ_ONLY_APP = "ScrapPurchaseReadOnlyApp"
SCRAP_PURCHASE_APP = "ScrapPurchaseApp"

logger = logging.getLogger(__name__)

read_only_scrap_purchase_app = DjangoDash(
    SCRAP_PURCHASE_READ_ONLY_APP, serve_locally=True, add_bootstrap_links=True
)
scrap_purchase_app = DjangoDash(SCRAP_PURCHASE_APP, serve_locally=True, add_bootstrap_links=True)

CONFIG_READ_ONLY = ScrapPurchaseAppConfig(read_only=True)
CONFIG = ScrapPurchaseAppConfig(read_only=False)

read_only_scrap_purchase_app.layout = ScrapPurchaseAppViewModel.get_layout(config=CONFIG_READ_ONLY)

sdc.sdc_initialize_app(  # type: ignore
    read_only_scrap_purchase_app,
    ScrapPurchaseAppViewModel,
    ScrapPurchaseAppCTX,
    callback_context_getter=DjangoPlotlyDashCallbackContext,
    assets_dir=Path(STATIC_ROOT) / "scrap/scrap_purchase_app/read_only/assets",
    global_config=CONFIG_READ_ONLY,
)

scrap_purchase_app.layout = ScrapPurchaseAppViewModel.get_layout(config=CONFIG)

sdc.sdc_initialize_app(  # type: ignore
    scrap_purchase_app,
    ScrapPurchaseAppViewModel,
    ScrapPurchaseAppCTX,
    callback_context_getter=DjangoPlotlyDashCallbackContext,
    assets_dir=Path(STATIC_ROOT) / "scrap/scrap_purchase_app/assets",
    global_config=CONFIG,
)
