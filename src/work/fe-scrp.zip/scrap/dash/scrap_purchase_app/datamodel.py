import logging
from typing import Optional, Tuple, Container
import uuid

import attr
import attrs
from django.contrib.auth.models import User
from django.db import transaction
from dash import html
import ussksdc as sdc
from ussksdc.components.data_store import DataStoreStrViewModel, DataStoreViewModel

from scrap.dash.components.global_alert import GlobalAlertVM
from scrap.dash.components.purchase_input_data_button.button import PurchaseInputDataButtonViewModel
from scrap.dash.components.purchase_app_navbar.navbar import PurchaseNavbarViewModel
from scrap.dash.components.close_purchase_button.button import ClosePurchaseButtonViewModel
from scrap.dash.components.realized_scrap_offers_table.table import RealizedScrapOfferTableViewModel
from scrap.dash.components.overall_purchase_table.table import OveralScrapPurchaseTableViewModel
from scrap.dash.components.realized_pivot_table.table import ScrapPurchaseRealizedPivotTableViewModel
from scrap.dash.components.delta_conditions_table.computations import compute_scrap_offers
from scrap.dash.components.scrap_offers_table.table.table import ScrapOffersTableVM
from scrap.dash.components.common import (
    PurchaseOptimizationDataSource,
    UserDataSource,
)
from scrap.dash.components.purchase_optimization_bar.datasource import PurchaseOptimizations
from scrap.dash.components.purchase_optimization_bar.optimization_bar import PurchaseOptimizationVM
from scrap.models import (
    ScrapPurchaseRecord,
    ScrapPurchaseOptimizationDisplayData,
    ScrapPurchaseOptimizationInput,
    ScrapPurchaseOptimizationResult,
    ScrapPurchaseOptimizationSettings,
    ScrapOfferData,
    BaseDeltaRuleData,
    ProductionPlanData,
    RealizedScrapOfferData,
    ScrapStateData,
    ScrapOffer,
    ScrapPurchase,
    ScrapSupplier,
    ScrapSupplierMapping,
)
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig
from datetime import date, datetime
from dateutil.relativedelta import relativedelta
from scrap.dash.components.delta_conditions_table.table import DeltaConditionsTableVM


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.s(frozen=True, auto_attribs=True)
class DBUsersDataSource:
    logged_user_id: int
    user_in_control_id: int

    @property
    def user_in_control(self) -> User:
        return User.objects.get(pk=self.user_in_control_id)

    @property
    def logged_user(self) -> User:
        return User.objects.get(pk=self.logged_user_id)

    def get_logged_user_username(self) -> str:
        return self.logged_user.username

    def get_user_in_control_username(self) -> str:
        return self.user_in_control.username


@attrs.frozen
class DBPurchaseOptimizationDataSource:
    def add_new_optimization(
        self, optimization_input: ScrapPurchaseOptimizationInput
    ) -> ScrapPurchaseOptimizationResult:
        optimization_result = ScrapPurchaseOptimizationResult(input_data=optimization_input)
        optimization_result.save()
        return optimization_result


@attr.frozen
class DBScrapPurchaseDataSource:
    purchase_id: int
    purchase_date: date

    @property
    def db_data(self):
        return ScrapPurchaseRecord.objects.get(pk=self.purchase_id).current_data

    def freeze_unfreeze_offers(self, to_change_ids: Tuple[str, ...]) -> None:
        new_scrap_offer_data = tuple(
            (
                scrap_offer
                if scrap_offer.uuid not in to_change_ids
                else attr.evolve(scrap_offer, frozen=not scrap_offer.frozen)
            )
            for scrap_offer in self.get_scrap_offer_data()
        )
        self.update_scrap_offer_data(new_scrap_offer_data)

    def update_computations(self, new_computations: Tuple[ScrapPurchaseOptimizationDisplayData, ...]) -> None:
        new_data = attrs.evolve(self.db_data, computations=new_computations)
        ScrapPurchaseRecord.objects.filter(pk=self.purchase_id).update(
            current_data=new_data, updated_at=datetime.utcnow()
        )

    def update_scrap_offer_data_and_base_delta_rule_data(
        self,
        new_scrap_offer_data: ScrapOfferData,
        new_base_delta_rule_data: BaseDeltaRuleData,
    ) -> None:
        new_data = attrs.evolve(
            self.db_data, scrap_offer_data=new_scrap_offer_data, base_delta_rule_data=new_base_delta_rule_data
        )
        ScrapPurchaseRecord.objects.filter(pk=self.purchase_id).update(
            current_data=new_data, updated_at=datetime.utcnow()
        )

    def update_scrap_offer_data_and_realized_scrap_offer_data(
        self, new_scrap_offer_data: ScrapOfferData, new_realized_scrap_offer_data: RealizedScrapOfferData
    ) -> None:
        new_data = attrs.evolve(
            self.db_data,
            scrap_offer_data=new_scrap_offer_data,
            realized_scrap_offer_data=new_realized_scrap_offer_data,
        )
        ScrapPurchaseRecord.objects.filter(pk=self.purchase_id).update(
            current_data=new_data, updated_at=datetime.utcnow()
        )

    def update_scrap_offer_data(self, new_scrap_offer_data: ScrapOfferData) -> None:
        new_data = attrs.evolve(self.db_data, scrap_offer_data=new_scrap_offer_data)
        ScrapPurchaseRecord.objects.filter(pk=self.purchase_id).update(
            current_data=new_data, updated_at=datetime.utcnow()
        )

    def update_scrap_offer(self, offer_id: str, **kwargs) -> None:
        scrap_offer_data = self.get_scrap_offer_data()
        delta_rules = self.get_delta_conditions()
        scrap_offer_data_list = list(scrap_offer_data)
        offer_idx = next(idx for idx, offer in enumerate(scrap_offer_data) if offer.uuid == offer_id)
        old_scrap_offer = scrap_offer_data[offer_idx]
        scrap_offer_data_list[offer_idx] = attr.evolve(
            old_scrap_offer, recommendation=None, scrap_purchased=False, **kwargs
        )
        new_scrap_offer_data = tuple(scrap_offer_data_list)
        recalculated_scrap_offer_data = compute_scrap_offers(delta_rules, new_scrap_offer_data)
        self.update_scrap_offer_data(recalculated_scrap_offer_data)

    def delete_scrap_offer(self, offer_id: str) -> None:
        new_scrap_offer_data = tuple(
            scrap_offer for scrap_offer in self.get_scrap_offer_data() if scrap_offer.uuid != offer_id
        )
        self.update_scrap_offer_data(new_scrap_offer_data)

    def freeze_unfreeze_scrap_offer(self, offer_id: str) -> None:
        new_scrap_offer_data = tuple(
            (
                scrap_offer
                if scrap_offer.uuid != offer_id
                else attr.evolve(scrap_offer, frozen=not scrap_offer.frozen)
            )
            for scrap_offer in self.get_scrap_offer_data()
        )
        self.update_scrap_offer_data(new_scrap_offer_data)

    def add_new_scrap_offer(self) -> str:
        data = self.get_scrap_offer_data()
        new_uuid = str(uuid.uuid4())
        new_data = data + (
            ScrapOffer(
                added_by_user=True,
                uuid=new_uuid,
            ),
        )
        self.update_scrap_offer_data(new_data)
        return new_uuid

    def remove_realized_offer(self, offer_idx: int) -> None:
        realized_offer_data = self.get_realized_scrap_offer_data()
        realized_offer_to_delete = realized_offer_data[offer_idx]
        new_scrap_offer_data = list()
        for scrap_offer in self.get_scrap_offer_data():
            if scrap_offer.uuid in realized_offer_to_delete.scrap_offer_uuid_list:
                if not scrap_offer.generated_from:
                    new_scrap_offer_data.append(scrap_offer.update_field(scrap_purchased=False))
            else:
                new_scrap_offer_data.append(scrap_offer)
        new_realized_offer_data = tuple(
            realized_offer for idx, realized_offer in enumerate(realized_offer_data) if idx != offer_idx
        )
        self.update_scrap_offer_data_and_realized_scrap_offer_data(
            tuple(new_scrap_offer_data), new_realized_offer_data
        )

    def finish_purchase(self) -> None:
        def save_realized_offers_to_db(offers: RealizedScrapOfferData, purchase_date: date) -> None:
            new_data = []
            inverse_scrap_supplier_mapping = {
                item.input_scrap_supplier: item.scrap_supplier for item in ScrapSupplierMapping.objects.all()
            }

            for offer in offers:
                supplier, created = ScrapSupplier.objects.get_or_create(
                    name=inverse_scrap_supplier_mapping.get(offer.supplier, offer.supplier)
                )
                if created:
                    log.info(f"New ScrapSupplier record created: {supplier}")

                new_data.append(
                    ScrapPurchase(
                        supplier=supplier,
                        scrap_type=offer.scrap_type,
                        zone=str(offer.zone),
                        date=purchase_date,
                        quantity=offer.weight,
                        price=offer.price,
                        note=offer.note,
                    )
                )
            ScrapPurchase.objects.bulk_create(new_data)
            log.info(f"{len(new_data)} realized scrap offers were saved to db")

        db_record = ScrapPurchaseRecord.objects.get(pk=self.purchase_id)

        if not db_record.finished:
            with transaction.atomic():
                save_realized_offers_to_db(
                    db_record.current_data.realized_scrap_offer_data, db_record.purchase_date
                )
                db_record.finished = True
                db_record.save()

            log.info(f"{db_record} has been finished")
        else:
            log.warning(f"Can't finish already finished {db_record} again")

    def take_control_over_purchase(self, new_user: User) -> None:
        record = ScrapPurchaseRecord.objects.get(pk=self.purchase_id)
        record.user_in_control = new_user
        record.save()

    def add_optimization(
        self, pk: int, optimizations: Tuple[ScrapPurchaseOptimizationDisplayData, ...]
    ) -> None:
        optimization_display_data = ScrapPurchaseOptimizationDisplayData(pk)
        self.update_computations(optimizations + (optimization_display_data,))

    def get_delta_conditions(self) -> BaseDeltaRuleData:
        return self.db_data.base_delta_rule_data

    def get_scrap_offer_data(self, suppliers: Container[str] = ()) -> ScrapOfferData:
        if not suppliers:
            return self.db_data.scrap_offer_data

        return tuple(offer for offer in self.db_data.scrap_offer_data if offer.supplier in suppliers)

    def get_optimization_settings(self) -> ScrapPurchaseOptimizationSettings:
        return ScrapPurchaseRecord.objects.get(pk=self.purchase_id).optimization_settings

    def get_scrap_state_data(self) -> ScrapStateData:
        return self.db_data.scrap_state_data

    def get_realized_scrap_offer_data(self, suppliers: Container[str] = ()) -> RealizedScrapOfferData:
        if not suppliers:
            return self.db_data.realized_scrap_offer_data

        return tuple(offer for offer in self.db_data.realized_scrap_offer_data if offer.supplier in suppliers)

    def get_production_plan_data(self) -> ProductionPlanData:
        return self.db_data.production_plan_data

    def get_production_plan_date(self) -> Optional[datetime]:
        return self.db_data.production_plan_date

    def get_production_plan_nr_of_weeks(self) -> int:
        return self.db_data.production_plan_nr_of_weeks

    def get_user_defined_expected_steel_production(self) -> Optional[int]:
        return self.db_data.user_defined_expected_steel_production

    def get_scrap_stock_objective(self) -> Optional[int]:
        return self.db_data.scrap_stock_objective

    def get_export_slabs_weight(self) -> int:
        return self.db_data.export_slabs_weight

    def get_mean_scrap_weight(self) -> int:
        return self.db_data.mean_scrap_weight

    def get_suppliers(self) -> Tuple[str, ...]:
        return tuple(
            sorted(
                set(
                    scrap_offer.supplier
                    for scrap_offer in self.get_scrap_offer_data()
                    if scrap_offer.supplier is not None
                )
            )
        )

    def get_last_update_time(self) -> datetime:
        return ScrapPurchaseRecord.objects.get(pk=self.purchase_id).updated_at


@attrs.frozen
class DbScrapPurchases:
    purchase_date: date

    @property
    def last_month(self) -> date:
        return (self.purchase_date - relativedelta(months=1)).replace(day=1)

    def create(self, supplier: str, scrap_type: str, zone: str, price: float) -> int:
        supplier_mapping = ScrapSupplierMapping.objects.filter(input_scrap_supplier=supplier)
        if not supplier_mapping:
            return -1
        scrap_supplier = supplier_mapping[0].scrap_supplier
        scrap_purchase = ScrapPurchase(
            supplier=scrap_supplier,
            scrap_type=scrap_type,
            zone=zone,
            price=price,
            date=self.last_month,
            quantity=0,
            entered_manually=True,
        )
        scrap_purchase.save()
        return scrap_purchase.id

    def update(self, scrap_purchase_id: int, **kwargs) -> None:
        ScrapPurchase.objects.filter(id=scrap_purchase_id).update(**kwargs)


@attr.s(frozen=True, slots=True, cache_hash=False)
class ScrapPurchaseAppViewModel:
    logged_user_id: DataStoreViewModel = sdc.child_component("logged-user-id", default=DataStoreViewModel())
    user_in_control_id: DataStoreViewModel = sdc.child_component(
        "user-in-control-id", default=DataStoreViewModel()
    )
    scrap_purchase_info: DataStoreStrViewModel = sdc.child_component(
        "scrap-purchase-info", default=DataStoreStrViewModel()
    )
    scrap_purchase_record_id: DataStoreViewModel = sdc.child_component(
        "scrap-purchase-record-id", default=DataStoreViewModel()
    )
    delta_conditions_table: DeltaConditionsTableVM = sdc.child_component(
        "delta-conditions", factory=DeltaConditionsTableVM
    )
    purchase_navbar: PurchaseNavbarViewModel = sdc.child_component(
        "purchase", factory=PurchaseNavbarViewModel
    )
    purchase_inputs_button: PurchaseInputDataButtonViewModel = sdc.child_component(
        "data-inputs", factory=PurchaseInputDataButtonViewModel
    )
    purchase_optimization_bar: PurchaseOptimizationVM = sdc.child_component(
        "purchase-optimization-bar", factory=PurchaseOptimizationVM
    )
    scrap_offers_table: ScrapOffersTableVM = sdc.child_component("scrap-offers", factory=ScrapOffersTableVM)
    scrap_pivot_table: ScrapPurchaseRealizedPivotTableViewModel = sdc.child_component(
        "scrap-pivot", factory=ScrapPurchaseRealizedPivotTableViewModel
    )
    overal_purchase_table: OveralScrapPurchaseTableViewModel = sdc.child_component(
        "overal-purchase", factory=OveralScrapPurchaseTableViewModel
    )
    realized_scrap_offer_table: RealizedScrapOfferTableViewModel = sdc.child_component(
        "realized-offer", factory=RealizedScrapOfferTableViewModel
    )
    close_purchase_button: ClosePurchaseButtonViewModel = sdc.child_component(
        "close-purchase", default=ClosePurchaseButtonViewModel()
    )
    purchase_date_str: DataStoreStrViewModel = sdc.child_component(
        "purchase-date", default=DataStoreStrViewModel()
    )
    global_alert: GlobalAlertVM = sdc.child_component("", factory=GlobalAlertVM)

    @classmethod
    def get_layout(cls, config: ScrapPurchaseAppConfig):
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id="", child_component=cls.purchase_navbar, config=config),
                sdc.get_child_layout(parent_id="", child_component=cls.purchase_inputs_button, config=config),
                sdc.get_child_layout(parent_id="", child_component=cls.delta_conditions_table, config=config),
                sdc.get_child_layout(parent_id="", child_component=cls.global_alert),
                sdc.get_child_layout(
                    parent_id="", child_component=cls.purchase_optimization_bar, config=config
                ),
                sdc.get_child_layout(parent_id="", child_component=cls.scrap_offers_table, config=config),
                sdc.get_child_layout(parent_id="", child_component=cls.scrap_pivot_table),
                sdc.get_child_layout(parent_id="", child_component=cls.overal_purchase_table),
                sdc.get_child_layout(
                    parent_id="", child_component=cls.realized_scrap_offer_table, config=config
                ),
                sdc.get_child_layout(parent_id="", child_component=cls.close_purchase_button, config=config),
                sdc.get_child_layout(parent_id="", child_component=cls.logged_user_id),
                sdc.get_child_layout(parent_id="", child_component=cls.scrap_purchase_record_id),
                sdc.get_child_layout(parent_id="", child_component=cls.purchase_date_str),
                sdc.get_child_layout(parent_id="", child_component=cls.user_in_control_id),
                sdc.get_child_layout(parent_id="", child_component=cls.scrap_purchase_info),
            ]
        )

    @classmethod
    def load_initial_data(cls, *args, **kwargs) -> "ScrapPurchaseAppViewModel":
        logged_user_id = kwargs["user"].id
        scrap_purchase_record_id = kwargs["session_state"]["scrap_purchase_record_id"]
        purchase_date = kwargs["session_state"]["purchase_date"]
        user_in_control_id = kwargs["session_state"]["user_in_control_id"]
        scrap_purchase_info = kwargs["session_state"]["scrap_purchase_info"]
        return ScrapPurchaseAppViewModel(  # type: ignore
            logged_user_id=DataStoreViewModel(data=logged_user_id),  # type: ignore
            user_in_control_id=DataStoreViewModel(data=user_in_control_id),  # type: ignore
            scrap_purchase_record_id=DataStoreViewModel(data=scrap_purchase_record_id),  # type: ignore
            purchase_date_str=DataStoreStrViewModel(data=purchase_date),  # type: ignore
            scrap_purchase_info=DataStoreStrViewModel(data=scrap_purchase_info),  # type: ignore
        )


class ScrapPurchaseAppCTX:
    def __init__(self, parent: ScrapPurchaseAppViewModel):
        self.parent = parent

    @property
    def db_scrap_purchases(self) -> DbScrapPurchases:
        return DbScrapPurchases(self.purchase_date)

    @property
    def db_purchase_data_source(self) -> DBScrapPurchaseDataSource:
        return DBScrapPurchaseDataSource(self.scrap_purchase_id, self.purchase_date)

    @property
    def db_purchase_optimization_data_source(self) -> PurchaseOptimizationDataSource:
        return DBPurchaseOptimizationDataSource()

    @property
    def scrap_purchase_id(self) -> int:
        return self.parent.scrap_purchase_record_id.data

    @property
    def purchase_date(self) -> date:
        return datetime.strptime(self.parent.purchase_date_str.data, "%Y-%m-%d").date()

    @property
    def purchase_optimizations(self) -> PurchaseOptimizations:
        return self.parent.purchase_optimization_bar.get_optimizations_data_source(self.scrap_purchase_id)

    @property
    def db_user_data(self) -> UserDataSource:
        return DBUsersDataSource(self.parent.logged_user_id.data, self.parent.user_in_control_id.data)

    @property
    def scrap_purchase_info(self) -> str:
        return self.parent.scrap_purchase_info.data

    @property
    def filtered_offers_ids(self) -> Tuple[str, ...]:
        return self.parent.scrap_offers_table.filtered_offer_ids
