class ScrapPurchaseAppConfig:
    def __init__(self, read_only: bool):
        self.read_only = read_only


# Possible solution for common.py protocols is to use config.py for protocol definitions
