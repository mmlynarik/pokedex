import logging
from django.conf import settings
import dash
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash
from typing import Any, Callable, NamedTuple, Sequence, List, Dict, Tuple, Optional, Union

from ..components import multiple_callback_triggered_by_exact

from ..components.scrap_purchase_components import (
    CONTROL_CHANGED_MODAL_ID,
    REFRESH_REQUEST_MODAL_ID,
    USER_IN_CONTROL_NAME_ID,
    get_layout,
    get_input_data_layout,
    ScrapPurchaseViewModel,
    deserialize_scrap_purchase_view_model,
    DISPLAY_DATA_STORE_ID,
    SCRAP_PURCHASE_RECORD_ID_DIV_ID,
    SHOW_SCRAP_STATE_PARSED_DATA_BUTTON,
    SHOW_SCRAP_ON_THE_WAY_PARSED_DATA_BUTTON,
    SHOW_SCRAP_OFFERS_PARSED_DATA_BUTTON,
    SCRAP_PURCHASE_TITLE_INPUT,
    PURCHASE_DATE_INPUT,
    SCRAP_STATE_FILENAME_ID,
    SCRAP_ON_THE_WAY_FILENAME_ID,
    SCRAP_STATE_TABLE,
    SCRAP_STOCK_OBJECTIVE_INPUT,
    SCRAP_STATE_PARSED_DATA_COLLAPSE,
    SCRAP_STATE_PARSED_DATA_TABLE,
    SCRAP_ON_THE_WAY_PARSED_DATA_COLLAPSE,
    SCRAP_ON_THE_WAY_PARSED_DATA_TABLE,
    PRODUCTION_PLAN_DATE_PICKER_ID,
    PRODUCTION_PLAN_NR_OF_WEEKS_ID,
    PRODUCTION_PLAN_TABLE_ID,
    SCRAP_OFFERS_PARSED_DATA_TABLE,
    SCRAP_OFFERS_FILENAME_ID,
    SCRAP_OFFERS_PARSED_DATA_COLLAPSE,
    USER_NAME_ID,
    NAVBAR_SCRAP_PURCHASE_INFO,
    SCRAP_OFFERS_TABLE,
    SCRAP_PRICE_PLOT_HIDE_BUTTON,
    WIZARD_STEP_1_ID,
    WIZARD_STEP_2_ID,
    WIZARD_STEP_3_ID,
    WIZARD_STEP_4_ID,
    MAIN_SECTION_ID,
    BASE_DELTA_RULES_TABLE,
    REALIZED_SCRAP_OFFERS_TABLE,
    OVERALL_PURCHASE_TABLE,
    SCRAP_PRICE_PLOT,
    SCRAP_PRICE_PLOT_SECTION,
    INPUT_DATA_LINK_ID,
    APPLIED_DELTA_RULES_PROGRESS_BAR,
    UPLOAD_SCRAP_STATE_ID,
    SCRAP_ON_THE_WAY_UPLOAD_ID,
    UPLOAD_SCRAP_OFFERS_ID,
    SCRAP_STATE_MAPPING_TABLE,
    SCRAP_STATE_SAVE_MAPPINGS,
    PRODUCTION_PLAN_LOAD_BUTTON_ID,
    SCRAP_OFFERS_MAPPING_TABLE,
    SCRAP_OFFERS_SAVE_MAPPINGS,
    UNMAPPED_SCRAP_SUPPLIER_TABLE,
    UNMAPPED_SCRAP_SUPPLIER_SAVE,
    ADD_NEW_SCRAP_OFFER_BUTTON_ID,
    BASE_DELTA_RULES_ADD_BUTTON,
    BUY_SCRAP_MODAL_WINDOW,
    BUY_SCRAP_MODAL_CONFIRMATION_BUTTON,
    BUY_SCRAP_MODAL_PRICE,
    BUY_SCRAP_MODAL_AMOUNT,
    CREATE_EDIT_OFFER_MODAL_WINDOW,
    CREATE_EDIT_OFFER_MODAL_DELETE,
    CREATE_EDIT_OFFER_MODAL_CONFIRM,
    CREATE_EDIT_OFFER_MODAL_SCRAP_TYPE,
    CREATE_EDIT_OFFER_MODAL_ZONE,
    CREATE_EDIT_OFFER_MODAL_WEIGHT,
    CREATE_EDIT_OFFER_MODAL_SUPPLIER,
    CREATE_EDIT_OFFER_MODAL_PRICE,
    CREATE_EDIT_OFFER_MODAL_OVERRIDE_PRICE,
    CREATE_EDIT_OFFER_MODAL_NOTE,
    CREATE_EDIT_OFFER_MODAL_STATION,
    DELETE_REALIZED_OFFER_MODAL,
    DELETE_REALIZED_OFFER_CONFIRM,
    WIZARD_CONFIRM_1_ID,
    WIZARD_CONFIRM_2_ID,
    WIZARD_CONFIRM_3_ID,
    WIZARD_CONFIRM_4_ID,
    WIZARD_BACK_FROM_STEP_2_ID,
    WIZARD_BACK_FROM_STEP_3_ID,
    WIZARD_BACK_FROM_STEP_4_ID,
    RUN_COMPUTATION_BUTTON,
    COMPUTATION_REFRESH_INTERVAL_ID,
    FINISH_PURCHASE_BUTTON,
    FINISH_PURCHASE_MODAL_WINDOW,
    FINISH_PURCHASE_MODAL_CONFIRMATION,
    FINISH_PURCHASE_MODAL_BODY,
    SCRAP_STATE_ERROR_DIV,
    SCRAP_STATE_MAPPING_SECTION,
    SCRAP_OFFERS_MAPPING_SECTION,
    UNMAPPED_SCRAP_SUPPLIER_SECTION,
    BUY_SCRAP_MODAL_OFFER_INFO,
    DELETE_REALIZED_OFFER_MODAL_BODY,
    ERROR_MODAL_WINDOW_ID,
    PROGRESS_BAR_ID,
    RELOAD_DATA_INTERVAL_ID,
    STATUS_ID,
    SCRAP_PURCHASED_RECOMMENDED_PIVOT_TABLE_ID,
    MEAN_SCRAP_WEIGHT_INPUT,
    REALIZED_SCRAP_OFFERS_TABLE_EXPORT,
    EXPECTED_STEEL_PRODUCTION_INPUT,
    EXPORT_SLABS_WEIGHT_INPUT,
)

from .input_callbacks import (
    # common inputs
    change_control,
    show_hide_scrap_state_parsed_table,
    show_hide_scrap_on_the_way_parsed_table,
    show_hide_scrap_offers_parsed_table,
    # read only inputs
    click_on_scrap_offers_table,
    scrap_offers_table_derived_viewport_indices,
    hide_price_plot_button_click,
    readonly_reload,
    # edit app inputs
    upload_scrap_state_filename,
    upload_scrap_state_content,
    upload_scrap_on_the_way_filename,
    upload_scrap_on_the_way_content,
    upload_scrap_offers_filename,
    upload_scrap_offers_content,
    unmapped_scrap_state_mapping_table_data_update,
    save_scrap_state_scrap_types_mappings,
    production_plan_date_selected,
    load_production_plan,
    unmapped_scrap_offers_mapping_table_data_update,
    save_scrap_offers_scrap_types_mappings,
    unmapped_scrap_supplier_mapping_table_data_update,
    save_scrap_supplier_mapping,
    set_scrap_stock_objective,
    update_scrap_purchase_title,
    add_new_scrap_offer_row,
    user_update_scrap_offer_table,
    add_new_base_delta_rule,
    user_update_base_delta_rules_table,
    click_on_base_delta_rule_table,
    sync_modal_state_with_model,
    confirm_scrap_purchase,
    set_buy_scrap_modal_price,
    set_buy_scrap_modal_amount,
    set_purchase_date,
    sync_create_edit_offer_modal_state_with_model,
    delete_scrap_offer_click,
    create_update_offer_confirm_click,
    set_create_edit_offer_scrap_type,
    set_create_edit_offer_zone,
    set_create_edit_offer_weight,
    set_create_edit_offer_supplier,
    set_create_edit_offer_price,
    set_create_edit_offer_override_price,
    set_create_edit_offer_note,
    set_create_edit_offer_station,
    click_on_realized_scrap_offers_table,
    sync_delete_realized_offer_modal_state_with_model,
    confirm_delete_realized_scrap_offer,
    set_production_plan_nr_of_weeks,
    click_on_confirm_step_1,
    click_on_confirm_step_2,
    click_on_confirm_step_3,
    click_on_confirm_step_4,
    click_on_back_from_step_2,
    click_on_back_from_step_3,
    click_on_back_from_step_4,
    click_on_run_computation_button,
    computation_refresh_data,
    click_on_finish_purchase_button,
    sync_finish_purchase_modal_is_open,
    click_on_confirm_finish_purchase,
    set_mean_scrap_weight,
    set_expected_steel_production_weight,
)

from .output_callbacks import (
    # common outputs
    control_gained,
    control_lost,
    hide_get_control_button,
    set_scrap_purchase_title,
    update_purchase_date,
    set_scrap_state_filename,
    set_scrap_on_the_way_filename,
    set_scrap_state_table_data,
    update_scrap_stock_objective,
    open_close_scrap_state_parsed_data_collapse,
    set_scrap_state_parsed_table_data,
    open_close_scrap_on_the_way_parsed_data_collapse,
    set_scrap_on_the_way_parsed_table_data,
    update_production_plan_date,
    update_production_plan_nr_of_weeks,
    set_production_plan_table_data,
    set_scrap_offers_parsed_table_data,
    set_scrap_offers_filename,
    open_close_scrap_offers_parsed_data_collapse,
    update_user_in_control_name,
    update_username,
    update_navbar_scrap_purchase_info,
    # read only outputs
    show_hide_wizard_step_1,
    show_hide_wizard_step_2,
    show_hide_wizard_step_3,
    show_hide_wizard_step_4,
    show_hide_main_section,
    update_scrap_offers_table,
    update_base_delta_rules_table,
    update_base_delta_rules_dropdowns,
    update_realized_scrap_offers_table,
    update_overall_purchase_table,
    update_price_plot_figure,
    show_hide_scrap_price_plot_section,
    update_input_data_link,
    update_applied_delta_rules_progress_bar_value,
    update_applied_delta_rules_progress_bar_children,
    update_refresh_time,
    # edit app outputs
    set_error_message,
    enable_save_scrap_state_mappings_button,
    set_unmapped_scrap_state_scrap_types,
    show_hide_scrap_state_mappings_section,
    enable_save_scrap_offers_mappings_button,
    set_unmapped_scrap_offers_scrap_types,
    show_hide_scrap_offers_mapping_section,
    set_unmapped_scrap_supplier_mapping_table,
    enable_save_scrap_supplier_mappings_button,
    show_hide_scrap_supplier_mapping_section,
    disable_production_plan_load_button,
    enable_show_scrap_state_parsed_data_button,
    enable_show_scrap_on_the_way_parsed_data_button,
    enable_show_scrap_offers_data_button,
    update_scrap_offers_table_dropdowns,
    update_unmapped_scrap_supplier_dropdowns,
    show_hide_buy_scrap_modal_window,
    fill_buy_scrap_modal_offer_info,
    enable_buy_scrap_button,
    sync_buy_scrap_modal_price,
    sync_buy_scrap_modal_amount,
    show_hide_create_edit_offer_modal_window,
    update_create_edit_offer_modal_supplier_options,
    disable_update_scrap_offer_confirm_button,
    update_create_edit_offer_scrap_type,
    update_create_edit_offer_zone,
    update_create_edit_offer_weight,
    update_create_edit_offer_supplier,
    update_create_edit_offer_price,
    update_create_edit_offer_override_price,
    update_create_edit_offer_note,
    update_create_edit_offer_station,
    show_hide_delete_realized_offer_modal,
    fill_delete_realized_offer_info,
    open_close_error_modal_window,
    disable_confirm_step_1,
    disable_confirm_step_2,
    disable_confirm_step_3,
    disable_confirm_step_4,
    disable_run_computation_button,
    disable_computation_refresh_interval,
    update_computation_progress_text,
    update_computation_progress_value,
    update_computation_progress_style,
    update_scrap_offers_table_columns,
    update_realized_scrap_offers_table_columns,
    update_finish_purchase_modal_is_open,
    update_finish_purchase_modal_backdrop,
    show_hide_finish_purchase_modal_body,
    disable_confirm_finish_purchase_button,
    update_scrap_pivot_table,
    update_mean_scrap_weight,
    update_export_realized_scrap_offers_button,
    update_expected_steel_production_weight,
    update_export_slabs_weight,
)

from .internal import load_initial_data

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

scrap_purchase_app = DjangoDash(
    "ScrapPurchase",
    serve_locally=settings.PLOTLY_DASH.get("serve_locally", True),
    add_bootstrap_links=True,
)
scrap_purchase_app.layout = get_layout()

scrap_purchase_input_data_app = DjangoDash(
    "ScrapPurchaseInputData",
    serve_locally=settings.PLOTLY_DASH.get("serve_locally", True),
    add_bootstrap_links=True,
)
scrap_purchase_input_data_app.layout = get_input_data_layout()

scrap_purchase_read_only_app = DjangoDash(
    "ScrapPurchaseReadOnly",
    serve_locally=settings.PLOTLY_DASH.get("serve_locally", True),
    add_bootstrap_links=True,
)
scrap_purchase_read_only_app.layout = get_layout(read_only=True)


class InputField(NamedTuple):
    component_name: str
    component_value: str
    update_display_data: Callable[[ScrapPurchaseViewModel, Any], ScrapPurchaseViewModel]


class OutputField(NamedTuple):
    component_name: str
    component_value: str
    sync_value: Callable[[ScrapPurchaseViewModel], Any]


InputFields = Sequence[InputField]
OutputFields = Sequence[OutputField]


def create_process_output_callback(output_fields: OutputFields):
    def process_output_callback(*args, **kwargs):  # pylint: disable=unused-argument
        try:
            if not args[0]:
                return tuple([dash.no_update] * (len(output_fields)))
            display_data = deserialize_scrap_purchase_view_model(args[0])
            results = []
            for i, field in enumerate(output_fields):
                new_value = field.sync_value(display_data)
                results.append(new_value if (new_value != args[i + 1]) else dash.no_update)
            return tuple(results)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Scrap purchase - output processing error ")
            return tuple(([dash.no_update] * len(output_fields)))

    return process_output_callback


def create_process_input_callback(input_fields: InputFields):
    def process_input_callback(*args, **kwargs) -> str:
        try:
            trigger = kwargs["callback_context"].triggered
            if not args[-1]:
                initial_callback = True
                display_data = load_initial_data(
                    kwargs["session_state"]["scrap_purchase_record_id"], kwargs["user"].username
                )
            else:
                initial_callback = False
                display_data = deserialize_scrap_purchase_view_model(args[-1])

            trigger_count = 0
            new_display_data_found = False
            for i, field in enumerate(input_fields):
                if multiple_callback_triggered_by_exact(field.component_name, field.component_value, trigger):
                    trigger_count += 1
                    new_display_data = field.update_display_data(display_data, args[i])
                    if new_display_data != display_data:
                        new_display_data_found = True
                        display_data = new_display_data
                    if trigger_count >= len(trigger) and new_display_data_found:
                        return new_display_data.serialize()
            if initial_callback:
                return display_data.serialize()
            return dash.no_update
        except Exception:  # pylint: disable=broad-except
            logger.exception("Scrap purchase - input processing error ")
            return dash.no_update

    return process_input_callback


def register_all_callbacks(app: DjangoDash, input_fields: InputFields, output_fields: OutputFields):
    app.expanded_callback(
        Output(DISPLAY_DATA_STORE_ID, "children"),
        [Input(field.component_name, field.component_value) for field in input_fields],
        [State(SCRAP_PURCHASE_RECORD_ID_DIV_ID, "children"), State(DISPLAY_DATA_STORE_ID, "children")],
    )(create_process_input_callback(input_fields))

    app.expanded_callback(
        [Output(field.component_name, field.component_value) for field in output_fields],
        [Input(DISPLAY_DATA_STORE_ID, "children")],
        [State(field.component_name, field.component_value) for field in output_fields],
    )(create_process_output_callback(output_fields))


common_input_fields = [
    InputField(SHOW_SCRAP_STATE_PARSED_DATA_BUTTON, "n_clicks", show_hide_scrap_state_parsed_table),
    InputField(SHOW_SCRAP_ON_THE_WAY_PARSED_DATA_BUTTON, "n_clicks", show_hide_scrap_on_the_way_parsed_table),
    InputField(SHOW_SCRAP_OFFERS_PARSED_DATA_BUTTON, "n_clicks", show_hide_scrap_offers_parsed_table),
]


common_output_fields = [
    OutputField(SCRAP_PURCHASE_TITLE_INPUT, "value", set_scrap_purchase_title),
    OutputField(PURCHASE_DATE_INPUT, "date", update_purchase_date),
    OutputField(SCRAP_STATE_FILENAME_ID, "value", set_scrap_state_filename),
    OutputField(SCRAP_ON_THE_WAY_FILENAME_ID, "value", set_scrap_on_the_way_filename),
    OutputField(SCRAP_STATE_TABLE, "data", set_scrap_state_table_data),
    OutputField(SCRAP_STOCK_OBJECTIVE_INPUT, "value", update_scrap_stock_objective),
    OutputField(MEAN_SCRAP_WEIGHT_INPUT, "value", update_mean_scrap_weight),
    OutputField(SCRAP_STATE_PARSED_DATA_COLLAPSE, "is_open", open_close_scrap_state_parsed_data_collapse),
    OutputField(SCRAP_STATE_PARSED_DATA_TABLE, "data", set_scrap_state_parsed_table_data),
    OutputField(
        SCRAP_ON_THE_WAY_PARSED_DATA_COLLAPSE, "is_open", open_close_scrap_on_the_way_parsed_data_collapse
    ),
    OutputField(SCRAP_ON_THE_WAY_PARSED_DATA_TABLE, "data", set_scrap_on_the_way_parsed_table_data),
    OutputField(PRODUCTION_PLAN_DATE_PICKER_ID, "date", update_production_plan_date),
    OutputField(PRODUCTION_PLAN_NR_OF_WEEKS_ID, "value", update_production_plan_nr_of_weeks),
    OutputField(EXPECTED_STEEL_PRODUCTION_INPUT, "value", update_expected_steel_production_weight),
    OutputField(EXPORT_SLABS_WEIGHT_INPUT, "value", update_export_slabs_weight),
    OutputField(PRODUCTION_PLAN_TABLE_ID, "data", set_production_plan_table_data),
    OutputField(SCRAP_OFFERS_PARSED_DATA_TABLE, "data", set_scrap_offers_parsed_table_data),
    OutputField(SCRAP_OFFERS_FILENAME_ID, "value", set_scrap_offers_filename),
    OutputField(SCRAP_OFFERS_PARSED_DATA_COLLAPSE, "is_open", open_close_scrap_offers_parsed_data_collapse),
    OutputField(USER_NAME_ID, "children", update_username),
    OutputField(NAVBAR_SCRAP_PURCHASE_INFO, "children", update_navbar_scrap_purchase_info),
    OutputField(USER_IN_CONTROL_NAME_ID, "children", update_user_in_control_name),
    OutputField(USER_IN_CONTROL_NAME_ID + "-div", "hidden", hide_get_control_button),
]


read_only_input_fields = [
    InputField(USER_IN_CONTROL_NAME_ID, "n_clicks", change_control),
    InputField(SCRAP_OFFERS_TABLE, "active_cell", click_on_scrap_offers_table),
    InputField(SCRAP_OFFERS_TABLE, "derived_viewport_indices", scrap_offers_table_derived_viewport_indices),
    InputField(SCRAP_PRICE_PLOT_HIDE_BUTTON, "n_clicks", hide_price_plot_button_click),
]


read_only_output_fields = [
    OutputField(REFRESH_REQUEST_MODAL_ID, "is_open", control_gained),
    OutputField(WIZARD_STEP_1_ID, "style", show_hide_wizard_step_1),
    OutputField(WIZARD_STEP_2_ID, "style", show_hide_wizard_step_2),
    OutputField(WIZARD_STEP_3_ID, "style", show_hide_wizard_step_3),
    OutputField(WIZARD_STEP_4_ID, "style", show_hide_wizard_step_4),
    OutputField(MAIN_SECTION_ID, "style", show_hide_main_section),
    OutputField(SCRAP_OFFERS_TABLE, "data", update_scrap_offers_table),
    OutputField(BASE_DELTA_RULES_TABLE, "data", update_base_delta_rules_table),
    OutputField(BASE_DELTA_RULES_TABLE, "dropdown", update_base_delta_rules_dropdowns),
    OutputField(REALIZED_SCRAP_OFFERS_TABLE, "data", update_realized_scrap_offers_table),
    OutputField(OVERALL_PURCHASE_TABLE, "data", update_overall_purchase_table),
    OutputField(SCRAP_PRICE_PLOT, "figure", update_price_plot_figure),
    OutputField(SCRAP_PRICE_PLOT_SECTION, "style", show_hide_scrap_price_plot_section),
    OutputField(INPUT_DATA_LINK_ID, "href", update_input_data_link),
    OutputField(APPLIED_DELTA_RULES_PROGRESS_BAR, "value", update_applied_delta_rules_progress_bar_value),
    OutputField(
        APPLIED_DELTA_RULES_PROGRESS_BAR, "children", update_applied_delta_rules_progress_bar_children
    ),
    OutputField(SCRAP_PURCHASED_RECOMMENDED_PIVOT_TABLE_ID, "data", update_scrap_pivot_table),
]


edit_app_input_fields = [
    # upload scrap state
    InputField(UPLOAD_SCRAP_STATE_ID, "filename", upload_scrap_state_filename),
    InputField(UPLOAD_SCRAP_STATE_ID, "contents", upload_scrap_state_content),
    # upload scrap on the way
    InputField(SCRAP_ON_THE_WAY_UPLOAD_ID, "filename", upload_scrap_on_the_way_filename),
    InputField(SCRAP_ON_THE_WAY_UPLOAD_ID, "contents", upload_scrap_on_the_way_content),
    # upload scrap offers
    InputField(UPLOAD_SCRAP_OFFERS_ID, "filename", upload_scrap_offers_filename),
    InputField(UPLOAD_SCRAP_OFFERS_ID, "contents", upload_scrap_offers_content),
    # scrap state mapping
    InputField(SCRAP_STATE_MAPPING_TABLE, "data", unmapped_scrap_state_mapping_table_data_update),
    InputField(SCRAP_STATE_SAVE_MAPPINGS, "n_clicks", save_scrap_state_scrap_types_mappings),
    # production plan
    InputField(PRODUCTION_PLAN_DATE_PICKER_ID, "date", production_plan_date_selected),
    InputField(PRODUCTION_PLAN_LOAD_BUTTON_ID, "n_clicks", load_production_plan),
    InputField(EXPECTED_STEEL_PRODUCTION_INPUT, "value", set_expected_steel_production_weight),
    # scrap type from scrap offers mapping
    InputField(SCRAP_OFFERS_MAPPING_TABLE, "data", unmapped_scrap_offers_mapping_table_data_update),
    InputField(SCRAP_OFFERS_SAVE_MAPPINGS, "n_clicks", save_scrap_offers_scrap_types_mappings),
    # scrap supplier mapping
    InputField(UNMAPPED_SCRAP_SUPPLIER_TABLE, "data", unmapped_scrap_supplier_mapping_table_data_update),
    InputField(UNMAPPED_SCRAP_SUPPLIER_SAVE, "n_clicks", save_scrap_supplier_mapping),
    InputField(SCRAP_STOCK_OBJECTIVE_INPUT, "value", set_scrap_stock_objective),
    InputField(MEAN_SCRAP_WEIGHT_INPUT, "value", set_mean_scrap_weight),
    InputField(SCRAP_PURCHASE_TITLE_INPUT, "value", update_scrap_purchase_title),
    InputField(ADD_NEW_SCRAP_OFFER_BUTTON_ID, "n_clicks", add_new_scrap_offer_row),
    InputField(SCRAP_OFFERS_TABLE, "data", user_update_scrap_offer_table),
    InputField(BASE_DELTA_RULES_ADD_BUTTON, "n_clicks", add_new_base_delta_rule),
    InputField(BASE_DELTA_RULES_TABLE, "data", user_update_base_delta_rules_table),
    InputField(BASE_DELTA_RULES_TABLE, "active_cell", click_on_base_delta_rule_table),
    InputField(BUY_SCRAP_MODAL_WINDOW, "is_open", sync_modal_state_with_model),
    InputField(BUY_SCRAP_MODAL_CONFIRMATION_BUTTON, "n_clicks", confirm_scrap_purchase),
    InputField(BUY_SCRAP_MODAL_PRICE, "value", set_buy_scrap_modal_price),
    InputField(BUY_SCRAP_MODAL_AMOUNT, "value", set_buy_scrap_modal_amount),
    InputField(PURCHASE_DATE_INPUT, "date", set_purchase_date),
    InputField(CREATE_EDIT_OFFER_MODAL_WINDOW, "is_open", sync_create_edit_offer_modal_state_with_model),
    InputField(CREATE_EDIT_OFFER_MODAL_DELETE, "n_clicks", delete_scrap_offer_click),
    InputField(CREATE_EDIT_OFFER_MODAL_CONFIRM, "n_clicks", create_update_offer_confirm_click),
    InputField(CREATE_EDIT_OFFER_MODAL_SCRAP_TYPE, "value", set_create_edit_offer_scrap_type),
    InputField(CREATE_EDIT_OFFER_MODAL_ZONE, "value", set_create_edit_offer_zone),
    InputField(CREATE_EDIT_OFFER_MODAL_WEIGHT, "value", set_create_edit_offer_weight),
    InputField(CREATE_EDIT_OFFER_MODAL_SUPPLIER, "value", set_create_edit_offer_supplier),
    InputField(CREATE_EDIT_OFFER_MODAL_PRICE, "value", set_create_edit_offer_price),
    InputField(CREATE_EDIT_OFFER_MODAL_OVERRIDE_PRICE, "value", set_create_edit_offer_override_price),
    InputField(CREATE_EDIT_OFFER_MODAL_NOTE, "value", set_create_edit_offer_note),
    InputField(CREATE_EDIT_OFFER_MODAL_STATION, "value", set_create_edit_offer_station),
    InputField(REALIZED_SCRAP_OFFERS_TABLE, "active_cell", click_on_realized_scrap_offers_table),
    InputField(DELETE_REALIZED_OFFER_MODAL, "is_open", sync_delete_realized_offer_modal_state_with_model),
    InputField(DELETE_REALIZED_OFFER_CONFIRM, "n_clicks", confirm_delete_realized_scrap_offer),
    InputField(PRODUCTION_PLAN_NR_OF_WEEKS_ID, "value", set_production_plan_nr_of_weeks),
    InputField(WIZARD_CONFIRM_1_ID, "n_clicks", click_on_confirm_step_1),
    InputField(WIZARD_CONFIRM_2_ID, "n_clicks", click_on_confirm_step_2),
    InputField(WIZARD_CONFIRM_3_ID, "n_clicks", click_on_confirm_step_3),
    InputField(WIZARD_CONFIRM_4_ID, "n_clicks", click_on_confirm_step_4),
    InputField(WIZARD_BACK_FROM_STEP_2_ID, "n_clicks", click_on_back_from_step_2),
    InputField(WIZARD_BACK_FROM_STEP_3_ID, "n_clicks", click_on_back_from_step_3),
    InputField(WIZARD_BACK_FROM_STEP_4_ID, "n_clicks", click_on_back_from_step_4),
    InputField(RUN_COMPUTATION_BUTTON, "n_clicks", click_on_run_computation_button),
    InputField(COMPUTATION_REFRESH_INTERVAL_ID, "n_intervals", computation_refresh_data),
    InputField(FINISH_PURCHASE_BUTTON, "n_clicks", click_on_finish_purchase_button),
    InputField(FINISH_PURCHASE_MODAL_WINDOW, "is_open", sync_finish_purchase_modal_is_open),
    InputField(FINISH_PURCHASE_MODAL_CONFIRMATION, "n_clicks", click_on_confirm_finish_purchase),
]

edit_app_output_fields = [
    OutputField(SCRAP_STATE_ERROR_DIV, "children", set_error_message),
    # scrap state mapping
    OutputField(SCRAP_STATE_SAVE_MAPPINGS, "disabled", enable_save_scrap_state_mappings_button),
    OutputField(SCRAP_STATE_MAPPING_TABLE, "data", set_unmapped_scrap_state_scrap_types),
    OutputField(SCRAP_STATE_MAPPING_SECTION, "style", show_hide_scrap_state_mappings_section),
    # scrap offers mapping
    OutputField(SCRAP_OFFERS_SAVE_MAPPINGS, "disabled", enable_save_scrap_offers_mappings_button),
    OutputField(SCRAP_OFFERS_MAPPING_TABLE, "data", set_unmapped_scrap_offers_scrap_types),
    OutputField(SCRAP_OFFERS_MAPPING_SECTION, "style", show_hide_scrap_offers_mapping_section),
    # scrap offers supplier mappings
    OutputField(UNMAPPED_SCRAP_SUPPLIER_TABLE, "data", set_unmapped_scrap_supplier_mapping_table),
    OutputField(UNMAPPED_SCRAP_SUPPLIER_SAVE, "disabled", enable_save_scrap_supplier_mappings_button),
    OutputField(UNMAPPED_SCRAP_SUPPLIER_SECTION, "style", show_hide_scrap_supplier_mapping_section),
    OutputField(PRODUCTION_PLAN_LOAD_BUTTON_ID, "disabled", disable_production_plan_load_button),
    OutputField(SHOW_SCRAP_STATE_PARSED_DATA_BUTTON, "disabled", enable_show_scrap_state_parsed_data_button),
    OutputField(
        SHOW_SCRAP_ON_THE_WAY_PARSED_DATA_BUTTON, "disabled", enable_show_scrap_on_the_way_parsed_data_button
    ),
    OutputField(SHOW_SCRAP_OFFERS_PARSED_DATA_BUTTON, "disabled", enable_show_scrap_offers_data_button),
    OutputField(SCRAP_OFFERS_TABLE, "dropdown", update_scrap_offers_table_dropdowns),
    OutputField(UNMAPPED_SCRAP_SUPPLIER_TABLE, "dropdown", update_unmapped_scrap_supplier_dropdowns),
    OutputField(BUY_SCRAP_MODAL_WINDOW, "is_open", show_hide_buy_scrap_modal_window),
    OutputField(BUY_SCRAP_MODAL_OFFER_INFO, "children", fill_buy_scrap_modal_offer_info),
    OutputField(BUY_SCRAP_MODAL_CONFIRMATION_BUTTON, "disabled", enable_buy_scrap_button),
    OutputField(BUY_SCRAP_MODAL_PRICE, "value", sync_buy_scrap_modal_price),
    OutputField(BUY_SCRAP_MODAL_AMOUNT, "value", sync_buy_scrap_modal_amount),
    OutputField(CREATE_EDIT_OFFER_MODAL_WINDOW, "is_open", show_hide_create_edit_offer_modal_window),
    OutputField(CREATE_EDIT_OFFER_MODAL_SUPPLIER, "options", update_create_edit_offer_modal_supplier_options),
    OutputField(CREATE_EDIT_OFFER_MODAL_CONFIRM, "disabled", disable_update_scrap_offer_confirm_button),
    OutputField(CREATE_EDIT_OFFER_MODAL_SCRAP_TYPE, "value", update_create_edit_offer_scrap_type),
    OutputField(CREATE_EDIT_OFFER_MODAL_ZONE, "value", update_create_edit_offer_zone),
    OutputField(CREATE_EDIT_OFFER_MODAL_WEIGHT, "value", update_create_edit_offer_weight),
    OutputField(CREATE_EDIT_OFFER_MODAL_SUPPLIER, "value", update_create_edit_offer_supplier),
    OutputField(CREATE_EDIT_OFFER_MODAL_PRICE, "value", update_create_edit_offer_price),
    OutputField(CREATE_EDIT_OFFER_MODAL_OVERRIDE_PRICE, "value", update_create_edit_offer_override_price),
    OutputField(CREATE_EDIT_OFFER_MODAL_NOTE, "value", update_create_edit_offer_note),
    OutputField(CREATE_EDIT_OFFER_MODAL_STATION, "value", update_create_edit_offer_station),
    OutputField(DELETE_REALIZED_OFFER_MODAL, "is_open", show_hide_delete_realized_offer_modal),
    OutputField(DELETE_REALIZED_OFFER_MODAL_BODY, "children", fill_delete_realized_offer_info),
    OutputField(ERROR_MODAL_WINDOW_ID, "is_open", open_close_error_modal_window),
    # wizard
    OutputField(WIZARD_CONFIRM_1_ID, "disabled", disable_confirm_step_1),
    OutputField(WIZARD_CONFIRM_2_ID, "disabled", disable_confirm_step_2),
    OutputField(WIZARD_CONFIRM_3_ID, "disabled", disable_confirm_step_3),
    OutputField(WIZARD_CONFIRM_4_ID, "disabled", disable_confirm_step_4),
    OutputField(RUN_COMPUTATION_BUTTON, "disabled", disable_run_computation_button),
    OutputField(COMPUTATION_REFRESH_INTERVAL_ID, "disabled", disable_computation_refresh_interval),
    OutputField(PROGRESS_BAR_ID, "children", update_computation_progress_text),
    OutputField(PROGRESS_BAR_ID, "value", update_computation_progress_value),
    OutputField(PROGRESS_BAR_ID, "className", update_computation_progress_style),
    OutputField(SCRAP_OFFERS_TABLE, "columns", update_scrap_offers_table_columns),
    OutputField(REALIZED_SCRAP_OFFERS_TABLE, "columns", update_realized_scrap_offers_table_columns),
    OutputField(REALIZED_SCRAP_OFFERS_TABLE_EXPORT, "href", update_export_realized_scrap_offers_button),
    OutputField(FINISH_PURCHASE_MODAL_WINDOW, "is_open", update_finish_purchase_modal_is_open),
    OutputField(FINISH_PURCHASE_MODAL_WINDOW, "backdrop", update_finish_purchase_modal_backdrop),
    OutputField(FINISH_PURCHASE_MODAL_CONFIRMATION, "disabled", disable_confirm_finish_purchase_button),
    OutputField(FINISH_PURCHASE_MODAL_BODY, "style", show_hide_finish_purchase_modal_body),
]


# INPUT DATA APP
register_all_callbacks(
    scrap_purchase_input_data_app,
    common_input_fields,
    common_output_fields,
)


# READ ONLY APP
register_all_callbacks(
    scrap_purchase_read_only_app,
    common_input_fields
    + read_only_input_fields
    + [
        InputField(RELOAD_DATA_INTERVAL_ID, "n_intervals", readonly_reload),
    ],
    common_output_fields
    + read_only_output_fields
    + [
        OutputField(STATUS_ID, "children", update_refresh_time),
        OutputField(RELOAD_DATA_INTERVAL_ID, "disabled", control_gained),
    ],
)


# EDIT APP
register_all_callbacks(
    scrap_purchase_app,
    common_input_fields + read_only_input_fields + edit_app_input_fields,
    common_output_fields + read_only_output_fields + edit_app_output_fields,
)
