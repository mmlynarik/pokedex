class ScrapPurchaseError(Exception):
    """Generic exception for scrap purchase"""
