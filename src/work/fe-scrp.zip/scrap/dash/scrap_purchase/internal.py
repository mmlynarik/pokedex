import logging

from dateutil.relativedelta import relativedelta

from scrap_core.utils import convert_kilograms_to_tons, MEAN_SCRAP_WEIGHT

from .errors import ScrapPurchaseError
from ..components.scrap_purchase_components import (
    ScrapPurchaseViewModel,
    PricePlotData,
    PricePlotValues,
    ScrapOffer,
    ScrapOfferData,
    ScrapOfferTableRow,
    ScrapTypeMappingTableRow,
    ScrapTypeMapping,
    ScrapTypeMappingData,
    ProductionPlanData,
    ScrapSupplierMapping,
    ScrapSupplierMappingTableRow,
    ScrapStateTableRow,
    ProductionPlanTableRow,
    BaseDeltaRuleTableRow,
    OverallPurchaseTableData,
    OverallPurchaseTableRow,
)

from ..base_delta_rule_evaluation import evaluate_base_delta_rule
from ...scrap_purchase.optimization import get_remainder_recommendation
from ...utils import is_zone_domestic
from typing import List, Dict, Tuple, Any, Optional, Callable
import numpy
import uuid
import pandas as pd
from datetime import datetime, date
import cattr
from collections import OrderedDict
from django.conf import settings

from usskssgrades.ispv_hook import (
    PlannedHeatWeek,
    IspvHook,
)

from ..database_api import steel_grades

from ...models import (
    SupportedScrapTypeMapping,
    ScrapPurchase as ScrapPurchaseModel,
    ScrapSupplier as ScrapSupplierModel,
    ScrapSupplierMapping as ScrapSupplierMappingModel,
    ScrapState,
    ScrapParsedData,
    ScrapOfferParsedRecord,
    ProductionPlan,
    BaseDeltaRule,
    ScrapPurchaseRecord,
)

from ...imports import (
    assign_scrap_type_to_scrap_state_data,
    decode_uploaded_file,
    parse_scrap_state_file,
    parse_scrap_on_the_way_file,
    # TODO: rename parse_scrap_excel_file method
    parse_scrap_excel_file,
    assign_scrap_type_to_scrap_offers_data,
    assign_scrap_supplier_to_scrap_offer_data,
)

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def save_state_after_input(f: Callable[[ScrapPurchaseViewModel, Any], ScrapPurchaseViewModel]):
    def wrapper(*args):
        res = f(*args)
        try:
            save_current_data(res)
        except Exception as e:  # pylint: disable=broad-except
            logger.error(f"Error while saving scrap purchase record to database:\n{e}")
            return res.update_field(error=True)
        return res

    return wrapper


def get_global_scrap_offer_idx(data: ScrapPurchaseViewModel, clicked_row_id: int) -> int:
    return data.scrap_offers_table_derived_indices[clicked_row_id]


def show_price_plot(data: ScrapPurchaseViewModel, global_row_id: int) -> ScrapPurchaseViewModel:
    new_data = data.update_field(scrap_offer_to_plot=data.scrap_offer_data[global_row_id])
    return compute_price_plot_data(new_data)


def open_buy_scrap_modal_window(data: ScrapPurchaseViewModel, global_row_id: int) -> ScrapPurchaseViewModel:
    scrap_offer_to_buy = data.scrap_offer_data[global_row_id]

    if scrap_offer_to_buy.scrap_purchased:
        return data

    return data.update_field(
        scrap_offer_to_buy_idx=global_row_id,
        scrap_offer_to_buy_price=scrap_offer_to_buy.purchase_price,
    )


def open_edit_create_offer_modal_window(
    data: ScrapPurchaseViewModel, global_row_id: int
) -> ScrapPurchaseViewModel:
    scrap_offer_to_edit = data.scrap_offer_data[global_row_id]
    if not scrap_offer_to_edit.scrap_purchased:
        return data.update_field(
            scrap_offer_to_edit_idx=global_row_id,
            scrap_offer_to_edit_scrap_type=scrap_offer_to_edit.scrap_type,
            scrap_offer_to_edit_zone=scrap_offer_to_edit.zone,
            scrap_offer_to_edit_weight=scrap_offer_to_edit.weight,
            scrap_offer_to_edit_supplier=scrap_offer_to_edit.supplier,
            scrap_offer_to_edit_price=scrap_offer_to_edit.supplier_price,
            scrap_offer_to_edit_note=scrap_offer_to_edit.note,
            scrap_offer_to_edit_override_price=scrap_offer_to_edit.override_price,
            scrap_offer_to_edit_station=scrap_offer_to_edit.station,
        )
    return data


def divide_price_history_list(price_history_list: List[ScrapPurchaseModel]) -> OrderedDict:
    group_by_date: OrderedDict = OrderedDict()
    for price_history_item in price_history_list:
        item_date = price_history_item.date
        if item_date not in group_by_date:
            group_by_date[item_date] = {
                "price_list": list(),
                "quantity_list": list(),
                "supplier_list": list(),
            }
        group_by_date[item_date]["price_list"].append(price_history_item.price)
        group_by_date[item_date]["quantity_list"].append(price_history_item.quantity)
        group_by_date[item_date]["supplier_list"].append(price_history_item.supplier)
    return group_by_date


def process_price_history_group(price_history_group: Dict) -> Tuple[float, str]:
    temp_price_list = price_history_group["price_list"]
    temp_quantity_list = price_history_group["quantity_list"]
    temp_supplier_list = price_history_group["supplier_list"]

    final_value = (
        numpy.average(temp_price_list, weights=temp_quantity_list) if sum(temp_quantity_list) > 0 else 0.0
    )
    hover_label = f"{final_value}€<br>" + "<br>".join(
        [
            "{}€ {}ton {}".format(p, q, s)
            for p, q, s in zip(temp_price_list, temp_quantity_list, temp_supplier_list)
        ]
    )
    return final_value, hover_label


# pylint: disable=too-many-locals
def compute_price_plot_data(data: ScrapPurchaseViewModel) -> Any:
    if not data.scrap_offer_to_plot or data.scrap_offer_to_plot.scrap_type is None:
        return data.update_field(
            price_plot_data=PricePlotData(
                scrap_type=None,
                price_plot_values=OrderedDict(),
            ),
        )

    scrap_type = data.scrap_offer_to_plot.scrap_type
    if scrap_type != data.price_plot_data.scrap_type:

        computed_data = OrderedDict()
        price_plot_data = PricePlotData(
            scrap_type=scrap_type,
            price_plot_values=OrderedDict(),
        )

        zone_list = get_zone_list_for_scrap_type_from_db(ordered=True)
        price_history_querysets = get_scrap_type_price_histories_for_zones(
            scrap_type=str(scrap_type), zones=zone_list
        )

        for price_history_zone, price_history in price_history_querysets.items():
            price_history_list = list(price_history)

            date_list = list()
            hover_label_list = list()
            weighted_price_list = list()

            group_by_date = divide_price_history_list(price_history_list)

            for item_date, item_dict in group_by_date.items():
                final_value, hover_label = process_price_history_group(item_dict)
                if final_value:
                    item_datetime = datetime(year=item_date.year, month=item_date.month, day=item_date.day)
                    date_list.append(item_datetime)
                    weighted_price_list.append(final_value)
                    hover_label_list.append(hover_label)

            computed_data[price_history_zone] = PricePlotValues(
                date_list=date_list,
                hover_label_list=hover_label_list,
                weighted_price_list=weighted_price_list,
            )
        price_plot_data = price_plot_data.update_field(
            price_plot_values=computed_data,
        )
        return data.update_field(
            price_plot_data=price_plot_data,
        )
    return data


def get_zone_list_for_scrap_type_from_db(ordered: bool = False) -> List[str]:
    zone_values = list(ScrapPurchaseModel.objects.order_by().values("zone").distinct())
    zone_list = list()
    for zone_dict in zone_values:
        zone_value = zone_dict.get("zone", None)
        if zone_value:
            zone_list.append(zone_value)
    if ordered:
        zone_list = sorted(zone_list)
    return zone_list


def get_scrap_type_price_histories_for_zones(scrap_type: str, zones: List[str]) -> Dict:
    price_histories = dict()
    for zone in zones:
        price_histories[zone] = ScrapPurchaseModel.objects.filter(scrap_type=scrap_type, zone=zone).order_by(
            "date"
        )
    return price_histories


# helping function called after upload or after saving supported scrap type mappings
# TODO: this method is doing unnecessary things when scrap offers are uploaded
def process_scrap_state_data_after_parsing(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    parsed_scrap_state_with_type = assign_scrap_type_to_scrap_state_data(data.parsed_scrap_state_data)
    parsed_scrap_on_the_way_with_type = assign_scrap_type_to_scrap_state_data(
        data.parsed_scrap_on_the_way_data
    )
    new_data = data.update_field(
        parsed_scrap_state_data=parsed_scrap_state_with_type,
        parsed_scrap_on_the_way_data=parsed_scrap_on_the_way_with_type,
    )
    unmapped_scrap_types = find_unmapped_scrap_types_from_parsed_data(
        new_data.parsed_scrap_state_data + new_data.parsed_scrap_on_the_way_data
    )
    new_data = new_data.update_field(unmapped_scrap_types_from_scrap_state=unmapped_scrap_types)

    if new_data.are_unmapped_types_from_scrap_state_data():
        return new_data.reset_unmapped_scrap_types_from_scrap_state_data()

    return compute_scrap_state(new_data)


def find_unmapped_scrap_types_from_parsed_data(parsed_data: Tuple[Any, ...]) -> Tuple[str, ...]:
    unmapped_scrap_types = list()
    for parsed_row in parsed_data:
        scrap_type = parsed_row.scrap_type
        if not scrap_type:
            if parsed_row.input_scrap_type not in unmapped_scrap_types:
                unmapped_scrap_types.append(str(parsed_row.input_scrap_type))
    return tuple(unmapped_scrap_types)


def compute_scrap_state(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    input_scrap_type_column_name = "input_scrap_type"
    scrap_type_column_name = "scrap_type"
    weight_column_name = "weight"
    state_weight_column_name = "state_weight"
    on_the_way_column_name = "on_the_way_weight"

    scrap_state_data = data.parsed_scrap_state_data
    scrap_on_the_way_data = data.parsed_scrap_on_the_way_data

    state_df = pd.DataFrame.from_records(
        [cattr.unstructure(parsed_record) for parsed_record in scrap_state_data],
        columns=[input_scrap_type_column_name, scrap_type_column_name, weight_column_name],
        exclude=[input_scrap_type_column_name],
    ).rename(columns={weight_column_name: state_weight_column_name})

    on_the_way_df = pd.DataFrame.from_records(
        [cattr.unstructure(parsed_record) for parsed_record in scrap_on_the_way_data],
        columns=[input_scrap_type_column_name, scrap_type_column_name, weight_column_name],
        exclude=[input_scrap_type_column_name],
    ).rename(columns={weight_column_name: on_the_way_column_name})

    appended_df = pd.concat([state_df, on_the_way_df]).fillna(0.0)
    data_list = appended_df.groupby(by="scrap_type", as_index=False).sum().T.to_dict().values()

    result_list = list()
    for data_record in data_list:
        result_list.append(
            ScrapState(
                scrap_type=data_record[scrap_type_column_name],
                state_weight=data_record[state_weight_column_name],
                on_the_way_weight=data_record[on_the_way_column_name],
            )
        )

    return data.update_field(scrap_state_data=tuple(result_list))


def parse_scrap_state_excel_file(contents: str) -> Tuple[ScrapParsedData, ...]:
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_state_file(excel_bytes)[0]


def parse_scrap_on_the_way_excel_file(contents: str) -> Tuple[ScrapParsedData, ...]:
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_on_the_way_file(excel_bytes)[0]


def parse_scrap_offers_excel_file(contents: str) -> Tuple[ScrapOfferParsedRecord, ...]:
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_excel_file(excel_bytes)[0]


def process_scrap_offers_data_after_parsing(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    parsed_scrap_offers_with_type = assign_scrap_type_to_scrap_offers_data(data.parsed_scrap_offers_data)
    new_data = data.update_field(parsed_scrap_offers_data=parsed_scrap_offers_with_type)

    unmapped_scrap_types = find_unmapped_scrap_types_from_parsed_data(new_data.parsed_scrap_offers_data)
    new_data = new_data.update_field(unmapped_scrap_types_from_scrap_offers=unmapped_scrap_types)

    if new_data.are_unmapped_types_from_scrap_offers_data():
        return new_data.reset_unmapped_scrap_types_from_scrap_offers_data()

    # assign supplier
    parsed_scrap_offers_with_supplier = assign_scrap_supplier_to_scrap_offer_data(
        parsed_data=new_data.parsed_scrap_offers_data
    )
    new_data = new_data.update_field(parsed_scrap_offers_data=parsed_scrap_offers_with_supplier)

    unmapped_scrap_suppliers = find_unmapped_scrap_suppliers_from_parsed_data(
        parsed_data=new_data.parsed_scrap_offers_data
    )
    new_data = new_data.update_field(unmapped_scrap_supplier_from_scrap_offers=unmapped_scrap_suppliers)

    if new_data.are_unmapped_scrap_supplier_from_scrap_offers():
        return new_data.reset_unmapped_scrap_suppliers()

    # find last price
    return fill_scrap_offers_data_from_parsed_data(new_data)


def find_unmapped_scrap_suppliers_from_parsed_data(
    parsed_data: Tuple[ScrapOfferParsedRecord, ...],
) -> Tuple[str, ...]:
    unmapped_scrap_suppliers = list()
    for parsed_row in parsed_data:
        scrap_supplier = parsed_row.supplier
        if not scrap_supplier:
            if parsed_row.input_supplier not in unmapped_scrap_suppliers:
                unmapped_scrap_suppliers.append(str(parsed_row.input_supplier))
    return tuple(unmapped_scrap_suppliers)


def fill_scrap_offers_data_from_parsed_data(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    scrap_offers_data = list()
    for parsed_row in data.parsed_scrap_offers_data:
        scrap_offers_data.append(
            ScrapOffer(
                scrap_type=parsed_row.scrap_type,
                zone=parsed_row.zone,
                weight=parsed_row.quantity,
                supplier=parsed_row.supplier,
                supplier_price=parsed_row.price,
                price_with_delta=None,
                recommendation=None,
                scrap_purchased=False,
                base_delta_rules=list(),
                added_by_user=False,
                note=parsed_row.note,
                override_price=None,
                uuid=str(uuid.uuid4()),
                generated_from=None,
                station=parsed_row.station,
            )
        )
    return data.update_field(scrap_offer_data=tuple(scrap_offers_data))


def get_scrap_type_mapping_from_scrap_type_mapping_row(
    scrap_type_mapping_row: ScrapTypeMappingTableRow,
) -> ScrapTypeMapping:
    return ScrapTypeMapping(
        input_scrap_type=scrap_type_mapping_row["input_scrap_type"],
        scrap_type=scrap_type_mapping_row["scrap_type"],
    )


def save_scrap_state_scrap_type_mappings_to_db(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    result = save_scrap_type_mappings_to_db(data.scrap_type_from_scrap_state_data)
    if result:
        return data.delete_scrap_state_scrap_type_mappings()
    return data.set_error_flag(error_value=True)


def save_scrap_type_mappings_to_db(scrap_type_mappings: ScrapTypeMappingData) -> bool:
    new_mappings = list()
    for scrap_type_map in scrap_type_mappings:
        new_scrap_type_mapping = SupportedScrapTypeMapping(
            scrap_type=str(scrap_type_map.scrap_type),
            input_scrap_type=scrap_type_map.input_scrap_type,
        )
        new_mappings.append(new_scrap_type_mapping)
    try:
        SupportedScrapTypeMapping.objects.bulk_create(new_mappings)
        return True
    except Exception:  # pylint: disable=broad-except
        return False


def get_production_plan_from_db(start_dt: date, num_of_weeks: int) -> Tuple[PlannedHeatWeek, ...]:
    ispv_db_conf = settings.ISPV_DB
    ispv_db = IspvHook(ispv_db_conf)
    return ispv_db.get_midterm_heat_plan(start_dt=start_dt, num_of_weeks=num_of_weeks)


def get_production_plan_data_with_names(planned_heat_week: Tuple[PlannedHeatWeek, ...]) -> ProductionPlanData:
    return tuple(
        get_production_plan_with_grade_name(planned_heat_week_item)
        for planned_heat_week_item in planned_heat_week
    )


def aggregate_production_plan(production_plan_data: ProductionPlanData) -> ProductionPlanData:
    data_frame = pd.DataFrame.from_records(
        [cattr.unstructure(pp) for pp in production_plan_data], columns=["scrap_grade_name", "scrap_amount"]
    )
    group_by_results = data_frame.groupby(by="scrap_grade_name").sum().to_dict()["scrap_amount"]
    aggregated_list = list()
    for key, value in group_by_results.items():
        aggregated_list.append(ProductionPlan(scrap_grade_name=key, scrap_amount=value))
    return tuple(aggregated_list)


def get_production_plan_with_grade_name(planned_heat_week: PlannedHeatWeek) -> ProductionPlan:
    scrap_grade_name = steel_grades.get_display_name(planned_heat_week.grade_id, planned_heat_week.monday)
    return ProductionPlan(
        scrap_grade_name=scrap_grade_name,
        scrap_amount=planned_heat_week.weight,
    )


def save_scrap_offers_scrap_type_mappings_to_db(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    result = save_scrap_type_mappings_to_db(data.scrap_type_from_scrap_offers_data)
    if result:
        return data.delete_scrap_offer_scrap_type_mappings()
    return data.set_error_flag(error_value=True)


def get_scrap_supplier_mapping_from_mapping_row(
    scrap_supplier_mapping_row: ScrapSupplierMappingTableRow,
) -> ScrapSupplierMapping:
    return ScrapSupplierMapping(
        input_scrap_supplier=scrap_supplier_mapping_row["input_scrap_supplier"],
        scrap_supplier=scrap_supplier_mapping_row["scrap_supplier"],
    )


def save_scrap_supplier_mappings_to_db(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    new_mappings = list()
    for scrap_supplier_mapping in data.scrap_supplier_mapping:
        scrap_supplier_name = scrap_supplier_mapping.scrap_supplier
        try:
            scrap_supplier_object = ScrapSupplierModel.objects.get(name=scrap_supplier_name)
        except Exception:  # pylint: disable=broad-except
            continue

        new_scrap_supplier_mapping = ScrapSupplierMappingModel(
            input_scrap_supplier=scrap_supplier_mapping.input_scrap_supplier,
            scrap_supplier=scrap_supplier_object,
        )
        new_mappings.append(new_scrap_supplier_mapping)
    try:
        ScrapSupplierMappingModel.objects.bulk_create(new_mappings)
        error = False
    except Exception:  # pylint: disable=broad-except
        error = False
    return data.update_field(error=error)


def get_scrap_offer_from_scrap_offer_table_row(scrap_offer_table_row: ScrapOfferTableRow) -> ScrapOffer:
    return ScrapOffer(
        scrap_type=scrap_offer_table_row["scrap_type"],
        zone=scrap_offer_table_row["zone"],
        weight=scrap_offer_table_row["weight"],
        supplier=scrap_offer_table_row["supplier"],
        supplier_price=scrap_offer_table_row["supplier_price"],
        price_with_delta=scrap_offer_table_row["price_with_delta"],
        recommendation=scrap_offer_table_row["recommendation"],
        scrap_purchased=scrap_offer_table_row["scrap_purchased"],
        base_delta_rules=list(),
        added_by_user=scrap_offer_table_row["added_by_user"],
        note=scrap_offer_table_row["note"],
        override_price=scrap_offer_table_row["override_price"],
        uuid=scrap_offer_table_row["uuid"],
        generated_from=scrap_offer_table_row["generated_from"],
        station=scrap_offer_table_row["station"],
    )


def compute_scrap_offers(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    new_data = find_base_delta_rules_for_offers(data)
    scrap_offers_with_price = compute_price_with_delta_for_scrap_offers(new_data)
    nr_of_scrap_offers_with_rules = get_nr_of_offers_with_rules(scrap_offers_with_price)
    return new_data.update_field(
        scrap_offer_data=scrap_offers_with_price,
        nr_of_scrap_offers_with_rules=nr_of_scrap_offers_with_rules,
    )


def find_base_delta_rules_for_offers(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    scrap_offer_list = list()
    for scrap_offer in data.scrap_offer_data:
        applied_base_delta_rules = list()
        for base_delta_rule_idx, base_delta_rule in enumerate(data.base_delta_rule_data):
            if check_scrap_offer_for_base_delta_rule(
                scrap_offer=scrap_offer, base_delta_rule=base_delta_rule
            ):
                applied_base_delta_rules.append(base_delta_rule_idx)
        scrap_offer_list.append(scrap_offer.update_field(base_delta_rules=applied_base_delta_rules))
    return data.update_field(scrap_offer_data=tuple(scrap_offer_list))


def compute_price_with_delta_for_scrap_offers(data: ScrapPurchaseViewModel) -> ScrapOfferData:
    updated_scrap_offer_data = list()
    for scrap_offer_data_item in data.scrap_offer_data:
        # purchase date can't be None in this phase (when prices with deltas are calculated)
        previous_price, previous_price_age = get_last_price_for_scrap_offer(
            scrap_offer_data_item, data.purchase_date.date()  # type: ignore
        )

        # if there isn't any corresponding offer from previous month, keep price with delta unset
        if previous_price is None or (previous_price_age is not None and previous_price_age > 1):
            updated_scrap_offer_data.append(scrap_offer_data_item.update_field(price_with_delta=None))
            continue

        base_delta = 0.0
        base_delta_rules = scrap_offer_data_item.base_delta_rules
        if len(base_delta_rules) > 0:
            highest_priority_rule_idx = min(base_delta_rules)
            base_delta_value = data.base_delta_rule_data[highest_priority_rule_idx].base_delta
            if base_delta_value is not None:
                base_delta = base_delta_value

        updated_scrap_offer_data.append(
            scrap_offer_data_item.update_field(price_with_delta=previous_price + base_delta)
        )
    return tuple(updated_scrap_offer_data)


def get_nr_of_offers_with_rules(scrap_offer_data: ScrapOfferData) -> int:
    scrap_offer_with_rules_nr = 0
    for scrap_offer in scrap_offer_data:
        if scrap_offer.base_delta_rules:
            scrap_offer_with_rules_nr = scrap_offer_with_rules_nr + 1
    return scrap_offer_with_rules_nr


def check_scrap_offer_for_base_delta_rule(scrap_offer: ScrapOffer, base_delta_rule: BaseDeltaRule):
    return evaluate_base_delta_rule(base_delta_rule=base_delta_rule, scrap_offer=scrap_offer)


def get_last_price_for_scrap_offer(
    scrap_offer: ScrapOffer, purchase_date: date
) -> Tuple[Optional[float], Optional[int]]:
    def month_diff(dta: date, dtb: date) -> int:
        diff = relativedelta(dta.replace(day=1), dtb.replace(day=1))
        return 12 * diff.years + diff.months

    scrap_type = scrap_offer.scrap_type
    zone = scrap_offer.zone
    if None in (scrap_type, zone):
        return None, None

    filter_kwargs = {"scrap_type": scrap_type, "zone": zone, "date__lt": purchase_date}

    if not is_zone_domestic(str(zone)):
        supplier = scrap_offer.supplier
        if supplier is None:
            return None, None
        filter_kwargs["supplier__name"] = supplier
    try:
        scrap_purchase_obj = ScrapPurchaseModel.objects.filter(**filter_kwargs).order_by("-date")[0]
        return scrap_purchase_obj.price, month_diff(purchase_date, scrap_purchase_obj.date)
    except IndexError:
        return None, None


def move_base_delta_rule_up(data: ScrapPurchaseViewModel, row_id: int) -> ScrapPurchaseViewModel:
    if row_id == 0:
        return data
    bdr_tuple = data.base_delta_rule_data
    reordered_tuple = (
        (bdr_tuple[0 : row_id - 1]) + (bdr_tuple[row_id], bdr_tuple[row_id - 1]) + (bdr_tuple[row_id + 1 :])
    )
    return data.update_field(base_delta_rule_data=reordered_tuple)


def move_base_delta_rule_down(data: ScrapPurchaseViewModel, row_id: int) -> ScrapPurchaseViewModel:
    bdr_tuple = data.base_delta_rule_data
    if row_id >= len(bdr_tuple) - 1:
        return data
    reordered_tuple = (
        (bdr_tuple[0:row_id]) + (bdr_tuple[row_id + 1], bdr_tuple[row_id]) + bdr_tuple[row_id + 2 :]
    )
    return data.update_field(base_delta_rule_data=reordered_tuple)


def update_scrap_offers_after_purchase(
    data: ScrapPurchaseViewModel,
) -> Tuple[ScrapPurchaseViewModel, Optional[str]]:
    assert data.scrap_offer_to_buy_idx is not None
    scrap_offer_to_buy_idx: int = data.scrap_offer_to_buy_idx
    scrap_offer_to_buy = data.scrap_offer_data[scrap_offer_to_buy_idx]

    scrap_offer_list = list(data.scrap_offer_data)

    updated_scrap_offer = scrap_offer_to_buy.update_field(scrap_purchased=True)

    scrap_offer_list[scrap_offer_to_buy_idx] = updated_scrap_offer

    assert data.scrap_offer_to_buy_amount is not None
    amount_to_buy = data.scrap_offer_to_buy_amount
    assert scrap_offer_to_buy.weight is not None
    scrap_offer_amount = scrap_offer_to_buy.weight

    amount_diff = scrap_offer_amount - amount_to_buy
    additional_scrap_offer_uuid = None
    if amount_diff != 0:
        if amount_diff > 0:
            new_weight = amount_diff
            new_scrap_purchased = False
        else:
            new_weight = abs(amount_diff)
            new_scrap_purchased = True

        additional_scrap_offer = ScrapOffer(
            scrap_type=scrap_offer_to_buy.scrap_type,
            zone=scrap_offer_to_buy.zone,
            weight=new_weight,
            supplier=scrap_offer_to_buy.supplier,
            supplier_price=scrap_offer_to_buy.supplier_price,
            price_with_delta=scrap_offer_to_buy.price_with_delta,
            recommendation=get_remainder_recommendation(
                new_weight, scrap_offer_to_buy.weight, scrap_offer_to_buy.recommendation or 0
            ),
            scrap_purchased=new_scrap_purchased,
            base_delta_rules=scrap_offer_to_buy.base_delta_rules,
            added_by_user=False,
            note=scrap_offer_to_buy.note,
            uuid=str(uuid.uuid4()),
            override_price=scrap_offer_to_buy.override_price,
            generated_from=scrap_offer_to_buy.uuid,
            station=scrap_offer_to_buy.station,
        )
        additional_scrap_offer_uuid = additional_scrap_offer.uuid
        scrap_offer_list.insert(scrap_offer_to_buy_idx + 1, additional_scrap_offer)

    return data.update_field(scrap_offer_data=tuple(scrap_offer_list)), additional_scrap_offer_uuid


def reset_edit_create_scrap_offer_data(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    return data.update_field(
        scrap_offer_to_edit_idx=None,
        scrap_offer_to_edit_scrap_type=None,
        scrap_offer_to_edit_zone=None,
        scrap_offer_to_edit_weight=None,
        scrap_offer_to_edit_supplier=None,
        scrap_offer_to_edit_price=None,
        scrap_offer_to_edit_override_price=None,
        scrap_offer_to_edit_note=None,
        scrap_offer_to_edit_station=None,
    )


def set_realized_scrap_offer_for_delete(
    data: ScrapPurchaseViewModel, global_row_id: int
) -> ScrapPurchaseViewModel:
    return data.update_field(realized_offer_to_delete_idx=global_row_id)


def adapt_scrap_offers_after_realized_offer_delete(
    data: ScrapPurchaseViewModel, scrap_offer_uuid_list: List[str]
) -> ScrapPurchaseViewModel:
    scrap_offer_result_list = list()
    for scrap_offer in data.scrap_offer_data:
        if scrap_offer.uuid in scrap_offer_uuid_list:
            if not scrap_offer.generated_from:
                scrap_offer_result_list.append(scrap_offer.update_field(scrap_purchased=False))
        else:
            scrap_offer_result_list.append(scrap_offer)
    return data.update_field(scrap_offer_data=tuple(scrap_offer_result_list))


def refresh_scrap_offers_recommendation(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    scrap_offers_data_list = list()

    if data.latest_computation is None:
        raise ScrapPurchaseError(
            f"Scrap Purchase Record {data.scrap_purchase_record_id}"
            f" - No computation has been triggered, yet"
        )

    if data.latest_computation.output_data is None:
        raise ScrapPurchaseError(
            f"Scrap Purchase Record {data.scrap_purchase_record_id}"
            f" - Either there is no computation or the latest one has not finished, yet"
        )

    recommendations = data.latest_computation.output_data.recommendations

    for scrap_offer in data.scrap_offer_data:
        offer_with_recommendation = scrap_offer.update_field(
            recommendation=recommendations.get(scrap_offer.uuid, 0)
        )
        scrap_offers_data_list.append(offer_with_recommendation)

    return data.update_field(scrap_offer_data=tuple(scrap_offers_data_list))


def save_realized_scrap_purchase_to_db(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    realized_scrap_offers = list()
    try:
        for scrap_offer in data.realized_scrap_offer_data:
            supplier_obj = ScrapSupplierModel.objects.get(name=scrap_offer.supplier)
            assert supplier_obj is not None
            assert scrap_offer.scrap_type is not None
            assert scrap_offer.zone is not None
            assert data.purchase_date is not None
            assert scrap_offer.weight is not None
            assert scrap_offer.price is not None
            realized_scrap_offers.append(
                ScrapPurchaseModel(
                    supplier=supplier_obj,
                    scrap_type=scrap_offer.scrap_type,
                    zone=str(scrap_offer.zone),
                    date=data.purchase_date,
                    quantity=scrap_offer.weight,
                    price=scrap_offer.price,
                    note=scrap_offer.note,
                )
            )
        ScrapPurchaseModel.objects.bulk_create(realized_scrap_offers)
    except Exception:  # pylint: disable=broad-except
        logger.error("Error during saving realized scrap offers to DB.")
        return data.update_field(error=True)
    return data


def set_purchase_record_as_finished(data: ScrapPurchaseViewModel) -> None:
    scrap_purchase_record_id = data.scrap_purchase_record_id
    scrap_purchase_record = ScrapPurchaseRecord.objects.get(pk=scrap_purchase_record_id)
    scrap_purchase_record.finished = True
    scrap_purchase_record.save()


def get_scrap_state_row(scrap_state: ScrapState) -> ScrapStateTableRow:
    return ScrapStateTableRow(
        scrap_type=scrap_state.scrap_type,
        state_weight=scrap_state.state_weight,
        on_the_way_weight=scrap_state.on_the_way_weight,
    )


def get_scrap_parsed_table_row(parsed_row: ScrapParsedData) -> Dict:
    return parsed_row.to_table_row()


def get_production_plan_mapping_row(production_plan: ProductionPlan) -> ProductionPlanTableRow:
    return ProductionPlanTableRow(
        scrap_grade_name=production_plan.scrap_grade_name,
        scrap_amount=convert_kilograms_to_tons(production_plan.scrap_amount),
    )


def get_scrap_offer_table_row(scrap_offer_item: ScrapOffer) -> ScrapOfferTableRow:
    return ScrapOfferTableRow(
        scrap_type=scrap_offer_item.scrap_type,
        zone=scrap_offer_item.zone,
        weight=scrap_offer_item.weight,
        supplier=scrap_offer_item.supplier,
        supplier_price=scrap_offer_item.supplier_price,
        price_with_delta=scrap_offer_item.price_with_delta,
        recommendation=scrap_offer_item.recommendation,
        scrap_purchased=scrap_offer_item.scrap_purchased,
        added_by_user=scrap_offer_item.added_by_user,
        note=scrap_offer_item.note,
        base_delta_rules=",".join(str(el + 1) for el in scrap_offer_item.base_delta_rules),
        purchase="-" if scrap_offer_item.scrap_purchased else "Kúpiť",
        show_price_plot="📈",
        edit_offer="🔒" if scrap_offer_item.scrap_purchased else "\u270E",
        override_price=scrap_offer_item.override_price,
        uuid=scrap_offer_item.uuid,
        generated_from=scrap_offer_item.generated_from,
        generated="↖️" if scrap_offer_item.generated_from else None,
        station=scrap_offer_item.station,
    )


def get_base_delta_rule_row_from_base_delta_rule(
    base_delta_rule: BaseDeltaRule, row_idx: int
) -> BaseDeltaRuleTableRow:
    return BaseDeltaRuleTableRow(
        scrap_type=base_delta_rule.scrap_type,
        zone=base_delta_rule.zone,
        supplier=base_delta_rule.supplier,
        priority=row_idx + 1,
        move_up="\u2191",
        move_down="\u2193",
        base_delta=base_delta_rule.base_delta,
    )


def compute_overall_purchase_table(data: ScrapPurchaseViewModel) -> OverallPurchaseTableData:
    if len(data.realized_scrap_offer_data) == 0:
        return list()

    price_key = "price"
    weight_key = "weight"

    computation_data: Dict = dict()
    for realized_scrap_offer in data.realized_scrap_offer_data:
        scrap_type = realized_scrap_offer.scrap_type
        if scrap_type not in computation_data:
            computation_data[scrap_type] = {
                price_key: list(),
                weight_key: list(),
            }
        computation_data[scrap_type][price_key].append(realized_scrap_offer.price)
        computation_data[scrap_type][weight_key].append(realized_scrap_offer.weight)

    result_data: OverallPurchaseTableData = list()
    overall_weight = list()
    overall_price = list()
    for key, value in computation_data.items():
        overall_weight.extend(value[weight_key])
        overall_price.extend(value[price_key])

        result_data.append(
            OverallPurchaseTableRow(
                scrap_type=key,
                quantity=sum(value[weight_key]),
                price=numpy.average(value[price_key], weights=value[weight_key]),
            )
        )

    result_data.append(
        OverallPurchaseTableRow(
            scrap_type="Celkovo",
            quantity=sum(overall_weight),
            price=numpy.average(overall_price, weights=overall_weight),
        )
    )

    return result_data


def get_scrap_type_mapping_row(scrap_type_mapping: ScrapTypeMapping) -> ScrapTypeMappingTableRow:
    return ScrapTypeMappingTableRow(
        input_scrap_type=scrap_type_mapping.input_scrap_type, scrap_type=scrap_type_mapping.scrap_type
    )


def get_scrap_supplier_mapping_row(
    scrap_supplier_mapping: ScrapSupplierMapping,
) -> ScrapSupplierMappingTableRow:
    return ScrapSupplierMappingTableRow(
        input_scrap_supplier=scrap_supplier_mapping.input_scrap_supplier,
        scrap_supplier=scrap_supplier_mapping.scrap_supplier,
    )


def get_supplier_dropdown_values(scrap_supplier_names: Tuple[str, ...]) -> List[Dict]:
    return [
        {"label": scrap_supplier_name, "value": scrap_supplier_name}
        for scrap_supplier_name in scrap_supplier_names
    ]


def get_scrap_offer_info_text(scrap_offer: ScrapOffer) -> str:
    return (
        f"{scrap_offer.scrap_type} "
        f"{scrap_offer.zone} "
        f"{scrap_offer.weight} "
        f"{scrap_offer.supplier_price} "
        f"{scrap_offer.override_price} "
        f"{scrap_offer.note}"
    )


def get_scrap_supplier_names_from_db() -> Tuple[str, ...]:
    return tuple(scrap_supplier.name for scrap_supplier in ScrapSupplierModel.objects.all())


def get_default_datetime_from_date(input_date: Optional[date]) -> Optional[datetime]:
    if not input_date:
        return None
    return datetime(
        year=input_date.year,
        month=input_date.month,
        day=input_date.day,
    )


def assign_wizard_confirm_button_values(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    confirm_step_1_value = data.is_wizard_step_1_fulfilled()
    confirm_step_2_value = data.is_wizard_step_2_fulfilled()
    confirm_step_3_value = data.is_wizard_step_3_fulfilled()
    confirm_step_4_value = data.is_wizard_step_4_fulfilled()
    return data.update_field(
        wizard_step_1_confirmed=confirm_step_1_value,
        wizard_step_2_confirmed=confirm_step_2_value,
        wizard_step_3_confirmed=confirm_step_3_value,
        wizard_step_4_confirmed=confirm_step_4_value,
    )


def compute_data_after_load(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    if len(data.scrap_offer_data) == 0:
        data = process_scrap_offers_data_after_parsing(data)
    if len(data.scrap_state_data) == 0:
        data = process_scrap_state_data_after_parsing(data)
    if data.scrap_offer_data:
        data = compute_scrap_offers(data)
    return data


def update_data_from_db(data: ScrapPurchaseViewModel) -> ScrapPurchaseViewModel:
    scrap_purchase_record = ScrapPurchaseRecord.objects.get(pk=data.scrap_purchase_record_id)
    loaded_data = data.load_display_data(scrap_purchase_record.current_data)
    computed_data = compute_data_after_load(loaded_data)
    return assign_wizard_confirm_button_values(computed_data)


def save_current_data(data: ScrapPurchaseViewModel) -> None:
    ScrapPurchaseRecord.objects.filter(pk=data.scrap_purchase_record_id).update(
        name=data.scrap_purchase_title,
        current_data=data.create_display_data(),
        updated_at=datetime.utcnow(),
        purchase_date=data.purchase_date,
    )


def load_initial_data(scrap_purchase_record_id: int, username: str) -> ScrapPurchaseViewModel:
    scrap_purchase_record = ScrapPurchaseRecord.objects.get(pk=scrap_purchase_record_id)
    user_in_control = scrap_purchase_record.user_in_control
    user_in_control_name = user_in_control.username if user_in_control is not None else ""
    base_data = ScrapPurchaseViewModel(
        user=username,
        user_in_control=user_in_control_name,
        authorized_users=tuple([user.username for user in scrap_purchase_record.authorized_users.all()]),
        control_gained=False,
        control_lost=False,
        purchase_date=get_default_datetime_from_date(scrap_purchase_record.purchase_date),
        scrap_purchase_record_id=scrap_purchase_record.id,
        scrap_purchase_title=scrap_purchase_record.name,
        debug=scrap_purchase_record.debug,
        scrap_state_filename="",
        scrap_on_the_way_filename="",
        scrap_state_data=tuple(),
        error=False,
        production_plan_date=None,
        production_plan_nr_of_weeks=4,
        user_defined_expected_steel_production=None,
        production_plan_data=tuple(),
        parsed_scrap_state_data=tuple(),
        parsed_scrap_on_the_way_data=tuple(),
        parsed_scrap_state_is_open=False,
        parsed_scrap_on_the_way_is_open=False,
        parsed_scrap_offers_is_open=False,
        scrap_stock_objective=None,
        mean_scrap_weight=MEAN_SCRAP_WEIGHT,
        scrap_offer_data=tuple(),
        realized_scrap_offer_data=tuple(),
        parsed_scrap_offers_data=tuple(),
        scrap_offers_filename="",
        unmapped_scrap_types_from_scrap_state=tuple(),
        unmapped_scrap_types_from_scrap_offers=tuple(),
        scrap_type_from_scrap_state_data=tuple(),
        scrap_type_from_scrap_offers_data=tuple(),
        unmapped_scrap_supplier_from_scrap_offers=tuple(),
        scrap_supplier_mapping=tuple(),
        base_delta_rule_data=tuple(),
        scrap_offer_to_plot=None,
        scrap_offer_to_buy_price=0.0,
        scrap_offer_to_buy_amount=0.0,
        scrap_supplier_names=get_scrap_supplier_names_from_db(),
        scrap_offer_to_buy_idx=None,
        scrap_offer_to_edit_idx=None,
        scrap_offers_table_derived_indices=list(),
        scrap_offer_to_edit_scrap_type=None,
        scrap_offer_to_edit_zone=None,
        scrap_offer_to_edit_weight=None,
        scrap_offer_to_edit_supplier=None,
        scrap_offer_to_edit_price=None,
        scrap_offer_to_edit_override_price=None,
        scrap_offer_to_edit_note=None,
        scrap_offer_to_edit_station=None,
        realized_offer_to_delete_idx=None,
        wizard_step_1_confirmed=False,
        wizard_step_2_confirmed=False,
        wizard_step_3_confirmed=False,
        wizard_step_4_confirmed=False,
        price_plot_data=PricePlotData(scrap_type=None, price_plot_values=OrderedDict()),
        nr_of_scrap_offers_with_rules=0,
        computation_start_clicked=False,
        finish_scrap_purchase_is_open=False,
        finish_scrap_purchase_in_progress=False,
        export_slabs_weight=0,
    )
    loaded_data = base_data.load_display_data(scrap_purchase_record.current_data)
    computed_data = compute_data_after_load(loaded_data)
    return assign_wizard_confirm_button_values(computed_data)
