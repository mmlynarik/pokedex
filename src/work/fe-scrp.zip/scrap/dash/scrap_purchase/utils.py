DATETIME_CONVERSION_STRING = "%Y-%m-%d"
DISPLAY_BLOCK_STYLE = {"display": "block"}
DISPLAY_NONE_STYLE = {"display": "none"}
