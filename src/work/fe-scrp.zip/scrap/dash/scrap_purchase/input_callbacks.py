import logging
import uuid
from datetime import datetime
from typing import Dict, List, Optional
from django.db import transaction
from django.contrib.auth.models import User

from scrap_core.utils import convert_tons_to_kilograms

from ..components.scrap_purchase_components import (
    ScrapPurchaseViewModel,
    ScrapTypeMappingTableData,
    ScrapSupplierMappingTableData,
    ScrapOfferTableData,
    ScrapOffer,
)

from ...models import BaseDeltaRule, RealizedScrapOffer, ScrapType, ScrapPurchaseRecord

from .utils import DATETIME_CONVERSION_STRING

from .internal import (
    save_state_after_input,
    get_global_scrap_offer_idx,
    show_price_plot,
    open_buy_scrap_modal_window,
    open_edit_create_offer_modal_window,
    process_scrap_state_data_after_parsing,
    parse_scrap_state_excel_file,
    parse_scrap_on_the_way_excel_file,
    parse_scrap_offers_excel_file,
    process_scrap_offers_data_after_parsing,
    get_scrap_type_mapping_from_scrap_type_mapping_row,
    save_scrap_state_scrap_type_mappings_to_db,
    get_production_plan_from_db,
    get_production_plan_data_with_names,
    aggregate_production_plan,
    save_scrap_offers_scrap_type_mappings_to_db,
    get_scrap_supplier_mapping_from_mapping_row,
    save_scrap_supplier_mappings_to_db,
    get_scrap_offer_from_scrap_offer_table_row,
    compute_scrap_offers,
    move_base_delta_rule_up,
    move_base_delta_rule_down,
    update_scrap_offers_after_purchase,
    reset_edit_create_scrap_offer_data,
    set_realized_scrap_offer_for_delete,
    adapt_scrap_offers_after_realized_offer_delete,
    refresh_scrap_offers_recommendation,
    save_realized_scrap_purchase_to_db,
    set_purchase_record_as_finished,
    update_data_from_db,
)


# region COMMON INPUT FIELDS
from ...models import (
    ScrapPurchaseOptimizationInput,
    ScrapPurchaseOptimizationResult,
    ScrapPurchaseOptimizationDisplayData,
)
from ...tasks import calculate_optimal_scrap_purchase

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def show_hide_scrap_state_parsed_table(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if not n_clicks:
        return data
    new_value = not data.parsed_scrap_state_is_open
    return data.update_field(parsed_scrap_state_is_open=new_value)


def show_hide_scrap_on_the_way_parsed_table(
    data: ScrapPurchaseViewModel, n_clicks: int
) -> ScrapPurchaseViewModel:
    if not n_clicks:
        return data
    new_value = not data.parsed_scrap_on_the_way_is_open
    return data.update_field(parsed_scrap_on_the_way_is_open=new_value)


def show_hide_scrap_offers_parsed_table(
    data: ScrapPurchaseViewModel, n_clicks: int
) -> ScrapPurchaseViewModel:
    if not n_clicks:
        return data
    new_value = not data.parsed_scrap_offers_is_open
    return data.update_field(parsed_scrap_offers_is_open=new_value)


# endregion


# region READ ONLY INPUT FIELDS
def click_on_scrap_offers_table(data: ScrapPurchaseViewModel, active_cell: Dict) -> ScrapPurchaseViewModel:
    if not active_cell:
        return data
    clicked_column_id = active_cell.get("column_id", None)
    clicked_row_id = active_cell.get("row", None)
    if clicked_row_id is not None:
        global_row_id = get_global_scrap_offer_idx(data, clicked_row_id)
        if clicked_column_id == "show_price_plot":
            return show_price_plot(data, global_row_id)
        if clicked_column_id == "purchase":
            return open_buy_scrap_modal_window(data, global_row_id)
        if clicked_column_id == "edit_offer":
            return open_edit_create_offer_modal_window(data, global_row_id)
    return data


def scrap_offers_table_derived_viewport_indices(
    data: ScrapPurchaseViewModel, derived_viewport_indices: List[int]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offers_table_derived_indices=derived_viewport_indices)


def hide_price_plot_button_click(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(scrap_offer_to_plot=None)


# endregion


# region EDIT APP INPUT FIELDS
@save_state_after_input
def upload_scrap_state_filename(data: ScrapPurchaseViewModel, filename: str) -> ScrapPurchaseViewModel:
    new_data = data.update_field(scrap_state_filename=filename)
    return new_data


@save_state_after_input
def upload_scrap_state_content(data: ScrapPurchaseViewModel, contents: str) -> ScrapPurchaseViewModel:
    if not contents:
        return data
    parsed_scrap_state_data = parse_scrap_state_excel_file(contents)
    new_data = data.update_field(parsed_scrap_state_data=parsed_scrap_state_data)
    return process_scrap_state_data_after_parsing(new_data)


@save_state_after_input
def upload_scrap_on_the_way_filename(data: ScrapPurchaseViewModel, filename: str) -> ScrapPurchaseViewModel:
    new_data = data.update_field(scrap_on_the_way_filename=filename)
    return new_data


@save_state_after_input
def upload_scrap_on_the_way_content(data: ScrapPurchaseViewModel, contents: str) -> ScrapPurchaseViewModel:
    if not contents:
        return data
    scrap_on_the_way_parsed_data = parse_scrap_on_the_way_excel_file(contents)
    new_data = data.update_field(parsed_scrap_on_the_way_data=scrap_on_the_way_parsed_data)
    return process_scrap_state_data_after_parsing(new_data)


@save_state_after_input
def upload_scrap_offers_filename(data: ScrapPurchaseViewModel, filename: str) -> ScrapPurchaseViewModel:
    new_data = data.update_field(scrap_offers_filename=filename)
    return new_data


@save_state_after_input
def upload_scrap_offers_content(data: ScrapPurchaseViewModel, contents: str) -> ScrapPurchaseViewModel:
    if not contents:
        return data
    scrap_offers_parsed_data = parse_scrap_offers_excel_file(contents)
    new_data = data.update_field(parsed_scrap_offers_data=scrap_offers_parsed_data)
    return process_scrap_offers_data_after_parsing(new_data)


def unmapped_scrap_state_mapping_table_data_update(
    data: ScrapPurchaseViewModel, table_data: ScrapTypeMappingTableData
) -> ScrapPurchaseViewModel:
    new_scrap_type_mapping_data = [
        get_scrap_type_mapping_from_scrap_type_mapping_row(table_row) for table_row in table_data
    ]
    return data.update_field(scrap_type_from_scrap_state_data=tuple(new_scrap_type_mapping_data))


def save_scrap_state_scrap_types_mappings(
    data: ScrapPurchaseViewModel, n_clicks: int
) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    new_data = save_scrap_state_scrap_type_mappings_to_db(data)
    if not new_data.error:
        return process_scrap_state_data_after_parsing(new_data)
    return new_data


@save_state_after_input
def production_plan_date_selected(
    data: ScrapPurchaseViewModel, selected_date: Optional[str]
) -> ScrapPurchaseViewModel:
    if not selected_date:
        selected_date = None
        new_data = data.update_field(
            production_plan_date=selected_date,
            production_plan_data=tuple(),
        )
        return new_data
    new_selected_date = datetime.strptime(selected_date, DATETIME_CONVERSION_STRING)
    return data.update_field(production_plan_date=new_selected_date)


@save_state_after_input
def load_production_plan(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks and data.production_plan_date and data.production_plan_nr_of_weeks:
        planned_heat_week = get_production_plan_from_db(
            start_dt=data.production_plan_date.date(), num_of_weeks=data.production_plan_nr_of_weeks
        )
        production_plan = get_production_plan_data_with_names(planned_heat_week)
        aggregated_production_plan = aggregate_production_plan(production_plan)
        new_data = data.update_field(production_plan_data=aggregated_production_plan)
        return new_data
    return data


def unmapped_scrap_offers_mapping_table_data_update(
    data: ScrapPurchaseViewModel, table_data: ScrapTypeMappingTableData
) -> ScrapPurchaseViewModel:
    new_scrap_type_mapping_data = [
        get_scrap_type_mapping_from_scrap_type_mapping_row(table_row) for table_row in table_data
    ]
    return data.update_field(scrap_type_from_scrap_offers_data=tuple(new_scrap_type_mapping_data))


def save_scrap_offers_scrap_types_mappings(
    data: ScrapPurchaseViewModel, n_clicks: int
) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    new_data = save_scrap_offers_scrap_type_mappings_to_db(data)
    if not new_data.error:
        return process_scrap_offers_data_after_parsing(new_data)
    return new_data


def unmapped_scrap_supplier_mapping_table_data_update(
    data: ScrapPurchaseViewModel, table_data: ScrapSupplierMappingTableData
) -> ScrapPurchaseViewModel:
    new_scrap_supplier_mapping_data = [
        get_scrap_supplier_mapping_from_mapping_row(table_row) for table_row in table_data
    ]
    return data.update_field(scrap_supplier_mapping=tuple(new_scrap_supplier_mapping_data))


def save_scrap_supplier_mapping(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    new_data = save_scrap_supplier_mappings_to_db(data)
    if not new_data.error:
        return process_scrap_offers_data_after_parsing(new_data)
    return new_data


@save_state_after_input
def set_scrap_stock_objective(data: ScrapPurchaseViewModel, value: Optional[int]) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_stock_objective=value)


@save_state_after_input
def set_mean_scrap_weight(data: ScrapPurchaseViewModel, value: Optional[int]) -> ScrapPurchaseViewModel:
    return data if value is None else data.update_field(mean_scrap_weight=convert_tons_to_kilograms(value))


@save_state_after_input
def set_expected_steel_production_weight(
    data: ScrapPurchaseViewModel, value: Optional[int]
) -> ScrapPurchaseViewModel:
    new_value = convert_tons_to_kilograms(value) if value is not None else None
    return data.update_field(user_defined_expected_steel_production=new_value)


@save_state_after_input
def update_scrap_purchase_title(data: ScrapPurchaseViewModel, value: str) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_purchase_title=value)


@save_state_after_input
def add_new_scrap_offer_row(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    scrap_offer_list = list(data.scrap_offer_data)
    scrap_offer_list.append(
        ScrapOffer(
            scrap_type=None,
            zone=None,
            weight=None,
            supplier=None,
            supplier_price=None,
            price_with_delta=None,
            recommendation=None,
            scrap_purchased=False,
            base_delta_rules=list(),
            added_by_user=False,
            note=None,
            uuid=str(uuid.uuid4()),
            override_price=None,
            generated_from=None,
        )
    )
    new_scrap_offer_id = len(scrap_offer_list) - 1
    return data.update_field(
        scrap_offer_data=tuple(scrap_offer_list),
        scrap_offer_to_edit_idx=new_scrap_offer_id,
    )


# TODO: is this method even triggered?
@save_state_after_input
def user_update_scrap_offer_table(
    data: ScrapPurchaseViewModel, table_data: ScrapOfferTableData
) -> ScrapPurchaseViewModel:
    updated_scrap_offer = [get_scrap_offer_from_scrap_offer_table_row(table_row) for table_row in table_data]
    new_data = data.update_field(scrap_offer_data=tuple(updated_scrap_offer))
    return compute_scrap_offers(new_data)


@save_state_after_input
def add_new_base_delta_rule(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    new_base_delta_rule = BaseDeltaRule(
        scrap_type=None,
        zone=None,
        supplier=None,
        base_delta=None,
    )
    return data.update_field(base_delta_rule_data=data.base_delta_rule_data + (new_base_delta_rule,))


@save_state_after_input
def user_update_base_delta_rules_table(
    data: ScrapPurchaseViewModel, table_data: List[Dict]
) -> ScrapPurchaseViewModel:
    def safe_float(value: Optional[str]) -> Optional[float]:
        """
        If user writes down value and deletes it afterwards, empty string is the result,
        which may be accidentally stored in database. Since it can't be converted back to float,
        app ends with 500 Server Error.
        """
        if value is None:
            return None

        try:
            return float(value)
        except ValueError:
            return None

    updated_delta_rules = [
        BaseDeltaRule(
            scrap_type=table_row["scrap_type"],
            zone=table_row["zone"],
            supplier=table_row["supplier"],
            base_delta=safe_float(table_row["base_delta"]),
        )
        for table_row in table_data
    ]
    new_data = data.update_field(base_delta_rule_data=tuple(updated_delta_rules))
    return compute_scrap_offers(new_data)


@save_state_after_input
def click_on_base_delta_rule_table(data: ScrapPurchaseViewModel, active_cell: Dict) -> ScrapPurchaseViewModel:
    if not active_cell:
        return data
    clicked_column_id = active_cell.get("column_id", None)
    clicked_row_id = active_cell.get("row", 0)
    if clicked_column_id == "move_up":
        data = move_base_delta_rule_up(data, clicked_row_id)
    if clicked_column_id == "move_down":
        data = move_base_delta_rule_down(data, clicked_row_id)
    return compute_scrap_offers(data)


def sync_modal_state_with_model(data: ScrapPurchaseViewModel, is_open: bool) -> ScrapPurchaseViewModel:
    if not is_open:
        return data.update_field(
            scrap_offer_to_buy_idx=None,
            scrap_offer_to_buy_price=0.0,
            scrap_offer_to_buy_amount=0.0,
        )
    return data


@save_state_after_input
def confirm_scrap_purchase(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data

    scrap_offer_to_buy_idx = data.scrap_offer_to_buy_idx
    if scrap_offer_to_buy_idx is None:
        return data

    scrap_offer_to_buy = data.scrap_offer_data[scrap_offer_to_buy_idx]
    if not (scrap_offer_to_buy and data.scrap_offer_to_buy_price and data.scrap_offer_to_buy_amount):
        return data

    data, additional_scrap_offer_uuid = update_scrap_offers_after_purchase(data)

    scrap_offer_uuid_list = [scrap_offer_to_buy.uuid]
    if additional_scrap_offer_uuid:
        scrap_offer_uuid_list.append(additional_scrap_offer_uuid)

    realized_scrap_offer = RealizedScrapOffer(
        scrap_type=scrap_offer_to_buy.scrap_type,
        zone=scrap_offer_to_buy.zone,
        weight=data.scrap_offer_to_buy_amount,
        price=data.scrap_offer_to_buy_price,
        supplier=scrap_offer_to_buy.supplier,
        note=scrap_offer_to_buy.note,
        scrap_offer_uuid_list=scrap_offer_uuid_list,
    )

    return data.update_field(
        realized_scrap_offer_data=data.realized_scrap_offer_data + (realized_scrap_offer,),
        scrap_offer_to_buy_idx=None,
        scrap_offer_to_buy_price=0.0,
        scrap_offer_to_buy_amount=0.0,
    )


def set_buy_scrap_modal_price(data: ScrapPurchaseViewModel, value: Optional[float]) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_buy_price=value)


def set_buy_scrap_modal_amount(
    data: ScrapPurchaseViewModel, value: Optional[float]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_buy_amount=value)


@save_state_after_input
def set_purchase_date(data: ScrapPurchaseViewModel, selected_date: Optional[str]) -> ScrapPurchaseViewModel:
    if not selected_date:
        new_date = None
    else:
        new_date = datetime.strptime(selected_date, DATETIME_CONVERSION_STRING).replace(day=1)
    return data.update_field(purchase_date=new_date)


def sync_create_edit_offer_modal_state_with_model(
    data: ScrapPurchaseViewModel, is_open: bool
) -> ScrapPurchaseViewModel:
    if not is_open:
        return reset_edit_create_scrap_offer_data(data)
    return data


@save_state_after_input
def delete_scrap_offer_click(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0 or data.scrap_offer_to_edit_idx is None:
        return data
    scrap_offer_data_list = list(data.scrap_offer_data)
    del scrap_offer_data_list[int(data.scrap_offer_to_edit_idx)]
    new_data = data.update_field(
        scrap_offer_data=tuple(scrap_offer_data_list),
    )
    new_data = reset_edit_create_scrap_offer_data(new_data)
    return compute_scrap_offers(new_data)


@save_state_after_input
def create_update_offer_confirm_click(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0 or data.scrap_offer_to_edit_idx is None:
        return data
    scrap_offer_to_edit_idx = int(data.scrap_offer_to_edit_idx)
    scrap_offer_to_edit = data.scrap_offer_data[scrap_offer_to_edit_idx]
    updated_scrap_offer = scrap_offer_to_edit.update_field(
        scrap_type=data.scrap_offer_to_edit_scrap_type,
        zone=data.scrap_offer_to_edit_zone,
        weight=data.scrap_offer_to_edit_weight,
        supplier=data.scrap_offer_to_edit_supplier,
        supplier_price=data.scrap_offer_to_edit_price,
        override_price=data.scrap_offer_to_edit_override_price,
        note=data.scrap_offer_to_edit_note,
        station=data.scrap_offer_to_edit_station,
    )
    scrap_offer_data_list = list(data.scrap_offer_data)
    scrap_offer_data_list[scrap_offer_to_edit_idx] = updated_scrap_offer
    new_data = data.update_field(
        scrap_offer_data=tuple(scrap_offer_data_list),
    )
    new_data = reset_edit_create_scrap_offer_data(new_data)
    return compute_scrap_offers(new_data)


def set_create_edit_offer_scrap_type(
    data: ScrapPurchaseViewModel, value: ScrapType
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_scrap_type=value)


def set_create_edit_offer_zone(data: ScrapPurchaseViewModel, value: Optional[str]) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_zone=value)


def set_create_edit_offer_weight(
    data: ScrapPurchaseViewModel, value: Optional[float]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_weight=value)


def set_create_edit_offer_supplier(
    data: ScrapPurchaseViewModel, value: Optional[str]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_supplier=value)


def set_create_edit_offer_price(
    data: ScrapPurchaseViewModel, value: Optional[float]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_price=value)


def set_create_edit_offer_override_price(
    data: ScrapPurchaseViewModel, value: Optional[float]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_override_price=value)


def set_create_edit_offer_note(data: ScrapPurchaseViewModel, value: Optional[str]) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_note=value)


def set_create_edit_offer_station(
    data: ScrapPurchaseViewModel, value: Optional[str]
) -> ScrapPurchaseViewModel:
    return data.update_field(scrap_offer_to_edit_station=value)


def click_on_realized_scrap_offers_table(
    data: ScrapPurchaseViewModel, active_cell: Dict
) -> ScrapPurchaseViewModel:
    if not active_cell:
        return data
    clicked_column_id = active_cell.get("column_id", None)
    clicked_row_id = active_cell.get("row", None)
    if clicked_row_id is not None:
        if clicked_column_id == "delete":
            return set_realized_scrap_offer_for_delete(data, clicked_row_id)
    return data


def sync_delete_realized_offer_modal_state_with_model(
    data: ScrapPurchaseViewModel, is_open: bool
) -> ScrapPurchaseViewModel:
    if not is_open:
        return data.update_field(
            realized_offer_to_delete_idx=None,
        )
    return data


@save_state_after_input
def confirm_delete_realized_scrap_offer(
    data: ScrapPurchaseViewModel, n_clicks: int
) -> ScrapPurchaseViewModel:
    if n_clicks == 0 or data.realized_offer_to_delete_idx is None:
        return data
    realized_offer_to_delete_idx = int(data.realized_offer_to_delete_idx)
    realized_scrap_offers = list(data.realized_scrap_offer_data)
    data = adapt_scrap_offers_after_realized_offer_delete(
        data, realized_scrap_offers[realized_offer_to_delete_idx].scrap_offer_uuid_list
    )
    del realized_scrap_offers[realized_offer_to_delete_idx]
    return data.update_field(
        realized_scrap_offer_data=tuple(realized_scrap_offers),
        realized_offer_to_delete_idx=None,
    )


@save_state_after_input
def set_production_plan_nr_of_weeks(
    data: ScrapPurchaseViewModel, value: Optional[int]
) -> ScrapPurchaseViewModel:
    return data if value is None else data.update_field(production_plan_nr_of_weeks=value)


def click_on_confirm_step_1(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_1_confirmed=True)


def click_on_confirm_step_2(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_2_confirmed=True)


def click_on_confirm_step_3(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_3_confirmed=True)


def click_on_confirm_step_4(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_4_confirmed=True)


def click_on_back_from_step_2(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_1_confirmed=False)


def click_on_back_from_step_3(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_2_confirmed=False)


def click_on_back_from_step_4(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(wizard_step_3_confirmed=False)


@save_state_after_input
def click_on_run_computation_button(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:

    if n_clicks == 0:
        return data

    new_data = data.update_field(computation_start_clicked=True)
    optimization_settings = ScrapPurchaseRecord.objects.get(
        pk=data.scrap_purchase_record_id
    ).optimization_settings

    # TODO validate sum(all scrap) vs sum(production_plan) + scrap_stock objective in kgs
    #   very likely we would need to validate "corrected" production plan
    #   - see `get_corrected_production_plan` function
    # TODO validate that all offers have (nonzero) weight and price defined

    optimization_input = ScrapPurchaseOptimizationInput(
        optimization_settings,
        new_data.scrap_state_data,
        new_data.scrap_offer_data,
        new_data.realized_scrap_offer_data,
        new_data.production_plan_data,
        # Following attributes are optional in `ScrapPurchaseViewModel`,
        # because they are available in later steps of input data creation wizard only.
        # However, they are required in optimization. Since optimization (i.e. button related
        # to this callback) is available only after all steps in creation wizard are taken,
        # we are safe (?) to ignore type checking here.
        new_data.production_plan_date.date(),  # type: ignore
        new_data.production_plan_nr_of_weeks,  # type: ignore
        new_data.expected_steel_production,
        new_data.scrap_stock_objective,  # type: ignore
        new_data.mean_scrap_weight,
    )

    optimization_result = ScrapPurchaseOptimizationResult(input_data=optimization_input)
    optimization_result.save()
    log.info(f"New scrap purchase optimization with ID {optimization_result.pk} created")

    calculate_optimal_scrap_purchase.send(optimization_result.pk)

    optimization_display_data = ScrapPurchaseOptimizationDisplayData(optimization_result.pk)
    new_data = new_data.update_field(computations=new_data.computations + (optimization_display_data,))

    return new_data


@save_state_after_input
def computation_refresh_data(data: ScrapPurchaseViewModel, _: int) -> ScrapPurchaseViewModel:
    latest_computation = data.latest_computation
    if latest_computation is not None:
        updated_computation = latest_computation.update()
        new_data = data.update_field(computations=data.computations[:-1] + (updated_computation,))

        if new_data.computation_start_clicked and new_data.latest_computation.is_finished():  # type: ignore
            new_data = new_data.update_field(computation_start_clicked=False)
            new_data = refresh_scrap_offers_recommendation(new_data)
            log.info(
                f"Scrap offer recommendations refreshed "  # type: ignore
                f"according to optimization {new_data.latest_computation.optimization_id}"
            )

        return new_data

    return data


def click_on_finish_purchase_button(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    return data.update_field(finish_scrap_purchase_is_open=True)


def sync_finish_purchase_modal_is_open(data: ScrapPurchaseViewModel, is_open: bool) -> ScrapPurchaseViewModel:
    if not is_open:
        return data.update_field(finish_scrap_purchase_is_open=False)
    return data


def click_on_confirm_finish_purchase(data: ScrapPurchaseViewModel, n_clicks: int) -> ScrapPurchaseViewModel:
    if n_clicks == 0:
        return data
    new_data = save_realized_scrap_purchase_to_db(data)
    if new_data.error:
        return new_data
    set_purchase_record_as_finished(new_data)
    return data.update_field(finish_scrap_purchase_in_progress=True)


# endregion


# region READ ONLY APP SPECIFIC INPUT
def readonly_reload(data: ScrapPurchaseViewModel, _: int) -> ScrapPurchaseViewModel:
    return update_data_from_db(data)


def change_control(data: ScrapPurchaseViewModel, _: int) -> ScrapPurchaseViewModel:
    with transaction.atomic():
        user = User.objects.get(username=data.user)
        ScrapPurchaseRecord.objects.select_for_update(nowait=True, of=("self", "user_in_control")).filter(
            pk=data.scrap_purchase_record_id
        ).update(user_in_control=user)

    return data.update_field(control_gained=True)


# endregion
