from datetime import datetime
import logging
from typing import Optional, List, Dict, Any, Union, Container

import cattr
from dash import html
from django.urls import reverse
import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from scrap_core import (
    ScrapType,
    PRIME_GROUP_NAME,
    CUT_GROUP_NAME,
    PRIME_SCRAP,
    CUT_SCRAP,
)
from scrap_core.utils import convert_kilograms_to_tons

from ..components.scrap_purchase_components import (
    ScrapPurchaseViewModel,
    ScrapStateTableData,
    ProductionPlanTableData,
    ScrapOfferTableData,
    BaseDeltaRuleTableRow,
    RealizedScrapOfferTableRow,
    OverallPurchaseTableData,
    ScrapTypeMappingTableData,
    ScrapSupplierMappingTableData,
    get_scrap_type_dropdown_options,
    get_scrap_offers_table_columns,
    get_realized_scrap_offers_columns,
    ScrapPivotTableRow,
)

from .errors import ScrapPurchaseError
from .internal import (
    get_scrap_state_row,
    get_scrap_parsed_table_row,
    get_production_plan_mapping_row,
    get_scrap_offer_table_row,
    get_base_delta_rule_row_from_base_delta_rule,
    compute_overall_purchase_table,
    get_scrap_type_mapping_row,
    get_scrap_supplier_mapping_row,
    get_supplier_dropdown_values,
    get_scrap_offer_info_text,
)

from .utils import (
    DATETIME_CONVERSION_STRING,
    DISPLAY_BLOCK_STYLE,
    DISPLAY_NONE_STYLE,
)
from ...models import ScrapOffer, ScrapOfferData, RealizedScrapOfferData, RealizedScrapOffer

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


# region COMMON OUTPUT FIELDS
def set_scrap_purchase_title(data: ScrapPurchaseViewModel) -> Optional[str]:
    return data.scrap_purchase_title


# TODO: find out why UI is not in sync with view model
def update_purchase_date(data: ScrapPurchaseViewModel) -> Optional[str]:
    if not data.purchase_date:
        return None
    return data.purchase_date.strftime(DATETIME_CONVERSION_STRING)


def set_scrap_state_filename(data: ScrapPurchaseViewModel) -> str:
    return data.scrap_state_filename


def set_scrap_on_the_way_filename(data: ScrapPurchaseViewModel) -> str:
    return data.scrap_on_the_way_filename


def set_scrap_state_table_data(data: ScrapPurchaseViewModel) -> ScrapStateTableData:
    return [get_scrap_state_row(scrap_state) for scrap_state in data.scrap_state_data]


def update_scrap_stock_objective(data: ScrapPurchaseViewModel) -> Optional[int]:
    return data.scrap_stock_objective


def update_mean_scrap_weight(data: ScrapPurchaseViewModel) -> int:
    return int(convert_kilograms_to_tons(data.mean_scrap_weight))


def open_close_scrap_state_parsed_data_collapse(data: ScrapPurchaseViewModel) -> bool:
    return data.parsed_scrap_state_is_open


def set_scrap_state_parsed_table_data(data: ScrapPurchaseViewModel) -> List[Dict]:
    return [get_scrap_parsed_table_row(parsed_row) for parsed_row in data.parsed_scrap_state_data]


def open_close_scrap_on_the_way_parsed_data_collapse(data: ScrapPurchaseViewModel) -> bool:
    return data.parsed_scrap_on_the_way_is_open


def set_scrap_on_the_way_parsed_table_data(data: ScrapPurchaseViewModel) -> List[Dict]:
    return [get_scrap_parsed_table_row(parsed_row) for parsed_row in data.parsed_scrap_on_the_way_data]


def update_production_plan_date(data: ScrapPurchaseViewModel) -> Optional[str]:
    if not data.production_plan_date:
        return None
    return data.production_plan_date.strftime(DATETIME_CONVERSION_STRING)


def update_production_plan_nr_of_weeks(data: ScrapPurchaseViewModel) -> Optional[int]:
    return data.production_plan_nr_of_weeks


def update_expected_steel_production_weight(data: ScrapPurchaseViewModel) -> int:
    return int(convert_kilograms_to_tons(data.expected_steel_production))


def update_export_slabs_weight(data: ScrapPurchaseViewModel) -> int:
    return data.export_slabs_weight


def set_production_plan_table_data(data: ScrapPurchaseViewModel) -> ProductionPlanTableData:
    return [get_production_plan_mapping_row(production_plan) for production_plan in data.production_plan_data]


def set_scrap_offers_parsed_table_data(data: ScrapPurchaseViewModel) -> List[Dict]:
    return [
        cattr.unstructure(scrap_offer_parsed_record)
        for scrap_offer_parsed_record in data.parsed_scrap_offers_data
    ]


def set_scrap_offers_filename(data: ScrapPurchaseViewModel) -> str:
    return data.scrap_offers_filename


def open_close_scrap_offers_parsed_data_collapse(data: ScrapPurchaseViewModel) -> bool:
    return data.parsed_scrap_offers_is_open


def update_username(data: ScrapPurchaseViewModel) -> str:
    return data.user


def update_navbar_scrap_purchase_info(data: ScrapPurchaseViewModel) -> str:
    scrap_purchase_info = "Nákup šrotu"
    if data.scrap_purchase_title:
        scrap_purchase_info += f" - {data.scrap_purchase_title}"
    if data.purchase_date:
        scrap_purchase_info += f" - {data.purchase_date:%m.%Y}"
    return scrap_purchase_info


# endregion


# region READ ONLY OUTPUT FIELDS
def show_hide_wizard_step_1(data: ScrapPurchaseViewModel) -> Dict:
    if data.get_wizard_step() == 1:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def show_hide_wizard_step_2(data: ScrapPurchaseViewModel) -> Dict:
    if data.get_wizard_step() == 2:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def show_hide_wizard_step_3(data: ScrapPurchaseViewModel) -> Dict:
    if data.get_wizard_step() == 3:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def show_hide_wizard_step_4(data: ScrapPurchaseViewModel) -> Dict:
    if data.get_wizard_step() == 4:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def show_hide_main_section(data: ScrapPurchaseViewModel) -> Dict:
    if data.get_wizard_step() == 0:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def update_scrap_offers_table(data: ScrapPurchaseViewModel) -> ScrapOfferTableData:
    return [get_scrap_offer_table_row(scrap_offer) for scrap_offer in data.scrap_offer_data]


def update_base_delta_rules_table(data: ScrapPurchaseViewModel) -> List[BaseDeltaRuleTableRow]:
    return [
        get_base_delta_rule_row_from_base_delta_rule(base_delta_rule, row_idx)
        for row_idx, base_delta_rule in enumerate(data.base_delta_rule_data)
    ]


def update_base_delta_rules_dropdowns(data: ScrapPurchaseViewModel) -> Dict:
    scrap_offers_data = data.scrap_offer_data
    scrap_types = [PRIME_GROUP_NAME, CUT_GROUP_NAME] + sorted(
        {scrap_offer.scrap_type for scrap_offer in scrap_offers_data if scrap_offer.scrap_type}
    )
    suppliers = {scrap_offer.supplier for scrap_offer in scrap_offers_data if scrap_offer.supplier}
    zones = {scrap_offer.zone for scrap_offer in scrap_offers_data if scrap_offer.zone}

    dropdown = {
        "scrap_type": {
            "clearable": False,
            "options": [
                {"label": scrap_type_name, "value": scrap_type_name} for scrap_type_name in scrap_types
            ],
        },
        "zone": {
            "clearable": False,
            "options": [{"label": zone, "value": zone} for zone in sorted(zones)],
        },
        "supplier": {
            "clearable": True,
            "options": [{"label": supplier, "value": supplier} for supplier in sorted(suppliers)],
        },
    }
    return dropdown


def update_scrap_pivot_table(data: ScrapPurchaseViewModel) -> List[ScrapPivotTableRow]:
    def get_zone(offer: Union[RealizedScrapOffer, ScrapOffer]) -> Optional[str]:
        if offer.zone is None:
            return None

        return f"z{offer.zone}" if offer.zone.isdigit() else offer.zone.lower()

    def get_realized_pivot_table(
        realized_offers: RealizedScrapOfferData, scrap_types: Container[ScrapType]
    ) -> pd.DataFrame:
        df_data = pd.DataFrame(
            {
                "scrap_type": offer.scrap_type,
                "zone": get_zone(offer),
                "realized": offer.weight,
            }
            for offer in realized_offers
            if offer.scrap_type in scrap_types
        )

        if df_data.empty:
            return df_data

        return (
            df_data.groupby(["scrap_type", "zone"])
            .sum()
            .reset_index()
            .pivot(index="scrap_type", columns="zone", values="realized")
            .groupby("scrap_type")
            .sum()
        )

    def get_recommended_pivot_table(
        offers: ScrapOfferData, scrap_types: Container[ScrapType]
    ) -> pd.DataFrame:
        df_data = pd.DataFrame(
            {
                "scrap_type": offer.scrap_type,
                "zone": get_zone(offer),
                "recommended": (offer.weight or 0) * (offer.recommendation or 0),
            }
            for offer in offers
            if offer.scrap_type in scrap_types
        )

        if df_data.empty:
            return df_data

        return (
            df_data.groupby(["scrap_type", "zone"])
            .sum()
            .reset_index()
            .pivot(index="scrap_type", columns="zone", values="recommended")
            .groupby("scrap_type")
            .sum()
        )

    def combine(df_prime: pd.DataFrame, df_cut: pd.DataFrame) -> pd.DataFrame:
        df_prime, df_cut = df_prime.align(df_cut, axis=1, fill_value=0)

        # add per zone prime total row
        s_prime_total = df_prime.sum().rename("Prime Total")

        # add per zone cut total row
        s_cut_total = df_cut.sum().rename("Cut Total")

        # add per zone total row
        s_total = (s_prime_total + s_cut_total).rename("Total")

        # due to unknown reasons concatenation of rows does not work as expected,
        # thus we concatenate data as columns and transpose the result
        df_combined = pd.concat(
            [
                df_prime.T,
                s_prime_total,
                df_cut.T,
                s_cut_total,
                s_total,
            ],
            axis=1,
        ).T

        # add per scrap total column
        df_combined["total"] = df_combined.sum(axis=1)

        return df_combined

    if not data.scrap_offer_data:
        return []

    df_realized_prime = get_realized_pivot_table(data.realized_scrap_offer_data, PRIME_SCRAP)
    df_realized_cut = get_realized_pivot_table(data.realized_scrap_offer_data, CUT_SCRAP)

    df_realized = combine(df_realized_prime, df_realized_cut)

    df_recommended_prime = get_recommended_pivot_table(data.scrap_offer_data, PRIME_SCRAP)
    df_recommended_cut = get_recommended_pivot_table(data.scrap_offer_data, CUT_SCRAP)

    df_recommended = combine(df_recommended_prime, df_recommended_cut)

    # align dataframes on both axis
    df_realized, df_recommended = df_realized.align(df_recommended, fill_value=0)

    # fix index order
    index = [
        *sorted(set(PRIME_SCRAP) & set(df_realized.index)),
        "Prime Total",
        *sorted(set(CUT_SCRAP) & set(df_realized.index)),
        "Cut Total",
        "Total",
    ]

    df_realized = df_realized.astype(int)
    df_recommended = df_recommended.astype(int)

    return [
        ScrapPivotTableRow(
            scrap_type=idx,
            zone_1=f"{df_realized.z1[idx]} ({df_recommended.z1[idx]})",
            zone_2=f"{df_realized.z2[idx]} ({df_recommended.z2[idx]})",
            zone_3=f"{df_realized.z3[idx]} ({df_recommended.z3[idx]})",
            zone_4=f"{df_realized.z4[idx]} ({df_recommended.z4[idx]})",
            zone_cz=f"{df_realized.cz[idx]} ({df_recommended.cz[idx]})",
            zone_hu=f"{df_realized.hu[idx]} ({df_recommended.hu[idx]})",
            zone_pl=f"{df_realized.pl[idx]} ({df_recommended.pl[idx]})",
            total=f"{df_realized.total[idx]} ({df_recommended.total[idx]})",
        )
        for idx in index
    ]


def update_realized_scrap_offers_table(data: ScrapPurchaseViewModel) -> List[RealizedScrapOfferTableRow]:
    return [
        RealizedScrapOfferTableRow(
            scrap_type=realized_scrap_offer.scrap_type,
            zone=realized_scrap_offer.zone,
            weight=realized_scrap_offer.weight,
            supplier=realized_scrap_offer.supplier,
            price=realized_scrap_offer.price,
            note=realized_scrap_offer.note,
            delete="🗑️",
            scrap_offer_uuid_list=realized_scrap_offer.scrap_offer_uuid_list,
        )
        for realized_scrap_offer in data.realized_scrap_offer_data
    ]


def update_overall_purchase_table(data: ScrapPurchaseViewModel) -> OverallPurchaseTableData:
    return compute_overall_purchase_table(data)


def update_price_plot_figure(data: ScrapPurchaseViewModel) -> go.Figure:
    if not data.scrap_offer_to_plot:
        return go.Figure()

    price_plot_data = data.price_plot_data
    scrap_type = price_plot_data.scrap_type

    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.update_layout(
        title_text=f"{scrap_type}",
    )
    fig.update_xaxes(title_text="Dátum", showspikes=True)
    fig.update_yaxes(title_text="Cena", secondary_y=True, showspikes=True)

    min_date = datetime.utcnow()
    max_date = datetime(year=1970, month=1, day=1)

    for price_history_zone, price_history in price_plot_data.price_plot_values.items():
        date_list = price_history.date_list
        hover_label_list = price_history.hover_label_list
        weighted_price_list = price_history.weighted_price_list

        if date_list:
            fig.add_trace(
                go.Scatter(
                    x=date_list,
                    y=weighted_price_list,
                    name=f"Zóna {price_history_zone}",
                    text=hover_label_list,
                    hoverinfo="text",
                ),
                secondary_y=True,
            )
            min_date = min(date_list + [min_date])
            max_date = max(date_list + [max_date])
            nr_of_months = (max_date.year - min_date.year) * 12 + (max_date.month - min_date.month)
            fig.update_xaxes(
                {
                    "nticks": nr_of_months,
                    "range": [min_date, max_date],
                }
            )
        fig.update_traces(showlegend=True)
    return fig


def show_hide_scrap_price_plot_section(data: ScrapPurchaseViewModel) -> Dict:
    if data.scrap_offer_to_plot:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def update_input_data_link(data: ScrapPurchaseViewModel) -> str:
    return reverse(
        "scrap:update_scrap_purchase",
        kwargs={"scrap_purchase_record_id": data.scrap_purchase_record_id},
    )


def update_applied_delta_rules_progress_bar_value(data: ScrapPurchaseViewModel) -> float:
    if data.scrap_offer_data:
        return data.nr_of_scrap_offers_with_rules * 100.0 / len(data.scrap_offer_data)
    return 0.0


def update_applied_delta_rules_progress_bar_children(data: ScrapPurchaseViewModel) -> str:
    return f"{data.nr_of_scrap_offers_with_rules} / {len(data.scrap_offer_data)}"


# endregion


# region EDIT APP OUTPUT FIELDS
def set_error_message(data: ScrapPurchaseViewModel) -> str:
    if data.error:
        return "Error occurred"
    return ""


def enable_save_scrap_state_mappings_button(data: ScrapPurchaseViewModel) -> bool:
    return not data.are_scrap_state_mappings_filled()


def set_unmapped_scrap_state_scrap_types(data: ScrapPurchaseViewModel) -> ScrapTypeMappingTableData:
    return [
        get_scrap_type_mapping_row(scrap_type_mapping)
        for scrap_type_mapping in data.scrap_type_from_scrap_state_data
    ]


def show_hide_scrap_state_mappings_section(data: ScrapPurchaseViewModel) -> Dict:
    if data.are_unmapped_types_from_scrap_state_data():
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def enable_save_scrap_offers_mappings_button(data: ScrapPurchaseViewModel) -> bool:
    return not data.are_scrap_offers_mappings_filled()


def set_unmapped_scrap_offers_scrap_types(data: ScrapPurchaseViewModel) -> ScrapTypeMappingTableData:
    return [
        get_scrap_type_mapping_row(scrap_type_mapping)
        for scrap_type_mapping in data.scrap_type_from_scrap_offers_data
    ]


def show_hide_scrap_offers_mapping_section(data: ScrapPurchaseViewModel) -> Dict:
    if data.are_unmapped_types_from_scrap_offers_data():
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def set_unmapped_scrap_supplier_mapping_table(data: ScrapPurchaseViewModel) -> ScrapSupplierMappingTableData:
    return [
        get_scrap_supplier_mapping_row(scrap_supplier_mapping)
        for scrap_supplier_mapping in data.scrap_supplier_mapping
    ]


def enable_save_scrap_supplier_mappings_button(data: ScrapPurchaseViewModel) -> bool:
    return not data.are_scrap_supplier_mappings_filled(data.scrap_supplier_mapping)


def show_hide_scrap_supplier_mapping_section(data: ScrapPurchaseViewModel) -> Dict:
    if data.are_unmapped_scrap_supplier_from_scrap_offers():
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def disable_production_plan_load_button(data: ScrapPurchaseViewModel) -> bool:
    if data.production_plan_date and data.production_plan_nr_of_weeks:
        return False
    return True


def enable_show_scrap_state_parsed_data_button(data: ScrapPurchaseViewModel) -> bool:
    if not data.scrap_state_filename:
        return True
    return False


def enable_show_scrap_on_the_way_parsed_data_button(data: ScrapPurchaseViewModel) -> bool:
    if not data.scrap_on_the_way_filename:
        return True
    return False


def enable_show_scrap_offers_data_button(data: ScrapPurchaseViewModel) -> bool:
    if not data.scrap_offers_filename:
        return True
    return False


def update_scrap_offers_table_dropdowns(
    data: ScrapPurchaseViewModel,
) -> Dict:
    return {
        "scrap_type": {
            "clearable": False,
            "options": get_scrap_type_dropdown_options(),
        },
        "scrap_purchased": {
            "clearable": False,
            "options": [
                {"label": "Kúpené", "value": True},
                {"label": "Nekúpené", "value": False},
            ],
        },
        "supplier": {
            "clearable": False,
            "options": get_supplier_dropdown_values(data.scrap_supplier_names),
        },
    }


def update_unmapped_scrap_supplier_dropdowns(
    data: ScrapPurchaseViewModel,
) -> Dict:
    return {
        "scrap_supplier": {
            "clearable": False,
            "options": get_supplier_dropdown_values(data.scrap_supplier_names),
        }
    }


def show_hide_buy_scrap_modal_window(data: ScrapPurchaseViewModel) -> bool:
    if data.scrap_offer_to_buy_idx is not None:
        return True
    return False


def fill_buy_scrap_modal_offer_info(data: ScrapPurchaseViewModel) -> str:
    if data.scrap_offer_to_buy_idx is None:
        return ""
    scrap_offer_to_buy = data.scrap_offer_data[data.scrap_offer_to_buy_idx]
    if scrap_offer_to_buy:
        return (
            f"{scrap_offer_to_buy.scrap_type} "
            f"{scrap_offer_to_buy.zone} "
            f"{scrap_offer_to_buy.supplier} "
            f"{scrap_offer_to_buy.weight} ton"
        )
    return ""


def enable_buy_scrap_button(data: ScrapPurchaseViewModel) -> bool:
    if data.scrap_offer_to_buy_idx is None:
        return True
    if (
        data.scrap_offer_data[data.scrap_offer_to_buy_idx]
        and data.scrap_offer_to_buy_price
        and data.scrap_offer_to_buy_amount
    ):
        return False
    return True


def sync_buy_scrap_modal_price(data: ScrapPurchaseViewModel) -> Optional[float]:
    return data.scrap_offer_to_buy_price


def sync_buy_scrap_modal_amount(data: ScrapPurchaseViewModel) -> Optional[float]:
    return data.scrap_offer_to_buy_amount


def show_hide_create_edit_offer_modal_window(data: ScrapPurchaseViewModel) -> bool:
    if data.scrap_offer_to_edit_idx is not None:
        return True
    return False


def update_create_edit_offer_modal_supplier_options(data: ScrapPurchaseViewModel) -> List[Dict]:
    return get_supplier_dropdown_values(data.scrap_supplier_names)


def disable_update_scrap_offer_confirm_button(data: ScrapPurchaseViewModel) -> bool:
    if data.scrap_offer_to_edit_idx is None:
        return True
    if all(
        [
            data.scrap_offer_to_edit_scrap_type,
            data.scrap_offer_to_edit_zone,
            data.scrap_offer_to_edit_weight,
            data.scrap_offer_to_edit_supplier,
            data.scrap_offer_to_edit_price,
        ]
    ):
        return False
    return True


def update_create_edit_offer_scrap_type(data: ScrapPurchaseViewModel) -> Optional[ScrapType]:
    return data.scrap_offer_to_edit_scrap_type


def update_create_edit_offer_zone(data: ScrapPurchaseViewModel) -> Optional[str]:
    return data.scrap_offer_to_edit_zone


def update_create_edit_offer_weight(data: ScrapPurchaseViewModel) -> Optional[float]:
    return data.scrap_offer_to_edit_weight


def update_create_edit_offer_supplier(data: ScrapPurchaseViewModel) -> Optional[str]:
    return data.scrap_offer_to_edit_supplier


def update_create_edit_offer_price(data: ScrapPurchaseViewModel) -> Optional[float]:
    return data.scrap_offer_to_edit_price


def update_create_edit_offer_override_price(data: ScrapPurchaseViewModel) -> Optional[float]:
    return data.scrap_offer_to_edit_override_price


def update_create_edit_offer_note(data: ScrapPurchaseViewModel) -> Optional[str]:
    return data.scrap_offer_to_edit_note


def update_create_edit_offer_station(data: ScrapPurchaseViewModel) -> Optional[str]:
    return data.scrap_offer_to_edit_station


def show_hide_delete_realized_offer_modal(data: ScrapPurchaseViewModel) -> bool:
    if data.realized_offer_to_delete_idx is not None:
        return True
    return False


def fill_delete_realized_offer_info(data: ScrapPurchaseViewModel) -> List[Any]:
    if data.realized_offer_to_delete_idx is None:
        return list()
    realized_offer_to_delete = data.realized_scrap_offer_data[data.realized_offer_to_delete_idx]
    scrap_offer_uuid_list = realized_offer_to_delete.scrap_offer_uuid_list
    connected_scrap_offers = [
        scrap_offer for scrap_offer in data.scrap_offer_data if scrap_offer.uuid in scrap_offer_uuid_list
    ]
    children = list()
    children.append(html.H6("Realizovaná ponuka, ktorá bude zmazaná:"))
    children.append(
        html.P(
            f"{realized_offer_to_delete.scrap_type} "
            f"{realized_offer_to_delete.zone} "
            f"{realized_offer_to_delete.weight} "
            f"{realized_offer_to_delete.price} "
            f"{realized_offer_to_delete.note}"
        )
    )

    scrap_offers_to_unlock = list()
    scrap_offers_to_delete = list()
    for scrap_offer in connected_scrap_offers:
        if scrap_offer.generated_from:
            scrap_offers_to_delete.append(scrap_offer)
        else:
            scrap_offers_to_unlock.append(scrap_offer)

    if scrap_offers_to_unlock:
        children.append(html.H6("Ponuky, ktoré budú odomknuté:"))
        children.extend(
            [html.P(get_scrap_offer_info_text(scrap_offer)) for scrap_offer in scrap_offers_to_unlock]
        )

    if scrap_offers_to_delete:
        children.append(html.H6("Ponuky, ktoré budú zmazaneé:"))
        children.extend(
            [html.P(get_scrap_offer_info_text(scrap_offer)) for scrap_offer in scrap_offers_to_delete]
        )

    return children


def open_close_error_modal_window(data: ScrapPurchaseViewModel) -> bool:
    return data.error


def disable_confirm_step_1(data: ScrapPurchaseViewModel) -> bool:
    return not data.is_wizard_step_1_fulfilled()


def disable_confirm_step_2(data: ScrapPurchaseViewModel) -> bool:
    return not data.is_wizard_step_2_fulfilled()


def disable_confirm_step_3(data: ScrapPurchaseViewModel) -> bool:
    return not data.is_wizard_step_3_fulfilled()


def disable_confirm_step_4(data: ScrapPurchaseViewModel) -> bool:
    return not data.is_wizard_step_4_fulfilled()


def disable_run_computation_button(data: ScrapPurchaseViewModel) -> bool:
    if data.computation_start_clicked:
        return True
    if data.scrap_offer_data:
        if data.nr_of_scrap_offers_with_rules == len(data.scrap_offer_data) and all(
            offer.has_valid_price for offer in data.scrap_offer_data
        ):
            return False
    return True


def disable_computation_refresh_interval(data: ScrapPurchaseViewModel) -> bool:
    return not data.computation_start_clicked


def update_computation_progress_text(data: ScrapPurchaseViewModel) -> str:
    return f"{update_computation_progress_value(data):.1f}%"


def update_computation_progress_value(data: ScrapPurchaseViewModel) -> float:
    if data.computation_start_clicked:

        # This check is due to `mypy`
        if data.latest_computation is None:
            raise ScrapPurchaseError(
                f"Scrap Purchase Record {data.scrap_purchase_record_id}"
                " - Attribute `computation_start_clicked` set to `True`"
                " despite no computation has been triggered, yet"
            )

        return data.latest_computation.progress

    return 0.0


def update_computation_progress_style(data: ScrapPurchaseViewModel) -> str:
    if data.computation_start_clicked:
        return "d-block"
    return "d-none"


def update_scrap_offers_table_columns(data: ScrapPurchaseViewModel) -> List[Dict]:
    return get_scrap_offers_table_columns(debug_mode=data.debug)


def update_realized_scrap_offers_table_columns(data: ScrapPurchaseViewModel) -> List[Dict]:
    return get_realized_scrap_offers_columns(debug_mode=data.debug)


def update_export_realized_scrap_offers_button(data: ScrapPurchaseViewModel) -> str:
    return reverse(
        "scrap:export_realized_offers_to_excel",
        kwargs={"scrap_purchase_record_id": data.scrap_purchase_record_id},
    )


def update_finish_purchase_modal_is_open(data: ScrapPurchaseViewModel) -> bool:
    return data.finish_scrap_purchase_is_open


def update_finish_purchase_modal_backdrop(data: ScrapPurchaseViewModel) -> Union[bool, str]:
    if data.finish_scrap_purchase_in_progress:
        return "static"
    return True


def disable_confirm_finish_purchase_button(data: ScrapPurchaseViewModel) -> bool:
    return data.finish_scrap_purchase_in_progress


def show_hide_finish_purchase_modal_body(data: ScrapPurchaseViewModel) -> Dict:
    if data.finish_scrap_purchase_in_progress:
        return DISPLAY_BLOCK_STYLE
    return DISPLAY_NONE_STYLE


def update_user_in_control_name(data: ScrapPurchaseViewModel) -> str:
    return f"Prevziať kontrolu od {data.user_in_control}"


def hide_get_control_button(data: ScrapPurchaseViewModel) -> bool:
    return (data.user == data.user_in_control) or (data.user not in data.authorized_users)


def control_gained(data: ScrapPurchaseViewModel) -> bool:
    return data.control_gained


def control_lost(data: ScrapPurchaseViewModel) -> bool:
    return data.control_lost


# region


# region READ ONLY APP SPECIFIC OUTPUT
def update_refresh_time(data: ScrapPurchaseViewModel) -> str:  # pylint: disable=unused-argument
    return datetime.now().strftime("Aktualizované %H:%M:%S")


# endregion
