import logging
from pathlib import Path

from common.dash import DjangoPlotlyDashCallbackContext
from django_plotly_dash import DjangoDash
from scrap.dash.settings_app.datamodel import LoadingStationSettingViewModel, SettingsAppDataSource
from vsadzka.settings import STATIC_ROOT

import ussksdc as sdc

SLUG_APP = "loading-station-settings"
NAME_APP = "LoadingScrapStationSettings"


logger = logging.getLogger(__name__)

loading_scrap_station_settings_app = DjangoDash(NAME_APP, serve_locally=True, add_bootstrap_links=True)

sdc.sdc_initialize_app(  # type: ignore
    loading_scrap_station_settings_app,
    LoadingStationSettingViewModel,
    SettingsAppDataSource,
    callback_context_getter=DjangoPlotlyDashCallbackContext,
    assets_dir=Path(STATIC_ROOT) / "scrap/settings_app/assets",
)
