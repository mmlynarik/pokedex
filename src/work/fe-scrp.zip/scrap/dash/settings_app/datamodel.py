import logging
from typing import List, Optional

import attr
from dash import dcc, html
from dash.development.base_component import Component
from django.contrib.auth.models import User
from scrap.dash.components.exclusive_group.table import ExclusiveGroupSettingsTableViewModel
from scrap.dash.components.grade_group.datasource import GradeGroupTableDataSource
from scrap.dash.components.grade_group.table import GradeGroupTableViewModel
from scrap.dash.components.layouts.nav_tabs import NavTab, NavTabs, create_tabs_layout
from scrap.dash.components.layouts.sidebar import SideBar, create_sidebar_layout, get_input_wrapper
from scrap.dash.components.risk_limit.table import RiskLimitsSettingsTableViewModel
from scrap.dash.components.scrap_group.datasource import ScrapGroupTableDataSource
from scrap.dash.components.scrap_group.table import ScrapGroupTableViewModel
from scrap.dash.components.selectors import (
    GradeGroupSelectorViewModel,
    GradeIdsSelectorViewModel,
    LoadingStationSelectorViewModel,
)
from scrap.dash.components.summing_limit.tables import (
    LowerSummingLimitsSettingsTableViewModel,
    UpperSummingLimitsSettingsTableViewModel,
)

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())

# User friendly text used in fronted
APP_NAME = "Šrotový model Nastavenia"
LOADING_STATION = "Nakladacia stanica"
GRADE_IDS = "Akosť"
PRIORITY = "Priorita"
LIMITS = "Limity"
SCRAP_GROUP = "Skupiny šrotov"
GRADE_GROUP = "Skupiny akostí"

# Component class names
TABLE_WRAPPER_CLASSNAMES = "limits-table-wrapper"


@attr.s(frozen=True, slots=True, cache_hash=False)
class LoadingStationSettingViewModel:
    logged_user_id: DataStoreViewModel = sdc.child_component(
        "data-store", default=DataStoreViewModel(data=-1)  # type: ignore
    )
    # Inputs
    loading_station_selector: LoadingStationSelectorViewModel = sdc.child_component(
        "loading-station", default=LoadingStationSelectorViewModel()
    )
    grades_selector: GradeIdsSelectorViewModel = sdc.child_component(
        "grades-ids", default=GradeIdsSelectorViewModel()
    )
    grades_group_selector: GradeGroupSelectorViewModel = sdc.child_component(
        "grades-group", default=GradeGroupSelectorViewModel()
    )
    # Table
    risk_table: RiskLimitsSettingsTableViewModel = sdc.child_component(
        "risk-limits-settings", factory=RiskLimitsSettingsTableViewModel
    )
    exclusive_table: ExclusiveGroupSettingsTableViewModel = sdc.child_component(
        "exclusive-limits-settings", factory=ExclusiveGroupSettingsTableViewModel
    )
    upper_summing_limits_table: UpperSummingLimitsSettingsTableViewModel = sdc.child_component(
        "upper-summing-limits-settings", factory=UpperSummingLimitsSettingsTableViewModel
    )
    lower_summing_limits_table: LowerSummingLimitsSettingsTableViewModel = sdc.child_component(
        "lower-summing-limits-settings", factory=LowerSummingLimitsSettingsTableViewModel
    )
    scrap_group_table: ScrapGroupTableViewModel = sdc.child_component(
        "scrap-groups", factory=ScrapGroupTableViewModel
    )
    grade_group_table: GradeGroupTableViewModel = sdc.child_component(
        "grade-groups", factory=GradeGroupTableViewModel
    )

    @classmethod
    def load_initial_data(
        cls, *args, **kwargs  # pylint: disable=unused-argument
    ) -> "LoadingStationSettingViewModel":
        logged_user_id = kwargs["user"].id
        return LoadingStationSettingViewModel(  # type: ignore
            logged_user_id=DataStoreViewModel(data=logged_user_id)  # type: ignore
        )

    @classmethod
    def get_sidebar_bottom_items(cls) -> List[Component]:
        return [
            dcc.Loading(
                children=sdc.get_child_layout("", cls.logged_user_id),
            )
        ]

    @classmethod
    def get_sidebar_inputs(cls) -> List[Component]:
        return [
            get_input_wrapper(
                LOADING_STATION,
                sdc.get_child_layout("", cls.loading_station_selector),
            ),
            get_input_wrapper(
                GRADE_IDS,
                sdc.get_child_layout("", cls.grades_selector),
            ),
            get_input_wrapper(
                GRADE_GROUP,
                sdc.get_child_layout("", cls.grades_group_selector),
            ),
        ]

    @classmethod
    def get_tables(cls) -> List[Component]:
        return html.Div(
            children=[
                sdc.get_child_layout("", cls.risk_table),
                sdc.get_child_layout("", cls.upper_summing_limits_table),
                sdc.get_child_layout("", cls.lower_summing_limits_table),
                sdc.get_child_layout("", cls.exclusive_table),
            ],
            className=TABLE_WRAPPER_CLASSNAMES,
        )

    @classmethod
    def get_layout(cls):
        return create_sidebar_layout(
            sidebar=SideBar(
                title=APP_NAME,
                main_content=cls.get_sidebar_inputs(),
                bottom_content=cls.get_sidebar_bottom_items(),
            ),
            page_content=create_tabs_layout(
                NavTabs(
                    tabs=(
                        NavTab(content=cls.get_tables(), label=LIMITS),
                        NavTab(
                            content=sdc.get_child_layout("", cls.scrap_group_table),
                            label=SCRAP_GROUP,
                        ),
                        NavTab(
                            content=sdc.get_child_layout("", cls.grade_group_table),
                            label=GRADE_GROUP,
                        ),
                    )
                ),
            ),
        )


class SettingsAppDataSource:
    def __init__(self, parent: LoadingStationSettingViewModel):
        self.parent = parent

    @property
    def selected_loading_station_id(self) -> Optional[int]:
        return self.parent.loading_station_selector.selected_option  # type: ignore

    @property
    def selected_grade_id(self) -> Optional[int]:
        return self.parent.grades_selector.selected_option  # type: ignore

    @property
    def selected_grade_group_id(self) -> Optional[int]:
        return self.parent.grades_group_selector.selected_option  # type: ignore

    @property
    def logged_user(self) -> User:
        return User.objects.get(id=self.parent.logged_user_id.data)

    @property
    def scrap_groups_source(self) -> ScrapGroupTableDataSource:
        return self.parent.scrap_group_table.data_source

    @property
    def grade_groups_source(self) -> GradeGroupTableDataSource:
        return self.parent.grade_group_table.data_source
