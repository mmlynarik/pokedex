from abc import ABC, abstractmethod
from typing import Optional

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from ussksdc.validation import (
    NO_VALIDATION_PROBLEMS,
    ValidationResult,
    error_to_validation_result,
    join_validation_results,
    validation_result_to_msg,
    warning_to_validation_result,
)

VALIDATION_MSG_CLASSNAME = "validation-message"
INPUTS_ROW_CLASSNAME = "inline-inputs"
VALIDATION_MSG_ERROR_CLASSNAME = f"{VALIDATION_MSG_CLASSNAME} {VALIDATION_MSG_CLASSNAME}-error"
VALIDATION_MSG_WARNING_CLASSNAME = f"{VALIDATION_MSG_CLASSNAME} {VALIDATION_MSG_CLASSNAME}-warning"


@attr.s(frozen=True, slots=True)
class PairInputsViewModel(ABC):
    # Initial settings
    DEBOUNCE = True
    INPUT_TYPE = "number"
    # Components ids
    PAIR_LIMIT_AIM_ID = "aim"
    PAIR_LIMIT_ALLOWED_ID = "allowed"
    PAIR_LIMIT_AIM_MSG_ID = "aim-msg"
    PAIR_LIMIT_ALLOWED_MSG_ID = "allowed-msg"
    # User friendly msg
    AIM_LE_THEN_ALLOWED = "Cieľový limit musi byť menší rovný ako max. povolená hodnota."
    AIM_GE_THEN_ALLOWED = "Cieľový limit musi byť väčší rovný ako min. povolená hodnota."
    NOT_DEFINED_LIMIT = "Limit musí byť definovaný."

    # Fields
    aim: Optional[float] = sdc.two_way_binding(PAIR_LIMIT_AIM_ID, "value", default=None)
    allowed: Optional[float] = sdc.two_way_binding(PAIR_LIMIT_ALLOWED_ID, "value", default=None)
    validation_aim: ValidationResult = attr.ib(default=((), ()))
    validation_allowed: ValidationResult = attr.ib(default=((), ()))

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.PAIR_LIMIT_AIM_MSG_ID, "children", PairInputsViewModel.get_aim_validation_msg
            ),
            sdc.OutputField(
                cls.PAIR_LIMIT_ALLOWED_MSG_ID, "children", PairInputsViewModel.get_allowed_validation_msg
            ),
            sdc.OutputField(cls.PAIR_LIMIT_AIM_MSG_ID, "className", PairInputsViewModel.get_aim_class_name),
            sdc.OutputField(
                cls.PAIR_LIMIT_ALLOWED_MSG_ID, "className", PairInputsViewModel.get_allowed_class_name
            ),
        )

    @classmethod
    def get_single_input_layout(cls, parent_id: str, input_id: str, msg_id: str) -> html.Div:
        return html.Div(
            children=[
                dbc.Input(
                    debounce=cls.DEBOUNCE,
                    id=sdc.create_id(parent_id, input_id),
                    type=cls.INPUT_TYPE,
                    step=cls.get_step(),
                ),
                html.Div(
                    className=VALIDATION_MSG_CLASSNAME,
                    id=sdc.create_id(parent_id, msg_id),
                ),
            ]
        )

    @classmethod
    def get_layout(cls, parent_id: str, pair_name: str) -> html.Div:
        return html.Div(
            children=[
                dbc.Label(children=pair_name),
                cls.get_single_input_layout(parent_id, cls.PAIR_LIMIT_AIM_ID, cls.PAIR_LIMIT_AIM_MSG_ID),
                cls.get_single_input_layout(
                    parent_id, cls.PAIR_LIMIT_ALLOWED_ID, cls.PAIR_LIMIT_ALLOWED_MSG_ID
                ),
            ],
            className=INPUTS_ROW_CLASSNAME,
        )

    @classmethod
    @abstractmethod
    def get_step(cls) -> float: ...

    @classmethod
    @abstractmethod
    def get_min(cls) -> float: ...

    @classmethod
    @abstractmethod
    def get_max(cls) -> float: ...

    @property
    def valid_inputs(self) -> bool:
        return (not self.validation_aim[0] and not self.validation_aim[1]) and (
            not self.validation_allowed[0] and not self.validation_allowed[1]
        )

    @property
    def aim_or_raise(self) -> float:
        if self.aim is None:
            raise ValueError("Aim limit value is None")
        return self.aim

    @property
    def allowed_or_raise(self) -> float:
        if self.allowed is None:
            raise ValueError("Allowed limit value is None")
        return self.allowed

    def __attrs_post_init__(self):
        object.__setattr__(self, "validation_aim", self.get_aim_validation())
        object.__setattr__(self, "validation_allowed", self.get_allowed_validation())

    def get_aim_validation_msg(self) -> str:
        return validation_result_to_msg(self.validation_aim)

    def get_allowed_validation_msg(self) -> str:
        return validation_result_to_msg(self.validation_allowed)

    def get_aim_class_name(self) -> str:
        return VALIDATION_MSG_ERROR_CLASSNAME if self.validation_aim[0] else VALIDATION_MSG_WARNING_CLASSNAME

    def get_allowed_class_name(self) -> str:
        return (
            VALIDATION_MSG_ERROR_CLASSNAME if self.validation_allowed[0] else VALIDATION_MSG_WARNING_CLASSNAME
        )

    def _validation_in_range(self, limit: float) -> ValidationResult:
        if (self.get_min() > limit) or (limit > self.get_max()):
            return warning_to_validation_result(
                f"Limit musí byť v rozmedzí {self.get_min()} až {self.get_max()}"
            )
        return NO_VALIDATION_PROBLEMS

    def _validation_aim_values_order(self) -> ValidationResult:
        if self.aim is not None and self.allowed is not None:
            if self.aim > self.allowed:
                return warning_to_validation_result(self.AIM_LE_THEN_ALLOWED)
        return NO_VALIDATION_PROBLEMS

    def _validation_empty_limit(self, limit: Optional[float]) -> ValidationResult:
        if limit is None:
            return error_to_validation_result(self.NOT_DEFINED_LIMIT)
        return NO_VALIDATION_PROBLEMS

    def get_aim_validation(self) -> ValidationResult:
        validation = self._validation_empty_limit(self.aim)
        if self.aim is not None:
            validation = join_validation_results(
                (self._validation_in_range(self.aim), self._validation_aim_values_order())
            )
        return validation

    def get_allowed_validation(self) -> ValidationResult:
        validation = self._validation_empty_limit(self.allowed)
        if self.allowed is not None:
            validation = join_validation_results((self._validation_in_range(self.allowed),))
        return validation
