import attr
import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel
from scrap.dash.components.pair_inputs.base import PairInputsViewModel
from ussksdc.validation import NO_VALIDATION_PROBLEMS, ValidationResult, warning_to_validation_result
from dash import html


@attr.s(frozen=True, slots=True)
class ChemInputsViewModel(PairInputsViewModel):
    @classmethod
    def get_step(cls) -> float:
        return 0.01

    @classmethod
    def get_max(cls) -> float:
        return 1.0

    @classmethod
    def get_min(cls) -> float:
        return 0.0


@attr.s(frozen=True, slots=True)
class RatioInputsViewModel(PairInputsViewModel):
    upper_limit: DataStoreViewModel = sdc.child_component(
        "upper-limit", default=DataStoreViewModel(True)  # type: ignore #[SDC MYPY BUG]
    )

    @classmethod
    def get_layout(cls, parent_id: str, pair_name: str) -> html.Div:
        return html.Div(
            children=[
                super().get_layout(parent_id, pair_name),
                sdc.get_child_layout(parent_id, cls.upper_limit),
            ]
        )

    @classmethod
    def get_step(cls) -> float:
        return 1.0

    @classmethod
    def get_max(cls) -> float:
        return 1.0

    @classmethod
    def get_min(cls) -> float:
        return 0.0

    def _validation_in_range(self, limit: float) -> ValidationResult:
        if self.upper_limit.data:
            return super()._validation_in_range(limit)
        if not (0 <= limit <= self.get_max()):
            return warning_to_validation_result(
                f"Limit musí byť v rozmedzí {self.get_min()} až {self.get_max()}"
            )
        return NO_VALIDATION_PROBLEMS

    def _validation_aim_values_order(self) -> ValidationResult:
        if self.upper_limit.data:
            return super()._validation_aim_values_order()
        if self.aim is not None and self.allowed is not None:
            if self.allowed > self.aim:
                return warning_to_validation_result(self.AIM_GE_THEN_ALLOWED)
        return NO_VALIDATION_PROBLEMS


@attr.s(frozen=True, slots=True)
class WeightInputsViewModel(PairInputsViewModel):
    upper_limit: DataStoreViewModel = sdc.child_component(
        "upper-limit", default=DataStoreViewModel(True)  # type: ignore #[SDC MYPY BUG]
    )

    @classmethod
    def get_layout(cls, parent_id: str, pair_name: str) -> html.Div:
        return html.Div(
            children=[
                super().get_layout(parent_id, pair_name),
                sdc.get_child_layout(parent_id, cls.upper_limit),
            ]
        )

    @classmethod
    def get_step(cls) -> float:
        return 1.0

    @classmethod
    def get_max(cls) -> float:
        return 75000.0

    @classmethod
    def get_min(cls) -> float:
        return 0.0

    def _validation_in_range(self, limit: float) -> ValidationResult:
        if self.upper_limit.data:
            return super()._validation_in_range(limit)
        if not (0 <= limit <= self.get_max()):
            return warning_to_validation_result(
                f"Limit musí byť v rozmedzí {self.get_min()} až {self.get_max()}"
            )
        return NO_VALIDATION_PROBLEMS

    def _validation_aim_values_order(self) -> ValidationResult:
        if self.upper_limit.data:
            return super()._validation_aim_values_order()
        if self.aim is not None and self.allowed is not None:
            if self.allowed > self.aim:
                return warning_to_validation_result(self.AIM_GE_THEN_ALLOWED)
        return NO_VALIDATION_PROBLEMS
