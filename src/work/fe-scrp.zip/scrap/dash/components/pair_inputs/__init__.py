from typing import List

from dash import html
from scrap.dash.components.pair_inputs.various_inputs import (
    ChemInputsViewModel,
    RatioInputsViewModel,
    WeightInputsViewModel,
)

# Component class names
INPUT_HEADER_ROW_CLASSNAME = "inline-inputs-header"


def get_pair_inputs_wrapper(
    pair_inputs: List[html.Div], first_column_label: str, second_column_label: str, second_column_id: str = ""
) -> html.Div:
    return html.Div(
        children=[
            html.Div(
                children=[
                    html.Div(children=first_column_label),
                    html.Div(children=second_column_label, id=second_column_id),
                ],
                className=INPUT_HEADER_ROW_CLASSNAME,
            ),
        ]
        + pair_inputs,
    )
