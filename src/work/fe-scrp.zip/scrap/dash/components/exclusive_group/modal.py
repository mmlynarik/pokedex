import time
from typing import Optional

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.exclusive_group import ExclusiveGroupSettingsTableRowViewModel
from scrap.dash.components.modals import create_input_wrapper, create_modal_footer, create_modal_header
from scrap.dash.components.scrap_group.modal import ScrapGroupModalViewModel
from scrap.dash.components.selectors import (
    LoadingStationMultipleSelectorViewModel,
    ScrapGroupSelectorViewModel,
)
from scrap.models import ScrapExclusiveGroupSetting
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class ExclusiveGroupModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    COMPONENT_ID = "modal"
    NAME_ID = "name"
    CLOSE_BUTTON_ID = "close"
    COMMENT_ID = "comment"
    CONFIRM_BUTTON_ID = "update"
    CREATE_SCRAP_GROUP_MODAL_OPEN_BUTTON_ID = "scrap-group-modal-open"
    NAME_VALIDATION_MSG_ID = "name-validation"
    # User friendly msg
    NEW_GROUP = "Nová skupina"
    COMMENT = "Komentár"
    CHOOSE_SCRAP_GROUP = "Vyber skupinu šrotov"
    CHOOSE_LOADING_STATIONS = "Vyber nakladacie stanice"
    NAME_MUST_BE_FILLED = "Názov skupiny musí byť vyplnený"
    CREATE_GROUP = "Vytvoriť skupinu"
    UPDATE_GROUP = "Aktualizovať skupinu"

    loading_stations: LoadingStationMultipleSelectorViewModel = sdc.child_component(
        "loading-stations", default=LoadingStationMultipleSelectorViewModel()
    )
    scrap_groups: ScrapGroupSelectorViewModel = sdc.child_component(
        "scrap-groups", default=ScrapGroupSelectorViewModel()
    )
    create_scrap_group_modal: ScrapGroupModalViewModel = sdc.child_component(
        "create-scrap-group-modal", default=ScrapGroupModalViewModel()
    )
    affected_limit_id: DataStoreViewModel = sdc.child_component(
        "affected-id-data-store", default=DataStoreViewModel()
    )
    last_change: DataStoreViewModel = sdc.child_component(
        "last-change-data-store", default=DataStoreViewModel(0)  # type: ignore #[SDC MYPY BUG]
    )
    confirm_button_label: str = sdc.one_way_binding(CONFIRM_BUTTON_ID, "children", default=CREATE_GROUP)
    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    name: str = sdc.two_way_binding(NAME_ID, "value", default=NEW_GROUP)
    comment: str = sdc.two_way_binding(COMMENT_ID, "value", default="")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", ExclusiveGroupModalViewModel.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", ExclusiveGroupModalViewModel.confirm_event),
            sdc.InputField(
                cls.CREATE_SCRAP_GROUP_MODAL_OPEN_BUTTON_ID,
                "n_clicks",
                ExclusiveGroupModalViewModel.open_create_scrap_group_modal,
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.CONFIRM_BUTTON_ID, "disabled", ExclusiveGroupModalViewModel.are_inputs_invalid
            ),
            sdc.OutputField(
                cls.NAME_VALIDATION_MSG_ID, "children", ExclusiveGroupModalViewModel.name_validation
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            backdrop="static",
            children=[
                create_modal_header(
                    sdc.create_id(parent_id, cls.NAME_ID),
                    sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID),
                    sdc.create_id(parent_id, cls.NAME_VALIDATION_MSG_ID),
                ),
                dbc.ModalBody(
                    children=[
                        create_input_wrapper(
                            cls.CHOOSE_SCRAP_GROUP,
                            [
                                html.Div(
                                    children=[
                                        sdc.get_child_layout(parent_id, cls.scrap_groups),
                                        dbc.Button(
                                            children="+",
                                            color="light",
                                            id=sdc.create_id(
                                                parent_id, cls.CREATE_SCRAP_GROUP_MODAL_OPEN_BUTTON_ID
                                            ),
                                        ),
                                    ],
                                    className="inputs-group",
                                )
                            ],
                        ),
                        create_input_wrapper(
                            cls.CHOOSE_LOADING_STATIONS,
                            [
                                sdc.get_child_layout(parent_id, cls.loading_stations),
                            ],
                        ),
                        create_input_wrapper(
                            cls.COMMENT,
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.COMMENT_ID), debounce=True),
                            ],
                        ),
                        sdc.get_child_layout(parent_id, cls.affected_limit_id),
                        sdc.get_child_layout(parent_id, cls.last_change),
                    ]
                ),
                create_modal_footer(sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), ""),
                sdc.get_child_layout(parent_id, cls.create_scrap_group_modal),
            ],
            centered=True,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            keyboard=False,
        )

    @property
    def update(self) -> bool:
        return self.affected_limit_id.data != -1

    def update_group(self, ctx: SettingsAppFiltersSource) -> None:
        group = ScrapExclusiveGroupSetting.objects.get(id=self.affected_limit_id.data)

        group.comment = self.comment
        group.name = self.name
        group.scrap_types = self.scrap_groups.selected_value_or_raise
        group.created_by = ctx.logged_user
        group.save()

        # remove all associated loading stations
        group.loadingstation_set.clear()
        # update relationship between selected limit and loading stations
        group.loadingstation_set.set(self.loading_stations.selected_values_or_raise)

    def create_group(self, ctx: SettingsAppFiltersSource) -> None:
        new_group = ScrapExclusiveGroupSetting(
            comment=self.comment,
            created_by=ctx.logged_user,
            name=self.name,
            scrap_types=self.scrap_groups.selected_value_or_raise,
        )
        new_group.save()
        new_group.loadingstation_set.set(self.loading_stations.selected_values_or_raise)  # type: ignore

    def confirm_event(self, _: int, ctx: SettingsAppFiltersSource) -> "ExclusiveGroupModalViewModel":
        if self.update:
            self.update_group(ctx)
        else:
            self.create_group(ctx)
        return self.reset_to_initial_state(True)

    def reset_to_initial_state(self, data_changed: bool) -> "ExclusiveGroupModalViewModel":
        last_change = time.time_ns() if data_changed else self.last_change.data
        return ExclusiveGroupModalViewModel(
            last_change=DataStoreViewModel(last_change)  # type: ignore #[SDC MYPY BUG]
        )

    def close_modal(self, _: int) -> "ExclusiveGroupModalViewModel":
        return self.reset_to_initial_state(False)

    def name_validation(self) -> str:
        if not self.name:
            return self.NAME_MUST_BE_FILLED
        return ""

    def are_inputs_invalid(self) -> bool:
        return not (
            self.loading_stations.has_selected_options and self.scrap_groups.has_selected_option and self.name
        )

    def open_create_scrap_group_modal(self, _: int) -> "ExclusiveGroupModalViewModel":
        return attr.evolve(
            self, create_scrap_group_modal=self.create_scrap_group_modal.set_input_values_and_open()
        )

    def set_input_values_and_open(
        self, ctx: SettingsAppFiltersSource, data: Optional[ExclusiveGroupSettingsTableRowViewModel] = None
    ) -> "ExclusiveGroupModalViewModel":
        if data is None:
            return ExclusiveGroupModalViewModel(  # type: ignore #[SDC MYPY BUG]
                is_open=True,
                loading_stations=self.loading_stations.set_selected_option(ctx.selected_loading_station_id),
                scrap_groups=self.scrap_groups.set_selected_option(None),
            )
        return ExclusiveGroupModalViewModel(
            is_open=True,
            name=data.name,
            comment=data.comment,
            scrap_groups=attr.evolve(self.scrap_groups, selected_option=data.scrap_types_id),
            loading_stations=attr.evolve(
                self.loading_stations, selected_options=data.affected_loading_stations_ids
            ),
            affected_limit_id=DataStoreViewModel(data.limit_id),  # type: ignore #[SDC MYPY BUG]
            confirm_button_label=self.UPDATE_GROUP,
        )
