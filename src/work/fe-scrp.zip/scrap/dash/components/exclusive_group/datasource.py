from functools import lru_cache
from typing import Optional, Protocol, Sequence

from scrap.dash.components import TABLE_DATETIME_FORMAT, get_scrap_groups_str
from scrap.dash.components.exclusive_group import ExclusiveGroupSettingsTableRowViewModel
from scrap.models import ScrapExclusiveGroupSetting


class ExclusiveLimitsTableDataSource(Protocol):
    def get_exclusive_limits_for_loading_station(
        self,
        loading_station_id: Optional[int],
    ) -> Sequence[ExclusiveGroupSettingsTableRowViewModel]: ...


@lru_cache(maxsize=128)
def get_exclusive_limits(
    loading_station_id: Optional[int], timestamp: int  # pylint: disable=unused-argument
) -> Sequence[ExclusiveGroupSettingsTableRowViewModel]:
    if loading_station_id is None:
        return []
    exclusive_groups = (
        ScrapExclusiveGroupSetting.objects.select_related("scrap_types", "created_by")
        .prefetch_related("scrap_types__scrap_ids", "loadingstation_set")
        .filter(loadingstation__pk=loading_station_id)
    )
    return [
        ExclusiveGroupSettingsTableRowViewModel(
            limit_id=group.id,
            name=group.name,
            scrap_types=get_scrap_groups_str(group.scrap_types),
            created_at=group.created_at.strftime(TABLE_DATETIME_FORMAT),
            created_by=group.created_by.username,
            comment=group.comment,
            affected_loading_stations_ids=group.affected_loading_stations_ids,
            scrap_types_id=group.scrap_types.id,
        )
        for group in exclusive_groups
    ]


class CachedDbExclusiveLimitsTableDataSource:
    def __init__(self, timestamp: int):
        self.timestamp = timestamp

    def get_exclusive_limits_for_loading_station(
        self,
        loading_station_id: Optional[int],
    ) -> Sequence[ExclusiveGroupSettingsTableRowViewModel]:
        return get_exclusive_limits(loading_station_id, self.timestamp)


@lru_cache(maxsize=16)
def get_data_source(timestamp: int) -> ExclusiveLimitsTableDataSource:
    return CachedDbExclusiveLimitsTableDataSource(timestamp)
