from typing import Dict, Tuple, Union

import attr


@attr.s(frozen=True, auto_attribs=True, slots=True)
class ExclusiveGroupSettingsTableRowViewModel:
    limit_id: int
    name: str
    created_at: str
    created_by: str
    scrap_types_id: int
    affected_loading_stations_ids: Tuple[int, ...] = ()
    scrap_types: str = ""
    comment: str = ""
    edit: str = "📝"
    delete: str = "❌"

    @property
    def dash_table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)  # type: ignore
        # TODO remove type ignore with new mypy version
