import time
from typing import Any, Dict, List, Sequence, Union

import attr
from dash import html
from dash.dash_table import DataTable
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.exclusive_group import ExclusiveGroupSettingsTableRowViewModel
from scrap.dash.components.exclusive_group.datasource import ExclusiveLimitsTableDataSource, get_data_source
from scrap.dash.components.exclusive_group.modal import ExclusiveGroupModalViewModel
from scrap.dash.components.modals.delete_confirm import DeleteExclusiveGroupConfirmModalViewModel
from scrap.dash.components.table_common import table_wrapper_with_header

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class ExclusiveGroupSettingsTableViewModel:
    # Initial setup
    TOOLTIP_CHARACTER_THRESHOLD = 18
    HIDDEN_ON_LOAD = True
    # Components ID
    COMPONENT_ID = "table"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    TABLE_WRAPPER_ID = "dash-table-wrapper"
    ADD_NEW_GROUP_ID = "add-new-group"
    HEADER_MSG_ID = "message"
    DELETE_COLUMN_ID = "delete"
    EDIT_COLUMN_ID = "edit"
    SCRAP_TYPES_COLUMN_ID = "scrap_types"
    # User friendly msg
    NAME = "Skupiny nemiešateľných šrotov"
    ADD = "Pridať skupinu"
    DELETE = "Odstrániť skupinu"
    MISSING_DATA = "V databáze neboli nájdené žiadné dáta."

    data_load_time: int = attr.ib(factory=time.time_ns, converter=int)
    modal: ExclusiveGroupModalViewModel = sdc.child_component(
        "exclusive-group-modal", default=ExclusiveGroupModalViewModel()
    )
    delete_confirm_modal: DeleteExclusiveGroupConfirmModalViewModel = sdc.child_component(
        "delete-confirm", default=DeleteExclusiveGroupConfirmModalViewModel()
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(
                cls.COMPONENT_ID,
                "active_cell",
                ExclusiveGroupSettingsTableViewModel.control_active_cell,
            ),
            sdc.InputField(cls.ADD_NEW_GROUP_ID, "n_clicks", ExclusiveGroupSettingsTableViewModel.open_modal),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", ExclusiveGroupSettingsTableViewModel.to_table_data),
            sdc.OutputField(
                cls.COMPONENT_ID, "tooltip_data", ExclusiveGroupSettingsTableViewModel.to_tooltip_data
            ),
            sdc.OutputField(
                cls.COMPONENT_WRAPPER_ID, "hidden", ExclusiveGroupSettingsTableViewModel.is_hidden
            ),
            sdc.OutputField(
                cls.HEADER_MSG_ID, "children", ExclusiveGroupSettingsTableViewModel.get_table_msg
            ),
            sdc.OutputField(
                cls.TABLE_WRAPPER_ID, "hidden", ExclusiveGroupSettingsTableViewModel.is_table_empty
            ),
            sdc.OutputField(
                cls.COMPONENT_ID, "active_cell", lambda _: None
            ),  # Reset active cell makes it possible to click on cell more then once
        )

    @classmethod
    def get_exclusive_scrap_table(cls, table_id: str, dash_table_wrapper_id: str) -> html.Div:
        return html.Div(
            DataTable(
                columns=[
                    {"name": "", "id": cls.EDIT_COLUMN_ID, "type": "text"},
                    {"name": "Názov", "id": "name", "type": "text"},
                    {"name": "Typy šrotov", "id": cls.SCRAP_TYPES_COLUMN_ID, "type": "text"},
                    {"name": "Komentár", "id": "comment", "type": "text"},
                    # {"name": "Vytvorené dňa", "id": "created_at", "type": "datetime"},
                    # {"name": "Vytvoril", "id": "created_by", "type": "text"},
                    {"name": "", "id": cls.DELETE_COLUMN_ID, "type": "text"},
                ],
                data=[],
                editable=False,
                fill_width=True,
                id=table_id,
                tooltip_delay=0,
                tooltip_duration=None,
            ),
            id=dash_table_wrapper_id,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return table_wrapper_with_header(
            cls.get_exclusive_scrap_table(
                sdc.create_id(parent_id, cls.COMPONENT_ID), sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID)
            ),
            cls.NAME,
            cls.ADD,
            sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
            sdc.create_id(parent_id, cls.HEADER_MSG_ID),
            sdc.create_id(parent_id, cls.ADD_NEW_GROUP_ID),
            cls.HIDDEN_ON_LOAD,
            [
                sdc.get_child_layout(parent_id, cls.modal),
                sdc.get_child_layout(parent_id, cls.delete_confirm_modal),
            ],
        )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time, self.modal.last_change.data, self.delete_confirm_modal.last_change.data
        )

    @property
    def data_source(self) -> ExclusiveLimitsTableDataSource:
        return get_data_source(self.last_change)

    def rows(self, ctx: SettingsAppFiltersSource) -> Sequence[ExclusiveGroupSettingsTableRowViewModel]:
        return get_data_source(self.last_change).get_exclusive_limits_for_loading_station(
            ctx.selected_loading_station_id
        )

    def to_table_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, Union[str, float]]]:
        return [row.dash_table_row for row in self.rows(ctx)]

    def to_tooltip_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, str]]:
        return [
            {
                self.SCRAP_TYPES_COLUMN_ID: (
                    row.scrap_types if len(row.scrap_types) > self.TOOLTIP_CHARACTER_THRESHOLD else ""
                )
            }
            for row in self.rows(ctx)
        ]

    def __open_delete_confirm_modal(
        self, row_view_model: ExclusiveGroupSettingsTableRowViewModel
    ) -> "ExclusiveGroupSettingsTableViewModel":
        return attr.evolve(
            self,
            delete_confirm_modal=DeleteExclusiveGroupConfirmModalViewModel(  # type: ignore #[SDC MYPY BUG]
                is_open=True,
                is_action_impossible=False,
                affected_id=DataStoreViewModel(row_view_model.limit_id),  # type: ignore #[SDC MYPY BUG]
                message=f"Pozor snažíte sa vymazať exkluzívnu skupinu šrotov s názvom {row_view_model.name}!"
                + " Naozaj chcete túto skupinu odstrániť?",
            ),
        )

    def control_active_cell(
        self, active_cell: Dict[str, Any], ctx: SettingsAppFiltersSource
    ) -> "ExclusiveGroupSettingsTableViewModel":
        if active_cell is None:
            return self
        row_view_model = self.rows(ctx)[active_cell["row"]]
        active_column_id = active_cell["column_id"]
        if active_column_id == self.DELETE_COLUMN_ID:
            return self.__open_delete_confirm_modal(row_view_model)
        if active_column_id == self.EDIT_COLUMN_ID:
            return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx, row_view_model))
        return self

    def open_modal(self, _: int, ctx: SettingsAppFiltersSource) -> "ExclusiveGroupSettingsTableViewModel":
        return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx))

    def get_table_msg(self, ctx: SettingsAppFiltersSource) -> str:
        if not self.rows(ctx):
            return self.MISSING_DATA
        return ""

    def is_table_empty(self, ctx: SettingsAppFiltersSource) -> bool:
        return not self.rows(ctx)

    def is_hidden(self, ctx: SettingsAppFiltersSource) -> bool:
        return ctx.selected_loading_station_id is None
