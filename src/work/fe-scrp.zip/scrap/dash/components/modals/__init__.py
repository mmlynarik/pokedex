from typing import Any, Collection

import dash_bootstrap_components as dbc
from dash import html

# class names
INPUT_ROW_CLASSNAME = "inline-input"
INPUTS_ROW_CLASSNAME = "inline-inputs"
INPUT_TEXT_STYLE_CLASSNAME = "text-style-input"


def create_input_wrapper(label: str, inputs: Collection[Any]) -> html.Div:
    return html.Div(
        children=[dbc.Label(children=label), *inputs],
        className=INPUT_ROW_CLASSNAME if len(inputs) == 1 else INPUTS_ROW_CLASSNAME,
    )


def create_modal_header(
    name_input_id: str, close_button_id: str, validation_msg_id: str, debounce: bool = True
) -> html.Div:
    return html.Div(
        children=[
            html.Div(
                children=[
                    dbc.Input(
                        className=INPUT_TEXT_STYLE_CLASSNAME,
                        debounce=debounce,
                        id=name_input_id,
                    ),
                    dbc.Button(color="link", id=close_button_id, n_clicks=0),
                ],
                className="modal-header-inputs",
            ),
            html.Div(children="", className="modal-header-msg", id=validation_msg_id),
        ],
        className="modal-header",
    )


def create_modal_label_header(modal_label: str, close_button_id: str) -> html.Div:
    return html.Div(
        children=[dbc.Label(modal_label), dbc.Button(color="link", id=close_button_id, n_clicks=0)],
        className="modal-header",
    )


def create_modal_footer(confirm_button_id: str, button_label: str) -> dbc.ModalFooter:
    return dbc.ModalFooter(
        children=dbc.Button(children=button_label, color="success", id=confirm_button_id, n_clicks=0),
    )


def create_modal_footer_with_delete_button(
    confirm_button_id: str, confirm_label: str, delete_button_id: str, delete_label: str
) -> dbc.ModalFooter:
    return dbc.ModalFooter(
        children=[
            dbc.Button(delete_label, color="danger", id=delete_button_id, n_clicks=0),
            dbc.Button(confirm_label, color="success", id=confirm_button_id, n_clicks=0),
        ],
    )
