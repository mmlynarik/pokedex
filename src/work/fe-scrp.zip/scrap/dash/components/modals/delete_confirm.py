from abc import ABC, abstractmethod
import time
from typing import Type

import attr
from ussksdc.components.data_store import DataStoreViewModel
from ussksdc.components.modals import ConfirmModalViewModel
from scrap.models import (
    GradeGroup,
    ScrapGroup,
    RelaxableLowerSummingLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScrapExclusiveGroupSetting,
    RelaxableRiskLimitSetting,
)
from django.db.models import Model as DjangoModel


@attr.s(frozen=True, slots=True)
class DeleteConfirmModalViewModel(ConfirmModalViewModel, ABC):
    @property
    @abstractmethod
    def affected_model(self) -> Type[DjangoModel]: ...

    def confirm_event(self, _: int) -> "DeleteConfirmModalViewModel":
        if self.affected_id.data != -1:
            self.affected_model.objects.get(id=self.affected_id.data).delete()
        return attr.evolve(
            self, is_open=False, last_change=DataStoreViewModel(time.time_ns())  # type: ignore #[SDC MYPY BUG]
        )


@attr.s(frozen=True, slots=True)
class DeleteRiskLimitConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = RelaxableRiskLimitSetting


@attr.s(frozen=True, slots=True)
class DeleteLowerSummingLimitConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = RelaxableLowerSummingLimitSetting


@attr.s(frozen=True, slots=True)
class DeleteUpperSummingLimitConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = RelaxableUpperSummingLimitSetting


@attr.s(frozen=True, slots=True)
class DeleteExclusiveGroupConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = ScrapExclusiveGroupSetting


@attr.s(frozen=True, slots=True)
class DeleteScrapGroupConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = ScrapGroup


@attr.s(frozen=True, slots=True)
class DeleteGradeGroupConfirmModalViewModel(DeleteConfirmModalViewModel):
    affected_model = GradeGroup
