from typing import List, Optional, TypedDict

from dash import dash_table
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE

from . import get_scrap_type_label


class ScrapOptimizationResultCompareTableRow(TypedDict):
    label: str
    scrap_type: str
    recommended_weight: Optional[float]
    loaded_weight: Optional[float]


ScrapOptimizationResultCompareTableData = List[ScrapOptimizationResultCompareTableRow]


def create_optimization_result_table_compare_row(
    scrap_type: str, recommended_weight: float, loaded_weight: float
) -> ScrapOptimizationResultCompareTableRow:
    return {
        "label": get_scrap_type_label(scrap_type),
        "scrap_type": scrap_type,
        "recommended_weight": recommended_weight,
        "loaded_weight": loaded_weight,
    }


def create_scrap_optimization_result_compare_table(table_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=[
            {"name": "Typ šrotu", "id": "label", "type": "text", "editable": False},
            {"name": "Odporúčanie [kg]", "id": "recommended_weight", "type": "number", "editable": False},
            {"name": "Reálne naložené [kg]", "id": "loaded_weight", "type": "number", "editable": False},
        ],
        data=[],
        style_data_conditional=DATA_TEXT_STYLE,
        style_cell_conditional=[{"if": {"column_id": "label"}, "width": "80px"}],
        style_table={"padding-left": "16px", "padding-right": "16px", "margin-top": "10px"},
        style_cell=CELL_STYLE,
        style_header=TABLE_HEADER_STYLE,
    )
