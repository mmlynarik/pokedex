from typing import Tuple, Dict, Union
import attr
import pandas as pd
from scrap.models import ScrapParsedData, ScrapState

from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_mapping.datasource import (
    ScrapStateTableDataSource,
)


@attr.frozen
class ScrapStateOverallTableDataSource:
    scrap_type: str
    scrap_state: float
    scrap_on_the_way: float

    @property
    def table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)

    @property
    def as_scrap_state_data(self) -> ScrapState:
        return ScrapState(
            scrap_type=self.scrap_type,
            state_weight=self.scrap_state,
            on_the_way_weight=self.scrap_on_the_way,
        )


def convert_to_scrap_state_overall_table_data(
    scrap_mapping: Tuple[ScrapStateTableDataSource, ...],
    scrap_state: Tuple[ScrapParsedData, ...],
    scrap_on_the_way: Tuple[ScrapParsedData, ...],
) -> Tuple[ScrapStateOverallTableDataSource, ...]:
    if not scrap_state or not scrap_on_the_way:
        return ()
    flattened_mapping = {}
    if scrap_mapping:
        flattened_mapping = {row.input_scrap_type: row.scrap_type for row in scrap_mapping}
    df_scrap_state = pd.DataFrame(attr.asdict(record) for record in scrap_state)
    df_scrap_state["scrap_type"] = df_scrap_state["scrap_type"].combine_first(
        df_scrap_state["input_scrap_type"].apply(flattened_mapping.get)
    )
    df_scrap_state_grouped = df_scrap_state.groupby("scrap_type")["weight"].sum().reset_index()
    df_scrap_on_the_way = pd.DataFrame(attr.asdict(record) for record in scrap_on_the_way)
    df_scrap_on_the_way["scrap_type"] = df_scrap_on_the_way["scrap_type"].combine_first(
        df_scrap_on_the_way["input_scrap_type"].apply(flattened_mapping.get)
    )
    df_scrap_on_the_way_grouped = df_scrap_on_the_way.groupby("scrap_type")["weight"].sum().reset_index()
    df_overall = (
        pd.merge(
            df_scrap_state_grouped,
            df_scrap_on_the_way_grouped,
            on="scrap_type",
            how="outer",
            suffixes=("_state", "_on_the_way"),
        )
        .fillna(0.0)
        .sort_values(["scrap_type"])
        .reset_index()
    )
    return tuple(
        ScrapStateOverallTableDataSource(
            scrap_type=row.scrap_type, scrap_state=row.weight_state, scrap_on_the_way=row.weight_on_the_way
        )
        for _, row in df_overall.iterrows()
    )
