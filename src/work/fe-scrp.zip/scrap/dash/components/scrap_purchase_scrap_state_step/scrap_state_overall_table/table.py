from typing import Any, Dict, List, Tuple

import attr
import ussksdc as sdc
from dash import html
from dash_ag_grid import AgGrid
from scrap.dash.components.protocols.create_scrap_purchase import CreateScrapPurchaseSource
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_overall_table.datasource import (
    ScrapStateOverallTableDataSource,
    convert_to_scrap_state_overall_table_data,
)
from scrap.models import converter


@attr.frozen
class ScrapStateOverallTableViewModel:
    TABLE_ID = "table"

    WRAPPER_ID = "wrapper"

    SCRAP_TYPE_COLUMN_ID = "scrap_type"
    SCRAP_STATE_COLUMN_ID = "scrap_state"
    SCRAP_ON_THE_WAY_COLUMN_ID = "scrap_on_the_way"

    SCRAP_TYPE_COLUMN = "Typ šrotu"
    SCRAP_STATE_COLUMN = "Zásoby"
    SCRAP_ON_THE_WAY_COLUMN = "Na ceste"

    DEFAULT_TABLE_HIDDEN_STATE = True

    unstructured_data: List[Dict[str, str]] = sdc.only_state_binding(TABLE_ID, "rowData", default=[])

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.WRAPPER_ID, "hidden", cls.doesnt_have_all_data),
            sdc.OutputField(cls.TABLE_ID, "rowData", cls.set_table_data),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        number_value_formater = {
            "valueFormatter": {"function": "d3.format(' .4f')(params.value) + ' t'"},
        }
        return html.Div(
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
            hidden=cls.DEFAULT_TABLE_HIDDEN_STATE,
            children=[
                AgGrid(
                    id=sdc.create_id(parent_id, cls.TABLE_ID),
                    className="ag-theme-alpine-dark",
                    columnDefs=[
                        {"headerName": cls.SCRAP_TYPE_COLUMN, "field": cls.SCRAP_TYPE_COLUMN_ID},
                        {
                            "headerName": cls.SCRAP_STATE_COLUMN,
                            "field": cls.SCRAP_STATE_COLUMN_ID,
                            **number_value_formater,
                        },
                        {
                            "headerName": cls.SCRAP_ON_THE_WAY_COLUMN,
                            "field": cls.SCRAP_ON_THE_WAY_COLUMN_ID,
                            **number_value_formater,
                        },
                    ],
                    defaultColDef={"sortable": True, "filter": True},
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={
                        "pagination": True,
                        "paginationPageSize": 5,
                    },
                )
            ],
        )

    @property
    def data(self) -> Tuple[ScrapStateOverallTableDataSource, ...]:
        return tuple(converter.structure(d, ScrapStateOverallTableDataSource) for d in self.unstructured_data)

    def set_table_data(self, ctx: CreateScrapPurchaseSource) -> Tuple[Dict[str, Any], ...]:
        return tuple(
            d.table_row
            for d in convert_to_scrap_state_overall_table_data(
                ctx.scrap_mapping, ctx.scrap_state_parsed_data, ctx.scrap_on_the_way_parsed_data
            )
        )

    def doesnt_have_all_data(self, ctx: CreateScrapPurchaseSource) -> bool:
        """
        The function returns a bool value for the property hidden. It's used to
        hide the overall scrap table when we don't have data of the scrap state
        or scrap on the way or when we have some not mapped scraps.
        """
        return (
            not ctx.scrap_state_parsed_data
            or not ctx.scrap_on_the_way_parsed_data
            or len([data for data in ctx.scrap_mapping if data.scrap_type == None]) != 0
        )
