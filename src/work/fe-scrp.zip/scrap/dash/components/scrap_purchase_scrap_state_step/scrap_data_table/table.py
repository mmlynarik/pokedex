from typing import Tuple

import attr
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from dash import html

from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_data_table.datasource import (
    ScrapDataTableDataType,
    convert_scrap_parsed_data_to_table_datasource,
    get_table_content,
)
from scrap.models import ScrapParsedData
from dash_ag_grid import AgGrid


@attr.frozen
class ScrapDataTableViewModel:
    # Component ids
    COMPONENT_ID = "scrap-data"
    TABLE_ID = "table"
    SCRAP_TYPE_COLUMN_ID = "input_scrap_type"
    SCRAP_WEIGHT_COLUMN_ID = "weight"
    # User friendly msg
    SCRAP_TYPE_COLUMN = "Typ šrotu"
    SCRAP_WEIGHT_COLUMN = "Množstvo"

    TABLE_HIDDEN_ON_LOAD = True

    data: ScrapDataTableDataType = sdc.binding(
        TABLE_ID,
        "rowData",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=[],
    )
    hidden: bool = sdc.clientside_one_way_binding_with_state(
        COMPONENT_ID, "hidden", default=TABLE_HIDDEN_ON_LOAD
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            hidden=cls.TABLE_HIDDEN_ON_LOAD,
            children=AgGrid(
                id=sdc.create_id(parent_id, cls.TABLE_ID),
                className="ag-theme-alpine-dark",
                columnDefs=[
                    {"headerName": cls.SCRAP_TYPE_COLUMN, "field": cls.SCRAP_TYPE_COLUMN_ID},
                    {
                        "headerName": cls.SCRAP_WEIGHT_COLUMN,
                        "field": cls.SCRAP_WEIGHT_COLUMN_ID,
                        "valueFormatter": {"function": "d3.format(' .4f')(params.value) + ' t'"},
                    },
                ],
                defaultColDef={"sortable": True, "filter": True},
                columnSize="responsiveSizeToFit",
                dashGridOptions={
                    "pagination": True,
                    "paginationAutoPageSize": True,
                    "singleClickEdit": True,
                },
            ),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.toggle_table_visibility()),
            sdc.JsCodeField(*cls.has_data()),
        )

    @classmethod
    def toggle_table_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleTableVisibility",
            ["viewModel"],
            """
            var updatedVM = {...this};
            if (updatedVM.hidden == null)
                updatedVM.hidden = true;
            updatedVM.hidden = !updatedVM.hidden;
            return updatedVM;
            """,
        )

    @classmethod
    def has_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasData",
            [],
            "return (this.data != null && this.data.length > 0)",
        )

    def set_data(self, data: Tuple[ScrapParsedData, ...]) -> "ScrapDataTableViewModel":
        return attr.evolve(
            self,
            data=get_table_content(convert_scrap_parsed_data_to_table_datasource(data)),
        )
