from typing import Dict, Tuple, Union

import attr

from scrap.models import ScrapParsedData


@attr.frozen
class ScrapDataTableDataSource:
    input_scrap_type: str
    weight: float

    @property
    def table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)


ScrapDataTableDataType = Tuple[Dict[str, Union[str, float]], ...]


def convert_scrap_parsed_data_to_table_datasource(
    parsed_data: Tuple[ScrapParsedData, ...]
) -> Tuple[ScrapDataTableDataSource, ...]:
    return tuple(
        ScrapDataTableDataSource(input_scrap_type=parsed_row.input_scrap_type, weight=parsed_row.weight)
        for parsed_row in parsed_data
    )


def get_table_content(data: Tuple[ScrapDataTableDataSource, ...]) -> ScrapDataTableDataType:
    return tuple(scrap_type.table_row for scrap_type in data)
