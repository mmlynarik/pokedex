from typing import Optional

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from dash_iconify import DashIconify


@attr.frozen
class WeightInputVM:
    INPUT_ID = "weight-input"

    weight: Optional[int] = sdc.binding(
        INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    description: Optional[str] = sdc.one_way_binding(INPUT_ID, "description", default=None)
    label: Optional[str] = sdc.one_way_binding(INPUT_ID, "label", default=None)
    step: int = sdc.one_way_binding(INPUT_ID, "step", default=1)

    @classmethod
    def create(
        cls, weight: Optional[int] = None, label: str = "", desc: Optional[str] = None, step: int = 1
    ) -> "WeightInputVM":
        return cls(
            weight=weight,
            description=desc,
            label=label,
            step=step,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return dmc.NumberInput(
            id=sdc.create_id(parent_id, cls.INPUT_ID),
            debounce=700,
            step=1,
            min=0,
            icon=DashIconify(icon="fa6-solid:weight-scale"),
        )
