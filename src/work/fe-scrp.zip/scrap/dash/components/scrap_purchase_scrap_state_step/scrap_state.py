from typing import Tuple, Optional
from string import Template
import attr
import ussksdc as sdc
from dash import html
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_mapping.table import (
    ScrapStateMappingVM,
)
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_overall_table.table import (
    ScrapStateOverallTableViewModel,
)
from scrap.dash.components.scrap_purchase_scrap_state_step.upload_excel_files.pile_evidence import (
    PileEvidenceLoadVM,
)
from scrap.dash.components.scrap_purchase_scrap_state_step.upload_excel_files.scrap_on_the_way import (
    ScrapOnTheWayVM,
)
from scrap.dash.components.scrap_purchase_scrap_state_step.weight_input import WeightInputVM
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
import dash_mantine_components as dmc


@attr.frozen
class PurchaseScrapStateVM:
    COMPONENT_ID = "state-step"
    PILE_EVIDENCE_ID = "pile-evidence"
    SCRAP_ON_THE_WAY_ID = "scrap-on-the-way"
    SCRAP_STOCK_ID = "scrap-stock-objective"
    MEAN_SCRAP_ID = "mean-scrap"

    SCRAP_STOCK_LABEL = "Cieľová zásoba šrotu"
    MEAN_SCRAP_WEIGHT_LABEL = "Hmotnosť šrotovej vsádzky (očakávaná)"

    DEFAULT_MEAN_SCRAP_WEIGHT = 38  # tons

    pile_evidence: PileEvidenceLoadVM = sdc.child_component(PILE_EVIDENCE_ID, factory=PileEvidenceLoadVM)
    scrap_on_the_way: ScrapOnTheWayVM = sdc.child_component(SCRAP_ON_THE_WAY_ID, factory=ScrapOnTheWayVM)

    scrap_stock_objective: WeightInputVM = sdc.child_component(SCRAP_STOCK_ID, factory=WeightInputVM)
    mean_scrap: WeightInputVM = sdc.child_component(MEAN_SCRAP_ID, factory=WeightInputVM)
    scrap_overall_table: ScrapStateOverallTableViewModel = sdc.child_component(
        "overall", factory=ScrapStateOverallTableViewModel
    )
    scrap_mapping: ScrapStateMappingVM = sdc.child_component("mapping", factory=ScrapStateMappingVM)

    @classmethod
    def create(
        cls, scrap_stock_objective: Optional[int] = None, mean_scrap_weight: Optional[int] = None
    ) -> "PurchaseScrapStateVM":
        return cls(
            pile_evidence=PileEvidenceLoadVM.create(),
            scrap_on_the_way=ScrapOnTheWayVM.create(),
            scrap_stock_objective=WeightInputVM.create(
                weight=scrap_stock_objective,
                label=cls.SCRAP_STOCK_LABEL,
                desc="Váhu uvádzajte v tonách",
                step=1000,
            ),
            mean_scrap=WeightInputVM.create(
                weight=mean_scrap_weight if mean_scrap_weight is not None else cls.DEFAULT_MEAN_SCRAP_WEIGHT,
                label=cls.MEAN_SCRAP_WEIGHT_LABEL,
                desc="Váhu uvádzajte v tonách",
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.pile_evidence),
                sdc.get_child_layout(parent_id, cls.scrap_mapping),
                sdc.get_child_layout(parent_id, cls.scrap_on_the_way),
                dmc.Group(
                    [
                        sdc.get_child_layout(parent_id, cls.scrap_stock_objective),
                        sdc.get_child_layout(parent_id, cls.mean_scrap),
                    ],
                    grow=True,
                ),
                sdc.get_child_layout(parent_id, cls.scrap_overall_table),
            ],
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.mising_fields()),)

    @classmethod
    def mising_fields(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMissingFields",
            [],
            Template(
                """
            var missingFields = [];
            if (!this.mean_scrap.weight)
                missingFields.push('${mean_scrap}');
            if (!this.scrap_stock_objective.weight)
                missingFields.push('${scrap_stock}');
            if (!this.pile_evidence.table.hasData())
                missingFields.push('${pile_evidence}');
            if (!this.scrap_on_the_way.table.hasData())
                missingFields.push('${scrap_on_the_way}');
            if (this.scrap_mapping.unstructured_data.length !== 0)
                missingFields.push('${scrap_mapping}');
            return missingFields;
            """
            ).substitute(
                mean_scrap=cls.MEAN_SCRAP_WEIGHT_LABEL,
                scrap_stock=cls.SCRAP_STOCK_LABEL,
                pile_evidence=PileEvidenceLoadVM.TITLE,
                scrap_on_the_way=ScrapOnTheWayVM.TITLE,
                scrap_mapping=ScrapStateMappingVM.TITLE,
            ),
        )
