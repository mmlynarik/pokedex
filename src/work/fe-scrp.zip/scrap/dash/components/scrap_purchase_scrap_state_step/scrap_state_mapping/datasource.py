from typing import Dict, Optional, Tuple, Union

import attr
from scrap.models import ScrapParsedData, SupportedScrapTypeMapping

from scrap_core import ScrapType


@attr.frozen
class ScrapStateTableDataSource:
    input_scrap_type: str = attr.ib(default="")
    scrap_type: Optional[ScrapType] = attr.ib(default=None)

    @property
    def table_row(self) -> Dict[str, Union[str, ScrapType]]:
        return attr.asdict(self)

    @property
    def as_db_model(self) -> Optional[SupportedScrapTypeMapping]:
        if not self.input_scrap_type or self.scrap_type is None:
            return None
        return SupportedScrapTypeMapping(scrap_type=self.scrap_type, input_scrap_type=self.input_scrap_type)


ScrapMappingTableDataType = Tuple[Dict[str, Union[str, ScrapType]], ...]


def convert_to_scrap_state_table_data(
    parsed_data: Tuple[ScrapParsedData, ...]
) -> Tuple[ScrapStateTableDataSource, ...]:
    return tuple(
        ScrapStateTableDataSource(scrap_type=None, input_scrap_type=parsed_row.input_scrap_type)
        for parsed_row in parsed_data
        if parsed_row.scrap_type is None
    )
