from typing import Tuple

from ussksdc.core.helper import generate_clientside_callback
from ussksdc.core.datamodel import JsCode
import attr
import ussksdc as sdc
from dash import html, dcc
from scrap_core import SUPPORTED_SCRAP_TYPES_SET
from scrap.dash.components.protocols.create_scrap_purchase import CreateScrapPurchaseSource

from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_mapping.datasource import (
    ScrapMappingTableDataType,
    convert_to_scrap_state_table_data,
    ScrapStateTableDataSource,
)
from scrap.models import converter
import dash_mantine_components as dmc
from dash_ag_grid import AgGrid


@attr.frozen
class ScrapStateMappingVM:
    MODAL_ID = "modal"
    TABLE_ID = "table"
    SCRAP_TYPE_COLUMN_ID = "scrap_type"
    INPUT_SCRAP_TYPE_COLUMN_ID = "input_scrap_type"
    SAVE_BUTTON_ID = "save"
    OPEN_MODAL_BTN_ID = "open-modal"
    OPEN_MODAL_BTN_WRAPPER_ID = "open-modal-wrapper"
    DATA_STORE_ID = "data"

    TITLE = "Nenamapované typy šrotu"
    SCRAP_TYPE_COLUMN = "Priradiť typ šrotu"
    INPUT_SCRAP_TYPE_COLUMN = "Načítaná hodnota"
    SAVE_BUTTON = "Uložiť mapovanie šrotov"

    unstructured_data: ScrapMappingTableDataType = sdc.clientside_only_state_binding(
        DATA_STORE_ID, "data", default=[]
    )
    table_data = sdc.only_state_binding(TABLE_ID, "rowData", default=[])
    opened: bool = sdc.one_way_binding(MODAL_ID, "opened", default=False)

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.DATA_STORE_ID, "data", cls.store_table_data),
            sdc.OutputField(cls.OPEN_MODAL_BTN_WRAPPER_ID, "className", cls.set_visibility),
            sdc.OutputFieldClientSide(cls.TABLE_ID, "rowData", *cls.set_table_data()),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.SAVE_BUTTON_ID, "n_clicks", cls.save_mapped_data),
            sdc.InputField(cls.OPEN_MODAL_BTN_ID, "n_clicks", cls.open_modal),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                html.Div(
                    children=dmc.Button(
                        id=sdc.create_id(parent_id, cls.OPEN_MODAL_BTN_ID),
                        color="red",
                        variant="outline",
                        compact=True,
                        children="Nepodarilo sa napárovať všetky šroty, skús to ručne",
                    ),
                    id=sdc.create_id(parent_id, cls.OPEN_MODAL_BTN_WRAPPER_ID),
                ),
                dmc.Modal(
                    id=sdc.create_id(parent_id, cls.MODAL_ID),
                    centered=True,
                    title=cls.TITLE,
                    closeOnClickOutside=False,
                    closeOnEscape=False,
                    children=[
                        AgGrid(
                            id=sdc.create_id(parent_id, cls.TABLE_ID),
                            className="ag-theme-alpine-dark",
                            columnDefs=[
                                {
                                    "headerName": cls.INPUT_SCRAP_TYPE_COLUMN,
                                    "field": cls.INPUT_SCRAP_TYPE_COLUMN_ID,
                                    "editable": False,
                                },
                                {
                                    "headerName": cls.SCRAP_TYPE_COLUMN,
                                    "field": cls.SCRAP_TYPE_COLUMN_ID,
                                    "cellEditor": "agSelectCellEditor",
                                    "cellEditorParams": {
                                        "values": list(sorted(map(str, SUPPORTED_SCRAP_TYPES_SET))),
                                    },
                                },
                            ],
                            columnSize="sizeToFit",
                            defaultColDef={"editable": True, "sortable": True},
                        ),
                        dmc.Button(
                            cls.SAVE_BUTTON,
                            id=sdc.create_id(parent_id, cls.SAVE_BUTTON_ID),
                        ),
                    ],
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.DATA_STORE_ID)),
            ]
        )

    @classmethod
    def set_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setTableData",
            ["viewModel"],
            "return [...new Set(viewModel.unstructured_data.map(JSON.stringify))].map(JSON.parse);",
        )

    @property
    def data(self) -> Tuple[ScrapStateTableDataSource, ...]:
        return [converter.structure(d, ScrapStateTableDataSource) for d in self.table_data]

    def has_not_mapped_scraps(self, ctx: CreateScrapPurchaseSource) -> bool:
        return len(ctx.scrap_state_parsed_data) > 0 and any(
            not parsed_row.scrap_type
            and (
                not self.data
                or any(
                    mapped_data.scrap_type is None
                    for mapped_data in self.data
                    if mapped_data.input_scrap_type == parsed_row.input_scrap_type
                )
            )
            for parsed_row in ctx.scrap_state_parsed_data
        )

    def set_visibility(self, ctx: CreateScrapPurchaseSource) -> str:
        return "" if self.has_not_mapped_scraps(ctx) else "invisible"

    def store_table_data(self, ctx: CreateScrapPurchaseSource):
        if self.has_not_mapped_scraps(ctx):
            return [data.table_row for data in convert_to_scrap_state_table_data(ctx.scrap_state_parsed_data)]
        return []

    def open_modal(self, _: int) -> bool:
        return attr.evolve(self, opened=True)

    def save_mapped_data(self, _: int, ctx: CreateScrapPurchaseSource) -> "ScrapStateMappingVM":
        ctx.models.supported_scrap_mapping.save_scrap_mapping(
            tuple(d.as_db_model for d in self.data if d.as_db_model is not None)
        )
        not_mapped_scraps = [converter.unstructure(d) for d in self.data if d.scrap_type is None]
        return attr.evolve(
            self,
            unstructured_data=not_mapped_scraps,
            opened=len(not_mapped_scraps) != 0,
        )
