from typing import Tuple

import attr
from scrap.dash.components.error_handler import ErrorHandlerMsg
from scrap.dash.components.scrap_purchase_scrap_state_step.upload_excel_files.base_component import (
    UploadFileVM,
)
from scrap.dash.components.scrap_purchase_scrap_state_step.upload_excel_files.parsers import (
    parse_scrap_on_the_way_excel_file,
)
from scrap.models import ScrapParsedData


@attr.frozen
class ScrapOnTheWayVM(UploadFileVM):
    TITLE = "Vyberte súbor so šrotom na ceste..."
    ERROR_MODAL_TITLE = "Chyby v súbore šroty na ceste"

    @classmethod
    def create(cls) -> "ScrapOnTheWayVM":
        return cls(title=cls.TITLE, error_msg_handler=ErrorHandlerMsg.create(title=cls.ERROR_MODAL_TITLE))

    @classmethod
    def parse_raw_excel_data(cls, raw_content: str) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
        return parse_scrap_on_the_way_excel_file(raw_content)
