from typing import Optional, Tuple

from scrap.imports import decode_uploaded_file, parse_scrap_on_the_way_file, parse_scrap_state_file
from scrap.models import ScrapParsedData


def convert_input_string_to_positive_float_or_none(str_num: Optional[str]) -> Optional[float]:
    if str_num is None:
        return None
    try:
        float_num = float(str_num)
        return float_num if float_num > 0.0 else None
    except ValueError:
        return None


def parse_scrap_state_excel_file(contents: str) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
    if not contents:
        return ()
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_state_file(excel_bytes)


def parse_scrap_on_the_way_excel_file(contents: str) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
    if not contents:
        return ()
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_on_the_way_file(excel_bytes)
