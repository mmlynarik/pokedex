from typing import Any, Dict, Optional, Tuple, TypeVar

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from dash_iconify import DashIconify
from scrap.imports import assign_scrap_type_to_scrap_state_data
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_data_table.table import (
    ScrapDataTableViewModel,
)
from scrap.dash.components.error_handler import ErrorHandlerMsg
from scrap.models import ScrapParsedData, converter
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from abc import ABC, abstractmethod

TUploadComponent = TypeVar("TUploadComponent", bound="UploadFileVM")


@attr.frozen
class UploadFileVM(ABC):
    # Component ids
    FILE_UPLOAD_ID = "file-upload"
    FILE_UPLOAD_TEXT_ID = "file-upload-text"
    FILE_CONTENT_ID = "file-upload-content"
    SHOW_DATA_BTN_ID = "file-upload-show-data"
    WRAPPER_ID = "file-upload-wrapper"
    BTN_WRAPPER_ID = "file-upload-btn-wrapper"
    HEADER_WRAPPER_ID = "file-upload-header-wrapper"
    TITLE_ID = "file-upload-title"
    # User friendly msg
    BTN_LABEL_SHOW = "Zobraziť načítané dáta"
    BTN_LABEL_HIDE = "Skryť načítané dáta"

    ACCEPTED_UPLOAD_FORMAT = [".xlsx", ".xls"]

    filename: Optional[str] = sdc.binding(
        FILE_UPLOAD_ID,
        "filename",
        ss_read=False,
        ss_state=True,
        ss_write=False,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    uploaded_file_content: Tuple[Dict[str, Any]] = sdc.binding(
        FILE_CONTENT_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=(),
    )
    table: ScrapDataTableViewModel = sdc.child_component("table", factory=ScrapDataTableViewModel)
    title: str = sdc.one_way_binding(TITLE_ID, "children", default="title")
    error_msg_handler: ErrorHandlerMsg = sdc.child_component("error-msg", factory=ErrorHandlerMsg)

    @classmethod
    @abstractmethod
    def parse_raw_excel_data(
        cls, raw_content: str
    ) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]: ...

    @classmethod
    @abstractmethod
    def create(cls) -> TUploadComponent: ...

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.FILE_UPLOAD_ID, "contents", cls.save_content),
            sdc.InputFieldClientSide(cls.SHOW_DATA_BTN_ID, "n_clicks", *cls.toggle_table_visibility()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.FILE_UPLOAD_TEXT_ID, "children", *cls.show_filename()),
            sdc.OutputFieldClientSide(cls.SHOW_DATA_BTN_ID, "children", *cls.change_btn_lable()),
            sdc.OutputFieldClientSide(cls.BTN_WRAPPER_ID, "className", *cls.show_action_btns()),
            sdc.OutputFieldClientSide(cls.FILE_UPLOAD_ID, "className", *cls.set_classname()),
            sdc.OutputFieldClientSide(cls.SHOW_DATA_BTN_ID, "color", *cls.set_btn_color()),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dmc.LoadingOverlay(
                    html.Div(
                        children=[
                            html.Div(
                                [
                                    DashIconify(icon="vscode-icons:file-type-excel", width=22),
                                    dmc.Title("title", id=sdc.create_id(parent_id, cls.TITLE_ID), order=5),
                                ],
                            ),
                            html.Div(
                                dmc.Button(
                                    id=sdc.create_id(parent_id, cls.SHOW_DATA_BTN_ID),
                                    leftIcon=DashIconify(icon="circum:view-table"),
                                    variant="outline",
                                    color="teal",
                                    compact=True,
                                ),
                                id=sdc.create_id(parent_id, cls.BTN_WRAPPER_ID),
                            ),
                        ],
                        id=sdc.create_id(parent_id, cls.HEADER_WRAPPER_ID),
                    ),
                    loaderProps={"variant": "dots", "color": "green", "size": "xl"},
                ),
                dcc.Upload(
                    id=sdc.create_id(parent_id, cls.FILE_UPLOAD_ID),
                    accept=", ".join(cls.ACCEPTED_UPLOAD_FORMAT),
                    multiple=False,
                    children=html.Div(
                        id=sdc.create_id(parent_id, cls.FILE_UPLOAD_TEXT_ID),
                    ),
                    style_active={},
                    style_reject={},
                ),
                sdc.get_child_layout(parent_id, cls.table),
                sdc.get_child_layout(parent_id, cls.error_msg_handler),
                dcc.Store(id=sdc.create_id(parent_id, cls.FILE_CONTENT_ID)),
            ],
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def toggle_table_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleTableVisibility",
            ["viewModel"],
            """
            var updatedVM = {...viewModel};
            updatedVM.table = updatedVM.table.toggleTableVisibility();
            return updatedVM;
            """,
        )

    @classmethod
    def show_filename(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getFilename",
            ["viewModel"],
            """
            if (Boolean(viewModel.filename))
                return viewModel.filename;
            return "Pretiahnite a pustite alebo Zvoľte súbor kliknutím";
            """,
        )

    @classmethod
    def change_btn_lable(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "changeBtnLabel",
            ["viewModel"],
            f"return viewModel.table.hidden ? '{cls.BTN_LABEL_SHOW}' : '{cls.BTN_LABEL_HIDE}'",
        )

    @classmethod
    def show_action_btns(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showActionBtns",
            ["viewModel"],
            "return Boolean(viewModel.uploaded_file_content.length !== 0) ? '' : 'invisible'",
        )

    @classmethod
    def set_classname(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setClassname",
            ["viewModel"],
            """
            if (viewModel.error_msg_handler.error.length != 0)
                return 'errorUpload';
            return Boolean(viewModel.filename) ? 'uploaded' : 'notUploaded';
            """,
        )

    @classmethod
    def set_btn_color(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setBtnColor",
            ["viewModel"],
            "return viewModel.error_msg_handler.error.length > 0 ? 'red' : 'teal';",
        )

    @property
    def file_content(self) -> Tuple[ScrapParsedData, ...]:
        if not self.uploaded_file_content:
            return ()
        return assign_scrap_type_to_scrap_state_data(
            (converter.structure(data, ScrapParsedData) for data in self.uploaded_file_content)
        )

    def reset(self, _: int) -> TUploadComponent:
        return attr.evolve(
            self,
            uploaded_file_content=(),
            filename=None,
        )

    def save_content(self, raw_content: str) -> TUploadComponent:
        parsed_excel, error = self.parse_raw_excel_data(raw_content)
        data = assign_scrap_type_to_scrap_state_data(parsed_excel)
        return attr.evolve(
            self,
            uploaded_file_content=converter.unstructure(parsed_excel),
            table=self.table.set_data(data),
            error_msg_handler=self.error_msg_handler.set_error(error),
        )
