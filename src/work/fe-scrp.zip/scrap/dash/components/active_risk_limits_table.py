import logging
from typing import TypedDict, List, Tuple, Optional
from datetime import date

import attr
from immutables import Map
from dash import dash_table
from dash.dash_table import FormatTemplate as FormatTemplate

from common.dash import CELL_STYLE, TABLE_HEADER_STYLE, DATA_TEXT_STYLE
from scrap.dash.database_api import steel_grades
from scrap.models import (
    MultipleHeatsOptimizationResult,
    MultipleHeatsOptimizationInput,
    MultipleHeatsOptimizationOutput,
    LoadingStation,
    all_prefetched_loading_station_query_set,
)
from scrap.dash.components.one_heat_optimizer_v2 import get_relaxable_risk_limit_for_grade
from scrap_core import Chem, ScrapCharge
from scrap_core.modelutils import get_ct_risks
from scrap_core.optimization.expected_risk import get_ct_risk_limits
from scrap_core.optimization.datamodel import RawFeChem, HeatInputs
from scrap_core.optimization.relaxable_limits import RelaxableRiskLimit


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class ActiveRiskLimitsTableRow(TypedDict):
    chem: Chem
    aim: float
    allowed: float
    estimate: float
    has_violated_aim_only: int
    has_violated_allowed: int
    has_ignored_chem: int


ActiveRiskLimitsTableData = List[ActiveRiskLimitsTableRow]


ACTIVE_RISK_LIMITS_TABLE_TEXT_STYLE = DATA_TEXT_STYLE + [
    {"if": {"filter_query": "{has_violated_allowed} = 1"}, "backgroundColor": "rgb(249,133,112)"},
    {"if": {"filter_query": "{has_violated_aim_only} = 1"}, "backgroundColor": "rgb(250, 245, 100)"},
    {"if": {"filter_query": "{has_ignored_chem} = 1"}, "color": "rgb(216, 219, 206)"},
    {"if": {"column_id": "limit_type"}, "width": "60px"},
    {"if": {"column_id": "limit_weight"}, "width": "60px"},
]


def create_active_risk_limits_table(element_id: str) -> dash_table.DataTable:
    columns = [
        {"name": "Prvok", "id": "chem", "type": "text", "editable": False},
        {
            "name": "Cieľ",
            "id": "aim",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
        {
            "name": "Max",
            "id": "allowed",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
        {
            "name": "Odhad (model)",
            "id": "estimate",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
    ]
    return dash_table.DataTable(
        id=element_id,
        style_cell_conditional=[
            {"if": {"column_id": "chem"}, "width": "10px"},
            {"if": {"column_id": "aim"}, "width": "65px"},
            {"if": {"column_id": "allowed"}, "width": "65px"},
            {"if": {"column_id": "estimate"}, "width": "65px"},
        ],
        style_data_conditional=ACTIVE_RISK_LIMITS_TABLE_TEXT_STYLE,
        style_table={"margin": "0px auto"},
        style_header=TABLE_HEADER_STYLE,
        style_cell=CELL_STYLE,
        columns=columns,
        data=[],
        editable=False,
    )


def get_active_risk_limits_table_data(
    ct_risks: Map[Chem, float],
    ct_risk_aim_limits: Map[Chem, float],
    ct_risk_allowed_limits: Map[Chem, float],
    supported_chems: Tuple[Chem, ...],
    ignored_chems: Tuple[Chem, ...],
) -> ActiveRiskLimitsTableData:
    return [
        {
            "chem": chem,
            "aim": ct_risk_aim_limits[chem],
            "allowed": ct_risk_allowed_limits[chem],
            "estimate": ct_risks[chem],
            "has_violated_aim_only": int(
                ct_risk_aim_limits[chem] < ct_risks[chem] <= ct_risk_allowed_limits[chem]
                and chem not in ignored_chems
            ),
            "has_violated_allowed": int(
                ct_risk_allowed_limits[chem] < ct_risks[chem] and chem not in ignored_chems
            ),
            "has_ignored_chem": int(chem in ignored_chems),
        }
        for chem in sorted(supported_chems)
    ]


def get_active_risk_limits_model_table_data(
    result: MultipleHeatsOptimizationResult,
) -> ActiveRiskLimitsTableData:
    input_data: MultipleHeatsOptimizationInput = result.input_data
    output: MultipleHeatsOptimizationOutput = result.result
    settings = input_data.model_settings
    supported_chems = settings.correction_technologies_settings.chems_for_correction_technologies
    heat, scrap_charge = input_data.heats[0], output.scrap_weights_per_heat[0]
    ignored_chems = settings.get_ignored_chems(heat.grade_planned)
    expected_ct_risks = get_ct_risks(scrap_charge, heat, settings)
    ct_risk_aim_limits, ct_risk_allowed_limits = get_ct_risk_limits(settings, heat.relaxable_risk_limit)
    return get_active_risk_limits_table_data(
        expected_ct_risks, ct_risk_aim_limits, ct_risk_allowed_limits, supported_chems, ignored_chems
    )


def get_active_risk_limits_loaded_table_data(
    result: MultipleHeatsOptimizationResult,
    scrap_charge: ScrapCharge,
    pellets_weight: int,
    briquetes_weight: int,
) -> ActiveRiskLimitsTableData:
    input_data: MultipleHeatsOptimizationInput = result.input_data
    settings = input_data.model_settings
    supported_chems = settings.correction_technologies_settings.chems_for_correction_technologies
    heat = input_data.heats[0]
    ignored_chems = settings.get_ignored_chems(heat.grade_planned)
    expected_ct_risks = get_ct_risks(scrap_charge, heat, settings, pellets_weight, briquetes_weight)
    ct_risk_aim_limits, ct_risk_allowed_limits = get_ct_risk_limits(settings, heat.relaxable_risk_limit)
    return get_active_risk_limits_table_data(
        expected_ct_risks, ct_risk_aim_limits, ct_risk_allowed_limits, supported_chems, ignored_chems
    )


def get_relaxable_risk_limit_from_loading_station(
    loading_station_id: int, grade_id: int
) -> RelaxableRiskLimit:
    station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=loading_station_id)
    relaxable_risk_limit_settings = station.relaxable_risk_limit_settings.all()
    return get_relaxable_risk_limit_for_grade(grade_id, relaxable_risk_limit_settings)


def get_active_risk_limits_free_table_data(
    scrap_charge: ScrapCharge,
    pellets_weight: int,
    briquetes_weight: int,
    raw_fe_chem: RawFeChem,
    raw_fe_weight: int,
    grade_id: int,
    loading_station_id: Optional[int] = None,
) -> ActiveRiskLimitsTableData:
    grade = steel_grades.get_grade_from_id(grade_id, date.today())
    # if result is None:
    station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=loading_station_id)
    heat = HeatInputs(
        grade_planned=grade,
        total_scrap_weight=sum(scrap_charge.values()),
        pig_iron_weight=raw_fe_weight,
        pig_iron_chem=raw_fe_chem,
        lower_bounds=Map(),
        upper_bounds=Map(),
        relaxable_risk_limit=get_relaxable_risk_limit_from_loading_station(loading_station_id, grade_id),
    )
    settings = station.model_settings
    # else:
    #     input_data: MultipleHeatsOptimizationInput = result.input_data
    #     settings = input_data.model_settings
    #     heat = input_data.heats[0]
    #     heat = attr.evolve(heat, pig_iron_chem=raw_fe_chem, pig_iron_weight=raw_fe_weight)

    ignored_chems = settings.get_ignored_chems(grade)
    supported_chems = settings.correction_technologies_settings.chems_for_correction_technologies
    expected_ct_risks = get_ct_risks(scrap_charge, heat, settings, pellets_weight, briquetes_weight)
    ct_risk_aim_limits, ct_risk_allowed_limits = get_ct_risk_limits(settings, heat.relaxable_risk_limit)
    return get_active_risk_limits_table_data(
        expected_ct_risks, ct_risk_aim_limits, ct_risk_allowed_limits, supported_chems, ignored_chems
    )
