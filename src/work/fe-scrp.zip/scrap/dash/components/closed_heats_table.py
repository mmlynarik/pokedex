from datetime import datetime
from typing import List, Sequence, TypedDict

from dash import dash_table

from scrap.models import ScrapChargeDisplayDataV2


class ClosedHeatsRow(TypedDict):
    heat_display_value: str
    closed_heats_year: str
    closed_heats_mounth: str
    closed_heats_day: str


ClosedHeatsTableData = List[ClosedHeatsRow]


def get_heat_display_value(heat: ScrapChargeDisplayDataV2, date: datetime) -> str:
    return date.strftime("%H:%M") + " " + ",".join(str(x) for x in heat.basket_ids)


def get_closed_heats_row(data: ScrapChargeDisplayDataV2, date: datetime) -> ClosedHeatsRow:
    return {
        "heat_display_value": get_heat_display_value(data, date),
        "closed_heats_year": date.strftime("%Y"),
        "closed_heats_mounth": date.strftime("%b"),
        "closed_heats_day": date.strftime("%d"),
    }


def get_closed_heats_table_data(
    closed_heats: Sequence[ScrapChargeDisplayDataV2], closed_heat_dates: Sequence[datetime]
) -> ClosedHeatsTableData:
    return [get_closed_heats_row(heat, date) for heat, date in zip(closed_heats, closed_heat_dates)]


def create_closed_heats_table(table_id: str, paging_page_size=3) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=[
            {"name": "Rok", "id": "closed_heats_year", "type": "text"},
            {"name": "Mesiac", "id": "closed_heats_mounth", "type": "text"},
            {"name": "Deň", "id": "closed_heats_day", "type": "text"},
            {"name": "Identifikátor tavby", "id": "heat_display_value", "type": "text"},
        ],
        editable=False,
        page_current=0,
        page_size=paging_page_size,
        page_action="custom",
    )
