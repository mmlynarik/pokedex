from typing import Collection, Tuple

import attr
from ussksdc.components.selectors import SelectorOptionViewModel
from ussksdc.components.selectors.multiple_selector import MultipleSelectorViewModel
from ussksdc.components.selectors.selector import SelectorViewModel

from scrap.models import ScrapDefinition


def scraps_to_selector_options(
    scraps: Collection[ScrapDefinition], options_sorted: bool = True
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert scraps definition sequence to dash dropdown options.

    Args:
        scraps: Collection of scrap definitions to convert.
        options_sorted: If True than options retured will be sorted in ascending order.

    Returns:
        Sequence of dash dropdown component options.
    """
    scraps = sorted(scraps, key=lambda scrap: scrap.scrap_type) if options_sorted else scraps
    return tuple(
        SelectorOptionViewModel(label=scrap.scrap_type, value=scrap.scrap_type, title=scrap.description)
        for scrap in scraps
    )


class DbScrapDefinitionSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return scraps_to_selector_options(ScrapDefinition.objects.all())

    def get_value(self, key: str) -> ScrapDefinition:
        return ScrapDefinition.objects.get(scrap_type=key)

    def get_values(self, keys: Collection[str]) -> Collection[ScrapDefinition]:
        return ScrapDefinition.objects.filter(scrap_type__in=keys)


@attr.s(frozen=True, slots=True)
class ScrapSelectorViewModel(SelectorViewModel[str, ScrapDefinition]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber šrot"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> DbScrapDefinitionSelectorDataSource:
        return DbScrapDefinitionSelectorDataSource()


@attr.s(frozen=True, slots=True)
class ScrapMultipleSelectorViewModel(MultipleSelectorViewModel[str, ScrapDefinition]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber šroty"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> DbScrapDefinitionSelectorDataSource:
        return DbScrapDefinitionSelectorDataSource()
