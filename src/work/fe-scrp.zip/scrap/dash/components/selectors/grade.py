from datetime import date
from typing import Collection, Dict, FrozenSet, Tuple

import attr
from dash import dcc
from ussksdc.components.selectors import SelectorOptionViewModel
from ussksdc.components.selectors.multiple_selector import MultipleSelectorViewModel
from ussksdc.components.selectors.selector import SelectorViewModel

from scrap.dash.database_api import steel_grades


def get_cached_available_grade_ids() -> FrozenSet[int]:
    today = date.today()
    return steel_grades.get_available_grade_ids(today)


def grades_to_selector_options(
    grade_ids: Collection[int], options_sorted: bool = True
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert grade ids sequence to dash dropdown options.

    Args:
        grade_ids: Collection of grade ids to convert.
        options_sorted: If True than options retured will be sorted in ascending order.

    Returns:
        Sequence of dash dropdown component options.
    """
    today = date.today()
    grade_ids = sorted(grade_ids) if options_sorted else grade_ids
    return tuple(
        SelectorOptionViewModel(label=steel_grades.get_display_name(grade_id, today), value=grade_id)
        for grade_id in grade_ids
    )


class GradeSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return grades_to_selector_options(get_cached_available_grade_ids())

    def get_value(self, key: int) -> int:
        return key

    def get_values(self, keys: Collection[int]) -> Collection[int]:
        return keys


@attr.s(frozen=True, slots=True)
class GradeIdsSelectorViewModel(SelectorViewModel[int, int]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber akosť"

    @classmethod
    def active_validation(cls) -> bool:
        return False

    @property
    def data_source(self) -> GradeSelectorDataSource:
        return GradeSelectorDataSource()


@attr.s(frozen=True, slots=True)
class GradeMultipleSelectorViewModel(MultipleSelectorViewModel[int, int]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber akosti"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> GradeSelectorDataSource:
        return GradeSelectorDataSource()


# TODO: move style to css files
# TODO: remove setup options. calculate.py setup grade options while creating layout.
def create_grade_selector(
    input_id: str, style: Dict[str, str] = {"margin-bottom": "16px"}, **kwargs
) -> dcc.Dropdown:
    """Function creating dropdown component as grade selector.

    Args:
        input_id: Id of dropdown html tag.
        kwagrs: Other arguments supported by Dropdown from DashCoreComponents.

    Returns:
        Dropdown component with all available grades.
    """
    view_model = GradeIdsSelectorViewModel()
    return dcc.Dropdown(
        id=input_id,
        options=view_model.to_dropdown_options(),
        placeholder="Vyber plánovaný grade",
        style=style,
        **kwargs
    )
