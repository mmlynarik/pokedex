from typing import Collection, Dict, Sequence, Tuple

import attr
import cachetools as ct
from ussksdc.components.selectors import SelectorOptionViewModel
from ussksdc.components.selectors.multiple_selector import MultipleSelectorViewModel
from ussksdc.components.selectors.selector import SelectorDataSource, SelectorViewModel

from scrap.models import LoadingStation


def loading_stations_to_selector_options(
    loading_stations: Sequence[LoadingStation],
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert LoadingStation data to dash dropdown component options.

    Args:
        loading_stations: Sequence of loading station data to convert.

    Returns:
        Sequence of dash dropdown component options.
    """
    return tuple(
        SelectorOptionViewModel(label=loading_station.name, value=loading_station.pk)
        for loading_station in loading_stations
    )


def get_loading_station_by_id(loading_station_id: int) -> LoadingStation:
    return LoadingStation.objects.get(id=loading_station_id)


def get_loading_stations_by_ids(ids: Collection[int]) -> Collection[LoadingStation]:
    return tuple(LoadingStation.objects.filter(id__in=ids))


def get_loading_stations() -> Sequence[LoadingStation]:
    return tuple(LoadingStation.objects.all())


class DbLoadingStationSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return loading_stations_to_selector_options(get_loading_stations())

    def get_value(self, key: int) -> LoadingStation:
        return get_loading_station_by_id(key)

    def get_values(self, keys: Collection[int]) -> Collection[LoadingStation]:
        return get_loading_stations_by_ids(keys)


class CachedLoadingStationSelectorDataSource:
    def __init__(self):
        self.all_loading_stations: Dict[int, LoadingStation] = {
            loading_station.pk: loading_station for loading_station in get_loading_stations()
        }
        self.options: Tuple[SelectorOptionViewModel, ...] = loading_stations_to_selector_options(
            list(self.all_loading_stations.values())
        )

    def get_value(self, key: int) -> LoadingStation:
        return self.all_loading_stations[key]

    def get_values(self, keys: Collection[int]) -> Collection[LoadingStation]:
        return [self.all_loading_stations[key] for key in keys]


# Long time because we expect that loading stations will not change that much
@ct.cached(cache=ct.TTLCache(maxsize=1, ttl=600))
def get_loading_station_selector_datasource() -> SelectorDataSource[int, LoadingStation]:
    return CachedLoadingStationSelectorDataSource()


@attr.s(frozen=True, slots=True)
class LoadingStationSelectorViewModel(SelectorViewModel[int, LoadingStation]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber nakladaciu stanicu"

    @classmethod
    def active_validation(cls) -> bool:
        return False

    @property
    def data_source(self) -> SelectorDataSource[int, LoadingStation]:
        return get_loading_station_selector_datasource()


@attr.s(frozen=True, slots=True)
class LoadingStationMultipleSelectorViewModel(MultipleSelectorViewModel[int, LoadingStation]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber nakladacie stanice"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> SelectorDataSource[int, LoadingStation]:
        return get_loading_station_selector_datasource()
