from typing import Collection, Dict, Tuple

import attr
import cachetools as ct
from ussksdc.components.selectors import SelectorOptionViewModel
from ussksdc.components.selectors.selector import SelectorDataSource, SelectorViewModel

from scrap.models import ScrapGroup


class DbScrapGroupSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return tuple(
            SelectorOptionViewModel(
                label=scrap_group.group_name,
                value=scrap_group.id,
                title=", ".join([scrap.scrap_type for scrap in scrap_group.scrap_ids.all()]),
            )
            for scrap_group in ScrapGroup.objects.all()
        )

    def get_value(self, key: int) -> ScrapGroup:
        return ScrapGroup.objects.get(id=key)

    def get_values(self, keys: Collection[int]) -> Collection[ScrapGroup]:
        return ScrapGroup.objects.filter(id__in=keys)


class CachedDbScrapGroupSelectorDataSource:
    def __init__(self):
        self.all_scrap_groups: Dict[int, ScrapGroup] = {
            scrap_group.pk: scrap_group
            for scrap_group in ScrapGroup.objects.all().prefetch_related("scrap_ids")
        }
        self.options: Tuple[SelectorOptionViewModel, ...] = tuple(
            SelectorOptionViewModel(
                label=scrap_group.group_name,
                value=pk,
                title=", ".join([scrap.scrap_type for scrap in scrap_group.scrap_ids.all()]),
            )
            for pk, scrap_group in self.all_scrap_groups.items()
        )

    def get_value(self, key: int) -> ScrapGroup:
        return self.all_scrap_groups[key]

    def get_values(self, keys: Collection[int]) -> Collection[ScrapGroup]:
        return [self.all_scrap_groups[key] for key in keys]


@ct.cached(cache=ct.TTLCache(maxsize=1, ttl=5))
def get_scrap_group_selector_datasource() -> SelectorDataSource[int, ScrapGroup]:
    return CachedDbScrapGroupSelectorDataSource()


@attr.s(frozen=True, slots=True)
class ScrapGroupSelectorViewModel(SelectorViewModel[int, ScrapGroup]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber skupinu šrotov"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> SelectorDataSource[int, ScrapGroup]:
        return get_scrap_group_selector_datasource()
