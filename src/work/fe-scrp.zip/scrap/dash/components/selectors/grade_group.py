from typing import Collection, Dict, Optional, Sequence, Tuple

import attr
import cachetools as ct
from django.db.models import Q
from ussksdc.components.data_store import DataStoreViewModel
from ussksdc.components.selectors import SelectorDataSource, SelectorOptionViewModel
from ussksdc.components.selectors.selector import SelectorViewModel

from scrap.dash.components import get_grade_groups_str
from scrap.models import GradeGroup


def grade_groups_to_selector_options(
    grade_groups: Sequence[GradeGroup],
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert GradeGroup data to dash dropdown options.

    Args:
        grade_groups: Sequence of grade groups data to convert.

    Returns:
        Sequence of dash dropdown component options.
    """
    return tuple(
        SelectorOptionViewModel(
            label=grade_group.group_name,
            value=grade_group.id,
            title=get_grade_groups_str(grade_group.to_tuple()),
        )
        for grade_group in grade_groups
    )


class DbGradeGroupSelectorDataSource:
    def __init__(self, filter_grade_id: Optional[int]):
        self.filter_grade_id = filter_grade_id

    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        if self.filter_grade_id is None:
            return grade_groups_to_selector_options(tuple(GradeGroup.objects.all()))
        return grade_groups_to_selector_options(
            tuple(GradeGroup.objects.filter(Q(grade_ids__grade_id=self.filter_grade_id) | Q(grade_ids=None)))
        )

    def get_value(self, key: int) -> GradeGroup:
        return GradeGroup.objects.get(id=key)

    def get_values(self, keys: Collection[int]) -> Collection[GradeGroup]:
        return GradeGroup.objects.filter(id__in=keys)


class CachedDbGradeGroupSelectorDataSource:
    def __init__(self, grade_id: int):
        queryset = GradeGroup.objects.all().prefetch_related("grade_ids")
        if grade_id != -1:
            queryset = queryset.filter(Q(grade_ids__grade_id=grade_id) | Q(grade_ids=None))
        self.all_grade_groups: Dict[int, GradeGroup] = {
            grade_group.pk: grade_group for grade_group in queryset
        }
        self.options = grade_groups_to_selector_options(list(self.all_grade_groups.values()))

    def get_value(self, key: int) -> GradeGroup:
        return self.all_grade_groups[key]

    def get_values(self, keys: Collection[int]) -> Collection[GradeGroup]:
        return [self.all_grade_groups[key] for key in keys]


@ct.cached(cache=ct.TTLCache(maxsize=1024, ttl=5))
def get_grade_group_datasource(grade_id: int) -> SelectorDataSource[int, GradeGroup]:
    return CachedDbGradeGroupSelectorDataSource(grade_id)


@attr.s(frozen=True, slots=True)
class GradeGroupSelectorViewModel(SelectorViewModel[int, GradeGroup]):
    @classmethod
    def placeholder(cls) -> str:
        return "Vyber skupinu akostí"

    @classmethod
    def active_validation(cls) -> bool:
        return True

    @property
    def data_source(self) -> SelectorDataSource[int, GradeGroup]:
        return get_grade_group_datasource(self.filter_id.data)

    def set_filter_grade_id(self, grade_id: Optional[int]) -> "GradeGroupSelectorViewModel":
        return attr.evolve(self, filter_id=DataStoreViewModel(grade_id))  # type: ignore
