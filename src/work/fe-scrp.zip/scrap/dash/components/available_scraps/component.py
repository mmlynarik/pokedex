import ussksdc as sdc
from attr import frozen
from dash import html

from scrap.dash.components.available_scraps.model.available_scraps.component import AvailableScrapsDataVM
from scrap.dash.components.available_scraps.model.scrap_definitions.component import AllScrapDefinitionVM
from scrap.dash.components.available_scraps.modify_scraps.add import AddAvailableScrapVM
from scrap.dash.components.available_scraps.modify_scraps.update_weight import UpdateAvailableScrapWeightVM
from scrap.dash.components.available_scraps.table import AvailableScrapsTableVM
from scrap.dash.components.available_scraps.transfer_capacity import TransferCapacityVM
from scrap.dash.components.protocols.scrap_loading_station import (
    LoadingStationModels,
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)


@frozen
class AvailableScrapsVM:
    ID = "available-scrap"
    ADD_UPDATE_SCRAP = "add-update-scrap"

    table: AvailableScrapsTableVM = sdc.child_component("", factory=AvailableScrapsTableVM)
    transfer_capacity: TransferCapacityVM = sdc.child_component(
        "transfer-capacity", factory=TransferCapacityVM
    )
    add_scrap: AddAvailableScrapVM = sdc.child_component("add-new-scrap", factory=AddAvailableScrapVM)
    update_scrap: UpdateAvailableScrapWeightVM = sdc.child_component(
        "update-scrap", factory=UpdateAvailableScrapWeightVM
    )
    data: AvailableScrapsDataVM = sdc.child_component("datasource", factory=AvailableScrapsDataVM)
    scrap_definitions_data: AllScrapDefinitionVM = sdc.child_component(
        "scrap-definition-datasource", factory=AllScrapDefinitionVM
    )

    @classmethod
    def create_from_models(cls, models: LoadingStationModels) -> "AvailableScrapsVM":
        return cls(
            data=AvailableScrapsDataVM(
                data_to_sync=AvailableScrapsDataVM.convert_new_data_to_crud_model_msg(
                    models.available_scraps.get_all()
                )
            ),
            scrap_definitions_data=AllScrapDefinitionVM(
                data_to_sync=AllScrapDefinitionVM.convert_new_data_to_crud_model_msg(
                    models.scrap_definitions.get_all()
                )
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.table, config),
                sdc.get_child_layout(parent_id, cls.transfer_capacity, config),
                sdc.get_child_layout(parent_id, cls.data),
                sdc.get_child_layout(parent_id, cls.scrap_definitions_data),
                html.Div(
                    [
                        sdc.get_child_layout(parent_id, cls.add_scrap, config),
                        sdc.get_child_layout(parent_id, cls.update_scrap, config),
                    ],
                    id=sdc.create_id(parent_id, cls.ADD_UPDATE_SCRAP),
                ),
            ],
            id=sdc.create_id(parent_id, cls.ID),
        )

    def hide_add_update_scrap_when_use_scrap_yard_api(self, ctx: ScrapLoadingStationCTX) -> bool:
        return ctx.use_scrap_yard_api

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.ADD_UPDATE_SCRAP, "hidden", cls.hide_add_update_scrap_when_use_scrap_yard_api
            ),
        )
