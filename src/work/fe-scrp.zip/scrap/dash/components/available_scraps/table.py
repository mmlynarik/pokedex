from string import Template
from typing import Tuple

import ussksdc as sdc
from attr import frozen
from dash_ag_grid import AgGrid
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@frozen
class AvailableScrapsTableVM:
    # Component ids
    COMPONENT_ID = "table"
    # Column ids
    ID_COL_ID = "id"
    SCRAP_TYPE_COL_ID = "scrap-type"
    WEIGHT_COL_ID = "weight"
    LOCATED_OUTDOOR_ID = "located_outdoor"
    # User friendly msg
    INDOOR_MSG = "V hale"
    OUTDOOR_MSG = "Mimo haly"

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                AgGrid(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={"rowHeight": 30, "headerHeight": 38, "domLayout": "autoHeight"},
                    defaultColDef={"editable": False},
                    getRowId=f"params.data.{cls.ID_COL_ID}",
                    style={"height": None},
                ),
            ]
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.COMPONENT_ID, "cellValueChanged", *cls.update_location()),)

    @classmethod
    def update_location(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateScrapLocation",
            ["viewModel", "newValue", "ctx"],
            """
            var update = {};
            update[newValue.colId] = newValue.value;
            ctx.models.availableScraps.update(newValue.rowId, update);
            return viewModel;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "columnDefs", *cls.get_column_defs()),
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "rowData", *cls.get_table_data()),
        )

    @classmethod
    def get_column_defs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getColumnDefs",
            ["viewModel", "ctx"],
            Template(
                """
            var columns = [
                {'field': '${type_col}', 'headerName': 'Typ šrotu'},
                {
                    'field': '${weight_col}',
                    'headerName': 'Hmotnosť',
                    "valueFormatter": {"function": "params.value + ' t'"}
                },
            ];

            if (ctx.debug)
                columns = [{'field': '${id_col}', 'headerName': 'Id'}, ...columns];
            if (ctx.steelshop === 1)
                columns = [
                    ...columns,
                    {
                        'cellEditor': 'agSelectCellEditor',
                        'cellEditorParams': {
                            'values': [false, true],
                        },
                        'field': '${location_col}',
                        'headerName': 'Umiestnenie',
                        "valueFormatter": {"function": "params.value ? '${outdoor}' : '${indoor}'"},
                        "editable": !ctx.useScrapYardApi && !ctx.readOnly,
                    }
                ];
            return columns;
            """
            ).substitute(
                id_col=cls.ID_COL_ID,
                type_col=cls.SCRAP_TYPE_COL_ID,
                weight_col=cls.WEIGHT_COL_ID,
                location_col=cls.LOCATED_OUTDOOR_ID,
                indoor=cls.INDOOR_MSG,
                outdoor=cls.OUTDOOR_MSG,
            ),
        )

    @classmethod
    def get_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getAvailableScraps",
            ["viewModel", "ctx"],
            Template(
                """
            var tableData = [];
            const scrapDefinitions = Object.values(ctx.models.scrapDefinitions.getAll()).filter(
                scrap => scrap.tms_id != null
            );
            for(const [key, scrap] of Object.entries(sdc.models.availableScraps.getAll())){
                if (scrap.weight === 0)
                    continue;
                const scrapDef = scrapDefinitions.find(elem => elem.scrap_type==scrap.scrap_type);
                var tmsId = null;
                if (scrapDef !== undefined)
                    tmsId = scrapDef.tms_id;
                tableData.push({
                    '${id_col}': key,
                    '${type_col}': tmsId === null ? scrap.scrap_type : scrap.scrap_type + ' (' + tmsId + ')',
                    '${weight_col}': ctx.kgsToTons(scrap.weight),
                    '${location_col}': ctx.useScrapYardApi ? (scrap.located_outdoor ? "${indoor}" : "${outdoor}") : scrap.located_outdoor,
                });
            }
            return tableData;
            """
            ).substitute(
                id_col=cls.ID_COL_ID,
                type_col=cls.SCRAP_TYPE_COL_ID,
                weight_col=cls.WEIGHT_COL_ID,
                location_col=cls.LOCATED_OUTDOOR_ID,
                indoor=cls.INDOOR_MSG,
                outdoor=cls.OUTDOOR_MSG,
            ),
        )
