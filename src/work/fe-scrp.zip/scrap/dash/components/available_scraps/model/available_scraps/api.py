import logging
from collections import defaultdict
from enum import IntEnum
from typing import Tuple

import attr
import requests
from immutables import Map
from scrap.models import LoadingStation, ScrapCharge, WeightedScrap, ScrapFacility
from scrap_core import SPAREPARTS_ID_REVERSE_MAPPING, ScrapMix, ScrapMixMapping
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    AvailableScraps,
    OUTDOOR_SCRAP_NAME,
    INDOOR_SCRAP_NAME,
)
from vsadzka.settings import SPAREPARTS_API_ENDPOINT_GET, SPAREPARTS_API_ENDPOINT_POST

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.s(frozen=True, auto_attribs=True, slots=True)
class ScrapMixDefinition:
    """Class to represent a scrap mix (i.e. heap) compatible with spareparts API."""

    heap_id: int
    heap: str
    facility_id: int
    facility: str
    type_id: int
    type: str


class ScrapMixState(IntEnum):
    """ScrapMix state representing whether heap is allowed to be filled or taken from."""

    INCOMING = 1
    OUTGOING = 2
    BOTH = 3


@attr.s(frozen=True, auto_attribs=True, slots=True)
class ScrapMixComponentWeight:
    """Class to represent one element in a list of JSON objects obtained from spareparts API."""

    scrap_mix_definition: ScrapMixDefinition
    material_number: int
    weight: float
    scrap: str
    scrap_id: int

    @property
    def scrap_type(self):
        splits = self.scrap.split(" ")
        return splits[-1] if splits[-2] not in ("1", "2") else "".join(splits[-2:])


@attr.s(frozen=True, auto_attribs=True, slots=True)
class AvailableScrapMixes:
    """Class to represent a list of all JSON objects obtained from spareparts API."""

    scrap_mix_components_weights: Tuple[ScrapMixComponentWeight, ...]

    def get_heap_id(self, scrap_mix: ScrapMix):
        for weight in self.scrap_mix_components_weights:
            if weight.scrap_mix_definition.heap == scrap_mix:
                return weight.scrap_mix_definition.heap_id
        raise ValueError(f"Heap {scrap_mix} was not found in any scrap facility.")

    def get_scrap_mixes(self, loading_station_id: int) -> Tuple[Tuple[ScrapMix, bool], ...]:
        """Get available scrap mixes with their outdoor flags relevant for given loading station."""
        station = LoadingStation.objects.get(pk=loading_station_id)
        scrap_facilities = station.scrap_facilities.values_list("facility_id", flat=True)
        scrap_mixes = set()
        for weight in self.scrap_mix_components_weights:
            if (
                weight.scrap_mix_definition.facility_id in scrap_facilities
                and weight.scrap_mix_definition.type_id
                in (ScrapMixState.OUTGOING.value, ScrapMixState.BOTH.value)
            ):
                scrap_mixes.add(
                    (
                        weight.scrap_mix_definition.heap,
                        ScrapFacility.objects.get(pk=weight.scrap_mix_definition.facility_id).outdoor,
                    )
                )
        return tuple(scrap_mixes)

    def get_available_scraps(self, loading_station_id: int) -> AvailableScraps:
        available_scraps = []
        for scrap_mix, outdoor in self.get_scrap_mixes(loading_station_id):
            weight = 0
            for component_weight in self.scrap_mix_components_weights:
                if component_weight.scrap_mix_definition.heap == scrap_mix:
                    weight += component_weight.weight
            weight = weight * 1e3  # API weight is in tonnes but AvailableScrap uses kilograms
            available_scraps.append(
                AvailableScrap(scrap_mix, weight, OUTDOOR_SCRAP_NAME if outdoor else INDOOR_SCRAP_NAME)
            )
        return tuple(available_scraps)

    def get_scrap_mix_mapping(self, loading_station_id: int) -> ScrapMixMapping:
        scrap_mix_mapping = {}
        for scrap_mix, _ in self.get_scrap_mixes(loading_station_id):
            single_mapping = defaultdict(float)
            for component_weight in self.scrap_mix_components_weights:
                if component_weight.scrap_mix_definition.heap == scrap_mix:
                    single_mapping[component_weight.scrap_type] += component_weight.weight
            single_mapping = {k: v / sum(single_mapping.values()) for k, v in single_mapping.items()}
            scrap_mix_mapping[scrap_mix] = single_mapping
        return Map(scrap_mix_mapping)


@attr.s(frozen=True, auto_attribs=True, slots=True)
class LoadedScrapMixComponentWeight:
    """Class to represent one element in a list of JSON objects sent to sparepart API. Amount is in tonnes."""

    heap_id: int
    amount: float
    scrap_id: int
    id_charge: int
    user: str


def get_availables_scrap_mixes_from_api() -> AvailableScrapMixes:
    response = requests.get(url=SPAREPARTS_API_ENDPOINT_GET)
    if response.status_code != 200:
        raise ConnectionError("Cannot get scrap mix component weights from spareparts api.")
    available_scrap_mixes = []
    for item in response.json():
        weight = ScrapMixComponentWeight(
            ScrapMixDefinition(
                item["heap_id"],
                item["heap"],
                item["facility_id"],
                item["facility"],
                item["type_id"],
                item["type"],
            ),
            item["mc"],
            item["quantity"],
            item["scrap"],
            item["scrap_id"],
        )
        available_scrap_mixes.append(weight)
    return AvailableScrapMixes(tuple(available_scrap_mixes))


def send_loaded_scrap_mixes_to_api(scrap_charge: ScrapCharge, user_in_control: str) -> bool:
    station_id = scrap_charge.loading_station_id

    weighted_scraps: Tuple[WeightedScrap, ...] = tuple(scrap_charge.weightedscrap_set.all())
    try:
        available_scrap_mixes = get_availables_scrap_mixes_from_api()
    except ConnectionError:
        log.exception(f"Loaded scrap for scrap charge {scrap_charge.pk} not sent")
        return False
    scrap_mix_mapping = available_scrap_mixes.get_scrap_mix_mapping(station_id)

    loaded_scrap_mix_components_weights = []
    for weighted_scrap in weighted_scraps:
        scrap_mix = weighted_scrap.scrap
        try:
            heap_id = available_scrap_mixes.get_heap_id(scrap_mix)
        except ValueError:
            log.exception(f"Loaded scrap for scrap charge {scrap_charge.pk} not sent")
            return False

        scrap_types = scrap_mix_mapping[scrap_mix]
        for scrap_type in scrap_types:
            loaded_scrap_weight = LoadedScrapMixComponentWeight(
                heap_id=heap_id,
                amount=weighted_scrap.weight * scrap_mix_mapping[scrap_mix][scrap_type] / 1e3,
                scrap_id=SPAREPARTS_ID_REVERSE_MAPPING[scrap_type],
                id_charge=scrap_charge.pk,
                user=user_in_control,
            )
            loaded_scrap_mix_components_weights.append(loaded_scrap_weight)

    response = requests.post(
        url=SPAREPARTS_API_ENDPOINT_POST,
        json=[attr.asdict(weight) for weight in loaded_scrap_mix_components_weights],
    )
    if response.status_code == 200:
        return True

    log.error(
        f"Scrap Yard data not updated for scrap charge {scrap_charge.pk} "
        f"- response code: {response.status_code}, response text: {response.text}"
    )
    return False
