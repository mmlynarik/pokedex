import logging
from typing import Any, Collection, Optional

import attr
from ussksdc.core.datamodel import CRUDModel

from scrap.models import ScrapDefinition

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.frozen
class ScrapDefinitionAttr:
    tms_id: Optional[int] = attr.ib()
    scrap_type: str = attr.ib()
    description: str = attr.ib(default="")

    @classmethod
    def from_django_model(cls, data: ScrapDefinition) -> "ScrapDefinitionAttr":
        return ScrapDefinitionAttr(
            tms_id=data.tms_id, scrap_type=data.scrap_type, description=data.description
        )


class AllScrapDefinitionsDatasource(CRUDModel[ScrapDefinitionAttr, str]): ...


class AllScrapDefinitionsDb:
    def get_all(self) -> Collection[ScrapDefinitionAttr]:
        return tuple(ScrapDefinitionAttr.from_django_model(scrap) for scrap in ScrapDefinition.objects.all())

    def get(self, elem_id: str) -> Optional[ScrapDefinitionAttr]:
        try:
            return ScrapDefinitionAttr.from_django_model(ScrapDefinition.objects.get(scrap_type=elem_id))
        except ScrapDefinition.DoesNotExist:
            log.exception(f"Scrap definition with scrap type '{elem_id}' does not exist.")
        return None

    def create(self, _: ScrapDefinitionAttr) -> str:
        raise NotImplementedError("Can't use 'create' on the scrap definition")

    def update(self, _: str, **changes: Any) -> Optional[ScrapDefinitionAttr]:
        raise NotImplementedError("Can't use 'update' on the scrap definition")

    def delete(self, _: str) -> None:
        raise NotImplementedError("Can't use 'delete' on the scrap definition")
