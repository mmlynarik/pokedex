# TODO generate models with sdc core
# This models will be generated with sdc core but in this time
# is models copirighted for each models separately.
