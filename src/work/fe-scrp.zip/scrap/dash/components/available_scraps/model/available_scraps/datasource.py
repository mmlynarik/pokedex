import logging
from typing import Any, Collection, Optional

from immutables import Map
from scrap.dash.components.available_scraps.model.available_scraps.api import (
    get_availables_scrap_mixes_from_api,
)
from scrap.models import ScrapMixDefinition
from scrap.models import AvailableScrap as AvailableScrapDbModel
from scrap_core import ScrapMix, ScrapMixMapping
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    AvailableScraps,
    INDOOR_SCRAP_NAME,
    OUTDOOR_SCRAP_NAME,
)
from ussksdc.core.datamodel import CRUDModel

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class AvailableScrapDatasource(CRUDModel[AvailableScrapDbModel, int]):
    scrap_mix_mapping: ScrapMixMapping

    def get_all_for_optimizer(self) -> Collection[AvailableScrap]: ...


class AvailableScrapDb:
    MODEL_DOES_NOT_EXIST_MSG = "Loading station with id=%d does not exist."

    def __init__(self, loading_station_id: int) -> None:
        self.loading_station_id = loading_station_id

    def get_all(self) -> Collection[AvailableScrapDbModel]:
        return AvailableScrapDbModel.objects.filter(loading_station_id=self.loading_station_id)

    def get(self, elem_id: int) -> Optional[AvailableScrapDbModel]:
        available_scrap = AvailableScrapDbModel.objects.filter(id=elem_id)
        return None if not available_scrap else available_scrap[0]

    def create(self, new_data: AvailableScrapDbModel) -> int:
        new_data.loading_station_id = self.loading_station_id
        new_data.save()
        return new_data.id

    def update(self, elem_id: int, **changes: Any) -> Optional[AvailableScrapDbModel]:
        available_scrap = self.get(elem_id)
        if available_scrap is None:
            return None

        for key, updated_value in changes.items():
            available_scrap.__setattr__(key, updated_value)
        available_scrap.save()
        return available_scrap

    def delete(self, elem_id: int) -> None:
        available_scrap = self.get(elem_id)
        if available_scrap is not None:
            available_scrap.delete()

    def get_all_for_optimizer(self) -> Collection[AvailableScrap]:
        return tuple(
            AvailableScrap(
                scrap_type=s.scrap_type,
                weight=s.weight,
                location=OUTDOOR_SCRAP_NAME if s.located_outdoor else INDOOR_SCRAP_NAME,
            )
            for s in self.get_all()
        )

    @property
    def scrap_mix_mapping(self) -> ScrapMixMapping:
        return Map(
            {
                ScrapMix(definition.name): definition.get_scrap_type_mapping()
                for definition in ScrapMixDefinition.objects.filter(exhausted=False)
            }
        )


class AvailableScrapAPI:
    def __init__(self, loading_station_id: int) -> None:
        self.loading_station_id = loading_station_id

    def get_all(self) -> AvailableScraps:
        available_scrap_mixes = get_availables_scrap_mixes_from_api()
        return available_scrap_mixes.get_available_scraps(self.loading_station_id)

    def get(self, elem_id: int) -> Optional[AvailableScrap]:
        available_scraps = self.get_all()
        if elem_id < len(available_scraps):
            return available_scraps[elem_id]
        return None

    def create(self, new_data: AvailableScrap) -> int:
        raise NotImplementedError("Can't use 'create' on available scrap")

    def update(self, elem_id: int, **changes: Any) -> Optional[AvailableScrap]:
        raise NotImplementedError("Can't use 'update' on available scrap")

    def delete(self, elem_id: int) -> None:
        raise NotImplementedError("Can't use 'delete' on available scrap")

    @property
    def scrap_mix_mapping(self) -> ScrapMixMapping:
        available_scrap_mixes = get_availables_scrap_mixes_from_api()
        return available_scrap_mixes.get_scrap_mix_mapping(self.loading_station_id)
