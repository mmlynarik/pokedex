from typing import Optional, Tuple

import dash_bootstrap_components as dbc
import ussksdc as sdc
from attr import frozen
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.available_scraps.modify_scraps.common import COMPONENT_WRAPPER, FORM_WRAPPER
from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@frozen
class TransferCapacityVM:
    # Component ids
    WEIGHT_INPUT_ID = "weight"
    INPUT_WRAPPER_ID = "input-wrapper"
    # User friendly msg
    LABEL = "Prepravná kapacita"

    weight: Optional[int] = sdc.only_state_binding(
        WEIGHT_INPUT_ID,
        "value",
        default=None,
    )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            className=COMPONENT_WRAPPER,
            children=[
                html.H6(cls.LABEL),
                html.Div(
                    className=FORM_WRAPPER,
                    children=[
                        dbc.InputGroup(
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.WEIGHT_INPUT_ID), min=0),
                                dbc.InputGroupText("t"),
                            ],
                        ),
                    ],
                ),
            ],
            id=sdc.create_id(parent_id, cls.INPUT_WRAPPER_ID),
            hidden=config.read_only,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.INPUT_WRAPPER_ID, "hidden", *cls.hide_if_not_ss1()),)

    @classmethod
    def hide_if_not_ss1(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideIfNotSs1", ["viewModel", "ctx"], "return Boolean(ctx.steelshop !== 1);"
        )
