from typing import Any, Dict, List, Optional, Tuple

import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.available_scraps.modify_scraps.common import WeightInputVM, layout
from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@frozen
class ScrapSelectorVM:
    # Component id
    SELECTOR_ID = "selector"
    # User friendly msg
    CHOOSE_SCRAP = "Zvoľte z dostupných šrotov"

    options: List[Dict[str, Any]] = sdc.clientside_only_state_binding(SELECTOR_ID, "options", default=[])
    selected_option: Optional[int] = sdc.clientside_two_way_binding(SELECTOR_ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Dropdown:
        return dcc.Dropdown(
            id=sdc.create_id(parent_id, cls.SELECTOR_ID),
            placeholder=cls.CHOOSE_SCRAP,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.SELECTOR_ID, "options", *cls.get_options_from_table()),)

    @classmethod
    def get_options_from_table(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function getAvailableScraps(viewModel, ctx){
                    const scrapDefinitions = Object.values(ctx.models.scrapDefinitions.getAll()).filter(
                        scrap => scrap.tms_id != null
                    );
                    return scrapDefinitions.map((scrap, idx) => {
                        return {
                            label: ctx.models.scrapDefinitions.getDisplayName(scrap.scrap_type),
                            value: scrap.tms_id,
                            disabled: false,
                            title: scrap.description
                        }
                    });
                }
                """
            ),
            "getAvailableScraps",
        )


@frozen
class AddAvailableScrapVM:
    # Component ids
    SCRAP_SELECTOR_ID = "scrap"
    WEIGHT_INPUT_ID = "weight"
    CONFIRM_BTN_ID = "confirm"
    # User friendly msg
    CONFIRM_BTN = "Pridaj šrot"
    CONFIRM_BTN_COLOR = "primary"
    LABEL = "Pridanie šrotu"

    scrap: ScrapSelectorVM = sdc.child_component(SCRAP_SELECTOR_ID, factory=ScrapSelectorVM)
    weight: WeightInputVM = sdc.child_component(WEIGHT_INPUT_ID, factory=WeightInputVM)

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (sdc.InputFieldClientSide(cls.CONFIRM_BTN_ID, "n_clicks", *cls.update_weight()),)

    @classmethod
    def get_output_fields(cls, config: ScrapLoadingStationConfig) -> sdc.OutputFields:
        if config.read_only:
            return ()
        return (sdc.OutputFieldClientSide(cls.CONFIRM_BTN_ID, "disabled", *cls.hasnt_required_data()),)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return layout(
            cls.LABEL,
            cls.CONFIRM_BTN,
            sdc.create_id(parent_id, cls.CONFIRM_BTN_ID),
            cls.CONFIRM_BTN_COLOR,
            sdc.get_child_layout(parent_id, cls.weight),
            sdc.get_child_layout(parent_id, cls.scrap),
            config.read_only,
        )

    @classmethod
    def update_weight(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function addNewScrap(viewModel, n_clicks, ctx){
                    if (viewModel.scrap.selected_option !== undefined && viewModel.weight.value !== undefined){
                        const weightInKgs = viewModel.weight.value * 1000;
                        const availableScraps = ctx.models.availableScraps.getAll();
                        const newScrap = Object.values(ctx.models.scrapDefinitions.getAll()).find(scrap => scrap.tms_id === viewModel.scrap.selected_option);
                        const maybeScrap = Object.values(availableScraps).find(scrap => scrap.scrap_type === newScrap.scrap_type);
                        if (!maybeScrap){
                            ctx.models.availableScraps.add(
                                {
                                    "scrap_type": newScrap.scrap_type,
                                    "weight": weightInKgs,
                                    "located_outdoor": false,
                                }
                            );
                        } else {
                            for (let scrapId in availableScraps){
                                if (availableScraps[scrapId].scrap_type == maybeScrap.scrap_type){
                                    ctx.models.availableScraps.update(
                                        scrapId,
                                        {
                                            "weight": maybeScrap.weight + weightInKgs
                                        }
                                    );
                                    break;
                                }
                            }
                        }
                    }

                    newObj = Object.assign(viewModel);
                    newObj.weight.value = undefined;
                    newObj.scrap.selected_option = undefined;
                    return newObj;
                }
                """
            ),
            "addNewScrap",
        )

    @classmethod
    def hasnt_required_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasntRequiredData", [], "return (!this.weight.value || !this.scrap.selected_option);"
        )
