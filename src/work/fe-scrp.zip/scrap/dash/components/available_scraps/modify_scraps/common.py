from typing import Any, Dict

import dash_bootstrap_components as dbc
from attr import frozen
from dash import dcc, html
from ussksdc.components.inputs.number import ClientNumberInputVM

# class names
COMPONENT_WRAPPER = "add-available-scrap-wrapper"
FORM_WRAPPER = "add-available-scrap-form-wrapper"


@frozen
class WeightInputVM(ClientNumberInputVM):
    @classmethod
    def dbc_input_options(cls) -> Dict[str, Any]:
        return {
            **super().dbc_input_options(),
            "min": 0,
            "placeholder": "Hmotnosť šrotu",
        }


def layout(  # pylint: disable=too-many-arguments
    label: str,
    btn_label: str,
    btn_id: str,
    btn_color: str,
    weight_input: dbc.Input,
    selector: dcc.Dropdown,
    read_only: bool,
) -> html.Div:
    return html.Div(
        className=COMPONENT_WRAPPER,
        children=[
            html.H6(label),
            html.Div(
                className=FORM_WRAPPER,
                children=[
                    selector,
                    dbc.InputGroup(
                        [
                            weight_input,
                            dbc.InputGroupText("t"),
                        ],
                    ),
                    dbc.Button(
                        btn_label,
                        id=btn_id,
                        color=btn_color,
                    ),
                ],
            ),
        ],
        hidden=read_only,
    )
