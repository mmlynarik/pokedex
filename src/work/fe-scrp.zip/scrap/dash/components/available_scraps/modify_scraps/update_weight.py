from typing import Optional, Tuple

import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.available_scraps.modify_scraps.common import WeightInputVM, layout
from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@frozen
class AvailableScrapSelectorVM:
    SELECTOR_ID = "selector"
    CHOOSE_SCRAP = "Zvoľte z dostupných šrotov"

    selected_option: Optional[int] = sdc.clientside_two_way_binding(SELECTOR_ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Dropdown:
        return dcc.Dropdown(
            id=sdc.create_id(parent_id, cls.SELECTOR_ID),
            placeholder=cls.CHOOSE_SCRAP,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.SELECTOR_ID, "options", *cls.get_options_from_table()),)

    @classmethod
    def get_options_from_table(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getAvailableScraps",
            ["viewModel", "ctx"],
            """
            var options = [];
            for (const [id, scrap] of Object.entries(ctx.models.availableScraps.getAll())){
                if (scrap.weight === 0)
                    continue
                options.push({
                    label: ctx.models.scrapDefinitions.getDisplayName(scrap.scrap_type),
                    search: scrap.tms_id,
                    value: id,
                    disabled: false,
                    title: scrap.description,
                });
            }
            return options;
            """,
        )


@frozen
class UpdateAvailableScrapWeightVM:
    # Component ids
    SCRAP_SELECTOR_ID = "scrap"
    WEIGHT_INPUT_ID = "weight"
    CONFIRM_BTN_ID = "confirm"
    # User friendly msg
    CONFIRM_BTN = "Aktualizácia váhy šrotu"
    CONFIRM_BTN_COLOR = "secondary"
    LABEL = "Aktualizuj váhu"

    scrap: AvailableScrapSelectorVM = sdc.child_component(SCRAP_SELECTOR_ID, factory=AvailableScrapSelectorVM)
    weight: WeightInputVM = sdc.child_component(WEIGHT_INPUT_ID, factory=WeightInputVM)

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (sdc.InputFieldClientSide(cls.CONFIRM_BTN_ID, "n_clicks", *cls.update_weight()),)

    @classmethod
    def get_output_fields(cls, config: ScrapLoadingStationConfig) -> sdc.OutputFields:
        if config.read_only:
            return ()
        return (sdc.OutputFieldClientSide(cls.CONFIRM_BTN_ID, "disabled", *cls.hasnt_required_data()),)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            [
                layout(
                    cls.LABEL,
                    cls.CONFIRM_BTN,
                    sdc.create_id(parent_id, cls.CONFIRM_BTN_ID),
                    cls.CONFIRM_BTN_COLOR,
                    sdc.get_child_layout(parent_id, cls.weight),
                    sdc.get_child_layout(parent_id, cls.scrap),
                    config.read_only,
                ),
            ]
        )

    @classmethod
    def update_weight(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function updateScrapWeight(viewModel, n_clicks){
                    const tonsToKgs = weight => (Number(weight) === weight) ? weight * 1000 : weight;
                    if (viewModel.scrap.selected_option !== undefined && viewModel.weight.value !== undefined)
                        ctx.models.availableScraps.update(
                            viewModel.scrap.selected_option, {"weight": tonsToKgs(viewModel.weight.value)}
                        );

                    newObj = {...viewModel};
                    newObj.weight.value = undefined;
                    newObj.scrap.selected_option = undefined;
                    return newObj;
                }
                """
            ),
            "updateScrapWeight",
        )

    @classmethod
    def hasnt_required_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasntRequiredData",
            [],
            "return (this.weight.value === undefined || this.scrap.selected_option === undefined);",
        )
