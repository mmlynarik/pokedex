from datetime import date, datetime
from typing import Optional, Protocol, Tuple, Container

from django.contrib.auth.models import User
from scrap.dash.components.grade_group.datasource import GradeGroupTableDataSource
from scrap.dash.components.loaded_baskets.datasource import LoadedBasketsDataSource
from scrap.dash.components.purchase_optimization_bar.datasource import PurchaseOptimizations
from scrap.dash.components.scrap_group.datasource import ScrapGroupTableDataSource
from scrap.models import (
    ScrapPurchaseOptimizationDisplayData,
    ScrapPurchaseOptimizationInput,
    ScrapPurchaseOptimizationResult,
    ScrapPurchaseOptimizationSettings,
    BaseDeltaRuleData,
    ProductionPlanData,
    RealizedScrapOfferData,
    ScrapOfferData,
    ScrapStateData,
)


# TODO Better name for file and split dependencies of different apps
class SelectedLoadingStationSource(Protocol):
    selected_loading_station_id: Optional[int]


class SelectedGradeIdSource(Protocol):
    selected_grade_id: Optional[int]


class SelectedGradeGroupSource(Protocol):
    selected_grade_group_id: Optional[int]


class LoggedUserSource(Protocol):
    logged_user: User


class ScrapGroupsSource(Protocol):
    scrap_groups_source: ScrapGroupTableDataSource


class GradeGroupsSource(Protocol):
    grade_groups_source: GradeGroupTableDataSource


class SettingsAppFiltersSource(
    SelectedLoadingStationSource,
    SelectedGradeIdSource,
    SelectedGradeGroupSource,
    LoggedUserSource,
    ScrapGroupsSource,
    GradeGroupsSource,
    Protocol,
): ...


class ScrapPurchaseIdSource(Protocol):
    scrap_purchase_id: int


class ScrapPurchaseDateSource(Protocol):
    purchase_date: date


class PurchaseOptimizationsDataSource(Protocol):
    purchase_optimizations: PurchaseOptimizations


class UserDataSource(Protocol):
    logged_user: User

    def get_logged_user_username(self) -> str: ...

    def get_user_in_control_username(self) -> str: ...


class ScrapOfferDataSource(Protocol):
    def get_scrap_offer_data(self, suppliers: Container[str] = ()) -> ScrapOfferData: ...


class PurchaseOptimizationInputs(ScrapOfferDataSource, Protocol):
    def get_delta_conditions(self) -> BaseDeltaRuleData: ...

    def get_optimization_settings(self) -> ScrapPurchaseOptimizationSettings: ...

    def get_scrap_state_data(self) -> ScrapStateData: ...

    def get_realized_scrap_offer_data(self, suppliers: Container[str] = ()) -> RealizedScrapOfferData: ...

    def get_production_plan_data(self) -> ProductionPlanData: ...

    def get_production_plan_date(self) -> Optional[datetime]: ...

    def get_production_plan_nr_of_weeks(self) -> int: ...

    def get_user_defined_expected_steel_production(self) -> Optional[int]: ...

    def get_scrap_stock_objective(self) -> Optional[int]: ...

    def get_export_slabs_weight(self) -> int: ...

    def get_mean_scrap_weight(self) -> int: ...

    def get_suppliers(self) -> Tuple[str, ...]: ...

    def get_last_update_time(self) -> datetime: ...


class PurchaseOptimizationDataSource(Protocol):
    def add_new_optimization(
        self, optimization_input: ScrapPurchaseOptimizationInput
    ) -> ScrapPurchaseOptimizationResult: ...


class ScrapOfferDataSource(PurchaseOptimizationInputs, Protocol):
    def update_computations(
        self,
        new_computations: Tuple[ScrapPurchaseOptimizationDisplayData, ...],
    ) -> None: ...

    def update_scrap_offer_data_and_base_delta_rule_data(
        self,
        new_scrap_offer_data: ScrapOfferData,
        new_base_delta_rule_data: BaseDeltaRuleData,
    ) -> None: ...

    def update_scrap_offer_data_and_realized_scrap_offer_data(
        self, new_scrap_offer_data: ScrapOfferData, new_realized_scrap_offer_data: RealizedScrapOfferData
    ) -> None: ...

    def update_scrap_offer_data(self, new_scrap_offer_data: ScrapOfferData) -> None: ...

    def add_optimization(
        self, pk: int, optimizations: Tuple[ScrapPurchaseOptimizationDisplayData, ...]
    ) -> None: ...

    def freeze_unfreeze_scrap_offer(self, offer_id: str) -> None: ...

    def update_scrap_offer(self, offer_id: str, **kwargs) -> None: ...

    def delete_scrap_offer(self, offer_id: int) -> None: ...

    def add_new_scrap_offer(self) -> str: ...

    def remove_realized_offer(self, offer_idx: int) -> None: ...

    def finish_purchase(self) -> None: ...

    def take_control_over_purchase(self, new_user: User) -> None: ...

    def freeze_unfreeze_offers(self, scrap_offers: ScrapOfferData) -> None: ...


class DBScrapOfferDataSource(Protocol):
    db_purchase_data_source: ScrapOfferDataSource


class DBPurchaseOptimizationDataSource(Protocol):
    db_purchase_optimization_data_source: PurchaseOptimizationDataSource


class DBUsersDataSource(Protocol):
    db_user_data: UserDataSource


class PurchaseInfoDataSource(Protocol):
    scrap_purchase_info: str


class FilteredOffersIdsDataSource(Protocol):
    filtered_offers_ids: Tuple[str, ...]


class ScrapPurchasesDataSource(Protocol):
    purchase_date: date
    last_month: date

    def create(self, supplier: str, scrap_type: str, zone: str, price: float) -> int: ...

    def update(self, scrap_purchase_id: int, **kwargs) -> None: ...


class ScrapPurchaseAppSource(
    DBUsersDataSource,
    ScrapPurchaseIdSource,
    ScrapPurchaseDateSource,
    PurchaseInfoDataSource,
    DBScrapOfferDataSource,
    DBPurchaseOptimizationDataSource,
    PurchaseOptimizationsDataSource,
    FilteredOffersIdsDataSource,
    ScrapPurchasesDataSource,
    Protocol,
): ...


class LoadedBasketCompatibilitySource(Protocol):
    loading_station_id: int
    selected_grade_id: Optional[int]
    datasource: LoadedBasketsDataSource
