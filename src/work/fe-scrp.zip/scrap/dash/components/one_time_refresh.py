from typing import Tuple

from attr import frozen
from dash import dcc

import ussksdc as sdc
from ussksdc.core.datamodel import JsCode


@frozen
class OneTimeRefreshVM:
    ONE_TIME_INTERVAL_ID = "interval"

    n_intervals: int = sdc.binding(
        ONE_TIME_INTERVAL_ID,
        "n_intervals",
        cs_read=True,
        cs_state=True,
        cs_write=False,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=-1,
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Interval:
        return dcc.Interval(id=sdc.create_id(parent_id, cls.ONE_TIME_INTERVAL_ID))

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ONE_TIME_INTERVAL_ID, "disabled", *cls.stop_one_time_callback()),
        )

    @classmethod
    def stop_one_time_callback(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function disabledInterval(){
                    if (this.n_intervals === 1)
                        return true;
                    return false;
                }
                """
            ),
            "disabledInterval",
        )
