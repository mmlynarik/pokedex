from typing import List, Tuple
import attr

from dash import html, dcc
import dash_mantine_components as dmc
import ussksdc as sdc

from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class ErrorHandlerMsg:
    ERROR_MSG_STORE_ID = "msg-store"
    ERROR_MSG_HANDLER_ID = "error-msg-handler"
    SHOW_MORE_ID = "show-more"
    ALL_ERROR_MODAL = "modal"
    FIRST_MSG_ID = "first-msg"

    error: Tuple[str, ...] = sdc.binding(
        ERROR_MSG_STORE_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=(),
    )
    error_msg_text: List[dmc.Text] = sdc.one_way_binding(ALL_ERROR_MODAL, "children", default=[])
    show_more_visibility: str = sdc.one_way_binding(SHOW_MORE_ID, "className", default="invisible")
    first_error: str = sdc.one_way_binding(FIRST_MSG_ID, "children", default="")
    title: str = sdc.one_way_binding(ALL_ERROR_MODAL, "title", default="Error list")
    opened: bool = sdc.clientside_one_way_binding_with_state(ALL_ERROR_MODAL, "opened", default=False)

    @classmethod
    def create(cls, title: str) -> "ErrorHandlerMsg":
        return cls(title=title)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                html.Div(id=sdc.create_id(parent_id, cls.FIRST_MSG_ID)),
                dmc.Button(
                    "Zobraziť ďalšie",
                    id=sdc.create_id(parent_id, cls.SHOW_MORE_ID),
                    variant="subtle",
                    color="red",
                    compact=True,
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.ERROR_MSG_STORE_ID)),
                dmc.Modal(
                    id=sdc.create_id(parent_id, cls.ALL_ERROR_MODAL), centered=True, zIndex=10000, size="50%"
                ),
            ],
            id=sdc.create_id(parent_id, cls.ERROR_MSG_HANDLER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.SHOW_MORE_ID, "n_clicks", *cls.open_modal()),)

    @classmethod
    def open_modal(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "openModal",
            ["viewModel", "nClicks"],
            """
            var updatedVm = {...viewModel};
            updatedVm.opened = true;
            return updatedVm;
            """,
        )

    def set_error(self, error: Tuple[str, ...]) -> "ErrorHandlerMsg":
        return attr.evolve(
            self,
            error=error,
            first_error="" if not error else error[0] + "...",
            show_more_visibility="invisible" if len(error) < 2 else "",
            error_msg_text=[dmc.Text(e) for e in error],
        )
