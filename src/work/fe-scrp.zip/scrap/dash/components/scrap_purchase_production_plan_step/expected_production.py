from typing import Dict, Optional

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from scrap.dash.components.protocols.create_scrap_purchase import CreateScrapPurchaseSource

from scrap_core.utils import convert_kilograms_to_tons


def calculate_expected_production(daily_production: Dict[str, int], number_of_weeks: int) -> int:
    return sum(daily_production.values()) * 7 * number_of_weeks


@attr.frozen
class ExpectedProductionVM:
    # Component id
    COMPONENT_ID = "input"
    USER_DEFINED_EXPECTED_PRODUCTION_ID = "user-defined-expected-production"
    CALCULATED_EXPECTED_PRODUCTION_ID = "calculated-expected-production"
    # User friendly msg
    LABEL = "Očakávaná produkcia ocele"
    DESC = "Očakavaná produkcia ocele uvedená v tonách"

    MEAN_DAILY_PRODUCTION_PER_STEELSHOP = {"OC1": 6336000, "OC2": 7226000}  # in kgs
    DEFAULT_PRODUCTION_WEEKS = 4

    expected_production: Optional[int] = sdc.clientside_only_state_binding(
        COMPONENT_ID, "value", default=None
    )
    user_defined_expected_production: Optional[int] = sdc.binding(
        USER_DEFINED_EXPECTED_PRODUCTION_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    calculated_expected_production: Optional[int] = sdc.one_way_binding(
        CALCULATED_EXPECTED_PRODUCTION_ID, "data", default=None
    )

    @classmethod
    def create(cls, user_defined_expected_production: Optional[int]) -> "ExpectedProductionVM":
        return cls(
            user_defined_expected_production=user_defined_expected_production,
            calculated_expected_production=calculate_expected_production(
                cls.MEAN_DAILY_PRODUCTION_PER_STEELSHOP, cls.DEFAULT_PRODUCTION_WEEKS
            ),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.COMPONENT_ID, "value", cls.set_user_input),)

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputField(cls.COMPONENT_ID, "value", cls.get_input_value),)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dmc.NumberInput(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    label=cls.LABEL,
                    description=cls.DESC,
                    debounce=700,
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.USER_DEFINED_EXPECTED_PRODUCTION_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.CALCULATED_EXPECTED_PRODUCTION_ID)),
            ]
        )

    def set_user_input(self, value: Optional[int], ctx: CreateScrapPurchaseSource) -> "ExpectedProductionVM":
        updated_data = attr.evolve(self, user_defined_expected_production=value)
        if value is not None:
            return updated_data
        return attr.evolve(
            updated_data,
            calculated_expected_production=calculate_expected_production(
                self.MEAN_DAILY_PRODUCTION_PER_STEELSHOP, ctx.production_plan_weeks
            ),
        )

    def get_input_value(self) -> int:
        return (
            self.user_defined_expected_production
            if self.user_defined_expected_production is not None
            else convert_kilograms_to_tons(self.calculated_expected_production)
        )
