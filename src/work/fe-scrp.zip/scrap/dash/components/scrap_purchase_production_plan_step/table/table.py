from datetime import date
from typing import Dict, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from dash_ag_grid import AgGrid
from scrap.dash.components.scrap_purchase_production_plan_step.table.datamodel import (
    DataResource,
    ProductionPlanTableData,
    ProductionPlanTableDataSource,
    convert_to_production_plan_table_data,
)
from scrap.models import converter
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from usskssgrades.ispv_hook import PlannedHeatWeek


@attr.frozen
class ProductionPlanTableVM:
    # Components ids
    COMPONENT_ID = "table"
    GRADE_COLUMN_ID = "grade"
    AMOUNT_COLUMN_ID = "amount"
    TABLE_WRAPPER_ID = "table-wrapper"
    DATA_RESOURCE_ID = "data-resource"
    # User friendly msg
    GRADE_COLUMN = "Akosť"
    AMOUNT_COLUMN = "Množstvo"

    PAGE_SIZE = 10

    data_resource: Dict[str, str] = sdc.binding(
        DATA_RESOURCE_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=[],
    )
    unstructured_data: ProductionPlanTableData = sdc.binding(
        COMPONENT_ID,
        "rowData",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=[],
    )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.TABLE_WRAPPER_ID, "hidden", *cls.hasnt_data()),)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            id=sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID),
            children=[
                AgGrid(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    className="ag-theme-alpine-dark",
                    columnDefs=[
                        {"headerName": cls.GRADE_COLUMN, "field": cls.GRADE_COLUMN_ID},
                        {
                            "headerName": cls.AMOUNT_COLUMN,
                            "field": cls.AMOUNT_COLUMN_ID,
                            "valueFormatter": {"function": "d3.format(' .4f')(params.value) + ' t'"},
                        },
                    ],
                    defaultColDef={"sortable": True, "filter": True},
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={
                        "pagination": True,
                        "paginationPageSize": cls.PAGE_SIZE,
                    },
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.DATA_RESOURCE_ID)),
            ],
        )

    @classmethod
    def hasnt_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasntData",
            ["viewModel"],
            "return (viewModel.unstructured_data == null || viewModel.unstructured_data.length == 0);",
        )

    @property
    def data(self) -> Tuple[ProductionPlanTableDataSource, ...]:
        return tuple(converter.structure(d, ProductionPlanTableDataSource) for d in self.unstructured_data)

    def set_data(
        self, data: Tuple[PlannedHeatWeek, ...], plan_date: date, weeks: int
    ) -> "ProductionPlanTableVM":
        return attr.evolve(
            self,
            unstructured_data=[d.table_row for d in convert_to_production_plan_table_data(data)],
            data_resource=converter.unstructure(DataResource(plan_date, weeks)),
        )
