import attr
from typing import Tuple, Dict, Union
from scrap_core.utils import convert_kilograms_to_tons
from usskssgrades.ispv_hook import PlannedHeatWeek
from scrap.dash.database_api import steel_grades

from scrap.models import ProductionPlan

ProductionPlanTableData = Tuple[Dict[str, Union[str, int]], ...]


@attr.frozen
class DataResource:
    plan_date: str = attr.ib(converter=lambda dt: dt.strftime("%Y-%m-%d"))
    weeks: int = attr.ib()


@attr.frozen
class ProductionPlanTableDataSource:
    grade: str
    amount: int

    @property
    def table_row(self) -> Dict[str, Union[str, int]]:
        return attr.asdict(self)

    @property
    def as_production_plan(self) -> ProductionPlan:
        return ProductionPlan(scrap_grade_name=self.grade, scrap_amount=self.amount)


def get_production_plan_with_grade_name(planned_heat_week: PlannedHeatWeek) -> ProductionPlan:
    scrap_grade_name = steel_grades.get_display_name(planned_heat_week.grade_id, planned_heat_week.monday)
    return ProductionPlan(
        scrap_grade_name=scrap_grade_name,
        scrap_amount=convert_kilograms_to_tons(planned_heat_week.weight),
    )


def convert_to_production_plan_table_data(
    planned_heat_week_data: Tuple[PlannedHeatWeek, ...]
) -> Tuple[ProductionPlanTableDataSource, ...]:
    production_plan_data = tuple(
        get_production_plan_with_grade_name(planned_heat_week) for planned_heat_week in planned_heat_week_data
    )
    planned_grades = set(production_plan.scrap_grade_name for production_plan in production_plan_data)
    production_plan_processed = tuple(
        ProductionPlan(
            scrap_grade_name=grade,
            scrap_amount=sum(
                production_plan.scrap_amount
                for production_plan in production_plan_data
                if production_plan.scrap_grade_name == grade
            ),
        )
        for grade in planned_grades
    )
    return tuple(
        ProductionPlanTableDataSource(
            grade=production_plan.scrap_grade_name, amount=production_plan.scrap_amount
        )
        for production_plan in production_plan_processed
    )
