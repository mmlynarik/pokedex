from datetime import date, datetime
from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from scrap.dash.components.protocols.create_scrap_purchase import CreateScrapPurchaseSource
from scrap.dash.components.scrap_purchase_production_plan_step.expected_production import ExpectedProductionVM
from scrap.dash.components.scrap_purchase_production_plan_step.table.table import ProductionPlanTableVM
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class PurchaseProductionPlanVM:
    # Component ids
    COMPONENT_ID = "step"
    DATE_INPUT_ID = "date"
    WEEKS_INPUT_ID = "weeks"
    EXPORT_SLABS_INPUT_ID = "export-slabs-weight"
    LOAD_PRODUCTION_PLAN_ID = "load-production-plan"
    # User friendly msg
    DATE_LABEL = "Dátum"
    DATE_DESC = "Dátum od ktorého sa načíta plán výroby"
    NUMBER_OF_WEEKS_LABEL = "Počet týždňov"
    NUMBER_OF_WEEKS_DESC = "Počet týždňov pre ktoré sa načíta plán výroby"
    EXPORT_SLABS_LABEL = "Brámy na export"
    EXPORT_SLABS_DESC = "Predpokladaná hmotnosť exportných brám v tonách"
    LOAD_BTN_LABEL = "Načítaj plán výroby"
    UPDATE_BTN_LABEL = "Aktualizuj plán výroby"

    DATE_FORMAT = "MMMM DD, YYYY"
    OUTPUT_DATE_FORMAT = "%Y-%m-%d"
    DEFAULT_PRODUCTION_WEEKS = 4

    plan_date: Optional[str] = sdc.binding(
        DATE_INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=False,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    weeks: Optional[int] = sdc.binding(
        WEEKS_INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=4,
    )
    expected_production: ExpectedProductionVM = sdc.child_component(
        "expected-production", factory=ExpectedProductionVM
    )
    export_slabs_weight: int = sdc.binding(
        EXPORT_SLABS_INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=0,
    )
    table: ProductionPlanTableVM = sdc.child_component("data", factory=ProductionPlanTableVM)

    @classmethod
    def create(
        cls, user_defined_expected_production: Optional[int] = None, export_slabs_weight: int = 0
    ) -> "PurchaseProductionPlanVM":
        return cls(
            expected_production=ExpectedProductionVM.create(
                user_defined_expected_production=user_defined_expected_production
            ),
            export_slabs_weight=export_slabs_weight,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.expected_production),
                dmc.LoadingOverlay(
                    dmc.Group(
                        [
                            dmc.DatePicker(
                                id=sdc.create_id(parent_id, cls.DATE_INPUT_ID),
                                label=cls.DATE_LABEL,
                                description=cls.DATE_DESC,
                                inputFormat=cls.DATE_FORMAT,
                            ),
                            dmc.NumberInput(
                                value=4,
                                id=sdc.create_id(parent_id, cls.WEEKS_INPUT_ID),
                                label=cls.NUMBER_OF_WEEKS_LABEL,
                                description=cls.NUMBER_OF_WEEKS_DESC,
                                debounce=700,
                            ),
                            dmc.NumberInput(
                                value=0,
                                id=sdc.create_id(parent_id, cls.EXPORT_SLABS_INPUT_ID),
                                label=cls.EXPORT_SLABS_LABEL,
                                description=cls.EXPORT_SLABS_DESC,
                                debounce=700,
                            ),
                        ],
                        grow=True,
                    ),
                ),
                sdc.get_child_layout(parent_id, cls.table),
                dmc.Button(id=sdc.create_id(parent_id, cls.LOAD_PRODUCTION_PLAN_ID)),
            ],
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.LOAD_PRODUCTION_PLAN_ID, "n_clicks", cls.load_production_plan),)

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(
                cls.LOAD_PRODUCTION_PLAN_ID, "disabled", *cls.hasnt_start_data_and_weeks()
            ),
            sdc.OutputFieldClientSide(cls.LOAD_PRODUCTION_PLAN_ID, "className", *cls.set_visibility()),
            sdc.OutputFieldClientSide(cls.LOAD_PRODUCTION_PLAN_ID, "children", *cls.set_label()),
        )

    @property
    def production_plan_date(self) -> Optional[datetime]:
        if self.plan_date is None:
            return None
        return datetime.strptime(self.plan_date, self.OUTPUT_DATE_FORMAT)

    def load_production_plan(self, _: int, ctx: CreateScrapPurchaseSource) -> "PurchaseProductionPlanVM":
        return attr.evolve(
            self,
            table=self.table.set_data(
                ctx.models.ispv.get_production_plan(self.production_plan_date, self.weeks),
                self.production_plan_date,
                self.weeks,
            ),
        )

    @classmethod
    def set_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setVisibility",
            ["viewModel", "ctx"],
            """
            if (
                viewModel.table.unstructured_data != null &&
                viewModel.table.unstructured_data.length > 0 &&
                viewModel.table.data_resource != null &&
                viewModel.table.data_resource.weeks === viewModel.weeks &&
                viewModel.table.data_resource.plan_date === viewModel.plan_date
                )
                return 'invisible';
            return '';
            """,
        )

    @classmethod
    def set_label(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setLabel",
            ["viewModel", "ctx"],
            Template(
                """
            if (viewModel.table.unstructured_data != null && viewModel.table.unstructured_data.length > 0)
                return '${update_data}';
            return '${load_data}';
            """
            ).substitute(load_data=cls.LOAD_BTN_LABEL, update_data=cls.UPDATE_BTN_LABEL),
        )

    @classmethod
    def hasnt_start_data_and_weeks(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasntStartDataOrWeeks",
            ["viewModel", "ctx"],
            """return (
                viewModel.plan_date == null || viewModel.weeks == null || viewModel.weeks <= 0
            );
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.data_is_valid()),
            sdc.JsCodeField(*cls.mising_fields()),
        )

    @classmethod
    def data_is_valid(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "dataIsValid",
            [],
            """return (
                (
                    this.table.unstructured_data == null ||
                    !this.table.unstructured_data.length
                ) ||
                this.table.data_resource != null &&
                this.table.data_resource.weeks === this.weeks &&
                this.table.data_resource.plan_date === this.plan_date
            );
            """,
        )

    @classmethod
    def mising_fields(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMissingFields",
            [],
            Template(
                """
            var missingFields = [];
            if (!this.plan_date)
                missingFields.push('${plan_date}');
            if (!this.weeks)
                missingFields.push('${weeks}');
            if (!this.expected_production.expected_production)
                missingFields.push('${expected_production}');
            if (!this.table.unstructured_data.length)
                missingFields.push('${plan}');
            if (!this.dataIsValid())
                missingFields.push('${update}');
            return missingFields;
            """
            ).substitute(
                plan_date=cls.DATE_LABEL,
                weeks=cls.NUMBER_OF_WEEKS_LABEL,
                expected_production=ExpectedProductionVM.LABEL,
                plan=cls.LOAD_BTN_LABEL,
                update=cls.UPDATE_BTN_LABEL,
            ),
        )
