import json
from functools import lru_cache, partial
from typing import Any, Callable, Dict, List, Optional, Tuple, TypeVar

import attr
import dash_bootstrap_components as dbc
from dash import dcc, html
from scrap_core.utils import convert_kilograms_to_tons
from common.dash import create_bootstrap_column_with_header, create_main_div
from scrap.dash.components.raw_fe_chem_table import RawFeChemTableData, convert_raw_fe_chem_to_table_data
from scrap.dash.components.scrap_charge_limits_table import (
    ScrapChargeLimitsTableData,
    convert_scrap_limits_to_table_data,
)
from scrap.dash.components.scrap_charge_optimization_card_v2 import create_scrap_charge_optimization_card_v2
from scrap.dash.components.scrap_charges_table import create_scrap_charge_table, get_basket_ids_display_value
from scrap.dash.components.scrap_table_ls import create_scrap_table_ls
from scrap.dash.components.one_heat_optimizer_v2 import (
    get_relaxable_upper_summing_limits_for_grade,
    get_relaxable_lower_summing_limits_for_grade,
)
from scrap.dash.database_api import steel_grades
from scrap.models import (
    DEFAULT_SCRAP_WEIGHT,
    LoadingStationDisplayDataV2,
    OptimizationDisplayDataV2,
    ScrapChargeDisplayDataV2,
    LoadingStation,
    converter,
    all_prefetched_loading_station_query_set,
)
from scrap_core import ScrapOrder, ScrapMix, ScrapMixOrder
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.datamodel import ModelSettings, ScrapMixLimits
from scrap_core.optimization.validations import (
    NO_VALIDATION_PROBLEMS,
    ChargeInfoValidationResult,
    join_validation_results,
    validate_basket_ids,
    validate_scrap_mix_ratios,
    validate_grade_id,
    validate_heat_id,
    validate_pig_iron_weight,
    validate_raw_fe_chem,
    validate_scrap_limits,
    validate_switched_basket_ids,
    validate_total_scrap_weight,
)

DISPLAY_DATA_STORE_ID = "display-data"
MAIN_DIV_ID = "scrap-model"
SCRAP_TABLE_ID = "scrap_table"
SCRAP_TYPE_DROPDOWN_ID = "scrap-type"
SCRAP_CHARGE_TABLE_ID = "scrap-charge-table"
OPTIMIZATION_PROGRESS_BAR_REFRESH_INTERVAL_ID = "calculate-optimization-interval-component"
DEBUG_ELEMENT_ID = "debug"
RELOAD_DATA_INTERVAL_ID = "reload-data-interval"
LOADING_STATION_ID_DIV_ID = "loading-station-id"
GLOBAL_ERROR_MODAL_ID_INPUT = "global-modal-error-input"
GLOBAL_ERROR_MODAL_ID_OUTPUT = "global-modal-error-output"
REFRESH_REQUEST_MODAL_ID = "global-modal-refresh-request"
CONTROL_CHANGED_MODAL_ID = "global-model-control-changed"
STATUS_ID = "floating-div"
STATION_NAME_ID = "navbar-station-name"
USER_NAME_ID = "navbar-username"
USER_IN_CONTROL_NAME_ID = "navbar-username-incontrol"
DEBUG_COLLAPSE_BTN_ID = "debug-collapse-btn"
DEBUG_COLLAPSE_ID = "debug-collapse"

T = TypeVar("T")


@attr.s(frozen=True, auto_attribs=True, slots=True)
class ScrapLoadingStationViewModelV2:
    loading_station_id: int
    loading_station_name: str
    user: str
    user_in_control: str
    authorized_users: Tuple[str, ...]
    display_data: LoadingStationDisplayDataV2
    debug: bool
    level_2: bool
    steelshop: Optional[int]
    read_only: bool
    selected_row: Optional[int]
    advanced_settings_open: bool
    results_detail_open: bool
    error: bool
    scrap_mix_for_append: Optional[ScrapMix]
    scrap_mix_for_update: Optional[ScrapMix]
    scrap_weight_for_append: Optional[float]
    scrap_weight_for_update: Optional[float]
    debug_data_open: bool
    available_grades: List[Dict[str, Any]]
    available_scraps: ScrapOrder
    control_gained: bool
    control_lost: bool
    transfer_capacity: Optional[float]
    model_settings: ModelSettings

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def to_context_data(self) -> dict:
        # Better will be to assign data directly to components
        # Unfortunatelly it does not work for dash tables now :( so we need to use this hack
        return {DISPLAY_DATA_STORE_ID: {"children": self.serialize()}}

    def update_display_data_field(self, **kwargs) -> "ScrapLoadingStationViewModelV2":
        return attr.evolve(self, display_data=attr.evolve(self.display_data, **kwargs))

    def update_field(self, **kwargs) -> "ScrapLoadingStationViewModelV2":
        return attr.evolve(self, **kwargs)

    def update_charge_field(self, index, **kwargs) -> "ScrapLoadingStationViewModelV2":
        new_scrap_charges = []
        for i, scrap_charge in enumerate(self.display_data.scrap_charges):
            if i == index:
                new_scrap_charges.append(attr.evolve(scrap_charge, **kwargs))
            else:
                new_scrap_charges.append(scrap_charge)
        return attr.evolve(self, display_data=attr.evolve(self.display_data, scrap_charges=new_scrap_charges))

    def update_selected_charge_field(self, **kwargs) -> "ScrapLoadingStationViewModelV2":
        if self.selected_row is None:
            return self
        return self.update_charge_field(self.selected_row, **kwargs)

    def get_selected_charge_field(self, getter: Callable[[ScrapChargeDisplayDataV2], T]) -> Optional[T]:
        if self.selected_row is None:
            return None
        return getter(self.display_data.scrap_charges[self.selected_row])

    @property
    def selected_charge_optimization_clicked(self) -> Optional[bool]:
        return self.get_selected_charge_field(lambda charge: charge.optimization_start_clicked)

    # TODO do we still need this here currently we do not display heat id anywhere ?
    @property
    def selected_heat_id(self) -> Optional[int]:
        return self.get_selected_charge_field(lambda charge: charge.heat_id)

    # TODO do we still need this here currently we do not display heat id anywhere ?
    @property
    def selected_heat_id_validation_result(self) -> ChargeInfoValidationResult:
        return validate_heat_id(self.selected_heat_id, self.steelshop)

    # TODO typing
    def validate_if_optimization_started(self, validator, value) -> ChargeInfoValidationResult:
        if not value and not self.selected_charge_optimization_clicked:
            return NO_VALIDATION_PROBLEMS
        return validator(value)

    @property
    def selected_basket_ids(self) -> Tuple[int, ...]:
        return self.get_selected_charge_field(lambda charge: charge.basket_ids) or ()

    @property
    def selected_basket_ids_display_value(self) -> str:
        return get_basket_ids_display_value(self.selected_basket_ids)

    @property
    def selected_basket_ids_validation_result(self) -> ChargeInfoValidationResult:
        return self.validate_if_optimization_started(validate_basket_ids, self.selected_basket_ids)

    @property
    def selected_switched_basket_ids(self) -> Tuple[int, ...]:
        return self.get_selected_charge_field(lambda charge: charge.switched_basket_ids) or ()

    @property
    def selected_switched_basket_ids_display_value(self) -> str:
        return get_basket_ids_display_value(self.selected_switched_basket_ids)

    @property
    def selected_switched_basket_ids_validation_result(self) -> ChargeInfoValidationResult:
        return self.validate_if_optimization_started(
            partial(validate_switched_basket_ids, basket_ids=self.selected_basket_ids),
            self.selected_switched_basket_ids,
        )

    @property
    def selected_grade_id(self) -> Optional[int]:
        return self.get_selected_charge_field(lambda charge: charge.grade_id)

    @property
    def selected_grade_id_validation_result(self) -> ChargeInfoValidationResult:
        return self.validate_if_optimization_started(
            partial(validate_grade_id, steel_grades=steel_grades), self.selected_grade_id
        )

    @property
    def selected_total_scrap_weight(self) -> Optional[int]:
        return self.get_selected_charge_field(lambda charge: charge.total_scrap_weight)

    @property
    def selected_total_scrap_weight_display_value(self) -> Optional[float]:
        return (
            convert_kilograms_to_tons(self.selected_total_scrap_weight)
            if self.selected_total_scrap_weight is not None
            else None
        )

    @property
    def selected_total_scrap_weight_or_constant(self) -> int:
        return self.selected_total_scrap_weight or DEFAULT_SCRAP_WEIGHT

    @property
    def selected_total_scrap_weight_validation_result(self) -> ChargeInfoValidationResult:
        return self.validate_if_optimization_started(
            partial(
                validate_total_scrap_weight,
                precision_step=self.model_settings.optimizer_settings.precision_step,
            ),
            self.selected_total_scrap_weight,
        )

    @property
    def selected_pig_iron_weight(self) -> Optional[int]:
        return self.get_selected_charge_field(lambda charge: charge.pig_iron_weight)

    @property
    def selected_pig_iron_weight_display_value(self) -> Optional[float]:
        return (
            convert_kilograms_to_tons(self.selected_pig_iron_weight)
            if self.selected_pig_iron_weight is not None
            else None
        )

    @property
    def selected_pig_iron_weight_validation_result(self) -> ChargeInfoValidationResult:
        return self.validate_if_optimization_started(validate_pig_iron_weight, self.selected_pig_iron_weight)

    @property
    def selected_charge_limits(self) -> ScrapMixLimits:
        return self.get_selected_charge_field(lambda charge: charge.scrap_limits) or ()

    @property
    def selected_charge_limits_display_value(self) -> ScrapChargeLimitsTableData:
        return convert_scrap_limits_to_table_data(self.selected_charge_limits)

    @property
    def selected_charge_limits_validation_result(self) -> ChargeInfoValidationResult:
        station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=self.loading_station_id)
        relaxable_upper_summing_limits_settings = tuple(station.relaxable_upper_summing_limit_settings.all())
        relaxable_lower_summing_limits_settings = tuple(station.relaxable_lower_summing_limit_settings.all())

        available_scraps: ScrapMixOrder = tuple(mix.scrap_type for mix in self.display_data.available_scraps)

        relaxable_lower_summing_limits, relaxable_upper_summing_limits = (), ()
        if self.selected_grade_id is not None:
            relaxable_upper_summing_limits = get_relaxable_upper_summing_limits_for_grade(
                self.selected_grade_id, relaxable_upper_summing_limits_settings
            )
            relaxable_lower_summing_limits = get_relaxable_lower_summing_limits_for_grade(
                self.selected_grade_id, relaxable_lower_summing_limits_settings
            )
        return join_validation_results(
            [
                validate_scrap_limits(
                    self.selected_charge_limits,
                    self.selected_total_scrap_weight_or_constant,
                    self.display_data.available_scraps,
                    relaxable_lower_summing_limits,
                    relaxable_upper_summing_limits,
                    self.selected_grade_id,
                    station.model_settings.optimizer_settings.scrap_mix_mapping,
                ),
                validate_scrap_mix_ratios(
                    station.model_settings.optimizer_settings.scrap_mix_mapping, available_scraps
                ),
            ]
        )

    @property
    def selected_pig_iron_chem(self) -> RawFeChem:
        return self.get_selected_charge_field(lambda charge: charge.raw_fe_chem) or RawFeChem()

    @property
    def selected_pig_iron_chem_display_value(self) -> RawFeChemTableData:
        return convert_raw_fe_chem_to_table_data(self.selected_pig_iron_chem)

    @property
    def selected_pig_iron_chem_validation_result(self) -> ChargeInfoValidationResult:
        return validate_raw_fe_chem(self.selected_pig_iron_chem)

    def update_selected_charge_pig_iron_chem_field(self, **kwargs) -> "ScrapLoadingStationViewModelV2":
        return self.update_charge_field(
            self.selected_row, raw_fe_chem=attr.evolve(self.selected_pig_iron_chem, **kwargs)
        )

    def delete_selected_charge_field(self) -> "ScrapLoadingStationViewModelV2":
        if self.selected_row is None:
            return self
        new_scrap_charges = [
            scrap_charge
            for i, scrap_charge in enumerate(self.display_data.scrap_charges)
            if i != self.selected_row
        ]
        new_selected_row = 0 if new_scrap_charges else None

        return attr.evolve(
            self,
            selected_row=new_selected_row,
            display_data=attr.evolve(self.display_data, scrap_charges=new_scrap_charges),
        )

    def get_all_optimizations_for_selected_charge(self) -> Optional[Tuple[OptimizationDisplayDataV2, ...]]:
        return self.get_selected_charge_field(lambda charge: charge.optimizations)

    def get_last_optimization_for_selected_charge(self) -> Optional[OptimizationDisplayDataV2]:
        optimizations = self.get_all_optimizations_for_selected_charge()
        if not optimizations:
            return None
        return optimizations[-1]

    def update_last_optimization_field(self, **kwargs) -> "ScrapLoadingStationViewModelV2":
        maybe_optimizations = self.get_all_optimizations_for_selected_charge()
        if not maybe_optimizations:
            return self
        updated_optimization = attr.evolve(maybe_optimizations[-1], **kwargs)
        return self.update_selected_charge_field(
            optimizations=(*maybe_optimizations[:-1], updated_optimization)
        )


@lru_cache()
def deserialize_loading_station_view_model_v2(serialized: str) -> ScrapLoadingStationViewModelV2:
    return converter.structure(json.loads(serialized), ScrapLoadingStationViewModelV2)


def get_navbar_component() -> dbc.Navbar:
    loading_info = dbc.Col(
        dcc.Loading(
            id="test-loading",
            children=[
                html.Div(
                    className="text-left text-primary my-auto",
                    id=STATUS_ID,
                    style={
                        "width": "100%",
                        "white-space": "nowrap",
                        "overflow": "visibel",
                    },
                    children="Načítavam...",
                ),
                # Display data store component must be in Loading component to correctly
                # overlap page with loading layer while callbacks are running.
                html.Pre(id=DISPLAY_DATA_STORE_ID, children="", hidden=True),
            ],
            className="my-auto mx-auto",
            type="dot",
        ),
        width=1,
    )
    station_name = dbc.Col(
        html.A("Nákladka koryta", href="/scrap/scrap_loading", id=STATION_NAME_ID),
        className="text-center my-auto font-weight-bold offset-2",
        style={"font-size": "1.2rem"},
        width=6,
    )
    username = dbc.Col(
        [
            html.Div("", id=USER_NAME_ID),
            html.Div(
                dbc.Button(
                    "",
                    id=USER_IN_CONTROL_NAME_ID,
                    color="link",
                    n_clicks=0,
                    style={"color": "green"},
                    className="p-0",
                ),
                id=USER_IN_CONTROL_NAME_ID + "-div",
                hidden=True,
            ),
        ],
        className="text-right my-auto text-primary",
        width=3,
    )
    return dbc.Navbar(
        dbc.Row(
            [loading_info, station_name, username],
            align="betwen",
            className="w-100 align-items-center",
        ),
        color="#f7f7f7",
        className="shadow",
        style={"height": "50px"},
        sticky="sticky",
        fixed="top",
    )


def get_full_screen_modal(modal_id: str, header: str, body: str) -> dbc.Modal:
    return dbc.Modal(
        [dbc.ModalHeader(header), dbc.ModalBody(body)],
        id=modal_id,
        centered=True,
        backdrop="static",
        keyboard=False,
        is_open=False,
    )


def get_full_screen_error_modal(modal_id: str) -> dbc.Modal:
    return get_full_screen_modal(
        modal_id, "Vyskytla sa chyba!", "Nastala chyba v systéme - prosím kontaktujte IT"
    )


def get_available_scrap_component(read_only: bool) -> html.Div:
    scrap_table = create_scrap_table_ls(SCRAP_TABLE_ID, read_only)
    return html.Div(
        [
            html.H5("Dostupné šroty", style={"margin-top": "8px", "margin-bottom": "8px"}),
            dbc.Row(
                dbc.Col(
                    scrap_table,
                    width=12,
                ),
                align="start",
            ),
        ],
        style={"margin": "16px 0px 0px 16px"},
    )


def get_charge_table_component(read_only: bool) -> dbc.Col:
    return create_bootstrap_column_with_header(
        "Nakladané tavby",
        html.Div(create_scrap_charge_table(SCRAP_CHARGE_TABLE_ID, read_only)),
    )


def get_charge_card_component_v2(read_only: bool) -> dbc.Col:
    return dbc.Col(
        create_scrap_charge_optimization_card_v2(read_only),
        width=12,
    )


def get_page_core(read_only: bool) -> dbc.Row:
    charge_card_component = get_charge_card_component_v2(read_only)
    return dbc.Row(
        [
            dbc.Col(
                get_available_scrap_component(read_only),
                sm=12,
                md=4,
                lg=4,
                xl=3,
            ),
            dbc.Col(
                [
                    dbc.Row(
                        [
                            get_charge_table_component(read_only),
                            charge_card_component,
                        ],
                    ),
                ],
                sm=12,
                md=8,
                lg=8,
                xl=9,
            ),
            dbc.Col(get_debug_collapse(), width=12),
        ],
        className="mx-auto",
        id="core-page",
        style={"margin-top": "50px"},
    )


def get_debug_collapse() -> html.Div:
    return html.Div(
        [
            dbc.Button(
                "Vývojárske dáta",
                id=DEBUG_COLLAPSE_BTN_ID,
                color="link",
                n_clicks=0,
                className="font-weight-bold",
                style={"float": "right", "margin-right": "16px", "color": "gray"},
            ),
            dbc.Collapse(
                html.Pre(id=DEBUG_ELEMENT_ID, children=""),
                id=DEBUG_COLLAPSE_ID,
                is_open=False,
            ),
        ],
        hidden=True,
        id=DEBUG_ELEMENT_ID + "-div",
    )


def get_layout(read_only: bool) -> html.Div:
    interval_components = [
        dcc.Interval(
            id=OPTIMIZATION_PROGRESS_BAR_REFRESH_INTERVAL_ID, interval=1500, n_intervals=0, disabled=True
        ),
    ]
    if read_only:
        interval_components.append(
            dcc.Interval(id=RELOAD_DATA_INTERVAL_ID, interval=10000, n_intervals=0, disabled=not read_only)
        )
    all_children = [
        html.Div(id=LOADING_STATION_ID_DIV_ID, hidden=True, children=-1),
        html.Div(interval_components),
        get_navbar_component(),
        get_page_core(read_only),
        get_full_screen_error_modal(GLOBAL_ERROR_MODAL_ID_INPUT),
        get_full_screen_error_modal(GLOBAL_ERROR_MODAL_ID_OUTPUT),
        get_full_screen_modal(
            REFRESH_REQUEST_MODAL_ID,
            "Prevzatie kontroly prebehlo úspešne",
            "Pre pokračovanie je nutné prenačítať stránku",
        ),
        get_full_screen_modal(
            CONTROL_CHANGED_MODAL_ID,
            "Kontrola bola prevziata iným užívateľom",
            "Pre pokračovanie je nutné prenačítať stránku",
        ),
    ]
    return create_main_div(MAIN_DIV_ID, all_children)
