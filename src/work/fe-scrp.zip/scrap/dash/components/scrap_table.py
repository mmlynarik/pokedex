from typing import Callable, List, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, dcc
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

from scrap_core import ScrapMix, ScrapBounds, ScrapCharge
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE
from scrap.models import MultipleHeatsOptimizationOutput, MultipleHeatsOptimizationResult
from . import get_scrap_type_label


class ScrapTableRow(TypedDict):
    label: str
    scrap_mix: ScrapMix
    weight: float


ScrapTableData = List[ScrapTableRow]


def get_scrap_row(scrap_mix: ScrapMix, scrap_weight: float = 0.0) -> ScrapTableRow:
    return {
        "label": get_scrap_type_label(scrap_mix),
        "scrap_mix": scrap_mix,
        "weight": scrap_weight,
    }


def create_scrap_table(
    table_id: str, scrap_type_dropdown_id: str, show_weight: bool = False, read_only: bool = False
) -> dbc.Row:
    cols = [{"name": "Hromada šrotu", "id": "label", "type": "text", "editable": False}]
    if show_weight:
        cols.append({"name": "Hmotnosť [kg]", "id": "weight", "type": "numeric", "editable": 1 - read_only})
    dropdown = dbc.Col()
    if not read_only:
        dropdown = dbc.Col(
            dcc.Dropdown(
                id=scrap_type_dropdown_id,
                placeholder="Pridaj šrot",
                # options parameter is set via callback `set_initial_data`
                style={"margin-top": "16px", "width": "100%"},
            ),
            width=12,
        )

    full_div = dbc.Row(
        [
            dbc.Col(
                dash_table.DataTable(
                    id=table_id,
                    columns=cols,
                    data=[],
                    style_data_conditional=DATA_TEXT_STYLE,
                    style_cell=CELL_STYLE,
                    style_header=TABLE_HEADER_STYLE,
                    row_deletable=not read_only,
                ),
                width=12,
            ),
            dropdown,
        ]
    )
    return full_div


# Why we need initial data here ?
# It's a current limitation of dash - Output can be only used in one callback
# So in this callback we need to cover all possibilities of data update in table (initial data, add new row)
def create_add_scrap_row_callback(scrap_data_from_initial_data: Callable[[str], ScrapTableData]):
    def add_scrap_row_callback(  # pylint: disable=unused-argument
        scrap_mix: ScrapMix, initial_data: str, current_rows: ScrapTableData, **kwargs
    ) -> ScrapTableData:
        if scrap_mix is None:
            return scrap_data_from_initial_data(initial_data)
        currently_used_scrap_mixes = {row["scrap_mix"] for row in current_rows}
        if scrap_mix in currently_used_scrap_mixes:
            return current_rows
        current_rows.append(get_scrap_row(scrap_mix))
        return current_rows

    return add_scrap_row_callback


# pylint: disable=too-many-arguments
def register_add_scrap_callback(
    app: DjangoDash,
    initial_data_id: str,
    table_id: str,
    scrap_type_dropdown_id: str,
    scrap_data_from_initial_data: Callable[[str], ScrapTableData],
):
    app.callback(
        Output(table_id, "data"),
        [Input(scrap_type_dropdown_id, "value"), Input(initial_data_id, "children")],
        [State(table_id, "data")],
    )(create_add_scrap_row_callback(scrap_data_from_initial_data))


def get_scrap_table_data(scrap: ScrapCharge) -> ScrapTableData:
    return [get_scrap_row(scrap_mix, weight) for scrap_mix, weight in scrap.items()]


def get_scrap_charge_model_table_data(result: MultipleHeatsOptimizationResult) -> ScrapTableData:
    output: MultipleHeatsOptimizationOutput = result.result
    scrap_charge = output.scrap_weights_per_heat[0]
    return get_scrap_table_data(scrap_charge)


def get_available_scrap_table_data(available_scrap: ScrapBounds) -> ScrapTableData:
    return get_scrap_table_data(available_scrap)
