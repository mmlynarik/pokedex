from typing import List, Optional, Tuple, Iterable
from math import isfinite

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from usskssgrades import Grade
from scrap_core import Chem
from scrap_core.correctiontechnologiesmodel.correction_technologies import (
    get_correction_technologies_for_grade,
    CorrectionTechnology,
    CorrectionTechnologies,
    CorrectionTechnologyType,
)
from scrap_core.correctiontechnologiesmodel import CorrectionTechnologiesModelOutput
from scrap_core.blendmodel.datamodel import ScrapBlendModelOutput, OrdinalRegressionChemEstimate


def get_widths(binning: Tuple[float, ...], last_bin_width: float) -> Iterable[float]:
    for i in range(len(binning)):
        if i == 0:
            yield binning[i]
        else:
            yield binning[i] - binning[i - 1]
    yield last_bin_width


def get_x(binning: Tuple[float, ...], widths: Iterable[float]) -> List[float]:
    return [b + w / 2 for b, w in zip((0.0,) + binning, widths)]


def add_bmo_histogram_to_fig(
    fig: go.Figure, chem_estimate: OrdinalRegressionChemEstimate, last_bin_width: float
) -> go.Figure:
    """
    Generate histogram of blend model output probabilities using plotly barplot. Since we are adding this plot as a new trace into existing figure, it must be defined as a graph object type (go.Bar), even
    though the original figure to which it will be added has been created as Plotly Express figure.
    """
    widths = list(get_widths(chem_estimate.binning, last_bin_width))
    x = get_x(chem_estimate.binning, widths)
    fig.add_trace(go.Bar(x=x, y=chem_estimate.probas, width=widths, marker={"color": "cornflowerblue"}))
    return fig


def add_bmo_vline_to_fig(
    fig: go.Figure,
    bmo: Optional[ScrapBlendModelOutput],
    chem: Chem,
    value: float,
    label: str,
    position: str = "top",
    width: int = 1,
    line_dash: Optional[str] = None,
) -> go.Figure:
    x = bmo.get_chem_estimate(chem).percentile(value) if bmo is not None else value
    fig.add_vline(
        x=x,
        annotation_text=f"{label} <br> {x:.2}",
        annotation_position=position,
        line_width=width,
        line_dash=line_dash,
    )
    return fig


def get_ordered_cts_for_chem(cts: CorrectionTechnologies, chem: Chem) -> Tuple[CorrectionTechnology, ...]:
    def get_merged_synt_slag_ct_for_chem(
        ct: CorrectionTechnologies, chem: Chem
    ) -> Optional[CorrectionTechnology]:
        slag_cts = [ct for ct in ct.get_chem(chem) if ct.type == CorrectionTechnologyType.SYNT_SLAG]
        if slag_cts:
            return CorrectionTechnology(
                reason=chem,
                lower_limit=min(ct.lower_limit for ct in slag_cts),
                upper_limit=max(ct.upper_limit for ct in slag_cts),
                type=CorrectionTechnologyType.SYNT_SLAG,
            )
        return None

    ok_ct = cts.get_no_correction_ct_for_chem(chem)
    slag_ct = get_merged_synt_slag_ct_for_chem(cts, chem)
    reblow_ct = cts.get_reblow_ct_for_chem(chem)
    reclass_ct = cts.get_reclass_ct_for_chem(chem)
    return tuple(ct for ct in [ok_ct, slag_ct, reblow_ct, reclass_ct] if ct is not None)


def get_ct_bar_plot_marker_color(ordered_cts: Tuple[CorrectionTechnology, ...]) -> List[str]:
    marker_color = ["LimeGreen", "Lime", "Orange", "OrangeRed"]  # NO-CORRECTION->SYNT-SLAG->REBLOW->RECLASS
    if all(ct.type != CorrectionTechnologyType.SYNT_SLAG for ct in ordered_cts):
        marker_color.remove("Lime")
    if all(ct.type != CorrectionTechnologyType.REBLOW for ct in ordered_cts):
        marker_color.remove("Orange")
    if all(ct.type != CorrectionTechnologyType.RECLASSIFICATION for ct in ordered_cts):
        marker_color.remove("OrangeRed")
    return marker_color


def add_text_to_ct_bar_plot(
    fig: go.Figure,
    ordered_cts: Tuple[CorrectionTechnology, ...],
    ctmo: CorrectionTechnologiesModelOutput,
    xaxis_upper_bound: float,
    y: float,
) -> go.Figure:
    def get_mid_value(ct: CorrectionTechnology, upper_bound: float) -> float:
        return (max(ct.lower_limit, 0) + min(ct.upper_limit, upper_bound)) / 2

    texts = [
        f"OK <br> {ctmo.ok_proba:.2%}",
        f"SyntTroska <br> {ctmo.synt_slag_proba:.2%}",
        f"Dofuk <br> {ctmo.reblow_proba:.2%}",
        f"Preplán <br> {ctmo.reclass_proba:.2%}",
    ]
    if all(ct.type != CorrectionTechnologyType.SYNT_SLAG for ct in ordered_cts):
        texts.remove(f"SyntTroska <br> {ctmo.synt_slag_proba:.2%}")
    if all(ct.type != CorrectionTechnologyType.REBLOW for ct in ordered_cts):
        texts.remove(f"Dofuk <br> {ctmo.reblow_proba:.2%}")
    if all(ct.type != CorrectionTechnologyType.RECLASSIFICATION for ct in ordered_cts):
        texts.remove(f"Preplán <br> {ctmo.reclass_proba:.2%}")

    for ct, text in zip(ordered_cts, texts):
        fig.add_annotation(
            text=text,
            x=get_mid_value(ct, xaxis_upper_bound),
            y=y,
            showarrow=False,
        )
    return fig


def get_horizontal_bar_plot(x_values: List[float], y_value: float, height: float, color: List[str]):
    """Creates single-bar barplot using Plotly Express API which is necessary for it to work correctly."""
    df = pd.DataFrame({"x": x_values, "y": len(x_values) * [y_value], "color": color})
    fig = px.bar(df, x="x", y="y", color_discrete_sequence=color, color="color", orientation="h")
    fig.update_traces(width=height)
    return fig


def get_ct_bar_plot(
    ctmo: CorrectionTechnologiesModelOutput,
    chem_estimate: OrdinalRegressionChemEstimate,
    chem: Chem,
    grade: Grade,
    last_bin_width: float,
) -> go.Figure:
    grade_cts = get_correction_technologies_for_grade(grade)
    chem_ordered_cts = get_ordered_cts_for_chem(grade_cts, chem)
    xaxis_upper_bound = max(grade.get_limit(chem).maximum, chem_estimate.binning[-1]) + last_bin_width
    marker_color = get_ct_bar_plot_marker_color(chem_ordered_cts)
    height = max(chem_estimate.probas) / 5
    x_values = [min(ct.upper_limit, xaxis_upper_bound) - max(ct.lower_limit, 0) for ct in chem_ordered_cts]
    y = max(chem_estimate.probas) + 0.02 + height / 2
    fig = get_horizontal_bar_plot(x_values=x_values, y_value=y, height=height, color=marker_color)
    fig = add_text_to_ct_bar_plot(fig, chem_ordered_cts, ctmo, xaxis_upper_bound, y - 0.01)
    return fig


def get_results_histogram_for_chem(
    bmo: ScrapBlendModelOutput,
    ctmo: CorrectionTechnologiesModelOutput,
    chem: Chem,
    actual_eob: Optional[float],
    actual_final: Optional[float],
    grade: Grade,
    last_bin_width: float,
) -> go.Figure:
    chem_estimate: OrdinalRegressionChemEstimate = bmo.get_chem_estimate(chem)
    # Display empty Figure to avoid error log messages when not all necessary values are provided by the user.
    if not isfinite(chem_estimate.probas[0]):
        return go.Figure()
    xaxis_text = {"S": "síry", "Cu": "medi", "Cr": "chrómu", "Mo": "molybdénu", "Sn": "cínu", "Ni": "niklu"}
    fig = get_ct_bar_plot(ctmo, chem_estimate, chem, grade, last_bin_width)
    fig = add_bmo_histogram_to_fig(fig, chem_estimate, last_bin_width)
    fig = add_bmo_vline_to_fig(fig, bmo, chem, 0.05, "Model 5%")
    fig = add_bmo_vline_to_fig(fig, bmo, chem, 0.50, "Odhad modelu", width=5)
    fig = add_bmo_vline_to_fig(fig, bmo, chem, 0.95, "Model 95%")
    if actual_eob is not None:
        fig = add_bmo_vline_to_fig(
            fig, None, chem, actual_eob, "Meranie (EOB)", position="bottom", line_dash="dash"
        )
    if actual_final is not None:
        fig = add_bmo_vline_to_fig(
            fig, None, chem, actual_final, "Meranie (FINAL)", position="bottom right", line_dash="dash"
        )
    fig.update_layout(
        margin=dict(l=50, r=5, t=35, b=35),
        xaxis_range=[0, max(grade.get_limit(chem).maximum, chem_estimate.binning[-1]) + last_bin_width],
        showlegend=False,
        yaxis=dict(showgrid=True),
        paper_bgcolor="#f1f4f6",
        xaxis_title=f"Množstvo {xaxis_text[chem]} v oceli (%)",
        yaxis_title="Pravdepodobnosť",
        yaxis_range=[0, max(chem_estimate.probas) * 6 / 5],
    )
    return fig
