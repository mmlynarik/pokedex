from typing import Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class TitlePurchaseStepperVM:
    # Component ids
    COMPONENT_ID = "wrapper"
    NAME_ID = "name"
    # User friendly msg
    TITLE = "Nákup šrotu"

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[dmc.Title(cls.TITLE), dmc.Text(id=sdc.create_id(parent_id, cls.NAME_ID))],
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.NAME_ID, "children", *cls.get_purchase_name()),)

    @classmethod
    def get_purchase_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getPurchaseName", ["viewModel", "ctx"], "return ctx.purchaseName ?? '';"
        )
