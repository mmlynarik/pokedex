import datetime
from string import Template
from typing import Optional, Tuple, Collection

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from dash_iconify import DashIconify
from django.contrib.auth.models import User
from scrap.dash.components.create_purchase_submit_step.submit_step import SubmitCreateScrapPurchaseVM
from scrap.dash.components.create_scrap_purchase_stepper.title import TitlePurchaseStepperVM
from scrap.dash.components.scrap_purchase_base_step.base_info import PurchaseNameAndDateVM
from scrap.dash.components.scrap_purchase_production_plan_step.production_plan import PurchaseProductionPlanVM
from scrap.dash.components.scrap_purchase_scrap_offers_step.scrap_offers_step import ScrapOffersVM
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state import PurchaseScrapStateVM
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.models import ScrapPurchaseRecord
from scrap_core.utils import convert_kilograms_to_tons


def to_tons_safe(weight: Optional[float]) -> Optional[int]:
    return int(convert_kilograms_to_tons(weight)) if weight is not None else None


@attr.frozen
class CreatePurchaseStepperVM:
    # Component ids
    COMPONENT_ID = "stepper"
    COMPONENT_WRAPPER_ID = "stepper-wrapper"
    BACKWARD_BUTTON_ID = "backward"
    FORWARD_BUTTON_ID = "forward"
    FORWARD_BTN_TOOLTIP_ID = "forward-btn-tooltip"
    STEPPER_BTNS_ID = "stepper-btn-wrapper"
    PURCHASE_RECORD_ID = "scrap-purchase-record-id"
    ALERT_ID = "alert"
    ALERT_WRAPPER_ID = "alert-wrapper"
    # User friendly msg
    BACK_BUTTON = "Späť"
    FORWARD_BUTTON = "Ďalej"
    FIRST_STEP = "Názov a dátum"
    SECOND_STEP = "Stav šrotu"
    THIRD_STEP = "Plán výroby"
    FOURTH_STEP = "Ponuky"
    LAST_STEP = "Sumarizácia"
    REQUIRED_VALUES = "Pre pokračovanie je potrebné dopniť: "
    # Settings
    INIT_STEP = 0
    NUM_OF_STEPS = 4

    title: TitlePurchaseStepperVM = sdc.child_component("title", factory=TitlePurchaseStepperVM)
    base_info: PurchaseNameAndDateVM = sdc.child_component("name-and-date", factory=PurchaseNameAndDateVM)
    scrap_state: PurchaseScrapStateVM = sdc.child_component("scrap", factory=PurchaseScrapStateVM)
    production_plan: PurchaseProductionPlanVM = sdc.child_component(
        "production-plan", factory=PurchaseProductionPlanVM
    )
    scrap_offers: ScrapOffersVM = sdc.child_component("scrap-offers", factory=ScrapOffersVM)
    confirm: SubmitCreateScrapPurchaseVM = sdc.child_component("confirm", factory=SubmitCreateScrapPurchaseVM)
    current_step = sdc.clientside_one_way_binding_with_state(COMPONENT_ID, "active", default=INIT_STEP)
    alert_msg: Optional[str] = sdc.clientside_one_way_binding_with_state(ALERT_ID, "children", default=None)
    hide_alert: bool = sdc.clientside_one_way_binding_with_state(ALERT_ID, "hide", default=None)
    purchase_record_id: Optional[int] = sdc.binding(
        PURCHASE_RECORD_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=None,
    )

    @classmethod
    def create(
        cls,
        all_users: Tuple[User, ...],
        authorized_users: Collection[User],
        for_date: datetime.date,
        purchase_record: Optional[ScrapPurchaseRecord] = None,
    ) -> "CreatePurchaseStepperVM":
        if purchase_record is not None:
            current_data = purchase_record.current_data
            return cls(
                base_info=PurchaseNameAndDateVM.create(
                    all_users=all_users,
                    authorized_users=authorized_users,
                    for_date=for_date,
                    name=purchase_record.name,
                ),
                scrap_state=PurchaseScrapStateVM.create(
                    scrap_stock_objective=current_data.scrap_stock_objective,
                    mean_scrap_weight=to_tons_safe(current_data.mean_scrap_weight),
                ),
                production_plan=PurchaseProductionPlanVM.create(
                    user_defined_expected_production=to_tons_safe(
                        current_data.user_defined_expected_steel_production
                    ),
                    export_slabs_weight=current_data.export_slabs_weight,
                ),
                purchase_record_id=purchase_record.pk,
            )

        return cls(
            base_info=PurchaseNameAndDateVM.create(
                all_users=all_users, authorized_users=authorized_users, for_date=for_date
            ),
            scrap_state=PurchaseScrapStateVM.create(),
            production_plan=PurchaseProductionPlanVM.create(),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.BACKWARD_BUTTON_ID, "n_clicks", *cls.move_backward()),
            sdc.InputFieldClientSide(cls.FORWARD_BUTTON_ID, "n_clicks", *cls.move_forward()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.FORWARD_BTN_TOOLTIP_ID, "label", *cls.set_tooltip_label()),
            sdc.OutputFieldClientSide(cls.BACKWARD_BUTTON_ID, "className", *cls.hide_backward_btn()),
            sdc.OutputFieldClientSide(cls.FORWARD_BUTTON_ID, "className", *cls.hide_forward_btn()),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.title),
                html.Div(
                    children=[
                        dmc.Button(
                            cls.BACK_BUTTON,
                            id=sdc.create_id(parent_id, cls.BACKWARD_BUTTON_ID),
                            variant="outline",
                            className="invisible",
                            leftIcon=DashIconify(icon="ic:round-skip-previous"),
                        ),
                        dmc.Tooltip(
                            id=sdc.create_id(parent_id, cls.FORWARD_BTN_TOOLTIP_ID),
                            children=dmc.Button(
                                cls.FORWARD_BUTTON,
                                id=sdc.create_id(parent_id, cls.FORWARD_BUTTON_ID),
                                variant="outline",
                                rightIcon=DashIconify(icon="ic:round-skip-next"),
                            ),
                            label="",
                            position="left",
                            withArrow=True,
                            arrowSize=10,
                            transition="slide-left",
                            openDelay=700,
                            multiline=True,
                        ),
                    ],
                    id=sdc.create_id(parent_id, cls.STEPPER_BTNS_ID),
                ),
                dmc.Stepper(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    active=cls.INIT_STEP,
                    children=[
                        dmc.StepperStep(
                            label="Prvý krok",
                            description=cls.FIRST_STEP,
                            children=sdc.get_child_layout(parent_id, cls.base_info),
                        ),
                        dmc.StepperStep(
                            label="Druhý krok",
                            description=cls.SECOND_STEP,
                            children=sdc.get_child_layout(parent_id, cls.scrap_state),
                        ),
                        dmc.StepperStep(
                            label="Tretí krok",
                            description=cls.THIRD_STEP,
                            children=sdc.get_child_layout(parent_id, cls.production_plan),
                        ),
                        dmc.StepperStep(
                            label="Štvrtý krok",
                            description=cls.FOURTH_STEP,
                            children=sdc.get_child_layout(parent_id, cls.scrap_offers),
                        ),
                        dmc.StepperCompleted(children=sdc.get_child_layout(parent_id, cls.confirm)),
                    ],
                ),
                html.Div(
                    dmc.Alert(
                        id=sdc.create_id(parent_id, cls.ALERT_ID),
                        title="Oops, Problém.",
                        color="yellow.4",
                        duration=5000,
                        withCloseButton=True,
                        hide=True,
                    ),
                    id=sdc.create_id(parent_id, cls.ALERT_WRAPPER_ID),
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.PURCHASE_RECORD_ID)),
            ],
            id=sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
        )

    @classmethod
    def hide_backward_btn(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideBackwardBtn", ["vm"], "return ((vm.current_step ?? 0) == 0) ? 'invisible' : '';"
        )

    @classmethod
    def hide_forward_btn(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideForwardBtn",
            ["vm"],
            f"return ((vm.current_step ?? 0) == {cls.NUM_OF_STEPS}) ? 'invisible' : '';",
        )

    @classmethod
    def move_backward(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "moveBackward",
            ["vm", "nClicks"],
            """
            var updatedVM = {...vm};
            if (vm.current_step > 0)
                updatedVM.current_step = vm.current_step > 0 ? vm.current_step - 1 : vm.current_step;
            return updatedVM;
            """,
        )

    @classmethod
    def move_forward(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "moveForward",
            ["vm", "nClicks"],
            Template(
                """
                var updatedVM = {...vm};
                var [isForwardPossible, missingFields] = vm.isForwardMovePossible();
                if (isForwardPossible | (vm.purchase_record_id > 0)) {
                    updatedVM.current_step = vm.current_step < ${numOfSteps} ? vm.current_step + 1 : vm.current_step;
                } else {
                    updatedVM.alert_msg = '${required}' + missingFields.join(', ');
                    updatedVM.hide_alert = false;
                }
                return updatedVM;
                """
            ).substitute(numOfSteps=cls.NUM_OF_STEPS, required=cls.REQUIRED_VALUES),
        )

    @classmethod
    def set_tooltip_label(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setTooltipLabel",
            ["vm"],
            Template(
                """
            if (vm.current_step == 0)
                return '${second_step}';
            if (vm.current_step == 1)
                return '${third_step}';
            if (vm.current_step == 2)
                return '${fourth_step}';
            if (vm.current_step == 3)
                return '${summary}';
            return "Ďalší krok";
            """
            ).substitute(
                second_step=cls.SECOND_STEP,
                third_step=cls.THIRD_STEP,
                fourth_step=cls.FOURTH_STEP,
                summary=cls.LAST_STEP,
            ),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.is_forward_move_possible()),)

    @classmethod
    def is_forward_move_possible(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isForwardMovePossible",
            [],
            """
            var missingFields = [false, ['']];
            if (this.current_step == 0)
                missingFields = this.base_info.getMissingFields();
            if (this.current_step == 1)
                missingFields = this.scrap_state.getMissingFields();
            if (this.current_step == 2)
                missingFields = this.production_plan.getMissingFields();
            if (this.current_step == 3)
                missingFields = this.scrap_offers.getMissingFields();
            return [!missingFields.length, missingFields];
            """,
        )
