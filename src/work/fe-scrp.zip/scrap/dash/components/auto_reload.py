from typing import Self

import attr
from dash import dcc

import ussksdc as sdc


@attr.frozen
class AutoReloadViewModel:
    # COMPONENT INITIAL STATE
    UPDATE_DATA_INTERVAL_FALLBACK = 60000  # 60000 ms = 60 sec
    # COMPONENT IDS
    UPDATE_DATA_INTERVAL_ID = "reload-interval"

    update_interval: int = sdc.one_way_binding(
        UPDATE_DATA_INTERVAL_ID, "interval", default=UPDATE_DATA_INTERVAL_FALLBACK
    )
    trigger: int = sdc.binding(
        UPDATE_DATA_INTERVAL_ID,
        "n_intervals",
        ss_read=True,
        ss_state=False,
        ss_write=False,
        cs_read=False,
        cs_state=False,
        cs_write=False,
        default=0,
    )

    @classmethod
    def create(cls, interval: int) -> Self:
        return cls(update_interval=interval)

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Interval:
        return dcc.Interval(
            id=sdc.create_id(parent_id, cls.UPDATE_DATA_INTERVAL_ID),
            interval=cls.UPDATE_DATA_INTERVAL_FALLBACK,
        )

    def set_interval(self, interval_ms: int) -> Self:
        return attr.evolve(self, update_interval=interval_ms)
