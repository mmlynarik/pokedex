from typing import Any, Collection, Dict, Tuple

import attr
from dash import html
from scrap.dash.components.new_selectors import (
    VALIDATION_WRAPPER_CLASSNAME,
    get_validation_msg_clienside_fn_multiple_selector,
)
from scrap.dash.components.new_selectors.loading_station.datasource import (
    get_loading_station_selector_datasource,
)
from scrap.models import LoadingStation

import ussksdc as sdc
from ussksdc.components.selectors import SelectorDataSource
from ussksdc.components.selectors.new_selector import ClientsideMultiSelectorVM, InputSelectorVM
from ussksdc.components.validator import CSValidatorVM
from ussksdc.core.datamodel import JsCode

CHOOSE_LOADING_STATION = "Vyber nakladaciu stanicu"
CHOOSE_LOADING_STATIONS = "Vyber nakladacie stanice"
CHOOSE_AT_LEAST_ONE_OPTION = "Vyber aspoň jednu z možností."


@attr.s(frozen=True, slots=True)
class LoadingStationSelectorVM(InputSelectorVM[int, LoadingStation]):
    data_source: SelectorDataSource[int, LoadingStation] = attr.ib(
        factory=get_loading_station_selector_datasource
    )

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(LoadingStationSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_LOADING_STATION,
        }


@attr.s(frozen=True, slots=True)
class ClientLoadingStationMSelectorVM(ClientsideMultiSelectorVM[int, LoadingStation]):
    data_source: SelectorDataSource[int, LoadingStation] = attr.ib(
        factory=get_loading_station_selector_datasource
    )

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(ClientLoadingStationMSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_LOADING_STATIONS,
        }


@attr.s(frozen=True, slots=True)
class ClientValidatedLoadingStationMSelectorVM(CSValidatorVM[ClientLoadingStationMSelectorVM]):  # type: ignore
    to_validate: ClientLoadingStationMSelectorVM = sdc.child_component(
        "selector", factory=ClientLoadingStationMSelectorVM
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[sdc.get_child_layout(parent_id, cls.to_validate), super().get_layout(parent_id)],
            className=VALIDATION_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return get_validation_msg_clienside_fn_multiple_selector()

    def set_selected_options(self, options: Collection[int]) -> "ClientValidatedLoadingStationMSelectorVM":
        return attr.evolve(self, to_validate=self.to_validate.set_selected_options(options))
