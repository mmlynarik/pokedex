from typing import Any, Dict, Tuple

import attr
from dash import html
from scrap.dash.components.new_selectors import VALIDATION_WRAPPER_CLASSNAME, get_validation_msg_clienside_fn
from scrap.models import ScrapDefinition

import ussksdc as sdc
from ussksdc.components.selectors.new_selector import ClientsideStateSelectorVM
from ussksdc.components.validator import CSValidatorVM
from ussksdc.core.datamodel import JsCode

# User friendly msg
CHOOSE_SCRAP = "Vyber šrot"
CHOOSE_SCRAPS = "Vyber šroty"


@attr.s(frozen=True, slots=True)
class ScrapSelectorVM(ClientsideStateSelectorVM[int, ScrapDefinition]):
    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(ScrapSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_SCRAP,
        }


@attr.s(frozen=True, slots=True)
class ClientValidatedScrapSelectorVM(CSValidatorVM[ScrapSelectorVM]):  # type: ignore
    to_validate: ScrapSelectorVM = sdc.child_component("selector", factory=ScrapSelectorVM)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[sdc.get_child_layout(parent_id, cls.to_validate), super().get_layout(parent_id)],
            className=VALIDATION_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return get_validation_msg_clienside_fn()
