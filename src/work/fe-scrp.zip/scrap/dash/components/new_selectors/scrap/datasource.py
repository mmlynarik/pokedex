from typing import Collection, Protocol, Tuple

from scrap.models import ScrapDefinition

from ussksdc.components.selectors import SelectorOptionViewModel
from scrap_core import vectorize_values_dynamic, SUPPORTED_SCRAP_TYPES, ScrapType
from scrap.dash.components import get_scrap_type_label
from scrap.dash.components import DashOptionsType, DashOptionType


class ScrapSelectorDataSource(Protocol):
    @property
    def scrap_selector_options(self) -> DashOptionsType: ...


def scrap_type_to_option_vm(scrap_type: ScrapType) -> DashOptionType:
    return SelectorOptionViewModel(
        label=get_scrap_type_label(scrap_type),
        value=scrap_type,
    ).dash_dropdown_item


class StaticSelectorDataSource:
    @property
    def scrap_selector_options(self) -> DashOptionsType:
        return vectorize_values_dynamic(SUPPORTED_SCRAP_TYPES, scrap_type_to_option_vm)


def scraps_to_selector_options(
    scraps: Collection[ScrapDefinition], options_sorted: bool = True
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert scraps definition sequence to dash dropdown options.

    Args:
        scraps: Collection of scrap definitions to convert.
        options_sorted: If True than options retured will be sorted in ascending order.

    Returns:
        Sequence of dash dropdown component options.
    """
    scraps = sorted(scraps, key=lambda scrap: scrap.scrap_type) if options_sorted else scraps
    return tuple(
        SelectorOptionViewModel(label=scrap.scrap_type, value=scrap.scrap_type, title=scrap.description)
        for scrap in scraps
    )


class DbScrapDefinitionSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return scraps_to_selector_options(ScrapDefinition.objects.all())

    def get_value(self, key: str) -> ScrapDefinition:
        return ScrapDefinition.objects.get(scrap_type=key)

    def get_values(self, keys: Collection[str]) -> Collection[ScrapDefinition]:
        return ScrapDefinition.objects.filter(scrap_type__in=keys)
