from string import Template
from typing import Tuple

from ussksdc.core.datamodel import JsCode

GET_VALIDATION_MSG_FN_NAME = "getValidationMsg"
# Component class name
VALIDATION_WRAPPER_CLASSNAME = "validation-wrapper"
# User friendly msg
CHOOSE_OPTION = "Vyber jednu z možností."
CHOOSE_AT_LEAST_ONE_OPTION = "Vyber aspoň jednu z možností."


def get_validation_msg_clienside_fn() -> Tuple[JsCode, str]:
    return (
        JsCode(
            Template(
                """
            function $fn_name(){
                if (!this.to_validate.selected_option)
                    return "$msg";
                return "";
            }
        """
            ).substitute(fn_name=GET_VALIDATION_MSG_FN_NAME, msg=CHOOSE_OPTION)
        ),
        GET_VALIDATION_MSG_FN_NAME,
    )


def get_validation_msg_clienside_fn_multiple_selector() -> Tuple[JsCode, str]:
    return (
        JsCode(
            Template(
                """
        function $fn_name(){
            if (!this.to_validate.selected_options.length)
                return $msg;
            return "";
        }
    """
            ).substitute(fn_name=GET_VALIDATION_MSG_FN_NAME, msg=CHOOSE_AT_LEAST_ONE_OPTION)
        ),
        GET_VALIDATION_MSG_FN_NAME,
    )
