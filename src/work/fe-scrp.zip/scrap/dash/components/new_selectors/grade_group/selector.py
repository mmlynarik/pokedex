from typing import Any, Dict, Optional, Tuple

import attr
from dash import html
from scrap.dash.components.new_selectors import VALIDATION_WRAPPER_CLASSNAME, get_validation_msg_clienside_fn
from scrap.dash.components.new_selectors.grade_group.datasource import get_grade_group_datasource
from scrap.models import GradeGroup

import ussksdc as sdc
from ussksdc.components.selectors import SelectorDataSource
from ussksdc.components.selectors.new_selector import ClientsideStateSelectorVM
from ussksdc.components.validator import CSValidatorVM
from ussksdc.core.datamodel import JsCode

# User friendly msg
CHOOSE_GRADE_GROUP = "Vyber skupinu akostí"


@attr.s(frozen=True, slots=True)
class GradeGroupSelectorVM(ClientsideStateSelectorVM[int, GradeGroup]):
    data_source: SelectorDataSource[int, GradeGroup] = attr.ib(factory=get_grade_group_datasource)

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(GradeGroupSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_GRADE_GROUP,
        }

    def set_grade_group_filter(self, grade_id: int):
        return attr.evolve(self, data_source=get_grade_group_datasource(grade_id))


@attr.s(frozen=True, slots=True)
class ClientValidatedGradeGroupSelectorVM(CSValidatorVM[GradeGroupSelectorVM]):  # type: ignore
    to_validate: GradeGroupSelectorVM = sdc.child_component("selector", factory=GradeGroupSelectorVM)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[sdc.get_child_layout(parent_id, cls.to_validate), super().get_layout(parent_id)],
            className=VALIDATION_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return get_validation_msg_clienside_fn()

    def set_grade_group_filter(self, grade_id: int):
        return attr.evolve(self, to_validate=self.to_validate.set_grade_group_filter(grade_id))

    def set_selected_option(self, option: Optional[int]) -> "ClientValidatedGradeGroupSelectorVM":
        return attr.evolve(self, to_validate=self.to_validate.set_selected_option(option))
