from dash import dcc, html


def get_upload_excel_file_element(
    element_id: str,
    text_id: str,
    text_placeholder: str = "Vyberte súbor...",
    button_text: str = "Import",
) -> dcc.Upload:
    return dcc.Upload(
        id=element_id,
        accept=".xlsx, .xls",
        multiple=False,
        children=[
            html.Label(
                text_placeholder,
                id=text_id,
            ),
            html.Button(button_text),
        ],
    )
