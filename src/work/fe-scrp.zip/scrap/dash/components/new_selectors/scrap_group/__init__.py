from scrap.dash.components.new_selectors.scrap_group.selector import (
    ScrapGroupSelectorVM,
    ClientValidatedScrapGroupSelectorVM,
)
