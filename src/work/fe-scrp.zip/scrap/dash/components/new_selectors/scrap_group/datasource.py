from typing import Collection, Dict, Tuple

import cachetools as ct

from scrap.models import ScrapGroup

from ussksdc.components.selectors import SelectorOptionViewModel
from ussksdc.components.selectors.selector import SelectorDataSource


class CachedDbScrapGroupSelectorDataSource:
    def __init__(self):
        self.all_scrap_groups: Dict[int, ScrapGroup] = {
            scrap_group.pk: scrap_group
            for scrap_group in ScrapGroup.objects.all().prefetch_related("scrap_ids")
        }
        self.options: Tuple[SelectorOptionViewModel, ...] = tuple(
            SelectorOptionViewModel(
                label=scrap_group.group_name,
                value=pk,
                title=", ".join([scrap.scrap_type for scrap in scrap_group.scrap_ids.all()]),
            )
            for pk, scrap_group in self.all_scrap_groups.items()
        )

    def get_value(self, key: int) -> ScrapGroup:
        return self.all_scrap_groups[key]

    def get_values(self, keys: Collection[int]) -> Collection[ScrapGroup]:
        return [self.all_scrap_groups[key] for key in keys]


@ct.cached(cache=ct.TTLCache(maxsize=1, ttl=5))
def get_scrap_group_selector_datasource() -> SelectorDataSource[int, ScrapGroup]:
    return CachedDbScrapGroupSelectorDataSource()
