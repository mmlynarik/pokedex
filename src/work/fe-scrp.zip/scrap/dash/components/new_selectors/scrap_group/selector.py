from typing import Any, Dict, Optional, Tuple

import attr
from dash import html
from scrap.dash.components.new_selectors import VALIDATION_WRAPPER_CLASSNAME, get_validation_msg_clienside_fn
from scrap.dash.components.new_selectors.scrap_group.datasource import get_scrap_group_selector_datasource
from scrap.models import ScrapGroup

import ussksdc as sdc
from ussksdc.components.selectors import SelectorDataSource
from ussksdc.components.selectors.new_selector import ClientsideStateSelectorVM
from ussksdc.components.validator import CSValidatorVM
from ussksdc.core.datamodel import JsCode

# User friendly msg
CHOOSE_SCRAP_GROUP = "Vyber skupinu šrotov"


@attr.s(frozen=True, slots=True)
class ScrapGroupSelectorVM(ClientsideStateSelectorVM[int, ScrapGroup]):
    data_source: SelectorDataSource[int, ScrapGroup] = attr.ib(factory=get_scrap_group_selector_datasource)

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(ScrapGroupSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_SCRAP_GROUP,
        }


@attr.s(frozen=True, slots=True)
class ClientValidatedScrapGroupSelectorVM(CSValidatorVM[ScrapGroupSelectorVM]):  # type: ignore
    to_validate: ScrapGroupSelectorVM = sdc.child_component("selector", factory=ScrapGroupSelectorVM)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[sdc.get_child_layout(parent_id, cls.to_validate), super().get_layout(parent_id)],
            className=VALIDATION_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return get_validation_msg_clienside_fn()

    def set_selected_option(self, option: Optional[int]) -> "ClientValidatedScrapGroupSelectorVM":
        return attr.evolve(self, selector=self.to_validate.set_selected_option(option))
