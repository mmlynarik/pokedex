from datetime import date
from typing import Collection, FrozenSet, Tuple

from scrap.dash.database_api import steel_grades

from ussksdc.components.selectors import SelectorOptionViewModel


def get_available_grade_ids() -> FrozenSet[int]:
    today = date.today()
    return steel_grades.get_available_grade_ids(today)


def grades_to_selector_options(
    grade_ids: Collection[int], options_sorted: bool = True
) -> Tuple[SelectorOptionViewModel, ...]:
    """Function convert grade ids sequence to dash dropdown options.

    Args:
        grade_ids: Collection of grade ids to convert.
        options_sorted: If True than options retured will be sorted in ascending order.

    Returns:
        Sequence of dash dropdown component options.
    """
    today = date.today()
    grade_ids = sorted(grade_ids) if options_sorted else grade_ids
    return tuple(
        SelectorOptionViewModel(label=steel_grades.get_display_name(grade_id, today), value=grade_id)
        for grade_id in grade_ids
    )


class GradeSelectorDataSource:
    @property
    def options(self) -> Tuple[SelectorOptionViewModel, ...]:
        return grades_to_selector_options(get_available_grade_ids())

    def get_value(self, key: int) -> int:
        return key

    def get_values(self, keys: Collection[int]) -> Collection[int]:
        return keys
