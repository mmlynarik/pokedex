from typing import Any, Dict, Tuple

import attr
from dash import html
from scrap.dash.components.new_selectors import (
    VALIDATION_WRAPPER_CLASSNAME,
    get_validation_msg_clienside_fn_multiple_selector,
)
from scrap.dash.components.new_selectors.grade.datasource import GradeSelectorDataSource

import ussksdc as sdc
from ussksdc.components.selectors import SelectorDataSource
from ussksdc.components.selectors.new_selector import ClientsideMultiSelectorVM, InputSelectorVM
from ussksdc.components.validator import CSValidatorVM
from ussksdc.core.datamodel import JsCode

CHOOSE_GRADE = "Vyber akosť"
CHOOSE_GRADES = "Vyber akosti"


@attr.s(frozen=True, slots=True)
class GradeIdsSelectorVM(InputSelectorVM[int, int]):
    data_source: SelectorDataSource[int, int] = attr.ib(factory=GradeSelectorDataSource)

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(GradeIdsSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_GRADE,
        }


@attr.s(frozen=True, slots=True)
class ClientGradeIdsMSelectorVM(ClientsideMultiSelectorVM[int, int]):
    data_source: SelectorDataSource[int, int] = attr.ib(factory=GradeSelectorDataSource)

    @classmethod
    def dcc_dropdown_options(cls) -> Dict[str, Any]:
        return {
            **super(ClientGradeIdsMSelectorVM, cls).dcc_dropdown_options(),
            "placeholder": CHOOSE_GRADES,
        }


@attr.s(frozen=True, slots=True)
class ClientValidatedGradeIdsMSelectorVM(CSValidatorVM[ClientGradeIdsMSelectorVM]):  # type: ignore
    to_validate: ClientGradeIdsMSelectorVM = sdc.child_component(
        "selector", factory=ClientGradeIdsMSelectorVM
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[sdc.get_child_layout(parent_id, cls.to_validate), super().get_layout(parent_id)],
            className=VALIDATION_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return get_validation_msg_clienside_fn_multiple_selector()
