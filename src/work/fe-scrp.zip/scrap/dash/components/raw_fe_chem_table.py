from typing import List, Optional, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, html
from dash.dash_table.Format import Format, Scheme
from scrap_core import Chem
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE
from scrap_core.datamodel import RawFeChem


class RawFeChemTableRow(TypedDict):
    name: Chem
    value: float


RawFeChemTableData = List[RawFeChemTableRow]
DISPLAYED_CHEMS: List[Chem] = ["S", "Cu", "Ni", "Cr", "Mo", "Sn", "Si"]


def create_raw_fe_chem_table_row(name: Chem, value: float) -> RawFeChemTableRow:
    return {"name": name, "value": value}


def convert_raw_fe_chem_to_table_data(raw_fe_chem: RawFeChem) -> RawFeChemTableData:
    return [create_raw_fe_chem_table_row(chem, raw_fe_chem.get_chem(chem)) for chem in DISPLAYED_CHEMS]


def process_chem_value(raw_value: Optional[float]) -> float:
    if raw_value is None:
        return 0.0
    return min(10.0, max([0.0, raw_value]))


def convert_table_data_to_raw_fe_chem(raw_fe_chem_table_data: RawFeChemTableData) -> RawFeChem:
    return RawFeChem(**{str(row["name"]): process_chem_value(row["value"]) for row in raw_fe_chem_table_data})


def create_raw_fe_chem_table(element_id: str, read_only: bool = False, estimate: bool = False) -> html.Div:
    columns = [
        {"name": "Prvok", "id": "name", "type": "text", "editable": False},
        {
            "name": "Hodnota [%]",
            "id": "value",
            "type": "numeric",
            "format": Format(precision=3, scheme=Scheme.fixed),
            "validation": {"default": 0.0},
            "on_change": {"action": "coerce", "failure": "default"},
        },
    ]
    if read_only:
        columns[1]["editable"] = False
    label = "Odhad chémie surového železa" if estimate else "Chémia surového železa"
    return html.Div(
        [
            dbc.Label(label, className="m-0"),
            dbc.Label(
                "Pre potvrdenie hodnoty v tabuľke je potrebné po zadaní hodnoty stlačiť ENTER.",
                className="text-info w-100 m-0 p-0",
                style={"font-size": "0.8rem"},
                hidden=read_only,
            ),
            dash_table.DataTable(
                id=element_id,
                style_data_conditional=DATA_TEXT_STYLE,
                style_cell_conditional=[
                    {"if": {"column_id": "name"}, "width": "80px"},
                    {"if": {"column_id": "value"}, "width": "80px"},
                ],
                tooltip_conditional=[],
                style_table={"width": "100%"},
                style_header=TABLE_HEADER_STYLE,
                style_cell=CELL_STYLE,
                columns=columns,
                data=[],
                editable=not read_only,
            ),
            dbc.FormText("", id=element_id + "-msg"),
        ],
        id=element_id + "-group",
    )
