from functools import lru_cache
from typing import Optional, Protocol, Sequence

from django.db.models import Q
from scrap.dash.components import get_scrap_groups_str
from scrap.dash.components.summing_limit import SummingLimitsSettingsTableRowViewModel
from scrap.models import (
    RelaxableLowerSummingLimitSetting,
    RelaxableUpperSummingLimitSetting,
    get_relevant_relaxable_summing_limits_settings,
)


class SummingLimitsTableDataSource(Protocol):
    def get_limits(
        self,
        loading_station_id: Optional[int],
        grade_id: Optional[int],
        grade_group_id: Optional[int],
    ) -> Sequence[SummingLimitsSettingsTableRowViewModel]: ...


@lru_cache(maxsize=256)
def get_summing_limits(
    loading_station_id: Optional[int],
    grade_id: Optional[int],
    grade_group_id: Optional[int],
    is_upper: bool,
    timestamp: int,  # pylint: disable=unused-argument
) -> Sequence[SummingLimitsSettingsTableRowViewModel]:
    if grade_id is not None and loading_station_id is not None:
        filter_condition = Q(grade_ids__grade_ids__grade_id__exact=grade_id) | Q(grade_ids__grade_ids=None)
    elif grade_group_id is not None and loading_station_id is not None:
        filter_condition = Q(grade_ids__id=grade_group_id) | Q(grade_ids__grade_ids=None)
    else:
        return []

    model = RelaxableUpperSummingLimitSetting if is_upper else RelaxableLowerSummingLimitSetting

    all_limits = set(
        model.objects.select_related("grade_ids", "scrap_types")
        .prefetch_related("loadingstation_set", "grade_ids__grade_ids", "scrap_types__scrap_ids")
        .filter(loadingstation__pk=loading_station_id)
        .filter(filter_condition)
    )

    relevant_limits = get_relevant_relaxable_summing_limits_settings(all_limits, grade_id)
    return [
        SummingLimitsSettingsTableRowViewModel(
            limit_id=limit.id,
            affected_loading_stations_ids=limit.affected_loading_stations_ids,
            name=limit.name,
            comment=limit.comment,
            grade_group_id=limit.grade_ids.id,
            grade_group_name=limit.grade_ids.group_name,
            grade_ids=limit.grade_ids.to_tuple(),
            scrap_types_id=limit.scrap_types.id,
            scrap_types=get_scrap_groups_str(limit.scrap_types),
            weight_limit_aim=limit.weight_aim,
            weight_limit_allowed=limit.weight_allowed,
            ratio_aim=limit.ratio_aim,
            ratio_allowed=limit.ratio_allowed,
            is_limit_relevant=int(limit in relevant_limits),
        )
        for limit in all_limits
    ]


class CachedDbSummingLimitsTableDataSource:
    def __init__(self, is_upper: bool, timestamp: int):
        self.is_upper = is_upper
        self.timestamp = timestamp

    def get_limits(
        self,
        loading_station_id: Optional[int],
        grade_id: Optional[int],
        grade_group_id: Optional[int],
    ) -> Sequence[SummingLimitsSettingsTableRowViewModel]:
        return get_summing_limits(loading_station_id, grade_id, grade_group_id, self.is_upper, self.timestamp)


@lru_cache(maxsize=32)
def get_upper_summing_limits_data_source(timestamp: int) -> SummingLimitsTableDataSource:
    return CachedDbSummingLimitsTableDataSource(True, timestamp)


@lru_cache(maxsize=32)
def get_lower_summing_limits_data_source(timestamp: int) -> SummingLimitsTableDataSource:
    return CachedDbSummingLimitsTableDataSource(False, timestamp)
