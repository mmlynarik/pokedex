from typing import Union

from scrap.models import RelaxableLowerSummingLimitSetting, RelaxableUpperSummingLimitSetting

# User Friendly msg
MAX_ALLOWED = "Max-Povolené"
MIN_ALLOWED = "Min-Povolené"

RelaxableSummingLimitSetting = Union[RelaxableUpperSummingLimitSetting, RelaxableLowerSummingLimitSetting]
