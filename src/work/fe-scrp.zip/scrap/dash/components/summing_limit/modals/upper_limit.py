from typing import Optional

import attr
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.pair_inputs.various_inputs import RatioInputsViewModel, WeightInputsViewModel
from scrap.dash.components.summing_limit import SummingLimitsSettingsTableRowViewModel
from scrap.dash.components.summing_limit.modals import MAX_ALLOWED
from scrap.dash.components.summing_limit.modals.base import SummingLimitModalViewModel
from scrap.models import RelaxableUpperSummingLimitSetting

from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class UpperSummingLimitModalViewModel(SummingLimitModalViewModel):
    affected_model = RelaxableUpperSummingLimitSetting

    def set_input_values_and_open(
        self,
        ctx: SettingsAppFiltersSource,
        row_view_model: Optional[SummingLimitsSettingsTableRowViewModel] = None,
    ) -> "UpperSummingLimitModalViewModel":
        if row_view_model is None:
            return UpperSummingLimitModalViewModel(
                is_open=True,
                loading_stations=self.loading_stations.set_selected_option(ctx.selected_loading_station_id),
                scrap_groups=self.scrap_groups.set_selected_option(None),
                grade_groups=self.grade_groups.set_filter_grade_id(ctx.selected_grade_id).set_selected_option(
                    None
                ),
                weight_limits_inputs=WeightInputsViewModel(aim=75000, allowed=75000, upper_limit=DataStoreViewModel(True)),  # type: ignore #[SDC MYPY BUG]
                ratio_inputs=RatioInputsViewModel(aim=1, allowed=1, upper_limit=DataStoreViewModel(True)),  # type: ignore #[SDC MYPY BUG]
                confirm_button_label="Pridať limit",
                is_upper_limit=DataStoreViewModel(int(False)),  # type: ignore #[SDC MYPY BUG]
                second_column_label=MAX_ALLOWED,
            )
        return UpperSummingLimitModalViewModel(
            is_open=True,
            name=row_view_model.name,
            comment=row_view_model.comment,
            loading_stations=self.loading_stations.set_selected_options(
                row_view_model.affected_loading_stations_ids
            ),
            scrap_groups=self.scrap_groups.set_selected_option(row_view_model.scrap_types_id),
            grade_groups=self.grade_groups.set_filter_grade_id(ctx.selected_grade_id).set_selected_option(
                row_view_model.grade_group_id
            ),
            weight_limits_inputs=attr.evolve(
                self.weight_limits_inputs,
                aim=row_view_model.weight_limit_aim,
                allowed=row_view_model.weight_limit_allowed,
                upper_limit=DataStoreViewModel(True),  # type: ignore #[SDC MYPY BUG]
            ),
            ratio_inputs=attr.evolve(
                self.ratio_inputs,
                aim=row_view_model.ratio_aim,
                allowed=row_view_model.ratio_allowed,
                upper_limit=DataStoreViewModel(True),  # type: ignore #[SDC MYPY BUG]
            ),
            confirm_button_label="Aktualizovať limit",
            affected_limit_id=DataStoreViewModel(row_view_model.limit_id),  # type: ignore #[SDC MYPY BUG]
            is_upper_limit=DataStoreViewModel(int(False)),  # type: ignore #[SDC MYPY BUG]
            second_column_label=MAX_ALLOWED,
        )
