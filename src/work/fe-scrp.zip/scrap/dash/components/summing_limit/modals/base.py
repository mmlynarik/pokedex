import time
from abc import ABC, abstractmethod
from typing import Optional, Type, TypeVar

import attr
import dash_bootstrap_components as dbc
from dash import html
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.grade_group.modal import GradeGroupModalViewModel
from scrap.dash.components.modals import create_input_wrapper, create_modal_footer, create_modal_header
from scrap.dash.components.pair_inputs import (
    RatioInputsViewModel,
    WeightInputsViewModel,
    get_pair_inputs_wrapper,
)
from scrap.dash.components.scrap_group.modal import ScrapGroupModalViewModel
from scrap.dash.components.selectors import GradeGroupSelectorViewModel, ScrapGroupSelectorViewModel
from scrap.dash.components.selectors.loading_station import LoadingStationMultipleSelectorViewModel
from scrap.dash.components.summing_limit import SummingLimitsSettingsTableRowViewModel
from scrap.dash.components.summing_limit.modals import MAX_ALLOWED, RelaxableSummingLimitSetting

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel

# TODO - After python migration replace TModal type for Self from typing package.
TModal = TypeVar("TModal", bound="SummingLimitModalViewModel")


@attr.s(frozen=True, slots=True)
class SummingLimitModalViewModel(ABC):
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    COMPONENT_ID = "modal"
    NAME_ID = "name"
    CLOSE_BUTTON_ID = "close"
    COMMENT_ID = "comment"
    CONFIRM_BUTTON_ID = "confirm"
    PAIR_INPUTS_SECOND_COLUMN_LABEL_ID = "pair-inputs-second-col-label"
    CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID = "grade-group-modal-open"
    CREATE_SCRAP_GRADE_MODAL_OPEN_BUTTON_ID = "scrap-group-modal-open"
    NAME_VALIDATION_MSG_ID = "name-validation"
    # User friendly msg
    NEW_LIMIT = "Nový limit"
    COMMENT = "Komentár"
    CHOOSE_GRADE_GROUP = "Vyber skupinu akostí"
    CHOOSE_SCRAP_GROUP = "Vyber skupinu šrotov"
    CHOOSE_LOADING_STATIONS = "Vyber nakladacie stanice"
    AIM = "Cieľ"

    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    second_column_label: str = sdc.one_way_binding(
        PAIR_INPUTS_SECOND_COLUMN_LABEL_ID, "children", default=MAX_ALLOWED
    )
    name: str = sdc.two_way_binding(NAME_ID, "value", default=NEW_LIMIT)
    comment: str = sdc.two_way_binding(COMMENT_ID, "value", default="")
    grade_groups: GradeGroupSelectorViewModel = sdc.child_component(
        "grade-groups", default=GradeGroupSelectorViewModel()
    )
    loading_stations: LoadingStationMultipleSelectorViewModel = sdc.child_component(
        "loading-stations", default=LoadingStationMultipleSelectorViewModel()
    )
    scrap_groups: ScrapGroupSelectorViewModel = sdc.child_component(
        "scrap-groups", default=ScrapGroupSelectorViewModel()
    )
    weight_limits_inputs: WeightInputsViewModel = sdc.child_component(
        "weight_limit", default=WeightInputsViewModel()
    )
    ratio_inputs: RatioInputsViewModel = sdc.child_component("ratio", default=RatioInputsViewModel())
    create_grade_group_modal: GradeGroupModalViewModel = sdc.child_component(
        "create-grade-group-modal", default=GradeGroupModalViewModel()
    )
    create_scrap_group_modal: ScrapGroupModalViewModel = sdc.child_component(
        "create-scrap-group-modal", default=ScrapGroupModalViewModel()
    )
    is_upper_limit: DataStoreViewModel = sdc.child_component("upper-limit", default=DataStoreViewModel(0))  # type: ignore #[SDC MYPY BUG]
    affected_limit_id: DataStoreViewModel = sdc.child_component(
        "affected-id-data-store", default=DataStoreViewModel()
    )
    last_change: DataStoreViewModel = sdc.child_component(
        "last-change-data-store", default=DataStoreViewModel(0)  # type: ignore #[SDC MYPY BUG]
    )
    confirm_button_label: str = sdc.one_way_binding(CONFIRM_BUTTON_ID, "children", default="Pridať limit")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", SummingLimitModalViewModel.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", SummingLimitModalViewModel.confirm_event),
            sdc.InputField(
                cls.CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID,
                "n_clicks",
                SummingLimitModalViewModel.open_create_grade_group_modal,
            ),
            sdc.InputField(
                cls.CREATE_SCRAP_GRADE_MODAL_OPEN_BUTTON_ID,
                "n_clicks",
                SummingLimitModalViewModel.open_create_scrap_group_modal,
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.CONFIRM_BUTTON_ID, "disabled", SummingLimitModalViewModel.are_inputs_invalid),
            sdc.OutputField(
                cls.NAME_VALIDATION_MSG_ID, "children", SummingLimitModalViewModel.name_validation
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            backdrop="static",
            children=[
                create_modal_header(
                    sdc.create_id(parent_id, cls.NAME_ID),
                    sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID),
                    sdc.create_id(parent_id, cls.NAME_VALIDATION_MSG_ID),
                ),
                dbc.ModalBody(
                    children=[
                        get_pair_inputs_wrapper(
                            pair_inputs=[
                                sdc.get_child_layout(
                                    parent_id, cls.weight_limits_inputs, pair_name="Váhový limit"
                                ),
                                sdc.get_child_layout(parent_id, cls.ratio_inputs, pair_name="Pomer"),
                            ],
                            first_column_label=cls.AIM,
                            second_column_label=MAX_ALLOWED,
                            second_column_id=sdc.create_id(parent_id, cls.PAIR_INPUTS_SECOND_COLUMN_LABEL_ID),
                        ),
                        create_input_wrapper(
                            cls.CHOOSE_GRADE_GROUP,
                            [
                                html.Div(
                                    children=[
                                        sdc.get_child_layout(parent_id, cls.grade_groups),
                                        dbc.Button(
                                            children="+",
                                            color="light",
                                            id=sdc.create_id(
                                                parent_id, cls.CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID
                                            ),
                                        ),
                                    ],
                                    className="inputs-group",
                                )
                            ],
                        ),
                        create_input_wrapper(
                            cls.CHOOSE_SCRAP_GROUP,
                            [
                                html.Div(
                                    children=[
                                        sdc.get_child_layout(parent_id, cls.scrap_groups),
                                        dbc.Button(
                                            children="+",
                                            color="light",
                                            id=sdc.create_id(
                                                parent_id, cls.CREATE_SCRAP_GRADE_MODAL_OPEN_BUTTON_ID
                                            ),
                                        ),
                                    ],
                                    className="inputs-group",
                                )
                            ],
                        ),
                        create_input_wrapper(
                            cls.CHOOSE_LOADING_STATIONS,
                            [
                                sdc.get_child_layout(parent_id, cls.loading_stations),
                            ],
                        ),
                        create_input_wrapper(
                            cls.COMMENT,
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.COMMENT_ID), debounce=True),
                            ],
                        ),
                        sdc.get_child_layout(parent_id, cls.is_upper_limit),
                        sdc.get_child_layout(parent_id, cls.affected_limit_id),
                        sdc.get_child_layout(parent_id, cls.last_change),
                    ]
                ),
                create_modal_footer(sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), ""),
                sdc.get_child_layout(parent_id, cls.create_grade_group_modal),
                sdc.get_child_layout(parent_id, cls.create_scrap_group_modal),
            ],
            centered=True,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            keyboard=False,
        )

    @property
    @abstractmethod
    def affected_model(self) -> Type[RelaxableSummingLimitSetting]: ...

    @abstractmethod
    def set_input_values_and_open(
        self: TModal,
        ctx: SettingsAppFiltersSource,
        row_view_model: Optional[SummingLimitsSettingsTableRowViewModel] = None,
    ) -> TModal: ...

    @property
    def update(self) -> bool:
        return self.affected_limit_id.data != -1

    @property
    def summing_limit_or_raise(self) -> RelaxableSummingLimitSetting:
        if self.affected_limit_id.data == -1:
            raise ValueError("Missing limit id")
        return self.affected_model.objects.get(id=self.affected_limit_id.data)

    def update_group(self) -> None:
        relaxable_limit = self.summing_limit_or_raise

        relaxable_limit.name = self.name
        relaxable_limit.comment = self.comment
        relaxable_limit.weight_aim = self.weight_limits_inputs.aim_or_raise
        relaxable_limit.weight_allowed = self.weight_limits_inputs.allowed_or_raise
        relaxable_limit.ratio_aim = self.ratio_inputs.aim_or_raise
        relaxable_limit.ratio_allowed = self.ratio_inputs.allowed_or_raise
        relaxable_limit.grade_ids = self.grade_groups.selected_value_or_raise
        relaxable_limit.scrap_types = self.scrap_groups.selected_value_or_raise
        relaxable_limit.save()

        # remove all associated loading stations
        relaxable_limit.loadingstation_set.clear()
        # update relationship between selected limit and loading stations
        relaxable_limit.loadingstation_set.set(self.loading_stations.selected_values)

    def create_group(self) -> None:
        limit = self.affected_model(
            name=self.name,
            comment=self.comment,
            weight_aim=self.weight_limits_inputs.aim,
            weight_allowed=self.weight_limits_inputs.allowed,
            ratio_aim=self.ratio_inputs.aim,
            ratio_allowed=self.ratio_inputs.allowed,
            scrap_types=self.scrap_groups.selected_value_or_raise,
            grade_ids=self.grade_groups.selected_value_or_raise,
        )
        limit.save()

        limit.loadingstation_set.set(self.loading_stations.selected_values)

    def confirm_event(self: TModal, _: int) -> TModal:
        if self.update:
            self.update_group()
        else:
            self.create_group()
        return self.reset_to_initial_state(True)

    def reset_to_initial_state(self: TModal, data_changed: bool) -> TModal:
        last_change = time.time_ns() if data_changed else self.last_change.data
        return self.__class__(last_change=DataStoreViewModel(last_change))  # type: ignore

    def close_modal(self: TModal, _: int) -> TModal:
        return self.reset_to_initial_state(False)

    def are_inputs_invalid(self) -> bool:
        return not (
            self.grade_groups.has_selected_option
            and self.scrap_groups.has_selected_option
            and self.loading_stations.has_selected_options
            and self.weight_limits_inputs.valid_inputs
            and self.ratio_inputs.valid_inputs
        )

    def open_create_grade_group_modal(self: TModal, _: int, ctx: SettingsAppFiltersSource) -> TModal:
        return attr.evolve(
            self,
            create_grade_group_modal=self.create_grade_group_modal.set_input_values_and_open(ctx),
        )

    def open_create_scrap_group_modal(self: TModal, _: int) -> TModal:
        return attr.evolve(
            self, create_scrap_group_modal=self.create_scrap_group_modal.set_input_values_and_open()
        )

    def name_validation(self) -> str:
        if not self.name:
            return "Názov limitu musí byť vyplnený"
        return ""
