from typing import Collection, Dict, Tuple

import attr
from scrap.dash.components import get_grade_groups_str


@attr.s(frozen=True, auto_attribs=True, slots=True)
class SummingLimitsSettingsTableRowViewModel:
    limit_id: int
    name: str
    weight_limit_aim: float
    weight_limit_allowed: float
    ratio_aim: float
    ratio_allowed: float
    scrap_types_id: int
    grade_group_id: int
    grade_group_name: str
    # Value of is_limit_relevant is bool type but for table we need int
    is_limit_relevant: int = 1  # bool value
    grade_ids: Collection[int] = ()
    affected_loading_stations_ids: Tuple[int, ...] = ()
    created_at: str = ""
    created_by: str = ""
    comment: str = ""
    scrap_types: str = ""
    edit: str = "📝"
    delete: str = "❌"

    @property
    def dash_table_row(self) -> Dict[str, str]:
        return attr.asdict(self)  # type: ignore
        # TODO remove type ignore with new mypy version

    @property
    def grade_ids_str(self) -> str:
        return get_grade_groups_str(self.grade_ids)
