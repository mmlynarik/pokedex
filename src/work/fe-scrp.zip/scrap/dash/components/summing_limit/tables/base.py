import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Sequence, Union

import attr
from dash import html
from dash.dash_table import DataTable
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.modals.delete_confirm import (
    DeleteLowerSummingLimitConfirmModalViewModel,
    DeleteUpperSummingLimitConfirmModalViewModel,
)
from scrap.dash.components.summing_limit import SummingLimitsSettingsTableRowViewModel
from scrap.dash.components.summing_limit.datasource import SummingLimitsTableDataSource
from scrap.dash.components.summing_limit.modals.lower_limit import LowerSummingLimitModalViewModel
from scrap.dash.components.summing_limit.modals.upper_limit import UpperSummingLimitModalViewModel
from scrap.dash.components.table_common import table_wrapper_with_header

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel

DeleteSummingLimitConfirmModalViewModels = Union[
    DeleteLowerSummingLimitConfirmModalViewModel, DeleteUpperSummingLimitConfirmModalViewModel
]
SummingLimitModalViewModels = Union[LowerSummingLimitModalViewModel, UpperSummingLimitModalViewModel]


@attr.s(frozen=True, slots=True)
class SummingLimitsSettingsTableViewModel(ABC):
    # Initial property
    HIDDEN_ON_LOAD = True
    TOOLTIP_CHARACTER_THRESHOLD = 18
    # Component ids
    LIMITS_ID = "table-limits"
    LIMITS_MSG_ID = f"{LIMITS_ID}-msg"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    LIMITS_WRAPPER_ID = "limits-wrapper"
    EDIT_COLUMN_ID = "edit"
    DELETE_COLUMN_ID = "delete"
    ADD_NEW_LIMIT_ID = "add-limit"
    SCRAP_TYPES_COLUMN_ID = "scrap_types"
    GRADE_GROUP_COLUMN_ID = "grade_group_name"
    RELEVANT_LIMIT_COLUMN_ID = "is_limit_relevant"
    # Component class names
    TABLE_TOP_TITLE_SECTION_CLASSNAME = "title-section title-section-top"
    TABLE_TITLE_SECTION_CLASSNAME = "title-section"
    TABLE_TITLE_MESSAGE_CLASSNAME = "title-section-msg"
    # User friendly msg
    ADD = "Pridať limit"
    DELETE = "Odstrániť limnit"
    UPDATE = "Upraviť limnit"
    MISSING_DATA = "V databáze neboli nájdené žiadné dáta."

    data_load_time: int = attr.ib(factory=time.time_ns, converter=int)

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(
                cls.ADD_NEW_LIMIT_ID, "n_clicks", SummingLimitsSettingsTableViewModel.open_limit_modal
            ),
            sdc.InputField(
                cls.LIMITS_ID, "active_cell", SummingLimitsSettingsTableViewModel.control_active_cell
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.LIMITS_ID, "data", SummingLimitsSettingsTableViewModel.to_table_data),
            sdc.OutputField(
                cls.LIMITS_ID, "tooltip_data", SummingLimitsSettingsTableViewModel.to_tooltip_data
            ),
            sdc.OutputField(
                cls.COMPONENT_WRAPPER_ID, "hidden", SummingLimitsSettingsTableViewModel.is_hidden
            ),
            sdc.OutputField(
                cls.LIMITS_WRAPPER_ID, "hidden", SummingLimitsSettingsTableViewModel.table_hidden
            ),
            sdc.OutputField(cls.LIMITS_MSG_ID, "hidden", lambda data, ctx: not data.table_hidden(ctx)),
            sdc.OutputField(cls.LIMITS_MSG_ID, "children", SummingLimitsSettingsTableViewModel.get_table_msg),
            sdc.OutputField(
                cls.LIMITS_ID, "active_cell", lambda _: None
            ),  # Reset active cell makes it possible to click on cell more then once
        )

    @classmethod
    def get_summing_limits_dash_table(cls, table_id: str, wrapper_id: str) -> html.Div:
        return html.Div(
            children=DataTable(
                columns=[
                    {"name": ["Názov", ""], "id": cls.EDIT_COLUMN_ID, "type": "text"},
                    {"name": ["Názov", ""], "id": "name", "type": "text"},
                    {"name": ["Skupina akostí", ""], "id": cls.GRADE_GROUP_COLUMN_ID, "type": "text"},
                    {"name": ["Typy šrotov", ""], "id": "scrap_types", "type": "text"},
                    {"name": ["Váhový limit", "Cieľ"], "id": "weight_limit_aim", "type": "numeric"},
                    {"name": ["Váhový limit", "Povolené"], "id": "weight_limit_allowed", "type": "numeric"},
                    {"name": ["Pomer", "Cieľ"], "id": "ratio_aim", "type": "numeric"},
                    {"name": ["Pomer", "Povolené"], "id": "ratio_allowed", "type": "numeric"},
                    {"name": ["Komentár", ""], "id": "comment", "type": "text"},
                    # {"name": ["Vytvorené dňa", ""], "id": "created_at", "type": "datetime"},
                    # {"name": ["Vytvoril", ""], "id": "created_by", "type": "text"},
                    {"name": ["", ""], "id": cls.DELETE_COLUMN_ID, "type": "text"},
                    {
                        "name": ["Relevantný limit", "Relevantný limit"],
                        "id": cls.RELEVANT_LIMIT_COLUMN_ID,
                        "type": "numeric",
                    },
                ],
                data=[],
                editable=False,
                fill_width=True,
                id=table_id,
                merge_duplicate_headers=True,
                # TODO http://vdevops/Esten/UssAi/_workitems/edit/388/
                style_data_conditional=[
                    {
                        "if": {"filter_query": "{is_limit_relevant} = 0"},
                        "backgroundColor": "rgb(190,190,190)",
                        "color": "rgb(160, 160, 160)",
                    },
                ],
                tooltip_delay=500,
                tooltip_duration=3000,
            ),
            hidden=True,
            id=wrapper_id,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return table_wrapper_with_header(
            cls.get_summing_limits_dash_table(
                sdc.create_id(parent_id, cls.LIMITS_ID),
                sdc.create_id(parent_id, cls.LIMITS_WRAPPER_ID),
            ),
            cls.table_title(),
            cls.ADD,
            sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
            sdc.create_id(parent_id, cls.LIMITS_MSG_ID),
            sdc.create_id(parent_id, cls.ADD_NEW_LIMIT_ID),
            cls.HIDDEN_ON_LOAD,
            [
                sdc.get_child_layout(parent_id, cls.get_modal()),
                sdc.get_child_layout(parent_id, cls.get_delete_confirm_modal()),
            ],
        )

    @classmethod
    @abstractmethod
    def get_data_source(cls, timestamp: int) -> SummingLimitsTableDataSource: ...

    @classmethod
    @abstractmethod
    def table_title(cls) -> str: ...

    @classmethod
    @abstractmethod
    def get_modal(cls) -> SummingLimitModalViewModels: ...

    @classmethod
    @abstractmethod
    def get_delete_confirm_modal(cls) -> DeleteSummingLimitConfirmModalViewModels: ...

    @property
    @abstractmethod
    def modal(self) -> SummingLimitModalViewModels: ...

    @property
    @abstractmethod
    def delete_confirm_modal(self) -> DeleteSummingLimitConfirmModalViewModels: ...

    @property
    @abstractmethod
    def upper_limit(self) -> bool: ...

    @property
    def last_change(self) -> int: ...

    def is_hidden(self, ctx: SettingsAppFiltersSource) -> bool:
        return (
            (ctx.selected_loading_station_id is None and ctx.selected_grade_id is None)
            or (ctx.selected_loading_station_id is None and ctx.selected_grade_group_id is None)
            or (ctx.selected_grade_id is None and ctx.selected_grade_group_id is None)
        )

    def rows(self, ctx: SettingsAppFiltersSource) -> Sequence[SummingLimitsSettingsTableRowViewModel]:
        return self.get_data_source(self.last_change).get_limits(
            ctx.selected_loading_station_id, ctx.selected_grade_id, ctx.selected_grade_group_id
        )

    def to_table_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, str]]:
        return [row.dash_table_row for row in self.rows(ctx)]

    def to_tooltip_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, str]]:
        return [
            {
                self.EDIT_COLUMN_ID: self.UPDATE,
                self.DELETE_COLUMN_ID: self.DELETE,
                self.SCRAP_TYPES_COLUMN_ID: (
                    row.scrap_types if len(row.scrap_types) > self.TOOLTIP_CHARACTER_THRESHOLD else ""
                ),
                self.GRADE_GROUP_COLUMN_ID: row.grade_ids_str,
            }
            for row in self.rows(ctx)
        ]

    def get_table_msg(self, ctx: SettingsAppFiltersSource) -> str:
        return self.MISSING_DATA if not self.rows(ctx) else ""

    def edit(
        self, ctx: SettingsAppFiltersSource, row_view_model: SummingLimitsSettingsTableRowViewModel
    ) -> "SummingLimitsSettingsTableViewModel":
        return attr.evolve(
            self,
            create_modal=self.modal.set_input_values_and_open(ctx, row_view_model),
        )

    def delete(
        self, row_view_model: SummingLimitsSettingsTableRowViewModel
    ) -> "SummingLimitsSettingsTableViewModel":
        return attr.evolve(
            self,
            confirm_modal=self.delete_confirm_modal.__class__(
                is_open=True,
                message=f"Pozor snažíte sa vymazať summing limit s názvom {row_view_model.name}! "
                + "Naozaj chcete tento limit odstrániť?",
                affected_id=DataStoreViewModel(row_view_model.limit_id),  # type: ignore #[SDC MYPY BUG]
                is_action_impossible=False,
            ),
        )

    def control_active_cell(
        self, active_cell: Dict[str, Any], ctx: SettingsAppFiltersSource
    ) -> "SummingLimitsSettingsTableViewModel":
        if not active_cell:
            return self
        row_view_model = self.rows(ctx)[active_cell["row"]]
        active_cell_id = active_cell["column_id"]
        if active_cell_id == self.EDIT_COLUMN_ID:
            return self.edit(ctx, row_view_model)
        if active_cell_id == self.DELETE_COLUMN_ID:
            return self.delete(row_view_model)
        return self

    def open_limit_modal(
        self, _: int, ctx: SettingsAppFiltersSource
    ) -> "SummingLimitsSettingsTableViewModel":
        return attr.evolve(self, create_modal=self.modal.set_input_values_and_open(ctx))

    def table_hidden(self, ctx: SettingsAppFiltersSource) -> bool:
        return not self.rows(ctx)
