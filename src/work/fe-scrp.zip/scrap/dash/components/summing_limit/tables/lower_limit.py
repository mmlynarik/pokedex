import attr
from scrap.dash.components.modals.delete_confirm import DeleteLowerSummingLimitConfirmModalViewModel
from scrap.dash.components.summing_limit.datasource import (
    SummingLimitsTableDataSource,
    get_lower_summing_limits_data_source,
)
from scrap.dash.components.summing_limit.modals.lower_limit import LowerSummingLimitModalViewModel
from scrap.dash.components.summing_limit.tables.base import (
    DeleteSummingLimitConfirmModalViewModels,
    SummingLimitModalViewModels,
    SummingLimitsSettingsTableViewModel,
)

import ussksdc as sdc


@attr.s(frozen=True, slots=True)
class LowerSummingLimitsSettingsTableViewModel(SummingLimitsSettingsTableViewModel):
    LOWER_LIMIT = "Minimálne povolené množstvo šrotu"

    confirm_modal: DeleteLowerSummingLimitConfirmModalViewModel = sdc.child_component(
        "confirm-delete-modal", default=DeleteLowerSummingLimitConfirmModalViewModel()
    )
    create_modal: LowerSummingLimitModalViewModel = sdc.child_component(
        "modal", default=LowerSummingLimitModalViewModel()
    )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time, self.create_modal.last_change.data, self.confirm_modal.last_change.data
        )

    @classmethod
    def get_data_source(cls, timestamp: int) -> SummingLimitsTableDataSource:
        return get_lower_summing_limits_data_source(timestamp)

    @classmethod
    def table_title(cls) -> str:
        return cls.LOWER_LIMIT

    @classmethod
    def get_modal(cls) -> SummingLimitModalViewModels:
        return cls.create_modal

    @classmethod
    def get_delete_confirm_modal(cls) -> DeleteSummingLimitConfirmModalViewModels:
        return cls.confirm_modal

    @property
    def modal(self) -> SummingLimitModalViewModels:
        return self.create_modal

    @property
    def delete_confirm_modal(self) -> DeleteSummingLimitConfirmModalViewModels:
        return self.confirm_modal

    @property
    def upper_limit(self) -> bool:
        return False
