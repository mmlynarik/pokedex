import attr
from scrap.dash.components.modals.delete_confirm import DeleteUpperSummingLimitConfirmModalViewModel
from scrap.dash.components.summing_limit.datasource import (
    SummingLimitsTableDataSource,
    get_upper_summing_limits_data_source,
)
from scrap.dash.components.summing_limit.modals.upper_limit import UpperSummingLimitModalViewModel
from scrap.dash.components.summing_limit.tables.base import (
    DeleteSummingLimitConfirmModalViewModels,
    SummingLimitModalViewModels,
    SummingLimitsSettingsTableViewModel,
)

import ussksdc as sdc


@attr.s(frozen=True, slots=True)
class UpperSummingLimitsSettingsTableViewModel(SummingLimitsSettingsTableViewModel):
    UPPER_LIMIT = "Maximálne povolené množstvo šrotu"

    confirm_modal: DeleteUpperSummingLimitConfirmModalViewModel = sdc.child_component(
        "confirm-delete-modal", default=DeleteUpperSummingLimitConfirmModalViewModel()
    )
    create_modal: UpperSummingLimitModalViewModel = sdc.child_component(
        "modal", default=UpperSummingLimitModalViewModel()
    )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time, self.create_modal.last_change.data, self.confirm_modal.last_change.data
        )

    @classmethod
    def get_data_source(cls, timestamp: int) -> SummingLimitsTableDataSource:
        return get_upper_summing_limits_data_source(timestamp)

    @classmethod
    def table_title(cls) -> str:
        return cls.UPPER_LIMIT

    @classmethod
    def get_modal(cls) -> SummingLimitModalViewModels:
        return cls.create_modal

    @classmethod
    def get_delete_confirm_modal(cls) -> DeleteSummingLimitConfirmModalViewModels:
        return cls.confirm_modal

    @property
    def modal(self) -> SummingLimitModalViewModels:
        return self.create_modal

    @property
    def delete_confirm_modal(self) -> DeleteSummingLimitConfirmModalViewModels:
        return self.confirm_modal

    @property
    def upper_limit(self) -> bool:
        return True
