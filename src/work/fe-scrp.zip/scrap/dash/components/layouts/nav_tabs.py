from typing import Tuple, Union

import attr
import dash_bootstrap_components as dbc
from dash import html
from dash.development.base_component import Component

TABS_WRAPPER_CLASSNAME = "tabs-wrapper"

Content = Union[Component, Tuple[Component, ...]]


@attr.s(frozen=True, slots=True, cache_hash=False)
class NavTab:
    content: Content = attr.ib()
    label: str = attr.ib(default="New Tab")
    disabled: bool = attr.ib(default=False)
    active_label_class_name: str = attr.ib(default="active-tab-label")

    @property
    def dash_component(self) -> dbc.Tab:
        return dbc.Tab(
            children=self.content,
            label=self.label,
            disabled=self.disabled,
            active_label_class_name=self.active_label_class_name,
        )


@attr.s(frozen=True, slots=True, cache_hash=False)
class NavTabs:
    tabs: Tuple[NavTab, ...] = attr.ib(default=())

    @property
    def dash_component(self) -> dbc.Tabs:
        return dbc.Tabs(
            children=[tab.dash_component for tab in self.tabs],
        )


def create_tabs_layout(tabs: NavTabs) -> html.Div:
    return html.Div(
        children=tabs.dash_component,
        className=TABS_WRAPPER_CLASSNAME,
    )
