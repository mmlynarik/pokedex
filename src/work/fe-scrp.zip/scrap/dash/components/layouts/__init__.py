# For the application to work properly, it is necessary to insert a link to
# the scss file in the head of the html file in which the component is used.
# <link rel="stylesheet" type="text/css" href="{% sass_src 'scrap/styles/layouts/<used_layout>.scss' %}">
# OR
# If the html file is already using the scss file, you need to import this file into the main scss file.
# @import './components/<used_layout>.scss';
from scrap.dash.components.layouts.nav_tabs import NavTab, NavTabs, create_tabs_layout
from scrap.dash.components.layouts.sidebar import SideBar, create_sidebar_layout
