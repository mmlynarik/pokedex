from typing import List, Optional, Tuple, Union

import attr
import dash_bootstrap_components as dbc
from dash import html
from dash.development.base_component import Component

LAYOUT_WRAPPER_CLASSNAME = "wrapper"
SIDEBAR_CLASS_NAME = "sidebar"
SIDEBAR_HEADER_CLASS_NAME = f"{SIDEBAR_CLASS_NAME}-header"
SIDEBAR_CONTENT_CLASS_NAME = f"{SIDEBAR_CLASS_NAME}-content"
SIDEBAR_HEADER_TITLE_CLASS_NAME = f"{SIDEBAR_HEADER_CLASS_NAME}-title"
SIDEBAR_COMPONENT_CLASS_NAME = f"{SIDEBAR_CLASS_NAME}-component"
SIDEBAR_BOTTOM_ITEMS_WRAPPER_CLASSNAME = f"{SIDEBAR_CLASS_NAME}-bottom-items"

SIDEBAR_COMPONENTS_LIST_ID = f"{SIDEBAR_CLASS_NAME}-components"

Content = Union[Component, Tuple[Component, ...]]


@attr.s(frozen=True, slots=True, cache_hash=False)
class SideBar:
    main_content: Content = attr.ib()
    bottom_content: Content = attr.ib()
    title: str = attr.ib(default="Name of your app")

    @property
    def main_content_as_list_items(self) -> Optional[Union[html.Li, List[html.Li]]]:
        if not self.main_content:
            return None
        list_items = []
        for children in self.main_content:
            list_items.append(html.Li(children=children, className=SIDEBAR_COMPONENT_CLASS_NAME))
        return list_items if len(list_items) > 1 else list_items[0]

    @property
    def dash_component(self) -> html.Nav:
        return html.Nav(
            children=[
                html.Div(
                    children=html.H4(children=self.title, className=SIDEBAR_HEADER_TITLE_CLASS_NAME),
                    className=SIDEBAR_HEADER_CLASS_NAME,
                ),
                html.Div(
                    children=[
                        html.Ul(
                            children=self.main_content_as_list_items,
                            className=f"{SIDEBAR_COMPONENTS_LIST_ID} list-unstyled",
                        ),
                        html.Div(
                            children=self.bottom_content,
                            className=SIDEBAR_BOTTOM_ITEMS_WRAPPER_CLASSNAME,
                        ),
                    ],
                    className=SIDEBAR_CONTENT_CLASS_NAME,
                ),
            ],
            className=SIDEBAR_CLASS_NAME,
        )


def create_sidebar_layout(sidebar: SideBar, page_content: Content) -> html.Div:
    return html.Div(
        className=LAYOUT_WRAPPER_CLASSNAME,
        children=[
            sidebar.dash_component,
            page_content,
        ],
    )


def get_input_wrapper(label: str, input_component: Component) -> html.Div:
    return html.Div(
        children=[dbc.Label(children=label), input_component],
    )
