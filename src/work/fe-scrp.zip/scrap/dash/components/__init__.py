from functools import lru_cache
from typing import Any, Collection, Dict, List, Union

from scrap.models import ScrapGroup, ScrapMixDefinition
from scrap_core import TMS_ID_REVERSE_MAPPING, ScrapMix

TABLE_DATETIME_FORMAT = "%d.%m.%Y %H:%M"
DashOptionType = Dict[str, Any]
DashOptionsType = List[Dict[str, Any]]


def callback_triggered_by(input_id: str, callback_context: List[Dict[str, Union[str, int]]]) -> bool:
    return input_id == callback_context[0]["prop_id"].split(".")[0]  # type: ignore


def multiple_callback_triggered_by_exact(
    input_id: str, property_name: str, callback_context: List[Dict[str, Union[str, int]]]
) -> bool:
    trigger_identifier = ".".join([input_id, property_name])
    for callback_trigger in callback_context:
        if trigger_identifier == callback_trigger["prop_id"]:
            return True
    return False


def callback_triggered_by_property(
    property_name: str, callback_context: List[Dict[str, Union[str, int]]]
) -> bool:
    return property_name == callback_context[0]["prop_id"].split(".")[1]  # type: ignore


@lru_cache(maxsize=128)
def get_scrap_type_label(scrap_mix: ScrapMix) -> str:
    maybe_mix = ScrapMixDefinition.objects.filter(name=scrap_mix).first()
    if maybe_mix is not None:
        return maybe_mix.display_name
    maybe_id = TMS_ID_REVERSE_MAPPING.get(scrap_mix)  # type: ignore
    if maybe_id is None:
        return scrap_mix
    return f"{scrap_mix} ({maybe_id})"


def get_grade_groups_str(grade_ids: Collection[int]) -> str:
    if not grade_ids:
        return "Všetky akosti"
    return ", ".join(str(grade) for grade in grade_ids)


def get_scrap_groups_str(scrap_group: ScrapGroup) -> str:
    scraps = scrap_group.scrap_ids.all()
    if not scraps:
        return "Všetky typy šrotov"
    return ", ".join(scrap.scrap_type for scrap in scraps)
