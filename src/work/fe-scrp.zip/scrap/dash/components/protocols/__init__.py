from typing import Optional, Protocol


class ReadOnlySource(Protocol):
    read_only: bool


class DebugModeSource(Protocol):
    debug: bool


class SteelShopSource(Protocol):
    steelshop: Optional[int]


class LoadingStationIdSource(Protocol):
    loading_station_id: int
