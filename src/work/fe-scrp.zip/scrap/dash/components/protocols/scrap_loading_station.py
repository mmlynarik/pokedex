from typing import Dict, Optional, Protocol, Tuple

from ussksdc.core.datamodel import TViewModel

from scrap.dash.components.available_scraps.model.available_scraps.datasource import (
    AvailableScrapDatasource,
)
from scrap.dash.components.available_scraps.model.scrap_definitions.datasource import (
    AllScrapDefinitionsDatasource,
)
from scrap.dash.components.protocols import (
    LoadingStationIdSource,
    ReadOnlySource,
    SteelShopSource,
)
from scrap.dash.components.scrap_charges.model.basket_waggon_weight.datasource import (
    BasketWaggonWeightDatasource,
)
from scrap.dash.components.scrap_charges.model.basket_weight.datasource import (
    BasketWeightDatasource,
)
from scrap.dash.components.scrap_charges.model.grade_definitions.datasource import (
    GradeDefinitionsDatasource,
)
from scrap.dash.components.scrap_charges.model.optimizations.datasource import (
    MultipleHeatsOptimizationDatasource,
)
from scrap.dash.components.scrap_charges.model.scale_state.datasource import (
    ScrapCurrentStateDatasource,
)
from scrap.dash.components.scrap_charges.model.scrap_charge.datasource import (
    ScrapChargesDatasource,
)
from scrap.dash.components.scrap_charges.model.weighted_scrap.datasource import (
    WeightedScrapDatasource,
)
from scrap.dash.scrap_loading_station.datasource import ScrapLoadingStationDataSource
from scrap.models import ScrapCharge


class LoadingStationModels(Protocol):
    loading_station: ScrapLoadingStationDataSource
    available_scraps: AvailableScrapDatasource
    scrap_definitions: AllScrapDefinitionsDatasource
    grade_definitions: GradeDefinitionsDatasource
    scrap_charges: ScrapChargesDatasource
    optimizations: MultipleHeatsOptimizationDatasource
    basket_weight: BasketWeightDatasource
    basket_waggon_weight: BasketWaggonWeightDatasource
    scale_state: ScrapCurrentStateDatasource

    def weighted_scrap(self, scrap_charge_id: int) -> WeightedScrapDatasource: ...


class ScrapLoadingStationCTX(LoadingStationIdSource, SteelShopSource, Protocol):
    parent: TViewModel
    models: LoadingStationModels
    loading_station_id: int
    steelshop: Optional[int]
    logged_username: str
    operator_id: int
    use_scrap_yard_api: bool
    scale_control: bool
    read_only: bool
    error_msg: Tuple[str, ...]
    transfer_capacity_or_zero: int
    scale_ids: Tuple[str, str]

    def get_active_scales(self, card_idx: int) -> Tuple[str, ...]: ...

    def get_grade_id(self, card_index: int) -> Optional[int]: ...

    def get_scrap_weight(self, card_index: int) -> int: ...

    def get_scrap_weight_or_constant(self, card_index: int) -> int: ...

    def get_scrap_charge_id(self, card_idx: int) -> int: ...

    def get_scrap_charge(self, card_idx: int) -> Optional[ScrapCharge]: ...

    def get_scale_basket_map(self, card_idx: int) -> Dict[str, Optional[int]]: ...

    def get_switched_basket_selected_scale_id(self, card_idx: int) -> Optional[int]: ...


class ScrapLoadingStationConfig(ReadOnlySource):
    host: str
    port: int
    ...
