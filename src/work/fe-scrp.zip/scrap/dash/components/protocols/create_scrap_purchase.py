from datetime import date, datetime
from typing import Optional, Protocol, Tuple

from django.contrib.auth.models import User
from scrap.dash.components.scrap_purchase_scrap_state_step.scrap_state_mapping.datasource import (
    ScrapStateTableDataSource,
)
from scrap.dash.create_scrap_purchase.datasource import CreateScrapPurchaseModelsDatasource
from scrap.models import (
    ProductionPlan,
    ScrapOfferParsedRecord,
    ScrapParsedData,
    ScrapPurchaseRecordDisplayData,
    ScrapState,
)


class ScrapMappingSectionDataSource(Protocol):
    scrap_mapping: Tuple[ScrapStateTableDataSource, ...]


class CreateScrapPurchaseBaseInfoDataSource(Protocol):
    purchase_id: Optional[int]
    purchase_name: str
    purchase_date: date
    authorized_user_ids: Tuple[int, ...]


class ScrapStateDataSource(Protocol):
    scrap_state_parsed_data: Tuple[ScrapParsedData, ...]
    scrap_on_the_way_parsed_data: Tuple[ScrapParsedData, ...]
    scrap_state_filename: Optional[str]
    scrap_on_the_way_filename: Optional[str]
    scrap_stock_objective: Optional[int]
    mean_scrap_weight: Optional[int]
    scrap_state_data: Tuple[ScrapState, ...]


class ScrapOffersDataSouce(Protocol):
    scrap_offer_parsed_data: Tuple[ScrapOfferParsedRecord, ...]
    scrap_offers_filename: Optional[str]


class ProductionPlanDataSource(Protocol):
    production_plan_data: Tuple[ProductionPlan, ...]
    production_plan_weeks: Optional[int]
    production_plan_date: Optional[datetime]
    user_defined_expected_production: Optional[int]


class CreateScrapPurchaseSource(
    CreateScrapPurchaseBaseInfoDataSource,
    ScrapMappingSectionDataSource,
    ScrapStateDataSource,
    ProductionPlanDataSource,
    ScrapOffersDataSouce,
    Protocol,
):
    models: CreateScrapPurchaseModelsDatasource
    logged_user: User
    scrap_purchase_record_display_data: ScrapPurchaseRecordDisplayData
