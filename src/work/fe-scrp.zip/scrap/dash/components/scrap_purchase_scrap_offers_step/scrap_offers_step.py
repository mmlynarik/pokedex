from typing import Dict, List, Optional, Tuple
from string import Template
import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from dash_iconify import DashIconify
from scrap.dash.components.error_handler import ErrorHandlerMsg
from scrap.dash.components.scrap_purchase_scrap_offers_step.table.table import ScrapOffersTableVM
from scrap.dash.components.scrap_purchase_scrap_offers_step.parser import parse_scrap_offers_excel_file
from scrap.imports import assign_scrap_type_to_scrap_offers_data
from scrap.models import ScrapOfferParsedRecord, converter

from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class ScrapOffersVM:
    # Component ids
    FILE_UPLOAD_ID = "file-upload"
    FILE_UPLOAD_TEXT_ID = "file-upload-text"
    FILE_CONTENT_ID = "file-upload-content"
    SHOW_DATA_BTN_ID = "file-upload-show-data"
    WRAPPER_ID = "file-upload-wrapper"
    BTN_WRAPPER_ID = "file-upload-btn-wrapper"
    HEADER_WRAPPER_ID = "file-upload-header-wrapper"
    TITLE_ID = "file-upload-title"
    # User friendly msg
    SCRAP_OFFERS_LABEL = "Vyberte súbor s ponukami..."
    BTN_LABEL_SHOW = "Zobraziť načítané dáta"
    BTN_LABEL_HIDE = "Skryť načítané dáta"

    ACCEPTED_UPLOAD_FORMAT = [".xls", ".xlsx"]

    uploaded_file_content: List[Dict[str, str]] = sdc.binding(
        FILE_CONTENT_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=[],
    )
    filename: Optional[str] = sdc.binding(
        FILE_UPLOAD_ID,
        "filename",
        ss_read=False,
        ss_state=True,
        ss_write=False,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    table: ScrapOffersTableVM = sdc.child_component("data", factory=ScrapOffersTableVM)
    error_msg_handler: ErrorHandlerMsg = sdc.child_component("error", factory=ErrorHandlerMsg)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dmc.LoadingOverlay(
                    html.Div(
                        children=[
                            html.Div(
                                [
                                    DashIconify(icon="vscode-icons:file-type-excel", width=22),
                                    dmc.Title(
                                        cls.SCRAP_OFFERS_LABEL,
                                        id=sdc.create_id(parent_id, cls.TITLE_ID),
                                        order=5,
                                    ),
                                ],
                            ),
                            html.Div(
                                dmc.Button(
                                    id=sdc.create_id(parent_id, cls.SHOW_DATA_BTN_ID),
                                    leftIcon=DashIconify(icon="circum:view-table"),
                                    variant="outline",
                                    color="teal",
                                    compact=True,
                                ),
                                id=sdc.create_id(parent_id, cls.BTN_WRAPPER_ID),
                            ),
                        ],
                        id=sdc.create_id(parent_id, cls.HEADER_WRAPPER_ID),
                    ),
                    loaderProps={"variant": "dots", "color": "green", "size": "xl"},
                ),
                dcc.Upload(
                    id=sdc.create_id(parent_id, cls.FILE_UPLOAD_ID),
                    accept=", ".join(cls.ACCEPTED_UPLOAD_FORMAT),
                    multiple=False,
                    children=html.Div(
                        id=sdc.create_id(parent_id, cls.FILE_UPLOAD_TEXT_ID),
                    ),
                ),
                sdc.get_child_layout(parent_id, cls.error_msg_handler),
                sdc.get_child_layout(parent_id, cls.table),
                dcc.Store(id=sdc.create_id(parent_id, cls.FILE_CONTENT_ID)),
            ],
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.FILE_UPLOAD_ID, "contents", cls.save_content),
            sdc.InputFieldClientSide(cls.SHOW_DATA_BTN_ID, "n_clicks", *cls.toggle_table_visibility()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.FILE_UPLOAD_TEXT_ID, "children", *cls.show_filename()),
            sdc.OutputFieldClientSide(cls.SHOW_DATA_BTN_ID, "children", *cls.change_btn_label()),
            sdc.OutputFieldClientSide(cls.BTN_WRAPPER_ID, "className", *cls.show_action_btns()),
            sdc.OutputFieldClientSide(cls.FILE_UPLOAD_ID, "className", *cls.set_classname()),
            sdc.OutputFieldClientSide(cls.SHOW_DATA_BTN_ID, "color", *cls.set_btn_color()),
        )

    @property
    def file_content(self) -> Tuple[ScrapOfferParsedRecord, ...]:
        return assign_scrap_type_to_scrap_offers_data(
            tuple(converter.structure(data, ScrapOfferParsedRecord) for data in self.uploaded_file_content)
        )

    @classmethod
    def toggle_table_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleTableVisibility",
            ["viewModel"],
            """
            var updatedVM = {...viewModel};
            updatedVM.table = updatedVM.table.toggleTableVisibility();
            return updatedVM;
            """,
        )

    @classmethod
    def show_filename(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getFilename",
            ["viewModel"],
            """
            if (Boolean(viewModel.filename))
                return viewModel.filename;
            return "Pretiahnite a pustite alebo Zvoľte súbor kliknutím";
            """,
        )

    @classmethod
    def change_btn_label(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "changeBtnLabel",
            ["viewModel"],
            f"return viewModel.table.hidden ? '{cls.BTN_LABEL_SHOW}' : '{cls.BTN_LABEL_HIDE}'",
        )

    @classmethod
    def show_action_btns(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showActionBtns",
            ["viewModel"],
            "return Boolean(viewModel.uploaded_file_content.length !== 0) ? '' : 'invisible'",
        )

    @classmethod
    def set_classname(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setClassname",
            ["viewModel"],
            """
            if (viewModel.error_msg_handler.error.length != 0)
                return 'errorUpload';
            return Boolean(viewModel.filename) ? 'uploaded' : 'notUploaded';
            """,
        )

    @classmethod
    def set_btn_color(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setBtnColor",
            ["viewModel"],
            "return viewModel.error_msg_handler.error.length > 0 ? 'red' : 'teal';",
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.mising_fields()),)

    @classmethod
    def mising_fields(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMissingFields",
            [],
            Template(
                """
            var missingFields = [];
            if (!this.table.data.length)
                missingFields.push('${scrap_offer}');
            return missingFields;
            """
            ).substitute(scrap_offer=cls.SCRAP_OFFERS_LABEL),
        )

    def save_content(self, raw_contents: str) -> "ScrapOffersVM":
        parsed_data, error_msg = parse_scrap_offers_excel_file(raw_contents)
        data = assign_scrap_type_to_scrap_offers_data(parsed_data)
        return attr.evolve(
            self,
            uploaded_file_content=converter.unstructure(parsed_data),
            table=self.table.set_data(data),
            error_msg_handler=self.error_msg_handler.set_error(error_msg),
        )
