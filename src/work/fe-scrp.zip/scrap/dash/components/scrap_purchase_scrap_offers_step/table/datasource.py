from typing import Optional, Tuple

import attr
from scrap.models import ScrapOfferParsedRecord


@attr.frozen
class ScrapOffersTableDataSource:
    supplier: str
    scrap_group: str
    weight: int
    price: int
    zone: str
    station: str
    country: str
    note: Optional[str]

    @property
    def table_row(self):
        return attr.asdict(self)


def convert_to_scrap_offers_table_data(
    scrap_offer_data: Tuple[ScrapOfferParsedRecord, ...]
) -> Tuple[ScrapOffersTableDataSource]:
    return tuple(
        ScrapOffersTableDataSource(
            supplier=scrap_offer.supplier if scrap_offer.supplier else scrap_offer.input_supplier,
            scrap_group=scrap_offer.scrap_type,
            weight=scrap_offer.quantity,
            price=scrap_offer.price,
            zone=scrap_offer.zone,
            station=scrap_offer.station,
            country=scrap_offer.country,
            note=scrap_offer.note,
        )
        for scrap_offer in scrap_offer_data
    )
