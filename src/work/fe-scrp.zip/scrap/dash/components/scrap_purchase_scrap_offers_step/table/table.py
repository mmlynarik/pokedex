from typing import Any, Dict, List, Tuple

import attr
import ussksdc as sdc
from dash import html
from dash_ag_grid import AgGrid
from scrap.models import ScrapOfferParsedRecord
from scrap.dash.components.scrap_purchase_scrap_offers_step.table.datasource import (
    convert_to_scrap_offers_table_data,
)
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class ScrapOffersTableVM:
    COMPONENT_ID = "offer-data"

    TABLE_ID = "table"
    SUPPLIER_COLUMN_ID = "supplier"
    SCRAP_GROUP_COLUMN_ID = "scrap_group"
    SCRAP_WEIGHT_COLUMN_ID = "weight"
    PRICE_COLUMN_ID = "price"
    ZONE_COLUMN_ID = "zone"
    STATION_COLUMN_ID = "station"
    COUNTRY_COLUMN_ID = "country"
    NOTE_COLUMN_ID = "note"

    SUPPLIER_COLUMN = "Dodávateľ"
    SCRAP_GROUP_COLUMN = "Skupina šrotu"
    SCRAP_WEIGHT_COLUMN = "Množstvo"
    PRICE_COLUMN = "Cena"
    ZONE_COLUMN = "Zóna"
    STATION_COLUMN = "Stanica"
    COUNTRY_COLUMN = "Krajina"
    NOTE_COLUMN = "Poznámka"

    DEFAULT_TABLE_HIDDEN_STATE = True
    PAGE_SIZE = 20

    data: List[Dict[str, Any]] = sdc.binding(
        TABLE_ID,
        "rowData",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=[],
    )
    hidden: bool = sdc.clientside_one_way_binding_with_state(
        COMPONENT_ID, "hidden", default=DEFAULT_TABLE_HIDDEN_STATE
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            hidden=cls.DEFAULT_TABLE_HIDDEN_STATE,
            children=[
                AgGrid(
                    id=sdc.create_id(parent_id, cls.TABLE_ID),
                    className="ag-theme-alpine-dark",
                    columnDefs=[
                        {"headerName": cls.SUPPLIER_COLUMN, "field": cls.SUPPLIER_COLUMN_ID},
                        {"headerName": cls.SCRAP_GROUP_COLUMN, "field": cls.SCRAP_GROUP_COLUMN_ID},
                        {"headerName": cls.SCRAP_WEIGHT_COLUMN, "field": cls.SCRAP_WEIGHT_COLUMN_ID},
                        {"headerName": cls.PRICE_COLUMN, "field": cls.PRICE_COLUMN_ID},
                        {"headerName": cls.ZONE_COLUMN, "field": cls.ZONE_COLUMN_ID},
                        {"headerName": cls.STATION_COLUMN, "field": cls.STATION_COLUMN_ID},
                        {"headerName": cls.COUNTRY_COLUMN, "field": cls.COUNTRY_COLUMN_ID},
                        {"headerName": cls.NOTE_COLUMN, "field": cls.NOTE_COLUMN_ID},
                    ],
                    columnSize="responsiveSizeToFit",
                    defaultColDef={"sortable": True, "filter": True},
                    dashGridOptions={"pagination": True, "paginationPageSize": 20},
                )
            ],
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.toggle_table_visibility()),
            sdc.JsCodeField(*cls.has_data()),
        )

    @classmethod
    def toggle_table_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleTableVisibility",
            ["viewModel"],
            """
            var updatedVM = {...this};
            if (updatedVM.hidden == null)
                updatedVM.hidden = true;
            updatedVM.hidden = !updatedVM.hidden;
            return updatedVM;
            """,
        )

    @classmethod
    def has_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasData",
            [],
            "return (this.data != null && this.data.length > 0)",
        )

    def set_data(self, data: Tuple[ScrapOfferParsedRecord]) -> "ScrapOffersTableVM":
        return attr.evolve(self, data=[row.table_row for row in convert_to_scrap_offers_table_data(data)])
