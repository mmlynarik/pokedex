from typing import Tuple

from scrap.imports import decode_uploaded_file, parse_scrap_excel_file
from scrap.models import ScrapParsedData


def parse_scrap_offers_excel_file(contents: str) -> Tuple[Tuple[ScrapParsedData, ...], Tuple[str, ...]]:
    if not contents:
        return ()
    excel_bytes = decode_uploaded_file(contents)
    return parse_scrap_excel_file(excel_bytes)
