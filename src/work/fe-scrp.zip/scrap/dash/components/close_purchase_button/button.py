import attr
from dash import html
import ussksdc as sdc
import dash_bootstrap_components as dbc
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig

from scrap.dash.components.close_purchase_button.modal import ConfirmPurchaseCloseModalViewModel


@attr.s(frozen=True, slots=True)
class ClosePurchaseButtonViewModel:
    COMPONENT_ID = "close"

    CLOSE_BUTTON = "🔒"
    CLOSE = "Uzamknúť nákup"

    confirm_modal: ConfirmPurchaseCloseModalViewModel = sdc.child_component(
        "modal", default=ConfirmPurchaseCloseModalViewModel()
    )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig) -> html.Div:
        return html.Div(
            hidden=config.read_only,
            children=[
                html.Hr(),
                dbc.Button(
                    cls.CLOSE_BUTTON,
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    color="danger",
                    className="close-button",
                ),
                html.H6(cls.CLOSE),
                sdc.get_child_layout(parent_id, cls.confirm_modal),
            ],
            className="text-center close-purchase-wrapper",
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.COMPONENT_ID, "n_clicks", cls.open_confirm),)

    def open_confirm(self, _: int) -> "ClosePurchaseButtonViewModel":
        return attr.evolve(self, confirm_modal=self.confirm_modal.set_input_values_and_open())
