import attr
import ussksdc as sdc
from dash import html
import dash_bootstrap_components as dbc
from scrap.dash.components.common import ScrapPurchaseAppSource

from scrap.dash.components.modals import create_modal_footer, create_modal_label_header


@attr.s(frozen=True, slots=True)
class ConfirmPurchaseCloseModalViewModel:
    OPEN_ON_LOAD = False

    COMPONENT_ID = "name"
    CLOSE_BUTTON_ID = "close"
    BODY_ID = "body"
    CONFIRM_BUTTON_ID = "confirm"

    HEADER = "Uzamknúť nákup?"
    FINISH_PURCHASE_MODAL_BODY = "Nákup bol uzatvorený. Môžete obnoviť stránku."
    NOT_FINISH_PURCHASE_MODAL_BODY = ""
    CONFIRM_BUTTON = "Uzamknúť"

    is_open = sdc.one_way_binding(COMPONENT_ID, "is_open", default=OPEN_ON_LOAD)
    is_finished = sdc.one_way_binding(BODY_ID, "children", default=NOT_FINISH_PURCHASE_MODAL_BODY)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dbc.Modal(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    is_open=False,
                    keyboard=False,
                    backdrop=True,
                    children=[
                        create_modal_label_header(cls.HEADER, sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID)),
                        dbc.ModalBody(
                            id=sdc.create_id(parent_id, cls.BODY_ID),
                        ),
                        create_modal_footer(
                            sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), cls.CONFIRM_BUTTON
                        ),
                    ],
                )
            ]
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", cls.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", cls.close_purchase),
        )

    def close_purchase(self, _: int, ctx: ScrapPurchaseAppSource) -> "ConfirmPurchaseCloseModalViewModel":
        ctx.db_purchase_data_source.finish_purchase()
        return attr.evolve(self, is_finished=self.FINISH_PURCHASE_MODAL_BODY)

    def close_modal(self, _: int) -> "ConfirmPurchaseCloseModalViewModel":
        return attr.evolve(self, is_open=False)

    def set_input_values_and_open(self) -> "ConfirmPurchaseCloseModalViewModel":
        return attr.evolve(self, is_open=True)
