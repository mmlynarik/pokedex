from typing import Tuple

import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@frozen
class MultipleScrapChargesAtOnceVM:
    # Component ids
    COMPONENT_ID = "checkbox"
    WRAPPER_ID = f"{COMPONENT_ID}-wrapper"
    # User friendly msg
    MULTIPLE_SCRAP_CHARGES_AT_ONCE = "Paralelné nakladanie"

    checked = sdc.clientside_only_state_binding(COMPONENT_ID, "checked", default=False)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            dmc.Checkbox(
                id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                label=cls.MULTIPLE_SCRAP_CHARGES_AT_ONCE,
                checked=False,
                size="xs",
                radius="xs",
                disabled=config.read_only,
            ),
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.WRAPPER_ID, "hidden", *cls.hide_on_ss1()),)

    @classmethod
    def hide_on_ss1(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("hideOnSs1", ["viewModel", "ctx"], "return ctx.steelshop === 1;")
