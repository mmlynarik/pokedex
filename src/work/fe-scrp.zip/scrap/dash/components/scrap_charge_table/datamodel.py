from typing import Collection, Dict, Optional, Self, Union

import attr

from scrap.models import ScrapChargeDisplayDataV2


def join_number_collection(numbers: Collection[int]) -> str:
    return ", ".join(map(str, numbers))


@attr.frozen
class ScrapChargesTableRow:
    id: int = attr.ib()
    heat_baskets: str = attr.ib(converter=join_number_collection)
    grade: str = attr.ib()
    scrap_weight: Optional[int] = attr.ib()
    pig_iron_weight: Optional[int] = attr.ib()
    delete: str = attr.ib(default="")

    @classmethod
    def from_display_data(cls, idx: int, data: ScrapChargeDisplayDataV2) -> Self:
        return cls(
            id=idx,
            heat_baskets=data.basket_ids,
            grade=data.grade_id,
            scrap_weight=data.total_scrap_weight,
            pig_iron_weight=data.pig_iron_weight,
        )

    @property
    def row_data(self) -> Dict[str, Union[str, int]]:
        return attr.asdict(self)
