import json
import logging
from string import Template
from typing import Any, Dict, List, Optional, Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from dash_ag_grid import AgGrid
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.card_ws_wrapper import ScrapChargeCardWsWrapperVM
from scrap.dash.components.scrap_charge_table.add_scrap_charge_btn import AddScrapChargeVM
from scrap.dash.components.scrap_charge_table.multiple_scrap_charges_checkbox import (
    MultipleScrapChargesAtOnceVM,
)
from scrap.models import converter

log = logging.getLogger(__name__)


@attr.frozen
class ScrapChargeConfig:
    multiple: bool = attr.ib(default=False)
    selected_scrap_charge: List[int] = attr.ib(default=[None, None])

    @classmethod
    def as_dict(cls) -> Dict[str, str]:
        return json.dumps(converter.unstructure(cls()))


@attr.frozen
class ScrapChargesTableVM:
    # Component ids
    TABLE_ID = "table"
    TABLE_WRAPPER_ID = f"{TABLE_ID}-wrapper"
    SCRAP_CHARGE_COMPONENT_ID = "scrap-charge-container"
    MESSAGE_BUFFER_ID = "msg-buffer"
    SCRAP_CHARGE_CARD_WRAPPER_ID = "scrap-charge-cards-wrapper"
    MODAL_ID = "selection-modal"
    SCRAP_CHARGE_TO_ASSIGN_ID = "sc-to-assign"
    SCRAP_CHARGE_CONFIG_ID = "store"
    SELECTOR_WRAPPER_ID = "selector-wrapper"
    ZERO_INDEX_SELECTOR_ID = "zero-index"
    FIRST_INDEX_SELECTOR_ID = "first-index"
    CLOSE_CONFIRMATION_MODAL_FORM_ID = "confirmation-modal"
    CLOSE_CONFIRM_BTN_ID = "btn"
    CS_TRIGGER_ID = "cs-trigger"
    ERROR_STORE_MSG_ID = "error-store-msg-id"
    SCRAP_CHARGE_ID = "sc-id"
    # Table column ids
    BASKET_IDS_COL_ID = "heat_baskets"
    DB_ID_OF_DATA = "id"
    GRADE_COL_ID = "grade"
    PIG_IRON_WEIGHT_COL_ID = "pig_iron_weight"
    SCRAP_WEIGHT_COL_ID = "scrap_weight"
    DELETE_COL_ID = "delete"
    # Table cell formatter
    WEIGHT_VALUE_FORMATTER = {"function": "params.value == null ? '-' : (params.value / 1000) + ' t'"}
    ID_VALUE_FORMATTER = {"function": "params.value == -1 ? 'Vytváram' : params.value"}
    COLORS = ["#FFC999", "#FBA7A7"]
    # User friendly msg
    NO_DATA_MSG = "Súčastne nemáte vytvorenú žiadnu optimalizáciu šrotovej vsádzky."
    LOADING_DATA = "Načítavam dáta"
    CLOSE_CONFIRMATION_MODAL_TITLE = "Uzavretie vsádzky"
    CONFIRM_BTN_LABEL = "Uzavrieť vsádzku"

    # Child component
    add_btn: AddScrapChargeVM = sdc.child_component("add", factory=AddScrapChargeVM)
    multiple_charges: MultipleScrapChargesAtOnceVM = sdc.child_component(
        "", factory=MultipleScrapChargesAtOnceVM
    )
    scrap_charges_cards: ScrapChargeCardWsWrapperVM = sdc.child_component(
        "wrapper", factory=ScrapChargeCardWsWrapperVM
    )

    # Bounded values
    table_data: List[Dict[str, Any]] = sdc.clientside_only_state_binding(TABLE_ID, "rowData", default=[])
    message_buffer_cs: Optional[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_BUFFER_ID,
        "data",
        default="",
    )
    scrap_charge_config: Dict[str, str] = sdc.clientside_one_way_binding_with_both_states(
        SCRAP_CHARGE_CONFIG_ID, "data", default={}
    )
    scrap_charge_to_assign: Optional[str] = sdc.clientside_one_way_binding_with_state(
        SCRAP_CHARGE_TO_ASSIGN_ID, "data", default=None
    )
    select_side_modal_opened: bool = sdc.clientside_one_way_binding(MODAL_ID, "opened", default=False)

    cs_trigger: int = sdc.clientside_only_state_binding(CS_TRIGGER_ID, "data", default=0)

    def get_scrap_charge_config(self) -> Optional[ScrapChargeConfig]:
        return (
            ScrapChargeConfig()
            if not self.scrap_charge_config
            else ScrapChargeConfig(
                multiple=self.scrap_charge_config.get("multiple"),
                selected_scrap_charge=self.scrap_charge_config.get("selectedScrapCharge"),
            )
        )

    @classmethod
    def create(cls, host: str, port: int, scale_ids: Tuple[str, ...]) -> Self:
        return cls(
            scrap_charges_cards=ScrapChargeCardWsWrapperVM.create(host, port, scale_ids),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            [
                html.Div(
                    children=[
                        sdc.get_child_layout(parent_id, cls.multiple_charges, config),
                        AgGrid(
                            columnSize="responsiveSizeToFit",
                            columnDefs=[
                                {
                                    "headerName": "Id",
                                    "field": cls.DB_ID_OF_DATA,
                                    "valueFormatter": cls.ID_VALUE_FORMATTER,
                                },
                                {"headerName": "Čísla Korýt", "field": cls.BASKET_IDS_COL_ID},
                                {"headerName": "Akosť", "field": cls.GRADE_COL_ID},
                                {
                                    "headerName": "Váha šrotu",
                                    "field": cls.SCRAP_WEIGHT_COL_ID,
                                    "valueFormatter": cls.WEIGHT_VALUE_FORMATTER,
                                },
                                {
                                    "headerName": "Váha sur. železa",
                                    "field": cls.PIG_IRON_WEIGHT_COL_ID,
                                    "valueFormatter": cls.WEIGHT_VALUE_FORMATTER,
                                },
                                {
                                    "headerName": "Odstrániť",
                                    "field": cls.DELETE_COL_ID,
                                    "cellRenderer": "Button",
                                    "cellRendererParams": {"variant": "subtle", "color": "red"},
                                    "suppressSizeToFit": True,
                                    "width": 100,
                                },
                            ],
                            dashGridOptions={
                                "domLayout": "autoHeight",
                                "rowHeight": 28,
                                "headerHeight": 30,
                                "noRowsOverlayComponent": "CustomNoRowsOverlay",
                                "noRowsOverlayComponentParams": {
                                    "message": cls.NO_DATA_MSG,
                                    "fontSize": 12,
                                },
                                "loadingOverlayComponent": "CustomLoadingOverlay",
                                "loadingOverlayComponentParams": {
                                    "message": cls.LOADING_DATA,
                                    "fontSize": 12,
                                },
                                "resizable": False,
                            },
                            getRowId=f"params.data.{cls.DB_ID_OF_DATA}",
                            id=sdc.create_id(parent_id, cls.TABLE_ID),
                            style={"height": None},
                        ),
                        sdc.get_child_layout(parent_id, cls.add_btn, config),
                    ],
                    id=sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID),
                ),
                sdc.get_child_layout(parent_id, cls.scrap_charges_cards, config),
                dmc.Modal(
                    children=[
                        html.Div(
                            children=[
                                html.Div(
                                    className="table-skeleton",
                                    children=html.Div(
                                        children=[
                                            dmc.Skeleton(h=8, w="90%"),
                                            dmc.Skeleton(h=8),
                                            dmc.Skeleton(h=8, w="70%"),
                                        ],
                                    ),
                                ),
                                html.Div(
                                    id=sdc.create_id(parent_id, cls.ZERO_INDEX_SELECTOR_ID),
                                    className="position",
                                    children="Prázdne",
                                ),
                                html.Div(
                                    id=sdc.create_id(parent_id, cls.FIRST_INDEX_SELECTOR_ID),
                                    className="position",
                                    children="Prázdne",
                                ),
                            ],
                            id=sdc.create_id(parent_id, cls.SELECTOR_WRAPPER_ID),
                        ),
                        dcc.Store(id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_CONFIG_ID)),
                        dcc.Store(id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_TO_ASSIGN_ID)),
                    ],
                    title="Kde chcete zobraziť zvolenú vsádzku?",
                    size="lg",
                    id=sdc.create_id(parent_id, cls.MODAL_ID),
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.CS_TRIGGER_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_BUFFER_ID)),
            ],
            id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_COMPONENT_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.TABLE_ID, "cellRendererData", *cls.delete_scrap_charge()),
            sdc.InputFieldClientSide(cls.TABLE_ID, "cellClicked", *cls.select_scrap_charge()),
            sdc.InputFieldClientSide(
                cls.ZERO_INDEX_SELECTOR_ID, "n_clicks", *cls.set_scrap_charge_at_index(0)
            ),
            sdc.InputFieldClientSide(
                cls.FIRST_INDEX_SELECTOR_ID, "n_clicks", *cls.set_scrap_charge_at_index(1)
            ),
            sdc.InputFieldClientSide(
                cls.CS_TRIGGER_ID, "modified_timestamp", *cls.close_scrap_charge_clientside()
            ),
        )

    @classmethod
    def delete_scrap_charge(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "deleteScrapCharge",
            ["viewModel", "rowToDelete", "ctx"],
            """
            var updatedVm = {...viewModel};
            const weightedScraps = ctx.getWeightedScraps(rowToDelete.rowId);
            if (weightedScraps === null){
                return updatedVm;
            }

            if (Object.keys(weightedScraps.getAll()).length === 0){
                ctx.models.scrapCharges.delete(rowToDelete.rowId);
            } else {
                updatedVm.message_buffer_cs = JSON.stringify(
                    new ctx.messageDataClass(
                        "Tavbu nie je možné odstrániť po spustení váženia.",
                        "warning"
                    )
                );
            }
            
            return updatedVm;
            """,
        )

    @classmethod
    def select_scrap_charge(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "selectScrapCharge",
            ["viewModel", "selectedCell", "ctx"],
            Template(
                """
            var updatedVm = {...viewModel};
            if (selectedCell.colId === '${delete_col_id}'){
                return updatedVm;
            }

            updatedVm = updatedVm.setScrapCharge(selectedCell.rowId, updatedVm.multiple_charges.checked);
            
            const positionConfig = updatedVm.scrap_charge_config.selectedScrapCharge;
            updatedVm.scrap_charges_cards.card = updatedVm.scrap_charges_cards.card.setInputsValue(
                positionConfig.at(0), updatedVm.scrap_charges_cards.selector_states , ctx
            );
            updatedVm.scrap_charges_cards.card_1 = updatedVm.scrap_charges_cards.card_1.setInputsValue(
                positionConfig.at(1), updatedVm.scrap_charges_cards.selector_states, ctx
            );
            
            return updatedVm;
            """
            ).substitute(delete_col_id=cls.DELETE_COL_ID),
        )

    @classmethod
    def set_scrap_charge_at_index(cls, index: int) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            f"setScrapChargeAtIdx{index}",
            ["viewModel", "nClicks", "ctx"],
            Template(
                """
                var updatedVm = {...viewModel};
                var updatedConfig = {...updatedVm.scrap_charge_config};
                var updatedPosition = [...updatedConfig.selectedScrapCharge];
                     
                updatedPosition[${idx}] = updatedVm.scrap_charge_to_assign;
                updatedConfig.selectedScrapCharge = updatedPosition;
                
                updatedVm.scrap_charge_config = updatedConfig;
                updatedVm.select_side_modal_opened = false;
                updatedVm.scrap_charges_cards.${component_name} = (
                    updatedVm.scrap_charges_cards.${component_name}.setInputsValue(
                        updatedPosition.at(${idx}), updatedVm.scrap_charges_cards.selector_states, ctx
                    )
                );
                     
                return updatedVm;
            """
            ).substitute(idx=index, component_name="card" if index == 0 else f"card_{index}"),
        )

    @classmethod
    def close_scrap_charge_clientside(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "syncDb",
            ["viewModel", "nClicks", "ctx"],
            """
            updatedVm = {...viewModel};

            var updatedConfig = {...updatedVm.scrap_charge_config}
            const updatedPositions = [...updatedConfig.selectedScrapCharge];
            existingIdAt = updatedConfig.selectedScrapCharge.indexOf(viewModel.cs_trigger);
            if (existingIdAt !== -1){
                updatedPositions[existingIdAt] = null;
            }
            updatedConfig.selectedScrapCharge = updatedPositions;
            updatedVm.scrap_charge_config = updatedConfig;
            
            return updatedVm;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.TABLE_ID, "rowData", *cls.get_table_data()),
            sdc.OutputFieldClientSide(
                cls.ZERO_INDEX_SELECTOR_ID, "children", *cls.print_selected_scrap_charge(0)
            ),
            sdc.OutputFieldClientSide(
                cls.FIRST_INDEX_SELECTOR_ID, "children", *cls.print_selected_scrap_charge(1)
            ),
            sdc.OutputFieldClientSide(cls.TABLE_ID, "getRowStyle", *cls.get_row_highlight()),
            sdc.OutputFieldClientSide(cls.CS_TRIGGER_ID, "data", *cls.trigger_cs_to_close_card()),
        )

    @classmethod
    def get_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableData",
            ["viewModel", "ctx"],
            Template(
                """
            const scrapCharges = ctx.models.scrapCharges.getAll();
            const gradeDefinitions = Object.values(ctx.models.gradeDefinitions.getAll());

            var tableData = [];
            for (let chargeId in scrapCharges){
                const sc = scrapCharges[chargeId];
                if (!sc.closed_at){
                    tableData.push(
                        {
                            $db_id: chargeId,
                            $basket_ids: sc.basket_ids.join(", "),
                            $grade: !sc.grade_id ? sc.grade_id : gradeDefinitions.find(grade => grade.grade_id === sc.grade_id).label,
                            $scrap_weight: sc.total_scrap_weight,
                            $pig_iron_weight: sc.pig_iron_weight,
                            $delete: '❌',
                        }
                    );
                }
            }
            return tableData;
            """
            ).substitute(
                db_id=cls.DB_ID_OF_DATA,
                basket_ids=cls.BASKET_IDS_COL_ID,
                grade=cls.GRADE_COL_ID,
                scrap_weight=cls.SCRAP_WEIGHT_COL_ID,
                pig_iron_weight=cls.PIG_IRON_WEIGHT_COL_ID,
                delete=cls.DELETE_COL_ID,
            ),
        )

    @classmethod
    def print_selected_scrap_charge(cls, index: int) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            f"printSelectedScrapCharge{index}",
            ["viewModel", "ctx"],
            Template(
                """
                const config = (viewModel.scrap_charge_config ?? {});
                if (Object.keys(config).length === 0){
                    return 'Prázdne';
                }
                const selectedScrapChargeId = config.selectedScrapCharge.at(${idx});
                const scrapCharge = ctx.models.scrapCharges.get(selectedScrapChargeId);
                if (!scrapCharge){
                    return 'Prázdne';
                }

                
                const values = [
                    {label: 'Čísla korýt', value: viewModel.getValueOrString(scrapCharge.basket_ids, 'Neuvedené')},
                    {label: 'Akosť', value: viewModel.getValueOrString(scrapCharge.grade, 'Neuvedené')},
                    {label: 'Váha šrotu', value: viewModel.getValueOrString(ctx.kgsToTons(scrapCharge.total_scrap_weight), 'Neuvedené', 't')},
                    {label: 'Váha sur. železa', value: viewModel.getValueOrString(ctx.kgsToTons(scrapCharge.pig_iron_weight), 'Neuvedené', 't')},
                ];

                const spanElem = {type: "Span", namespace: "dash_html_components"};
                return values.map(
                    row => {
                        return {
                            type: "Div",
                            namespace: "dash_html_components",
                            props: {
                                className: 'row-data',
                                children: [
                                    {...spanElem, props: {className: 'label', children: row.label}},
                                    {...spanElem, props: {className: 'value', children: row.value}},
                                ]
                            }
                        } 
                    }
                );
            """
            ).substitute(idx=index),
        )

    @classmethod
    def get_row_highlight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getConditionalStyle",
            ["viewModel", "ctx"],
            Template(
                """
                const base = {styleConditions: []};
                const config = (viewModel.scrap_charge_config ?? {});
                if (Object.keys(config).length === 0){
                    return base;
                }

                const colors = ${colors};
                var conditions = [];
                for (let idx of [0, 1]){
                    let scrapChargeId = config.selectedScrapCharge.at(idx);
                    if (scrapChargeId != null){
                        var condition = {};
                        condition["condition"] = "params.data.id ===  '" + config.selectedScrapCharge.at(idx) + "'";
                        condition["style"] = {
                            "background": "linear-gradient(" + (idx ? "" : "-") + "45deg, #fff 50%, " + colors.at(idx) + " 100%)"
                        };
                        conditions.push(condition);
                    }
                }
                
                base.styleConditions = conditions;
                return base;
            """
            ).substitute(colors=cls.COLORS),
        )

    @classmethod
    def trigger_cs_to_close_card(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "triggerToCloseCard",
            ["viewModel"],
            "return viewModel.scrap_charges_cards.card.decision.confirmation_data?.scrapChargeId;",
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_scrap_charge()),
            sdc.JsCodeField(*cls.get_value_or_default_string()),
        )

    @classmethod
    def set_scrap_charge(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setScrapCharge",
            ["scrapChargeId", "multiple"],
            Template(
                """
            var updatedVm = {...this};
            var updatedConfig = {...updatedVm.scrap_charge_config}
            if (Object.keys({...updatedVm.scrap_charge_config}).length === 0){
                // Initial setup
                updatedConfig = {
                    multiple: multiple,
                    selectedScrapCharge: [null, null]
                };
            }

            const updatedPositions = [...updatedConfig.selectedScrapCharge];
            existingIdAt = updatedConfig.selectedScrapCharge.indexOf(scrapChargeId);
            if (existingIdAt !== -1){
                updatedPositions[existingIdAt] = null;
            } else {
                if (multiple){
                    const nullValueIndex = updatedPositions.indexOf(null);
                    if (nullValueIndex === -1){
                        updatedVm.select_side_modal_opened = true;
                        updatedVm.scrap_charge_to_assign = scrapChargeId;
                    } else {
                        updatedPositions[nullValueIndex] = scrapChargeId;
                    }
                } else {
                    updatedPositions[0] = scrapChargeId;
                }
            }
            updatedConfig.selectedScrapCharge = updatedPositions;
            updatedVm.scrap_charge_config = updatedConfig;
            
            return updatedVm;
            """
            ).substitute(base_config=ScrapChargeConfig.as_dict()),
        )

    @classmethod
    def get_value_or_default_string(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValueOrString",
            ["value", "defaultString", "valueUnit = ''"],
            """
            if (value?.constructor.name === 'Array')
                return value.length === 0 ? defaultString : value.join(', ');
            return !value ? defaultString : `${value} ${valueUnit}`;
            """,
        )
