import json
from string import Template
from typing import Optional, Tuple

import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charges.model.scrap_charge.datamodel import ScrapChargeDb
from scrap.models import converter


@frozen
class AddScrapChargeVM:
    # Component id
    COMPONENT_ID = "btn"
    WRAPPER_ID = "wrapper"
    # User friendly msg
    NEW_CHARGE = "Vytvoriť šrotovu vsádzku"

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> Optional[dmc.Button]:
        return dmc.Button(
            cls.NEW_CHARGE,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            leftIcon=html.Img(
                src="/static/scrap/img/add-row.svg",
                height=24,
                width=24,
            ),
            disabled=config.read_only,
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (sdc.InputFieldClientSide(cls.COMPONENT_ID, "n_clicks", *cls.add_scrap_charge()),)

    @classmethod
    def add_scrap_charge(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "addScrapCharge",
            ["viewModel", "nClicks", "ctx"],
            Template(
                """
            var newScrapCharge = $new_scrap_charge;
            newScrapCharge.scrap_limits = Object.values(ctx.models.availableScraps.getAll()).map(
                scrap => {
                    return {"scrap_type": scrap.scrap_type, "maximum": null, "minimum": null}
                }
            );
            ctx.models.scrapCharges.add(newScrapCharge);
            ctx.models.scrapCharges.save();
            return viewModel;
            """
            ).substitute(new_scrap_charge=json.dumps(converter.unstructure(ScrapChargeDb()))),
        )
