from typing import Collection

import dash_bootstrap_components as dbc
from dash import html
from dash.development.base_component import Component

# Component classnames
TABLE_TOP_TITLE_SECTION_CLASSNAME = "title-section title-section-top"
TABLE_TITLE_MESSAGE_CLASSNAME = "title-section-msg"
BUTTON_SIGN_CLASSNAME = "sign"
COMPONENT_WRAPPER_ID = "table-wrapper"


def get_table_header(
    message_id: str, new_group_button_id: str, table_title: str, add_button_label: str
) -> html.Div:
    return html.Div(
        children=[
            html.Div(
                children=[
                    html.H5(table_title),
                    html.P(className=TABLE_TITLE_MESSAGE_CLASSNAME, id=message_id),
                ],
            ),
            dbc.Button(
                children=[
                    html.Span(children="+", className=BUTTON_SIGN_CLASSNAME),
                    html.Span(add_button_label),
                ],
                color="success",
                id=new_group_button_id,
            ),
        ],
        className=TABLE_TOP_TITLE_SECTION_CLASSNAME,
    )


def table_wrapper_with_header(
    table_component: Component,
    table_title: str,
    add_button_label: str,
    wrapper_id: str,
    message_id: str,
    new_group_button_id: str,
    hidden_on_load: bool = True,
    other_components: Collection[Component] = (),
) -> html.Div:
    return html.Div(
        children=[
            get_table_header(
                message_id,
                new_group_button_id,
                table_title,
                add_button_label,
            ),
            table_component,
            *other_components,
        ],
        className=COMPONENT_WRAPPER_ID,
        hidden=hidden_on_load,
        id=wrapper_id,
    )
