from typing import Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


SUMMARY_ROW_CLASSNAME = "summary-row"


def get_summary_row(id_: str, title: str) -> html.Div:
    return html.Div(
        [
            dmc.Title(title, order=5),
            dmc.Text(id=id_),
        ],
        className=SUMMARY_ROW_CLASSNAME,
    )


@attr.frozen
class SummaryCreateScrapPurchaseVM:
    # Component ids
    DATE_ID = "date"
    PILE_EVIDENCE_ID = "pile-evidence"
    SCRAP_ON_THE_WAY_ID = "scrap-on-the-way"
    MEAN_SCRAP_ID = "mean-scrap"
    SCRAP_STOCK_ID = "scrap-stock"
    EXPECTED_STEEL_ID = "expected-steel"
    EXPORT_SLABS_ID = "export-slabs"
    PRODUCTION_PLAN_DATE_ID = "production-plan-date"
    PRODUCTION_PLAN_WEEKS_ID = "production-plan-weeks"
    PRODUCTION_PLAN_COUNT_ID = "production-plan-count"
    SCRAP_OFFERS_FILENAME_ID = "scrap-offers-filename"
    SCRAP_OFFERS_COUNT_ID = "scrap-offers-count"

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.DATE_ID, "children", *cls.set_purchase_date()),
            sdc.OutputFieldClientSide(cls.PILE_EVIDENCE_ID, "children", *cls.set_pile_evidence_filename()),
            sdc.OutputFieldClientSide(cls.SCRAP_ON_THE_WAY_ID, "children", *cls.scrap_on_the_way_filename()),
            sdc.OutputFieldClientSide(cls.MEAN_SCRAP_ID, "children", *cls.set_mean_scrap()),
            sdc.OutputFieldClientSide(cls.SCRAP_STOCK_ID, "children", *cls.set_scrap_stock()),
            sdc.OutputFieldClientSide(cls.EXPORT_SLABS_ID, "children", *cls.set_export_slabs()),
            sdc.OutputFieldClientSide(cls.EXPECTED_STEEL_ID, "children", *cls.set_expected_steel()),
            sdc.OutputFieldClientSide(
                cls.PRODUCTION_PLAN_DATE_ID, "children", *cls.set_production_plan_date()
            ),
            sdc.OutputFieldClientSide(
                cls.PRODUCTION_PLAN_WEEKS_ID, "children", *cls.set_production_plan_weeks()
            ),
            sdc.OutputFieldClientSide(
                cls.PRODUCTION_PLAN_COUNT_ID, "children", *cls.set_production_plan_count()
            ),
            sdc.OutputFieldClientSide(
                cls.SCRAP_OFFERS_FILENAME_ID, "children", *cls.set_scrap_offer_filename()
            ),
            sdc.OutputFieldClientSide(cls.SCRAP_OFFERS_COUNT_ID, "children", *cls.set_scrap_offer_count()),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                dmc.Divider(label="Základné informácie", size="sm", color="white"),
                get_summary_row(sdc.create_id(parent_id, cls.DATE_ID), "Dátum nákupu: "),
                dmc.Divider(label="Stav šrotu", size="sm", color="white"),
                get_summary_row(sdc.create_id(parent_id, cls.PILE_EVIDENCE_ID), "Súbor s evidenciou šrotu: "),
                get_summary_row(
                    sdc.create_id(parent_id, cls.SCRAP_ON_THE_WAY_ID), "Súbor so šrotom na ceste: "
                ),
                get_summary_row(sdc.create_id(parent_id, cls.SCRAP_STOCK_ID), "Cieľova zásoba šrotu: "),
                get_summary_row(sdc.create_id(parent_id, cls.MEAN_SCRAP_ID), "Hmotnosť šrotovej vsádzky: "),
                dmc.Divider(label="Plán výroby", size="sm", color="white"),
                get_summary_row(
                    sdc.create_id(parent_id, cls.PRODUCTION_PLAN_DATE_ID), "Datum plánu výroby: "
                ),
                get_summary_row(
                    sdc.create_id(parent_id, cls.PRODUCTION_PLAN_WEEKS_ID), "Plán výroby získaný pre: "
                ),
                get_summary_row(
                    sdc.create_id(parent_id, cls.PRODUCTION_PLAN_COUNT_ID), "Počet plánovaných akostí: "
                ),
                get_summary_row(
                    sdc.create_id(parent_id, cls.EXPECTED_STEEL_ID), "Očakávaná produkcia ocele: "
                ),
                get_summary_row(sdc.create_id(parent_id, cls.EXPORT_SLABS_ID), "Hmotnosť exportných brám: "),
                dmc.Divider(label="Ponuky", size="sm", color="white"),
                get_summary_row(
                    sdc.create_id(parent_id, cls.SCRAP_OFFERS_FILENAME_ID), "Súbor s ponukami šrotu: "
                ),
                get_summary_row(sdc.create_id(parent_id, cls.SCRAP_OFFERS_COUNT_ID), "Počet ponúk šrotu: "),
            ],
        )

    @classmethod
    def set_purchase_date(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setPurchasedDate", ["vm", "ctx"], "return ctx.purchaseDate ?? '';"
        )

    @classmethod
    def set_pile_evidence_filename(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setPileEvidenceFilename", ["vm", "ctx"], "return ctx.pileEvidenceFilename ?? '';"
        )

    @classmethod
    def scrap_on_the_way_filename(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setScrapOnTheWayFilename", ["vm", "ctx"], "return ctx.scrapOnTheWay ?? '';"
        )

    @classmethod
    def set_mean_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setMeanScrap", ["vm", "ctx"], "return (ctx.meanScrap ?? '') + 't';"
        )

    @classmethod
    def set_scrap_stock(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setScrapStock", ["vm", "ctx"], "return (ctx.scrapStock ?? '') + 't';"
        )

    @classmethod
    def set_export_slabs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setExportSlabs", ["vm", "ctx"], "return (ctx.exportSlabs ?? '') + 't';"
        )

    @classmethod
    def set_expected_steel(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setExpectedSteel", ["vm", "ctx"], "return (ctx.expectedProduction ?? '') + 't';"
        )

    @classmethod
    def set_production_plan_date(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setProductionPlanDate", ["vm", "ctx"], "return ctx.productionPlanDate ?? '';"
        )

    @classmethod
    def set_production_plan_weeks(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setProductionPlanWeeks", ["vm", "ctx"], "return (ctx.productionPlanWeeks ?? '') + ' týždne';"
        )

    @classmethod
    def set_production_plan_count(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setProductionPlanCount", ["vm", "ctx"], "return (ctx.productionPlanedCount ?? '') + ' akostí';"
        )

    @classmethod
    def set_scrap_offer_filename(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setScrapOfferFilename", ["vm", "ctx"], "return ctx.scrapOfferFilename ?? '';"
        )

    @classmethod
    def set_scrap_offer_count(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setScrapOfferCount", ["vm", "ctx"], "return (ctx.scrapOfferCount ?? '') + ' ponúk';"
        )
