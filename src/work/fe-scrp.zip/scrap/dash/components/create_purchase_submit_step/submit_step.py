from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from scrap.dash.components.protocols.create_scrap_purchase import CreateScrapPurchaseSource
from scrap.dash.components.create_purchase_submit_step.summary import SummaryCreateScrapPurchaseVM
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class SubmitCreateScrapPurchaseVM:
    # Component ids
    COMPONENT_ID = "summary-step"
    CONFIRM_BUTTON_ID = "create-scrap-purchase-btn"
    REDIRECT_LINK_ID = "redirect-link"
    CREATION_RESULT_ID = "creating-result"
    DRAWER_ID = "drawer"
    INTERVAL_ID = "interval"
    RELOAD_TEXT_ID = "reload-text"
    RELOAD_TITLE_ID = "reload-title"
    START_TRIGGER_ID = "start-trigger"
    # User friendly msg
    CONFIRM_BUTTON = "Vytvoriť nákup"
    # Settings
    COUNTDOWN_LENGTH = 5  # 5 seconds

    creation_trigger: Optional[bool] = sdc.clientside_one_way_binding_with_state(
        START_TRIGGER_ID, "data", default=None
    )
    loading: bool = sdc.clientside_one_way_binding_with_state(CONFIRM_BUTTON_ID, "loading", default=False)
    opened: bool = sdc.one_way_binding(DRAWER_ID, "opened", default=False)
    interval_disabled: bool = sdc.one_way_binding(INTERVAL_ID, "disabled", default=True)
    purchase_record_id: Optional[int] = sdc.binding(
        CREATION_RESULT_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    reload_text: str = sdc.clientside_one_way_binding(RELOAD_TEXT_ID, "children", default="")
    reload_title: str = sdc.one_way_binding(RELOAD_TITLE_ID, "children", default="")
    redirect_pathname: str = sdc.clientside_one_way_binding_with_state(
        REDIRECT_LINK_ID, "pathname", default=""
    )
    redirect_refresh: bool = sdc.clientside_one_way_binding_with_state(
        REDIRECT_LINK_ID, "refresh", default=False
    )
    summary: SummaryCreateScrapPurchaseVM = sdc.child_component(
        "summary", factory=SummaryCreateScrapPurchaseVM
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.START_TRIGGER_ID, "modified_timestamp", cls.create_or_update_scrap_purchase),
            sdc.InputFieldClientSide(cls.INTERVAL_ID, "n_intervals", *cls.update_reload_text()),
            sdc.InputFieldClientSide(cls.CONFIRM_BUTTON_ID, "n_clicks", *cls.start_creation()),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                sdc.get_child_layout(parent_id, cls.summary),
                dmc.Button(
                    cls.CONFIRM_BUTTON,
                    id=sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID),
                    color="green",
                    variant="light",
                ),
                dcc.Location(id=sdc.create_id(parent_id, cls.REDIRECT_LINK_ID), refresh=False),
                dcc.Store(id=sdc.create_id(parent_id, cls.CREATION_RESULT_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.START_TRIGGER_ID)),
                dmc.Drawer(
                    id=sdc.create_id(parent_id, cls.DRAWER_ID),
                    closeOnClickOutside=False,
                    closeOnEscape=False,
                    withCloseButton=False,
                    children=[
                        html.H2(
                            "Vytvorenie nákupu prebehlo úspešne",
                            id=sdc.create_id(parent_id, cls.RELOAD_TITLE_ID),
                        ),
                        html.Div(
                            "Za 5 sekúnd budete presmerovaný na stránku nákupu.",
                            id=sdc.create_id(parent_id, cls.RELOAD_TEXT_ID),
                        ),
                    ],
                    position="bottom",
                    zIndex=10000,
                ),
                dcc.Interval(id=sdc.create_id(parent_id, cls.INTERVAL_ID), disabled=True, max_intervals=10),
            ],
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def start_creation(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "startCreation",
            ["vm", "nClicks"],
            """
            var updatedVM = {...vm};
            updatedVM.loading = true;
            updatedVM.creation_trigger = true;
            return updatedVM;
            """,
        )

    @classmethod
    def update_reload_text(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateReloadText",
            ["vm", "nIntervals"],
            Template(
                """
            var updatedVM = {...vm};
            if (vm.purchase_record_id == -1){
                updatedVM.reload_text = 'Prosím kontaktujte IT';
            } else {
                const wait = ${countdown_len} - nIntervals;
                updatedVM.reload_text = 'Za ' + wait + ' sekúnd budete presmerovaný na stránku nákupu';
                if (wait === 0){
                    updatedVM.redirect_pathname = '/scrap/purchase_app/' + vm.purchase_record_id + '/';
                    updatedVM.redirect_refresh = true;
                }
            }
            return updatedVM;
            """
            ).substitute(countdown_len=cls.COUNTDOWN_LENGTH),
        )

    def create_or_update_scrap_purchase(
        self, _: int, ctx: CreateScrapPurchaseSource
    ) -> "SubmitCreateScrapPurchaseVM":
        if ctx.purchase_id is None:
            purchase_record_id = ctx.models.scrap_purchase_record.create(
                purchase_name=ctx.purchase_name,
                purchase_date=ctx.purchase_date,
                current_data=ctx.scrap_purchase_record_display_data,
                user_in_control=ctx.logged_user,
                authorized_user_ids=ctx.authorized_user_ids,
            )
        else:
            purchase_record_id = ctx.models.scrap_purchase_record.update(
                ctx.purchase_id,
                current_data=ctx.scrap_purchase_record_display_data,
            )

        return attr.evolve(
            self,
            purchase_record_id=purchase_record_id,
            opened=True,
            interval_disabled=False,
            reload_title=(
                "Nepodarilo sa vytvoriť/aktualizovať nákup"
                if purchase_record_id == -1
                else "Vytvorenie/aktualizácia nákupu prebehlo/a úspešne"
            ),
        )
