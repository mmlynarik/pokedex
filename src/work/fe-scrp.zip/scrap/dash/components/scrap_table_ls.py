from typing import List, Sequence, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, dcc, html
from scrap_core import ScrapMix
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    AvailableScraps,
    INDOOR_SCRAP_NAME,
    OUTDOOR_SCRAP_NAME,
)
from scrap_core.utils import convert_kilograms_to_tons, convert_tons_to_kilograms
from common.dash import CELL_STYLE, DATA_TEXT_STYLE
from scrap_core import ScrapType, vectorize_values_dynamic, SUPPORTED_SCRAP_TYPES

from . import get_scrap_type_label

CHANGE_WEIGHT_SCRAP_DROPDOWN_ID = "change-weight-scrap-dropdown"
CHANGE_WEIGHT_INPUT_ID = "change-scrap-weight-input"
CHANGE_WEIGHT_UPDATE_BTN_ID = "change-scrap-weight-btn"

APPEND_SCRAP_DROPDOWN_ID = "append-scrap-dropdown"
APPEND_WEIGHT_INPUT_ID = "append-scrap-weight-input"
APPEND_SCRAP_BTN_ID = "append-scrap-weight-btn"

TRANSFER_CAPACITY_WEIGHT_INPUT_ID = "transfer-capacity-weight-input"


class ScrapTableRow(TypedDict):
    label: str
    scrap_mix: ScrapMix
    weight: float
    location: str


ScrapTableData = List[ScrapTableRow]


def get_scrap_row(
    scrap_mix: ScrapMix, scrap_weight: float = 0.0, location: str = INDOOR_SCRAP_NAME
) -> ScrapTableRow:
    return {
        "label": get_scrap_type_label(scrap_mix),
        "scrap_mix": scrap_mix,
        "weight": scrap_weight,
        "location": location,
    }


def get_scrap_table_data_with_weights(scrap_map: AvailableScraps) -> ScrapTableData:
    return [
        get_scrap_row(
            scrap_data.scrap_type, convert_kilograms_to_tons(scrap_data.weight), scrap_data.location
        )
        for scrap_data in scrap_map
    ]


def get_scrap_table_data_without_weights(scrap_mixes: Sequence[ScrapMix]) -> ScrapTableData:
    return [get_scrap_row(scrap_mix) for scrap_mix in scrap_mixes]


def get_scrap_map_from_scrap_table_data(table_data: ScrapTableData) -> AvailableScraps:
    return tuple(
        AvailableScrap(row["scrap_mix"], convert_tons_to_kilograms(row["weight"]), row["location"])
        for row in table_data
    )


# pylint: disable=too-many-arguments
def get_card_with_input_for_scrap_update(
    card_label: str,
    dropdown_id: str,
    dropdown_placeholder: str,
    weight_input_id: str,
    button_id: str,
    button_text: str,
    button_color: str,
) -> dbc.Col:
    return dbc.Col(
        html.Div(
            [
                html.H6(
                    card_label,
                    className="add-scrap-card-headline",
                ),
                dcc.Dropdown(
                    id=dropdown_id,
                    # options parameter is set via callback
                    # `set_all_available_scrap_types_to_dropdown` or
                    # `set_scrap_to_change_scrap_weight_dropdown`
                    placeholder=dropdown_placeholder,
                    style={"margin": "16px auto", "width": "97%"},
                ),
                dbc.InputGroup(
                    [
                        dbc.Input(
                            id=weight_input_id,
                            type="number",
                            min=0.0,
                            step=0.1,
                            placeholder="Hmotnosť šrotu",
                            style={"width": "70%"},
                            debounce=True,
                        ),
                        dbc.InputGroupText("t"),
                    ],
                    style={"margin": "0 auto", "width": "94%"},
                ),
                dbc.Button(
                    button_text,
                    id=button_id,
                    color=button_color,
                    className="mt-3 w-100",
                ),
            ],
            style={"border": "solid 1px #cecece", "border-radius": "5px", "margin-top": "32px"},
        ),
        width=12,
    )


def get_card_with_transfer_capacity(card_label: str, weight_input_id: str) -> dbc.Col:
    return dbc.Col(
        html.Div(
            [
                html.H6(
                    card_label,
                    className="add-scrap-card-headline",
                ),
                dbc.InputGroup(
                    [
                        dbc.Input(
                            id=weight_input_id,
                            type="number",
                            min=0.0,
                            step=1.0,
                            placeholder="Hmotnosť šrotu",
                            style={"width": "70%"},
                            debounce=True,
                        ),
                        dbc.InputGroupText("t"),
                    ],
                    style={"margin": "0 auto", "width": "94%"},
                ),
            ],
            style={"border": "solid 1px #cecece", "border-radius": "5px", "margin-top": "32px"},
            id=weight_input_id + "-div",
        ),
        width=12,
    )


def create_scrap_table_ls(table_id: str, read_only: bool) -> dbc.Row:
    """Scrap table for loading station."""
    not_read_only_element = dbc.Col()
    not_read_only_element_2 = dbc.Col()
    not_read_only_element_3 = dbc.Col()
    if not read_only:
        not_read_only_element = get_card_with_input_for_scrap_update(
            "Pridanie šrotu",
            APPEND_SCRAP_DROPDOWN_ID,
            "Zvoľ šrot",
            APPEND_WEIGHT_INPUT_ID,
            APPEND_SCRAP_BTN_ID,
            "Pridaj šrot",
            "primary",
        )
        not_read_only_element_2 = get_card_with_input_for_scrap_update(
            "Úprava hmotnosti šrotu",
            CHANGE_WEIGHT_SCRAP_DROPDOWN_ID,
            "Zvoľ z dostupných šrotov",
            CHANGE_WEIGHT_INPUT_ID,
            CHANGE_WEIGHT_UPDATE_BTN_ID,
            "Uprav hmotnosť",
            "secondary",
        )
        not_read_only_element_3 = get_card_with_transfer_capacity(
            "Prepravná kapacita",
            TRANSFER_CAPACITY_WEIGHT_INPUT_ID,
        )

    return dbc.Row(
        [
            dbc.Col(
                dash_table.DataTable(
                    id=table_id,
                    editable=True,
                    columns=[
                        {"name": "Typ šrotu", "id": "label", "type": "text", "editable": False},
                        {"name": "Hmotnosť [t]", "id": "weight", "type": "numeric", "editable": False},
                        {
                            "name": "Umiestnenie",
                            "id": "location",
                            "presentation": "dropdown",
                            "type": "text",
                            "editable": True,
                        },
                    ],
                    dropdown={
                        "location": {
                            "options": [
                                {"label": "Mimo haly", "value": OUTDOOR_SCRAP_NAME},
                                {"label": "V hale", "value": INDOOR_SCRAP_NAME},
                            ]
                        }
                    },
                    style_data_conditional=DATA_TEXT_STYLE,
                    style_table={"width": "100%", "padding-left": "16px", "padding-right": "16px"},
                    style_cell=CELL_STYLE,
                    style_header={
                        "font-family": "calibri",
                        "whiteSpace": "normal",
                        "height": "auto",
                        "textAlign": "center",
                        "fontWeight": "bold",
                    },
                ),
                width=12,
            ),
            not_read_only_element_3,
            not_read_only_element,
            not_read_only_element_2,
        ]
    )
