import attr
import dash_mantine_components as dmc
import ussksdc as sdc

from scrap.dash.components.common import ScrapPurchaseAppSource
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig


@attr.frozen
class FreezeUnfreezeButtonVM:
    BTN_ID = "button"

    BTN_LABEL = "Zmraziť/Odmraziť filtrované"
    BTN_VARIANT = "white"
    BTN_COLOR = "blue.4"  # Dash mantine color scheme
    BTN_COMPACT = True

    @classmethod
    def get_input_fields(
        cls,
    ) -> sdc.InputFields:
        return (
            sdc.InputField(
                cls.BTN_ID,
                "n_clicks",
                cls.freeze_unfreeze_offers,
            ),
        )

    @classmethod
    def get_layout(
        cls,
        parent_id: str,
        config: ScrapPurchaseAppConfig,
    ) -> dmc.Button:
        return dmc.Button(
            cls.BTN_LABEL,
            id=sdc.create_id(
                parent_id,
                cls.BTN_ID,
            ),
            color=cls.BTN_COLOR,
            compact=cls.BTN_COMPACT,
            variant=cls.BTN_VARIANT,
            disabled=config.read_only,
        )

    def freeze_unfreeze_offers(
        self,
        _: int,
        ctx: ScrapPurchaseAppSource,
    ) -> "FreezeUnfreezeButtonVM":
        ctx.db_purchase_data_source.freeze_unfreeze_offers(ctx.filtered_offers_ids)
        return self
