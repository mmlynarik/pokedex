import json
import uuid
from collections import OrderedDict
from datetime import date
from typing import Dict, List, Optional, Tuple

import attr
import numpy
from django.db.models import QuerySet
from scrap_core import SCRAP_GROUP_MAPPING, ScrapType

from scrap.models import (
    RealizedScrapOffer,
    RealizedScrapOfferData,
    ScrapOffer,
    ScrapOfferData,
    ScrapPurchase,
    converter,
)
from scrap.scrap_purchase.optimization import get_remainder_recommendation


@attr.s(auto_attribs=True, slots=True, frozen=True)
class PricePlotValues:
    date_list: List[date]
    hover_label_list: List[str]
    weighted_price_list: List[float]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class PricePlotData:
    scrap_type: Optional[ScrapType]
    price_plot_values: Dict[str, PricePlotValues]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def update_field(self, **kwargs) -> "PricePlotData":
        return attr.evolve(self, **kwargs)


def update_scrap_offers_after_purchase(
    scrap_offer_data: ScrapOfferData, scrap_uuid: str, amount_to_buy: float
) -> Tuple[ScrapOfferData, Optional[str], ScrapOffer]:
    scrap_offer_data_list = list(scrap_offer_data)
    idx, scrap_offer_to_buy = [
        (idx, scrap_offer)
        for idx, scrap_offer in enumerate(scrap_offer_data)
        if scrap_offer.uuid == scrap_uuid
    ][0]
    updated_scrap_offer = scrap_offer_to_buy.update_field(scrap_purchased=True)
    scrap_offer_data_list[idx] = updated_scrap_offer

    offer_weight = updated_scrap_offer.weight if updated_scrap_offer.weight is not None else 0
    offer_to_buy_weight = scrap_offer_to_buy.weight if scrap_offer_to_buy.weight is not None else 0

    amount_diff = offer_weight - amount_to_buy
    additional_scrap_offer_uuid = None
    if amount_diff != 0:
        if amount_diff > 0:
            new_weight = amount_diff
            new_scrap_purchased = False
        else:
            new_weight = abs(amount_diff)
            new_scrap_purchased = True

        additional_scrap_offer = ScrapOffer(
            scrap_type=scrap_offer_to_buy.scrap_type,
            zone=scrap_offer_to_buy.zone,
            weight=new_weight,
            supplier=scrap_offer_to_buy.supplier,
            supplier_price=scrap_offer_to_buy.supplier_price,
            price_with_delta=scrap_offer_to_buy.price_with_delta,
            recommendation=get_remainder_recommendation(
                new_weight, offer_to_buy_weight, scrap_offer_to_buy.recommendation or 0
            ),
            scrap_purchased=new_scrap_purchased,
            base_delta_rules=scrap_offer_to_buy.base_delta_rules,
            added_by_user=False,
            note=scrap_offer_to_buy.note,
            uuid=str(uuid.uuid4()),
            override_price=scrap_offer_to_buy.override_price,
            generated_from=scrap_offer_to_buy.uuid,
            station=scrap_offer_to_buy.station,
            last_month_price=scrap_offer_to_buy.last_month_price,
            last_month_price_added_manually=scrap_offer_to_buy.last_month_price_added_manually,
            scrap_purchase_pk=scrap_offer_to_buy.scrap_purchase_pk,
        )
        additional_scrap_offer_uuid = additional_scrap_offer.uuid
        scrap_offer_data_list.insert(idx + 1, additional_scrap_offer)

    return tuple(scrap_offer_data_list), additional_scrap_offer_uuid, scrap_offer_to_buy


def update_realized_scrap_offer_data(
    realized_scrap_offer_data: RealizedScrapOfferData,
    scrap_offer_to_buy: ScrapOffer,
    scrap_offer_uuid_list: List[str],
    amount: float,
    price: float,
) -> RealizedScrapOfferData:
    return realized_scrap_offer_data + (
        RealizedScrapOffer(
            scrap_type=scrap_offer_to_buy.scrap_type,
            zone=scrap_offer_to_buy.zone,
            weight=amount,
            price=price,
            supplier=scrap_offer_to_buy.supplier,
            note=scrap_offer_to_buy.note,
            scrap_offer_uuid_list=scrap_offer_uuid_list,
        ),
    )


def convert_input_string_to_positive_float_or_none(str_num: Optional[str]) -> Optional[float]:
    if str_num is None:
        return None
    try:
        float_num = float(str_num)
        return float_num if float_num > 0.0 else None
    except ValueError:
        return None


def get_scrap_type_dropdown_options():
    scraps = [scrap_type for scrap_type, resource in SCRAP_GROUP_MAPPING.items() if resource != "Home"]
    return [{"label": scrap_type_name, "value": scrap_type_name} for scrap_type_name in scraps]


def get_zone_list_for_scrap_type_from_db(ordered: bool = False) -> List[str]:
    zone_list = list(ScrapPurchase.objects.order_by().values_list("zone", flat=True).distinct())
    if ordered:
        zone_list = sorted(zone_list)
    return zone_list


def get_scrap_type_price_histories_for_zones(scrap_type: str, zones: List[str]) -> Dict[str, QuerySet]:
    price_histories = dict()
    for zone in zones:
        price_histories[zone] = ScrapPurchase.objects.filter(scrap_type=scrap_type, zone=zone).order_by(
            "date"
        )
    return price_histories


def divide_price_history_list(price_history_list: List[ScrapPurchase]) -> OrderedDict:
    group_by_date: OrderedDict = OrderedDict()
    for price_history_item in price_history_list:
        item_date = price_history_item.date
        if item_date not in group_by_date:
            group_by_date[item_date] = {
                "price_list": list(),
                "quantity_list": list(),
                "supplier_list": list(),
            }
        group_by_date[item_date]["price_list"].append(price_history_item.price)
        group_by_date[item_date]["quantity_list"].append(price_history_item.quantity)
        group_by_date[item_date]["supplier_list"].append(price_history_item.supplier)
    return group_by_date


def process_price_history_group(price_history_group: Dict) -> Tuple[float, str]:
    temp_price_list = price_history_group["price_list"]
    temp_quantity_list = price_history_group["quantity_list"]
    temp_supplier_list = price_history_group["supplier_list"]

    final_value = (
        numpy.average(temp_price_list, weights=temp_quantity_list) if sum(temp_quantity_list) > 0 else 0.0
    )
    hover_label = f"{final_value}€<br>" + "<br>".join(
        [
            "{}€ {}ton {}".format(p, q, s)
            for p, q, s in zip(temp_price_list, temp_quantity_list, temp_supplier_list)
        ]
    )
    return final_value, hover_label


def compute_price_plot_data(scrap_type: ScrapType) -> PricePlotData:
    computed_data = OrderedDict()
    price_plot_data = PricePlotData(
        scrap_type=scrap_type,
        price_plot_values=OrderedDict(),
    )

    zone_list = get_zone_list_for_scrap_type_from_db(ordered=True)
    price_history_querysets = get_scrap_type_price_histories_for_zones(
        scrap_type=str(scrap_type), zones=zone_list
    )

    for price_history_zone, price_history in price_history_querysets.items():
        price_history_list = list(price_history)

        date_list = list()
        hover_label_list = list()
        weighted_price_list = list()

        group_by_date = divide_price_history_list(price_history_list)

        for item_date, item_dict in group_by_date.items():
            final_value, hover_label = process_price_history_group(item_dict)
            if final_value:
                date_list.append(item_date)
                weighted_price_list.append(final_value)
                hover_label_list.append(hover_label)

        computed_data[price_history_zone] = PricePlotValues(
            date_list=date_list,
            hover_label_list=hover_label_list,
            weighted_price_list=weighted_price_list,
        )
    price_plot_data = price_plot_data.update_field(
        price_plot_values=computed_data,
    )
    return price_plot_data
