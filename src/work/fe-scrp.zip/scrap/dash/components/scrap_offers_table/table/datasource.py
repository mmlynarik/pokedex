from typing import Any, Dict, Optional, Tuple

import attr
from scrap_core import ScrapType

from scrap.models import ScrapOfferData


@attr.frozen
class ScrapOffersTableRowVM:
    uuid: str
    scrap_offer_pk: int
    frozen: bool
    scrap_purchased: bool
    base_delta_rules: str
    last_month_price_added_manually: bool
    scrap_type: Optional[ScrapType]
    zone: Optional[str]
    weight: Optional[float]
    supplier: Optional[str]
    supplier_price: Optional[float]
    last_month_price: Optional[float]
    override_price: Optional[float]
    price_with_delta: Optional[float]
    recommendation: Optional[float]
    note: Optional[str]
    generated_from: Optional[str]
    station: Optional[str]

    @property
    def table_row(self) -> Dict[str, Any]:
        return attr.asdict(self)


def convert_scrap_offer_table_data(scrap_offer_data: ScrapOfferData) -> Tuple[ScrapOffersTableRowVM, ...]:
    return tuple(
        ScrapOffersTableRowVM(
            uuid=scrap_offer.uuid,
            scrap_offer_pk=scrap_offer.scrap_purchase_pk,
            scrap_type=scrap_offer.scrap_type,
            zone=scrap_offer.zone,
            weight=scrap_offer.weight,
            supplier=scrap_offer.supplier,
            supplier_price=scrap_offer.supplier_price,
            last_month_price=scrap_offer.last_month_price,
            override_price=scrap_offer.override_price,
            price_with_delta=scrap_offer.price_with_delta,
            recommendation=scrap_offer.recommendation,
            base_delta_rules=", ".join(str(el + 1) for el in scrap_offer.base_delta_rules),
            scrap_purchased=scrap_offer.scrap_purchased,
            note=scrap_offer.note,
            generated_from=scrap_offer.generated_from,
            station=scrap_offer.station,
            frozen=scrap_offer.frozen,
            last_month_price_added_manually=scrap_offer.last_month_price_added_manually,
        )
        for scrap_offer in scrap_offer_data
    )
