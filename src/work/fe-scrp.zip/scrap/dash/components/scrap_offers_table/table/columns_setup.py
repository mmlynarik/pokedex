from typing import Dict, List, Optional, Union


def get_hidden_col_def(field: str) -> Dict[str, str]:
    return {
        "colId": field.replace(
            "_",
            "-",
        ),
        "field": field,
        "hide": True,
    }


def get_icon_col_def(
    field: str,
    title: str = "",
    sortable: bool = True,
    replace: Optional[str] = None,
    width: int = 80,
) -> Dict[str, str]:
    column = {
        "headerName": title,
        "colId": field.replace(
            "_",
            "-",
        ),
        "field": field,
        "sortable": sortable,
        "suppressMovable": True,
        "width": width,
        "cellStyle": {
            "cursor": "pointer",
            "text-align": "center",
        },
    }

    if replace is not None:
        column["valueFormatter"] = {"function": replace}
    return column


def get_text_col_def(
    field: str,
    title: str = "",
    sortable: bool = True,
    filter: bool = True,
    edditable: Union[
        bool,
        str,
    ] = False,
    replace_empty_with: Optional[str] = None,
    replace: Optional[str] = None,
    width: Optional[int] = None,
) -> Dict[str, str]:
    column = {
        "headerName": title,
        "colId": field.replace(
            "_",
            "-",
        ),
        "field": field,
        "editable": (
            edditable
            if isinstance(
                edditable,
                bool,
            )
            else {"function": edditable}
        ),
        "sortable": sortable,
        "filterParams": {
            "buttons": ["reset"],
        },
        "suppressMovable": True,
    }

    if filter:
        column["filter"] = "agTextColumnFilter"

    if width is not None:
        column["width"] = width

    value_formater = "params.value"
    if replace is not None:
        value_formater = replace

    if replace_empty_with is not None:
        value_formater = f"params.value == null ? '{replace_empty_with}' : {value_formater}"

    column["valueFormatter"] = {"function": value_formater}
    return column


def get_number_col_def(
    field: str,
    title: str = "",
    sortable: bool = True,
    filter: bool = True,
    edditable: Union[
        bool,
        str,
    ] = False,
    number_format: Optional[str] = None,
    unit: Optional[str] = None,
    replace_empty: Optional[str] = None,
    replace: Optional[str] = None,
    width: Optional[int] = None,
    hidden: Optional[bool] = False,
) -> Dict[str, str]:
    column = {
        "headerName": title,
        "colId": field.replace(
            "_",
            "-",
        ),
        "field": field,
        "editable": (
            edditable
            if isinstance(
                edditable,
                bool,
            )
            else {"function": edditable}
        ),
        "sortable": sortable,
        "filterParams": {
            "buttons": ["reset"],
        },
        "suppressMovable": True,
        "hide": hidden,
    }

    if filter:
        column["filter"] = "agNumberColumnFilter"

    if width is not None:
        column["width"] = width

    value_formater = "params.value"
    if number_format is not None:
        value_formater = f"d3.format('{number_format}')(params.value)"

    if unit is not None:
        value_formater += f"+ ' {unit}'"

    if replace_empty is not None:
        value_formater = f"params.value == null ? '{replace_empty}' : {value_formater}"
    elif replace is not None:
        value_formater = replace

    if value_formater != "params.value":
        column["valueFormatter"] = {"function": value_formater}
    return column


def get_scrap_offers_table_columns(
    uuid_cell: str,
    edit_cell: str,
    freeze_cell: str,
    plot_cell: str,
    buy_cell: str,
) -> List[
    Dict[
        str,
        str,
    ]
]:
    return [
        get_hidden_col_def(uuid_cell),
        get_hidden_col_def("scrap_offer_pk"),
        get_hidden_col_def("last_month_price_added_manually"),
        get_hidden_col_def("scrap_purchased"),
        get_icon_col_def(
            edit_cell,
            replace="params.data.scrap_purchased ? '🔏' : '✒️'",
        ),
        get_icon_col_def(
            freeze_cell,
            title="Zmrazené",
            replace="params.value ? '🧊' : '💧'",
            width=140,
        ),
        get_icon_col_def(
            "generated_from",
            replace="params.value == null ? '' : '↖️'",
            sortable=False,
        ),
        get_text_col_def(
            "scrap_type",
            title="Typ šrotu",
            width=160,
        ),
        get_text_col_def(
            "zone",
            title="Zóna",
            width=120,
        ),
        get_text_col_def(
            "supplier",
            title="Dodávateľ",
        ),
        get_text_col_def(
            "station",
            title="Stanica",
        ),
        get_number_col_def(
            "weight",
            title="Objem",
            number_format=",.3f",
            unit="t",
            replace_empty="-",
        ),
        get_number_col_def(
            "supplier_price",
            title="Ich cena",
            number_format=".2f",
            unit="€",
        ),
        get_number_col_def(
            "last_month_price",
            title="Cena minulý mesiac",
            edditable=True,
            number_format=".2f",
            unit="€",
            replace_empty="-",
        ),
        get_number_col_def(
            "override_price",
            title="Cena (prepísaná)",
            number_format=".2f",
            unit="€",
            replace_empty="-",
            hidden=True,
        ),
        get_number_col_def(
            "price_with_delta",
            title="Cena minulý mesiac + Delta (Naša cena)",
            number_format=".2f",
            unit="€",
            replace_empty="-",
        ),
        get_number_col_def(
            "recommendation",
            title="Odporúčanie",
            number_format=".2f",
        ),
        get_text_col_def(
            "note",
            title="Poznámka",
        ),
        get_icon_col_def(
            plot_cell,
            replace="'📈'",
            sortable=False,
        ),
        get_text_col_def(
            "base_delta_rules",
            title="Delta pravidlá",
            filter="agNumberColumnFilter",
            width=160,
        ),
        get_text_col_def(
            buy_cell,
            replace="params.data.scrap_purchased ? '-' : 'Kupiť'",
            filter=False,
            sortable=False,
            width=100,
        ),
    ]
