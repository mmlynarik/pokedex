from typing import Any, Dict, Tuple

import attr
import dash_ag_grid as ag
import dash_bootstrap_components as dbc
import dash_mantine_components as dmc
import plotly.graph_objs as go
import ussksdc as sdc
from dash import dcc, html
from dash_iconify import DashIconify
from plotly.subplots import make_subplots
from ussksdc.components.data_store import DataStoreStrViewModel

from scrap.dash.components.common import ScrapPurchaseAppSource
from scrap.dash.components.scrap_offers_table.computations import compute_price_plot_data
from scrap.dash.components.scrap_offers_table.freeze_offer_btn import FreezeUnfreezeButtonVM
from scrap.dash.components.scrap_offers_table.modal import (
    BuyScrapOfferModalViewModel,
    EditScrapOfferModalViewModel,
)
from scrap.dash.components.scrap_offers_table.table.columns_setup import get_scrap_offers_table_columns
from scrap.dash.components.scrap_offers_table.table.datasource import (
    ScrapOffersTableRowVM,
    convert_scrap_offer_table_data,
)
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig


@attr.frozen
class ScrapOffersTableVM:
    TABLE_ID = "table"
    TABLE_HEADER_ID = "table-header"

    UUID_CELL = "uuid"
    BUY_CELL = "purchase"
    EDIT_OFFER_CELL = "edit_offer"
    PRICE_PLOT_CELL = "show_price_plot"
    FREEZE_CELL = "frozen"

    CONTROL_BTNS_ID = "control-btns"
    SCRAP_PRICE_PLOT_SECTION_ID = "scrap-plot-wrapper"
    SCRAP_PRICE_PLOT_ID = "scrap-plot"
    SCRAP_PRICE_PLOT_HIDE_BUTTON_ID = "hide"
    ADD_OFFER_BUTTON_ID = "add"

    SCRAP_PRICE_PLOT_HIDE = "Skryť graf"

    ADD_OFFER_BUTTON = "Pridať ponuku"

    buy_modal: BuyScrapOfferModalViewModel = sdc.child_component(
        "buy-offer-modal",
        default=BuyScrapOfferModalViewModel(),
    )

    edit_modal: EditScrapOfferModalViewModel = sdc.child_component(
        "edit-scrap-modal",
        default=EditScrapOfferModalViewModel(),
    )
    freeze_unfreeze_button: FreezeUnfreezeButtonVM = sdc.child_component(
        "freeze-unfreeze",
        factory=FreezeUnfreezeButtonVM,
    )
    temp = sdc.only_state_binding(
        TABLE_ID,
        "filterModel",
        default={},
    )

    plot_hidden: bool = sdc.one_way_binding(
        SCRAP_PRICE_PLOT_SECTION_ID,
        "hidden",
        default=True,
    )
    scrap_type_to_plot: DataStoreStrViewModel = sdc.child_component(
        "scrap-type-to-plot",
        default=DataStoreStrViewModel(),
    )
    data: Any = sdc.only_state_binding(
        TABLE_ID,
        "rowData",
        default=[],
    )
    filtered_data = sdc.only_state_binding(
        TABLE_ID,
        "virtualRowData",
        default=[],
    )

    @classmethod
    def get_output_fields(
        cls,
    ) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.TABLE_ID,
                "rowData",
                cls.get_scrap_offers_table_data,
            ),
            sdc.OutputField(
                cls.SCRAP_PRICE_PLOT_ID,
                "figure",
                cls.update_price_plot_figure,
            ),
        )

    @classmethod
    def get_input_fields(
        cls,
    ) -> sdc.InputFields:
        return (
            sdc.InputField(
                cls.TABLE_ID,
                "rowData",
                cls.update_scrap_offers_table,
            ),
            sdc.InputField(
                cls.TABLE_ID,
                "cellDoubleClicked",
                cls.click_on_scrap_offer_table,
            ),
            sdc.InputField(
                cls.SCRAP_PRICE_PLOT_HIDE_BUTTON_ID,
                "n_clicks",
                cls.hide_plot,
            ),
            sdc.InputField(
                cls.ADD_OFFER_BUTTON_ID,
                "n_clicks",
                cls.add_new_offer,
            ),
        )

    @classmethod
    def get_layout(
        cls,
        parent_id: str,
        config: ScrapPurchaseAppConfig,
    ):
        return html.Div(
            children=[
                html.Div(
                    children=[
                        html.P("Prehľad ponúk"),
                        dmc.Button(
                            cls.ADD_OFFER_BUTTON,
                            id=sdc.create_id(
                                parent_id,
                                cls.ADD_OFFER_BUTTON_ID,
                            ),
                            variant="subtle",
                            color="green.6",
                            leftIcon=DashIconify(icon="ic:baseline-add"),
                            disabled=config.read_only,
                        ),
                    ],
                    id=sdc.create_id(
                        parent_id,
                        cls.TABLE_HEADER_ID,
                    ),
                ),
                ag.AgGrid(
                    id=sdc.create_id(
                        parent_id,
                        cls.TABLE_ID,
                    ),
                    columnDefs=get_scrap_offers_table_columns(
                        cls.UUID_CELL,
                        cls.EDIT_OFFER_CELL,
                        cls.FREEZE_CELL,
                        cls.PRICE_PLOT_CELL,
                        cls.BUY_CELL,
                    ),
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={
                        "pagination": True,
                        "paginationAutoPageSize": True,
                    },
                    defaultColDef={
                        "wrapHeaderText": True,
                        "autoHeaderHeight": True,
                        "floatingFilter": False,
                    },
                ),
                html.Div(
                    children=[
                        sdc.get_child_layout(
                            parent_id,
                            child_component=cls.freeze_unfreeze_button,
                            config=config,
                        ),
                        html.Span(className="verticalLine"),
                    ],
                    id=sdc.create_id(
                        parent_id,
                        cls.CONTROL_BTNS_ID,
                    ),
                    hidden=config.read_only,
                ),
                html.Div(
                    id=sdc.create_id(
                        parent_id,
                        cls.SCRAP_PRICE_PLOT_SECTION_ID,
                    ),
                    children=[
                        dcc.Graph(
                            id=sdc.create_id(
                                parent_id,
                                cls.SCRAP_PRICE_PLOT_ID,
                            ),
                        ),
                        dbc.Button(
                            cls.SCRAP_PRICE_PLOT_HIDE,
                            id=sdc.create_id(
                                parent_id,
                                cls.SCRAP_PRICE_PLOT_HIDE_BUTTON_ID,
                            ),
                            color="primary",
                            n_clicks=0,
                        ),
                    ],
                ),
                sdc.get_child_layout(
                    parent_id,
                    cls.scrap_type_to_plot,
                ),
                sdc.get_child_layout(
                    parent_id,
                    cls.buy_modal,
                ),
                sdc.get_child_layout(
                    parent_id,
                    cls.edit_modal,
                ),
            ]
        )

    @property
    def scrap_to_plot(
        self,
    ) -> str:
        return self.scrap_type_to_plot.data

    @property
    def filtered_offer_ids(
        self,
    ) -> Tuple[
        str,
        ...,
    ]:
        return tuple(row.get(self.UUID_CELL) for row in self.filtered_data)

    def add_new_offer(
        self,
        _: int,
        ctx: ScrapPurchaseAppSource,
    ):
        new_offer_idx = ctx.db_purchase_data_source.add_new_scrap_offer()
        return attr.evolve(
            self,
            edit_modal=self.edit_modal.set_input_values_and_open(
                scrap_type=None,
                zone=None,
                supplier=None,
                station=None,
                weight=None,
                price=None,
                note=None,
                offer_id=new_offer_idx,
                last_month_price=None,
                last_month_price_added_manually=True,
                scrap_purchase_pk=-1,
            ),
        )

    def get_scrap_offers_table_data(
        self,
        ctx: ScrapPurchaseAppSource,
    ) -> Tuple:
        return tuple(
            scrap_offer_row.table_row
            for scrap_offer_row in convert_scrap_offer_table_data(
                ctx.db_purchase_data_source.get_scrap_offer_data()
            )
        )

    def update_scrap_offers_table(
        self,
        data,
        ctx: ScrapPurchaseAppSource,
    ) -> Tuple:
        return self

    def click_on_scrap_offer_table(
        self,
        active_cell: Dict,
        ctx: ScrapPurchaseAppSource,
    ) -> "ScrapOffersTableVM":
        selected_col = active_cell["colId"].replace(
            "-",
            "_",
        )
        rowData = ScrapOffersTableRowVM(**self.data[int(active_cell["rowId"])])

        if selected_col == self.BUY_CELL:
            info = " ".join(
                [
                    rowData.scrap_type if rowData.scrap_type is not None else "",
                    rowData.zone if rowData.zone is not None else "",
                    rowData.supplier if rowData.supplier is not None else "",
                    str(rowData.weight if rowData.weight is not None else ""),
                    "ton",
                ]
            )
            uuid = rowData.uuid
            return attr.evolve(
                self,
                buy_modal=self.buy_modal.set_input_values_and_open(
                    (
                        rowData.override_price
                        if rowData.override_price is not None
                        else rowData.price_with_delta
                    ),
                    info,
                    uuid=uuid,
                ),
            )
        elif selected_col == self.EDIT_OFFER_CELL:
            return attr.evolve(
                self,
                edit_modal=self.edit_modal.set_input_values_and_open(
                    scrap_type=rowData.scrap_type,
                    zone=rowData.zone,
                    supplier=rowData.supplier,
                    station=rowData.station,
                    weight=rowData.weight if rowData.weight is not None else 0.0,
                    price=rowData.supplier_price if rowData.supplier_price is not None else 0.0,
                    last_month_price=rowData.last_month_price,
                    note=rowData.note,
                    offer_id=rowData.uuid,
                    last_month_price_added_manually=rowData.last_month_price_added_manually,
                    scrap_purchase_pk=rowData.scrap_offer_pk,
                ),
            )
        elif selected_col == self.PRICE_PLOT_CELL and rowData.scrap_type is not None:
            return attr.evolve(
                self,
                plot_hidden=False,
                scrap_type_to_plot=DataStoreStrViewModel(rowData.scrap_type),
            )
        elif selected_col == self.FREEZE_CELL:
            ctx.db_purchase_data_source.freeze_unfreeze_scrap_offer(rowData.uuid)
        return self

    def hide_plot(
        self,
        _: int,
    ) -> "ScrapOffersTableVM":
        return attr.evolve(
            self,
            plot_hidden=True,
        )

    def update_price_plot_figure(
        self,
    ):
        if not self.scrap_to_plot:
            return go.Figure()
        price_plot_data = compute_price_plot_data(self.scrap_to_plot)

        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig.update_layout(
            title_text=f"{self.scrap_to_plot}",
        )
        fig.update_xaxes(
            title_text="Dátum",
            showspikes=True,
        )
        fig.update_yaxes(
            title_text="Cena",
            secondary_y=True,
            showspikes=True,
        )

        for (
            price_history_zone,
            price_history,
        ) in price_plot_data.price_plot_values.items():
            date_list = price_history.date_list
            hover_label_list = price_history.hover_label_list
            weighted_price_list = price_history.weighted_price_list

            if date_list:
                fig.add_trace(
                    go.Scatter(
                        x=date_list,
                        y=weighted_price_list,
                        name=f"Zóna {price_history_zone}",
                        text=hover_label_list,
                        hoverinfo="text",
                    ),
                    secondary_y=True,
                )
                max_date = max(date_list)
                min_date = min(date_list)
                nr_of_months = (max_date.year - min_date.year) * 12 + (max_date.month - min_date.month)
                fig.update_xaxes(
                    {
                        "nticks": nr_of_months,
                        "range": [
                            min_date,
                            max_date,
                        ],
                    }
                )
            fig.update_traces(showlegend=True)
        return fig
