from typing import Dict, Optional, Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import dcc, html
from scrap_core import ScrapType
from ussksdc.components.data_store import DataStoreStrViewModel

from scrap.dash.components.common import ScrapPurchaseAppSource
from scrap.dash.components.modals import (
    create_input_wrapper,
    create_modal_footer,
    create_modal_footer_with_delete_button,
    create_modal_label_header,
)
from scrap.dash.components.scrap_offers_table.computations import (
    convert_input_string_to_positive_float_or_none,
    get_scrap_type_dropdown_options,
    update_realized_scrap_offer_data,
    update_scrap_offers_after_purchase,
)
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig


@attr.s(frozen=True, slots=True)
class BuyScrapOfferModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    NAME_ID = "name"
    COMPONENT_ID = "buy"
    CLOSE_BUTTON_ID = "close"
    CONFIRM_BUTTON_ID = "confirm"
    PRICE_ID = "price"
    AMOUNT_ID = "amount"
    INFO_ID = "info"
    SCRAP_ID = "scrap"
    # User friendly msg
    NAME = "Nákup šrotu"
    PRICE = "Cena"
    AMOUNT = "Množstvo (ton)"
    CONFIRM_BUTTON = "Kúpiť"

    price: float = sdc.two_way_binding(
        PRICE_ID, "value", default=0.0, converter=convert_input_string_to_positive_float_or_none
    )
    amount: float = sdc.two_way_binding(
        AMOUNT_ID, "value", default=0.0, converter=convert_input_string_to_positive_float_or_none
    )
    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    info: str = sdc.one_way_binding(INFO_ID, "children", default="")
    uuid: DataStoreStrViewModel = sdc.child_component(SCRAP_ID, default=DataStoreStrViewModel())

    @classmethod
    def get_output_fields(cls, config: ScrapPurchaseAppConfig) -> sdc.OutputFields:
        return (sdc.OutputField(cls.CONFIRM_BUTTON_ID, "disabled", cls.disable_buy_scrap_button),)

    @classmethod
    def get_input_fields(cls, config: ScrapPurchaseAppConfig) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", cls.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", cls.confirm_scrap_purchase),
        )

    @classmethod
    def get_layout(cls, parent_id: str):
        return html.Div(
            children=[
                dbc.Modal(
                    backdrop="static",
                    children=[
                        create_modal_label_header(cls.NAME, sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID)),
                        dbc.ModalBody(
                            children=[
                                dbc.Label(id=sdc.create_id(parent_id, cls.INFO_ID)),
                                create_input_wrapper(
                                    cls.AMOUNT,
                                    (
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.AMOUNT_ID),
                                            type="number",
                                            debounce=True,
                                        ),
                                    ),
                                ),
                                create_input_wrapper(
                                    cls.PRICE,
                                    (
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.PRICE_ID),
                                            type="number",
                                            debounce=True,
                                        ),
                                    ),
                                ),
                                sdc.get_child_layout(parent_id, cls.uuid),
                            ]
                        ),
                        create_modal_footer(
                            sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), cls.CONFIRM_BUTTON
                        ),
                    ],
                    centered=True,
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                ),
            ]
        )

    def disable_buy_scrap_button(self, ctx: ScrapPurchaseAppSource) -> bool:
        if self.amount and self.price:
            if self.amount > 0 and self.price > 0:
                return False
        return True

    def confirm_scrap_purchase(self, _: int, ctx: ScrapPurchaseAppSource) -> "BuyScrapOfferModalViewModel":
        (
            updated_scrap_offer_data,
            additional_scrap_offer_uuid,
            scrap_offer_to_buy,
        ) = update_scrap_offers_after_purchase(
            ctx.db_purchase_data_source.get_scrap_offer_data(), self.offer_uuid, self.amount
        )
        scrap_offer_uuid_list = [self.offer_uuid]
        if additional_scrap_offer_uuid:
            scrap_offer_uuid_list.append(additional_scrap_offer_uuid)
        updated_realized_offer_data = update_realized_scrap_offer_data(
            ctx.db_purchase_data_source.get_realized_scrap_offer_data(),
            scrap_offer_to_buy,
            scrap_offer_uuid_list,
            self.amount,
            self.price,
        )
        ctx.db_purchase_data_source.update_scrap_offer_data_and_realized_scrap_offer_data(
            updated_scrap_offer_data, updated_realized_offer_data
        )
        return attr.evolve(self, is_open=False)

    def set_input_values_and_open(
        self, base_price: float, info: str, uuid: str
    ) -> "BuyScrapOfferModalViewModel":
        return attr.evolve(
            self, is_open=True, price=base_price, amount=0, info=info, uuid=DataStoreStrViewModel(uuid)
        )

    def close_modal(self, _: Optional[int] = None) -> "BuyScrapOfferModalViewModel":
        return attr.evolve(self, is_open=False)

    @property
    def offer_uuid(self):
        return self.uuid.data


@attr.s(frozen=True, slots=True)
class EditScrapOfferModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    NAME_ID = "name"
    COMPONENT_ID = "change"
    CLOSE_BUTTON_ID = "close"
    CONFIRM_BUTTON_ID = "confirm"
    DELETE_BUTTON_ID = "delete"
    SCRAP_TYPE_DROPDOWN_ID = "scrap-dropdown"
    ZONE_ID = "zone"
    SUPPLIER_ID = "supplier"
    STATION_ID = "station"
    WEIGHT_ID = "weight"
    PRICE_ID = "price"
    NOTE_ID = "note"
    REFRESH_ID = "refresh"
    LAST_MONTH_PRICE_ID = "last-month-price"
    SCRAP_OFFER_ID = "scrap-offer-id"
    # User friendly msg
    NAME = "Upraviť/vytvoriť ponuku"
    CONFIRM_BUTTON = "Uložiť"
    DELETE = "Zmazať ponuku"
    SCRAP_TYPE_DROPDOWN = "Typ šrotu"
    ZONE = "Zóna"
    SUPPLIER = "Dodávateľ"
    STATION = "Stanica"
    WEIGHT = "Objem"
    PRICE = "Ich cena"
    LAST_MONTH_PRICE = "Cena z minulého mesiaca"
    NOTE = "Poznámka"
    EMPTY_TYPE = "Vyberte typ"

    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    scrap_type: Optional[ScrapType] = sdc.two_way_binding(SCRAP_TYPE_DROPDOWN_ID, "value", default=None)
    zone: Optional[str] = sdc.two_way_binding(ZONE_ID, "value", default=None)
    supplier: Optional[str] = sdc.two_way_binding(SUPPLIER_ID, "value", default=None)
    station: Optional[str] = sdc.two_way_binding(STATION_ID, "value", default=None)
    weight: Optional[float] = sdc.two_way_binding(
        WEIGHT_ID, "value", converter=convert_input_string_to_positive_float_or_none, default=0.0
    )
    price: Optional[float] = sdc.two_way_binding(
        PRICE_ID, "value", converter=convert_input_string_to_positive_float_or_none, default=0.0
    )
    last_month_price: Optional[float] = sdc.two_way_binding(
        LAST_MONTH_PRICE_ID, "value", converter=convert_input_string_to_positive_float_or_none, default=0.0
    )
    lm_price_disabled: bool = sdc.one_way_binding(LAST_MONTH_PRICE_ID, "disabled", default=True)
    note: Optional[str] = sdc.two_way_binding(NOTE_ID, "value", default=None)
    offer_id: DataStoreStrViewModel = sdc.child_component("offer-id", default=DataStoreStrViewModel())
    scrap_purchase_pk: int = sdc.one_way_binding(SCRAP_OFFER_ID, "data", default=-1)

    @property
    def scrap_offer_id(self):
        return self.offer_id.data

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputField(cls.SUPPLIER_ID, "options", cls.get_supplier_options),)

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", cls.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", cls.save_offer),
            sdc.InputField(cls.DELETE_BUTTON_ID, "n_clicks", cls.delete_offer),
        )

    @classmethod
    def get_layout(cls, parent_id: str):
        return html.Div(
            children=[
                dbc.Modal(
                    children=[
                        create_modal_label_header(cls.NAME, sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID)),
                        dbc.ModalBody(
                            children=[
                                html.Div(
                                    [
                                        dbc.Label(cls.SCRAP_TYPE_DROPDOWN),
                                        dbc.Select(
                                            id=sdc.create_id(parent_id, cls.SCRAP_TYPE_DROPDOWN_ID),
                                            options=get_scrap_type_dropdown_options(),
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.ZONE),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.ZONE_ID),
                                            type="text",
                                            debounce=True,
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.SUPPLIER),
                                        dbc.Select(
                                            id=sdc.create_id(parent_id, cls.SUPPLIER_ID),
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.STATION),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.STATION_ID),
                                            type="text",
                                            debounce=True,
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.WEIGHT),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.WEIGHT_ID),
                                            type="number",
                                            min=0,
                                            debounce=True,
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.PRICE),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.PRICE_ID),
                                            type="number",
                                            min=0,
                                            debounce=True,
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.LAST_MONTH_PRICE),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.LAST_MONTH_PRICE_ID),
                                            type="number",
                                            min=0,
                                            debounce=True,
                                        ),
                                    ]
                                ),
                                html.Div(
                                    [
                                        dbc.Label(cls.NOTE),
                                        dbc.Input(
                                            id=sdc.create_id(parent_id, cls.NOTE_ID),
                                            type="text",
                                            debounce=True,
                                        ),
                                    ]
                                ),
                            ]
                        ),
                        create_modal_footer_with_delete_button(
                            sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID),
                            cls.CONFIRM_BUTTON,
                            sdc.create_id(parent_id, cls.DELETE_BUTTON_ID),
                            cls.DELETE,
                        ),
                    ],
                    centered=True,
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.SCRAP_OFFER_ID)),
                sdc.get_child_layout(parent_id, cls.offer_id),
            ]
        )

    def get_supplier_options(self, ctx: ScrapPurchaseAppSource) -> Tuple[Dict[str, str], ...]:
        return tuple(
            {"label": supplier, "value": supplier} for supplier in ctx.db_purchase_data_source.get_suppliers()
        )

    def set_input_values_and_open(
        self,
        scrap_type: Optional[str],
        zone: Optional[str],
        supplier: Optional[str],
        station: Optional[str],
        weight: Optional[float],
        price: Optional[float],
        note: Optional[str],
        offer_id: Optional[str],
        last_month_price: Optional[float],
        last_month_price_added_manually: Optional[bool],
        scrap_purchase_pk: int,
    ) -> "EditScrapOfferModalViewModel":
        return attr.evolve(
            self,
            is_open=True,
            scrap_type=scrap_type,
            zone=zone,
            supplier=supplier,
            station=station,
            weight=weight,
            price=price,
            last_month_price=last_month_price,
            note=note,
            offer_id=DataStoreStrViewModel(offer_id),
            lm_price_disabled=not last_month_price_added_manually,
            scrap_purchase_pk=scrap_purchase_pk,
        )

    def close_modal(self, _: Optional[int] = None) -> "EditScrapOfferModalViewModel":
        return attr.evolve(self, is_open=False)

    def save_offer(self, _: int, ctx: ScrapPurchaseAppSource) -> "EditScrapOfferModalViewModel":
        scrap_purchase_pk = self.scrap_purchase_pk
        if not self.lm_price_disabled and self.scrap_purchase_pk == -1:
            scrap_purchase_pk = ctx.db_scrap_purchases.create(
                self.supplier, self.scrap_type, self.zone, self.last_month_price
            )
        if not self.lm_price_disabled and self.scrap_purchase_pk != -1:
            ctx.db_scrap_purchases.update(scrap_purchase_pk, price=self.last_month_price)
        ctx.db_purchase_data_source.update_scrap_offer(
            scrap_type=self.scrap_type,
            zone=self.zone,
            supplier=self.supplier,
            station=self.station,
            weight=self.weight,
            supplier_price=self.price,
            note=self.note,
            offer_id=self.scrap_offer_id,
            last_month_price=self.last_month_price,
            last_month_price_added_manually=not self.lm_price_disabled,
            scrap_purchase_pk=scrap_purchase_pk,
        )
        return self.close_modal()

    def delete_offer(self, _: int, ctx: ScrapPurchaseAppSource) -> "EditScrapOfferModalViewModel":
        ctx.db_purchase_data_source.delete_scrap_offer(self.scrap_offer_id)
        return self.close_modal()
