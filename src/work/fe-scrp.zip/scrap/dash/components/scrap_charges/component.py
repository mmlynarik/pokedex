from typing import Self, Tuple

import ussksdc as sdc
from attr import frozen
from dash import html

from scrap.dash.components.protocols.scrap_loading_station import (
    LoadingStationModels,
    ScrapLoadingStationConfig,
)
from scrap.dash.components.scrap_charge_table.table import ScrapChargesTableVM
from scrap.dash.components.scrap_charges.model.basket_waggon_weight.component import (
    BasketWaggonWeightDataVM,
)
from scrap.dash.components.scrap_charges.model.basket_weight.component import (
    BasketWeightDataVM,
)
from scrap.dash.components.scrap_charges.model.grade_definitions.component import (
    GradeDefinitionsDataVM,
)
from scrap.dash.components.scrap_charges.model.scale_state.component import (
    ScaleCurrentStateVM,
)
from scrap.dash.components.scrap_charges.model.scrap_charge.component import (
    ScrapChargesDataVM,
)
from scrap.dash.components.scrap_charges.model.weighted_scrap.component import (
    WeightedScrapDataVM,
)


@frozen
class ScrapChargesVM:
    ID = "scrap-charge-container"

    data: ScrapChargesDataVM = sdc.child_component("data", factory=ScrapChargesDataVM)
    grade_definition_data: GradeDefinitionsDataVM = sdc.child_component(
        "grade-definition-data", factory=GradeDefinitionsDataVM
    )
    weighted_scrap_data: WeightedScrapDataVM = sdc.child_component(
        "weighted-scrap", factory=WeightedScrapDataVM
    )
    basket_weights: BasketWeightDataVM = sdc.child_component("basket-weights", factory=BasketWeightDataVM)
    basket_waggon_weights: BasketWaggonWeightDataVM = sdc.child_component(
        "basket-waggon-weights", factory=BasketWaggonWeightDataVM
    )
    scale_current_state: ScaleCurrentStateVM = sdc.child_component("scale-state", factory=ScaleCurrentStateVM)
    table: ScrapChargesTableVM = sdc.child_component("scrap-charge", factory=ScrapChargesTableVM)

    @classmethod
    def create(cls, models: LoadingStationModels, host: str, port: int, scale_ids: Tuple[str, ...]) -> Self:
        scrap_charges = models.scrap_charges.get_all()
        return cls(
            data=ScrapChargesDataVM(
                data_to_sync=ScrapChargesDataVM.convert_new_data_to_crud_model_msg(scrap_charges)
            ),
            grade_definition_data=GradeDefinitionsDataVM(
                data_to_sync=GradeDefinitionsDataVM.convert_new_data_to_crud_model_msg(
                    models.grade_definitions.get_all()
                )
            ),
            basket_weights=BasketWeightDataVM(
                data_to_sync=BasketWeightDataVM.convert_new_data_to_crud_model_msg(
                    models.basket_weight.get_all()
                )
            ),
            basket_waggon_weights=BasketWaggonWeightDataVM(
                data_to_sync=BasketWaggonWeightDataVM.convert_new_data_to_crud_model_msg(
                    models.basket_waggon_weight.get_all()
                )
            ),
            weighted_scrap_data=WeightedScrapDataVM(
                data_to_sync=WeightedScrapDataVM.initial_convert_new_data_to_crud_model_msg(
                    [[sc.pk, models.weighted_scrap(sc.pk).get_all()] for sc in scrap_charges]
                )
            ),
            scale_current_state=ScaleCurrentStateVM(
                data_to_sync=ScaleCurrentStateVM.convert_new_data_to_crud_model_msg(
                    models.scale_state.get_all()
                )
            ),
            table=ScrapChargesTableVM.create(host, port, scale_ids),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.table, config),
                html.Div(
                    children=[
                        sdc.get_child_layout(parent_id, cls.data),
                        sdc.get_child_layout(parent_id, cls.grade_definition_data),
                        sdc.get_child_layout(parent_id, cls.weighted_scrap_data),
                        sdc.get_child_layout(parent_id, cls.basket_weights),
                        sdc.get_child_layout(parent_id, cls.basket_waggon_weights),
                        sdc.get_child_layout(parent_id, cls.scale_current_state),
                    ],
                ),
            ],
            id=sdc.create_id(parent_id, cls.ID),
        )
