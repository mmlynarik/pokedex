import logging
from typing import Any, Collection, Optional, Protocol

from scrap.models import Basket
from ussksdc.core.datamodel import CRUDModel

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class BasketWeightDatasource(CRUDModel[Basket, int], Protocol):
    def get_basket_weight_by_basket_id(self, basket_id: int) -> Optional[Basket]: ...


class BasketWeightDb:
    MODEL_DOES_NOT_EXIST_MSG = "Basket weight with %s=%d does not exist."

    def get_all(self) -> Collection[Basket]:
        return tuple(Basket.objects.all())

    def get(self, elem_id: int) -> Optional[Basket]:
        try:
            return Basket.objects.get(id=elem_id)
        except Basket.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, "id", elem_id)

    def get_basket_weight_by_basket_id(self, basket_id: int) -> Optional[Basket]:
        try:
            return Basket.objects.get(basket_id=basket_id)
        except Basket.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, "basket_id", basket_id)

    def create(self, new_data: Basket) -> int:
        new_data.save()
        return new_data.id

    def update(self, elem_id: int, **changes: Any) -> Optional[Basket]:
        basket_weight = self.get(elem_id)
        if basket_weight is None:
            return None

        for key, value in changes.items():
            basket_weight.__setattr__(key, value)

        basket_weight.save()
        return basket_weight

    def delete(self, elem_id: int) -> None:
        raise Basket.objects.get(id=elem_id).delete()
