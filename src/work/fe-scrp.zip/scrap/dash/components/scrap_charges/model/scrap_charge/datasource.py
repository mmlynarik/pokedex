import logging
from datetime import datetime
from typing import Any, Optional, Tuple

import attr

from scrap_core.datamodel import RawFeChem
from ussksdc.core.datamodel import CRUDModel

from scrap.dash.components.scrap_charges.model.scrap_charge.datamodel import from_unix_timestamp
from scrap.dash.database_api import db_iars, steel_grades
from scrap.models import LoadingStation, ScrapCharge
from scrap.utils import get_pig_iron_s_for_grade
from scrap_core.optimization.datamodel import HeatPlan

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())

GRADE_ID_FIELD = "grade_id"
BASKET_FIELD = "basket_ids"
CLOSED_AT = "closed_at"
SWITCHED_BASKET_FIELD = "switched_baskets"
RAW_FE_CHEM_TABLE = "raw_fe_chem"


class ScrapChargesDatasource(CRUDModel[ScrapCharge, int]): ...


class ScrapChargesDb:
    MODEL_DOES_NOT_EXIST_MSG = "Loading station with id=%d does not exist."

    def __init__(self, loading_station_id: int, steelshop: Optional[int], logged_user: str) -> None:
        self.loading_station = LoadingStation.objects.get(id=loading_station_id)
        self.steelshop = steelshop
        self.logged_user = logged_user

    def get_all(self) -> Tuple[ScrapCharge, ...]:
        return tuple(self.loading_station.scrapcharge_set.filter(closed_at=None))

    def get(self, elem_id: int) -> Optional[ScrapCharge]:
        scrap_charges = self.loading_station.scrapcharge_set.filter(pk=elem_id)
        if not scrap_charges:
            return None
        return scrap_charges[0]

    def create(self, new_data: ScrapCharge) -> int:
        heat_plan = None
        if self.steelshop is None:
            log.info(
                f"Loading station with ID {self.loading_station_id} "
                f"has empty 'steelshop' attribute, so heat plan is not available."
            )
        else:
            # 128 is arbitrary, but large enough bound,
            # to make sure to read all available heats for next 3-4 days
            expected_heats = db_iars.get_next_planned_heats(steelshop=self.steelshop, num_of_heats=128)
            if expected_heats is None:
                heat_plan = None
            else:
                heat_plan = HeatPlan(int(datetime.utcnow().timestamp()), expected_heats)

        new_data.loading_station = self.loading_station
        new_data.heat_plan = heat_plan

        new_data.save()
        return new_data.id

    def update(self, elem_id: int, **changes: Any) -> Optional[ScrapCharge]:
        scrap_charge = self.get(elem_id)
        if scrap_charge is None:
            return None

        for key, value in changes.items():
            if key == BASKET_FIELD:
                scrap_charge.update_basket_ids(value)
                # many-to-many
                continue

            if key == SWITCHED_BASKET_FIELD:
                scrap_charge.update_switched_basket_ids(value)
                # many-to-many
                continue

            if key == RAW_FE_CHEM_TABLE:
                scrap_charge.raw_fe_chem = RawFeChem(**value)
                # json-field
                continue

            if key == CLOSED_AT:
                scrap_charge.closed_at = from_unix_timestamp(value)
                continue

            if key == GRADE_ID_FIELD:
                # change pig iron chem based on selected grade
                scrap_charge.raw_fe_chem = attr.evolve(
                    scrap_charge.raw_fe_chem, S=get_pig_iron_s_for_grade(steel_grades, value)
                )

            scrap_charge.__setattr__(key, value)

        scrap_charge.save()
        return scrap_charge

    def delete(self, elem_id: int) -> None:
        ScrapCharge.objects.get(id=elem_id).delete()
