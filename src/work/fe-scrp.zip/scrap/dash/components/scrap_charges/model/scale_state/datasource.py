import logging
from typing import Any, Optional, Tuple

from ussksdc.core.datamodel import CRUDModel
from vsadzka.settings import SCALE_PER_STEELSHOP

from scrap.models import ScaleCurrentState

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class ScrapCurrentStateDatasource(CRUDModel[ScaleCurrentState, int]): ...


class ScrapCurrentStateDb:
    MODEL_DOES_NOT_EXIST_MSG = "Scale current state with id=%d does not exist."

    def __init__(self, steelshop: int) -> None:
        self.scale_ids = SCALE_PER_STEELSHOP[steelshop]

    def get_all(self) -> Tuple[ScaleCurrentState, ...]:
        return tuple(ScaleCurrentState.objects.filter(scale_id__in=self.scale_ids))

    def get(self, elem_id: int) -> Optional[ScaleCurrentState]:
        try:
            return ScaleCurrentState.objects.get(pk=elem_id)
        except ScaleCurrentState.DoesNotExist:
            logger.exception(self.MODEL_DOES_NOT_EXIST_MSG, elem_id)
            return None

    def create(self, new_state: ScaleCurrentState) -> int:
        new_state.save()
        return new_state.pk

    def update(self, elem_id: int, **changes: Any) -> Optional[ScaleCurrentState]:
        current_state = self.get(elem_id)
        if current_state is None:
            return None

        for key, value in changes.items():
            current_state.__setattr__(key, value)

        current_state.save()
        return current_state

    def delete(self, elem_id: int) -> None:
        try:
            ScaleCurrentState.objects.get(id=elem_id).delete()
        except ScaleCurrentState.DoesNotExist:
            logger.exception(self.MODEL_DOES_NOT_EXIST_MSG, elem_id)
