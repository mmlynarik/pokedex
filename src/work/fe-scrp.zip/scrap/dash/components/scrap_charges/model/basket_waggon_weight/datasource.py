import logging
from typing import Any, Collection, Optional, Protocol

from scrap.models import BasketWaggonWeight
from ussksdc.core.datamodel import CRUDModel

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class BasketWaggonWeightDatasource(CRUDModel[BasketWaggonWeight, str], Protocol):
    def get_waggon_weight_by_scale_id(self, scale_id: str) -> Optional[BasketWaggonWeight]: ...


class BasketWaggonWeightDb:
    MODEL_DOES_NOT_EXIST_MSG = "Basket waggon weight for %s=%d does not exist."

    def get_all(self) -> Collection[BasketWaggonWeight]:
        return tuple(BasketWaggonWeight.objects.all())

    def get(self, elem_id: str) -> Optional[BasketWaggonWeight]:
        try:
            return BasketWaggonWeight.objects.get(scale_id=elem_id)
        except BasketWaggonWeight.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, "scale_id", elem_id)

    def get_waggon_weight_by_scale_id(self, scale_id: str) -> Optional[BasketWaggonWeight]:
        try:
            return BasketWaggonWeight.objects.get(scale_id=scale_id)
        except BasketWaggonWeight.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, "scale_id", scale_id)

    def create(self, new_data: BasketWaggonWeight) -> int:
        new_data.save()
        return new_data.scale_id

    def update(self, elem_id: str, **changes: Any) -> Optional[BasketWaggonWeight]:
        waggon_weight = self.get(elem_id)
        if waggon_weight is None:
            return None

        for key, value in changes.items():
            waggon_weight.__setattr__(key, value)

        waggon_weight.save()
        return waggon_weight

    def delete(self, elem_id: str) -> None:
        raise BasketWaggonWeight.objects.get(scale_id=elem_id).delete()
