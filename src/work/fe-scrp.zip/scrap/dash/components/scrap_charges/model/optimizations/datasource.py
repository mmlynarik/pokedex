import logging
from typing import Optional, Protocol, Sequence

from scrap.models import OptimizationInput, MultipleHeatsOptimizationResult, ScrapCharge

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class MultipleHeatsOptimizationDatasource(Protocol):
    def create(
        self, input_data: OptimizationInput, scrap_charge: ScrapCharge, warnings: Sequence[str]
    ) -> int: ...

    def get(self, elem_id: int) -> Optional[MultipleHeatsOptimizationResult]: ...


class MultipleHeatsOptimizationDb:
    MODEL_DOES_NOT_EXIST_MSG = "Multiple Heats Optimization Result with id=%d does not exist."

    def create(
        self, input_data: OptimizationInput, scrap_charge: ScrapCharge, warnings: Sequence[str]
    ) -> int:
        optimization = MultipleHeatsOptimizationResult(scrap_charge=scrap_charge, warnings=warnings)
        optimization.save()

        input_data.optimization_result = optimization
        input_data.save()

        return optimization.pk

    def get(self, elem_id: int) -> Optional[MultipleHeatsOptimizationResult]:
        try:
            optimization = MultipleHeatsOptimizationResult.objects.get(id=elem_id)
            return optimization
        except MultipleHeatsOptimizationResult.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, elem_id)
        return None
