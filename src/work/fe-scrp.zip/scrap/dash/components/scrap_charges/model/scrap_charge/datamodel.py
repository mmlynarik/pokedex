from datetime import datetime
from typing import Any, Dict, Optional, Tuple

import attr

from scrap.models import OptimizationDisplayDataV2, ScrapCharge, converter
from scrap.utils import from_milliseconds, to_milliseconds
from scrap_core.datamodel.model import RawFeChem
from scrap_core.optimization.datamodel import HeatPlan, ScrapMixLimits


def to_unix_timestamp(dt: Optional[datetime]) -> Optional[int]:
    if dt is None:
        return None
    return to_milliseconds(dt)


def from_unix_timestamp(timestamp: Optional[int]) -> Optional[datetime]:
    if timestamp is None:
        return None
    return from_milliseconds(timestamp)


@attr.frozen
class ScrapChargeDb:
    basket_ids: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    closed_at: Optional[int] = attr.ib(default=None, converter=to_unix_timestamp)
    grade_id: Optional[int] = attr.ib(default=None)
    heat_plan: Optional[HeatPlan] = attr.ib(default=None)
    is_wet: Optional[bool] = attr.ib(default=None)
    is_reserve: Optional[bool] = attr.ib(default=False)
    loading_station_id: int = attr.ib(default=-1, converter=int)
    optimizations: Tuple[OptimizationDisplayDataV2, ...] = attr.ib(default=(), converter=tuple)
    optimization_start_clicked: bool = attr.ib(default=False)
    pig_iron_weight: Optional[int] = attr.ib(default=None)
    raw_fe_chem: RawFeChem = attr.ib(default=RawFeChem())
    switched_baskets: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    scrap_limits: ScrapMixLimits = attr.ib(default=(), converter=tuple)
    total_scrap_weight: Optional[int] = attr.ib(default=None)
    operator_comment: Optional[str] = attr.ib(default=None)
    order_num: Optional[int] = attr.ib(default=None)

    @classmethod
    def parse(cls, scrap_charge: ScrapCharge) -> "ScrapChargeDb":
        return cls(
            basket_ids=scrap_charge.basket_basket_ids,
            closed_at=to_unix_timestamp(scrap_charge.closed_at),
            grade_id=scrap_charge.grade_id,
            heat_plan=scrap_charge.heat_plan,
            is_reserve=scrap_charge.is_reserve,
            is_wet=scrap_charge.is_wet,
            loading_station_id=scrap_charge.loading_station_id,
            # TODO Temporary usage of `OptimizationDisplayDataV2`. Find out what attributes are needed and forward them only
            optimizations=tuple(
                OptimizationDisplayDataV2.from_optimization_result(res)
                for res in scrap_charge.optimization_results.order_by("created_at")
            ),
            optimization_start_clicked=scrap_charge.optimization_start_clicked,
            pig_iron_weight=scrap_charge.pig_iron_weight,
            raw_fe_chem=scrap_charge.raw_fe_chem,
            switched_baskets=scrap_charge.switched_basket_ids,
            scrap_limits=scrap_charge.scrap_limits,
            total_scrap_weight=scrap_charge.total_scrap_weight,
            operator_comment=scrap_charge.operator_comment,
            order_num=scrap_charge.order_num,
        )

    @property
    def as_db_model(self) -> ScrapCharge:
        return ScrapCharge(
            loading_station_id=self.loading_station_id,
            closed_at=from_unix_timestamp(self.closed_at),
            grade_id=self.grade_id,
            total_scrap_weight=self.total_scrap_weight,
            pig_iron_weight=self.pig_iron_weight,
            optimization_start_clicked=self.optimization_start_clicked,
            heat_plan=self.heat_plan,
            raw_fe_chem=self.raw_fe_chem,
            scrap_limits=self.scrap_limits,
            optimizations=self.optimizations,
            is_wet=self.is_wet,
            is_reserve=self.is_reserve,
            operator_comment=self.operator_comment,
            order_num=self.order_num,
        )

    @property
    def serialize(self) -> Dict[str, Any]:
        return converter.unstructure(self)
