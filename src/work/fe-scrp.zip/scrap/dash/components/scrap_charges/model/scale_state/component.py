# This component will be generated from sdc core
# At this time is copied for every (data) model.
# TODO http://vdevops/Esten/UssAi/_workitems/edit/498
from typing import Any, List, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from django.forms.models import model_to_dict
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationCTX
from scrap.models import ScaleCurrentState


@attr.frozen
class ScaleCurrentStateVM:
    SYNC_DATA = "sync-data"
    UPDATE_DATA = "update-data"

    data_to_update: List[List[Any]] = sdc.only_state_binding(
        UPDATE_DATA,
        "data",
        default=[],
    )
    data_to_sync: List[List[Any]] = sdc.binding(
        SYNC_DATA,
        "data",
        ss_read=False,
        ss_state=False,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=[],
    )

    @classmethod
    def convert_new_data_to_crud_model_msg(
        cls, current_state: Tuple[ScaleCurrentState, ...]
    ) -> List[List[Any]]:
        return [[None, state.pk, model_to_dict(state)] for state in current_state]

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                dcc.Store(id=sdc.create_id(parent_id, cls.SYNC_DATA), storage_type="memory"),
                dcc.Store(id=sdc.create_id(parent_id, cls.UPDATE_DATA), storage_type="memory"),
            ]
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.SYNC_DATA, "modified_timestamp", *cls.apply_data_to_cache()),
            sdc.InputField(cls.UPDATE_DATA, "modified_timestamp", cls.update_data),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.UPDATE_DATA, "data", *cls.select_data_for_update()),)

    @classmethod
    def apply_data_to_cache(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "applyDataToCache",
            ["viewModel", "timestamp", "ctx"],
            """
            if (viewModel.data_to_sync.length)
                sdc.models.scaleState.apply(viewModel.data_to_sync);
            return viewModel;
            """,
        )

    @classmethod
    def select_data_for_update(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                function selectDataForUpdate(viewModel, ctx){
                    var request = Array();
                    if (ctx.models.scaleState.dump){
                        request = ctx.models.scaleState.localChanges;
                        ctx.models.scaleState.apply([]);
                    }if (ctx.models.scaleState.sync)
                        request.push([null, null, null]);

                    return request;
                }
                """
            ),
            "selectDataForUpdate",
        )

    def apply(self, changes: Any, ctx: ScrapLoadingStationCTX) -> List[List[Any]]:
        apply_changes = []
        for change in changes:
            old_id, new_id, obj = change
            if new_id is not None:
                # CREATE
                new_obj_id = ctx.models.scale_state.create(ScaleCurrentState(**obj))
                apply_changes.append([new_id, new_obj_id, None])
            if old_id is not None:
                if obj is not None:
                    # UPDATE
                    ctx.models.scale_state.update(int(old_id), **obj)
                else:
                    # DELETE
                    ctx.models.scale_state.delete(int(old_id))
            if new_id is None and old_id is None and obj is None:
                # SYNC
                apply_changes.extend(
                    self.convert_new_data_to_crud_model_msg(ctx.models.scale_state.get_all())
                )
        return apply_changes

    def update_data(self, _: int, ctx: ScrapLoadingStationCTX) -> "ScrapChargesDataVM":
        if not self.data_to_update:
            return self
        sync_data = self.apply(self.data_to_update, ctx)
        return attr.evolve(self, data_to_sync=sync_data)
