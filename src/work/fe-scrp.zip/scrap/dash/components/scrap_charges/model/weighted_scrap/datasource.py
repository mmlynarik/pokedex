import abc
import logging
from typing import Any, Collection, Optional, Tuple

from django.db import transaction
from ussksdc.core.datamodel import ConditionalCRUDModel, CRUDModel

from scrap.dash.components.scrap_charges.model.weighted_scrap.datamodel import (
    WeightedScrapModel,
)
from scrap.models import WeightedScrap
from scrap.scales import scale_processors
from scrap.utils import from_milliseconds, to_milliseconds
from vsadzka.settings import SCALE_PRECISION
from scalesingest.error import ScaleAPIError


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class WeightedScrapDatasource(CRUDModel[WeightedScrapModel, int]):
    @abc.abstractmethod
    def update_weight_with_scale_data(self) -> None: ...

    @abc.abstractmethod
    def get_switched_baskets(self) -> Collection[WeightedScrapModel]: ...

    @abc.abstractmethod
    def split(self, elem_id: int) -> bool: ...


class WeightedScrapDb:
    MODEL_DOES_NOT_EXIST_MSG = "Weighted scrap model with id=%d does not exist."

    def __init__(self, scrap_charge_id: int) -> None:
        self.scrap_charge_id = scrap_charge_id

    def get_all(self) -> Collection[WeightedScrapModel]:
        return tuple(
            map(WeightedScrapModel.parse, WeightedScrap.objects.filter(scrap_charge_id=self.scrap_charge_id))
        )

    def get(self, elem_id: int) -> Optional[WeightedScrap]:
        try:
            return WeightedScrap.objects.get(id=elem_id)
        except WeightedScrap.DoesNotExist:
            return None

    def create(self, new_data: WeightedScrapModel) -> int:
        ws = new_data.as_db_model()
        ws.save()
        return ws.pk

    def update(self, elem_id: int, **changes: Any) -> Optional[WeightedScrapModel]:
        weighted_scrap = self.get(elem_id)
        if weighted_scrap is None:
            return None

        for key, value in changes.items():
            weighted_scrap.__setattr__(key, value)

        weighted_scrap.save()
        return weighted_scrap

    def delete(self, elem_id: int) -> None:
        try:
            WeightedScrap.objects.get(id=elem_id).delete()
        except WeightedScrap.DoesNotExist:
            log.exception(self.MODEL_DOES_NOT_EXIST_MSG, elem_id)

    def update_weight_with_scale_data(self) -> None:
        for ws in WeightedScrap.objects.filter(scrap_charge_id=self.scrap_charge_id, end__isnull=True):
            try:
                ws.weight = scale_processors[ws.scale_id].get_current_relative_weight(ws.start)
                ws.save()
            except ScaleAPIError:
                log.exception(f"Can't update WeightedScrap {ws}")

    def get_switched_baskets(self) -> Tuple[WeightedScrapModel, ...]:
        return tuple(filter(lambda data: data.start == data.end, self.get_all()))

    def split(self, elem_id: int) -> bool:
        """
        Use case: The user forgot to switch to another type of scrap and it is necessary to fix it.
        This function obtains weighted scrap from db and splits the interval
        of measure into many small measurements, which can be modify.

        Keyword arguments:
        elem_id -- The id of weighted scrap in db.

        Return statment:
        bool - return True if weighted scrap was split else return False.
        """
        with transaction.atomic():
            ws = WeightedScrap.objects.get(id=elem_id)
            if ws.end is None:
                log.warning(f"Can't split weighted scrap {ws} - undefined end time")
                return False

            significant_steps = scale_processors[ws.scale_id].get_range_significant(
                to_milliseconds(ws.start), to_milliseconds(ws.end), SCALE_PRECISION
            )
            log.info(f"Interval [{ws.start}, {ws.end}] is composed of {significant_steps} significant steps")

            # if there is no significant step other than start and end,
            # then there is just trivial 1 element decomposition
            if len(significant_steps) <= 2:
                log.warning(f"Can't split weighted scrap {ws} - only trivial decomposition found")
                return False

            decomposition = [
                WeightedScrap(
                    start=from_milliseconds(prev.timestamp),
                    end=from_milliseconds(curr.timestamp),
                    scale_id=ws.scale_id,
                    weight=curr.weight - prev.weight,
                    scrap_charge=ws.scrap_charge,
                    scrap=ws.scrap,
                )
                for prev, curr in zip(significant_steps[:-1], significant_steps[1:])
            ]

            WeightedScrap.objects.bulk_create(decomposition)
            ws.delete()

        log.info(f"New {len(decomposition)} weighted scrap records created successfully")

        return True


class ConditionalWeightedScrapDatasource(ConditionalCRUDModel[CRUDModel[WeightedScrapModel, int], int]):
    @abc.abstractmethod
    def get_filtered_data(self, **kwargs: Any) -> CRUDModel[WeightedScrapModel, int]: ...


class ConditionalWeightedScrapDb:
    def get_filtered_data(self, **kwargs: Any) -> CRUDModel[WeightedScrapModel, int]:
        scrap_charge_id = kwargs.get("scrap_charge_id", None)
        if scrap_charge_id is None:
            raise ValueError("Argument scrap_charge_id is required for the get_filtered_data function.")

        return WeightedScrapDb(scrap_charge_id)
