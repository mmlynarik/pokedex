import logging
from datetime import date
from typing import Any, Collection, Optional

import attr
from scrap.dash.database_api import steel_grades
from ussksdc.core.datamodel import CRUDModel

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.frozen
class GradeDefinitionAttr:
    grade_id: int = attr.ib(converter=int)
    label: str = attr.ib()

    @classmethod
    def create_from_grade_id(cls, grade_id: int, when: date) -> "GradeDefinitionAttr":
        return GradeDefinitionAttr(grade_id=grade_id, label=steel_grades.get_display_name(grade_id, when))


class GradeDefinitionsDatasource(CRUDModel[GradeDefinitionAttr, int]): ...


class GradeDefinitionsDb:
    def get_all(self) -> Collection[GradeDefinitionAttr]:
        today = date.today()
        return (
            GradeDefinitionAttr.create_from_grade_id(grade_id, today)
            for grade_id in steel_grades.get_available_grade_ids(today)
        )

    def get(self, elem_id: int) -> Optional[GradeDefinitionAttr]:
        today = date.today()
        if steel_grades.grade_id_exists(elem_id, today):
            return GradeDefinitionAttr.create_from_grade_id(elem_id, today)
        return None

    def create(self, _: GradeDefinitionAttr) -> int:
        raise NotImplementedError("Can't use 'create' on the scrap definition")

    def update(self, _: str, **changes: Any) -> Optional[GradeDefinitionAttr]:
        raise NotImplementedError("Can't use 'update' on the scrap definition")

    def delete(self, _: str) -> None:
        raise NotImplementedError("Can't use 'delete' on the scrap definition")
