from datetime import datetime
from typing import Optional, Self

import attr

from scrap.models import WeightedScrap
from scrap.utils import from_milliseconds


@attr.frozen
class WeightedScrapModel:
    id: int = attr.ib()
    scale_id: str = attr.ib()
    scrap: str = attr.ib()
    start: int = attr.ib()
    scrap_charge_id: int = attr.ib()
    end: Optional[int] = attr.ib(default=None)
    weight: int = attr.ib(default=0)
    invalid_record: bool = attr.ib(default=False)

    @property
    def none_or_end_datetime(self) -> Optional[datetime]:
        if self.end <= 0:
            return None
        return from_milliseconds(self.end)

    @classmethod
    def parse(cls, ws: WeightedScrap) -> Self:
        return cls(
            id=ws.id,
            start=ws.start_timestamp,
            scale_id=ws.scale_id,
            scrap=ws.scrap,
            scrap_charge_id=ws.scrap_charge.id,
            weight=ws.weight,
            end=ws.end_timestamp_or_none,
            invalid_record=ws.invalid_record,
        )

    def as_db_model(self) -> WeightedScrap:
        return WeightedScrap(
            start=from_milliseconds(self.start),
            scale_id=self.scale_id,
            scrap=self.scrap,
            weight=self.weight,
            scrap_charge_id=self.scrap_charge_id,
            end=self.none_or_end_datetime,
            invalid_record=self.invalid_record,
        )
