import logging
import time
import uuid
from typing import Dict, List, Optional
from attrs import frozen, evolve
import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel

from scrap.dash.components.global_alert import Message
from scrap.tasks import calculate_optimal_scrap_purchase
from scrap.models import (
    converter,
    ScrapOfferData,
    ScrapPurchaseOptimizationInput,
    MEAN_DAILY_PRODUCTION_PER_STEELSHOP,
)
from scrap.dash.components.common import ScrapPurchaseAppSource
from scrap.dash.components.purchase_optimization_bar.datasource import (
    CachedOptimizationsDataSource,
    PurchaseOptimizations,
)
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig
import dash_bootstrap_components as dbc
from dash import html, dcc

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


def get_nr_of_offers_with_rules(scrap_offer_data: ScrapOfferData) -> int:
    scrap_offer_with_rules_nr = 0
    for scrap_offer in scrap_offer_data:
        if scrap_offer.base_delta_rules:
            scrap_offer_with_rules_nr = scrap_offer_with_rules_nr + 1
    return scrap_offer_with_rules_nr


class ScrapPurchaseAppError(Exception):
    """Generic exception for scrap purchase"""


@frozen
class PurchaseOptimizationVM:
    PROGRESS_BAR_ID = "not-applied"
    PROGRESS_BAR_DIV_ID = "optimization-div"
    BUTTON_ID = "start"
    APPLIED_DELTA_RULES_PROGRESS_BAR = "applied"
    OPTIMIZATION_REFRESH_INTERVAL_ID = "interval"
    OPTIMIZATION_START_TRIGGER_ID = "optimization-clicked"
    MESSAGE_CHANNEL_CS = "msg-channel-cs"
    MESSAGE_CHANNEL_SS = "msg-channel-ss"

    optimization_start_clicked_data: DataStoreViewModel = sdc.child_component(
        OPTIMIZATION_START_TRIGGER_ID,
        default=DataStoreViewModel(False),  # type: ignore
        converter=DataStoreViewModel.attr_converter(),
    )
    # error: Too many arguments for "DataStoreViewModel"

    data_load_time: DataStoreViewModel = sdc.child_component(
        "data-load-time",
        factory=time.time_ns,
        converter=DataStoreViewModel.attr_converter(),
    )
    message_channel_cs: List[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_CHANNEL_CS,
        "data",
        default=[],
    )
    messages_channel_ss: Dict[str, str] = sdc.binding(
        MESSAGE_CHANNEL_SS,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default={},
        converter=converter.unstructure,
    )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.APPLIED_DELTA_RULES_PROGRESS_BAR,
                "value",
                cls.update_applied_delta_rules_progress_bar_value,
            ),
            sdc.OutputField(
                cls.APPLIED_DELTA_RULES_PROGRESS_BAR,
                "children",
                cls.update_applied_delta_rules_progress_bar_children,
            ),
            sdc.OutputField(cls.PROGRESS_BAR_ID, "children", cls.update_optimization_progress_text),
            sdc.OutputField(cls.PROGRESS_BAR_ID, "value", cls.update_optimization_progress_value),
            sdc.OutputField(cls.PROGRESS_BAR_DIV_ID, "hidden", cls.update_optimization_progress_style),
            sdc.OutputField(cls.BUTTON_ID, "disabled", cls.disable_run_optimization_button),
            sdc.OutputField(
                cls.OPTIMIZATION_REFRESH_INTERVAL_ID, "disabled", cls.disable_optimization_refresh_interval
            ),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.BUTTON_ID, "n_clicks", cls.click_on_run_optimization_button),
            sdc.InputField(
                cls.OPTIMIZATION_REFRESH_INTERVAL_ID, "n_intervals", cls.optimization_refresh_data
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig):
        return html.Div(
            children=[
                dbc.Progress(
                    "",
                    value=0.0,
                    color="warning",
                    id=sdc.create_id(parent_id, cls.APPLIED_DELTA_RULES_PROGRESS_BAR),
                ),
                html.Div(
                    children=[
                        dbc.Button(
                            "Prepočítať",
                            className="mx-2",
                            disabled=True,
                            id=sdc.create_id(parent_id, cls.BUTTON_ID),
                            color="warning",
                        ),
                    ],
                    hidden=config.read_only,
                ),
                html.Div(
                    id=sdc.create_id(parent_id, cls.PROGRESS_BAR_DIV_ID),
                    hidden=True,
                    children=[
                        dbc.Progress(
                            "0%",
                            value=0.0,
                            id=sdc.create_id(parent_id, cls.PROGRESS_BAR_ID),
                            animated=True,
                        ),
                    ],
                ),
                dcc.Interval(
                    id=sdc.create_id(parent_id, cls.OPTIMIZATION_REFRESH_INTERVAL_ID),
                    interval=5000,
                    n_intervals=0,
                    disabled=True,
                ),
                sdc.get_child_layout(parent_id, cls.optimization_start_clicked_data),
                sdc.get_child_layout(parent_id, cls.data_load_time),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_CHANNEL_CS)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_CHANNEL_SS)),
            ],
            hidden=config.read_only,
            className="d-flex",
        )

    def get_optimizations_data_source(self, purchase_id: int) -> PurchaseOptimizations:
        return CachedOptimizationsDataSource(purchase_id, self.data_load_time.data)

    def click_on_run_optimization_button(
        self, n_clicks: int, ctx: ScrapPurchaseAppSource
    ) -> "PurchaseOptimizationVM":
        if n_clicks == 0:
            return self

        data_source = ctx.db_purchase_data_source
        user_defined_expected_steel_production = data_source.get_user_defined_expected_steel_production()
        production_plan_nr_of_weeks = data_source.get_production_plan_nr_of_weeks()
        # TODO validate sum(all scrap) vs sum(production_plan) + scrap_stock objective in kgs
        #   very likely we would need to validate "corrected" production plan
        #   - see `get_corrected_production_plan` function
        # TODO validate that all offers have (nonzero) weight and price defined

        optimization_input = ScrapPurchaseOptimizationInput(
            data_source.get_optimization_settings(),
            data_source.get_scrap_state_data(),
            tuple(filter(lambda scrap_offer: not scrap_offer.frozen, data_source.get_scrap_offer_data())),
            data_source.get_realized_scrap_offer_data(),
            data_source.get_production_plan_data(),
            # Following attributes are optional,
            # because they are available in later steps of input data creation wizard only.
            # However, they are required in optimization. Since optimization (i.e. button related
            # to this callback) is available only after all steps in creation wizard are taken,
            # we are safe (?) to ignore type checking here.
            data_source.get_production_plan_date().date(),  # type: ignore
            production_plan_nr_of_weeks,  # type: ignore
            (
                user_defined_expected_steel_production
                if user_defined_expected_steel_production is not None
                else sum(MEAN_DAILY_PRODUCTION_PER_STEELSHOP.values()) * 7 * production_plan_nr_of_weeks
            ),
            data_source.get_scrap_stock_objective(),  # type: ignore
            data_source.get_export_slabs_weight(),
            data_source.get_mean_scrap_weight(),
        )

        optimization_result = ctx.db_purchase_optimization_data_source.add_new_optimization(
            optimization_input
        )
        logger.info(f"New scrap purchase optimization with ID {optimization_result.pk} created")

        calculate_optimal_scrap_purchase.send(optimization_result.pk)

        ctx.db_purchase_data_source.add_optimization(
            optimization_result.pk, ctx.purchase_optimizations.get_optimizations()
        )

        return evolve(self, optimization_start_clicked_data=True, data_load_time=time.time_ns())

    def update_optimization_progress_text(self, ctx: ScrapPurchaseAppSource) -> str:
        return f"{self.update_optimization_progress_value(ctx):.1f}%"

    def update_optimization_progress_value(self, ctx: ScrapPurchaseAppSource) -> float:
        if self.optimization_start_clicked:
            # This check is due to `mypy`
            if ctx.purchase_optimizations.last_optimization is None:
                raise ScrapPurchaseAppError(
                    f"Scrap Purchase Record {ctx.scrap_purchase_id}"
                    " - Attribute `optimization_start_clicked` set to `True`"
                    " despite no optimization has been triggered, yet"
                )

            return ctx.purchase_optimizations.last_optimization.progress

        return 0.0

    def update_optimization_progress_style(self) -> bool:
        return not self.optimization_start_clicked

    def update_applied_delta_rules_progress_bar_value(self, ctx: ScrapPurchaseAppSource) -> float:
        scrap_offer_data = ctx.db_purchase_data_source.get_scrap_offer_data()
        if scrap_offer_data:
            return get_nr_of_offers_with_rules(scrap_offer_data) * 100.0 / len(scrap_offer_data)
        return 0.0

    def update_applied_delta_rules_progress_bar_children(self, ctx: ScrapPurchaseAppSource) -> str:
        scrap_offer_data = ctx.db_purchase_data_source.get_scrap_offer_data()
        return f"{get_nr_of_offers_with_rules(scrap_offer_data)} / {len(scrap_offer_data)}"

    def disable_run_optimization_button(self, ctx: ScrapPurchaseAppSource) -> bool:
        if self.optimization_start_clicked:
            return True
        scrap_offer_data = ctx.db_purchase_data_source.get_scrap_offer_data()
        if scrap_offer_data:
            return not (
                get_nr_of_offers_with_rules(scrap_offer_data) == len(scrap_offer_data)
                and all(offer.has_valid_price for offer in scrap_offer_data)
            )
        return True

    def optimization_refresh_data(self, _: int, ctx: ScrapPurchaseAppSource) -> "PurchaseOptimizationVM":
        if ctx.purchase_optimizations.last_optimization is not None:
            opt = ctx.purchase_optimizations.last_optimization.update()
            ctx.db_purchase_data_source.update_computations(
                ctx.purchase_optimizations.get_optimizations()[:-1] + (opt,)
            )
            if self.optimization_start_clicked and opt.is_finished():  # type: ignore
                view_model = evolve(
                    self, optimization_start_clicked_data=False, data_load_time=time.time_ns()
                )

                opt_error = opt.output_data.error
                if opt_error is not None:
                    return evolve(
                        view_model,
                        messages_channel_ss=Message(
                            uuid=str(uuid.uuid1()),
                            errors=(opt_error,),
                        ),
                    )

                opt_warning = opt.output_data.warning
                if opt_warning is not None:
                    view_model = evolve(
                        view_model,
                        messages_channel_ss=Message(
                            uuid=str(uuid.uuid1()),
                            warnings=(opt_warning,),
                        ),
                    )

                scrap_offers_data_list = list()

                recommendations = ctx.purchase_optimizations.last_optimization.output_data.recommendations

                for scrap_offer in ctx.db_purchase_data_source.get_scrap_offer_data():
                    offer_with_recommendation = scrap_offer.update_field(
                        recommendation=recommendations.get(scrap_offer.uuid, 0)
                    )
                    scrap_offers_data_list.append(offer_with_recommendation)

                updated_scrap_offers = tuple(scrap_offers_data_list)
                ctx.db_purchase_data_source.update_scrap_offer_data(updated_scrap_offers)
                logger.info(
                    f"Scrap offer recommendations refreshed "  # type: ignore
                    f"according to optimization {ctx.purchase_optimizations.last_optimization.optimization_id}"
                )

                return view_model

        return self

    def disable_optimization_refresh_interval(self) -> bool:
        return not self.optimization_start_clicked

    @property
    def optimization_start_clicked(self) -> bool:
        return bool(self.optimization_start_clicked_data.data)

    def message_channel(self) -> Optional[Message]:
        return None if not self.messages_channel_ss else Message(**self.messages_channel_ss)
