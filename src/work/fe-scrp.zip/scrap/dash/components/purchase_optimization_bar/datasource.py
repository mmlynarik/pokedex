from functools import lru_cache
from typing import Tuple, Protocol
import attr
from scrap.models import ScrapPurchaseRecord, ScrapPurchaseOptimizationDisplayData


class PurchaseOptimizations(Protocol):
    def get_optimizations(self) -> Tuple[ScrapPurchaseOptimizationDisplayData, ...]: ...

    @property
    def last_optimization(self) -> ScrapPurchaseOptimizationDisplayData: ...


@lru_cache(maxsize=128)
def get_optimizations(purchase_id: int, timestamp: int) -> Tuple[ScrapPurchaseOptimizationDisplayData, ...]:  # type: ignore
    return ScrapPurchaseRecord.objects.get(pk=purchase_id).current_data.computations


@attr.s(frozen=True, auto_attribs=True)
class CachedOptimizationsDataSource:

    purchase_id: int
    timestamp: int

    def get_optimizations(self) -> Tuple[ScrapPurchaseOptimizationDisplayData, ...]:
        return get_optimizations(self.purchase_id, self.timestamp)

    @property
    def last_optimization(self) -> ScrapPurchaseOptimizationDisplayData:
        return self.get_optimizations()[-1]
