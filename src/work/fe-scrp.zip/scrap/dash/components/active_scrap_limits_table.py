from typing import List, Optional, Tuple, TypedDict

from dash import dash_table
from dash.dash_table.Format import Format, Scheme
from immutables import Map

from scrap.models import (
    LoadingStation,
    all_prefetched_loading_station_query_set,
    MultipleHeatsOptimizationInput,
    MultipleHeatsOptimizationOutput,
    MultipleHeatsOptimizationResult,
)
from scrap_core import ScrapBounds, ScrapCharge, ScrapMixMapping, get_affected_scrap_mixes
from scrap_core.optimization.relaxable_limits import (
    RelaxableSummingLimit,
    RelaxableUpperSummingLimit,
    RelaxableLowerSummingLimit,
)
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE
from scrap.dash.components.one_heat_optimizer_v2 import (
    get_relaxable_upper_summing_limits_for_grade,
    get_relaxable_lower_summing_limits_for_grade,
)


class ActiveScrapLimitsTableRow(TypedDict):
    limit_type: str
    limit_name: str
    scraps: str
    aim: float
    allowed: float
    actual: float
    has_violated_aim_only: int
    has_violated_allowed: int


ActiveScrapLimitsTableData = List[ActiveScrapLimitsTableRow]


ACTIVE_SCRAP_LIMITS_TABLE_TEXT_STYLE = DATA_TEXT_STYLE + [
    {"if": {"filter_query": "{has_violated_allowed} = 1"}, "backgroundColor": "rgb(249, 133, 112)"},
    {"if": {"filter_query": "{has_violated_aim_only} = 1"}, "backgroundColor": "rgb(250, 245, 100)"},
    {"if": {"column_id": "limit_type"}, "width": "60px"},
    {"if": {"column_id": "aim"}, "width": "60px"},
    {"if": {"column_id": "allowed"}, "width": "60px"},
    {"if": {"column_id": "actual"}, "width": "60px"},
]


def create_active_scrap_limits_table(element_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=element_id,
        style_data_conditional=ACTIVE_SCRAP_LIMITS_TABLE_TEXT_STYLE,
        style_table={"margin-bottom": "16px"},
        style_header=TABLE_HEADER_STYLE,
        style_cell=CELL_STYLE,
        columns=[
            {"name": "Typ limitu", "id": "limit_type", "type": "text", "editable": False},
            {
                "name": "Názov/zdroj limitu",
                "id": "limit_name",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Šroty",
                "id": "scraps",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Cieľ",
                "id": "aim",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=0, scheme=Scheme.fixed),
            },
            {
                "name": "Max/Min",
                "id": "allowed",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=0, scheme=Scheme.fixed),
            },
            {
                "name": "Realita",
                "id": "actual",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=0, scheme=Scheme.fixed),
            },
        ],
        data=[],
        editable=False,
    )


def get_single_scrap_active_limits(
    limits: ScrapBounds, scrap_charge: ScrapCharge, limit_type: str, limit_name: str
) -> ActiveScrapLimitsTableData:
    """Get active availability or user limits for given scrap charge."""
    active_limits = {
        mix: limit
        for mix, limit in limits.items()
        if mix in scrap_charge
        and (
            (scrap_charge[mix] >= limit and limit_type == "Horný")
            or (scrap_charge[mix] <= limit and limit_type == "Dolný")
        )
    }
    return [
        {
            "limit_type": limit_type,
            "limit_name": limit_name,
            "scraps": mix,
            "aim": limit,
            "allowed": limit,
            "actual": scrap_charge[mix],
            "has_violated_aim_only": 0,
            "has_violated_allowed": int(
                (scrap_charge[mix] > limit and limit_type == "Horný")
                or (scrap_charge[mix] < limit and limit_type == "Dolný")
            ),
        }
        for mix, limit in active_limits.items()
    ]


def get_summing_scrap_active_limits(
    limits: Tuple[RelaxableSummingLimit, ...],
    scrap_charge: ScrapCharge,
    mix_mapping: ScrapMixMapping,
    limit_type: str,
) -> ActiveScrapLimitsTableData:
    """Get active summing limits for given scrap charge."""
    total_scrap_wght = sum(scrap_charge.values())
    active_limits = []
    for lim in limits:
        if lim.is_active(scrap_charge, mix_mapping):
            affected_scrap_mixes = get_affected_scrap_mixes(tuple(scrap_charge), mix_mapping, lim.scrap_types)
            active_limits.append(
                {
                    "limit_type": limit_type,
                    "limit_name": lim.name,
                    "scraps": ", ".join(affected_scrap_mixes),
                    "aim": lim.get_effective_weight_limit(total_scrap_wght),
                    "allowed": lim.get_last_relaxation_step().get_effective_weight_limit(total_scrap_wght),
                    "actual": sum(wght for mix, wght in scrap_charge.items() if mix in affected_scrap_mixes),
                    "has_violated_aim_only": int(lim.has_violated_aim_only(scrap_charge, mix_mapping)),
                    "has_violated_allowed": int(lim.has_violated_allowed(scrap_charge, mix_mapping)),
                }
            )
    return sorted(active_limits, key=lambda x: x["aim"])


def get_total_scrap_weight_limit(
    total_scrap_weight: float, scrap_charge: ScrapCharge, limit_type: str, limit_name: str
) -> ActiveScrapLimitsTableData:
    actual = sum(scrap_charge.values())
    diff = abs(actual - total_scrap_weight)
    if diff > 1000:
        return [
            {
                "limit_type": limit_type,
                "limit_name": limit_name,
                "scraps": "",
                "aim": total_scrap_weight,
                "allowed": total_scrap_weight,
                "actual": actual,
                "has_violated_aim_only": 0,
                "has_violated_allowed": 1,
            }
        ]
    return []


def get_active_scrap_limits_loaded_table_data(
    result: MultipleHeatsOptimizationResult, scrap_charge: ScrapCharge
) -> ActiveScrapLimitsTableData:
    input_data: MultipleHeatsOptimizationInput = result.input_data
    heat = input_data.heats[0]
    available_scraps = input_data.upper_bounds
    upper_user_bounds = Map(
        {mix: weight for mix, weight in heat.upper_bounds.items() if weight < heat.total_scrap_weight}
    )
    lower_user_bounds = Map({mix: weight for mix, weight in heat.lower_bounds.items() if weight > 0})
    relaxable_upper_summing_limits = heat.relaxable_upper_summing_limits
    relaxable_lower_summing_limits = heat.relaxable_lower_summing_limits
    mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping

    return (
        get_single_scrap_active_limits(available_scraps, scrap_charge, "Horný", "Dostupnosť")
        + get_single_scrap_active_limits(upper_user_bounds, scrap_charge, "Horný", "Operátor")
        + get_single_scrap_active_limits(lower_user_bounds, scrap_charge, "Dolný", "Operátor")
        + get_total_scrap_weight_limit(heat.total_scrap_weight, scrap_charge, "Zhoda", "Objednaný šrot")
        + get_summing_scrap_active_limits(relaxable_upper_summing_limits, scrap_charge, mix_mapping, "Horný")
        + get_summing_scrap_active_limits(relaxable_lower_summing_limits, scrap_charge, mix_mapping, "Dolný")
    )


def get_active_scrap_limits_model_table_data(
    result: MultipleHeatsOptimizationResult,
) -> ActiveScrapLimitsTableData:
    output: MultipleHeatsOptimizationOutput = result.result
    scrap_charge = output.scrap_weights_per_heat[0]
    return get_active_scrap_limits_loaded_table_data(result, scrap_charge)


def get_relaxable_summing_limits_from_loading_station(
    loading_station_id: int, grade_id: int
) -> Tuple[Tuple[RelaxableUpperSummingLimit, ...], Tuple[RelaxableLowerSummingLimit, ...]]:
    station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=loading_station_id)
    relaxable_lower_summing_limits_settings = tuple(station.relaxable_lower_summing_limit_settings.all())
    relaxable_upper_summing_limits_settings = tuple(station.relaxable_upper_summing_limit_settings.all())

    relaxable_upper_summing_limits = get_relaxable_upper_summing_limits_for_grade(
        grade_id, relaxable_upper_summing_limits_settings
    )
    relaxable_lower_summing_limits = get_relaxable_lower_summing_limits_for_grade(
        grade_id, relaxable_lower_summing_limits_settings
    )
    return relaxable_upper_summing_limits, relaxable_lower_summing_limits


def get_active_scrap_limits_free_table_data(
    scrap_charge: ScrapCharge,
    grade_id: Optional[int] = None,
    loading_station_id: Optional[int] = None,
) -> ActiveScrapLimitsTableData:
    # if result is None:
    station: LoadingStation = all_prefetched_loading_station_query_set().get(pk=loading_station_id)
    upper_summing_limits, lower_summing_limits = get_relaxable_summing_limits_from_loading_station(
        loading_station_id, grade_id
    )
    mix_mapping = station.model_settings.optimizer_settings.scrap_mix_mapping
    # else:
    #     input_data: MultipleHeatsOptimizationInput = result.input_data
    #     heat = input_data.heats[0]
    #     upper_summing_limits = heat.relaxable_upper_summing_limits
    #     lower_summing_limits = heat.relaxable_lower_summing_limits
    #     mix_mapping = input_data.model_settings.optimizer_settings.scrap_mix_mapping

    return get_summing_scrap_active_limits(
        upper_summing_limits, scrap_charge, mix_mapping, "Horný"
    ) + get_summing_scrap_active_limits(lower_summing_limits, scrap_charge, mix_mapping, "Dolný")
