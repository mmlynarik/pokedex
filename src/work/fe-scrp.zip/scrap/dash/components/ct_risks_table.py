import logging
from typing import TypedDict, List, Tuple

from immutables import Map
from dash import dash_table
from dash.dash_table import FormatTemplate as FormatTemplate

from common.dash import CELL_STYLE, TABLE_HEADER_STYLE, DATA_TEXT_STYLE
from scrap_core import Chem, ScrapCharge
from scrap_core.modelutils import get_ct_risks, get_ct_risk
from scrap_core.optimization.datamodel import HeatInputs, ModelSettings
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelInput,
    get_corr_tech_model,
    CorrectionTechnologyType,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class CTRisksTableRow(TypedDict):
    """Undesirable correction technology risks for given chem"""

    chem: Chem
    reblow_risk: float
    reclass_risk: float
    ct_risk: float


CTRiskTableData = List[CTRisksTableRow]


CT_RISKS_TABLE_TEXT_STYLE = DATA_TEXT_STYLE + [
    {"if": {"filter_query": "{has_ignored_chem} = 1"}, "color": "rgb(216, 219, 206)"}
]


def create_ct_risks_table(element_id: str) -> dash_table.DataTable:
    columns = [
        {"name": "Prvok", "id": "chem", "type": "text", "editable": False},
        {
            "name": "Riziko dofuku",
            "id": "reblow_risk",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
        {
            "name": "Riziko preplánu",
            "id": "reclass_risk",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
        {
            "name": "Celkové riziko",
            "id": "ct_risk",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(2),
        },
    ]
    return dash_table.DataTable(
        id=element_id,
        style_cell_conditional=[
            {"if": {"column_id": "chem"}, "width": "10px"},
            {"if": {"column_id": "reblow_risk"}, "width": "65px"},
            {"if": {"column_id": "reclass_risk"}, "width": "65px"},
            {"if": {"column_id": "ct_risk"}, "width": "65px"},
        ],
        style_data_conditional=CT_RISKS_TABLE_TEXT_STYLE,
        style_table={"margin": "0px auto"},
        style_header=TABLE_HEADER_STYLE,
        style_cell=CELL_STYLE,
        columns=columns,
        data=[],
        editable=False,
    )


def get_ct_risks_table_data(
    reblow_risks: Map[Chem, float],
    reclass_risks: Map[Chem, float],
    ct_risks: Map[Chem, float],
    supported_chems: Tuple[Chem, ...],
    ignored_chems: Tuple[Chem, ...],
) -> CTRiskTableData:
    return [
        {
            "chem": chem,
            "reblow_risk": reblow_risks[chem],
            "reclass_risk": reclass_risks[chem],
            "ct_risk": ct_risks[chem],
            "has_ignored_chem": int(chem in ignored_chems),
        }
        for chem in sorted(supported_chems)
    ]


def get_ct_risks_table_summary_row(
    scrap_charge: ScrapCharge,
    heat: HeatInputs,
    settings: ModelSettings,
    pellets_weight: int,
    briquetes_weight: int,
) -> CTRisksTableRow:
    return {
        "chem": "Tavba",
        "reblow_risk": get_ct_risk(
            scrap_charge,
            None,
            heat,
            settings,
            pellets_weight,
            briquetes_weight,
            CorrectionTechnologyType.REBLOW,
            True,
        ),
        "reclass_risk": get_ct_risk(
            scrap_charge,
            None,
            heat,
            settings,
            pellets_weight,
            briquetes_weight,
            CorrectionTechnologyType.RECLASSIFICATION,
            True,
        ),
        "ct_risk": get_ct_risk(
            scrap_charge, None, heat, settings, pellets_weight, briquetes_weight, None, True
        ),
        "has_ignored_chem": 0,
    }


def get_ct_risks_free_table_data(
    scrap_charge: ScrapCharge,
    heat: HeatInputs,
    settings: ModelSettings,
    pellets_weight: int,
    briquetes_weight: int,
) -> CTRiskTableData:

    supported_chems = settings.correction_technologies_settings.chems_for_correction_technologies
    ignored_chems = settings.get_ignored_chems(heat.grade_planned)
    expected_ct_risks = get_ct_risks(scrap_charge, heat, settings, pellets_weight, briquetes_weight)
    expected_reblow_risks = get_ct_risks(
        scrap_charge, heat, settings, pellets_weight, briquetes_weight, CorrectionTechnologyType.REBLOW
    )
    expected_reclass_risks = get_ct_risks(
        scrap_charge,
        heat,
        settings,
        pellets_weight,
        briquetes_weight,
        CorrectionTechnologyType.RECLASSIFICATION,
    )
    return get_ct_risks_table_data(
        expected_reblow_risks, expected_reclass_risks, expected_ct_risks, supported_chems, ignored_chems
    ) + [get_ct_risks_table_summary_row(scrap_charge, heat, settings, pellets_weight, briquetes_weight)]
