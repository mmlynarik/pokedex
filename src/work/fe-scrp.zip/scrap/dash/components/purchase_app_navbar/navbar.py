import attr
from dash import html, dcc
import ussksdc as sdc
import dash_bootstrap_components as dbc
from scrap.dash.components.purchase_app_navbar.modal import ConfirmTakingControlModalViewModel
from scrap.dash.components.common import ScrapPurchaseAppSource

from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig


@attr.s(frozen=True, slots=True)
class PurchaseNavbarViewModel:
    COMPONENT_ID = "nav"
    LOADING_ID = "loading"
    STATUS_ID = "status"
    PURCHASE_INFO_ID = "info"
    USER_IN_CONTROL_ID = "user-in-control"
    TAKE_CONTROL_ID = "take-control"
    TAKE_CONTROL_WRAPPER_ID = "take-control-wrapper"
    RELOAD_DATA_INTERVAL_ID = "refresh"

    message_modal: ConfirmTakingControlModalViewModel = sdc.child_component(
        "message", default=ConfirmTakingControlModalViewModel()
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.RELOAD_DATA_INTERVAL_ID, "n_intervals", cls.update_data),
            sdc.InputField(cls.TAKE_CONTROL_ID, "n_clicks", cls.take_control),
        )

    @classmethod
    def get_output_fields(cls, config: ScrapPurchaseAppConfig) -> sdc.OutputFields:
        output_fields = [
            sdc.OutputField(cls.PURCHASE_INFO_ID, "children", cls.get_purchase_info),
            sdc.OutputField(cls.USER_IN_CONTROL_ID, "children", cls.get_logged_username),
            sdc.OutputField(cls.TAKE_CONTROL_ID, "children", cls.get_take_control_message),
            sdc.OutputField(cls.STATUS_ID, "children", cls.get_update_status),
        ]
        if config.read_only:
            output_fields.append(
                sdc.OutputField(cls.TAKE_CONTROL_WRAPPER_ID, "hidden", cls.hide_take_control_wrapper)
            )
        return tuple(output_fields)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig) -> dbc.Navbar:
        return dbc.Navbar(
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            children=[
                html.Div(
                    hidden=not config.read_only,
                    children=dcc.Loading(
                        id=sdc.create_id(parent_id, cls.LOADING_ID),
                        type="dot",
                        children=[
                            html.Div(
                                id=sdc.create_id(parent_id, cls.STATUS_ID),
                                children="",
                            ),
                        ],
                    ),
                ),
                dbc.Label(id=sdc.create_id(parent_id, cls.PURCHASE_INFO_ID)),
                html.Div(id=sdc.create_id(parent_id, cls.USER_IN_CONTROL_ID)),
                html.Div(
                    hidden=True,
                    id=sdc.create_id(parent_id, cls.TAKE_CONTROL_WRAPPER_ID),
                    children=dbc.Button(
                        id=sdc.create_id(parent_id, cls.TAKE_CONTROL_ID),
                        color="link",
                        n_clicks=0,
                        style={"color": "green"},
                    ),
                ),
                dcc.Interval(
                    id=sdc.create_id(parent_id, cls.RELOAD_DATA_INTERVAL_ID),
                    interval=10000,
                    n_intervals=0,
                    disabled=not config.read_only,
                ),
                sdc.get_child_layout(parent_id, cls.message_modal),
            ],
        )

    def update_data(self, _: int, ctx: ScrapPurchaseAppSource) -> "PurchaseNavbarViewModel":
        return attr.evolve(self)

    def get_purchase_info(self, ctx: ScrapPurchaseAppSource) -> str:
        return ctx.scrap_purchase_info

    def get_logged_username(self, ctx: ScrapPurchaseAppSource) -> str:
        return ctx.db_user_data.get_logged_user_username()

    def get_take_control_message(self, ctx: ScrapPurchaseAppSource) -> str:
        return f"Prevziať kontrolu od {ctx.db_user_data.get_user_in_control_username()}"

    def take_control(self, _: int, ctx: ScrapPurchaseAppSource) -> "PurchaseNavbarViewModel":
        ctx.db_purchase_data_source.take_control_over_purchase(ctx.db_user_data.logged_user)
        return attr.evolve(self, message_modal=self.message_modal.set_input_and_open())

    def get_update_status(self, ctx: ScrapPurchaseAppSource) -> str:
        return f"Aktualizované {ctx.db_purchase_data_source.get_last_update_time().strftime('%H:%M:%S')}"

    def hide_take_control_wrapper(self, ctx: ScrapPurchaseAppSource):
        return (
            True
            if ctx.db_user_data.get_logged_user_username() == ctx.db_user_data.get_user_in_control_username()
            else False
        )
