import attr
import ussksdc as sdc
from dash import html
import dash_bootstrap_components as dbc

from scrap.dash.components.modals import create_modal_label_header


@attr.s(frozen=True, slots=True)
class ConfirmTakingControlModalViewModel:
    OPEN_ON_INIT = False

    COMPONENT_ID = "confirm"
    CLOSE_BUTTON_ID = "close"

    NAME = "Prevzatie kontroly prebehlo úspešne"
    MESSAGE = "Pre pokračovanie je nutné prenačítať stránku"

    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", default=OPEN_ON_INIT)

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", cls.close_modal),)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dbc.Modal(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    children=[
                        create_modal_label_header(cls.NAME, sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID)),
                        dbc.ModalBody(cls.MESSAGE),
                    ],
                )
            ]
        )

    def close_modal(self, _: int) -> "ConfirmTakingControlModalViewModel":
        return attr.evolve(self, is_open=False)

    def set_input_and_open(self) -> "ConfirmTakingControlModalViewModel":
        return attr.evolve(self, is_open=True)
