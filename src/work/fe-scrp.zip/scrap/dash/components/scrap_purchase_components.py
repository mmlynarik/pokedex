# pylint: disable=too-many-lines
import json
from functools import lru_cache

import attr
import dash_bootstrap_components as dbc
from dash import dash_table, dcc, html
from dash.dash_table.Format import Format, Scheme
from datetime import datetime
from typing import List, Dict, TypedDict, Optional, Tuple, Union, Literal, Any

from ...models import (
    converter,
    ScrapOffer,
    ScrapOfferData,
    RealizedScrapOfferData,
    ScrapOfferParsedData,
    BaseDeltaRuleData,
    ParsedScrapStateData,
    ParsedScrapOnTheWayData,
    ScrapPurchaseRecordDisplayData,
    ScrapStateData,
    ProductionPlanData,
    ScrapPurchaseOptimizationDisplayData,
    MEAN_DAILY_PRODUCTION_PER_STEELSHOP,
)

from scrap_core import (
    SUPPORTED_SCRAP_TYPES,
    ScrapType,
)

from .common_loading_station import get_full_screen_error_modal

DISPLAY_DATA_STORE_ID = "display-data"
MAIN_DIV_ID = "scrap-purchase-model"
UPLOAD_SCRAP_STATE_ID = "scrap-purchase-state-upload-file"
SCRAP_STATE_FILENAME_ID = "scrap-purchase-state-name"
SCRAP_STATE_TABLE = "scrap-state-table"
SCRAP_STATE_UNMAPPED_TYPES_CONTAINER = "scrap-state-unmapped-types-container"

INPUT_DATA_LINK_ID = "input-data-link-id"

USER_NAME_ID = "navbar-username"
NAVBAR_SCRAP_PURCHASE_INFO = "navbar-scrap-purchase-info"

SCRAP_STATE_MAPPING_TABLE = "scrap-state-mapping-table"
SCRAP_STATE_MAPPING_SECTION = "scrap-state-mapping-section"
SCRAP_STATE_SAVE_MAPPINGS = "scrap-state-save-mappings"

SCRAP_OFFERS_MAPPING_TABLE = "scrap-offers-mapping-table"
SCRAP_OFFERS_MAPPING_SECTION = "scrap-offers-mapping-section"
SCRAP_OFFERS_SAVE_MAPPINGS = "scrap-offers-save-mappings"

SCRAP_STATE_ERROR_DIV = "scrap-state-error-div"

STATUS_ID = "status-id"

PRODUCTION_PLAN_DATE_PICKER_ID = "production-plan-date-picker"
PRODUCTION_PLAN_NR_OF_WEEKS_ID = "production-plan-nr-of-weeks"
PRODUCTION_PLAN_LOAD_BUTTON_ID = "production-plan-load-button"
PRODUCTION_PLAN_TABLE_ID = "production-plan-table"
EXPECTED_STEEL_PRODUCTION_INPUT = "expected-steel-production"
EXPORT_SLABS_WEIGHT_INPUT = "export-slabs-weight"

SCRAP_MAPPING_TABLE_INPUT_KEY = "input_scrap_type"
SCRAP_MAPPING_TABLE_TYPE_KEY = "scrap_type"

SCRAP_ON_THE_WAY_UPLOAD_ID = "scrap-on-the-way-upload-file"
SCRAP_ON_THE_WAY_FILENAME_ID = "scrap-on-the-way-name"

SHOW_SCRAP_STATE_PARSED_DATA_BUTTON = "show-scrap-state-parsed-data-button"
SCRAP_STATE_PARSED_DATA_COLLAPSE = "scrap-state-parsed-data-collapse"
SCRAP_STATE_PARSED_DATA_TABLE = "scrap-state-parsed-data-table"

SHOW_SCRAP_ON_THE_WAY_PARSED_DATA_BUTTON = "show-scrap-on-the-way-parsed-data-button"
SCRAP_ON_THE_WAY_PARSED_DATA_COLLAPSE = "scrap-on-the-way-parsed-data-collapse"
SCRAP_ON_THE_WAY_PARSED_DATA_TABLE = "scrap-on-the-way-parsed-data-table"

SCRAP_PURCHASE_TITLE_INPUT = "scrap-purchase-title-input"

LOADING_ELEMENT = "loading-element"

SCRAP_STOCK_OBJECTIVE_INPUT = "scrap-stock-objective-input"
MEAN_SCRAP_WEIGHT_INPUT = "mean-scrap-weight-input"

BASE_DELTA_RULES_TABLE = "base-delta-rules-table"
BASE_DELTA_RULES_ADD_BUTTON = "base-delta-rules-add-button"

UPLOAD_SCRAP_OFFERS_ID = "upload-scrap-offers"
SCRAP_OFFERS_FILENAME_ID = "scrap-offers-filename"
ADD_NEW_SCRAP_OFFER_BUTTON_ID = "add-new-scrap-offer-id"

SCRAP_OFFERS_PARSED_DATA_TABLE = "scrap-offers-parsed-data-table"
SHOW_SCRAP_OFFERS_PARSED_DATA_BUTTON = "show-scrap-offers-parsed-data-button"
SCRAP_OFFERS_PARSED_DATA_COLLAPSE = "scrap-offers-parsed-data-collapse"
USER_IN_CONTROL_NAME_ID = "navbar-username-incontrol"

SCRAP_OFFERS_TABLE = "scrap-offers-table"
SCRAP_OFFERS_TABLE_PAGE_SIZE = 10
REALIZED_SCRAP_OFFERS_TABLE = "realized-scrap-offers-table"
REALIZED_SCRAP_OFFERS_TABLE_EXPORT = "realized-scrap-offers-table-export"

UNMAPPED_SCRAP_SUPPLIER_SECTION = "unmapped-scrap-supplier-section"
UNMAPPED_SCRAP_SUPPLIER_TABLE = "unmapped-scrap-supplier-table"
UNMAPPED_SCRAP_SUPPLIER_SAVE = "unmapped-scrap-supplier-save"

SCRAP_PRICE_PLOT_SECTION = "scrap-price-plot-section"
SCRAP_PRICE_PLOT = "scrap-price-plot"
SCRAP_PRICE_PLOT_HIDE_BUTTON = "scrap-price-plot-hide-button"

BUY_SCRAP_MODAL_WINDOW = "buy-scrap-modal-window"
BUY_SCRAP_MODAL_OFFER_INFO = "buy-scrap-modal-offer-info"
BUY_SCRAP_MODAL_CONFIRMATION_BUTTON = "buy-scrap-modal-confirmation-button"
BUY_SCRAP_MODAL_AMOUNT = "buy-scrap-modal-amount"
BUY_SCRAP_MODAL_PRICE = "buy-scrap-modal-price"

CREATE_EDIT_OFFER_MODAL_WINDOW = "create-edit-modal-window"
CREATE_EDIT_OFFER_MODAL_CONFIRM = "create-edit-modal-confirm"
CREATE_EDIT_OFFER_MODAL_DELETE = "create-edit-modal-delete"

CREATE_EDIT_OFFER_MODAL_SCRAP_TYPE = "create-edit-modal-scrap-type"
CREATE_EDIT_OFFER_MODAL_ZONE = "create-edit-modal-zone"
CREATE_EDIT_OFFER_MODAL_WEIGHT = "create-edit-modal-weight"
CREATE_EDIT_OFFER_MODAL_SUPPLIER = "create-edit-modal-supplier"
CREATE_EDIT_OFFER_MODAL_PRICE = "create-edit-modal-price"
CREATE_EDIT_OFFER_MODAL_OVERRIDE_PRICE = "create-edit-modal-override-price"
CREATE_EDIT_OFFER_MODAL_NOTE = "create-edit-modal-note"
CREATE_EDIT_OFFER_MODAL_STATION = "create-edit-modal-station"

OVERALL_PURCHASE_TABLE = "overall-purchase-table"

SCRAP_PURCHASE_RECORD_ID_DIV_ID = "scrap-purchase-record-id"

PURCHASE_DATE_INPUT = "purchase-date-input"

DELETE_REALIZED_OFFER_MODAL = "delete-realized-offer-modal"
DELETE_REALIZED_OFFER_CONFIRM = "delete-realized-offer-confirm"
DELETE_REALIZED_OFFER_MODAL_BODY = "delete-realized-offer-body"

WIZARD_SECTION_ID = "wizard-section"
MAIN_SECTION_ID = "main-section"

WIZARD_STEP_1_ID = "wizard-step-1"
WIZARD_STEP_2_ID = "wizard-step-2"
WIZARD_STEP_3_ID = "wizard-step-3"
WIZARD_STEP_4_ID = "wizard-step-4"

WIZARD_CONFIRM_1_ID = "wizard-confirm-1"
WIZARD_CONFIRM_2_ID = "wizard-confirm-2"
WIZARD_CONFIRM_3_ID = "wizard-confirm-3"
WIZARD_CONFIRM_4_ID = "wizard-confirm-4"

WIZARD_BACK_FROM_STEP_2_ID = "wizard-back-from-2"
WIZARD_BACK_FROM_STEP_3_ID = "wizard-back-from-3"
WIZARD_BACK_FROM_STEP_4_ID = "wizard-back-from-4"

RELOAD_DATA_INTERVAL_ID = "reload-data-interval"
REFRESH_REQUEST_MODAL_ID = "global-modal-refresh-request"
ERROR_MODAL_WINDOW_ID = "error-modal-window"

RUN_COMPUTATION_BUTTON = "run-computation-button"
PROGRESS_BAR_ID = "progress-bar-id"
COMPUTATION_REFRESH_INTERVAL_ID = "computation-refresh-interval"
APPLIED_DELTA_RULES_PROGRESS_BAR = "applied-delta-rules-progress-bar"

FINISH_PURCHASE_BUTTON = "finish-purchase-button"
FINISH_PURCHASE_MODAL_WINDOW = "finish-purchase-modal-window"
FINISH_PURCHASE_MODAL_CONFIRMATION = "finish-purchase-modal-confirmation"
FINISH_PURCHASE_IN_PROGRESS = "finish-purchase-in-progress"
FINISH_PURCHASE_MODAL_BODY = "finish-purchase-modal-body"

CONTROL_CHANGED_MODAL_ID = "global-model-control-changed"

SCRAP_STATE_EXCEL_IMG = "scrap-state-excel-img"

DISPLAY_FLEX_STYLE = {"display": "flex"}
DISPLAY_BLOCK_STYLE = {"display": "block"}
DISPLAY_NONE_STYLE = {"display": "none"}
FLEX_GROW_1_STYLE = {"flexGrow": "1"}
FLEX_ALIGN_ITEMS_CENTER = {"alignItems": "center"}
FLEX_JUSTIFY_CONTENT_SPACE_BETWEEN = {"justifyContent": "space-between"}
TEXT_ALIGN_RIGHT_STYLE = {"textAlign": "right"}
SPACER_BASIC_HEIGHT = "20px"

ICON_COLUMN_WIDTH = "50px"
ZONE_COLUMN_WIDTH = "50px"
SCRAP_TYPE_COLUMN_WIDTH = "70px"
PRICE_COLUMN_WIDTH = "100px"
RECOMMENDATION_COLUMN_WIDTH = "50px"
WEIGHT_COLUMN_WIDTH = "110px"
BASE_DELTA_RULES_COLUMN_WIDTH = "70px"
SUPPLIER_COLUMN_WIDTH = "190px"
PURCHASE_COLUMN_WIDTH = "70px"
PRIORITY_COLUMN_WIDTH = "50px"

DROPDOWN_TABLE_CSS = [
    {"selector": ".Select-menu-outer", "rule": "display: block !important"},
    {"selector": ".Select-value-label", "rule": "margin-right: 20px !important"},
    {"selector": ".Select-arrow", "rule": "border-top-color: #000000"},
]

SCRAP_PURCHASED_RECOMMENDED_PIVOT_TABLE_ID = "scrap-purchased-recommended-pivot-table"


class ScrapPivotTableRow(TypedDict):
    scrap_type: str
    zone_1: str
    zone_2: str
    zone_3: str
    zone_4: str
    zone_cz: str
    zone_hu: str
    zone_pl: str
    total: str


class RealizedScrapOfferTableRow(TypedDict):
    scrap_type: Optional[ScrapType]
    zone: Optional[str]
    weight: Optional[float]
    supplier: Optional[str]
    price: Optional[float]
    note: Optional[str]
    delete: str
    scrap_offer_uuid_list: List[str]


class BaseDeltaRuleTableRow(TypedDict):
    scrap_type: Optional[str]
    zone: Optional[str]
    supplier: Optional[str]
    base_delta: Optional[float]
    priority: int
    move_up: str
    move_down: str


class OverallPurchaseTableRow(TypedDict):
    scrap_type: Union[ScrapType, Literal["Celkovo"]]
    quantity: float
    price: float


OverallPurchaseTableData = List[OverallPurchaseTableRow]


class ScrapOfferTableRow(TypedDict):
    uuid: str
    scrap_type: Optional[ScrapType]
    zone: Optional[str]
    weight: Optional[float]
    supplier: Optional[str]
    supplier_price: Optional[float]
    override_price: Optional[float]
    price_with_delta: Optional[float]
    recommendation: Optional[float]
    base_delta_rules: str
    scrap_purchased: bool
    added_by_user: bool
    note: Optional[str]
    purchase: str
    show_price_plot: Optional[str]
    edit_offer: str
    generated_from: Optional[str]
    generated: Optional[str]
    station: Optional[str]


ScrapOfferTableData = List[ScrapOfferTableRow]


class ScrapStateTableRow(TypedDict):
    scrap_type: ScrapType
    state_weight: float
    on_the_way_weight: float


ScrapStateTableData = List[ScrapStateTableRow]


class ScrapTypeMappingTableRow(TypedDict):
    input_scrap_type: str
    scrap_type: Optional[ScrapType]


ScrapTypeMappingTableData = List[ScrapTypeMappingTableRow]


class ScrapSupplierMappingTableRow(TypedDict):
    input_scrap_supplier: str
    scrap_supplier: str


ScrapSupplierMappingTableData = List[ScrapSupplierMappingTableRow]


class ProductionPlanTableRow(TypedDict):
    scrap_grade_name: str
    scrap_amount: float


ProductionPlanTableData = List[ProductionPlanTableRow]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class PricePlotValues:
    date_list: List[datetime]
    hover_label_list: List[str]
    weighted_price_list: List[float]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class PricePlotData:
    scrap_type: Optional[ScrapType]
    price_plot_values: Dict[str, PricePlotValues]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def update_field(self, **kwargs) -> "PricePlotData":
        return attr.evolve(self, **kwargs)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapTypeMapping:
    input_scrap_type: str
    scrap_type: Optional[ScrapType]

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


ScrapTypeMappingData = Tuple[ScrapTypeMapping, ...]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapSupplierMapping:
    input_scrap_supplier: str
    scrap_supplier: str

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


ScrapSupplierMappingData = Tuple[ScrapSupplierMapping, ...]


# RMK idea - multiple attributes are optional due to 4-step creation wizard,
#   what makes type checking hard or even impossible. Moreover, these attributes are
#   in fact not optional, because they are required later in optimization
#   (e.g. `production_plan_nr_of_weeks` or `scrap_stock_objective`).
#   Thus we may think about splitting `ScrapPurchaseViewModel` into 4 models, where each model will have
#   all attributes corresponding to steps <= n.
# pylint: disable=too-many-public-methods
@attr.s(frozen=True, auto_attribs=True, slots=True)
class ScrapPurchaseViewModel:
    """
    I may be wrong, but it seems to me that default values are added
    in interplay with `ScrapPurchaseRecordDisplayData` class. In particular,
    see the method `load_display_data` below.
    """

    user: str

    # saved properties
    scrap_purchase_record_id: int
    scrap_purchase_title: Optional[str]
    purchase_date: Optional[datetime]

    user_in_control: str
    authorized_users: Tuple[str, ...]

    control_gained: bool
    control_lost: bool

    scrap_state_filename: str
    scrap_on_the_way_filename: str
    scrap_state_data: ScrapStateData
    parsed_scrap_state_data: ParsedScrapStateData
    parsed_scrap_on_the_way_data: ParsedScrapOnTheWayData

    production_plan_date: Optional[datetime]
    production_plan_nr_of_weeks: int
    scrap_stock_objective: Optional[int]  # in tons (TODO use kgs instead)
    mean_scrap_weight: int  # in kgs
    user_defined_expected_steel_production: Optional[int]  # in kgs
    export_slabs_weight: int  # in kgs
    scrap_offer_data: ScrapOfferData
    realized_scrap_offer_data: RealizedScrapOfferData
    parsed_scrap_offers_data: ScrapOfferParsedData
    scrap_offers_filename: str
    base_delta_rule_data: BaseDeltaRuleData
    production_plan_data: ProductionPlanData

    # not saved properties
    unmapped_scrap_types_from_scrap_state: Tuple[str, ...]
    unmapped_scrap_types_from_scrap_offers: Tuple[str, ...]
    error: bool  # TODO: do we need this? if yes use it properly
    scrap_type_from_scrap_state_data: ScrapTypeMappingData
    scrap_type_from_scrap_offers_data: ScrapTypeMappingData
    parsed_scrap_state_is_open: bool
    parsed_scrap_on_the_way_is_open: bool
    parsed_scrap_offers_is_open: bool
    unmapped_scrap_supplier_from_scrap_offers: Tuple[str, ...]
    scrap_supplier_mapping: ScrapSupplierMappingData
    scrap_offer_to_plot: Optional[ScrapOffer]

    scrap_offer_to_buy_idx: Optional[int]
    scrap_offer_to_edit_idx: Optional[int]
    realized_offer_to_delete_idx: Optional[int]

    scrap_offer_to_buy_price: Optional[float]
    scrap_offer_to_buy_amount: Optional[float]
    scrap_supplier_names: Tuple[str, ...]
    scrap_offers_table_derived_indices: List[int]

    scrap_offer_to_edit_scrap_type: Optional[ScrapType]
    scrap_offer_to_edit_zone: Optional[str]
    scrap_offer_to_edit_weight: Optional[float]
    scrap_offer_to_edit_supplier: Optional[str]
    scrap_offer_to_edit_price: Optional[float]
    scrap_offer_to_edit_override_price: Optional[float]
    scrap_offer_to_edit_note: Optional[str]
    scrap_offer_to_edit_station: Optional[str]

    nr_of_scrap_offers_with_rules: int

    wizard_step_1_confirmed: bool
    wizard_step_2_confirmed: bool
    wizard_step_3_confirmed: bool
    wizard_step_4_confirmed: bool

    price_plot_data: PricePlotData

    finish_scrap_purchase_is_open: bool = False
    finish_scrap_purchase_in_progress: bool = False

    # TODO rename to optimizations
    computation_start_clicked: bool = False
    computations: Tuple[ScrapPurchaseOptimizationDisplayData, ...] = attr.ib(default=())

    # saved properties
    debug: bool = False

    @property
    def expected_steel_production(self) -> int:
        if self.user_defined_expected_steel_production is not None:
            return self.user_defined_expected_steel_production

        return sum(MEAN_DAILY_PRODUCTION_PER_STEELSHOP.values()) * 7 * self.production_plan_nr_of_weeks

    # TODO rename to latest_optimization
    @property
    def latest_computation(self) -> Optional[ScrapPurchaseOptimizationDisplayData]:
        if self.computations:
            return self.computations[-1]

        return None

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def to_context_data(self) -> dict:
        # Better will be to assign data directly to components
        # Unfortunatelly it does not work for dash tables now :( so we need to use this hack
        return {DISPLAY_DATA_STORE_ID: {"children": self.serialize()}}

    def update_field(self, **kwargs) -> "ScrapPurchaseViewModel":
        return attr.evolve(self, **kwargs)

    def delete_scrap_state_scrap_type_mappings(self) -> "ScrapPurchaseViewModel":
        return attr.evolve(self, scrap_type_from_scrap_state_data=tuple())

    def delete_scrap_offer_scrap_type_mappings(self) -> "ScrapPurchaseViewModel":
        return attr.evolve(self, scrap_type_from_scrap_offers_data=tuple())

    def set_error_flag(self, error_value: bool = True) -> "ScrapPurchaseViewModel":
        return attr.evolve(self, error=error_value)

    def are_unmapped_types_from_scrap_state_data(self) -> bool:
        return len(self.unmapped_scrap_types_from_scrap_state) > 0

    def are_unmapped_types_from_scrap_offers_data(self) -> bool:
        return len(self.unmapped_scrap_types_from_scrap_offers) > 0

    def are_unmapped_scrap_supplier_from_scrap_offers(self) -> bool:
        return len(self.unmapped_scrap_supplier_from_scrap_offers) > 0

    def create_display_data(self) -> ScrapPurchaseRecordDisplayData:
        return ScrapPurchaseRecordDisplayData(
            scrap_state_filename=self.scrap_state_filename,
            scrap_on_the_way_filename=self.scrap_on_the_way_filename,
            production_plan_date=self.production_plan_date,
            scrap_stock_objective=self.scrap_stock_objective,
            mean_scrap_weight=self.mean_scrap_weight,
            scrap_offer_data=self.scrap_offer_data,
            realized_scrap_offer_data=self.realized_scrap_offer_data,
            parsed_scrap_offers_data=self.parsed_scrap_offers_data,
            scrap_offers_filename=self.scrap_offers_filename,
            base_delta_rule_data=self.base_delta_rule_data,
            parsed_scrap_state_data=self.parsed_scrap_state_data,
            parsed_scrap_on_the_way_data=self.parsed_scrap_on_the_way_data,
            scrap_state_data=self.scrap_state_data,
            production_plan_data=self.production_plan_data,
            production_plan_nr_of_weeks=self.production_plan_nr_of_weeks,
            computations=self.computations,
            user_defined_expected_steel_production=self.user_defined_expected_steel_production,
            export_slabs_weight=self.export_slabs_weight,
        )

    def load_display_data(self, display_data: ScrapPurchaseRecordDisplayData) -> "ScrapPurchaseViewModel":
        return self.update_field(
            scrap_state_filename=display_data.scrap_state_filename,
            scrap_on_the_way_filename=display_data.scrap_on_the_way_filename,
            production_plan_date=display_data.production_plan_date,
            scrap_stock_objective=display_data.scrap_stock_objective,
            mean_scrap_weight=display_data.mean_scrap_weight,
            scrap_offer_data=display_data.scrap_offer_data,
            realized_scrap_offer_data=display_data.realized_scrap_offer_data,
            parsed_scrap_offers_data=display_data.parsed_scrap_offers_data,
            scrap_offers_filename=display_data.scrap_offers_filename,
            base_delta_rule_data=display_data.base_delta_rule_data,
            parsed_scrap_state_data=display_data.parsed_scrap_state_data,
            parsed_scrap_on_the_way_data=display_data.parsed_scrap_on_the_way_data,
            scrap_state_data=display_data.scrap_state_data,
            production_plan_data=display_data.production_plan_data,
            production_plan_nr_of_weeks=display_data.production_plan_nr_of_weeks,
            computations=display_data.computations,
            user_defined_expected_steel_production=display_data.user_defined_expected_steel_production,
            export_slabs_weight=display_data.export_slabs_weight,
        )

    @staticmethod
    def are_scrap_supplier_mappings_filled(scrap_supplier_mappings: ScrapSupplierMappingData) -> bool:
        if not scrap_supplier_mappings:
            return False
        for scrap_supplier_mapping in scrap_supplier_mappings:
            if not scrap_supplier_mapping.scrap_supplier:
                return False
        return True

    @staticmethod
    def are_scrap_type_mappings_filled(scrap_type_mappings: ScrapTypeMappingData) -> bool:
        if not scrap_type_mappings:
            return False
        for scrap_type_mapping in scrap_type_mappings:
            if not scrap_type_mapping.scrap_type:
                return False
        return True

    def are_scrap_state_mappings_filled(self) -> bool:
        return ScrapPurchaseViewModel.are_scrap_type_mappings_filled(self.scrap_type_from_scrap_state_data)

    def are_scrap_offers_mappings_filled(self) -> bool:
        return ScrapPurchaseViewModel.are_scrap_type_mappings_filled(self.scrap_type_from_scrap_offers_data)

    @staticmethod
    def reset_unmapped_scrap_types(unmapped_scrap_types: Tuple[str, ...]) -> Tuple[ScrapTypeMapping, ...]:
        new_scrap_mapping_list = list()
        for unmapped_scrap_type_item in unmapped_scrap_types:
            new_scrap_mapping = ScrapTypeMapping(input_scrap_type=unmapped_scrap_type_item, scrap_type=None)
            new_scrap_mapping_list.append(new_scrap_mapping)
        return tuple(new_scrap_mapping_list)

    def reset_unmapped_scrap_types_from_scrap_state_data(self) -> "ScrapPurchaseViewModel":
        new_scrap_mapping_tuple = ScrapPurchaseViewModel.reset_unmapped_scrap_types(
            self.unmapped_scrap_types_from_scrap_state
        )
        return attr.evolve(self, scrap_type_from_scrap_state_data=new_scrap_mapping_tuple)

    def reset_unmapped_scrap_types_from_scrap_offers_data(self) -> "ScrapPurchaseViewModel":
        new_scrap_mapping_tuple = ScrapPurchaseViewModel.reset_unmapped_scrap_types(
            self.unmapped_scrap_types_from_scrap_offers
        )
        return attr.evolve(self, scrap_type_from_scrap_offers_data=new_scrap_mapping_tuple)

    def reset_unmapped_scrap_suppliers(self) -> "ScrapPurchaseViewModel":
        new_scrap_supplier_mapping_list = list()
        for unmapped_scrap_supplier_item in self.unmapped_scrap_supplier_from_scrap_offers:
            new_scrap_supplier_mapping = ScrapSupplierMapping(
                input_scrap_supplier=unmapped_scrap_supplier_item, scrap_supplier=""
            )
            new_scrap_supplier_mapping_list.append(new_scrap_supplier_mapping)
        return attr.evolve(self, scrap_supplier_mapping=tuple(new_scrap_supplier_mapping_list))

    def get_wizard_step(self) -> int:
        if not (self.is_wizard_step_1_fulfilled() and self.wizard_step_1_confirmed):
            return 1
        if not (self.is_wizard_step_2_fulfilled() and self.wizard_step_2_confirmed):
            return 2
        if not (self.is_wizard_step_3_fulfilled() and self.wizard_step_3_confirmed):
            return 3
        if not (self.is_wizard_step_4_fulfilled() and self.wizard_step_4_confirmed):
            return 4
        return 0

    def is_wizard_step_1_fulfilled(self) -> bool:
        if self.scrap_purchase_title and self.purchase_date:
            return True
        return False

    def is_wizard_step_2_fulfilled(self) -> bool:
        if all(
            [
                self.scrap_state_filename,
                self.scrap_on_the_way_filename,
                self.scrap_state_data,
                self.parsed_scrap_state_data,
                self.parsed_scrap_on_the_way_data,
                self.are_unmapped_types_from_scrap_state_data,
                self.scrap_stock_objective,
            ]
        ):
            return True
        return False

    def is_wizard_step_3_fulfilled(self) -> bool:
        if self.production_plan_data and self.production_plan_nr_of_weeks and self.production_plan_date:
            return True
        return False

    def is_wizard_step_4_fulfilled(self) -> bool:
        if self.scrap_offer_data:
            return True
        return False


@lru_cache()
def deserialize_scrap_purchase_view_model(serialized: str) -> ScrapPurchaseViewModel:
    return converter.structure(json.loads(serialized), ScrapPurchaseViewModel)


def get_full_screen_modal(modal_id: str, header: str, body: str) -> dbc.Modal:
    return dbc.Modal(
        [dbc.ModalHeader(header), dbc.ModalBody(body)],
        id=modal_id,
        centered=True,
        backdrop="static",
        keyboard=False,
        is_open=False,
    )


def get_base_delta_rules_table(read_only: bool = False) -> dash_table.DataTable:
    columns = [
        {"name": "Priorita", "id": "priority", "type": "numeric", "editable": False},
        {"name": "Typ šrotu", "id": "scrap_type", "presentation": "dropdown", "editable": not read_only},
        {"name": "Zóna", "id": "zone", "presentation": "dropdown", "editable": not read_only},
        {"name": "Dodávateľ", "id": "supplier", "presentation": "dropdown", "editable": not read_only},
        {"name": "Delta", "id": "base_delta", "type": "numeric", "editable": not read_only},
    ]
    if not read_only:
        columns.extend(
            [
                {"name": "", "id": "move_up", "type": "text", "editable": False},
                {"name": "", "id": "move_down", "type": "text", "editable": False},
            ]
        )
    return dash_table.DataTable(
        id=BASE_DELTA_RULES_TABLE,
        data=[],
        columns=columns,
        dropdown={
            "scrap_type": {
                "clearable": False,
                "options": [],
            },
            "zone": {
                "clearable": False,
                "options": [],
            },
            "supplier": {
                "clearable": False,
                "options": [],
            },
        },
        row_deletable=not read_only,
        css=DROPDOWN_TABLE_CSS + [{"selector": 'td[data-dash-column^="move"]', "rule": "cursor: pointer"}],
        style_cell_conditional=[
            {
                "if": {
                    "column_id": "priority",
                },
                "width": PRIORITY_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "width": SCRAP_TYPE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "width": ZONE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "supplier",
                },
                "width": SUPPLIER_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "base_delta",
                },
                "width": PRICE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "move_up",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "move_up",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "move_down",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "move_down",
                },
                "text-align": "center",
            },
        ],
    )


def create_unmapped_scrap_suppliers_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=UNMAPPED_SCRAP_SUPPLIER_TABLE,
        columns=[
            {"name": "Načítaná hodnota", "id": "input_scrap_supplier", "type": "text"},
            {
                "name": "Priradiť dodávateľa",
                "id": "scrap_supplier",
                "presentation": "dropdown",
                "editable": True,
            },
        ],
        style_cell_conditional=[{"if": {"column_id": "scrap_supplier"}, "textAlign": "left"}],
        dropdown={},
        css=DROPDOWN_TABLE_CSS,
    )


def get_scrap_type_dropdown_options() -> List[Dict]:
    return [{"label": scrap_type_name, "value": scrap_type_name} for scrap_type_name in SUPPORTED_SCRAP_TYPES]


def create_unmapped_scrap_types_table(table_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=[
            {"name": "Načítaná hodnota", "id": "input_scrap_type", "type": "text"},
            {"name": "Priradiť typ šrotu", "id": "scrap_type", "presentation": "dropdown", "editable": True},
        ],
        data=[],
        style_cell_conditional=[{"if": {"column_id": "scrap_type"}, "textAlign": "left"}],
        dropdown={
            "scrap_type": {
                "clearable": False,
                "options": get_scrap_type_dropdown_options(),
            }
        },
        css=DROPDOWN_TABLE_CSS,
    )


def create_production_plan_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=PRODUCTION_PLAN_TABLE_ID,
        columns=[
            {"name": "Akosť", "id": "scrap_grade_name", "type": "text"},
            {
                "name": "Množstvo",
                "id": "scrap_amount",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"),
            },
        ],
        data=[],
        page_action="native",
        page_size=20,
    )


def get_scrap_mapping_section(section_id: str, table_id: str, button_id: str) -> html.Section:
    return html.Section(
        id=section_id,
        style={"display": "none"},
        className="text-center",
        children=[
            html.H4("Nenamapované typy šrotu", className="mb-3"),
            dbc.Col(
                children=[
                    create_unmapped_scrap_types_table(table_id),
                ],
                className="mb-3",
            ),
            dbc.Button("Uložiť & načítať", id=button_id, n_clicks=0, color="primary", className="mb-3"),
        ],
    )


def get_intro_section(read_only: bool = False) -> html.Section:
    return html.Section(
        style={
            "maxWidth": "450px",
            "width": "100%",
        },
        className="mx-auto",
        children=[
            html.Div(
                className="text-center",
                children=[
                    html.H4("Názov", className="mb-3"),
                    dbc.Input(
                        id=SCRAP_PURCHASE_TITLE_INPUT,
                        debounce=True,
                        disabled=read_only,
                        className="mb-5 text-center",
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                        },
                    ),
                ],
            ),
            html.Div(
                className="text-center",
                children=[
                    html.H4("Dátum", className="mb-3"),
                    dcc.DatePickerSingle(
                        id=PURCHASE_DATE_INPUT,
                        display_format="DD.MM.YYYY",
                        clearable=not read_only,
                        first_day_of_week=1,
                        disabled=read_only,
                        placeholder="",
                    ),
                ],
            ),
        ],
    )


def get_upload_excel_file_element(
    element_id: str,
    text_id: str,
    text_placeholder: str = "Vyberte súbor...",
    button_text: str = "Import",
    read_only: bool = False,
) -> dcc.Upload:
    return dcc.Upload(
        id=element_id,
        accept=".xlsx, .xls",
        multiple=False,
        disabled=read_only,
        className="d-flex",
        children=[
            dbc.InputGroup(
                [
                    dbc.Input(
                        id=text_id,
                        placeholder=text_placeholder,
                        disabled=True,
                        # TODO: this style should be globally defined
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                        },
                    ),
                ]
            ),
            html.Span() if read_only else dbc.Button(button_text, color="primary", className="mr-1"),
        ],
    )


def get_scrap_state_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=SCRAP_STATE_TABLE,
        columns=[
            {
                "name": "Typ šrotu",
                "id": "scrap_type",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Zásoby",
                "id": "state_weight",
                "type": "numeric",
                "editable": False,
                "format": Format(
                    scheme=Scheme.fixed,
                    precision=3,
                    symbol="$",
                    symbol_suffix=" t",
                ),
            },
            {
                "name": "Na ceste",
                "id": "on_the_way_weight",
                "type": "numeric",
                "format": Format(
                    scheme=Scheme.fixed,
                    precision=3,
                    symbol="$",
                    symbol_suffix=" t",
                ),
            },
        ],
        data=[],
    )


def get_scrap_purchased_recommended_pivot_table_columns() -> List[Dict]:
    return [
        {"name": name, "id": id_, "type": "text", "editable": False}
        for name, id_ in [
            ("Typ šrotu", "scrap_type"),
            ("Z1", "zone_1"),
            ("Z2", "zone_2"),
            ("Z3", "zone_3"),
            ("Z4", "zone_4"),
            ("CZ", "zone_cz"),
            ("HU", "zone_hu"),
            ("PL", "zone_pl"),
            ("Total", "total"),
        ]
    ]


def get_scrap_purchased_recommended_pivot_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=SCRAP_PURCHASED_RECOMMENDED_PIVOT_TABLE_ID,
        columns=get_scrap_purchased_recommended_pivot_table_columns(),
        data=[],
        style_data_conditional=[
            {
                "if": {
                    "filter_query": '{scrap_type} contains "Total"',
                },
                "fontWeight": "bold",
            }
        ],
    )


def get_realized_scrap_offers_columns(read_only: bool = False, debug_mode: bool = False) -> List[Dict]:
    realized_scrap_offers_columns = list()
    if not read_only:
        realized_scrap_offers_columns.extend(
            [
                {"name": "", "id": "delete", "type": "text", "editable": False},
            ]
        )
    if debug_mode:
        realized_scrap_offers_columns.extend(
            [
                {"name": "SO-id-list", "id": "scrap_offer_uuid_list", "type": "text", "editable": False},
            ]
        )
    realized_scrap_offers_columns.extend(
        [
            {
                "name": "Typ šrotu",
                "id": "scrap_type",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Zóna",
                "id": "zone",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Objem",
                "id": "weight",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"),
                "editable": False,
            },
            {
                "name": "Dodávateľ",
                "id": "supplier",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Realizovaná cena",
                "id": "price",
                "type": "numeric",
                "editable": False,
                "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
            },
            {
                "name": "Poznámka",
                "id": "note",
                "type": "text",
                "editable": False,
            },
        ]
    )
    return realized_scrap_offers_columns


def get_realized_scrap_offers_table(read_only: bool = False) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=REALIZED_SCRAP_OFFERS_TABLE,
        columns=get_realized_scrap_offers_columns(read_only=read_only, debug_mode=False),
        data=[],
        style_cell={
            "whiteSpace": "normal",
            "height": "auto",
        },
        style_cell_conditional=[
            {
                "if": {
                    "column_id": "delete",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "delete",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "width": SCRAP_TYPE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "width": ZONE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "weight",
                },
                "width": WEIGHT_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "supplier",
                },
                "width": SUPPLIER_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "price",
                },
                "width": PRICE_COLUMN_WIDTH,
            },
        ],
        css=[
            {"selector": 'td[data-dash-column="delete"]', "rule": "cursor: pointer"},
        ],
    )


# TODO: find more effective way for debug mode
def get_scrap_offers_table_columns(read_only: bool = False, debug_mode: bool = False) -> List[Dict]:
    scrap_offers_table_columns = list()
    if debug_mode:
        scrap_offers_table_columns.extend(
            [
                {
                    "name": "uuid",
                    "id": "uuid",
                    "type": "text",
                },
                {"name": "gen-from", "id": "generated_from", "type": "text"},
            ]
        )
    scrap_offers_table_columns.extend(
        [
            {
                "name": "",
                "id": "edit_offer",
                "type": "text",
            },
            {"name": "", "id": "generated", "type": "text"},
            {
                "name": "Typ šrotu",
                "id": "scrap_type",
                "type": "text",
            },
            {
                "name": "Zóna",
                "id": "zone",
                "type": "text",
            },
            {
                "name": "Dodávateľ",
                "id": "supplier",
                "type": "text",
            },
            {"name": "Stanica", "id": "station", "type": "text"},
            {
                "name": "Objem",
                "id": "weight",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"),
            },
            {
                "name": "Ich cena",
                "id": "supplier_price",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
            },
            {
                "name": "Cena (prepísaná)",
                "id": "override_price",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
            },
            {
                "name": "Cena z minulého mesiaca + Delta (Naša cena)",
                "id": "price_with_delta",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
            },
            {
                "name": "Odporúčanie",
                "id": "recommendation",
                "type": "numeric",
                "format": Format(scheme=Scheme.fixed, precision=2),
            },
            {
                "name": "Poznámka",
                "id": "note",
                "type": "text",
            },
            {
                "name": "Graf",
                "id": "show_price_plot",
                "type": "text",
            },
            {
                "name": "Delta pravidlá",
                "id": "base_delta_rules",
                "type": "any",
            },
        ]
    )
    if not read_only:
        scrap_offers_table_columns.extend(
            [
                {
                    "name": "",
                    "id": "purchase",
                    "type": "text",
                },
            ]
        )
    return scrap_offers_table_columns


def get_scrap_offers_table(read_only: bool = False) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=SCRAP_OFFERS_TABLE,
        columns=get_scrap_offers_table_columns(read_only=read_only, debug_mode=False),
        dropdown={},
        filter_action="native",
        style_cell={
            "whiteSpace": "normal",
            "height": "auto",
        },
        style_cell_conditional=[
            {
                "if": {
                    "column_id": "show_price_plot",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "edit_offer",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "show_price_plot",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "edit_offer",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "purchase",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "generated",
                },
                "width": ICON_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "generated",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "width": ZONE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "zone",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "width": SCRAP_TYPE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "text-align": "center",
            },
            {"if": {"column_id": "price_with_delta"}, "width": PRICE_COLUMN_WIDTH},
            {"if": {"column_id": "supplier_price"}, "width": PRICE_COLUMN_WIDTH},
            {"if": {"column_id": "override_price"}, "width": PRICE_COLUMN_WIDTH},
            {"if": {"column_id": "recommendation"}, "width": RECOMMENDATION_COLUMN_WIDTH},
            {"if": {"column_id": "weight"}, "width": WEIGHT_COLUMN_WIDTH},
            {"if": {"column_id": "base_delta_rules"}, "width": BASE_DELTA_RULES_COLUMN_WIDTH},
            {"if": {"column_id": "supplier"}, "width": SUPPLIER_COLUMN_WIDTH},
            {"if": {"column_id": "purchase"}, "width": PURCHASE_COLUMN_WIDTH},
            {"if": {"column_id": "station"}, "width": SUPPLIER_COLUMN_WIDTH},
        ],
        css=DROPDOWN_TABLE_CSS
        + [
            {"selector": 'td[data-dash-column="show_price_plot"]', "rule": "cursor: pointer"},
            {"selector": 'td[data-dash-column="purchase"]', "rule": "cursor: pointer"},
            {"selector": 'td[data-dash-column="edit_offer"]', "rule": "cursor: pointer"},
        ],
        style_data_conditional=[
            {
                "if": {"filter_query": '{base_delta_rules} eq ""'},
                "backgroundColor": "#ffffcc",
            },
            {
                "if": {
                    "column_id": "override_price",
                    "filter_query": "{price_with_delta} is nil && {override_price} is nil",
                },
                "backgroundColor": "tomato",
            },
        ],
        data=[],
        page_action="native",
        page_size=SCRAP_OFFERS_TABLE_PAGE_SIZE,
        derived_viewport_indices=[],
    )


def get_parsed_data_table(table_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=[
            {
                "name": "Typ šrotu",
                "id": "input_scrap_type",
                "type": "text",
                "editable": False,
            },
            {
                "name": "Množstvo",
                "id": "weight",
                "type": "numeric",
                "editable": False,
                "format": Format(
                    scheme=Scheme.fixed,
                    precision=3,
                ),
            },
        ],
        data=[],
    )


def get_spacer() -> html.Div:
    return html.Div(style={"height": SPACER_BASIC_HEIGHT})


def get_scrap_stock_section(read_only: bool = False) -> html.Section:
    return html.Section(
        children=[
            get_scrap_mapping_section(
                section_id=SCRAP_STATE_MAPPING_SECTION,
                table_id=SCRAP_STATE_MAPPING_TABLE,
                button_id=SCRAP_STATE_SAVE_MAPPINGS,
            ),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    get_excel_icon_link("/static/scrap/img/scrap-state-excel-template.jpg"),
                    html.Div(
                        style=FLEX_GROW_1_STYLE,
                        children=[
                            get_upload_excel_file_element(
                                element_id=UPLOAD_SCRAP_STATE_ID,
                                text_id=SCRAP_STATE_FILENAME_ID,
                                text_placeholder="Vyberte súbor s evidenciou šrotu...",
                                button_text="Import",
                                read_only=read_only,
                            ),
                        ],
                    ),
                    dbc.Button(
                        "Dáta",
                        id=SHOW_SCRAP_STATE_PARSED_DATA_BUTTON,
                        outline=True,
                        color="info",
                        n_clicks=0,
                    ),
                ],
            ),
            dbc.Collapse(
                children=[
                    get_spacer(),
                    dbc.Col(children=[get_parsed_data_table(SCRAP_STATE_PARSED_DATA_TABLE)]),
                    html.Hr(),
                ],
                id=SCRAP_STATE_PARSED_DATA_COLLAPSE,
                is_open=False,
            ),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    get_excel_icon_link("/static/scrap/img/scrap-on-the-way-template.jpg"),
                    html.Div(
                        style=FLEX_GROW_1_STYLE,
                        children=[
                            get_upload_excel_file_element(
                                element_id=SCRAP_ON_THE_WAY_UPLOAD_ID,
                                text_id=SCRAP_ON_THE_WAY_FILENAME_ID,
                                text_placeholder="Vyberte súbor so šrotom na ceste...",
                                button_text="Import",
                                read_only=read_only,
                            ),
                        ],
                    ),
                    dbc.Button(
                        "Dáta",
                        id=SHOW_SCRAP_ON_THE_WAY_PARSED_DATA_BUTTON,
                        outline=True,
                        color="info",
                        n_clicks=0,
                    ),
                ],
            ),
            dbc.Collapse(
                children=[
                    get_spacer(),
                    dbc.Col(children=[get_parsed_data_table(SCRAP_ON_THE_WAY_PARSED_DATA_TABLE)]),
                    html.Hr(),
                ],
                id=SCRAP_ON_THE_WAY_PARSED_DATA_COLLAPSE,
                is_open=False,
            ),
            get_spacer(),
            dbc.Col(
                width=12,
                children=[
                    get_scrap_state_table(),
                ],
            ),
            get_spacer(),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    html.Span(
                        "Cieľová zásoba šrotu",
                        className="mr-1 font-weight-bold",
                        style={"whiteSpace": "nowrap"},
                    ),
                    dbc.Input(
                        id=SCRAP_STOCK_OBJECTIVE_INPUT,
                        type="number",
                        # style=TEXT_ALIGN_RIGHT_STYLE,
                        debounce=True,
                        disabled=read_only,
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                            "textAlign": "right",
                        },
                    ),
                    html.Span("ton", className="ml-1 font-weight-bold"),
                ],
            ),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    html.Span(
                        "Hmotnosť šrotovej vsádzky (očakávaná)",
                        className="mr-1 font-weight-bold",
                        style={"whiteSpace": "nowrap"},
                    ),
                    dbc.Input(
                        id=MEAN_SCRAP_WEIGHT_INPUT,
                        type="number",
                        debounce=True,
                        disabled=read_only,
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                            "textAlign": "right",
                        },
                    ),
                    html.Span("ton", className="ml-1 font-weight-bold"),
                ],
            ),
        ],
    )


def get_date_picking_element(
    date_picker_id: str,
    button_id: str,
    date_picker_placeholder: str = "Zvoľte dátum...",
    button_text: str = "Načítaj",
    read_only: bool = False,
) -> html.Div:
    return html.Div(
        style={**DISPLAY_FLEX_STYLE, **{"justifyContent": "flex-end"}},
        children=[
            dcc.DatePickerSingle(
                id=date_picker_id,
                display_format="DD.MM.YYYY",
                clearable=not read_only,
                placeholder=None if read_only else date_picker_placeholder,
                first_day_of_week=1,
                disabled=read_only,
            ),
            (
                html.Span(id=button_id)
                if read_only
                else dbc.Button(
                    button_text,
                    id=button_id,
                    color="primary",
                    disabled=read_only,
                )
            ),
        ],
    )


def get_production_plan_section(read_only: bool = False, input_data_app: bool = False) -> html.Section:

    children = list()
    if input_data_app:
        children.extend(
            [
                html.Div(
                    className="d-flex align-items-center mr-3",
                    children=[
                        html.Span(
                            "Počet týždňov", style={"whiteSpace": "nowrap"}, className="font-weight-bold mr-1"
                        ),
                        dbc.Input(
                            id=PRODUCTION_PLAN_NR_OF_WEEKS_ID,
                            type="number",
                            step=1,
                            min=1,
                            value=4,
                            debounce=True,
                            disabled=read_only,
                            style={
                                "outline": "0",
                                "borderWidth": "0 0 2px",
                                "backgroundColor": "transparent",
                            },
                        ),
                        html.Span("Dátum", style={"whiteSpace": "nowrap"}, className="font-weight-bold mx-1"),
                        dcc.DatePickerSingle(
                            id=PRODUCTION_PLAN_DATE_PICKER_ID,
                            display_format="DD.MM.YYYY",
                            clearable=not read_only,
                            first_day_of_week=1,
                            disabled=read_only,
                            placeholder="Zvoľte dátum...",
                        ),
                    ],
                ),
                html.Div(className="d-flex align-items-center mr-3", children=[]),
            ]
        )
    else:
        children.extend(
            [
                html.H4("Počet týždňov", className="mb-3"),
                dbc.Input(
                    id=PRODUCTION_PLAN_NR_OF_WEEKS_ID,
                    type="number",
                    step=1,
                    min=1,
                    value=4,
                    debounce=True,
                    disabled=read_only,
                    className="mb-5 text-center mx-auto",
                    style={
                        "outline": "0",
                        "borderWidth": "0 0 2px",
                        "backgroundColor": "transparent",
                        "fontSize": "35px",
                        "maxWidth": "100px",
                    },
                ),
                html.H4("Dátum", className="mb-3"),
                dcc.DatePickerSingle(
                    id=PRODUCTION_PLAN_DATE_PICKER_ID,
                    display_format="DD.MM.YYYY",
                    clearable=not read_only,
                    first_day_of_week=1,
                    disabled=read_only,
                    placeholder="Zvoľte dátum...",
                ),
                get_spacer(),
            ]
        )

    children.extend(
        [
            (
                html.Span()
                if read_only
                else dbc.Button(
                    "Načítaj plán výroby",
                    id=PRODUCTION_PLAN_LOAD_BUTTON_ID,
                    color="primary",
                    size="lg",
                    disabled=read_only,
                )
            ),
            get_spacer(),
            dbc.Col(
                width=12,
                children=[
                    create_production_plan_table(),
                ],
            ),
            get_spacer(),
            get_spacer(),
            get_spacer(),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    html.Span(
                        "Očakávaná produkcia ocele",
                        className="mr-1 font-weight-bold",
                        style={"whiteSpace": "nowrap"},
                    ),
                    dbc.Input(
                        id=EXPECTED_STEEL_PRODUCTION_INPUT,
                        type="number",
                        debounce=True,
                        disabled=read_only,
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                            "textAlign": "right",
                        },
                    ),
                    html.Span("ton", className="ml-1 font-weight-bold"),
                ],
            ),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    html.Span(
                        "Brámy na export",
                        className="mr-1 font-weight-bold",
                        style={"whiteSpace": "nowrap"},
                    ),
                    dbc.Input(
                        id=EXPORT_SLABS_WEIGHT_INPUT,
                        type="number",
                        debounce=True,
                        disabled=read_only,
                        style={
                            "outline": "0",
                            "borderWidth": "0 0 2px",
                            "backgroundColor": "transparent",
                            "textAlign": "right",
                        },
                    ),
                    html.Span("ton", className="ml-1 font-weight-bold"),
                ],
            ),
        ]
    )
    return html.Section(className="text-center", children=children)


def get_delta_rules_section(read_only: bool = False) -> html.Section:
    return html.Section(
        style={
            "maxWidth": "1000px",
            "margin-left": "auto",
            "margin-right": "auto",
        },
        children=[
            html.H4("Delta pravidlá"),
            dbc.Col(
                width=12,
                children=[
                    get_base_delta_rules_table(read_only=read_only),
                ],
            ),
            html.Div(
                children=[
                    (
                        html.Span()
                        if read_only
                        else dbc.Button(
                            "Pridať pravidlo",
                            id=BASE_DELTA_RULES_ADD_BUTTON,
                            color="primary",
                            n_clicks=0,
                            className="mt-2",
                        )
                    ),
                ],
                className="text-center",
            ),
        ],
    )


def get_scrap_offers_parsed_data_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=SCRAP_OFFERS_PARSED_DATA_TABLE,
        data=[],
        columns=[
            {"name": "Dodávateľ", "id": "supplier", "type": "text"},
            {"name": "Skupina šrotu", "id": "input_scrap_type", "type": "text"},
            {"name": "Množstvo", "id": "quantity", "type": "numeric"},
            {"name": "Cena", "id": "price", "type": "numeric"},
            {"name": "Zóna", "id": "zone", "type": "text"},
            {"name": "Stanica", "id": "station", "type": "text"},
            {"name": "Krajina", "id": "country", "type": "text"},
            {"name": "Poznámka", "id": "note", "type": "text"},
        ],
        page_action="native",
        page_size=50,
    )


def get_scrap_supplier_mapping_section() -> html.Section:
    return html.Section(
        id=UNMAPPED_SCRAP_SUPPLIER_SECTION,
        style={"display": "none"},
        children=[
            dbc.Col(
                className="text-center",
                width=12,
                children=[
                    html.H4("Nenamapovaní dodávatelia:", className="mb-3"),
                    create_unmapped_scrap_suppliers_table(),
                    dbc.Button(
                        "Uložiť & načítať",
                        id=UNMAPPED_SCRAP_SUPPLIER_SAVE,
                        n_clicks=0,
                        color="primary",
                        className="my-3",
                    ),
                    get_spacer(),
                ],
            ),
        ],
    )


def get_overall_purchase_table() -> dash_table.DataTable:
    return dash_table.DataTable(
        id=OVERALL_PURCHASE_TABLE,
        data=[],
        columns=[
            {"name": "Typ šrotu", "id": "scrap_type", "type": "text", "editable": False},
            {
                "name": "Celkovo",
                "id": "quantity",
                "type": "numeric",
                "editable": False,
                "format": Format(scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"),
            },
            {
                "name": "Cena - vážený priemer",
                "id": "price",
                "type": "numeric",
                "editable": False,
                "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
            },
        ],
        style_cell={
            "whiteSpace": "normal",
            "height": "auto",
        },
        style_cell_conditional=[
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "width": SCRAP_TYPE_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "scrap_type",
                },
                "text-align": "center",
            },
            {
                "if": {
                    "column_id": "quantity",
                },
                "width": WEIGHT_COLUMN_WIDTH,
            },
            {
                "if": {
                    "column_id": "price",
                },
                "width": PRICE_COLUMN_WIDTH,
            },
        ],
    )


def get_overall_purchase_section() -> html.Section:
    return html.Section(
        children=[
            html.H4("Celkovo nakúpené"),
            dbc.Row(
                children=[
                    dbc.Col(
                        width=12,
                        children=[
                            dbc.Col(
                                children=[
                                    get_overall_purchase_table(),
                                ]
                            )
                        ],
                    ),
                ]
            ),
        ]
    )


def get_excel_icon_link(href: str) -> dcc.Link:
    return dcc.Link(
        target="_blank",
        href=href,
        children=[
            html.Img(
                src="/static/scrap/img/excel-icon.png",
                className="mr-1",
                style={
                    "height": "30px",
                },
            ),
        ],
    )


def get_offers_import_section(read_only: bool = False) -> html.Section:
    return html.Section(
        children=[
            get_scrap_mapping_section(
                section_id=SCRAP_OFFERS_MAPPING_SECTION,
                table_id=SCRAP_OFFERS_MAPPING_TABLE,
                button_id=SCRAP_OFFERS_SAVE_MAPPINGS,
            ),
            get_scrap_supplier_mapping_section(),
            html.Div(
                className="d-flex align-items-center",
                children=[
                    get_excel_icon_link("/static/scrap/img/scrap-offers-excel-template.jpg"),
                    html.Div(
                        style=FLEX_GROW_1_STYLE,
                        children=[
                            get_upload_excel_file_element(
                                element_id=UPLOAD_SCRAP_OFFERS_ID,
                                text_id=SCRAP_OFFERS_FILENAME_ID,
                                text_placeholder="Vyberte súbor s ponukami...",
                                button_text="Import",
                                read_only=read_only,
                            ),
                        ],
                    ),
                    dbc.Button(
                        "Dáta",
                        id=SHOW_SCRAP_OFFERS_PARSED_DATA_BUTTON,
                        outline=True,
                        color="info",
                        n_clicks=0,
                    ),
                ],
            ),
            get_spacer(),
            dbc.Collapse(
                children=[
                    dbc.Col(
                        children=[
                            get_scrap_offers_parsed_data_table(),
                        ]
                    ),
                    get_spacer(),
                    get_spacer(),
                ],
                id=SCRAP_OFFERS_PARSED_DATA_COLLAPSE,
                is_open=False,
            ),
        ]
    )


def get_scrap_purchased_recommended_pivot_section() -> html.Section:
    return html.Section(
        children=[
            html.H4("Realizované ( Odporúčané / Dostupné )"),
            dbc.Col(children=[get_scrap_purchased_recommended_pivot_table()]),
        ]
    )


def get_realized_offers_export_button() -> dbc.Col:
    return dbc.Col(
        width=12,
        className="text-center",
        children=[
            dcc.Link(
                "Export",
                id=REALIZED_SCRAP_OFFERS_TABLE_EXPORT,
                href="#",
                target="_blank",
                className="btn btn-outline-info btn-sm",
            ),
        ],
    )


def get_realized_offers_section(read_only: bool = False) -> html.Section:
    return html.Section(
        children=[
            html.H4("Realizované ponuky"),
            dbc.Col(
                children=[
                    get_realized_scrap_offers_table(read_only=read_only),
                ]
            ),
            dbc.Modal(
                [
                    dbc.ModalHeader("Zmazanie realizovanej ponuky"),
                    dbc.ModalBody(id=DELETE_REALIZED_OFFER_MODAL_BODY, children=[]),
                    dbc.ModalFooter(
                        dbc.Button(
                            "Zmazať",
                            n_clicks=0,
                            color="danger",
                            id=DELETE_REALIZED_OFFER_CONFIRM,
                        )
                    ),
                ],
                is_open=False,
                id=DELETE_REALIZED_OFFER_MODAL,
            ),
        ]
        + ([get_spacer(), get_realized_offers_export_button()] if not read_only else [])
    )


def get_computation_section(read_only: bool = False) -> html.Section:
    all_children = [
        dbc.Progress(
            "",
            value=0.0,
            color="warning",
            style={"flexGrow": "1"},
            id=APPLIED_DELTA_RULES_PROGRESS_BAR,
        )
    ]
    if not read_only:
        all_children.extend(
            [
                dbc.Button(
                    "Prepočítať",
                    className="mx-2",
                    disabled=True,
                    id=RUN_COMPUTATION_BUTTON,
                    color="warning",
                ),
                dbc.Progress(
                    "0%",
                    value=0.0,
                    style={"flexGrow": "1"},
                    className="d-none",
                    id=PROGRESS_BAR_ID,
                    animated=True,
                ),
            ]
        )

    return html.Section(className="d-flex align-items-center w-100", children=all_children)


def get_offers_section(read_only: bool = False) -> html.Section:
    return html.Section(
        children=[
            html.H4("Ponuky"),
            dbc.Row(
                children=[
                    dbc.Col(
                        width=12,
                        children=[
                            dbc.Col(
                                children=[
                                    get_scrap_offers_table(read_only=read_only),
                                ]
                            )
                        ],
                    ),
                ]
            ),
            (
                html.Span()
                if read_only
                else html.Div(
                    className="text-center",
                    children=[
                        dbc.Button(
                            "Pridať ponuku",
                            id=ADD_NEW_SCRAP_OFFER_BUTTON_ID,
                            color="primary",
                            n_clicks=0,
                            className="mt-2",
                        )
                    ],
                )
            ),
            get_spacer(),
            html.Div(
                id=SCRAP_PRICE_PLOT_SECTION,
                className="text-center",
                children=[
                    dcc.Graph(
                        id=SCRAP_PRICE_PLOT,
                    ),
                    dbc.Button(
                        "Skryť graf",
                        id=SCRAP_PRICE_PLOT_HIDE_BUTTON,
                        color="primary",
                        n_clicks=0,
                        className="mt-2",
                    ),
                ],
            ),
            html.Hr(),
            dbc.Modal(
                [
                    dbc.ModalHeader("Upraviť/vytvoriť ponuku"),
                    dbc.ModalBody(
                        children=[
                            html.Div(
                                [
                                    dbc.Label("Typ šrotu"),
                                    dbc.Select(
                                        id=CREATE_EDIT_OFFER_MODAL_SCRAP_TYPE,
                                        options=get_scrap_type_dropdown_options(),
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Zóna"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_ZONE,
                                        type="text",
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Dodávateľ"),
                                    dbc.Select(
                                        id=CREATE_EDIT_OFFER_MODAL_SUPPLIER,
                                        options=[],
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Stanica"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_STATION,
                                        type="text",
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Objem"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_WEIGHT,
                                        type="number",
                                        min=0,
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Ich cena"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_PRICE,
                                        type="number",
                                        min=0,
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Prepísaná cena"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_OVERRIDE_PRICE,
                                        type="number",
                                        min=0,
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Poznámka"),
                                    dbc.Input(
                                        id=CREATE_EDIT_OFFER_MODAL_NOTE,
                                        type="text",
                                        debounce=True,
                                    ),
                                ]
                            ),
                        ]
                    ),
                    dbc.ModalFooter(
                        children=[
                            dbc.Button(
                                "Zmazať ponuku",
                                n_clicks=0,
                                color="danger",
                                id=CREATE_EDIT_OFFER_MODAL_DELETE,
                            ),
                            dbc.Button(
                                "Uložiť",
                                n_clicks=0,
                                color="primary",
                                id=CREATE_EDIT_OFFER_MODAL_CONFIRM,
                                disabled=True,
                            ),
                        ],
                        style={
                            **DISPLAY_FLEX_STYLE,
                            **FLEX_JUSTIFY_CONTENT_SPACE_BETWEEN,
                        },
                    ),
                ],
                is_open=False,
                id=CREATE_EDIT_OFFER_MODAL_WINDOW,
            ),
            dbc.Modal(
                [
                    dbc.ModalHeader("Nákup šrotu"),
                    dbc.ModalBody(
                        children=[
                            html.Div(id=BUY_SCRAP_MODAL_OFFER_INFO, children=[]),
                            html.Div(
                                [
                                    dbc.Label("Množstvo (ton)"),
                                    dbc.Input(
                                        id=BUY_SCRAP_MODAL_AMOUNT,
                                        type="number",
                                        debounce=True,
                                    ),
                                ]
                            ),
                            html.Div(
                                [
                                    dbc.Label("Cena"),
                                    dbc.Input(
                                        id=BUY_SCRAP_MODAL_PRICE,
                                        type="number",
                                        debounce=True,
                                    ),
                                ]
                            ),
                        ]
                    ),
                    dbc.ModalFooter(
                        dbc.Button(
                            "Kúpiť",
                            n_clicks=0,
                            color="primary",
                            id=BUY_SCRAP_MODAL_CONFIRMATION_BUTTON,
                            disabled=True,
                        )
                    ),
                ],
                is_open=False,
                id=BUY_SCRAP_MODAL_WINDOW,
            ),
        ],
    )


def get_back_button(button_id: str) -> dbc.Button:
    return dbc.Button(
        "Späť",
        id=button_id,
        color="light",
    )


def get_main_div(main_div_id: str, children: List[Any], fluid: bool = True) -> html.Div:
    return html.Div(
        id=main_div_id,
        children=[
            get_spacer(),
            dbc.Container(
                children=children,
                fluid=fluid,
            ),
        ],
        style={"margin-top": "50px"},
    )


def get_navbar() -> dbc.Navbar:
    loading_info = dbc.Col(
        dcc.Loading(
            id=LOADING_ELEMENT,
            type="dot",
            className="mx-auto",
            children=[
                html.Div(
                    className="text-left text-primary my-auto",
                    id=STATUS_ID,
                    style={
                        "width": "100%",
                        "white-space": "nowrap",
                        "overflow": "visibel",
                    },
                    children="",
                ),
                html.Pre(id=DISPLAY_DATA_STORE_ID, hidden=True, children=""),
            ],
        ),
        width=1,
    )
    scrap_purchase_name = dbc.Col(
        children=[],
        id=NAVBAR_SCRAP_PURCHASE_INFO,
        className="text-center my-auto font-weight-bold offset-2",
        style={"font-size": "1.2rem"},
        width=6,
    )
    username = dbc.Col(
        [
            html.Div("", id=USER_NAME_ID),
            html.Div(
                dbc.Button(
                    "",
                    id=USER_IN_CONTROL_NAME_ID,
                    color="link",
                    n_clicks=0,
                    style={"color": "green"},
                    className="p-0",
                ),
                id=USER_IN_CONTROL_NAME_ID + "-div",
                hidden=True,
            ),
        ],
        className="text-right my-auto text-primary",
        width=3,
    )
    return dbc.Navbar(
        dbc.Row(
            [
                loading_info,
                scrap_purchase_name,
                username,
            ],
            align="between",
            className="w-100 align-items-center",
        ),
        color="#f7f7f7",
        className="shadow",
        style={"height": "50px"},
        sticky="sticky",
        fixed="top",
    )


def get_rounded_button_with_icon_and_text(
    button_id: str, button_icon: str, button_text: str = None, button_color: str = "danger"
) -> html.Span:
    all_children = [
        dbc.Button(
            button_icon,
            id=button_id,
            disabled=False,
            className="shadow mb-3",
            color=button_color,
            style={
                "fontSize": "35px",
                "borderRadius": "50%",
            },
        ),
    ]
    if button_text:
        all_children.append(html.H6(button_text))
    return html.Span(
        className="d-flex flex-column justify-content-center align-items-center py-5", children=all_children
    )


def get_finish_scrap_purchase_section() -> html.Section:
    return html.Section(
        children=[
            html.Hr(),
            get_rounded_button_with_icon_and_text(
                button_id=FINISH_PURCHASE_BUTTON, button_icon="🔒", button_text="Uzamknúť nákup"
            ),
            dbc.Modal(
                id=FINISH_PURCHASE_MODAL_WINDOW,
                is_open=False,
                keyboard=False,
                backdrop=True,
                children=[
                    dbc.ModalHeader("Uzamknúť nákup?"),
                    dbc.ModalBody(
                        id=FINISH_PURCHASE_MODAL_BODY,
                        style=DISPLAY_NONE_STYLE,
                        children="Nákup bol uzatvorený. Môžete obnoviť stránku.",
                    ),
                    dbc.ModalFooter(
                        children=[
                            dbc.Button(
                                "Uzamknúť",
                                n_clicks=0,
                                color="primary",
                                id=FINISH_PURCHASE_MODAL_CONFIRMATION,
                            ),
                        ]
                    ),
                ],
            ),
        ]
    )


def get_stepper_section(actual_step: int = 1) -> html.Div:
    max_steps = 4
    if actual_step < 1:
        actual_step = 1
    if actual_step > max_steps:
        actual_step = max_steps
    actual_step = actual_step - 1
    colors = [
        "secondary",
        "secondary",
        "secondary",
        "secondary",
    ]
    colors[actual_step] = "primary"
    for step in range(actual_step):
        colors[step] = "success"

    font_sizes = [
        "75%",
        "75%",
        "75%",
        "75%",
    ]
    font_sizes[actual_step] = "120%"

    return html.Div(
        children=[
            dbc.Badge("Názov a dátum", color=colors[0], className="mx-1", style={"fontSize": font_sizes[0]}),
            dbc.Badge("Stav šrotu", color=colors[1], className="mx-1", style={"fontSize": font_sizes[1]}),
            dbc.Badge("Plán výroby", color=colors[2], className="mx-1", style={"fontSize": font_sizes[2]}),
            dbc.Badge("Ponuky", color=colors[3], className="mx-1", style={"fontSize": font_sizes[3]}),
        ],
        className="mb-5 mt-4 d-flex justify-content-center align-items-center",
    )


def get_wizard_navigation_buttons(
    back_button_id: str, confirm_button_id: str, read_only: bool = False
) -> html.Div:
    if read_only:
        return html.Div()
    childrens = []
    if back_button_id:
        childrens.append(dbc.Button("Späť", id=back_button_id, color="light", className="mx-4"))
    else:
        childrens.append(html.Span())
    childrens.append(
        dbc.Button("Ďalej", id=confirm_button_id, color="primary", size="lg", disabled=True, className="mx-4")
    )
    return html.Div(className="d-flex justify-content-center align-items-center mb-5", children=childrens)


def get_wizard_content_card(children: List[Any]) -> dbc.Card:
    return dbc.Card(
        children=children,
        className="shadow mb-5 p-3",
        style={
            "background-color": "#f7f7f7",
        },
    )


def get_layout(read_only: bool = False) -> html.Div:
    all_children = [
        get_navbar(),
        # TODO: find better place for error messages
        html.Div(id=SCRAP_STATE_ERROR_DIV, children=[]),
        # wizard section
        dbc.Row(
            id=WIZARD_SECTION_ID,
            children=[
                html.Div(
                    id=WIZARD_STEP_1_ID,
                    children=[
                        get_stepper_section(actual_step=1),
                        dbc.Col(
                            className="col-md-6 offset-md-3",
                            children=[
                                get_wizard_content_card(children=get_intro_section(read_only=read_only)),
                                get_wizard_navigation_buttons(
                                    read_only=read_only,
                                    back_button_id="",
                                    confirm_button_id=WIZARD_CONFIRM_1_ID,
                                ),
                            ],
                        ),
                    ],
                    style=DISPLAY_NONE_STYLE,
                ),
                html.Div(
                    id=WIZARD_STEP_2_ID,
                    children=[
                        get_stepper_section(actual_step=2),
                        dbc.Col(
                            className="col-md-6 offset-md-3",
                            children=[
                                get_wizard_content_card(
                                    children=get_scrap_stock_section(read_only=read_only)
                                ),
                                get_wizard_navigation_buttons(
                                    read_only=read_only,
                                    back_button_id=WIZARD_BACK_FROM_STEP_2_ID,
                                    confirm_button_id=WIZARD_CONFIRM_2_ID,
                                ),
                            ],
                        ),
                    ],
                    style=DISPLAY_NONE_STYLE,
                ),
                html.Div(
                    id=WIZARD_STEP_3_ID,
                    children=[
                        get_stepper_section(actual_step=3),
                        dbc.Col(
                            className="col-md-6 offset-md-3",
                            children=[
                                get_wizard_content_card(
                                    children=get_production_plan_section(read_only=read_only)
                                ),
                                get_wizard_navigation_buttons(
                                    read_only=read_only,
                                    back_button_id=WIZARD_BACK_FROM_STEP_3_ID,
                                    confirm_button_id=WIZARD_CONFIRM_3_ID,
                                ),
                            ],
                        ),
                    ],
                    style=DISPLAY_NONE_STYLE,
                ),
                html.Div(
                    id=WIZARD_STEP_4_ID,
                    children=[
                        get_stepper_section(actual_step=4),
                        dbc.Col(
                            className="col-md-10 offset-md-1",
                            children=[
                                get_wizard_content_card(
                                    children=get_offers_import_section(read_only=read_only)
                                ),
                                get_wizard_navigation_buttons(
                                    read_only=read_only,
                                    back_button_id=WIZARD_BACK_FROM_STEP_4_ID,
                                    confirm_button_id=WIZARD_CONFIRM_4_ID,
                                ),
                            ],
                        ),
                    ],
                    style=DISPLAY_NONE_STYLE,
                ),
            ],
            style=DISPLAY_BLOCK_STYLE,
        ),
        # main section
        html.Div(
            id=MAIN_SECTION_ID,
            style=DISPLAY_NONE_STYLE,
            children=[
                dbc.Row(
                    children=[
                        dbc.Col(
                            width=12,
                            className="text-center",
                            children=[
                                dcc.Link(
                                    "Vstupné dáta",
                                    id=INPUT_DATA_LINK_ID,
                                    href="#",
                                    target="_blank",
                                    className="btn btn-outline-info btn-sm",
                                ),
                            ],
                        ),
                        html.Br(),
                        dbc.Col(
                            width=12,
                            children=[
                                get_delta_rules_section(read_only=read_only),
                            ],
                        ),
                        dbc.Col(
                            width=12,
                            className="my-3",
                            children=[
                                get_computation_section(read_only=read_only),
                            ],
                        ),
                        dbc.Col(
                            width=12,
                            children=[
                                get_offers_section(read_only=read_only),
                            ],
                        ),
                    ]
                ),
                dbc.Row(
                    children=[
                        html.Div(
                            className="col-lg-12",
                            children=[get_scrap_purchased_recommended_pivot_section(), get_spacer()],
                        ),
                    ]
                ),
                dbc.Row(
                    children=[
                        html.Div(
                            className="col-lg-6",
                            children=[
                                get_overall_purchase_section(),
                                get_spacer(),
                            ],
                        ),
                        html.Div(
                            className="col-lg-6",
                            children=[
                                get_realized_offers_section(read_only=read_only),
                                get_spacer(),
                            ],
                        ),
                        (
                            html.Span()
                            if read_only
                            else dbc.Col(
                                width=12,
                                children=[
                                    get_finish_scrap_purchase_section(),
                                ],
                            )
                        ),
                    ],
                ),
            ],
        ),
        dcc.Interval(id=COMPUTATION_REFRESH_INTERVAL_ID, interval=1000, n_intervals=0, disabled=True),
        get_full_screen_error_modal(modal_id=ERROR_MODAL_WINDOW_ID),
        html.Div(id=SCRAP_PURCHASE_RECORD_ID_DIV_ID, hidden=True, children=-1),
    ]
    if read_only:
        all_children.append(
            dcc.Interval(id=RELOAD_DATA_INTERVAL_ID, interval=10000, n_intervals=0, disabled=not read_only)
        )
    all_children += [
        get_full_screen_modal(
            REFRESH_REQUEST_MODAL_ID,
            "Prevzatie kontroly prebehlo úspešne",
            "Pre pokračovanie je nutné prenačítať stránku",
        ),
        get_full_screen_modal(
            CONTROL_CHANGED_MODAL_ID,
            "Kontrola bola prevziata iným užívateľom",
            "Pre pokračovanie je nutné prenačítať stránku",
        ),
    ]
    return get_main_div(main_div_id=MAIN_DIV_ID, children=all_children)


def get_input_data_layout() -> html.Div:
    all_children = [
        get_navbar(),
        html.Div(
            # hidden -> name and date are already in navbar, but kept hidden because callbacks are registered
            hidden=True,
            children=[get_intro_section(read_only=True)],
        ),
        dbc.Row(
            children=[
                dbc.Col(
                    className="col-lg-6",
                    children=[
                        html.H3("Stav šrotu"),
                        get_scrap_stock_section(read_only=True),
                        html.Hr(),
                        get_spacer(),
                    ],
                ),
                dbc.Col(
                    className="col-lg-6",
                    children=[
                        html.H3("Plán výroby"),
                        get_production_plan_section(read_only=True, input_data_app=True),
                        html.Hr(),
                        get_spacer(),
                    ],
                ),
            ]
        ),
        dbc.Row(
            children=[
                dbc.Col(
                    children=[
                        html.H3("Ponuky"),
                        get_offers_import_section(read_only=True),
                    ]
                )
            ]
        ),
        # TODO: find better place for error messages
        html.Div(id=SCRAP_STATE_ERROR_DIV, children=[]),
        get_full_screen_error_modal(modal_id=ERROR_MODAL_WINDOW_ID),
        html.Div(id=SCRAP_PURCHASE_RECORD_ID_DIV_ID, hidden=True, children=-1),
    ]
    return get_main_div(main_div_id=MAIN_DIV_ID, children=all_children, fluid=False)
