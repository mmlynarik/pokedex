from datetime import date
import logging
import math
from typing import Dict, List, Optional, Sequence, TypedDict

from dash import dash_table
from dash.dash_table import FormatTemplate as FormatTemplate
from dash.dash_table.Format import Format, Scheme
from scrap_core import Chem

from common.dash import CELL_STYLE, TABLE_HEADER_STYLE, get_colorscale_style
from scrap_core.blendmodel.datamodel import ChemEstimate, ScrapBlendModelOutput
from scrap_core.modelutils import get_ct_risks, get_ct_risk
from scrap_core.correctiontechnologiesmodel.datamodel import CorrectionTechnologiesModelOutput
from usskssgrades import Grade

from ..database_api import steel_grades


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class BlendResultsTableRow(TypedDict):
    chem: Chem
    lower_grade: Optional[float]
    upper_grade: Optional[float]
    lower_model: Optional[float]
    upper_model: Optional[float]
    model_result: Optional[float]
    reality_eob: Optional[float]
    reality_final: Optional[float]
    upper_adjusted: Optional[str]
    upper_error_prob: Optional[float]


BlendResultsTableData = List[BlendResultsTableRow]

COLORSCALE_FORMAT = get_colorscale_style(column="upper_error_prob", minimum=0.0, maximum=1.0, style_row=True)


def create_results_table(element_id: str, real_value_from_db: bool = True) -> dash_table.DataTable:
    columns = [
        {"name": "Prvok", "id": "chem", "type": "text", "editable": False},
        {
            "name": "Spodná hranica gradu",
            "id": "lower_grade",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=3, scheme=Scheme.fixed),
        },
        {
            "name": "Spodná hranica 5% kvantil",
            "id": "lower_model",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=3, scheme=Scheme.fixed),
        },
        {
            "name": "Očakávaná hodnota (model)",
            "id": "model_result",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=4, scheme=Scheme.fixed),
        },
        {
            "name": "Meranie (EOB)",
            "id": "reality_eob",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=4, scheme=Scheme.fixed),
        },
        {
            "name": "Meranie (FINAL)",
            "id": "reality_final",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=4, scheme=Scheme.fixed),
        },
        {
            "name": "Horná hranica 95% kvantil",
            "id": "upper_model",
            "type": "numeric",
            "editable": False,
            "format": Format(precision=3, scheme=Scheme.fixed),
        },
        {"name": "Horná hranica gradu", "id": "upper_adjusted", "type": "text", "editable": False},
        {
            "name": "Riziko prekročenia hornej hranice gradu",
            "id": "upper_error_prob",
            "type": "numeric",
            "editable": False,
            "format": FormatTemplate.percentage(1),
        },
    ]
    if not real_value_from_db:
        columns = [
            column for column in columns if (column["id"] != "reality")
        ]  # pylint: disable=superfluous-parens
    return dash_table.DataTable(
        id=element_id,
        style_cell_conditional=[
            {"if": {"column_id": "chem"}, "width": "40px"},
            {"if": {"column_id": "lower_model"}, "width": "85px"},
            {"if": {"column_id": "lower_grade"}, "width": "85px"},
            {"if": {"column_id": "model_result"}, "width": "95px"},
            {"if": {"column_id": "reality_eob"}, "width": "75px"},
            {"if": {"column_id": "reality_final"}, "width": "75px"},
            {"if": {"column_id": "upper_model"}, "width": "85px"},
            {"if": {"column_id": "upper_adjusted"}, "width": "85px"},
            {"if": {"column_id": "upper_error_prob"}, "width": "115px"},
        ],
        style_data_conditional=COLORSCALE_FORMAT
        + [
            {"if": {"column_id": "chem"}, "textAlign": "left"},
            {"if": {"filter_query": '{chem} = "Tavba"'}, "fontWeight": "bold"},
        ],
        style_table={"margin": "0px auto", "width": "100%"},
        style_header=TABLE_HEADER_STYLE,
        style_cell=CELL_STYLE,
        columns=columns,
        data=[],
        editable=False,
    )


def get_corrected_mean(chem_estimate: ChemEstimate) -> float:
    try:
        return max(0.0, chem_estimate.percentile(0.5))
    except ValueError:
        log.warning(f"Invalid chem estimate - {chem_estimate}")
        return float("nan")


def get_95_lower_bound(chem_estimate: ChemEstimate) -> float:
    try:
        return max(0.0, chem_estimate.percentile(0.05))
    except ValueError:
        log.warning(f"Invalid chem estimate - {chem_estimate}")
        return float("nan")


def get_95_upper_bound(chem_estimate: ChemEstimate) -> float:
    try:
        return max(0.0, chem_estimate.percentile(0.95))
    except ValueError:
        log.warning(f"Invalid chem estimate - {chem_estimate}")
        return float("nan")


def get_grade_lower_bound(chem: Chem, grade: Optional[Grade]) -> Optional[float]:
    if grade is None:
        return None
    limit = grade.get_limit(chem)
    if limit is None:
        return None
    return limit.minimum


def get_grade_upper_bound(chem: Chem, grade: Optional[Grade]) -> Optional[float]:
    if grade is None:
        return None
    limit = grade.get_limit(chem)
    if limit is None:
        return None
    return limit.maximum


def get_grade_upper_adjusted_bound(chem: Chem, grade: Optional[Grade]) -> Optional[str]:
    if chem != "P":
        maximum = get_grade_upper_bound(chem, grade)
        if maximum is None:
            return None
        return f"{maximum:.3f}"
    if grade is None:
        return None
    p_blow_limit = grade.get_limit("P_blow")
    p_limit = grade.get_limit("P")
    if p_blow_limit is None or p_limit is None:
        return None
    return f"{p_blow_limit.maximum:.3f} ({p_limit.maximum:.3f})"


def get_result_table_row(
    chem: Chem,
    model_output: ScrapBlendModelOutput,
    selected_grade: Optional[Grade],
    success_probability: Optional[float],
    oko_output_eob: Optional[ScrapBlendModelOutput],
    oko_output_final: Optional[ScrapBlendModelOutput],
) -> BlendResultsTableRow:
    chem_estimate = model_output.get_chem_estimate(chem)
    oko_result_eob = oko_output_eob.get_chem_estimate(chem) if oko_output_eob is not None else None
    oko_result_final = oko_output_final.get_chem_estimate(chem) if oko_output_final is not None else None
    return {
        "chem": chem,
        "model_result": get_corrected_mean(chem_estimate),
        "reality_eob": get_corrected_mean(oko_result_eob) if oko_result_eob is not None else None,
        "reality_final": get_corrected_mean(oko_result_final) if oko_result_final is not None else None,
        "upper_model": get_95_upper_bound(chem_estimate),
        "lower_model": get_95_lower_bound(chem_estimate),
        "lower_grade": get_grade_lower_bound(chem, selected_grade),
        "upper_grade": get_grade_upper_bound(chem, selected_grade),
        "upper_adjusted": get_grade_upper_adjusted_bound(chem, selected_grade),
        "upper_error_prob": (1.0 - success_probability) if success_probability is not None else None,
    }


def get_summary_row(success_probabilities: Dict[Chem, float]) -> BlendResultsTableRow:
    proba = math.prod(success_probabilities.values())
    return {
        "chem": "Tavba",
        "model_result": None,
        "reality": None,
        "upper_model": None,
        "lower_model": None,
        "lower_grade": None,
        "upper_grade": None,
        "upper_adjusted": None,
        "upper_error_prob": (1.0 - proba),
    }


# TODO change selected_grade type to Optional[Grade]
def create_results_table_data(
    model_output: ScrapBlendModelOutput,
    predicted_chems: Sequence[Chem],
    selected_grade: Optional[int] = None,
    oko_output_eob: Optional[ScrapBlendModelOutput] = None,
    oko_output_final: Optional[ScrapBlendModelOutput] = None,
) -> BlendResultsTableData:
    grade: Optional[Grade] = (
        None if selected_grade is None else steel_grades.get_grade_from_id(selected_grade, date.today())
    )
    upper_success_probs = {}
    summary_row = []
    if grade is not None:
        upper_success_probs = model_output.calculate_probs(grade, predicted_chems)
        summary_row.append(get_summary_row(upper_success_probs))
    return [
        get_result_table_row(
            chem, model_output, grade, upper_success_probs.get(chem), oko_output_eob, oko_output_final
        )
        for chem in sorted(predicted_chems)
    ] + summary_row
