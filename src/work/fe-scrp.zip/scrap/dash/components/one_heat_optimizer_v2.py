import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple, TypeVar, Union

import attr
from immutables import Map
from scrap.dash.database_api import steel_grades
from scrap.models import (
    OptimizationDisplayDataV2,
    RelaxableLowerSummingLimitSetting,
    RelaxableRiskLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScrapChargeDisplayDataV2,
    get_relevant_relaxable_risk_limits_settings,
    get_relevant_relaxable_summing_limits_settings,
    resolve_risk_limit_settings,
    OptimizationInput,
    lower_setting_to_lower_limit,
    upper_setting_to_upper_limit,
    GradeDefinition,
    LoadingStation,
    ChargeInput,
    MultipleHeatsOptimizationResult,
    ScrapCharge,
)
from scrap.tasks import multiple_heats_scrap_optimization
from scrap.utils import get_pig_iron_s_for_grade, get_submodel_results_calculator
from scrap_core import ScrapMix, ScrapMixOrder
from scrap_core.optimization.datamodel import (
    OUTDOOR_SCRAP_NAME,
    AvailableScraps,
    ModelSettings,
    MultipleHeatsOptimizationOutput,
    ScrapExclusiveGroup,
    ScrapMixLimits,
    available_scraps_to_upper_bound_map,
)
from scrap_core.optimization.relaxable_limits import (
    RelaxableLowerSummingLimit,
    RelaxableRiskLimit,
    RelaxableUpperSummingLimit,
)
from scrap_core.optimization.validations import (
    ChargeInfoValidationResult,
    get_max_optimizable_heats,
    join_validation_results,
    scrap_limits_to_dicts,
    validate_available_scraps,
    validate_basket_ids,
    validate_grade_id,
    validate_heat_plan,
    validate_model_settings,
    validate_pig_iron_weight,
    validate_raw_fe_chem,
    validate_scrap_limits,
    validate_total_scrap_weight,
    validate_total_scrap_weight_and_weighted_scrap_bounds,
)

from scrap_core.utils import maximum, normalize_mapping

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


TS = TypeVar(
    "TS",
    bound=Union[
        RelaxableRiskLimitSetting, RelaxableLowerSummingLimitSetting, RelaxableUpperSummingLimitSetting
    ],
)


def validate_charge_info(
    charge_info: Union[ScrapCharge, ScrapChargeDisplayDataV2],
    relaxable_lower_summing_limits_settings: Tuple[RelaxableLowerSummingLimitSetting, ...],
    relaxable_upper_summing_limits_settings: Tuple[RelaxableUpperSummingLimitSetting, ...],
    available_scraps: AvailableScraps,
    model_settings: ModelSettings,
    user_defined_limits: Optional[ScrapMixLimits] = None,
) -> ChargeInfoValidationResult:
    relaxable_upper_summing_limits, relaxable_lower_summing_limits = (), ()
    if charge_info.grade_id is not None:
        relaxable_upper_summing_limits = get_relaxable_upper_summing_limits_for_grade(  # type: ignore
            charge_info.grade_id, relaxable_upper_summing_limits_settings
        )
        relaxable_lower_summing_limits = get_relaxable_lower_summing_limits_for_grade(  # type: ignore
            charge_info.grade_id, relaxable_lower_summing_limits_settings
        )

    # TODO remove "if instance" block, when ScrapChargeDisplayDataV2 is no longer used
    if isinstance(charge_info, ScrapCharge):
        weighted_scrap_lower_bounds = charge_info.get_weighted_scrap_lower_bounds()
    else:
        weighted_scrap_lower_bounds = Map()

    return join_validation_results(
        [
            validate_grade_id(charge_info.grade_id, steel_grades),
            validate_basket_ids(charge_info.basket_ids),
            validate_total_scrap_weight(
                charge_info.total_scrap_weight, model_settings.optimizer_settings.precision_step
            ),
            validate_total_scrap_weight_and_weighted_scrap_bounds(
                weighted_scrap_lower_bounds, charge_info.total_scrap_weight_or_constant
            ),
            validate_pig_iron_weight(charge_info.pig_iron_weight),
            validate_raw_fe_chem(charge_info.raw_fe_chem),
            validate_scrap_limits(
                user_defined_limits or charge_info.scrap_limits,
                charge_info.total_scrap_weight_or_constant,
                available_scraps,
                relaxable_lower_summing_limits,
                relaxable_upper_summing_limits,
                charge_info.grade_id,
                model_settings.optimizer_settings.scrap_mix_mapping,
            ),
            validate_available_scraps(
                available_scraps,
                charge_info.total_scrap_weight_or_constant,
                model_settings.optimizer_settings.heat_plan_optimized_heats + 1,
            ),
            validate_model_settings(model_settings),
            validate_heat_plan(charge_info.heat_plan),
        ]
    )


def get_relaxable_risk_limit_for_grade(
    grade_id: int, limits_settings: Iterable[RelaxableRiskLimitSetting]
) -> RelaxableRiskLimit:
    relevant_limits_settings = get_relevant_relaxable_risk_limits_settings(limits_settings, grade_id)
    return resolve_risk_limit_settings(relevant_limits_settings)


def get_relaxable_lower_summing_limits_for_grade(
    grade_id: int,
    limits_settings: Tuple[RelaxableLowerSummingLimitSetting, ...],
) -> Tuple[RelaxableLowerSummingLimit, ...]:
    relevant_limits_settings = get_relevant_relaxable_summing_limits_settings(limits_settings, grade_id)
    return tuple(lower_setting_to_lower_limit(lim) for lim in relevant_limits_settings)


def get_relaxable_upper_summing_limits_for_grade(
    grade_id: int,
    limits_settings: Tuple[RelaxableUpperSummingLimitSetting, ...],
) -> Tuple[RelaxableUpperSummingLimit, ...]:
    relevant_limits_settings = get_relevant_relaxable_summing_limits_settings(limits_settings, grade_id)
    return tuple(upper_setting_to_upper_limit(lim) for lim in relevant_limits_settings)


def add_outdoor_scrap_to_model_settings(
    model_settings: ModelSettings,
    outdoor_scrap_mixes: ScrapMixOrder,
) -> ModelSettings:
    if not outdoor_scrap_mixes:
        return model_settings
    outdoor_scrap_group = ScrapExclusiveGroup(name=OUTDOOR_SCRAP_NAME, scrap_types=outdoor_scrap_mixes)
    optimizer_settings_with_outdoor = attr.evolve(
        model_settings.optimizer_settings,
        scrap_exclusive_groups=model_settings.optimizer_settings.scrap_exclusive_groups
        + (outdoor_scrap_group,),
    )
    return attr.evolve(model_settings, optimizer_settings=optimizer_settings_with_outdoor)


def resolve_first_charge_scrap_bounds(
    charge_info: Union[ScrapCharge, ScrapChargeDisplayDataV2],
    available_scraps: AvailableScraps,
    user_defined_limits: Optional[ScrapMixLimits] = None,
) -> Tuple[Dict[ScrapMix, float], Dict[ScrapMix, float]]:
    available_scrap_types = tuple(scrap.scrap_type for scrap in available_scraps)
    target_scrap_weight = charge_info.total_scrap_weight_or_constant

    user_defined_lower_bounds, user_defined_upper_bounds = scrap_limits_to_dicts(
        user_defined_limits or charge_info.scrap_limits,
        available_scrap_types,
        target_scrap_weight,
    )

    # TODO remove "if instance" block, when ScrapChargeDisplayDataV2 is no longer used
    if isinstance(charge_info, ScrapCharge):
        weighted_scrap_lower_bounds = charge_info.get_weighted_scrap_lower_bounds()
    else:
        weighted_scrap_lower_bounds = {}

    lower_bounds = maximum(
        normalize_mapping(user_defined_lower_bounds, available_scrap_types, 0),
        normalize_mapping(weighted_scrap_lower_bounds, available_scrap_types, 0),
    )

    upper_bounds = maximum(
        normalize_mapping(user_defined_upper_bounds, available_scrap_types, target_scrap_weight),
        normalize_mapping(weighted_scrap_lower_bounds, available_scrap_types, 0),
    )

    return lower_bounds, upper_bounds


def create_optimization_input(
    charge_info: Union[ScrapCharge, ScrapChargeDisplayDataV2],
    available_scraps: AvailableScraps,
    model_settings: ModelSettings,
    transfer_capacity: int,
    # TODO temporary, for compatibility with frontend v2 only
    loading_station_id: Optional[int] = None,
    user_defined_limits: Optional[ScrapMixLimits] = None,
) -> OptimizationInput:

    first_charge_lower_bounds, first_charge_upper_bounds = resolve_first_charge_scrap_bounds(
        charge_info, available_scraps, user_defined_limits
    )

    scrap_upper_bounds = available_scraps_to_upper_bound_map(available_scraps, transfer_capacity)

    outdoor_scrap_types = tuple(
        scrap.scrap_type for scrap in available_scraps if scrap.location == OUTDOOR_SCRAP_NAME
    )
    model_settings_with_outdoor_scrap = add_outdoor_scrap_to_model_settings(
        model_settings, outdoor_scrap_types
    )

    # TODO remove these two "if instance" blocks, when ScrapChargeDisplayDataV2 is no longer used
    if isinstance(charge_info, ScrapChargeDisplayDataV2) and loading_station_id is None:
        raise AttributeError("Loading station not provided")

    if isinstance(charge_info, ScrapCharge):
        loading_station = charge_info.loading_station
    else:
        loading_station = LoadingStation.objects.get(pk=loading_station_id)

    opt_input = OptimizationInput(
        model_settings=model_settings_with_outdoor_scrap,
        lower_bounds={},
        upper_bounds=dict(scrap_upper_bounds),
        loading_station=loading_station,
    )
    opt_input.save()

    total_optimized_heats = get_max_optimizable_heats(
        available_scraps,
        model_settings.optimizer_settings.heat_plan_optimized_heats + 1,
        charge_info.total_scrap_weight_or_constant,
    )
    log.info(f"Total optimized heats: {total_optimized_heats}")

    first_charge_input = ChargeInput(
        grade_def=GradeDefinition.objects.get_or_create(grade_id=charge_info.grade_id)[0],
        total_scrap_weight=charge_info.total_scrap_weight_or_constant,
        pig_iron_weight=charge_info.pig_iron_weight_or_constant,
        pig_iron_chem=charge_info.raw_fe_chem,
        lower_bounds=first_charge_lower_bounds,
        upper_bounds=first_charge_upper_bounds,
        optimization_input=opt_input,
        order_index=0,
    )

    other_charge_inputs: List[ChargeInput] = []
    if (charge_info.heat_plan is not None) and (total_optimized_heats > 1):
        other_charge_inputs = [
            ChargeInput(
                grade_def=GradeDefinition.objects.get_or_create(grade_id=planned_heat.grade_id)[0],
                total_scrap_weight=charge_info.total_scrap_weight_or_constant,
                pig_iron_weight=charge_info.pig_iron_weight_or_constant,
                pig_iron_chem=attr.evolve(
                    charge_info.raw_fe_chem, S=get_pig_iron_s_for_grade(steel_grades, planned_heat.grade_id)
                ),
                lower_bounds={},
                upper_bounds=dict(scrap_upper_bounds),
                optimization_input=opt_input,
                order_index=idx,
            )
            # We need heat plan offset because scrap for some heats are already prepared
            for idx, planned_heat in enumerate(
                charge_info.heat_plan.heats[
                    model_settings.optimizer_settings.heat_plan_offset : (
                        total_optimized_heats - 1 + model_settings.optimizer_settings.heat_plan_offset
                    )
                ],
                start=1,
            )
        ]

    log.info(f"Number of charge heats: {len([first_charge_input, *other_charge_inputs])}")

    ChargeInput.objects.bulk_create([first_charge_input, *other_charge_inputs])

    return opt_input


# Warning - currently all weights in charge_info are in tons but in available scraps they are in kilograms
# TODO make everything in kilos
# FIXME add loading_station as temporary parameter until ScrapChargeDisplayDataV2 is removed
def optimize_multiple_heats(
    charge_info: Union[ScrapCharge, ScrapChargeDisplayDataV2],
    available_scraps: AvailableScraps,
    model_settings: ModelSettings,
    transfer_capacity: int,
    loading_station_id: Optional[int] = None,
) -> OptimizationDisplayDataV2:

    opt_input = create_optimization_input(
        charge_info, available_scraps, model_settings, transfer_capacity, loading_station_id
    )

    first_charge_input = opt_input.charge_inputs.get(order_index=0)

    errors, warnings = validate_charge_info(
        charge_info,
        first_charge_input.lower_summing_settings,
        first_charge_input.upper_summing_settings,
        available_scraps,
        model_settings,
    )
    if errors:
        raise ValueError(f"Invalid charge info: {errors}")

    # TODO remove this if-block, when ScrapChargeDisplayDataV2 is removed
    if isinstance(charge_info, ScrapCharge):
        db_result = MultipleHeatsOptimizationResult(scrap_charge=charge_info, warnings=warnings)
    else:
        db_result = MultipleHeatsOptimizationResult(warnings=warnings)

    db_result.save()

    opt_input.optimization_result = db_result
    opt_input.save()

    multiple_heats_scrap_optimization.send(db_result.pk)
    return OptimizationDisplayDataV2(optimization_id=db_result.pk, warnings=warnings)


def update_optimization_display_data(optimization: OptimizationDisplayDataV2) -> Dict[str, Any]:
    try:
        multiple_heat_optimization = MultipleHeatsOptimizationResult.objects.get(
            pk=optimization.optimization_id
        )
        elapsed_percentage = multiple_heat_optimization.progress
        if multiple_heat_optimization.status == MultipleHeatsOptimizationResult.ResultStatus.FINISHED:
            input_data = multiple_heat_optimization.input_data
            first_input = input_data.heats[0]
            submodel_calculator = get_submodel_results_calculator(
                first_input.pig_iron_weight,
                first_input.grade_planned,
                first_input.pig_iron_chem,
                input_data.model_settings,
            )
            return {
                "percentage_done": 100.0,
                "result": multiple_heat_optimization.result,
                **submodel_calculator(multiple_heat_optimization.result.first_heat_scrap_weights),
            }
        if multiple_heat_optimization.status == MultipleHeatsOptimizationResult.ResultStatus.ERROR:
            return {
                "percentage_done": 100.0,
                "result": multiple_heat_optimization.result,
            }
        return {"percentage_done": elapsed_percentage}
    except Exception as e:  # pylint: disable=broad-except
        log.exception("Multiple heats optimization error")
        return {
            "percentage_done": 100.0,
            "result": MultipleHeatsOptimizationOutput(error=str(e)),
        }


start_optimization, update_optimization_status = (
    optimize_multiple_heats,
    update_optimization_display_data,
)
