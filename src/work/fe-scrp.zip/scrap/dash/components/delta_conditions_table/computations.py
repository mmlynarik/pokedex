from datetime import date
from typing import Optional, Tuple
from scrap_core import CUT_GROUP_NAME, PRIME_GROUP_NAME, SCRAP_GROUP_MAPPING
from dateutil.relativedelta import relativedelta
from scrap.utils import is_zone_domestic
from scrap.models import (
    ScrapPurchase,
    ScrapOfferData,
    ScrapOffer,
    BaseDeltaRuleData,
    BaseDeltaRule,
)


def is_rule_domestic(base_delta_rule: BaseDeltaRule) -> bool:
    return is_zone_domestic(str(base_delta_rule.zone))


def is_offer_domestic(scrap_offer: ScrapOffer) -> bool:
    return is_zone_domestic(str(scrap_offer.zone))


def is_rule_prime_cut(base_delta_rule: BaseDeltaRule) -> bool:
    return base_delta_rule.scrap_type in (
        PRIME_GROUP_NAME,
        CUT_GROUP_NAME,
    )


def is_scrap_type_in_right_group(
    base_delta_scrap_type: Optional[str], scrap_offer_scrap_type: Optional[str]
) -> bool:
    if None in (base_delta_scrap_type, scrap_offer_scrap_type):
        return False
    scrap_type_group = SCRAP_GROUP_MAPPING[str(scrap_offer_scrap_type)]  # type: ignore
    # FIXME base_delta_scrap_type is a ScrapType literal (or shall be with correct typing),
    #  but scrap_type_group is a ScrapTypeGroup literal. Consequently their comparison is always false
    #  and it hence it is either a bug or a useless code.
    return scrap_type_group == base_delta_scrap_type


def check_mandatory_fields_for_rule_evaluation(
    base_delta_rule: BaseDeltaRule, scrap_offer: ScrapOffer
) -> bool:
    return None not in (
        base_delta_rule.scrap_type,
        base_delta_rule.zone,
        scrap_offer.scrap_type,
        scrap_offer.zone,
    )


def get_nr_of_offers_with_rules(scrap_offer_data: ScrapOfferData) -> int:
    scrap_offer_with_rules_nr = 0
    for scrap_offer in scrap_offer_data:
        if scrap_offer.base_delta_rules:
            scrap_offer_with_rules_nr = scrap_offer_with_rules_nr + 1
    return scrap_offer_with_rules_nr


def compute_price_with_delta_for_scrap_offers(
    scrap_offers: ScrapOfferData,
    delta_rules: BaseDeltaRuleData,
) -> ScrapOfferData:
    updated_scrap_offer_data = list()
    for scrap_offer_data_item in scrap_offers:
        if scrap_offer_data_item.last_month_price is None:
            updated_scrap_offer_data.append(scrap_offer_data_item)
            continue
        base_delta = 0.0
        base_delta_rules = scrap_offer_data_item.base_delta_rules
        if len(base_delta_rules) > 0:
            highest_priority_rule_idx = min(base_delta_rules)
            base_delta_value = delta_rules[highest_priority_rule_idx].base_delta
            if base_delta_value is not None:
                base_delta = base_delta_value

        updated_scrap_offer_data.append(
            scrap_offer_data_item.update_field(
                price_with_delta=scrap_offer_data_item.last_month_price + base_delta
            )
        )
    return tuple(updated_scrap_offer_data)


def get_last_price_for_scrap_offer(
    scrap_offer: ScrapOffer, purchase_date: date
) -> Tuple[Optional[float], Optional[int]]:
    def month_diff(dta: date, dtb: date) -> int:
        diff = relativedelta(dta.replace(day=1), dtb.replace(day=1))
        return 12 * diff.years + diff.months

    scrap_type = scrap_offer.scrap_type
    zone = scrap_offer.zone
    if None in (scrap_type, zone):
        return None, None

    filter_kwargs = {"scrap_type": scrap_type, "zone": zone, "date__lt": purchase_date}

    if not is_zone_domestic(str(zone)):
        supplier = scrap_offer.supplier
        if supplier is None:
            return None, None
        filter_kwargs["supplier__name"] = supplier
    try:
        scrap_purchase_obj = ScrapPurchase.objects.filter(**filter_kwargs).order_by("-date")[0]
        return scrap_purchase_obj.price, month_diff(purchase_date, scrap_purchase_obj.date)
    except IndexError:
        return None, None


def find_base_delta_rules_for_offers(
    scrap_offers_data: ScrapOfferData,
    updated_delta_rules: BaseDeltaRuleData,
) -> ScrapOfferData:
    scrap_offer_list = list()
    for scrap_offer in scrap_offers_data:
        applied_base_delta_rules = list()
        for base_delta_rule_idx, base_delta_rule in enumerate(updated_delta_rules):
            if evaluate_base_delta_rule(base_delta_rule=base_delta_rule, scrap_offer=scrap_offer):
                applied_base_delta_rules.append(base_delta_rule_idx)
        scrap_offer_list.append(scrap_offer.update_field(base_delta_rules=applied_base_delta_rules))
    return tuple(scrap_offer_list)


def evaluate_base_delta_rule(base_delta_rule: BaseDeltaRule, scrap_offer: ScrapOffer) -> bool:
    if not check_mandatory_fields_for_rule_evaluation(
        base_delta_rule=base_delta_rule, scrap_offer=scrap_offer
    ):
        return False

    scrap_type_comparison = base_delta_rule.scrap_type == scrap_offer.scrap_type
    zone_comparison = base_delta_rule.zone == scrap_offer.zone
    supplier_comparison = base_delta_rule.supplier == scrap_offer.supplier

    if is_rule_domestic(base_delta_rule=base_delta_rule):
        if not is_offer_domestic(scrap_offer=scrap_offer):
            return False
        supplier_comparison = True
    else:
        if None in (
            base_delta_rule.supplier,
            scrap_offer.supplier,
        ):
            return False
    if is_rule_prime_cut(base_delta_rule=base_delta_rule):
        if not is_scrap_type_in_right_group(
            base_delta_scrap_type=base_delta_rule.scrap_type,
            scrap_offer_scrap_type=scrap_offer.scrap_type,
        ):
            return False
        scrap_type_comparison = True

    return scrap_type_comparison and zone_comparison and supplier_comparison


def move_base_delta_rule_up(delta_rules: BaseDeltaRuleData, row_id: int) -> BaseDeltaRuleData:
    if row_id == 0:
        return delta_rules
    reordered_tuple = (
        (delta_rules[0 : row_id - 1])
        + (delta_rules[row_id], delta_rules[row_id - 1])
        + (delta_rules[row_id + 1 :])
    )
    return reordered_tuple


def move_base_delta_rule_down(delta_rules: BaseDeltaRuleData, row_id: int) -> BaseDeltaRuleData:
    if row_id >= len(delta_rules) - 1:
        return delta_rules
    reordered_tuple = (
        (delta_rules[0:row_id]) + (delta_rules[row_id + 1], delta_rules[row_id]) + delta_rules[row_id + 2 :]
    )
    return reordered_tuple


def compute_scrap_offers(delta_rules: BaseDeltaRuleData, scrap_offers: ScrapOfferData) -> ScrapOfferData:
    validated_scrap_offers_data = find_base_delta_rules_for_offers(scrap_offers, delta_rules)
    recalculated_scrap_offers_data = compute_price_with_delta_for_scrap_offers(
        validated_scrap_offers_data, delta_rules
    )

    return recalculated_scrap_offers_data


def update_delta_rules_from_table_data(table_data) -> BaseDeltaRuleData:
    def safe_float(value: Optional[str]) -> Optional[float]:
        """
        If user writes down value and deletes it afterwards, empty string is the result,
        which may be accidentally stored in database. Since it can't be converted back to float,
        app ends with 500 Server Error.
        """
        if value is None:
            return None

        try:
            return float(value)
        except ValueError:
            return None

    return tuple(
        [
            BaseDeltaRule(
                scrap_type=table_row["scrap_type"],
                zone=table_row["zone"],
                supplier=table_row["supplier"],
                base_delta=safe_float(table_row["base_delta"]),
            )
            for table_row in table_data
        ]
    )
