import attr
from typing import Dict, Optional, Tuple, Union

from scrap.models import BaseDeltaRule, BaseDeltaRuleData

MOVE_UP_SYMBOL = "\u2191"
MOVE_DOWN_SYMBOL = "\u2193"


@attr.s(frozen=True, auto_attribs=True, slots=True)
class DeltaConditionsTableRowViewModel:
    scrap_type: Optional[str]
    zone: Optional[str]
    supplier: Optional[str]
    base_delta: Optional[float]
    priority: int

    @property
    def dash_table_row(self) -> Dict[str, Union[str, float, int]]:
        return {**attr.asdict(self), "move_up": MOVE_UP_SYMBOL, "move_down": MOVE_DOWN_SYMBOL}  # type: ignore
        # TODO remove type ignore with new mypy version


def get_delta_conditions_table_data(
    base_delta_rule_data: BaseDeltaRuleData,
) -> Tuple[DeltaConditionsTableRowViewModel, ...]:
    return tuple(
        [
            DeltaConditionsTableRowViewModel(
                scrap_type=row.scrap_type,
                zone=row.zone,
                supplier=row.supplier,
                base_delta=row.base_delta,
                priority=row_idx + 1,
            )
            for row_idx, row in enumerate(base_delta_rule_data)
        ]
    )


# FIXME seems to me that this function does nothing
def transform_updated_delta_rules_to_db_model(
    updated_base_delta_rules: BaseDeltaRuleData,
) -> BaseDeltaRuleData:
    return tuple(
        [
            BaseDeltaRule(
                scrap_type=delta_condition.scrap_type,
                zone=delta_condition.zone,
                supplier=delta_condition.supplier,
                base_delta=delta_condition.base_delta,
            )
            for delta_condition in updated_base_delta_rules
        ]
    )


def get_empty_base_delta_rule() -> BaseDeltaRule:
    return BaseDeltaRule(None, None, None, None)
