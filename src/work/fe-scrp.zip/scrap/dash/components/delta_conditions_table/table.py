from dash import html
import dash_bootstrap_components as dbc
import logging
from typing import Dict, List, Union
import attr
from dash import dash_table

from scrap.models import BaseDeltaRule
from scrap_core import CUT_GROUP_NAME, PRIME_GROUP_NAME, DOMESTIC_SCRAP_ZONES, SCRAP_GROUP_MAPPING
import ussksdc as sdc
from scrap.dash.components.delta_conditions_table.computations import (
    compute_scrap_offers,
    move_base_delta_rule_down,
    move_base_delta_rule_up,
    update_delta_rules_from_table_data,
)

from scrap.dash.components.delta_conditions_table.datasource import (
    transform_updated_delta_rules_to_db_model,
    get_delta_conditions_table_data,
    get_empty_base_delta_rule,
)
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig
from scrap.dash.components.common import ScrapPurchaseAppSource
from scrap.dash.components.scrap_purchase_components import (
    PRIORITY_COLUMN_WIDTH,
    SCRAP_TYPE_COLUMN_WIDTH,
    ZONE_COLUMN_WIDTH,
    SUPPLIER_COLUMN_WIDTH,
    PRICE_COLUMN_WIDTH,
    ICON_COLUMN_WIDTH,
)

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


@attr.s(slots=True, frozen=True)
class DeltaConditionsTableVM:
    TABLE_ID = "table"

    ADD_BUTTON_ID = "add"
    GENERATE_BUTTON_ID = "generate"

    @classmethod
    def get_output_fields(cls, config: ScrapPurchaseAppConfig) -> sdc.OutputFields:
        outputs = [
            sdc.OutputField(cls.TABLE_ID, "data", cls.get_table_data),
        ]
        if not config.read_only:
            outputs.append(sdc.OutputField(cls.TABLE_ID, "dropdown", cls.get_dropdown_options))
        return tuple(outputs)

    @classmethod
    def get_input_fields(cls, config: ScrapPurchaseAppConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputField(cls.TABLE_ID, "data", cls.user_update_base_delta_rules_table),
            sdc.InputField(cls.TABLE_ID, "active_cell", cls.click_on_base_delta_rule_table),
            sdc.InputField(cls.ADD_BUTTON_ID, "n_clicks", cls.add_new_base_delta_rule),
            sdc.InputField(cls.GENERATE_BUTTON_ID, "n_clicks", cls.generate_missing_base_delta_rules),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig):
        read_only = config.read_only
        columns = [
            {"name": "Priorita", "id": "priority", "type": "numeric", "editable": False},
            {"name": "Typ šrotu", "id": "scrap_type", "presentation": "dropdown", "editable": not read_only},
            {"name": "Zóna", "id": "zone", "presentation": "dropdown", "editable": not read_only},
            {"name": "Dodávateľ", "id": "supplier", "presentation": "dropdown", "editable": not read_only},
            {"name": "Delta", "id": "base_delta", "type": "numeric", "editable": not read_only},
        ]
        if not read_only:
            columns.extend(
                [
                    {"name": "", "id": "move_up", "type": "text", "editable": False},
                    {"name": "", "id": "move_down", "type": "text", "editable": False},
                ]
            )
        return html.Div(
            children=[
                html.H4("Delta pravidlá"),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls.TABLE_ID),
                    data=[],
                    columns=columns,
                    dropdown={
                        "scrap_type": {
                            "clearable": False,
                            "options": [],
                        },
                        "zone": {
                            "clearable": False,
                            "options": [],
                        },
                        "supplier": {
                            "clearable": False,
                            "options": [],
                        },
                    },
                    row_deletable=not read_only,
                    style_cell_conditional=[
                        {
                            "if": {
                                "column_id": "priority",
                            },
                            "width": PRIORITY_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "scrap_type",
                            },
                            "width": SCRAP_TYPE_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "scrap_type",
                            },
                            "text-align": "center",
                        },
                        {
                            "if": {
                                "column_id": "zone",
                            },
                            "width": ZONE_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "zone",
                            },
                            "text-align": "center",
                        },
                        {
                            "if": {
                                "column_id": "supplier",
                            },
                            "width": SUPPLIER_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "base_delta",
                            },
                            "width": PRICE_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "move_up",
                            },
                            "width": ICON_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "move_up",
                            },
                            "text-align": "center",
                        },
                        {
                            "if": {
                                "column_id": "move_down",
                            },
                            "width": ICON_COLUMN_WIDTH,
                        },
                        {
                            "if": {
                                "column_id": "move_down",
                            },
                            "text-align": "center",
                        },
                    ],
                ),
                html.Div(
                    children=[
                        dbc.Button(
                            "Pridať pravidlo",
                            id=sdc.create_id(parent_id, cls.ADD_BUTTON_ID),
                            color="primary",
                            n_clicks=0,
                            className="m-1",
                        ),
                        dbc.Button(
                            "Generovať chýbajúce pravidlá",
                            id=sdc.create_id(parent_id, cls.GENERATE_BUTTON_ID),
                            color="primary",
                            n_clicks=0,
                            className="m-1",
                        ),
                    ],
                    hidden=read_only,
                    className="text-center",
                ),
            ],
            className="delta-table-wrapper",
        )

    def add_new_base_delta_rule(self, n_clicks: int, ctx: ScrapPurchaseAppSource):
        if n_clicks == 0:
            return self
        delta_rules = ctx.db_purchase_data_source.get_delta_conditions()
        scrap_offers = ctx.db_purchase_data_source.get_scrap_offer_data()
        new_base_delta_rule = get_empty_base_delta_rule()
        updated_delta_rules = delta_rules + (new_base_delta_rule,)
        recalculated_scrap_offers_data = compute_scrap_offers(updated_delta_rules, scrap_offers)

        ctx.db_purchase_data_source.update_scrap_offer_data_and_base_delta_rule_data(
            recalculated_scrap_offers_data,
            transform_updated_delta_rules_to_db_model(updated_delta_rules),
        )

        return self

    def get_table_data(self, ctx: ScrapPurchaseAppSource) -> List[Dict[str, Union[str, float, int]]]:
        return [
            row.dash_table_row
            for row in get_delta_conditions_table_data(ctx.db_purchase_data_source.get_delta_conditions())
        ]

    def get_dropdown_options(self, ctx: ScrapPurchaseAppSource) -> Dict[str, Dict]:
        scrap_offers_data = ctx.db_purchase_data_source.get_scrap_offer_data()
        scrap_types = [PRIME_GROUP_NAME, CUT_GROUP_NAME] + sorted(
            {scrap_offer.scrap_type for scrap_offer in scrap_offers_data if scrap_offer.scrap_type}
        )
        suppliers = {scrap_offer.supplier for scrap_offer in scrap_offers_data if scrap_offer.supplier}
        zones = {scrap_offer.zone for scrap_offer in scrap_offers_data if scrap_offer.zone}

        dropdown = {
            "scrap_type": {
                "clearable": False,
                "options": [
                    {"label": scrap_type_name, "value": scrap_type_name} for scrap_type_name in scrap_types
                ],
            },
            "zone": {
                "clearable": False,
                "options": [{"label": zone, "value": zone} for zone in sorted(zones)],
            },
            "supplier": {
                "clearable": True,
                "options": [{"label": supplier, "value": supplier} for supplier in sorted(suppliers)],
            },
        }
        return dropdown

    def click_on_base_delta_rule_table(
        self, active_cell: Dict, ctx: ScrapPurchaseAppSource
    ) -> "DeltaConditionsTableVM":
        delta_rules = ctx.db_purchase_data_source.get_delta_conditions()
        scrap_offers_data = ctx.db_purchase_data_source.get_scrap_offer_data()
        if not active_cell:
            return self
        clicked_column_id = active_cell["column_id"]
        clicked_row_id = active_cell["row"]
        updated_delta_rules = delta_rules
        if clicked_column_id == "move_up":
            updated_delta_rules = move_base_delta_rule_up(delta_rules, clicked_row_id)
        if clicked_column_id == "move_down":
            updated_delta_rules = move_base_delta_rule_down(delta_rules, clicked_row_id)
        recalculated_scrap_offers_data = compute_scrap_offers(updated_delta_rules, scrap_offers_data)
        ctx.db_purchase_data_source.update_scrap_offer_data_and_base_delta_rule_data(
            recalculated_scrap_offers_data,
            updated_delta_rules,
        )

        return self

    def user_update_base_delta_rules_table(
        self, table_data: List[Dict], ctx: ScrapPurchaseAppSource
    ) -> "DeltaConditionsTableVM":
        scrap_offers_data = ctx.db_purchase_data_source.get_scrap_offer_data()

        updated_delta_rules = update_delta_rules_from_table_data(table_data)
        recalculated_scrap_offers_data = compute_scrap_offers(updated_delta_rules, scrap_offers_data)

        ctx.db_purchase_data_source.update_scrap_offer_data_and_base_delta_rule_data(
            recalculated_scrap_offers_data,
            updated_delta_rules,
        )

        return self

    def generate_missing_base_delta_rules(
        self, n_clicks: int, ctx: ScrapPurchaseAppSource
    ) -> "DeltaConditionsTableVM":
        """
        For each scrap offer
            check if there is at least 1 "linked" delta rule and if there is none,
                add generic delta rule applicable to the given offer.
        """
        if n_clicks == 0:
            return self

        scrap_offers = ctx.db_purchase_data_source.get_scrap_offer_data()
        new_delta_rules = set()

        for offer in scrap_offers:
            if not offer.base_delta_rules:
                new_delta_rules.add(
                    BaseDeltaRule(
                        scrap_type=SCRAP_GROUP_MAPPING[offer.scrap_type],
                        zone=offer.zone,
                        # non-domestic suppliers must have specific delta rules,
                        # whereas domestic suppliers in the same zone have 1 common delta rule,
                        # thus supplier attribute is kept empty
                        supplier=None if offer.zone in DOMESTIC_SCRAP_ZONES else offer.supplier,
                        base_delta=None,
                    )
                )

        # append new delta rules at the end of existing delta rules
        delta_rules = ctx.db_purchase_data_source.get_delta_conditions() + tuple(
            sorted(new_delta_rules, key=lambda rule: (rule.scrap_type, rule.zone, rule.supplier))
        )

        recalculated_scrap_offers_data = compute_scrap_offers(delta_rules, scrap_offers)

        ctx.db_purchase_data_source.update_scrap_offer_data_and_base_delta_rule_data(
            recalculated_scrap_offers_data,
            delta_rules,
        )

        return self
