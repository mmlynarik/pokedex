from datetime import date
from typing import List, Optional, Sequence, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, html
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE

from scrap_core.utils import convert_kilograms_to_tons

from ...models import ScrapChargeDisplayDataV2
from ..database_api import steel_grades

NEW_HEAT_BUTTON_ID = "new-heat-button"
NEW_HEAT_TOAST_ID = "new-heat-toast"


class ScrapChargeRow(TypedDict):
    grade_display_name: str
    heat_basket_display_value: str
    total_scrap_weight: str


ScrapChargeData = List[ScrapChargeRow]


def get_basket_ids_display_value(basket_ids: Sequence[int]) -> str:
    return ",".join([str(bid) for bid in basket_ids])


def get_grade_display_name(grade_id: Optional[int]) -> str:
    if grade_id is None:
        return ""
    return steel_grades.get_display_name(grade_id, date.today())


def get_heat_id_basket_display_value(heat_id: Optional[int], basket_ids: Sequence[int]) -> str:
    if heat_id is None:
        return get_basket_ids_display_value(basket_ids)
    if not basket_ids:
        return str(heat_id)
    return "/".join([str(heat_id), get_basket_ids_display_value(basket_ids)])


def get_scrap_and_pig_iron_weight_display_value(
    scrap_weight: Optional[float], pig_iron_weight: Optional[float]
) -> str:
    def to_tons(weight: Optional[float]) -> str:
        return str(int(convert_kilograms_to_tons(weight))) if weight is not None else ""

    if scrap_weight is None and pig_iron_weight is None:
        return ""

    return f"{to_tons(scrap_weight)}/{to_tons(pig_iron_weight)}"


def get_scrap_charge_row_v2(data: ScrapChargeDisplayDataV2) -> ScrapChargeRow:
    return {
        "grade_display_name": get_grade_display_name(data.grade_id),
        "heat_basket_display_value": get_heat_id_basket_display_value(data.heat_id, data.basket_ids),
        "total_scrap_weight": get_scrap_and_pig_iron_weight_display_value(
            data.total_scrap_weight, data.pig_iron_weight
        ),
    }


def create_scrap_charge_table(table_id: str, read_only: bool = False) -> dbc.Row:
    return dbc.Row(
        [
            dbc.Col(
                dash_table.DataTable(
                    id=table_id,
                    columns=[
                        {"name": "Číslo tavby/Korytá", "id": "heat_basket_display_value", "type": "text"},
                        {"name": "Akosť", "id": "grade_display_name", "type": "text"},
                        {"name": "Váha šrotu/sur. železa", "id": "total_scrap_weight", "type": "number"},
                    ],
                    data=[],
                    style_data_conditional=DATA_TEXT_STYLE,
                    style_table={"padding-left": "16px", "padding-right": "16px"},
                    style_cell=CELL_STYLE,
                    style_header=TABLE_HEADER_STYLE,
                    editable=False,
                    row_selectable="single",
                ),
                width=12,
            ),
            dbc.Col(
                html.Div(
                    dbc.Button(
                        "Nová Tavba",
                        id=NEW_HEAT_BUTTON_ID,
                        color="primary",
                        className="btn-block mt-2",
                        n_clicks=0,
                    ),
                    hidden=read_only,
                ),
                width=12,
            ),
            dbc.Col(
                dbc.Alert(
                    "Pre vytvorenie novej tavby potrebujete mať aspoň jeden dostupný šrot.",
                    id=NEW_HEAT_TOAST_ID,
                    color="info",
                    duration=5000,
                    fade=True,
                    dismissable=True,
                    is_open=False,
                    className="mt-3",
                ),
            ),
        ]
    )
