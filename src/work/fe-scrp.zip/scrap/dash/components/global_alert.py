from typing import (
    Any,
    Callable,
    List,
    Optional,
    Protocol,
    Tuple,
    TypeVar,
    runtime_checkable,
)

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode, TViewModel
from ussksdc.core.field_types import is_child_component
from ussksdc.core.helper import generate_clientside_callback


class ViewModelCTX(Protocol):
    parent: TViewModel


@attr.frozen
class Message:
    uuid: str = attr.ib()
    warnings: Tuple[str, ...] = attr.ib(default=())
    errors: Tuple[str, ...] = attr.ib(default=())


@runtime_checkable
class ComponentWithMsgChannel(Protocol):
    def message_channel(self) -> Optional[Message]: ...


def get_message_from_component(child_component: Any) -> Optional[Message]:
    if isinstance(child_component, ComponentWithMsgChannel):
        return child_component.message_channel()
    return None


T = TypeVar("T")


def traverse_vm_tree(view_model, getter: Callable[[TViewModel], T]) -> Tuple[T, ...]:
    messages = []
    for field in attr.fields(type(view_model)):
        if is_child_component(field):
            child_component = getattr(view_model, field.name)
            messages.extend(traverse_vm_tree(child_component, getter))
            message = getter(child_component)
            if message is not None:
                messages.append(message)
    return tuple(messages)


def compose_messages(view_model) -> Tuple[Message, ...]:
    return traverse_vm_tree(view_model, get_message_from_component)


@attr.frozen
class GlobalAlertVM:
    ID = "alert-wrapper"
    ALERT_WRAPPER_SERVERSIDE_ID = "alert-wrapper-serverside"
    ALERT_WRAPPER_CLIENTSIDE_ID = "alert-wrapper-clientside"
    HISTORY_SERVERSIDE_ID = "history-serverside"
    HISTORY_CLIENTSIDE_ID = "history-clientside"

    displayed_uuid: List[str] = sdc.only_state_binding(
        HISTORY_SERVERSIDE_ID, "data", default="", converter=" ".join
    )
    cs_displayed_uuid: List[str] = sdc.clientside_only_state_binding(
        HISTORY_CLIENTSIDE_ID, "data", default=[]
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                html.Div(id=sdc.create_id(parent_id, cls.ALERT_WRAPPER_SERVERSIDE_ID)),
                html.Div(id=sdc.create_id(parent_id, cls.ALERT_WRAPPER_CLIENTSIDE_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.HISTORY_SERVERSIDE_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.HISTORY_CLIENTSIDE_ID)),
            ],
            id=sdc.create_id(parent_id, cls.ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.ALERT_WRAPPER_SERVERSIDE_ID, "children", cls.build_components),
            sdc.OutputField(cls.HISTORY_SERVERSIDE_ID, "data", cls.store_history),
            sdc.OutputFieldClientSide(
                cls.ALERT_WRAPPER_CLIENTSIDE_ID, "children", *cls.build_components_cs()
            ),
            sdc.OutputFieldClientSide(cls.HISTORY_CLIENTSIDE_ID, "data", *cls.store_history_cs()),
        )

    @classmethod
    def build_components_cs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "buildComponentCs",
            ["viewModel", "ctx"],
            """
            const messages = viewModel.traverseViewModel(ctx.parent);
            var components = [];
            for (let msgObj of messages){
                if ((viewModel.cs_displayed_uuid || []).includes(msgObj.uuid))
                    continue;
                components.push(viewModel.createAlert(msgObj));
            }
            
            if (components.length === 0)
                return null;
            if (components.length === 1)
                return components[0]; 
            return components;
            """,
        )

    @classmethod
    def store_history_cs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "storeHistoryCs",
            ["viewModel", "ctx"],
            """
            return viewModel.traverseViewModel(ctx.parent).map(msgObj => msgObj.uuid);
            """,
        )

    def store_history(self, ctx: ViewModelCTX) -> List[str]:
        messages = compose_messages(ctx.parent)
        return [msg.uuid for msg in messages]

    def build_components(self, ctx: ViewModelCTX) -> Any:
        messages = compose_messages(ctx.parent)
        if not messages:
            return None
        alerts = []
        for msg in messages:
            if msg.uuid in self.displayed_uuid.split():
                continue
            if msg.warnings:
                alerts.append(
                    dmc.Alert(
                        hide=False,
                        children=msg.warnings[0],
                        withCloseButton=True,
                        title="Pozor!",
                        color="yellow",
                    )
                )
            if msg.errors:
                alerts.append(
                    dmc.Alert(
                        hide=False, children=msg.errors[0], withCloseButton=True, title="Chyba!", color="red"
                    )
                )
        if not alerts:
            return None
        return alerts if len(alerts) > 1 else alerts[0]

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.traverse_vm_tree()),
            sdc.JsCodeField(*cls.msg_data_class()),
            sdc.JsCodeField(*cls.create_alert_for_msg()),
        )

    @classmethod
    def traverse_vm_tree(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "traverseViewModel",
            ["vm"],
            """
            const data = []
            for (const property in vm){
                if (vm[property] == null){
                    continue;
                }
                if (typeof vm[property] === 'object'){
                    if (!vm[property].hasOwnProperty("path"))
                        continue;
                    
                    var partialData = this.traverseViewModel(vm[property]);
                    if (partialData.length !== 0)
                        data.push(...partialData);
                }
                if (property === 'message_buffer_cs'){
                    const msg = JSON.parse(vm[property]);
                    if (msg !== null){
                        data.push(msg);
                    }
                }
            }
            return data;
            """,
        )

    @classmethod
    def msg_data_class(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "Message",
            [],
            """
            return class Message{
                constructor(message, level = info){
                    this.message = message,
                    this.level = level,
                    this.uuid = [level, Number(new Date())].join('_');
                }
            }
            """,
        )

    @classmethod
    def create_alert_for_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "createAlert",
            ["obj"],
            """
            const titles = {'info': 'Oznámenie', 'warning': 'Pozor!', 'error': 'Chyba!', 'success': 'Úspech'};
            const colors = {'info': 'blue.9', 'warning': 'yellow.9', 'error': 'red.9', 'success': 'green.9'};
            return {
                type: "Alert",
                namespace: "dash_mantine_components",
                props: {
                    'duration': 4000,
                    'withCloseButton': true,
                    'children': obj.message,
                    'color': colors[obj.level],
                    'title': titles[obj.level],
                },
            };
            """,
        )
