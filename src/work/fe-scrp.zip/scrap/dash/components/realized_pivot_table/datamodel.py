import attr


@attr.s(frozen=True, auto_attribs=True)
class ScrapRealizedPivotTableRowViewModel:
    scrap_type: int
    zone_1: str
    zone_2: str
    zone_3: str
    zone_4: str
    zone_cz: str
    zone_hu: str
    zone_pl: str
    total: str
