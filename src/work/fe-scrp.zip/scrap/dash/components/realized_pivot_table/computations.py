from typing import Container, Optional, Tuple, Union

import pandas as pd

from scrap_core import CUT_SCRAP, PRIME_SCRAP, ScrapType
from scrap.models import RealizedScrapOffer, RealizedScrapOfferData, ScrapOffer, ScrapOfferData
from scrap.dash.components.realized_pivot_table.datamodel import ScrapRealizedPivotTableRowViewModel


def get_scrap_pivot_data(
    scrap_offer_data: ScrapOfferData, realized_scrap_offer_data: RealizedScrapOfferData
) -> Tuple[ScrapRealizedPivotTableRowViewModel, ...]:
    def get_zone(offer: Union[RealizedScrapOffer, ScrapOffer]) -> Optional[str]:
        if offer.zone is None:
            return None

        return f"z{offer.zone}" if offer.zone.isdigit() else offer.zone.lower()

    def get_realized_pivot_table(
        realized_offers: RealizedScrapOfferData, scrap_types: Container[ScrapType]
    ) -> pd.DataFrame:
        df_data = pd.DataFrame(
            {
                "scrap_type": offer.scrap_type,
                "zone": get_zone(offer),
                "realized": offer.weight,
            }
            for offer in realized_offers
            if offer.scrap_type in scrap_types
        )

        if df_data.empty:
            return df_data

        return (
            df_data.groupby(["scrap_type", "zone"])
            .sum()
            .reset_index()
            .pivot(index="scrap_type", columns="zone", values="realized")
            .groupby("scrap_type")
            .sum()
        )

    def get_recommended_pivot_table(
        offers: ScrapOfferData, scrap_types: Container[ScrapType]
    ) -> pd.DataFrame:
        df_data = pd.DataFrame(
            {
                "scrap_type": offer.scrap_type,
                "zone": get_zone(offer),
                "recommended": (offer.weight or 0) * (offer.recommendation or 0),
            }
            for offer in offers
            if offer.scrap_type in scrap_types
        )

        if df_data.empty:
            return df_data

        return (
            df_data.groupby(["scrap_type", "zone"])
            .sum()
            .reset_index()
            .pivot(index="scrap_type", columns="zone", values="recommended")
            .groupby("scrap_type")
            .sum()
        )

    def combine(df_prime: pd.DataFrame, df_cut: pd.DataFrame) -> pd.DataFrame:
        df_prime, df_cut = df_prime.align(df_cut, axis=1, fill_value=0)

        # add per zone prime total row
        s_prime_total = df_prime.sum().rename("Prime Total")

        # add per zone cut total row
        s_cut_total = df_cut.sum().rename("Cut Total")

        # add per zone total row
        s_total = (s_prime_total + s_cut_total).rename("Total")

        # due to unknown reasons concatenation of rows does not work as expected,
        # thus we concatenate data as columns and transpose the result
        df_combined = pd.concat(
            [
                df_prime.T,
                s_prime_total,
                df_cut.T,
                s_cut_total,
                s_total,
            ],
            axis=1,
        ).T

        # add per scrap total column
        df_combined["total"] = df_combined.sum(axis=1)

        return df_combined

    def get_available_pivot_table(offers: ScrapOfferData, scrap_types: Container[ScrapType]) -> pd.DataFrame:
        df_data = pd.DataFrame(
            {
                "scrap_type": offer.scrap_type,
                "zone": get_zone(offer),
                "available": offer.weight,
            }
            for offer in offers
            if offer.scrap_type in scrap_types
        )

        if df_data.empty:
            return df_data

        return (
            df_data.groupby(["scrap_type", "zone"])
            .sum()
            .reset_index()
            .pivot(index="scrap_type", columns="zone", values="available")
            .groupby("scrap_type")
            .sum()
        )

    if not scrap_offer_data:
        return ()

    df_realized_prime = get_realized_pivot_table(realized_scrap_offer_data, PRIME_SCRAP)
    df_realized_cut = get_realized_pivot_table(realized_scrap_offer_data, CUT_SCRAP)

    df_realized = combine(df_realized_prime, df_realized_cut)

    df_recommended_prime = get_recommended_pivot_table(scrap_offer_data, PRIME_SCRAP)
    df_recommended_cut = get_recommended_pivot_table(scrap_offer_data, CUT_SCRAP)

    df_recommended = combine(df_recommended_prime, df_recommended_cut)

    df_available_prime = get_available_pivot_table(scrap_offer_data, PRIME_SCRAP)
    df_available_cut = get_available_pivot_table(scrap_offer_data, CUT_SCRAP)

    df_available = combine(df_available_prime, df_available_cut)

    # align dataframes on both axis
    df_recommended, df_available = df_recommended.align(df_available, fill_value=0)
    df_realized, df_recommended = df_realized.align(df_recommended, fill_value=0)

    # fill missing columns
    columns = ["z1", "z2", "z3", "z4", "cz", "hu", "pl", "total"]
    df_realized = df_realized.reindex(columns=columns, fill_value=0)
    df_recommended = df_recommended.reindex(columns=columns, fill_value=0)
    df_available = df_available.reindex(columns=columns, fill_value=0)

    # convert data to expected type
    df_realized = df_realized.astype(int)
    df_recommended = df_recommended.astype(int)
    df_available = df_available.astype(int)

    # fix index order
    index = [
        *sorted(set(PRIME_SCRAP) & set(df_realized.index)),
        "Prime Total",
        *sorted(set(CUT_SCRAP) & set(df_realized.index)),
        "Cut Total",
        "Total",
    ]

    return tuple(
        ScrapRealizedPivotTableRowViewModel(
            scrap_type=idx,
            zone_1=f"{df_realized.z1[idx]} ({df_recommended.z1[idx]} / {df_available.z1[idx]})",
            zone_2=f"{df_realized.z2[idx]} ({df_recommended.z2[idx]} / {df_available.z2[idx]})",
            zone_3=f"{df_realized.z3[idx]} ({df_recommended.z3[idx]} / {df_available.z3[idx]})",
            zone_4=f"{df_realized.z4[idx]} ({df_recommended.z4[idx]} / {df_available.z4[idx]})",
            zone_cz=f"{df_realized.cz[idx]} ({df_recommended.cz[idx]} / {df_available.cz[idx]})",
            zone_hu=f"{df_realized.hu[idx]} ({df_recommended.hu[idx]} / {df_available.hu[idx]})",
            zone_pl=f"{df_realized.pl[idx]} ({df_recommended.pl[idx]} / {df_available.pl[idx]})",
            total=f"{df_realized.total[idx]} ({df_recommended.total[idx]} / {df_available.total[idx]})",
        )
        for idx in index
    )
