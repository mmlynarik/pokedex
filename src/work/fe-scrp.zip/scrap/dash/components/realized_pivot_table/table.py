from typing import Dict, Tuple, List
import attr
import dash_mantine_components as dmc
from dash import html
from dash import dash_table

from scrap.dash.components.realized_pivot_table.computations import get_scrap_pivot_data
from scrap.dash.components.common import ScrapPurchaseAppSource
import ussksdc as sdc


@attr.s(frozen=True, slots=True)
class ScrapPurchaseRealizedPivotTableViewModel:
    COMPONENT_ID = "table"
    SUPPLIERS_SELECTOR_ID = "suppliers"

    suppliers: List[str] = sdc.two_way_binding(SUPPLIERS_SELECTOR_ID, "value", default=[])

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", cls.get_realized_pivot_data),
            sdc.OutputField(cls.SUPPLIERS_SELECTOR_ID, "data", cls.get_supplier_options),
        )

    @classmethod
    def get_layout(cls, parent_id: str):
        return html.Div(
            children=[
                html.Hr(),
                html.H4("Realizované ( Odporúčané / Dostupné )"),
                dmc.MultiSelect(
                    id=sdc.create_id(parent_id, cls.SUPPLIERS_SELECTOR_ID),
                    placeholder="Môžete zvoliť vybraných dodávateľov",
                    className="supplier-multiselect",
                ),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    columns=cls.get_scrap_purchased_recommended_pivot_table_columns(),
                    data=[],
                    style_data_conditional=[
                        {
                            "if": {
                                "filter_query": '{scrap_type} contains "Total"',
                            },
                            "fontWeight": "bold",
                        }
                    ],
                    tooltip={
                        item["id"]: {
                            "value": "realizované (odporúčané / dostupné)",
                            "use_with": "data",
                        }
                        for item in cls.get_scrap_purchased_recommended_pivot_table_columns()[1:]
                    },
                ),
            ],
            className="pivot-wrapper",
        )

    @classmethod
    def get_scrap_purchased_recommended_pivot_table_columns(cls) -> Tuple[Dict, ...]:
        return tuple(
            {"name": name, "id": id_, "type": "text", "editable": False}
            for name, id_ in [
                ("Typ šrotu", "scrap_type"),
                ("Z1", "zone_1"),
                ("Z2", "zone_2"),
                ("Z3", "zone_3"),
                ("Z4", "zone_4"),
                ("CZ", "zone_cz"),
                ("HU", "zone_hu"),
                ("PL", "zone_pl"),
                ("Total", "total"),
            ]
        )

    def get_supplier_options(self, ctx: ScrapPurchaseAppSource) -> Tuple[Dict[str, str], ...]:
        return tuple(
            {"label": supplier, "value": supplier} for supplier in ctx.db_purchase_data_source.get_suppliers()
        )

    def get_realized_pivot_data(self, ctx: ScrapPurchaseAppSource):
        return tuple(
            attr.asdict(row)
            for row in get_scrap_pivot_data(
                ctx.db_purchase_data_source.get_scrap_offer_data(self.suppliers),
                ctx.db_purchase_data_source.get_realized_scrap_offer_data(self.suppliers),
            )
        )
