from typing import Any, Dict, List, Optional, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, html
from scrap_core.optimization.validations import ScrapMixLimit, ScrapMixLimits
from scrap_core.utils import convert_kilograms_to_tons, convert_tons_to_kilograms
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE
from scrap_core import ScrapType, ScrapMix

from . import get_scrap_type_label


class ScrapChargeLimitsTableRow(TypedDict):
    label: str
    scrap_mix: ScrapMix
    minimum: Optional[float]
    maximum: Optional[float]


ScrapChargeLimitsTableData = List[ScrapChargeLimitsTableRow]


def convert_table_data_to_scrap_limits(
    scrap_limits_table_data: ScrapChargeLimitsTableData,
) -> ScrapMixLimits:
    return tuple(
        [
            ScrapMixLimit(
                row["scrap_mix"],
                convert_tons_to_kilograms(row["minimum"]) if row["minimum"] is not None else None,
                convert_tons_to_kilograms(row["maximum"]) if row["maximum"] is not None else None,
            )
            for row in scrap_limits_table_data
        ]
    )


def convert_scrap_limits_to_table_data(scrap_limits: ScrapMixLimits) -> ScrapChargeLimitsTableData:
    return [
        create_charge_limits_table_row(
            row.scrap_type,
            convert_kilograms_to_tons(row.minimum) if row.minimum is not None else None,
            convert_kilograms_to_tons(row.maximum) if row.maximum is not None else None,
        )
        for row in scrap_limits
    ]


def create_charge_limits_table_row(
    scrap_mix: ScrapMix, minimum: Optional[float], maximum: Optional[float]
) -> ScrapChargeLimitsTableRow:
    return {
        "label": get_scrap_type_label(scrap_mix),
        "scrap_mix": scrap_mix,
        "minimum": minimum,
        "maximum": maximum,
    }


def create_charge_limits_table(table_id: str, read_only: bool = False) -> dash_table.DataTable:
    columns: List[Dict[str, Any]] = [
        {"name": "Typ šrotu", "id": "label", "type": "text", "editable": False},
        {
            "name": "Minimum [kg]",
            "id": "minimum",
            "type": "numeric",
            "validation": {"allow_null": True, "default": None},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        {
            "name": "Maximum [kg]",
            "id": "maximum",
            "type": "numeric",
            "validation": {"allow_null": True, "default": None},
            "on_change": {"action": "coerce", "failure": "default"},
        },
    ]
    if read_only:
        columns[1]["editable"] = False
        columns[2]["editable"] = False
    return html.Div(
        [
            dbc.Label("Hmotnostné limity šrotov", className="m-0"),
            dbc.Label(
                "Pre potvrdenie hodnoty v tabuľke je potrebné po zadaní hodnoty stlačiť ENTER.",
                className="text-info w-100 m-0 p-0",
                style={"font-size": "0.8rem"},
                hidden=read_only,
            ),
            dash_table.DataTable(
                id=table_id,
                columns=columns,
                data=[],
                editable=not read_only,
                style_data_conditional=DATA_TEXT_STYLE,
                style_cell_conditional=[{"if": {"column_id": "label"}, "width": "80px"}],
                style_table={"width": "100%", "padding": "0px 16px"},
                style_cell=CELL_STYLE,
                style_header=TABLE_HEADER_STYLE,
            ),
            dbc.FormText("", id=table_id + "-msg"),
        ],
        id=table_id + "-group",
    )


def create_charge_limits_table_v2(table_id: str, read_only: bool = False) -> html.Div:
    columns: List[Dict[str, Any]] = [
        {"name": "Typ šrotu", "id": "label", "type": "text", "editable": False},
        {
            "name": "Minimum [t]",
            "id": "minimum",
            "type": "numeric",
            "validation": {"allow_null": True, "default": None},
            "on_change": {"action": "coerce", "failure": "default"},
        },
        {
            "name": "Maximum [t]",
            "id": "maximum",
            "type": "numeric",
            "validation": {"allow_null": True, "default": None},
            "on_change": {"action": "coerce", "failure": "default"},
        },
    ]
    if read_only:
        columns[1]["editable"] = False
        columns[2]["editable"] = False
    return html.Div(
        [
            dbc.Label("Hmotnostné limity šrotov", className="m-0"),
            dbc.Label(
                "Pre potvrdenie hodnoty v tabuľke je potrebné po zadaní hodnoty stlačiť ENTER.",
                className="text-info w-100 m-0 p-0",
                style={"font-size": "0.8rem"},
                hidden=read_only,
            ),
            dash_table.DataTable(
                id=table_id,
                columns=columns,
                data=[],
                editable=not read_only,
                style_data_conditional=DATA_TEXT_STYLE,
                style_cell_conditional=[{"if": {"column_id": "label"}, "width": "80px"}],
                style_table={"width": "100%", "padding": "0px 16px"},
                style_cell=CELL_STYLE,
                style_header=TABLE_HEADER_STYLE,
            ),
            dbc.FormText("", id=table_id + "-msg"),
        ],
        id=table_id + "-group",
    )
