import dash_mantine_components as dmc

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig

STOP_BTN_LABEL = "Zastaviť"


def get_stop_btn_layout(btn_id: str, config: ScrapLoadingStationConfig) -> dmc.Button:
    return dmc.Button(
        STOP_BTN_LABEL,
        id=btn_id,
        disabled=config.read_only,
        size="sm",
        color="blue.8",
        variant="subtle",
    )
