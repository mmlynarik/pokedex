from enum import IntEnum
from string import Template
from typing import Any, Dict, List, Optional, Self, Tuple

import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from dash_ag_grid import AgGrid
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.consumers.scale_controller import START_EVENT_KEY
from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


class TableState(IntEnum):
    NOT_SELECTED_SCALE = 0
    SELECTED_ONE_SCALE = 1
    SELECTED_BOTH_SCALES = 2


@frozen
class RecommendedScrapsTableVM:
    # Component Ids
    ID = "table"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    SCRAP_ID_COL_ID = "id"
    SCRAP_COL_ID = "scrap"
    WEIGHT_COL_ID = "recommended_weight"
    TOTAL_WEIGHT_COL_ID = "total_weight"
    BASKET_WEIGHT_COL_ID = "basket_weight"
    DIFF_WEIGHT_COL_ID = "diff_weight"
    SCALE_IDX_ID = "scale-idx"
    MESSAGE_BUFFER_ID = "message-buffer"
    WEIGHTING_REQ_ID = "weighting-req-identifier"
    # Component classnames
    BASE_CLASSNAME = "proposed-scrap-charge-table"
    NOT_SELECTED_SCALE_CLASSNAME = "not-scale-selected"
    SINGLE_SELECTED_SCALE_CLASSNAME = "single-scale"
    HAS_WEIGHTED_WEIGHT_CLASSNAME = "has-weighted-scraps"
    # Settings
    WEIGHT_VALUE_FORMATER = {"function": "d3.format(',.2f')(params.value) + ' t'"}

    scale_idx: int = sdc.binding(
        SCALE_IDX_ID,
        "data",
        cs_read=False,
        cs_state=True,
        cs_write=False,
        ss_read=False,
        ss_state=True,
        ss_write=True,
        default=-1,
    )
    data: List[Dict[str, Any]] = sdc.clientside_only_state_binding(
        ID,
        "rowData",
        default=[],
    )
    columns: List[Dict[str, Any]] = sdc.clientside_only_state_binding(
        ID,
        "columnDefs",
        default=[],
    )
    selectedRow: List[Dict[str, Any]] = sdc.clientside_one_way_binding_with_state(
        ID,
        "selectedRows",
        default=[],
    )
    message_buffer_cs: Optional[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_BUFFER_ID,
        "data",
        default="",
    )
    weightning_req_id: Optional[str] = sdc.clientside_one_way_binding_with_state(
        WEIGHTING_REQ_ID,
        "data",
        default=None,
    )

    @classmethod
    def create(cls, scale_index: int) -> Self:
        return cls(scale_idx=scale_index)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                AgGrid(
                    columnDefs=[
                        {"headerName": "ID", "field": cls.SCRAP_ID_COL_ID, "hide": True},
                        {"headerName": "Typ šrotu", "field": cls.SCRAP_COL_ID},
                        {
                            "headerName": "Naložiť",
                            "field": cls.WEIGHT_COL_ID,
                            "valueFormatter": cls.WEIGHT_VALUE_FORMATER,
                        },
                        {
                            "headerName": "Navážené na váhe",
                            "field": cls.BASKET_WEIGHT_COL_ID,
                            "valueFormatter": cls.WEIGHT_VALUE_FORMATER,
                            "hide": True,
                        },
                        {
                            "headerName": "Celkovo navážené",
                            "field": cls.TOTAL_WEIGHT_COL_ID,
                            "valueFormatter": cls.WEIGHT_VALUE_FORMATER,
                            "hide": True,
                        },
                        {
                            "headerName": "Zostáva naložiť",
                            "field": cls.DIFF_WEIGHT_COL_ID,
                            "valueFormatter": cls.WEIGHT_VALUE_FORMATER,
                            "hide": True,
                        },
                    ],
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={
                        "rowHeight": 30,
                        "headerHeight": 38,
                        "rowSelection": None if config.read_only else "single",
                        "domLayout": "autoHeight",
                        "wrapHeaderText": True,
                    },
                    getRowId=f"params.data.{cls.SCRAP_ID_COL_ID}",
                    id=sdc.create_id(parent_id, cls.ID),
                    style={"height": None},
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.SCALE_IDX_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.WEIGHTING_REQ_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_BUFFER_ID)),
            ],
            id=sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "selectedRows", *cls.select_weighted_scrap()),)

    @classmethod
    def select_weighted_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "addRowToAdditionalScrapTable",
            ["viewModel", "selectedRow", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            if (!ctx.isScaleSelected(updatedVM)){
                updatedVM.selectedRow = [];
                updatedVM.message_buffer_cs = ctx.createClientSideMsg(
                    "Pred zvolením váženého šrotu je potrebné zvoliť váhu.", "warning"
                );
                return updatedVM;
            }
            
            const scaleState = ctx.getScaleState(viewModel.scale_idx);
            if (scaleState == null){
                updatedVM.message_buffer_cs = ctx.createClientSideMsg(
                    "Nastala chyba na strane servera. Prosím kontaktujte IT. Kód chyby: s_e1", "error"
                );
                return updatedVM;
            }
            updatedVM.weightning_req_id = sdc.callbackRunId;
            return updatedVM;
            """
            ).substitute(
                start_event=START_EVENT_KEY,
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "rowData", *cls.get_table_data()),
            sdc.OutputFieldClientSide(cls.ID, "columnDefs", *cls.set_columns()),
        )

    @classmethod
    def set_columns(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setColumns",
            ["viewModel", "ctx"],
            Template(
                """
            const hasWeightedScraps = (
                ctx.scrapChargeId != null &&
                Object.keys(ctx.getWeightedScraps(scrapChargeId).getAll()).length !== 0
            );
            return viewModel.columns.map(
                col => {
                    let updatedCol = {...col};
                    if (col.field === '${id_col}')
                        updatedCol.hide = !ctx.debug;
                    if (col.field === '${basket_weight_col}')
                        updatedCol.hide = ctx.selectedScales(viewModel).length === 0;
                    if (col.field === '${diff_col}')
                        updatedCol.hide = ctx.selectedScales(viewModel).length === 0 && !hasWeightedScraps;
                    if (col.field === '${total_weight_col}')
                        updatedCol.hide = ctx.selectedScales(viewModel).length !== 2;
                    return updatedCol
                }
            );
            """
            ).substitute(
                id_col=cls.SCRAP_ID_COL_ID,
                scrap_col=cls.SCRAP_COL_ID,
                basket_weight_col=cls.BASKET_WEIGHT_COL_ID,
                total_weight_col=cls.TOTAL_WEIGHT_COL_ID,
                diff_col=cls.DIFF_WEIGHT_COL_ID,
            ),
        )

    @classmethod
    def get_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableData",
            ["viewModel", "ctx"],
            Template(
                """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            const lastOptimization = ctx.selectedScrapChargeOptimization(scrapChargeId);
            if (lastOptimization?.result == null)
                return [];

            const scraps = Object.values(ctx.getAvailableScrap()).map(scrap => scrap.scrap_type);
            const firstChargeRecommendedWeight = lastOptimization.result.scrap_weights_per_heat.at(0) || {};
            const weightedScraps = Object.values(ctx.getWeightedScraps(scrapChargeId).getAll());
            const totalWeightedScrapFilter = scrapType => {return weightedScraps.filter(
                scrap => (scrap.scrap === scrapType && scrap.invalid_record === false)
            )};
            const onScaleWeightedScrapFilter = scrapType => {return weightedScraps.filter(
                scrap => (
                    scrap.scale_id === ctx.scaleIds[this.scale_idx] &&
                    scrap.scrap === scrapType &&
                    scrap.invalid_record === false
                )
            )};
            const reduceToWeightOnly = data => {
                return ctx.kgsToTons(ctx.sum(data.map(scrap => scrap.weight)))
            };
            return scraps.map(scrap => {
                const total = reduceToWeightOnly(totalWeightedScrapFilter(scrap));
                const recommendedWeight = ctx.kgsToTons(firstChargeRecommendedWeight[scrap]) || 0;
                return {
                    $scrap_id_col: scrap,
                    $scrap_col: scrap,
                    $weight_col: recommendedWeight,
                    $basket_weight: reduceToWeightOnly(onScaleWeightedScrapFilter(scrap)),
                    $total_weight: total,
                    $diff_weight: recommendedWeight - total,
                }
            });
            """
            ).substitute(
                scrap_id_col=cls.SCRAP_ID_COL_ID,
                scrap_col=cls.SCRAP_COL_ID,
                weight_col=cls.WEIGHT_COL_ID,
                total_weight=cls.TOTAL_WEIGHT_COL_ID,
                basket_weight=cls.BASKET_WEIGHT_COL_ID,
                diff_weight=cls.DIFF_WEIGHT_COL_ID,
            ),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.get_table_state()),
            sdc.JsCodeField(*cls.deselect_scrap()),
            sdc.JsCodeField(*cls.select_scrap()),
            sdc.JsCodeField(*cls.is_weighting_requested()),
        )

    @classmethod
    def get_table_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableState",
            ["viewModel", "ctx"],
            "return Boolean(!ctx.selectedScales(viewModel).includes(`${this.scale_idx}`));",
        )

    @classmethod
    def deselect_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "deselectSelectedScrap",
            [],
            """
            var updatedVM = {...this};
            updatedVM.selectedRow = [];
            return updatedVM;
            """,
        )

    @classmethod
    def select_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "selectRow",
            ["scrap"],
            """
            var updatedVM = {...this};
            if (scrap == null)
                return updatedVM;
                
            const rowScrap = this.data.find(elem => elem.id === scrap);
            if (rowScrap == null){
                return updatedVM;
            }
            
            updatedVM.selectedRow = [rowScrap,];
            return updatedVM;
            """,
        )

    @classmethod
    def is_weighting_requested(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isWeightingRequested",
            [],
            "return this.weightning_req_id === sdc.callbackRunId",
        )
