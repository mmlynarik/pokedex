from string import Template
from typing import Dict, List, Self, Tuple

import attr
import ussksdc as sdc
from dash import html
from dash_ag_grid import AgGrid
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.content.result.addition_weight_table.actions import (
    INVALIDATE_MENU_KEY,
    SPLIT_MENU_KEY,
    LongActionVM,
)
from vsadzka.settings import LANGUAGE_CODE


@attr.frozen
class ScrapAdditionTimelineTableVM:
    # Component Ids
    ID = "table"
    TABLE_WRAPPER_ID = "table-wrapper"
    OVERLAY_ID = "overlay"
    # Table column Ids
    DB_ID_COL_ID = "id"
    START_COL_ID = "start"
    END_COL_ID = "end"
    SCRAP_COL_ID = "scrap"
    SCALE_ID_COL_ID = "scale"
    MENU_COL_ID = "menu"
    WEIGHT_COL_ID = "weighted_weight"
    INVALID_COL_ID = "invalid_record"
    # Classnames
    TABLE_WRAPPER_CLASSNAME = "scrap-addition-table-wrapper"
    # Friendly user msg
    NO_DATA_MSG = "Po spustení váženia sa na tomto mieste zobrazí vážený šrot."
    LOADING_DATA = "Načítavam odvážený šrot"
    # Table settings
    TIMESTAMP_TO_LOCAL_FORMAT = f"ToLocalTimeFormat(params.value, '{LANGUAGE_CODE}')"
    START_COL_FORMATER = {"function": TIMESTAMP_TO_LOCAL_FORMAT}
    END_COL_FORMATER = {
        "function": f"params.data.{END_COL_ID} != null ? {TIMESTAMP_TO_LOCAL_FORMAT} : 'Prebieha'"
    }
    WEIGHT_COL_FORMATER = {"function": "(params.value) + ' t'"}
    ROW_MENU = [
        {"label": "Rozdeliť", "value": SPLIT_MENU_KEY},
        {"label": "Zneplatniť", "value": INVALIDATE_MENU_KEY},
    ]

    column_defs: List[Dict[str, str]] = sdc.clientside_only_state_binding(ID, "columnDefs", default=[])
    row_data: List[Dict[str, str]] = sdc.clientside_only_state_binding(ID, "rowData", default=[])
    actions: LongActionVM = sdc.child_component("split-action", factory=LongActionVM)

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(actions=LongActionVM.create(card_index))

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                AgGrid(
                    id=sdc.create_id(parent_id, cls.ID),
                    columnDefs=[
                        {
                            "headerName": "Id",
                            "field": cls.DB_ID_COL_ID,
                            "suppressMovable": True,
                            "hide": True,
                        },
                        {
                            "headerName": "Začiatok",
                            "field": cls.START_COL_ID,
                            "valueFormatter": cls.START_COL_FORMATER,
                            "suppressMovable": True,
                            "sortable": False,
                            "sort": "desc",
                        },
                        {
                            "headerName": "Koniec",
                            "field": cls.END_COL_ID,
                            "valueFormatter": cls.END_COL_FORMATER,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                        {
                            "headerName": "Šrot",
                            "field": cls.SCRAP_COL_ID,
                            "cellEditor": "agSelectCellEditor",
                            "cellEditorParams": {"values": []},
                            "editable": True,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                        {
                            "headerName": "Váha",
                            "field": cls.SCALE_ID_COL_ID,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                        {
                            "headerName": "Odvážené",
                            "field": cls.WEIGHT_COL_ID,
                            "valueFormatter": cls.WEIGHT_COL_FORMATER,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                        {
                            "headerName": "Invalid",
                            "field": cls.INVALID_COL_ID,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                        {
                            "headerName": "",
                            "field": cls.MENU_COL_ID,
                            "hide": True,
                            "cellRenderer": "rowMenu",
                            "width": 40,
                            "suppressSizeToFit": True,
                            "suppressMovable": True,
                            "sortable": False,
                        },
                    ],
                    columnSize="responsiveSizeToFit",
                    dashGridOptions={
                        "rowHeight": 30,
                        "headerHeight": 38,
                        "noRowsOverlayComponent": "CustomNoRowsOverlay",
                        "noRowsOverlayComponentParams": {
                            "message": cls.NO_DATA_MSG,
                            "fontSize": 12,
                        },
                        "loadingOverlayComponent": "CustomLoadingOverlay",
                        "loadingOverlayComponentParams": {
                            "message": cls.LOADING_DATA,
                            "fontSize": 12,
                        },
                    },
                    defaultColDef={"editable": False},
                    getRowId=f"params.data.{cls.DB_ID_COL_ID}",
                    getRowStyle={
                        "styleConditions": [
                            {
                                "condition": "params.data.invalid_record",
                                "style": {"backgroundColor": "lightgrey"},
                            },
                        ],
                    },
                    style={"height": "100%"},
                ),
                sdc.get_child_layout(parent_id, cls.actions, config),
            ],
            id=sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID),
            className=cls.TABLE_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputFieldClientSide(cls.ID, "cellValueChanged", *cls.update_data()),
            sdc.InputFieldClientSide(cls.ID, "cellRendererData", *cls.table_action()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "rowData", *cls.get_table_data()),
            sdc.OutputFieldClientSide(cls.ID, "columnDefs", *cls.update_column_defs()),
        )

    @classmethod
    def get_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableData",
            ["viewModel", "ctx"],
            Template(
                """
            const weightedScraps = ctx.getWeightedScraps(ctx.getScrapChargeId(viewModel));
            if (!weightedScraps){
                return [];
            }

            const isSwitchedBasket = (obj) => obj.start === obj.end;
            var tableData = [];
            const allValues = weightedScraps.getAll();
            for (let id in allValues){
                let ws = allValues[id];
                var menu = ${menu};
                menu[1] = {...menu[1], "label": ws.invalid_record ? 'Uplatniť' : 'Zneplatniť'};
                tableData.push({
                    "$db_id_col": id,
                    "$start_col": ws.start,
                    "$end_col": ws.end,
                    "$scrap_col": ws.scrap,
                    "$scale_col": ws.scale_id,
                    "$weight_col": ctx.kgsToTons(ws.weight),
                    "$invalid_col": ws.invalid_record,
                    "$menu_col": isSwitchedBasket(ws) ? [] : menu,
                });
            }
            return tableData;
            """
            ).substitute(
                db_id_col=cls.DB_ID_COL_ID,
                start_col=cls.START_COL_ID,
                end_col=cls.END_COL_ID,
                scrap_col=cls.SCRAP_COL_ID,
                scale_col=cls.SCALE_ID_COL_ID,
                weight_col=cls.WEIGHT_COL_ID,
                menu_col=cls.MENU_COL_ID,
                menu=cls.ROW_MENU,
                invalid_col=cls.INVALID_COL_ID,
            ),
        )

    @classmethod
    def update_column_defs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateColumnDefs",
            ["viewModel", "ctx"],
            Template(
                """
            return viewModel.column_defs.map(
                colDef => {
                    let updateDef = {...colDef};
                    if (['${db_id}', '${invalid_id}'].includes(colDef.field))
                        updateDef.hide = !ctx.debug;
                    if (colDef.field === '${split}')
                        updateDef.hide = ctx.readOnly;
                    if (colDef.field === '${scrap}'){
                        updateDef.cellEditorParams = {
                            'values': ctx.models.availableScraps.getAllScrapTypes()
                        };
                        updateDef.editable = ctx.readOnly ? false : {'function': 'params.data.${end} != -1'};
                    }
                    return updateDef;
                }
            );
            """
            ).substitute(
                db_id=cls.DB_ID_COL_ID,
                invalid_id=cls.INVALID_COL_ID,
                split=cls.MENU_COL_ID,
                scrap=cls.SCRAP_COL_ID,
                end=cls.END_COL_ID,
            ),
        )

    @classmethod
    def update_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateData",
            ["viewModel", "changed", "ctx"],
            """
            const weightedScraps = ctx.getWeightedScraps(ctx.getScrapChargeId(viewModel));
            if (!weightedScraps){
                return viewModel;
            }

            var update = {};
            update[changed.colId] = changed.value;
            weightedScraps.update(Number(changed.rowId), update);
            return viewModel;
            """,
        )

    @classmethod
    def table_action(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "tableAction",
            ["viewModel", "action", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            const objId = Number(action.rowId);
            if (action.value === ${split_key}){
                updatedVM.actions = updatedVM.actions.doAction(
                    {${split_key}: objId}, "Prebieha rozdeľovanie váhy."
                );
            }
            if (action.value === ${invalidate_key}){
                const weightedScraps = ctx.getWeightedScraps(ctx.getScrapChargeId(viewModel));
                let obj = weightedScraps.get(objId);
                weightedScraps.update(objId, {'invalid_record': !obj.invalid_record});
            }
            return updatedVM;
            """
            ).substitute(split_key=SPLIT_MENU_KEY, invalidate_key=INVALIDATE_MENU_KEY),
        )
