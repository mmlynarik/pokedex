from string import Template
from typing import Dict, List, Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import dash_table, html
from dash.dash_table.Format import Format, Scheme
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@attr.frozen
class RawFeChemTableVM:
    # Component Ids
    _ID = "table"
    CHEM_NAME_COL_ID = "name"
    RAW_FE_CHEM_COL_ID = "value"
    VALIDATION_LIST_ID = "validation-msg"
    TABLE_WRAPPER_ID = "wrapper"
    # Component classname
    ERROR_LIST = "validation-error-list"
    # User friendly user
    LABEL = "Chémia surového železa"

    data: List[Dict[str, str]] = sdc.clientside_one_way_binding_with_both_states(
        _ID,
        "data",
        default=[],
    )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                dbc.Label(cls.LABEL),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls._ID),
                    columns=[
                        {"name": "Prvok", "id": cls.CHEM_NAME_COL_ID, "type": "text", "editable": False},
                        {
                            "name": "Hodnota [%]",
                            "id": cls.RAW_FE_CHEM_COL_ID,
                            "type": "numeric",
                            "format": Format(precision=3, scheme=Scheme.fixed),
                            "validation": {"default": 0.0},
                            "on_change": {"action": "coerce", "failure": "default"},
                        },
                    ],
                    editable=not config.read_only,
                ),
                html.Ul(id=sdc.create_id(parent_id, cls.VALIDATION_LIST_ID), className=cls.ERROR_LIST),
            ],
            id=sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls._ID, "data", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "data", "ctx"],
            """
            var rawFeChem = {};
            data.forEach(chem => rawFeChem[chem.name] = chem.value);
            const scrapChargeId = ctx.getScrapChargeId(this);
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(idx, {"raw_fe_chem": rawFeChem});
            }
            return viewModel;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.TABLE_WRAPPER_ID, "hidden", *cls.show_on_debug()),
            sdc.OutputFieldClientSide(cls.VALIDATION_LIST_ID, "children", *cls.get_validation_msg()),
        )

    @classmethod
    def show_on_debug(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("showOnDebug", ["viewModel", "ctx"], "return !ctx.debug;")

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidationMsg",
            ["viewModel", "ctx"],
            """
            const listElem = {
                type: "Li",
                namespace: "dash_html_components",
                props: {},
            };
            const limits = {
                "S": {min:0.002, max:0.030},
                "Cu": {min:0.0, max:0.1},
                "Ni": {min:0.0, max:0.1},
                "Cr": {min:0.0, max:0.1},
                "Mo": {min:0.0, max:0.1},
                "Sn": {min:0.0, max:0.1},
                "Si": {min:0.0, max:1.0},
            };

            const rawFeChem = viewModel.data || [];
            var warnings = Array();
            rawFeChem.forEach(chem => {
                let limit = limits[chem.name];
                if (limit.min > chem.value || limit.max < chem.value)
                    warnings.push(
                        {...listElem, props: {children: `Podozrivé chemické zloženie surového železa pre prvok ${chem.name}`}}
                    );
            });
            return warnings;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_table_data()),)

    @classmethod
    def set_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setTableData",
            ["rawFeChem"],
            Template(
                """
            var updatedVM = {...this};
            var tableData = [];
            for (let chem in rawFeChem){
                tableData.push({"$chem_name": chem, "$chem_value": rawFeChem[chem]});
            }
            updatedVM.data = tableData;
            return updatedVM;
            """
            ).substitute(
                chem_name=cls.CHEM_NAME_COL_ID,
                chem_value=cls.RAW_FE_CHEM_COL_ID,
            ),
        )
