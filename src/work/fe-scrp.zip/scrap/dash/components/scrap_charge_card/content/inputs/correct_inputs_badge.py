from typing import Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class CorrectInputsBadgeVM:
    # Component id
    WRAPPER_ID = "badge-wrapper"
    # User friendly msg
    APPLICATION_OF_CHANGES = "Pre aplikovanie zmenených vstupov je potrebné prepočítať vsádzku"

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Badge:
        return html.Div(
            children=dbc.Badge(cls.APPLICATION_OF_CHANGES, color="danger"),
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.WRAPPER_ID, "hidden", *cls.hide_warning()),)

    @classmethod
    def hide_warning(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideWarning",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            return ctx.isInputsSameAsOptimSnapshot(scrapChargeId);
            """,
        )
