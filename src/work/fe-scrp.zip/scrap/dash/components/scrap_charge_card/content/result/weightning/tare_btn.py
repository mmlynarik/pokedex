import dash_mantine_components as dmc
from dash import dcc, html

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig

TARE_BTN_LABEL = "Tare"


def get_tare_btn_layout(
    wrapper_id: str, btn_id: str, trigger_id: str, config: ScrapLoadingStationConfig
) -> html.Div:
    return html.Div(
        children=[
            dmc.Button(
                TARE_BTN_LABEL,
                id=btn_id,
                disabled=config.read_only,
                size="sm",
                variant="subtle",
                color="red.8",
            ),
            dcc.Store(id=trigger_id),
        ],
        id=wrapper_id,
    )
