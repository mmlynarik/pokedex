from typing import Tuple

import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@frozen
class OptimizationProgressBarVM:
    # Component id
    ID = "progress-bar"
    WRAPPER_ID = "progress-bar-wrapper"
    PROGRESS_ID = "progress"
    # User friendly msg
    OPTIMIZATION_SCRAP_CHARGE = "Optimalizujem šrotovu vsádzku"

    hidden: bool = sdc.clientside_one_way_binding_with_state(WRAPPER_ID, "hidden", default=True)
    progress: str = sdc.clientside_one_way_binding_with_state(PROGRESS_ID, "children", default="")

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                dmc.Title(cls.OPTIMIZATION_SCRAP_CHARGE, order=4),
                dmc.Loader(variant="bars", size="xl"),
                dmc.Text(id=sdc.create_id(parent_id, cls.PROGRESS_ID)),
            ],
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
            hidden=True,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_visibility()),
            sdc.JsCodeField(*cls.set_progress()),
        )

    @classmethod
    def set_visibility(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setHidden",
            ["hidden"],
            """
            var updatedVM = {...this};
            updatedVM.hidden = hidden;
            return updatedVM;
            """,
        )

    @classmethod
    def set_progress(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setProgress",
            ["progress"],
            """
            var updatedVM = {...this};
            updatedVM.progress = progress + '%';
            return updatedVM;
            """,
        )
