from typing import Self, Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.content.inputs.advance_settings.raw_fe_chem_table import (
    RawFeChemTableVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.advance_settings.sc_limits_table import (
    ScrapChargeLimitsTableVM,
)


@attr.frozen
class AdvanceSettingInputsTableVM:
    # Component ids
    ID = "advance-settings-collapse"
    WRAPPER_ID = f"{ID}-wrapper"

    scrap_charge_limits: ScrapChargeLimitsTableVM = sdc.child_component(
        "scrap-charge", factory=ScrapChargeLimitsTableVM
    )
    raw_fe_chem: RawFeChemTableVM = sdc.child_component("raw-fe-chem", factory=RawFeChemTableVM)
    is_open: bool = sdc.clientside_one_way_binding_with_state(
        ID,
        "is_open",
        default=False,
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(scrap_charge_limits=ScrapChargeLimitsTableVM.create(card_index))

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return dbc.Collapse(
            id=sdc.create_id(parent_id, cls.ID),
            children=html.Div(
                children=[
                    sdc.get_child_layout(parent_id, cls.scrap_charge_limits, config),
                    sdc.get_child_layout(parent_id, cls.raw_fe_chem, config),
                ],
                id=sdc.create_id(parent_id, cls.WRAPPER_ID),
            ),
            is_open=False,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_inputs_value()),
            sdc.JsCodeField(*cls.toggle_collapse()),
        )

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValues",
            ["scrapCharge", "ctx"],
            """
            var updatedVM = {...this};
            updatedVM.scrap_charge_limits = this.scrap_charge_limits.setTableData(scrapCharge?.scrap_limits ?? [], ctx);
            updatedVM.raw_fe_chem = this.raw_fe_chem.setTableData(scrapCharge?.raw_fe_chem ?? []);
            return updatedVM;
            """,
        )

    @classmethod
    def toggle_collapse(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleCollapse",
            [],
            """
            var updatedVM = {...this};
            updatedVM.is_open = !updatedVM.is_open;
            return updatedVM;
            """,
        )
