from datetime import date
from functools import lru_cache
from typing import Optional, Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from scrap_core.utils import convert_tons_to_kilograms
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from usskssgrades.grade import Grade

from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.components.scrap_charge_card.content.inputs.pig_iron_weight import PigIronWeightInputVM
from scrap.dash.database_api import steel_grades


def float_or_none(value: str) -> Optional[float]:
    if not value:
        return None
    return float(value)


@lru_cache(maxsize=128)
def get_grade_cached(grade_id: int, for_date: date) -> Grade:
    return steel_grades.get_grade_from_id(grade_id, for_date)


@attr.frozen
class GradeAndWeightInputsVM:
    # Component ids
    GRADE_ID = "grade-selector"
    ORDER_NUM_AND_GRADE_ID = "order-num-id"
    ID = "input"
    VALIDATION_MSG_ID = "msg"
    WRAPPER_ID = "input-wrapper"
    GRADE_WRAPPER_ID = "selector-wrapper"
    ORDER_NUM_AND_GRADE_WRAPPER_ID = "order-num-wrapper-id"
    COMPUTE_PIG_IRON_TRIGGER_ID = "compute-pig-iron-trigger"
    COMPUTED_PIG_IRON_WEIGHT_ID = "computed-pig-iron-weight"
    # User friendly msg
    LABEL = "Hmotnosť šrotu"
    GRADE_LABEL = "Plánovaná akosť"
    ORDER_NUM_AND_GRADE_LABEL = "ID výroby"
    PLACEHOLDER = "Zadajte hmotnosť šrotu"
    GRADE_PLACEHOLDER = "Vyberte plánovanú akosť"
    ORDER_NUM_AND_GRADE_PLACEHOLDER = "Vyberte ID výroby"
    # Classnames
    INPUT_CLASSNAME = "input-component"

    scrap_weight: Optional[float] = sdc.clientside_one_way_binding_with_both_states(
        ID, "value", default=None, converter=float_or_none
    )
    grade: Optional[int] = sdc.clientside_one_way_binding_with_both_states(
        GRADE_ID,
        "value",
        default=None,
    )
    order_num_and_grade: Optional[str] = sdc.clientside_one_way_binding_with_both_states(
        ORDER_NUM_AND_GRADE_ID,
        "value",
        default=None,
    )
    compute_pig_iron_trigger: Optional[int] = sdc.clientside_one_way_binding_with_state(
        COMPUTE_PIG_IRON_TRIGGER_ID, "data", default=0
    )
    normal_heat_weight: Optional[int] = sdc.binding(
        COMPUTED_PIG_IRON_WEIGHT_ID,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    pig_iron: PigIronWeightInputVM = sdc.child_component("pig-iron", factory=PigIronWeightInputVM)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:

        return (
            html.Div(
                children=[
                    dmc.Select(
                        clearable=True,
                        debounce=700,
                        disabled=config.read_only,
                        id=sdc.create_id(parent_id, cls.GRADE_ID),
                        label=cls.GRADE_LABEL,
                        placeholder=cls.GRADE_PLACEHOLDER,
                        searchable=True,
                    ),
                ],
                className=cls.INPUT_CLASSNAME,
                id=sdc.create_id(parent_id, cls.GRADE_WRAPPER_ID),
            ),
            html.Div(
                children=[
                    dmc.Select(
                        clearable=True,
                        debounce=700,
                        disabled=config.read_only,
                        id=sdc.create_id(parent_id, cls.ORDER_NUM_AND_GRADE_ID),
                        label=cls.ORDER_NUM_AND_GRADE_LABEL,
                        placeholder=cls.ORDER_NUM_AND_GRADE_PLACEHOLDER,
                        searchable=True,
                    ),
                ],
                className=cls.INPUT_CLASSNAME,
                id=sdc.create_id(parent_id, cls.ORDER_NUM_AND_GRADE_WRAPPER_ID),
            ),
            html.Div(
                children=[
                    dmc.TextInput(
                        debounce=700,
                        disabled=config.read_only,
                        id=sdc.create_id(parent_id, cls.ID),
                        label=cls.LABEL,
                        placeholder=cls.PLACEHOLDER,
                        persisted_props=[],
                        type="number",
                    ),
                    dcc.Store(sdc.create_id(parent_id, cls.COMPUTE_PIG_IRON_TRIGGER_ID)),
                    dcc.Store(sdc.create_id(parent_id, cls.COMPUTED_PIG_IRON_WEIGHT_ID)),
                ],
                className=cls.INPUT_CLASSNAME,
                id=sdc.create_id(parent_id, cls.WRAPPER_ID),
            ),
            sdc.get_child_layout(parent_id, cls.pig_iron, config),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.ID, "value", *cls.update_scrap_weight()),
            sdc.InputFieldClientSide(cls.GRADE_ID, "value", *cls.update_grade()),
            sdc.InputFieldClientSide(cls.ORDER_NUM_AND_GRADE_ID, "value", *cls.update_order_num()),
            sdc.InputField(cls.COMPUTE_PIG_IRON_TRIGGER_ID, "modified_timestamp", cls.compute_pig_iron),
            sdc.InputFieldClientSide(
                cls.COMPUTED_PIG_IRON_WEIGHT_ID, "modified_timestamp", *cls.set_pig_iron_weight()
            ),
        )

    @classmethod
    def update_grade(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateGradeInDatasource",
            ["viewModel", "grade", "ctx"],
            """
            var updatedVM = {...viewModel}
            var [orderNum, gradeIdByOrderNum] = [null, null];
            
            if (updatedVM.order_num_and_grade != null)
                [orderNum, gradeIdByOrderNum] = updatedVM.order_num_and_grade.split(',');

            const selectedScrapChargeId = ctx.getScrapChargeId(viewModel);
            ctx.updateSelectedScrapCharge(selectedScrapChargeId, {"grade_id": grade});
            if (grade != null && viewModel.scrap_weight != null){
                updatedVM.pig_iron = updatedVM.pig_iron.showLoader();
                updatedVM.compute_pig_iron_trigger = Number(new Date());
            }
            if (grade != null && gradeIdByOrderNum !== grade){
                ctx.updateSelectedScrapCharge(selectedScrapChargeId, {"order_num": null});
                updatedVM.order_num_and_grade = null;
            }
            
            return updatedVM;
            """,
        )

    @classmethod
    def update_order_num(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateOrderNum",
            ["viewModel", "orderNumAndGrade", "ctx"],
            """
            var updatedVM = {...viewModel};
            
            var [orderNum, gradeId] = [null, null];
            if (orderNumAndGrade != null)
                [orderNum, gradeId] = orderNumAndGrade.split(',');
            
            var update = {"order_num": Number(orderNum)};
            if (updatedVM.grade == null || updatedVM.grade !== gradeId){
                gradeId = gradeId != null ? Number(gradeId): gradeId;
                update["grade_id"] = gradeId;
                updatedVM.grade = gradeId;
            }
            const selectedScrapChargeId = ctx.getScrapChargeId(viewModel);
            ctx.updateSelectedScrapCharge(selectedScrapChargeId, update);

            return updatedVM;
            """,
        )

    @classmethod
    def update_scrap_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel, weight, ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            const scrapCharge = ctx.models.scrapCharges.get(scrapChargeId);
            if (!scrapCharge)
                return viewModel;
                
            var updatedVM = {...viewModel}
            if (!weight && !scrapCharge.total_scrap_weight)
                return updatedVM;

            const convertedWeight = (weight || null) === null ? null : Number(weight);
            ctx.updateSelectedScrapCharge(
                scrapChargeId,
                {"total_scrap_weight": ctx.tonsToKgs(convertedWeight)}
            );
            
            if (updatedVM.grade != null && weight != null){
                updatedVM.pig_iron = updatedVM.pig_iron.showLoader();
                updatedVM.compute_pig_iron_trigger = Number(new Date());
            }
            return updatedVM;
            """,
        )

    @classmethod
    def set_pig_iron_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setPigIronWeight",
            ["viewModel, modifiedTimestamp, ctx"],
            """
            var updatedVM = {...viewModel}
            updatedVM.pig_iron = viewModel.pig_iron.setWeight(
                ctx.kgsToTons(viewModel.normal_heat_weight)
            );
            const selectedScrapChargeId = ctx.getScrapChargeId(viewModel);
            ctx.updateSelectedScrapCharge(selectedScrapChargeId, {"pig_iron_weight": viewModel.normal_heat_weight});
            updatedVM.pig_iron = updatedVM.pig_iron.hideLoader();
            
            return updatedVM;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "error", *cls.get_scrap_validation_msg()),
            sdc.OutputFieldClientSide(cls.GRADE_ID, "data", *cls.get_grades_options()),
            sdc.OutputFieldClientSide(cls.GRADE_ID, "error", *cls.get_grade_validation_msg()),
            sdc.OutputFieldClientSide(cls.ORDER_NUM_AND_GRADE_ID, "data", *cls.get_order_num_options()),
            sdc.OutputFieldClientSide(cls.ORDER_NUM_AND_GRADE_WRAPPER_ID, "hidden", *cls.hide_on_ss1()),
        )

    @classmethod
    def hide_on_ss1(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("hideOnSs1", ["viewModel", "ctx"], "return ctx.steelshop === 1")

    @classmethod
    def get_grades_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getGradeOptions",
            ["viewModel", "ctx"],
            """
            return Object.values(ctx.models.gradeDefinitions.getAll()).map(
                grade => {
                    return {"label": grade.label, "value": grade.grade_id}
                }
            )
            """,
        )

    @classmethod
    def get_order_num_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getOrderNumOptions",
            ["viewModel", "ctx"],
            """
            const scrapCharge = ctx.getScrapCharge(viewModel);
            if (!scrapCharge?.heat_plan?.heats) {
                return [];
            }

            var heatPlans = Object.values(scrapCharge?.heat_plan.heats);
            const grade = ctx.grade(viewModel);
            if (grade != null)
                heatPlans = heatPlans.filter(obj => obj.grade_id === grade);

            const reducedHeatPlans = heatPlans.map(
                plan => {
                    let {grade_id, order_num} = plan;
                    return {"grade_id": grade_id, "order_num": order_num}
                }
            );
            const withoutDuplicates = new Set(reducedHeatPlans.map(JSON.stringify));
            const heatPlanList = Array.from(withoutDuplicates).map(JSON.parse);

            if (heatPlanList.length === 0)
                return [];
            
            return Object.values(heatPlanList).map(
                heat => {
                    return {"label": `${heat.order_num} - (${heat.grade_id})`, "value": `${heat.order_num},${heat.grade_id}`}
                }
            );
            """,
        )

    @classmethod
    def get_grade_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getGradeValidationMsg",
            ["viewModel", "ctx"],
            """
            const selectedScrapCharge = ctx.getScrapCharge(viewModel);
            if (!this.grade && Boolean(selectedScrapCharge?.optimization_start_clicked))
                return "Pre optimalizáciu je nutné vybrať grade";
            if (selectedScrapCharge != null && selectedScrapCharge?.heat_plan?.heats != undefined){
                const allGrades = Array.from(
                    new Set(Object.values(selectedScrapCharge.heat_plan.heats).map(obj => obj.grade_id))
                );
                if (ctx.steelshop === 2 && this.grade != null && !allGrades.includes(this.grade))
                    return "Zvolená akosť sa nenachádza v pláne výroby";
            }
            return "";
            """,
        )

    @classmethod
    def get_scrap_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getScrapValidationMsg",
            [],
            """
            if ((this.scrap_weight === "" ? null : this.scrap_weight) != null 
                && (this.scrap_weight <= 10 || this.scrap_weight > 60))
                return `Podozrivá hmotnosť šrotu ${this.weight}`;
            return "";
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_grade_and_weight_inputs()),)

    @classmethod
    def set_grade_and_weight_inputs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setGradeAndWeightInputs",
            ["grade", "orderNum", "gradeByOrderNum", "scrapWeight", "pigIronWeight"],
            """
            var updatedVM = {...this};
            updatedVM.grade = grade;
            updatedVM.order_num_and_grade = `${orderNum},${gradeByOrderNum}`;
            updatedVM.scrap_weight = scrapWeight == null ? undefined : scrapWeight;
            updatedVM.pig_iron = this.pig_iron.setWeight(pigIronWeight);
            return updatedVM;
            """,
        )

    def compute_pig_iron(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        if self.scrap_weight is None or self.grade is None:
            return attr.evolve(self, normal_heat_weight=None)

        grade = get_grade_cached(self.grade, date.today())
        return attr.evolve(
            self, normal_heat_weight=grade.normal_heat_weight - convert_tons_to_kilograms(self.scrap_weight)
        )
