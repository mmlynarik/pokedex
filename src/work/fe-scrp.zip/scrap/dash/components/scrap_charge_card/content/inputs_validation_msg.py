from string import Template
from typing import Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class InputsValidationMsgVM:
    # Component id
    ID = "validation-msg"
    # User friendly msg
    INITIAL_MSG = "Pre spustenie výpočtu vsádzky je potrebné vyplniť vstupné dáta."
    CORRECT_MSG = "Nasledujúce dáta boli použité pre výpočet šrotovej vsádzky."
    INCORRECT_MSG = "Pre aplikovanie zmenených vstupov je potrebné prepočítať vsádzku."

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Text:
        return dmc.Text(cls.ID, id=sdc.create_id(parent_id, cls.ID))

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "children", *cls.set_msg()),
            sdc.OutputFieldClientSide(cls.ID, "className", *cls.set_class_name()),
        )

    @classmethod
    def set_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setMsg",
            ["viewModel", "ctx"],
            Template(
                """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            if (ctx.selectedScrapChargeOptimization(scrapChargeId) === null)
                return '${initial}';
            return ctx.isInputsSameAsOptimSnapshot(scrapChargeId) ? '${correct}' : '${incorrect}';
            """
            ).substitute(initial=cls.INITIAL_MSG, correct=cls.CORRECT_MSG, incorrect=cls.INCORRECT_MSG),
        )

    @classmethod
    def set_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setClassName",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            if (ctx.selectedScrapChargeOptimization(scrapChargeId) === null)
                return '';
            return ctx.isInputsSameAsOptimSnapshot(scrapChargeId) ? 'success' : 'warning';
            """,
        )
