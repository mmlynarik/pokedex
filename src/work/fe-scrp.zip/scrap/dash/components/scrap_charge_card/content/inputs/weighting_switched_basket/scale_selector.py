from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class ScaleSelectorVM:
    # Component id
    ID = "selector"
    # User friendly msg
    LABEL = "Zvoľte váhu"
    PLACEHOLDER = "Vyber váhu"

    active_scale: Optional[int] = sdc.binding(
        ID,
        "value",
        cs_read=True,
        cs_write=True,
        cs_state=True,
        ss_read=False,
        ss_write=False,
        ss_state=True,
        default=None,
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Select:
        return dmc.Select(
            label=cls.LABEL,
            placeholder=cls.PLACEHOLDER,
            id=sdc.create_id(parent_id, cls.ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "data", *cls.get_selector_options()),)

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getScaleOptions",
            ["viewModel", "ctx"],
            "return ctx.scaleIds.map(s => {return {'label': s.toUpperCase(), 'value': s}});",
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.has_selected()),
            sdc.JsCodeField(*cls.get_selected_scale_id()),
            sdc.JsCodeField(*cls.reset_selected_scale()),
        )

    @classmethod
    def has_selected(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasSelected",
            [],
            "return this.active_scale != null;",
        )

    @classmethod
    def get_selected_scale_id(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSelectedScaleId",
            ["ctx"],
            "return (this.active_scale == null) ? null : ctx.scaleIds[this.active_scale];",
        )

    @classmethod
    def reset_selected_scale(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetScale",
            [],
            """
            var updatedVM = {...this};
            updatedVM.active_scale = null;
            return updatedVM;
            """,
        )
