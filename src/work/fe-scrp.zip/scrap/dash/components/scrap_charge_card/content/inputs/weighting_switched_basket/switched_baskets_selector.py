from typing import List, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class SwitchedBasketIdsVM:
    # Component Id
    ID = "input"
    # User friendly MSG
    LABEL = "Čísla korýt na váhe"
    PLACEHOLDER = "Vyber čísla korýt"
    NOTHING_FOUND = "Koryto sa nepodarilo nájsť"

    basket_ids: List[str] = sdc.binding(
        ID,
        "value",
        cs_read=True,
        cs_state=True,
        cs_write=True,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=None,
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.MultiSelect:
        return dmc.MultiSelect(
            clearable=True,
            debounce=700,
            id=sdc.create_id(parent_id, cls.ID),
            label=cls.LABEL,
            nothingFound=cls.NOTHING_FOUND,
            placeholder=cls.PLACEHOLDER,
            searchable=True,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "data", *cls.get_selector_options()),)

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getDropdownOptions",
            ["viewModel", "ctx"],
            """
            return Object.values(ctx.basketIds(viewModel)).map(
                basket => {
                    return {"label": basket.toString(), "value": basket}
                }
            );
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.update_basket_ids()),)

    @classmethod
    def update_basket_ids(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setBasketIds",
            ["basketIds"],
            """
            var updatedVm = {...this};
            updatedVm.basket_ids = basketIds;
            return updatedVm;
            """,
        )
