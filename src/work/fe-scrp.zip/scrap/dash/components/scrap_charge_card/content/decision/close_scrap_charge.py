import logging
import math
from datetime import datetime
from typing import Dict, Optional, Self, Tuple
from zoneinfo import ZoneInfo

import attr
import dash_bootstrap_components as dbc
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from django.db import transaction
from scrap_core.telegrams.client import send_data
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.available_scraps.model.available_scraps.api import send_loaded_scrap_mixes_to_api
from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.components.scrap_charge_card.content.decision.comment_input import OperatorCommentVM
from scrap.dash.components.scrap_charge_card.content.decision.dry_or_wet_scrap import DryOrWetVM
from scrap.dash.components.scrap_charge_card.content.decision.standard_or_reserve import StandardOrReserveVM
from scrap.dash.components.telegram_utils import InvalidSteelshopError, compose_telegram
from scrap.models import LOADED_CHARGE_OPERATOR_DECISION, Basket, ScrapCharge
from scrap.tasks import print_and_save_weighting_ticket
from vsadzka.settings import LEVEL_2_URL, SCALE_PRECISION

log = logging.getLogger(__name__)


@attr.frozen
class CloseScrapChargeVM:
    # Component id
    CARD_INDEX_ID = "card-idx"
    CLOSE_BTN_ID = "btn"
    VALIDATION_MSG_ID = "msg"
    MODAL_ID = "confirmation"
    CONFIRMATION_DATA_STORE_ID = "confirmation-data"
    # User friendly msg
    CLOSE_CHARGE = "Uzavrieť vsádzku"

    confirmation_data: Dict[str, str] = sdc.clientside_one_way_binding_with_both_states(
        CONFIRMATION_DATA_STORE_ID,
        "data",
        default={},
    )
    dry_or_wet: DryOrWetVM = sdc.child_component("dry-or-wet", factory=DryOrWetVM)
    standard_or_reserve: StandardOrReserveVM = sdc.child_component("s-or-r", factory=StandardOrReserveVM)
    operator_comment: OperatorCommentVM = sdc.child_component("operator-comment", factory=OperatorCommentVM)
    closing_in_progress: bool = sdc.clientside_one_way_binding_with_state(
        CLOSE_BTN_ID, "loading", default=False
    )
    card_index: int = sdc.one_way_binding(CARD_INDEX_ID, "data", default=-1)

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(card_index=card_index)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            [
                sdc.get_child_layout(parent_id, cls.operator_comment, config),
                sdc.get_child_layout(parent_id, cls.dry_or_wet, config),
                sdc.get_child_layout(parent_id, cls.standard_or_reserve, config),
                dmc.Button(
                    cls.CLOSE_CHARGE,
                    color="green",
                    id=sdc.create_id(parent_id, cls.CLOSE_BTN_ID),
                    disabled=config.read_only,
                ),
                dbc.FormText(id=sdc.create_id(parent_id, cls.VALIDATION_MSG_ID), color="danger"),
                dcc.Store(id=sdc.create_id(parent_id, cls.CONFIRMATION_DATA_STORE_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.CARD_INDEX_ID)),
            ],
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputFieldClientSide(cls.CLOSE_BTN_ID, "n_clicks", *cls.update_data_from_cs()),
            sdc.InputField(cls.CONFIRMATION_DATA_STORE_ID, "modified_timestamp", cls.close_scrap_charge),
        )

    @classmethod
    def update_data_from_cs(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDataFromCs",
            ["viewModel", "nClicks", "ctx"],
            """
                const updatedVm = {...viewModel};
                const scrapChargeId = ctx.getScrapChargeId(viewModel);
                updatedVm.confirmation_data =  {
                    id: sdc.callbackRunId,
                    scrapChargeId: scrapChargeId,
                    clickAt: Date.now()
                };
                if (scrapChargeId !== null){
                    const weightedScrapModel = ctx.getWeightedScraps(scrapChargeId);
                    const scraps = weightedScrapModel.getScrapsWeightSummed();

                    ctx.models.scrapCharges.update(scrapChargeId, {
                        'is_wet': ctx.isWetScrap(viewModel),
                        'is_reserve': ctx.isLoadedToReserve(viewModel),
                        'closed_at': Date.now(),
                    });
                    ctx.models.scrapCharges.save();
                    weightedScrapModel.save();

                    for (let [key, scrap] of Object.entries(ctx.models.availableScraps.getAll())){
                        if (scraps.hasOwnProperty(scrap.scrap_type)){
                            let newWeight = (scrap.weight - scraps[scrap.scrap_type]);
                            if (newWeight <= 0){
                                ctx.models.availableScraps.delete(key);
                            }else{
                                ctx.models.availableScraps.update(key, {"weight": newWeight});
                            }
                        }
                    }
                    ctx.models.availableScraps.save();
                    updatedVm.closing_in_progress = true;
                }
                return updatedVm;
            """,
        )

    def close_scrap_charge(self, modified_timestamp: int, ctx: ScrapLoadingStationCTX) -> Self:
        def add_baskets_id_to_weighted_scraps(
            scrap_charge_: ScrapCharge,
            ctx_: ScrapLoadingStationCTX,
        ) -> None:
            steelshop = ctx_.models.loading_station.steelshop
            with transaction.atomic():
                # add basket information to weighted scrap
                if steelshop == 1:
                    for scale_id in ctx_.get_active_scales(self.card_index):
                        # each scale has (or should have) associated basket
                        basket_id = ctx_.get_scale_basket_map(self.card_index)[scale_id]
                        if basket_id is None:
                            raise ValueError(f"Basket id for scale {scale_id} not set")

                        for weighted_scrap in scrap_charge_.weightedscrap_set.filter(scale_id=scale_id):
                            weighted_scrap.baskets.set(Basket.objects.filter(basket_id=basket_id))
                            weighted_scrap.save()

                elif steelshop == 2:
                    # both baskets are weighted at once,
                    # hence tuple of baskets is associated with given weighted scrap
                    for weighted_scrap in scrap_charge_.weightedscrap_set.all():
                        weighted_scrap.baskets.set(
                            Basket.objects.filter(basket_id__in=scrap_charge_.basket_ids)
                        )
                        weighted_scrap.save()

                else:
                    raise InvalidSteelshopError(
                        f"Loading station {ctx_.models.loading_station.name} "
                        f"- unsupported 'steelshop' field, expected 1 or 2, got {steelshop}"
                    )

        def update_db_data(scrap_charge_: ScrapCharge, ctx_: ScrapLoadingStationCTX) -> None:
            add_baskets_id_to_weighted_scraps(scrap_charge_, ctx_)

            scrap_charge_.operator = ctx_.models.loading_station.operator_in_control
            scrap_charge_.operator_decision = LOADED_CHARGE_OPERATOR_DECISION
            scrap_charge_.closed_at = datetime.now(tz=ZoneInfo("UTC"))
            log.info(f"Scrap charge {scrap_charge_.pk} - operator {scrap_charge_.operator} added")

            scrap_charge_.save()

        def send_telegram(scrap_charge_: ScrapCharge, ctx_: ScrapLoadingStationCTX) -> None:
            scrap_mix_mapping = ctx_.models.available_scraps.scrap_mix_mapping
            precision = math.gcd(
                ctx_.models.loading_station.model_settings.optimizer_settings.precision_step, SCALE_PRECISION
            )
            telegram = compose_telegram(scrap_charge_, ctx_.operator_id, scrap_mix_mapping, precision)

            log.info(f"Telegram raw - {attr.asdict(telegram)}")
            log.info(f"Telegram encoded - {telegram.to_bytes()}")

            log_msg = (
                f"Scrap Charge {scrap_charge_.pk} - "
                + f"telegram {telegram.tel_no}/{telegram.header.blend_id}"
            )
            if ctx_.models.loading_station.sending_telegram_required:
                send_data(telegram.to_bytes(), LEVEL_2_URL[ctx_.steelshop], timeout=5)
                log.info(log_msg + " sent successfully")
            else:
                log.warning(log_msg + " not sent. Level 2 telegrams are disabled for this loading station")

        def update_scrap_yard_data(scrap_charge_: ScrapCharge, username: str) -> Optional[str]:
            if not send_loaded_scrap_mixes_to_api(scrap_charge_, username):
                return (
                    "Prenos údajov o spotrebovanom šrote bol neúspešný kvôli chybe "
                    + "pri komunikácii so Spareparts API. Kontaktujte oddelenie IT.",
                )
            return None

        if not self.confirmation_data:
            return self

        log.info(f"Calling 'close_scrap_charge' for {self.confirmation_data['scrapChargeId']}...")

        if (modified_timestamp - (self.confirmation_data["clickAt"] or 0)) > 2000:
            log.warning(
                f"Too late, {modified_timestamp} >> {self.confirmation_data['clickAt']}, "
                f"difference {modified_timestamp  - self.confirmation_data['clickAt']}"
            )
            return self

        scrap_charge = ScrapCharge.objects.get(pk=int(self.confirmation_data["scrapChargeId"]))

        update_db_data(scrap_charge, ctx)
        log.info(f"Scrap charge {scrap_charge.pk} - db data updated")

        try:
            send_telegram(scrap_charge, ctx)
        except (ConnectionError, TimeoutError, InvalidSteelshopError):
            log.exception(f"Scrap Charge {scrap_charge.id} - telegram not sent")

        if ctx.use_scrap_yard_api:
            error_msg = update_scrap_yard_data(scrap_charge, ctx.logged_username)

            if error_msg is not None:
                log.error(
                    f"Scrap Charge {scrap_charge.pk} - scrap yard API encountered an error:\n{error_msg}"
                )
                return self
            else:
                log.info(f"Scrap Charge {scrap_charge.pk} - scrap yard API called successfully")

        print_and_save_weighting_ticket.send(scrap_charge.id)
        log.info(f"Scrap Charge {scrap_charge.pk} - weighting ticket saved and sent to printer")

        return self

    @classmethod
    def get_output_fields(cls, config: ScrapLoadingStationConfig) -> sdc.OutputFields:
        if config.read_only:
            return tuple()
        return (
            sdc.OutputFieldClientSide(cls.VALIDATION_MSG_ID, "children", *cls.get_validation_msg()),
            sdc.OutputFieldClientSide(cls.CLOSE_BTN_ID, "disabled", *cls.is_not_possible_to_close_charge()),
        )

    @classmethod
    def is_not_possible_to_close_charge(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isNotPossibleToCloseCharge",
            ["viewModel", "ctx"],
            "return viewModel.getValidationMsg(viewModel, ctx) !== ''",
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidationMsg",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            if (!ctx.isWeighingStopped(scrapChargeId)) {
                return 'Pre uzavretie vsádzky je potrebné najprv ukončiť váženie.';
            }
            
            var missingValues = [];
            if (ctx.basketIds(viewModel).length === 0)
                missingValues.push("čísla korýt");
            if (ctx.grade(viewModel) === null)
                missingValues.push("akosť");
            if (!ctx.scrapWeight(viewModel))
                missingValues.push("hmotnosť šrotu");
            if (!ctx.pigIronWeight(viewModel))
                missingValues.push("hmotnosť surového železa");
            if (ctx.isWetScrap(viewModel) === null)
                missingValues.push("typ šrotu");
            if (ctx.isLoadedToReserve(viewModel) === null)
                missingValues.push("určenie šrotu");
            if ((ctx.steelshop === 1) && !ctx.isScaleBasketMapSet(viewModel))
                missingValues.push("priradenie korýt a váh");                

            if (!missingValues.length) {
                return '';
            }
                            
            return `Pre uzavretie vsádzky je potrebné doplniť ${missingValues.join(", ")}`;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_inputs_value()),)

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["scrapCharge", "ctx"],
            """
            var updatedVm = {...this};
            updatedVm.confirmation_data = {};
            updatedVm.operator_comment = updatedVm.operator_comment.setComment(scrapCharge?.operator_comment);
            updatedVm.closing_in_progress = false;
            updatedVm.dry_or_wet = updatedVm.dry_or_wet.reset();
            updatedVm.standard_or_reserve = updatedVm.standard_or_reserve.setDefault();
            return updatedVm;
            """,
        )
