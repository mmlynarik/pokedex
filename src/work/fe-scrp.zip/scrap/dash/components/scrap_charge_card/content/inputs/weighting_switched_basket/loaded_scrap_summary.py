from string import Template
from typing import Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class LoadedScrapSummaryVM:
    # Component ids
    COMPONENT_ID = "wrapper"
    LIST_WRAPPER_ID = "list-wrapper"
    LIST_ID = "list"
    # User friendly msg
    TOP_ITEM_LABEL = "Obsah točeného koryta"

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Fade:
        return dbc.Fade(
            children=html.Div(
                children=dbc.ListGroup(
                    id=sdc.create_id(parent_id, cls.LIST_ID),
                ),
                hidden=True,
                id=sdc.create_id(parent_id, cls.LIST_WRAPPER_ID),
            ),
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "is_in", *cls.has_selected_scraps()),
            sdc.OutputFieldClientSide(cls.LIST_ID, "children", *cls.get_list_items()),
            sdc.OutputFieldClientSide(cls.LIST_WRAPPER_ID, "hidden", *cls.show_list()),
        )

    @classmethod
    def has_selected_scraps(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasSelectedScraps",
            ["viewModel", "ctx"],
            "return ctx.getSwitchedBasketsModal(viewModel)?.selectedScraps.length !== 0;",
        )

    @classmethod
    def show_list(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showList",
            ["viewModel", "ctx"],
            "return !viewModel.hasSelectedScraps(viewModel, ctx);",
        )

    @classmethod
    def get_list_items(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getListItems",
            ["viewModel", "ctx"],
            Template(
                """
            const listElem = {
                type: "ListGroupItem",
                namespace: "dash_bootstrap_components",
                props: {},
            };

            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(viewModel);
            const selectedScraps = weightingSwitchedBasket?.selectedScraps;
            const scrapWeight = (weightingSwitchedBasket?.scrapWeight || 0);
            const partialScrapWeight = (scrapWeight / selectedScraps.length).toFixed(2);

            var items = [{
                ...listElem,
                props: {children: '$top_item_label', active: true}
            }];
            selectedScraps.forEach(
                scrap => { items.push({
                    ...listElem,
                    props: {
                        children: scrap.scrap_type + " (" + scrap.tms_id + ") - " + partialScrapWeight + " t"}
                    })
                }
            );
            return items;
            """
            ).substitute(top_item_label=cls.TOP_ITEM_LABEL),
        )
