from string import Template
from typing import Dict, Optional, Self, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)

SPLIT_MENU_KEY = "1"
INVALIDATE_MENU_KEY = "2"


@attr.frozen
class LongActionVM:
    # Component Ids
    ACTION_MSG_ID = "action-msg"
    ACTION_FLAG_ID = "action"
    ACTION_RESULT_FLAG_ID = "action-result"
    MESSAGE_BUFFER_ID = "message-buffer"
    CARD_INDEX_ID = "card-index"
    # Classnames
    TABLE_WRAPPER_CLASSNAME = "scrap-addition-table-wrapper"
    LOADER_CLASSNAME = "loader"
    LOADER_DOT_CLASSNAME = "loader-dot"

    # Props
    card_index: int = sdc.one_way_binding(CARD_INDEX_ID, "data", default=-1)
    action: Dict[str, str] = sdc.clientside_one_way_binding_with_both_states(
        ACTION_FLAG_ID,
        "data",
        default={},
    )
    action_result: Dict[str, str] = sdc.clientside_state_with_server_default(
        ACTION_RESULT_FLAG_ID, "data", default={}
    )
    action_msg: str = sdc.clientside_one_way_binding(ACTION_MSG_ID, "children", default="")
    message_buffer_cs: Optional[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_BUFFER_ID,
        "data",
        default="",
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls()

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dcc.Store(id=sdc.create_id(parent_id, cls.ACTION_FLAG_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.ACTION_RESULT_FLAG_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_BUFFER_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.CARD_INDEX_ID)),
                html.Div(
                    children=[
                        "",
                        *[html.Span(".", className=cls.LOADER_DOT_CLASSNAME)] * 3,
                    ],
                    className=cls.LOADER_CLASSNAME,
                    id=sdc.create_id(parent_id, cls.ACTION_MSG_ID),
                ),
            ],
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputFieldClientSide(cls.ACTION_RESULT_FLAG_ID, "modified_timestamp", *cls.sync_data()),
            sdc.InputField(cls.ACTION_FLAG_ID, "modified_timestamp", cls.do_action),
        )

    @classmethod
    def sync_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "syncTableData",
            ["viewModel", "timestamp", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            if (Object.keys(viewModel.action_result).includes('${split_key}')){
                const weightedScraps = ctx.getWeightedScraps(ctx.getScrapChargeId(viewModel));
                if (weightedScraps !== null){
                    weightedScraps.syncData();
                }

                updatedVM.action_msg = '';
                if (viewModel.action_result[${split_key}]){
                    updatedVM.message_buffer_cs = JSON.stringify(
                        new ctx.messageDataClass(
                            "Rozdelenie váhy prebehlo úspešne.",
                            "success"
                        )
                    );
                } else {
                    updatedVM.message_buffer_cs = JSON.stringify(
                        new ctx.messageDataClass(
                            "Váhu sa nepodarilo rozdeliť.",
                            "warning"
                        )
                    );
                }
            }
            return updatedVM;
            """
            ).substitute(split_key=SPLIT_MENU_KEY),
        )

    @classmethod
    def clean_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("cleanMsg", ["viewModel"], "return true;")

    def do_action(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        if self.action is None:
            return self

        if SPLIT_MENU_KEY in self.action:
            obj_id = self.action.get(SPLIT_MENU_KEY, None)
            if obj_id is not None:
                scrap_charge_id = ctx.get_scrap_charge_id(self.card_index)
                if scrap_charge_id is not None:
                    success = ctx.models.weighted_scrap(scrap_charge_id).split(int(obj_id))
                    return attr.evolve(self, action_result={SPLIT_MENU_KEY: success})
        return self

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_action()),)

    @classmethod
    def set_action(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "doAction",
            ["action", "msg"],
            """
            var updatedVM = {...this};
            updatedVM.action = action;
            updatedVM.action_msg = msg;
            return updatedVM;
            """,
        )
