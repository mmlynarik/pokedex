from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class StandardOrReserveVM:
    # Component Id
    ID = "radio-group"

    LABEL = "Zvoľte určenie naloženia šrotu."
    STANDARD_OPTION = "standard"
    RESERVE_OPTION = "reserve"
    OPTIONS = {STANDARD_OPTION: "Naložené pre tavbu", RESERVE_OPTION: "Naložené do rezervy"}

    selected: Optional[str] = sdc.clientside_one_way_binding_with_state(ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.RadioGroup:
        return dmc.RadioGroup(
            children=dmc.Group(
                [dmc.Radio(label, value=val) for val, label in cls.OPTIONS.items()],
            ),
            id=sdc.create_id(parent_id, cls.ID),
            label=cls.LABEL,
            required=True,
            value=cls.STANDARD_OPTION,
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "selectedValue", "ctx"],
            Template(
                """
            const scrapChargeId = ctx.scrapChargeIdToClose;
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(
                    scrapChargeId, {"is_reserve": selectedValue === '$reserve_option'}
                );
            } 
            return viewModel;
            """
            ).substitute(reserve_option=cls.RESERVE_OPTION),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_input_value()),)

    @classmethod
    def set_input_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputValue",
            ["scrapCharge"],
            Template(
                """
            var updatedVM = {...this};
            
            if (scrapCharge.is_reserve == null){
                updatedVM.selected = null;
            } else {
                updatedVM.selected = scrapCharge.is_reserve ? '$reserve' : '$standard';
            }
            
            return updatedVM;
            """
            ).substitute(standard=cls.STANDARD_OPTION, reserve=cls.RESERVE_OPTION),
        )
