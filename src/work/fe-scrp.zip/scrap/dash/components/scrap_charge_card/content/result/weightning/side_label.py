from typing import Tuple

import attr
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class SideLabelVM:
    # Component ids
    SCALE_NAME_ID = "scale-name"
    SCALE_IDX_ID = "scale-idx"
    # Component classname
    TABLE_WRAPPER_CLASSNAME = "table-with-side-label"

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(id=sdc.create_id(parent_id, cls.SCALE_NAME_ID))

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.SCALE_NAME_ID, "children", *cls.get_table_title()),)

    @classmethod
    def get_table_title(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableTitle",
            ["viewModel", "ctx"],
            """
            if (ctx.selectedScales(viewModel).length === 0)
                return '';

            const scaleIdx = sdc.getParentVM(this.path).proposed_scraps.scale_idx;
            const scaleId = ctx.scaleIds[scaleIdx];
            if (ctx.steelshop === 2)
                return `Váha ${scaleId}`;

            const basket = sdc.getParentVM(this.path).basket;
            if (basket.basket == null || basket.options.length === 0)
                return `Váha ${scaleId}`;
            const basketId = basket.options[basket.basket].label;
            return `Váha ${scaleId} - ${basketId}`;
            """,
        )

    @classmethod
    def hide_scale_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideTableTitle",
            ["viewModel", "ctx"],
            """
            const scaleIdx = sdc.getParentVM(this.path).proposed_scraps.scale_idx;
            return !ctx.selectedScales(viewModel).includes(scaleIdx);
            """,
        )
