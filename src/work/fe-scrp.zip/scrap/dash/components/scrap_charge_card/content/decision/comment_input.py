from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@attr.frozen
class OperatorCommentVM:
    # Component Id
    ID = "input"
    # User friendly MSG
    LABEL = "Komentár operátora"
    DESCRIPTION = (
        "Zmenu limitov pre šroty alebo optimalizáciu spustenú napriek varovaniam je nutné zdôvodniť."
    )

    comment: Optional[str] = sdc.clientside_one_way_binding_with_state(ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> dmc.Textarea:
        return dmc.Textarea(
            label=cls.LABEL,
            placeholder=cls.DESCRIPTION,
            id=sdc.create_id(parent_id, cls.ID),
            disabled=config.read_only,
            debounce=700,
            autosize=True,
            minRows=1,
            maxRows=4,
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "comment", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(scrapChargeId, {"operator_comment": viewModel.comment});
            }
            return viewModel;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_comment()),)

    @classmethod
    def set_comment(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setComment",
            ["comment"],
            """
            var updatedVM = {...this};
            updatedVM.comment = comment;
            return updatedVM;
            """,
        )
