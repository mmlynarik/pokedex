from typing import Optional, Self, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.content.result.addition_weight_table.table import (
    ScrapAdditionTimelineTableVM,
)
from scrap.dash.components.scrap_charge_card.content.result.scale_selector import ScaleSelectorVM
from scrap.dash.components.scrap_charge_card.content.result.summary_table import LoadedScrapSummaryTableVM
from scrap.dash.components.scrap_charge_card.content.result.weightning.component import WeightingComponentVM


@attr.frozen
class ResultVM:
    # Component Ids
    FIRST_SCALE_TABLE_ID = "first-scales-tables"
    SECOND_SCALE_TABLE_ID = "second-scales-tables"
    SCALE_CONTROL_1_WS = "weighted-scrap-1-ws"
    SCALE_CONTROL_2_WS = "weighted-scrap-2-ws"
    MESSAGE_BUFFER_ID = "message-buffer"
    # Component classnames
    RESULT_COMPONENT_CLASSNAME = "scrap-charge-result"

    INPUTS_WRAPPER_CLASSNAME = "inline-inputs"
    TABLE_WRAPPER_CLASSNAME = "inline-tables"
    PURPOSE_SCRAP_TABLES_WRAPPER_CLASSNAME = "purpose-tables-wrapper"
    TABLES_WRAPPER_CLASSNAME = "tables-wrapper"

    # Child components
    scale_weightning: WeightingComponentVM = sdc.child_component(
        "scale-weightning-1",
        factory=WeightingComponentVM,
    )
    scale_weightning_2: WeightingComponentVM = sdc.child_component(
        "scale-weightning-2",
        factory=WeightingComponentVM,
    )
    scrap_addition_table: ScrapAdditionTimelineTableVM = sdc.child_component(
        "scrap-addition", factory=ScrapAdditionTimelineTableVM
    )
    scale_selector: ScaleSelectorVM = sdc.child_component("scale-selector", factory=ScaleSelectorVM)
    summary: LoadedScrapSummaryTableVM = sdc.child_component("summary", factory=LoadedScrapSummaryTableVM)
    message_buffer_cs: Optional[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_BUFFER_ID,
        "data",
        default="",
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(
            scale_weightning=WeightingComponentVM.create(scale_idx=0),
            scale_weightning_2=WeightingComponentVM.create(scale_idx=1),
            scrap_addition_table=ScrapAdditionTimelineTableVM.create(card_index),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.scale_selector),
                html.Div(
                    [
                        html.Div(
                            children=[
                                html.Div(
                                    [
                                        sdc.get_child_layout(parent_id, cls.scale_weightning, config),
                                    ],
                                    className=cls.TABLE_WRAPPER_CLASSNAME,
                                    id=sdc.create_id(parent_id, cls.FIRST_SCALE_TABLE_ID),
                                    hidden=True,
                                ),
                                html.Div(
                                    [
                                        sdc.get_child_layout(parent_id, cls.scale_weightning_2, config),
                                    ],
                                    className=cls.TABLE_WRAPPER_CLASSNAME,
                                    id=sdc.create_id(parent_id, cls.SECOND_SCALE_TABLE_ID),
                                    hidden=True,
                                ),
                            ],
                            className=cls.PURPOSE_SCRAP_TABLES_WRAPPER_CLASSNAME,
                        ),
                        sdc.get_child_layout(parent_id, cls.scrap_addition_table, config),
                        sdc.get_child_layout(parent_id, cls.summary),
                    ],
                    className=cls.TABLES_WRAPPER_CLASSNAME,
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_BUFFER_ID)),
            ],
            className=cls.RESULT_COMPONENT_CLASSNAME,
        )

    @classmethod
    def get_output_fields(cls, config: ScrapLoadingStationConfig) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(
                cls.FIRST_SCALE_TABLE_ID, "hidden", *cls.show_scrap_table_if_scale_is_selected(0)
            ),
            sdc.OutputFieldClientSide(
                cls.SECOND_SCALE_TABLE_ID, "hidden", *cls.show_scrap_table_if_scale_is_selected(1)
            ),
        )

    @classmethod
    def show_scrap_table_if_scale_is_selected(cls, scale_order: int) -> Tuple[JsCode, str]:
        code = f"""
            const selectedScales = ctx.selectedScales(viewModel);
            if(selectedScales.length === 0)
                return false
            return (!selectedScales.includes({scale_order}));
        """
        if scale_order == 1:
            code = f"return !ctx.selectedScales(viewModel).includes({scale_order});"
        return generate_clientside_callback(
            f"showTableWhenScaleIsSelected{scale_order}", ["viewModel", "ctx"], code
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_inputs_value()),)

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["selectedScales", "selectedBaskets"],
            """
            var updatedVm = {...this};
            updatedVm.scale_selector = this.scale_selector.setInputsValue(selectedScales);
            updatedVm.scale_weightning = this.scale_weightning.setInputsValue(selectedBaskets.at(0));
            updatedVm.scale_weightning_2 = this.scale_weightning_2.setInputsValue(selectedBaskets.at(1));
            return updatedVm;
            """,
        )
