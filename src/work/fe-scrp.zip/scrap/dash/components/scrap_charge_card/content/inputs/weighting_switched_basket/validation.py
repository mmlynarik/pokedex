from string import Template
from typing import Tuple

from scrap_core.optimization.datamodel import ScrapMixLimits
from scrap_core.utils import convert_kilograms_to_tons

from scrap.dash.components.scrap_charges.model.weighted_scrap.datamodel import WeightedScrapModel

SwitchedBasketValidationError = Tuple[str, ...]

VALIDATION_MSG = Template(
    "Minimalne množstvo šrotu ${scrap_type} musí byť väčšie rovné ako "
    + "${weight} ton naložených v točenom koryte."
)


def validate_loaded_switched_basket_minimum_limit(
    sc_limit_data: ScrapMixLimits, weighted_scraps: Tuple[WeightedScrapModel, ...]
) -> SwitchedBasketValidationError:
    """Check that the user has not entered the weight minimum for scrap which was loaded to switched basket

    Keyword arguments:
    sc_limit_data: ScrapMixLimits -- The scrap mix limit from DB
    weighted_scraps: Tuple[WeightedScrapModel, ...] -- Collection of the weighted scraps

    Return statement:
    return a collection of errors as msg.
    """
    loaded_switched_baskets = {scrap.scrap: scrap.weight for scrap in weighted_scraps}
    return tuple(
        VALIDATION_MSG.substitute(
            scrap_type=scrap.scrap_type,
            weight=convert_kilograms_to_tons(loaded_switched_baskets.get(scrap.scrap_type)),
        )
        for scrap in sc_limit_data
        if scrap.scrap_type in loaded_switched_baskets
        and convert_kilograms_to_tons(loaded_switched_baskets.get(scrap.scrap_type)) > (scrap.minimum or 0)
    )
