from typing import Any

import dash_mantine_components as dmc
from dash import html

STOP_BTN_LABEL = "Zastaviť"
TOOLTIP_LABEL = """
🟢 - Váha v pokoji,
🟠 - Váha v pohybe,
🔴 - Preťažená váha
"""


def get_control_panel_layout(
    tare_btn: Any,
    stop_btn: Any,
    btns_wrapper_id: str,
    control_panel_id: str,
    tooltip_id: str,
    iframe_id: str,
) -> html.Div:
    return html.Div(
        children=[
            html.Div(
                children=[
                    tare_btn,
                    stop_btn,
                ],
                id=btns_wrapper_id,
            ),
            dmc.Tooltip(
                id=tooltip_id,
                children=html.Iframe(id=iframe_id),
                className="scale-weight-tooltip",
                openDelay=250,
                disabled=True,
                closeDelay=1000,
                position="top-end",
                multiline=True,
                transition="fade",
                label=TOOLTIP_LABEL,
                width=160,
                withArrow=True,
            ),
        ],
        id=control_panel_id,
    )
