from abc import ABC, abstractmethod
from string import Template
from typing import Tuple

import attr
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class WeightInfoVM(ABC):
    # Component ids
    COMPONENT_ID = "weighting-info"
    LABEL_ID = "label"
    WEIGHT_ID = "weight"
    WEIGHT_WRAPPER_ID = "weight-wrapper"
    WEIGHT_SECONDARY_DATA_ID = "weight-secondary-data"
    # Component classnames
    WEIGHT_INFO_CLASSNAME = "weight-info"

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                html.Div(cls.get_label(), id=sdc.create_id(parent_id, cls.LABEL_ID), className="label"),
                html.Div(
                    [
                        html.Div(id=sdc.create_id(parent_id, cls.WEIGHT_ID)),
                        html.Div(id=sdc.create_id(parent_id, cls.WEIGHT_SECONDARY_DATA_ID)),
                    ],
                    id=sdc.create_id(parent_id, cls.WEIGHT_WRAPPER_ID),
                ),
            ],
            className=cls.WEIGHT_INFO_CLASSNAME,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.WEIGHT_ID, "children", *cls.get_weight()),
            sdc.OutputFieldClientSide(cls.WEIGHT_SECONDARY_DATA_ID, "children", *cls.get_secondary_info()),
        )

    @classmethod
    @abstractmethod
    def get_weight(cls) -> Tuple[JsCode, str]: ...

    @classmethod
    @abstractmethod
    def get_secondary_info(cls) -> Tuple[JsCode, str]: ...

    @classmethod
    @abstractmethod
    def get_label(cls) -> str: ...


@attr.frozen
class ScrapWeightingInfoVM(WeightInfoVM):
    @classmethod
    def get_label(cls) -> str:
        return "Váha šrotu"

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            *super().get_output_fields(),
            sdc.OutputFieldClientSide(cls.WEIGHT_ID, "className", *cls.get_classname()),
        )

    @classmethod
    def get_classname(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getClassName",
            ["viewModel", "ctx"],
            """
            const scrapWeight = viewModel.getScrapWeight(ctx);
            if (scrapWeight < 15 || scrapWeight > 50)
                return "text-warning"
            return "text-success"
            """,
        )

    @classmethod
    def get_secondary_info(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSecondaryInfo",
            ["viewModel", "ctx"],
            """
            return "Na váhe - (Voz + Koryto)";
            """,
        )

    @classmethod
    def get_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getWeight",
            ["viewModel", "ctx"],
            """
            return viewModel.getScrapWeight(ctx);
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.get_scrap_weight()),)

    @classmethod
    def get_scrap_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getScrapWeight",
            ["ctx"],
            """
            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(this);
            const basketWeight = weightingSwitchedBasket?.basketWeight;
            const waggonWeight = weightingSwitchedBasket?.waggonWeight;
            const scaleId = weightingSwitchedBasket?.selectedScale;
            if (basketWeight == null || waggonWeight == null || scaleId == null)
                return 0;

            const scrapWeight = (weightingSwitchedBasket?.loadOnScale / 1000) - (basketWeight + waggonWeight);
            if (scrapWeight >= 0)
                return scrapWeight.toFixed(2);
            return 0;
            """,
        )


@attr.frozen
class WaggonWeightInfoVM(WeightInfoVM):
    @classmethod
    def get_label(cls) -> str:
        return "Váha voza"

    @classmethod
    def get_secondary_info(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSecondaryInfo",
            ["viewModel", "ctx"],
            """
            const scaleId = ctx.getSwitchedBasketsModal(this)?.selectedScale;
            if (scaleId == null)
                return "Zvoľte váhu";
            return `Voz pre váhu ${scaleId}`;
            """,
        )

    @classmethod
    def get_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getWeight",
            ["viewModel", "ctx"],
            """
            const scaleId = ctx.getSwitchedBasketsModal(this)?.selectedScale;
            if (scaleId == null)
                return 0;

            const waggon = ctx.models.basketWaggonWeights.get(scaleId);
            return waggon.weight / 1000;
            """,
        )


@attr.frozen
class BasketWeightInfoVM(WeightInfoVM):
    @classmethod
    def get_label(cls) -> str:
        return "Váha koryta"

    @classmethod
    def get_secondary_info(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSecondaryInfo",
            ["viewModel", "ctx"],
            """
            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(viewModel);
            if (weightingSwitchedBasket?.selectedBaskets.length === 0)
                return "Neznáme koryto";
            return weightingSwitchedBasket?.selectedBaskets.map(
                basket => `Koryto ${ctx.models.basketWeights.get(basket).basket_id}`
            ).join(' + ');
            """,
        )

    @classmethod
    def get_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getWeight",
            ["viewModel", "ctx"],
            """
            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(this);
            if (weightingSwitchedBasket.selectedBaskets.length === 0)
                return 0;
            return ctx.kgsToTons(
                ctx.sum(
                    weightingSwitchedBasket.selectedBaskets.map(
                        basket => ctx.models.basketWeights.get(basket).weight
                    )
                )
            );
            """,
        )


@attr.frozen
class OnScaleWeightInfoVM(WeightInfoVM):
    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            *super().get_output_fields(),
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "className", *cls.hide_on_not_selected_scale()),
        )

    @classmethod
    def get_label(cls) -> str:
        return "Na váhe"

    @classmethod
    def get_secondary_info(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSecondaryInfo",
            ["viewModel", "ctx"],
            "return ctx.getSwitchedBasketsModal(viewModel)?.selectedScale ? 'Aktuálne' : 'Zvoľte váhu';",
        )

    @classmethod
    def get_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getWeight",
            ["viewModel", "ctx"],
            "return (ctx.getSwitchedBasketsModal(viewModel)?.loadOnScale / 1000).toFixed(2);",
        )

    @classmethod
    def hide_on_not_selected_scale(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideWhenNotSelectedScale",
            ["viewModel", "ctx"],
            Template(
                """
            const baseClassName = '${base}';
            return ctx.getSwitchedBasketsModal(viewModel)?.selectedScale != null ? baseClassName : baseClassName + ' unvisible';
            """
            ).substitute(base=WeightInfoVM.WEIGHT_INFO_CLASSNAME),
        )
