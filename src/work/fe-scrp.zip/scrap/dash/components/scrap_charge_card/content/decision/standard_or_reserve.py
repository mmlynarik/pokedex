from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class StandardOrReserveVM:
    # Component Id
    ID = "radio-group"

    LABEL = "Zvoľte určenie naloženia šrotu."
    DEFAULT_OPTION = STANDARD_OPTION = "standard"
    RESERVE_OPTION = "reserve"
    OPTIONS = {STANDARD_OPTION: "Naložené pre tavbu", RESERVE_OPTION: "Naložené do rezervy"}

    selected: Optional[str] = sdc.clientside_two_way_binding(ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.RadioGroup:
        return dmc.RadioGroup(
            children=dmc.Group(
                [dmc.Radio(label, value=val) for val, label in cls.OPTIONS.items()],
            ),
            id=sdc.create_id(parent_id, cls.ID),
            label=cls.LABEL,
            required=True,
            value=cls.STANDARD_OPTION,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.is_loaded_to_reserve()),
            sdc.JsCodeField(*cls.set_default()),
        )

    @classmethod
    def set_default(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setDefault",
            [],
            Template(
                """
            var viewModel = {...this};
            viewModel.selected = '${default}';
            return viewModel;
            """
            ).substitute(default=cls.DEFAULT_OPTION),
        )

    @classmethod
    def is_loaded_to_reserve(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isLoadedToReserve",
            [],
            Template(
                """
            var viewModel = {...this};
            if (viewModel.selected == null){
                return null;
            }
            return (viewModel.selected === '${reserve}');
            """
            ).substitute(reserve=cls.RESERVE_OPTION),
        )
