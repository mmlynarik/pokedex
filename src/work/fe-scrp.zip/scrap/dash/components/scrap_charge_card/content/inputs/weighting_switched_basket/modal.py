from string import Template
from typing import Dict, Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.loaded_scrap_summary import (
    LoadedScrapSummaryVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.scale_selector import (
    ScaleSelectorVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.scrap_selector import (
    ScrapSelectorVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.switched_baskets_selector import (
    SwitchedBasketIdsVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.tare_btn import (
    SwitchedBasketTareBtnVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.weight_info import (
    BasketWeightInfoVM,
    OnScaleWeightInfoVM,
    ScrapWeightingInfoVM,
    WaggonWeightInfoVM,
)


@attr.frozen
class LoadOnScale:
    timestamp: int
    weight: int
    scale_id: str

    @classmethod
    def from_scale_data(cls, scale_data: Tuple[int, int], scale_id: str) -> Self:
        return cls(timestamp=scale_data[0], weight=scale_data[1], scale_id=scale_id)

    @property
    def as_dict(self) -> Dict[str, int]:
        return attr.asdict(self)


@attr.frozen
class WeightingSwitchedBasketVM:
    # Component ids
    COMPONENT_ID = "modal"
    ON_WEIGHT_ID = "on-scale"
    BASKET_WEIGHT_ID = "basket-weight"
    CAR_WEIGHT_ID = "car-weight"
    SCRAP_WEIGT_ID = "scrap-weight"
    UPDATE_WEIGHT_INTERVAL_ID = "update-weight-interval"
    LOADED_SCRAP_ID = "loaded-scrap-id"
    SCALE_SELECTOR_ID = "scale-selector"
    SAVE_WEIGHT_BTN_ID = "save-weight-btn"
    LOADED_SCRAP_SUMMARY_ID = "loaded-scrap-summary"
    VALIDATION_LIST_ID = "validation-list-id"
    CARD_DECK_ID = "card-deck"
    BASKETS_ON_WAGON_ID = "basket-on-wagon"
    INPUT_GROUP_ID = "input-group"
    TARE_ID = "tare"
    # Component classnames
    TOOLTIP_CLASSNAME = "tooltip"
    # User friendly msg
    COMPONENT_LABEL = "Váženie točeného koryta"
    SAVE_BTN_LABEL = "Zaznamenať váhu"
    VALIDATION_SCRAP_COUNT = "Je potrebné zvoliť aspoň jeden šrot"
    VALIDATION_SCRAP_WEIGHT = "Váha šrotu by mala byť väčšia ako 0 t"

    is_open: bool = sdc.clientside_one_way_binding_with_state(
        COMPONENT_ID,
        "opened",
        default=False,
    )
    save_btn_n_clicks: int = sdc.binding(
        SAVE_WEIGHT_BTN_ID,
        "n_clicks",
        cs_read=False,
        cs_state=True,
        cs_write=True,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=0,
    )

    on_scale: OnScaleWeightInfoVM = sdc.child_component(ON_WEIGHT_ID, factory=OnScaleWeightInfoVM)
    waggon_weight: WaggonWeightInfoVM = sdc.child_component(CAR_WEIGHT_ID, factory=WaggonWeightInfoVM)
    basket_weight: BasketWeightInfoVM = sdc.child_component(BASKET_WEIGHT_ID, factory=BasketWeightInfoVM)
    scrap_weight: ScrapWeightingInfoVM = sdc.child_component(SCRAP_WEIGT_ID, factory=ScrapWeightingInfoVM)

    loaded_scraps: ScrapSelectorVM = sdc.child_component(LOADED_SCRAP_ID, factory=ScrapSelectorVM)
    baskets_on_wagon: SwitchedBasketIdsVM = sdc.child_component(
        BASKETS_ON_WAGON_ID, factory=SwitchedBasketIdsVM
    )
    scale_selector: ScaleSelectorVM = sdc.child_component(SCALE_SELECTOR_ID, factory=ScaleSelectorVM)

    loaded_scrap_summary: LoadedScrapSummaryVM = sdc.child_component(
        LOADED_SCRAP_SUMMARY_ID, factory=LoadedScrapSummaryVM
    )
    tare: SwitchedBasketTareBtnVM = sdc.child_component(TARE_ID, factory=SwitchedBasketTareBtnVM)

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(tare=SwitchedBasketTareBtnVM.create(card_index))

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Modal:
        return dmc.Modal(
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            centered=True,
            title=cls.COMPONENT_LABEL,
            children=[
                html.Div(
                    id=sdc.create_id(parent_id, cls.INPUT_GROUP_ID),
                    children=[
                        sdc.get_child_layout(parent_id, cls.scale_selector),
                        sdc.get_child_layout(parent_id, cls.baskets_on_wagon),
                    ],
                ),
                html.Div(
                    id=sdc.create_id(parent_id, cls.CARD_DECK_ID),
                    children=[
                        html.Div(
                            children=[
                                sdc.get_child_layout(parent_id, cls.on_scale),
                                sdc.get_child_layout(parent_id, cls.tare),
                            ],
                        ),
                        sdc.get_child_layout(parent_id, cls.waggon_weight),
                        sdc.get_child_layout(parent_id, cls.basket_weight),
                        sdc.get_child_layout(parent_id, cls.scrap_weight),
                    ],
                ),
                sdc.get_child_layout(parent_id, cls.loaded_scraps),
                sdc.get_child_layout(parent_id, cls.loaded_scrap_summary),
                html.Ul(id=sdc.create_id(parent_id, cls.VALIDATION_LIST_ID)),
                dmc.Button(
                    cls.SAVE_BTN_LABEL,
                    id=sdc.create_id(parent_id, cls.SAVE_WEIGHT_BTN_ID),
                ),
                dcc.Interval(
                    id=sdc.create_id(parent_id, cls.UPDATE_WEIGHT_INTERVAL_ID), disabled=True, interval=2000
                ),
            ],
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.SAVE_WEIGHT_BTN_ID, "n_clicks", *cls.save_weight()),
            sdc.InputFieldClientSide(cls.UPDATE_WEIGHT_INTERVAL_ID, "n_intervals", *cls.update_weight()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.UPDATE_WEIGHT_INTERVAL_ID, "disabled", *cls.disabled_interval()),
            sdc.OutputFieldClientSide(cls.VALIDATION_LIST_ID, "children", *cls.get_list_item_with_msg()),
        )

    @classmethod
    def get_list_item_with_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getListValidationMsg",
            ["viewModel", "ctx"],
            """
            if (viewModel.save_btn_n_clicks === 0)
                return [];

            const reasons = viewModel.getValidationMsg(ctx);
            if (reasons.length === 0)
                return [];

            const listElem = {
                type: "Li",
                namespace: "dash_html_components",
                props: {},
            };
            return reasons.map(
                reason => {
                    return {
                        ...listElem,
                        props: {children: reason}
                    }
                }
            );
            """,
        )

    # Only for wake up client side callbacks
    @classmethod
    def update_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("updateWeight", ["viewModel"], "return viewModel;")

    @classmethod
    def disabled_interval(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "disabledInterval",
            ["viewModel"],
            "return (!viewModel.is_open || !viewModel.scale_selector.hasSelected());",
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.open_modal()),
            sdc.JsCodeField(*cls.component_ctx()),
            sdc.JsCodeField(*cls.get_validation_msg()),
            sdc.JsCodeField(*cls.reset_modal_state()),
        )

    @classmethod
    def open_modal(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "openModal",
            ["ctx"],
            """
            var updatedVM = {...this};
            updatedVM.is_open = true;
            updatedVM.baskets_on_wagon = updatedVM.baskets_on_wagon.setBasketIds(ctx.switchedBasketIds(updatedVM));
            return updatedVM;
            """,
        )

    @classmethod
    def reset_modal_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetModalState",
            [],
            """
            this.disabled_interval = true;
            this.scale_selector = this.scale_selector.resetScale();
            this.loaded_scraps = this.loaded_scraps.resetSelectedScraps();
            this.load_on_scale_clear_data = true;
            this.save_btn_n_clicks = 0;
            return this;
            """,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidationMsg",
            ["ctx"],
            Template(
                """
            const reasons = [];
            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(this);
            if (weightingSwitchedBasket?.selectedScraps.length === 0)
                reasons.push("$scrap_count_msg");
            if (weightingSwitchedBasket?.scrapWeight === 0)
                reasons.push("$scrap_weight_msg");
            return reasons;
            """
            ).substitute(
                scrap_count_msg=cls.VALIDATION_SCRAP_COUNT, scrap_weight_msg=cls.VALIDATION_SCRAP_WEIGHT
            ),
        )

    @classmethod
    def component_ctx(cls) -> Tuple[JsCode, str]:
        return (
            JsCode(
                """
                class WeightingSwitchedBasketCtx{
                    #vm;
                    #ctx;

                    constructor(vm, ctx){
                        this.#vm = vm;
                        this.#ctx = ctx;
                    }

                    get selectedScale(){
                        return this.#vm.scale_selector.active_scale ?? null;
                    }

                    get selectedBaskets(){
                        return this.#vm.baskets_on_wagon.basket_ids ?? [];
                    }

                    get waggonWeight(){
                        return this.#vm.waggon_weight.getWeight(null, this.#ctx);
                    }

                    get basketWeight(){
                        return this.#vm.basket_weight.getWeight(null, this.#ctx);
                    }

                    get loadOnScale(){
                        if (!this.#vm.scale_selector.hasSelected())
                            return 0;
                        return this.#ctx.scaleDataFor(this.selectedScale)?.weight;
                    }

                    get selectedScraps(){
                        return this.#vm.loaded_scraps.getSelectedScraps(this.#ctx);
                    }

                    get scrapWeight(){
                        return this.#vm.scrap_weight.getScrapWeight(this.#ctx);
                    }
                }
                """
            ),
            "WeightingSwitchedBasketCtx",
        )

    @classmethod
    def save_weight(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "saveLoadedScrap",
            ["viewModel", "nClicks", "ctx"],
            """
            if (viewModel.getValidationMsg(ctx).length > 0)
                return viewModel;

            var now = new Date();
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            const weightedScrapModel = ctx.getWeightedScraps(scrapChargeId);
            const weightingSwitchedBasket = ctx.getSwitchedBasketsModal(viewModel);
            if (weightedScrapModel != null && weightingSwitchedBasket != null){
                const loadedScraps = weightingSwitchedBasket.selectedScraps.map(scrap => scrap.scrap_type);
                
                // split total weight into `loadedScraps.length` many "weight per scrap type" buckets as follows 
                // [weightQuotient + 1, weightQuotient + 1, ..., weightQuotient, ..., weightQuotient]
                // such that the sum is equal `to weightingSwitchedBasket.scrapWeight`
                  
                const weightRemainder = (weightingSwitchedBasket.scrapWeight * 1000) % loadedScraps.length;
                const weightQuotient = ((weightingSwitchedBasket.scrapWeight * 1000) - weightRemainder) / loadedScraps.length;
                
                const scale = weightingSwitchedBasket.selectedScale;
                for (let idx in loadedScraps){
                    // Due to unique constraints for weighting start time and scale id is 
                    // necessary to change the start time for every next weighted scrap
                    now.setSeconds(now.getSeconds() - idx);
                    const nowTimestamp = Number(now);
                    
                    // first `weightRemainder` weighted scrap records have weight equal to `weightQuotient + 1`,
                    // the rest of records have weight equal to `weightQuotient`
                    const scrapWeight = idx < weightRemainder ? weightQuotient + 1 : weightQuotient;    
                    weightedScrapModel.add(
                        {
                            id: (-1 - idx),
                            start: nowTimestamp,
                            end: nowTimestamp,
                            scale_id: scale,
                            scrap: loadedScraps[idx],
                            weight: scrapWeight,
                            scrap_charge_id: scrapChargeId,
                        }
                    );
                }
                weightedScrapModel.save();

                var updatedScrapLimits = []
                const scrapLimits = ctx.getScrapCharge(viewModel).scrap_limits ?? [];
                for (let scrapLimit of scrapLimits){
                    if (loadedScraps.includes(scrapLimit.scrap_type)){
                        if (scrapLimit.minimum < weightQuotient){
                            updatedScrapLimits.push({...scrapLimit, "minimum": weightQuotient})
                        }
                    }else {
                        updatedScrapLimits.push(scrapLimit)
                    }
                }
                ctx.updateSelectedScrapCharge(scrapChargeId, {"scrap_limits": updatedScrapLimits});
                ctx.models.scrapCharges.save();
            }

            viewModel = viewModel.resetModalState();
            viewModel.is_open = false;
            return viewModel;
            """,
        )
