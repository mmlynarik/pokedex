from string import Template
from typing import Collection, Tuple, Self

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.modal import (
    WeightingSwitchedBasketVM,
)


@attr.frozen
class SwitchedBasketIdsSelectorVM:
    # Component ids
    ID = "selector"
    WRAPPER_ID = "selector-wrapper"
    OPEN_WSB_MODAL_BTN_ID = "open-weighting-switched-basket-modal"
    # User friendly msg
    LABEL = "Točené korytá"
    PLACEHOLDER = "Vyber točené koryto"
    NOTHING_FOUND = "Koryto sa nepodarilo nájsť"
    WEIGHTING_SWITCHED_BASKET = "Zvážiť točené koryto"
    BASKET_WAS_WEIGHTED = "Koryto bolo zvážené"
    # Classnames
    INPUT_CLASSNAME = "input-component"
    # Settings
    MAX_SELECTED_BASKETS = 1

    switched_baskets: Collection[int] = sdc.clientside_one_way_binding_with_both_states(
        ID,
        "value",
        default=[],
    )
    weighting_switched_basket: WeightingSwitchedBasketVM = sdc.child_component(
        "weighting-switched-basket", factory=WeightingSwitchedBasketVM
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(weighting_switched_basket=WeightingSwitchedBasketVM.create(card_index))

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                dmc.MultiSelect(
                    clearable=True,
                    debounce=700,
                    disabled=config.read_only,
                    id=sdc.create_id(parent_id, cls.ID),
                    label=cls.LABEL,
                    maxSelectedValues=cls.MAX_SELECTED_BASKETS,
                    nothingFound=cls.NOTHING_FOUND,
                    placeholder=cls.PLACEHOLDER,
                    searchable=True,
                ),
                dmc.Button(
                    children=cls.WEIGHTING_SWITCHED_BASKET,
                    id=sdc.create_id(parent_id, cls.OPEN_WSB_MODAL_BTN_ID),
                    compact=True,
                    disabled=config.read_only,
                ),
                sdc.get_child_layout(parent_id, cls.weighting_switched_basket),
            ],
            className=cls.INPUT_CLASSNAME,
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),
            sdc.InputFieldClientSide(
                cls.OPEN_WSB_MODAL_BTN_ID,
                "n_clicks",
                *cls.open_wsb_modal(),
            ),
        )

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "switchedBasketIds", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            ctx.updateSelectedScrapCharge(scrapChargeId, {"switched_baskets": switchedBasketIds ?? []})
            return viewModel;
            """,
        )

    @classmethod
    def open_wsb_modal(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "openWeightingSwitchedBasketModal",
            ["viewModel", "nClicks", "ctx"],
            """
            var updatedVM = {...viewModel};
            ctx.models.scrapCharges.syncData();
            updatedVM.weighting_switched_basket = updatedVM.weighting_switched_basket.openModal(ctx);
            return updatedVM;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "data", *cls.get_selector_options()),
            sdc.OutputFieldClientSide(cls.WRAPPER_ID, "className", *cls.has_switched_basket()),
            sdc.OutputFieldClientSide(cls.OPEN_WSB_MODAL_BTN_ID, "disabled", *cls.disabled_btn()),
            sdc.OutputFieldClientSide(cls.OPEN_WSB_MODAL_BTN_ID, "children", *cls.set_btn_label()),
            sdc.OutputFieldClientSide(cls.WRAPPER_ID, "hidden", *cls.hide_for_ss1()),
        )

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getDropdownOptions",
            ["viewModel", "ctx"],
            """
            const scrapCharge = ctx.getScrapCharge(viewModel);
            const basketIds = scrapCharge?.basket_ids ?? [];
            return basketIds.map(
                (basketId) => {
                    return {"label": basketId.toString(), "value": basketId}
                }
            );
            """,
        )

    @classmethod
    def has_switched_basket(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasSwitchedBasket",
            ["viewModel", "ctx"],
            Template(
                "return (ctx.switchedBasketIds(viewModel).length === 0) ? '${base} unvisible-btn' : '${base}';"
            ).substitute(base=cls.INPUT_CLASSNAME),
        )

    @classmethod
    def disabled_btn(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "disableBtn",
            ["viewModel", "ctx"],
            "return viewModel.hasWeightedSwitchedBasket(ctx) || ctx.readOnly;",
        )

    @classmethod
    def set_btn_label(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setBtnLabel",
            ["viewModel", "ctx"],
            Template(
                """
            if (viewModel.hasWeightedSwitchedBasket(ctx))
                return '${was_weighted}';
            return '${base}';
            """
            ).substitute(base=cls.WEIGHTING_SWITCHED_BASKET, was_weighted=cls.BASKET_WAS_WEIGHTED),
        )

    @classmethod
    def hide_for_ss1(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("hideForSs1", ["viewModel", "ctx"], "return ctx.steelshop === 1;")

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_value()),
            sdc.JsCodeField(*cls.has_weighted_switched_baskets()),
        )

    @classmethod
    def set_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setSwitchedBaskets",
            ["switched_baskets"],
            """
            var updatedVM = {...this};
            updatedVM.switched_baskets = switched_baskets;
            return updatedVM;
            """,
        )

    @classmethod
    def has_weighted_switched_baskets(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasWeightedSwitchedBasket",
            ["ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(this);
            if (!scrapChargeId){
                return false;
            }

            return (
                Object.keys(ctx.getWeightedScraps(scrapChargeId).getWeightOfSwitchedBaskets())  
                .length !== 0
            );
            """,
        )
