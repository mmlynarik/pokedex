from typing import Collection, Optional, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class BasketIdsSelector:
    COMPONENT_ID = "selector"
    COMPONENT_WRAPPER_ID = "selector-wrapper"
    PLACEHOLDER = "Priraď koryto"

    basket: Optional[int] = sdc.binding(
        COMPONENT_ID,
        "value",
        cs_read=True,
        cs_state=True,
        cs_write=True,
        ss_read=False,
        ss_state=True,
        ss_write=False,
        default=None,
    )
    options: Collection[int] = sdc.binding(
        COMPONENT_ID,
        "options",
        cs_read=False,
        cs_state=True,
        cs_write=False,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=[],
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Dropdown:
        return html.Div(
            children=dcc.Dropdown(placeholder=cls.PLACEHOLDER, id=sdc.create_id(parent_id, cls.COMPONENT_ID)),
            id=sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "options", *cls.get_selector_options()),
            sdc.OutputFieldClientSide(cls.COMPONENT_WRAPPER_ID, "hidden", *cls.hide_on_ss2()),
        )

    @classmethod
    def hide_on_ss2(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("hideOnSS2", ["viewModel", "ctx"], "return ctx.steelshop === 2")

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getBasketIdsOptions",
            ["viewModel", "ctx"],
            """
            return ctx.basketIds(viewModel).map(
                (basket, idx) => {
                    return {"label": basket, "value": idx}
                }
            );
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_inputs_value()),)

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["selectedBasket"],
            """
            var updatedVm = {...this};
            updatedVm.basket = selectedBasket;
            return updatedVm;
            """,
        )
