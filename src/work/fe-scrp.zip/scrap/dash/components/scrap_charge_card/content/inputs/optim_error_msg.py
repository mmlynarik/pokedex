from typing import Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class OptimizationErrorMsgVM:
    # Component ids
    ID = "msg"
    # Component classname
    ERROR_MSG_CLASSNAME = "optimization-error"

    @classmethod
    def get_layout(cls, parent_id: str) -> dcc.Dropdown:
        return html.Div(id=sdc.create_id(parent_id, cls.ID), className=cls.ERROR_MSG_CLASSNAME, hidden=True)

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "children", *cls.get_error_msg()),
            sdc.OutputFieldClientSide(cls.ID, "hidden", *cls.hide_when_error_is_none()),
        )

    @classmethod
    def get_error_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getErrorMsg",
            ["viewModel", "ctx"],
            "return this.getOptimError(ctx.selectedScrapChargeOptimization);",
        )

    @classmethod
    def hide_when_error_is_none(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideWhenErrorIsNull",
            ["viewModel", "ctx"],
            "return !Boolean(this.getOptimError(ctx.selectedScrapChargeOptimization));",
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.get_optim_error()),)

    @classmethod
    def get_optim_error(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getOptimError",
            ["lastOptimization"],
            """
            if (!lastOptimization || !lastOptimization.result || !lastOptimization.result.error)
                return "";
            return  "Nastala chyba pri optimalizácií s identifikačným číslom "
                    + lastOptimization.optimization_id
                    + ". Skontrolujte vstupy a skúste znova. V prípade opakovaných problémov kontaktujte IT "
                    + "(JTkacik@sk.uss.com) a uveďte identifikačné číslo optimalizácie."
            """,
        )
