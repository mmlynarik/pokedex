import logging
from typing import Self, Tuple

import attr
from dash import dcc, html
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationCTX
from scrap.scales.utils import tare_scale

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


@attr.frozen
class SwitchedBasketTareBtnVM:
    # Component Id
    ID = "btn"
    CARD_INDEX_ID = "card-idx"
    WRAPPER_ID = "wrapper"
    # User friendly MSG
    TARE_BTN_LABEL = "Tare"

    card_index: int = sdc.one_way_binding(CARD_INDEX_ID, "data", default=-1)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            [
                dmc.Button(
                    cls.TARE_BTN_LABEL,
                    id=sdc.create_id(parent_id, cls.ID),
                    compact=True,
                    disabled=True,
                    size="xs",
                    variant="subtle",
                    radius="xs",
                    color="red.8",
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.CARD_INDEX_ID)),
            ]
        )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(card_index=card_index)

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "disabled", *cls.not_scale_selected()),)

    @classmethod
    def not_scale_selected(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "notScaleSelected",
            ["viewModel", "ctx"],
            """
            if (ctx.getSwitchedBasketsModal(viewModel).selectedScale == null){
                return ctx.readOnly;
            }
            return !ctx.scaleControl;
            """,
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.ID, "n_clicks", cls.send_tare_command),)

    def send_tare_command(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        scale_id = ctx.get_switched_basket_selected_scale_id(self.card_index)
        if scale_id is None:
            return self

        if ctx.read_only or not ctx.scale_control:
            logger.info(
                f"User {ctx.logged_username} trying to tare the scale {scale_id} on loading station "
                + f"{ctx.models.loading_station.name}, but user doesn't have a permission to this action."
            )
            return self

        tare_scale(scale_id)

        return self
