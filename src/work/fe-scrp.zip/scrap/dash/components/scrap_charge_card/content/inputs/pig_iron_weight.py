from datetime import date
from functools import lru_cache
from typing import Any, Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from usskssgrades.grade import Grade

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.database_api import steel_grades


@lru_cache(maxsize=128)
def get_grade_cached(grade_id: int, for_date: date) -> Grade:
    return steel_grades.get_grade_from_id(grade_id, for_date)


@attr.frozen
class PigIronWeightInputVM:
    # Component Ids
    ID = "input"
    VALIDATION_MSG_ID = "msg"
    WRAPPER_ID = "input-wrapper"
    # User friendly msg
    LABEL = "Hmotnosť sur. železa"
    PLACEHOLDER = "Zadajte hmotnosť sur. železa"
    # Classnames
    INPUT_CLASSNAME = "input-component"
    LOADER_CLASSNAME = "loader"
    LOADER_DOT_CLASSNAME = "loader-dot"

    weight: Optional[int] = sdc.clientside_one_way_binding_with_state(
        ID,
        "value",
        default=None,
    )
    right_section: Any = sdc.clientside_one_way_binding_with_state(ID, "rightSection", default=None)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=dmc.TextInput(
                debounce=700,
                disabled=config.read_only,
                id=sdc.create_id(parent_id, cls.ID),
                label=cls.LABEL,
                placeholder=cls.PLACEHOLDER,
                type="number",
            ),
            className=cls.INPUT_CLASSNAME,
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel, weight, ctx"],
            """
            const selectedScrapChargeId = ctx.getScrapChargeId(viewModel);
            const selectedScrapCharge = ctx.models.scrapCharges.get(selectedScrapChargeId);
            if (!selectedScrapChargeId)
                return viewModel;
                
            
            var updatedVM = {...viewModel};
            if (!weight && !selectedScrapCharge.pig_iron_weight)
                return updatedVM
            
            const convertedWeight = (weight || null) === null ? null : Number(weight);
            ctx.updateSelectedScrapCharge(
                selectedScrapChargeId,
                {"pig_iron_weight": ctx.tonsToKgs(convertedWeight)}
            );
            return updatedVM;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "error", *cls.get_validation_msg()),)

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidationMsg",
            [],
            """
            if ((this.weight === "" ? null : this.weight) != null && (this.weight <= 100 || this.weight > 180))
                return 'Podozrivá hmotnosť surového železa ' + this.weight;
            return "";
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_value()),
            sdc.JsCodeField(*cls.show_loader()),
            sdc.JsCodeField(*cls.hide_loader()),
        )

    @classmethod
    def set_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setWeight",
            ["weight"],
            """
            var updatedVM = {...this};
            updatedVM.weight = weight == null ? undefined : weight;
            return updatedVM;
            """,
        )

    @classmethod
    def show_loader(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showLoader",
            [],
            """
            var updatedVM = {...this};
            updatedVM.right_section = {
                type: "Loader",
                namespace: "dash_mantine_components",
                props: {'size': 'xs'},
            };
            return updatedVM;
            """,
        )

    @classmethod
    def hide_loader(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideLoader",
            [],
            "var updatedVM = {...this}; updatedVM.right_section = null; return updatedVM;",
        )
