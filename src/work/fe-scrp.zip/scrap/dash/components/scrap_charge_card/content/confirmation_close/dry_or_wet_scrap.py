from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class DryOrWetVM:
    # Component Id
    ID = "wet-or-dry"

    LABEL = "Zvoľte aký typ šrotu bol naložený."
    WET_SCRAP_OPTION = "wet_scrap"
    DRY_SCRAP_OPTION = "dry_scrap"
    OPTIONS = {WET_SCRAP_OPTION: "Mokrý šrot", DRY_SCRAP_OPTION: "Suchý šrot"}

    selected: Optional[str] = sdc.clientside_one_way_binding_with_state(ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.RadioGroup:
        return dmc.RadioGroup(
            children=dmc.Group(
                [dmc.Radio(label, value=val) for val, label in cls.OPTIONS.items()],
            ),
            id=sdc.create_id(parent_id, cls.ID),
            label=cls.LABEL,
            required=True,
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "selectedValue", "ctx"],
            Template(
                """
            const scrapChargeId = ctx.scrapChargeIdToClose;
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(scrapChargeId, {"is_wet": selectedValue === '$wet_scrap_option'});
            }
            return viewModel;
            """
            ).substitute(wet_scrap_option=cls.WET_SCRAP_OPTION),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.reset_value()),)

    @classmethod
    def reset_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetValue",
            [],
            """
            var updatedVM = {...this};
            updatedVM.selected = null;
            return updatedVM;
            """,
        )
