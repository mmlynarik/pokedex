from string import Template
from typing import Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class RiskMsgVM:
    # Component id
    ID = "msg"
    # User friendly msg
    RISK_MSG = "pravdepodobnosť nutnosti použitia nežiadúcej opravnej technológie"

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Text:
        return dmc.Text(id=sdc.create_id(parent_id, cls.ID))

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "children", *cls.get_msg()),
            sdc.OutputFieldClientSide(cls.ID, "className", *cls.get_class_name()),
        )

    @classmethod
    def get_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMsg",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(this);
            const classifyRisk = this.classifyRisk(ctx.selectedScrapChargeOptimization(scrapChargeId));
            return classifyRisk.msg;
            """,
        )

    @classmethod
    def get_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMsgClassName",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(this);
            const classifyRisk = this.classifyRisk(ctx.selectedScrapChargeOptimization(scrapChargeId));
            return classifyRisk.class;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.get_risk_msg()),)

    @classmethod
    def get_risk_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "classifyRisk",
            ["optimization"],
            Template(
                """
            if (optimization?.result == null || optimization.result.first_heat_expected_risk == null)
                return  {'class': '', 'msg': ''};;

            const risk = optimization.result.first_heat_expected_risk;
            if (risk.high.length === 0 && risk.medium.length === 0)
                return {'class': 'low-risk', 'msg': 'Nízka ${msg}'};

            if (risk.high.length === 0)
                return {'class': 'medium-risk', 'msg': 'Stredná ${msg}'};
            return {'class': 'high-risk', 'msg': 'Vysoká ${msg}'};
            """
            ).substitute(msg=cls.RISK_MSG),
        )
