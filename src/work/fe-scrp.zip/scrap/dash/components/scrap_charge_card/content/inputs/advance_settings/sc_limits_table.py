from string import Template
from typing import Dict, List, Self, Tuple

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import dash_table, dcc, html
from scrap_core.optimization.validations import (
    ScrapMixLimit,
    join_validation_results,
    validate_scrap_limits,
    validate_scrap_mix_ratios,
)
from scrap_core.utils import convert_tons_to_kilograms
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.validation import (
    validate_loaded_switched_basket_minimum_limit,
)
from scrap.models import get_relevant_relaxable_summing_limits_settings


@attr.frozen
class ScrapChargeLimitsTableVM:
    # Component Ids
    COMPONENT_ID = "table"
    SCRAP_TYPE_COL_ID = "scrap_type"
    MIN_LIMITS_COL_ID = "minimum"
    MAX_LIMITS_COL_ID = "maximum"
    VALIDATION_MSG_ID = "validation-msg"
    RESET_BTN_ID = "reset"
    CARD_INDEX_ID = "card-index"
    # Component classnames
    INLINE_TABLE_HEADER = "inline-header"
    ERROR_LIST = "validation-error-list"
    # User friendly user
    LABEL = "Hmotnostné limity šrotov"

    data: List[Dict[str, str]] = sdc.clientside_one_way_binding_with_both_states(
        COMPONENT_ID,
        "data",
        default=[],
    )
    card_index: int = sdc.one_way_binding(CARD_INDEX_ID, "data", default=-1)

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(card_index=card_index)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                html.Div(
                    children=[
                        dbc.Label(cls.LABEL),
                        dbc.Button(
                            "Resetovať limity",
                            color="link",
                            id=sdc.create_id(parent_id, cls.RESET_BTN_ID),
                            disabled=config.read_only,
                        ),
                    ],
                    className=cls.INLINE_TABLE_HEADER,
                ),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    columns=[
                        {"name": "Typ šrotu", "id": cls.SCRAP_TYPE_COL_ID, "type": "text", "editable": False},
                        {
                            "name": "Minimum [t]",
                            "id": cls.MIN_LIMITS_COL_ID,
                            "type": "numeric",
                            "editable": not config.read_only,
                            "validation": {"allow_null": True, "default": None},
                            "on_change": {"action": "coerce", "failure": "default"},
                        },
                        {
                            "name": "Maximum [t]",
                            "id": cls.MAX_LIMITS_COL_ID,
                            "type": "numeric",
                            "editable": not config.read_only,
                            "validation": {"allow_null": True, "default": None},
                            "on_change": {"action": "coerce", "failure": "default"},
                        },
                    ],
                    editable=not config.read_only,
                ),
                html.Ul(id=sdc.create_id(parent_id, cls.VALIDATION_MSG_ID), className=cls.ERROR_LIST),
                dcc.Store(id=sdc.create_id(parent_id, cls.CARD_INDEX_ID)),
            ],
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(cls.COMPONENT_ID, "data", *cls.update()),
            sdc.InputFieldClientSide(cls.RESET_BTN_ID, "n_clicks", *cls.reset_data()),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputField(cls.VALIDATION_MSG_ID, "children", cls.validate_scrap_limits),)

    @classmethod
    def update(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "update",
            ["viewModel", "data", "ctx"],
            """
            viewModel.updateDatasource(data, ctx);
            return viewModel;
            """,
        )

    @classmethod
    def reset_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetData",
            ["viewModel", "data", "ctx"],
            """
            var updatedVM = {...viewModel};
            updatedVM.reset(ctx);
            return updatedVM;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_table_data()),
            sdc.JsCodeField(*cls.reset_table_data()),
            sdc.JsCodeField(*cls.update_datasource()),
        )

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["data", "ctx"],
            Template(
                """
            const updatedScrapLimits = data.map(limit => {
                return {
                    ...limit,
                    $min_col_id: ctx.tonsToKgs(limit.$min_col_id),
                    $max_col_id: ctx.tonsToKgs(limit.$max_col_id),
                }
            });
            const scrapChargeId = ctx.getScrapChargeId(this);
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(scrapChargeId, {"scrap_limits": updatedScrapLimits});
            }
            """
            ).substitute(min_col_id=cls.MIN_LIMITS_COL_ID, max_col_id=cls.MAX_LIMITS_COL_ID),
        )

    @classmethod
    def set_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setTableData",
            ["scrapChargeLimits", "ctx"],
            Template(
                """
            var updatedVM = {...this};
            updatedVM.data = Object.values(ctx.getAvailableScrap()).map(scrap => {
                const limit = scrapChargeLimits.find(limit => limit.scrap_type === scrap.scrap_type);
                const minimum = !limit ? null : ctx.kgsToTons(limit.minimum);
                const maximum = !limit ? null : ctx.kgsToTons(limit.maximum);

                return {
                    "$scrap_type_col_id": scrap.scrap_type,
                    "$min_col_id": minimum,
                    "$max_col_id": maximum,
                }
            });
            return updatedVM;
            """
            ).substitute(
                scrap_type_col_id=cls.SCRAP_TYPE_COL_ID,
                min_col_id=cls.MIN_LIMITS_COL_ID,
                max_col_id=cls.MAX_LIMITS_COL_ID,
            ),
        )

    @classmethod
    def reset_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "reset",
            ["ctx"],
            Template(
                """
            const weightedScrapModel = ctx.getWeightedScraps(ctx.getScrapChargeId(this));
            const switchedBasketScraps = Object.values(weightedScrapModel.getWeightOfSwitchedBaskets());
            this.data = this.data.map(limit => {
                let minimum = null;
                let loadedScrap = switchedBasketScraps.find(scrap => scrap.scrap == limit.scrap_type)
                if (loadedScrap != null)
                    minimum = ctx.kgsToTons(loadedScrap.weight);
                return {
                    ...limit,
                    "$min_col_id": minimum,
                    "$max_col_id": null,
                }
            });
            this.updateDatasource(this.data, ctx);
            """
            ).substitute(
                min_col_id=cls.MIN_LIMITS_COL_ID,
                max_col_id=cls.MAX_LIMITS_COL_ID,
            ),
        )

    def table_row_to_scrap_mix_limit_in_kgs(self, row: Dict[str, str]) -> ScrapMixLimit:
        minimum = (
            None
            if row[self.MIN_LIMITS_COL_ID] is None
            else convert_tons_to_kilograms(row[self.MIN_LIMITS_COL_ID])
        )
        maximum = (
            None
            if row[self.MAX_LIMITS_COL_ID] is None
            else convert_tons_to_kilograms(row[self.MAX_LIMITS_COL_ID])
        )
        return ScrapMixLimit(
            scrap_type=row[self.SCRAP_TYPE_COL_ID],
            maximum=maximum,
            minimum=minimum,
        )

    def validate_scrap_limits(self, ctx: ScrapLoadingStationCTX) -> List[html.Li]:
        scrap_charge_id = ctx.get_scrap_charge_id(self.card_index)
        if not self.data or scrap_charge_id is None:
            return []
        available_scraps = tuple(mix.scrap_type for mix in ctx.models.available_scraps.get_all())
        relaxable_lower_summing_limits, relaxable_upper_summing_limits = (), ()
        grade_id = ctx.get_grade_id(self.card_index)
        if grade_id is not None:
            relaxable_upper_summing_limits = tuple(
                lim.to_relaxable_limit()
                for lim in get_relevant_relaxable_summing_limits_settings(
                    ctx.models.loading_station.relaxable_upper_summing_limits_settings, grade_id
                )
            )
            relaxable_lower_summing_limits = tuple(
                lim.to_relaxable_limit()
                for lim in get_relevant_relaxable_summing_limits_settings(
                    ctx.models.loading_station.relaxable_lower_summing_limits_settings, grade_id
                )
            )
        validation_msg = join_validation_results(
            [
                validate_scrap_limits(
                    tuple(limit for limit in map(self.table_row_to_scrap_mix_limit_in_kgs, self.data)),
                    ctx.get_scrap_weight_or_constant(self.card_index),
                    ctx.models.available_scraps.get_all(),
                    relaxable_lower_summing_limits,
                    relaxable_upper_summing_limits,
                    grade_id,
                    ctx.models.available_scraps.scrap_mix_mapping,
                ),
                validate_scrap_mix_ratios(ctx.models.available_scraps.scrap_mix_mapping, available_scraps),
            ]
        )
        weighted_scraps = ctx.models.weighted_scrap(scrap_charge_id).get_switched_baskets()
        switched_basket_errors = validate_loaded_switched_basket_minimum_limit(
            tuple(ScrapMixLimit(**data) for data in self.data), weighted_scraps
        )
        errors, _ = validation_msg
        return [html.Li(children=err) for err in (*errors, *switched_basket_errors)]
