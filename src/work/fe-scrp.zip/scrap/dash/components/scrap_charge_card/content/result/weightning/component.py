import logging
from string import Template
from typing import Any, Optional, Self, Tuple

import attr
import ussksdc as sdc
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.consumers.scale_controller import STOP_EVENT_KEY
from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.components.scrap_charge_card.content.result.basket_selector import BasketIdsSelector
from scrap.dash.components.scrap_charge_card.content.result.weightning.control_panel import (
    get_control_panel_layout,
)
from scrap.dash.components.scrap_charge_card.content.result.weightning.proposed_scrap_table import (
    RecommendedScrapsTableVM,
)
from scrap.dash.components.scrap_charge_card.content.result.weightning.side_label import SideLabelVM
from scrap.dash.components.scrap_charge_card.content.result.weightning.stop_btn import get_stop_btn_layout
from scrap.dash.components.scrap_charge_card.content.result.weightning.tare_btn import get_tare_btn_layout
from scrap.models.various_models import ScaleCurrentState
from scrap.scales.utils import tare_scale

logger = logging.getLogger(__name__)


@attr.frozen
class WeightingComponentVM:
    # Component id
    CONTROL_PANEL_ID = "scale-control-panel-wrapper"
    SCALE_IDX_ID = "scale-idx"
    STOP_WEIGHTING_BTN_ID = "stop-weighting-btn"
    CONTROL_BTNS_WRAPPER_ID = "control-btns-wrapper"
    TARE_WRAPPER_ID = "tare-wrapper"
    TARE_BTN_ID = "tare-btn"
    TARE_TRIGGER_ID = "tare-trigger-store"
    IFRAME_ID = "scale-actual-data-iframe"
    TOOLTIP_ID = "scale-weight-tooltip"
    MESSAGE_BUFFER_ID = "message-buffer"
    LAST_STP_BTN_IDENTIFIER_ID = "last-stp-btn-identifier"
    # Component classnames
    TABLE_WRAPPER_CLASSNAME = "table-with-side-label"

    side_label: SideLabelVM = sdc.child_component("side-label", factory=SideLabelVM)
    proposed_scraps: RecommendedScrapsTableVM = sdc.child_component(
        "proposed-scraps",
        factory=RecommendedScrapsTableVM,
    )
    basket: BasketIdsSelector = sdc.child_component("basket", factory=BasketIdsSelector)
    scale_idx: int = sdc.binding(
        SCALE_IDX_ID,
        "data",
        cs_read=False,
        cs_state=True,
        cs_write=False,
        ss_read=False,
        ss_state=True,
        ss_write=True,
        default=-1,
    )
    tare_trigger: Any = sdc.clientside_one_way_binding_with_state(TARE_TRIGGER_ID, "data", default=None)
    message_buffer_cs: Optional[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_BUFFER_ID,
        "data",
        default="",
    )
    stp_identifier: Optional[str] = sdc.binding(
        LAST_STP_BTN_IDENTIFIER_ID,
        "data",
        cs_read=False,
        cs_state=True,
        cs_write=True,
        ss_read=False,
        ss_state=False,
        ss_write=False,
        default=None,
    )

    @classmethod
    def create(cls, scale_idx: int) -> Self:
        return cls(
            scale_idx=scale_idx,
            proposed_scraps=RecommendedScrapsTableVM.create(scale_index=scale_idx),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.side_label),
                sdc.get_child_layout(parent_id, cls.proposed_scraps, config),
                get_control_panel_layout(
                    get_tare_btn_layout(
                        sdc.create_id(parent_id, cls.TARE_WRAPPER_ID),
                        sdc.create_id(parent_id, cls.TARE_BTN_ID),
                        sdc.create_id(parent_id, cls.TARE_TRIGGER_ID),
                        config,
                    ),
                    get_stop_btn_layout(sdc.create_id(parent_id, cls.STOP_WEIGHTING_BTN_ID), config),
                    sdc.create_id(parent_id, cls.CONTROL_BTNS_WRAPPER_ID),
                    sdc.create_id(parent_id, cls.CONTROL_PANEL_ID),
                    sdc.create_id(parent_id, cls.TOOLTIP_ID),
                    sdc.create_id(parent_id, cls.IFRAME_ID),
                ),
                sdc.get_child_layout(parent_id, cls.basket, config),
                dcc.Store(id=sdc.create_id(parent_id, cls.SCALE_IDX_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.LAST_STP_BTN_IDENTIFIER_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_BUFFER_ID)),
            ],
            className=cls.TABLE_WRAPPER_CLASSNAME,
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputFieldClientSide(cls.STOP_WEIGHTING_BTN_ID, "n_clicks", *cls.reset_weighted_scrap()),
            sdc.InputFieldClientSide(cls.TARE_BTN_ID, "n_clicks", *cls.stop_weighting_and_trigger_tare()),
            sdc.InputField(cls.TARE_TRIGGER_ID, "modified_timestamp", cls.send_tare_to_scale),
        )

    @classmethod
    def reset_weighted_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetWeightedScrap",
            ["viewModel", "nClicks", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            updatedVM.proposed_scraps = updatedVM.proposed_scraps.deselectSelectedScrap();
            updatedVM.stp_identifier = sdc.callbackRunId;
            return updatedVM;
            """
            ).substitute(
                stopping_event=STOP_EVENT_KEY,
            ),
        )

    # TODO make common tare btn component
    @classmethod
    def stop_weighting_and_trigger_tare(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "stopWeightingAndTriggerTare",
            ["viewModel", "nClicks", "ctx"],
            """
            var updatedVM = {...viewModel};
            if (ctx.readOnly || !ctx.scaleControl){
                updatedVM.message_buffer_cs = createClientSideMsg(
                    "Na vytarovanie váhy nemáte povolenie.", "warning"
                );
            } else {
                updatedVM.tare_trigger = Number(new Date());
            }
            return updatedVM;
            """,
        )

    def send_tare_to_scale(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        scale_id = ctx.scale_ids[self.scale_idx]
        if ctx.read_only or not ctx.scale_control:
            logger.info(
                f"User {ctx.logged_username} trying to tare the scale {scale_id} on loading station "
                + f"{ctx.models.loading_station.name}, but user doesn't have a permission to this action."
            )
            return self

        tare_scale(scale_id)

        return self

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.CONTROL_PANEL_ID, "className", *cls.set_class_name()),
            sdc.OutputFieldClientSide(cls.IFRAME_ID, "src", *cls.set_src()),
            sdc.OutputFieldClientSide(cls.IFRAME_ID, "className", *cls.show_iframe()),
            sdc.OutputFieldClientSide(cls.TOOLTIP_ID, "disabled", *cls.show_tooltip()),
        )

    @classmethod
    def set_src(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setSrc",
            ["viewModel", "ctx"],
            """
            const scaleId = ctx.scaleIds[viewModel.scale_idx];
            return `http://${window.location.host}/scrap/scale_monitor/steelshop/${ctx.steelshop}/scale_id/${scaleId}`;
            """,
        )

    @classmethod
    def show_iframe(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showIframe",
            ["viewModel", "ctx"],
            "return ctx.selectedScales(viewModel).includes(viewModel.scale_idx) ? '' : 'unvisible';",
        )

    @classmethod
    def show_tooltip(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "showTooltip",
            ["viewModel", "ctx"],
            "return !ctx.selectedScales(viewModel).includes(viewModel.scale_idx);",
        )

    @classmethod
    def set_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setClassNames",
            ["viewModel", "ctx"],
            Template(
                """
            var classes = [];
            const scaleId = ctx.scaleIds[viewModel.scale_idx];
            const scaleState = Object.values(ctx.models.scaleState.getAll()).find(s => s.scale_id === scaleId);
            if (scaleState.state === $stopped_state){
                classes.push("stopped");
            }else{
                classes.push("running");
            }

            if (ctx.selectedScales(viewModel).length !== 0){
                classes.push("scale-selected");
            }else{
                classes.push("scale-unselected");
            }
            return classes.join(" ");
            """
            ).substitute(stopped_state=ScaleCurrentState.ScaleState.STOPPED_WEIGHTING),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.is_stop_requested()),
            sdc.JsCodeField(*cls.set_inputs_value()),
        )

    @classmethod
    def is_stop_requested(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isStopRequested",
            [],
            "return this.stp_identifier === sdc.callbackRunId",
        )

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["selectedBasket"],
            """
            var updatedVm = {...this};
            updatedVm.basket = this.basket.setInputsValue(selectedBasket);
            return updatedVm;
            """,
        )
