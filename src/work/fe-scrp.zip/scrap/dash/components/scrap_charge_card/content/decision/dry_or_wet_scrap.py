from string import Template
from typing import Optional, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class DryOrWetVM:
    # Component Id
    ID = "wet-or-dry"

    LABEL = "Zvoľte aký typ šrotu bol naložený."
    WET_SCRAP_OPTION = "wet_scrap"
    DRY_SCRAP_OPTION = "dry_scrap"
    OPTIONS = {WET_SCRAP_OPTION: "Mokrý šrot", DRY_SCRAP_OPTION: "Suchý šrot"}

    selected: Optional[str] = sdc.clientside_two_way_binding(ID, "value", default=None)

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.RadioGroup:
        return dmc.RadioGroup(
            children=dmc.Group(
                [dmc.Radio(label, value=val) for val, label in cls.OPTIONS.items()],
            ),
            id=sdc.create_id(parent_id, cls.ID),
            label=cls.LABEL,
            required=True,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.is_wet_scrap()),
            sdc.JsCodeField(*cls.reset_selected()),
        )

    @classmethod
    def reset_selected(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "reset",
            [],
            """
            var viewModel = {...this};
            viewModel.selected = null;
            return viewModel;
            """,
        )

    @classmethod
    def is_wet_scrap(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "isWetScrap",
            [],
            Template(
                """
            var viewModel = {...this};
            if (viewModel.selected == null){
                return null;
            }
            return (viewModel.selected === '${wet_scrap}');
            """
            ).substitute(wet_scrap=cls.WET_SCRAP_OPTION),
        )
