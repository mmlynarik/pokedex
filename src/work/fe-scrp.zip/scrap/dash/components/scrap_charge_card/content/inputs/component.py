from typing import Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.content.inputs.advance_settings.component import (
    AdvanceSettingInputsTableVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.basket_ids import BasketIdsInputVM
from scrap.dash.components.scrap_charge_card.content.inputs.grade_and_weight_inputs import (
    GradeAndWeightInputsVM,
)
from scrap.dash.components.scrap_charge_card.content.inputs.optim_error_msg import OptimizationErrorMsgVM
from scrap.dash.components.scrap_charge_card.content.inputs.switched_baskets import (
    SwitchedBasketIdsSelectorVM,
)


@attr.frozen
class ScrapChargeInputsVM:
    # Component ids
    TOGGLE_ADVANCE_SETTINGS_BTN_ID = "toggle-advance-settings"
    SWITCHED_BASKET_WRAPPER_ID = "switched-basket-wrapper"
    SWITCH_SCRAP_CHARGE_FLAG_ID = "switched-scrap-charge-flag"
    # Component classnames
    INPUTS_CLASSNAME = "scrap-charge-inputs"
    # User friendly msg
    ADVANCED_SETTINGS = "Rozšírené nastavenia"

    basket_ids: BasketIdsInputVM = sdc.child_component("basket-ids", factory=BasketIdsInputVM)
    swiched_basket_ids: SwitchedBasketIdsSelectorVM = sdc.child_component(
        "switched-basket-ids", factory=SwitchedBasketIdsSelectorVM
    )
    grade_and_weight_inputs: GradeAndWeightInputsVM = sdc.child_component(
        "scrap", factory=GradeAndWeightInputsVM
    )
    advance_setting_tables: AdvanceSettingInputsTableVM = sdc.child_component(
        "advance-setting-tables", factory=AdvanceSettingInputsTableVM
    )
    optim_error_msg: OptimizationErrorMsgVM = sdc.child_component(
        "optim-error", factory=OptimizationErrorMsgVM
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(
            advance_setting_tables=AdvanceSettingInputsTableVM.create(card_index),
            swiched_basket_ids=SwitchedBasketIdsSelectorVM.create(card_index),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                html.Div(
                    [
                        sdc.get_child_layout(parent_id, cls.basket_ids, config),
                        sdc.get_child_layout(parent_id, cls.swiched_basket_ids, config),
                        *sdc.get_child_layout(parent_id, cls.grade_and_weight_inputs, config),
                        dmc.Button(
                            id=sdc.create_id(parent_id, cls.TOGGLE_ADVANCE_SETTINGS_BTN_ID),
                            children=cls.ADVANCED_SETTINGS,
                            variant="outline",
                        ),
                    ],
                    className=cls.INPUTS_CLASSNAME,
                ),
                sdc.get_child_layout(parent_id, cls.advance_setting_tables, config),
                sdc.get_child_layout(parent_id, cls.optim_error_msg),
            ],
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputFieldClientSide(
                cls.TOGGLE_ADVANCE_SETTINGS_BTN_ID, "n_clicks", *cls.toggle_advance_settings()
            ),
        )

    @classmethod
    def toggle_advance_settings(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "toggleAdvanceSettings",
            ["viewModel"],
            """
            var updatedVM = {...viewModel};
            updatedVM.advance_setting_tables = updatedVM.advance_setting_tables.toggleCollapse();
            return updatedVM;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_inputs_value()),
            sdc.JsCodeField(*cls.are_input_valid()),
        )

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["scrapCharge", "ctx"],
            """
            var updatedVM = {...this};
            updatedVM.basket_ids = this.basket_ids.setBasketIds(scrapCharge?.basket_ids);
            updatedVM.swiched_basket_ids = this.swiched_basket_ids.setSwitchedBaskets(scrapCharge?.switched_baskets);
            var gradeByOrderNum = (scrapCharge?.heat_plan?.heats || []).find(val => val.order_num == scrapCharge?.order_num);
            if (gradeByOrderNum != undefined){
                gradeByOrderNum = gradeByOrderNum.grade_id;
            }
            updatedVM.grade_and_weight_inputs = this.grade_and_weight_inputs.setGradeAndWeightInputs(
                scrapCharge?.grade_id,
                scrapCharge?.order_num,
                gradeByOrderNum,
                ctx.kgsToTons(scrapCharge?.total_scrap_weight),
                ctx.kgsToTons(scrapCharge?.pig_iron_weight)
            );

            updatedVM.advance_setting_tables = this.advance_setting_tables.setInputsValues(scrapCharge, ctx);
            return updatedVM;
            """,
        )

    @classmethod
    def are_input_valid(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "areInputsValid", ["ctx"], "return [this.basket_ids.isValid(ctx)].every(val => val);"
        )
