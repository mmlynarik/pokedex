from typing import Dict, List, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@attr.frozen
class ScaleSelectorVM:
    # Component id
    ID = "dropdown"
    # User friendly msg
    PLACEHOLDER = "Vyber váhu"

    active_scales: List[str] = sdc.binding(
        ID,
        "value",
        cs_read=False,
        cs_write=True,
        cs_state=True,
        ss_read=False,
        ss_write=False,
        ss_state=True,
        default=[],
    )
    options: List[Dict[str, str]] = sdc.clientside_only_state_binding(ID, "data", default=[])
    class_name: str = sdc.clientside_one_way_binding_with_state(ID, "className", default="")

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.MultiSelect:
        return dmc.MultiSelect(
            placeholder=cls.PLACEHOLDER,
            creatable=True,
            id=sdc.create_id(parent_id, cls.ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.set_value()),)

    @classmethod
    def set_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setActiveScales",
            ["viewModel", "value"],
            """
            var updatedVM = {...viewModel};
            updatedVM.class_name = "";
            return updatedVM;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "data", *cls.get_selector_options()),)

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getScaleOptions",
            ["viewModel", "ctx"],
            """
            const allScales = ctx.scaleIds.map((s, i) => i);
            for (let selectedScale of ctx.selectedScaleIds){
                let idx = allScales.indexOf(selectedScale);
                if (idx !== -1)
                    allScales.splice(idx, 1);
            }
            const options = Array.from(
                new Set([...allScales, ...(viewModel.active_scales ?? [])])
            );

            return (
                ctx.scaleIds.map(
                    (s, i) => {
                        if (options.includes(i))
                            return {'label': s.toUpperCase(), 'value': i};
                        return null;
                    }
                ).filter(val => val !== null)
            );
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.focus()),
            sdc.JsCodeField(*cls.set_inputs_value()),
        )

    @classmethod
    def focus(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "focus",
            [],
            "this.class_name = 'focus';",
        )

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["selectedScales"],
            """
            var updatedVm = {...this};
            updatedVm.active_scales = selectedScales;
            return updatedVm;
            """,
        )
