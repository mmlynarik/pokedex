from string import Template
from typing import Tuple

import ussksdc as sdc
from attr import frozen
from dash_ag_grid import AgGrid
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@frozen
class LoadedScrapSummaryTableVM:
    # Component Id
    COMPONENT_ID = "table"
    LOADED_SUM_COL_ID = "loaded-sum"
    NOT_LOADED_SUM_COL_ID = "not-loaded-sum"
    # User friendly msg
    SUM_COL = "Spolu"
    NOT_LOADED = "Zostáva naložiť"

    @classmethod
    def get_layout(cls, parent_id: str) -> AgGrid:
        return AgGrid(
            columnSize="responsiveSizeToFit",
            dashGridOptions={"rowHeight": 30, "headerHeight": 38},
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            style={"height": 71},
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "columnDefs", *cls.get_table_columns()),
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "rowData", *cls.get_table_data()),
            sdc.OutputFieldClientSide(cls.COMPONENT_ID, "className", *cls.get_table_class_name()),
        )

    @classmethod
    def get_table_columns(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableColumns",
            ["viewModel", "ctx"],
            Template(
                """
            const scraps = viewModel.getValidWeightedScraps(viewModel, ctx);
            if (scraps.size === 0)
                return [];

            var columns = [];
            for (let scrap of scraps){
                columns.push(viewModel.getColumn(scrap, scrap))
            }
            columns.push(viewModel.getColumn('${sum_label}', '${loaded_sum}', 120));
            columns.push(viewModel.getColumn('${not_loaded}', '${not_loaded_sum}', 140))
            return columns;
            """
            ).substitute(
                loaded_sum=cls.LOADED_SUM_COL_ID,
                sum_label=cls.SUM_COL,
                not_loaded_sum=cls.NOT_LOADED_SUM_COL_ID,
                not_loaded=cls.NOT_LOADED,
            ),
        )

    @classmethod
    def get_table_data(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableData",
            ["viewModel", "ctx"],
            Template(
                """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            const optimization = ctx.selectedScrapChargeOptimization(scrapChargeId);
            
            if (scrapChargeId !== null && optimization?.result != null && optimization?.result?.error == null){
                const weightedScrapModel = ctx.getWeightedScraps(scrapChargeId);
                const weightedScraps = Object.values(weightedScrapModel.getAll());
                if (weightedScraps.length === 0)
                    return []

                var summary = {"${loaded_sum}": 0}
                for (let ws of weightedScraps){
                    if (ws.invalid_record === false){
                        const weight = ctx.kgsToTons(ws.weight);
                        summary[ws.scrap] = summary.hasOwnProperty(ws.scrap) ? summary[ws.scrap] + weight : weight;
                        summary["${loaded_sum}"] += weight;
                    }
                }
                if (Object.keys(summary).length === 1)
                    return [];

                const recommendedWeigth = ctx.sum(Object.values(
                    optimization.result.scrap_weights_per_heat.at(0)
                ));
                summary["${not_loaded_sum}"] = ctx.kgsToTons(recommendedWeigth) - summary["${loaded_sum}"];
                return [summary];
            }
            return [];
            """
            ).substitute(loaded_sum=cls.LOADED_SUM_COL_ID, not_loaded_sum=cls.NOT_LOADED_SUM_COL_ID),
        )

    @classmethod
    def get_table_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getTableClassName",
            ["viewModel", "ctx"],
            """
            var baseClassName = 'ag-theme-alpine';
            const scraps = viewModel.getValidWeightedScraps(viewModel, ctx);
            if (scraps.size === 0)
                baseClassName += ' unvisible';
            return baseClassName;
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.get_valid_weighted_scraps()),
            sdc.JsCodeField(*cls.get_column_def()),
        )

    @classmethod
    def get_valid_weighted_scraps(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidWeightedScraps",
            ["viewModel", "ctx"],
            """
            const weightedScraps = ctx.getWeightedScraps(ctx.getScrapChargeId(viewModel));
            if (!weightedScraps){
                return new Set();
            }
            return new Set(
                Object.values(weightedScraps.getAll())
                .filter(ws => ws.invalid_record === false)
                .map(ws => ws.scrap)
            );
            """,
        )

    @classmethod
    def get_column_def(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getColumn",
            ["name", "id", "width=null"],
            """
            var colDef = {
                'headerName': name,
                'field': id,
                'valueFormatter': {
                    'function': "d3.format(',.1f')(params.value) + ' t'"
                }
            }
            if (width !== null){
                colDef['width'] = width;
                colDef['suppressSizeToFit'] = true;
            }
            return colDef;
            """,
        )
