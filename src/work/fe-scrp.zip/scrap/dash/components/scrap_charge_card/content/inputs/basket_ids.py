from typing import List, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig


@attr.frozen
class BasketIdsInputVM:
    # Component Id
    ID = "input"
    WRAPPER_ID = "selector-wrapper"
    # User friendly MSG
    LABEL = "Čísla korýt"
    PLACEHOLDER = "Vyber čísla korýt"
    NOTHING_FOUND = "Koryto sa nepodarilo nájsť"
    # Classnames
    INPUT_CLASSNAME = "input-component"
    # Settings
    MAX_SELECTED_BASKETS = 3

    basket_ids: List[str] = sdc.binding(
        ID,
        "value",
        cs_read=False,
        cs_state=True,
        cs_write=True,
        ss_read=False,
        ss_state=True,
        ss_write=False,
        default=None,
    )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                dmc.MultiSelect(
                    clearable=True,
                    debounce=700,
                    disabled=config.read_only,
                    id=sdc.create_id(parent_id, cls.ID),
                    label=cls.LABEL,
                    maxSelectedValues=cls.MAX_SELECTED_BASKETS,
                    nothingFound=cls.NOTHING_FOUND,
                    placeholder=cls.PLACEHOLDER,
                    searchable=True,
                ),
            ],
            className=cls.INPUT_CLASSNAME,
            id=sdc.create_id(parent_id, cls.WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputFieldClientSide(cls.ID, "value", *cls.update_datasource()),)

    @classmethod
    def update_datasource(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "updateDatasource",
            ["viewModel", "basketIds", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            if (scrapChargeId !== null){
                ctx.updateSelectedScrapCharge(scrapChargeId, {"basket_ids": basketIds ?? []});
            }
            return viewModel;
            """,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(cls.ID, "data", *cls.get_selector_options()),
            sdc.OutputFieldClientSide(cls.ID, "error", *cls.get_validation_msg()),
        )

    @classmethod
    def get_selector_options(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getDropdownOptions",
            ["viewModel", "ctx"],
            """
            return Object.values(ctx.models.basketWeights.getAll()).map(
                basket => {
                     return {"label": basket.basket_id.toString(), "value": basket.basket_id}
                }
            );
            """,
        )

    @classmethod
    def get_validation_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getValidationMsg",
            ["viewModel", "ctx"],
            """
            if (this.basket_ids && this.basket_ids.length > 2)
                return "Podozrivý počet korýt - ak sa jedná viac ako dvojkorytovú vsádzku ignorujte toto upozornenie";
            return "";
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.set_value()),
            sdc.JsCodeField(*cls.is_valid()),
        )

    @classmethod
    def set_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setBasketIds",
            ["basket_ids"],
            """
            var updatedData = {...this};
            updatedData.basket_ids = basket_ids;
            return updatedData;
            """,
        )

    @classmethod
    def is_valid(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("isValid", ["ctx"], "return !this.getValidationMsg(this, ctx)")
