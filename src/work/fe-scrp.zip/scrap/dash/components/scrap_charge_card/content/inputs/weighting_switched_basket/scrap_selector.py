from typing import Any, Dict, List, Tuple

import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback


@frozen
class ScrapSelectorVM:
    # Component id
    SELECTOR_ID = "selector"
    # User friendly msg
    LABEL = "Zvoľte naložené šroty"
    CHOOSE_SCRAP = "Zvoľte z dostupných šrotov"

    options: List[Dict[str, Any]] = sdc.clientside_only_state_binding(SELECTOR_ID, "data", default=[])
    selected_option: List[int] = sdc.binding(
        SELECTOR_ID,
        "value",
        cs_read=True,
        cs_write=True,
        cs_state=True,
        ss_read=False,
        ss_write=False,
        ss_state=True,
        default=None,
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.MultiSelect:
        return dmc.MultiSelect(
            id=sdc.create_id(parent_id, cls.SELECTOR_ID),
            placeholder=cls.CHOOSE_SCRAP,
            label=cls.LABEL,
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.SELECTOR_ID, "data", *cls.get_options_from_table()),)

    @classmethod
    def get_options_from_table(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getAvailableScraps",
            ["viewModel", "ctx"],
            """
            return Object.values(sdc.models.availableScraps.getAll()).map(scrap => {
                return {
                    label: ctx.models.scrapDefinitions.getDisplayName(scrap.scrap_type),
                    value: scrap.scrap_type,
                }
            });
            """,
        )

    @classmethod
    def has_selected(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback("hasSelected", [], "return this.selected_option.length > 0;")

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.reset_selected_scraps()),
            sdc.JsCodeField(*cls.get_selected_scraps()),
        )

    @classmethod
    def reset_selected_scraps(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetSelectedScraps",
            [],
            """
            var updatedVM = {...this};
            updatedVM.selected_option = null;
            return updatedVM;
            """,
        )

    @classmethod
    def get_selected_scraps(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getSelectedScraps",
            ["ctx"],
            """
            return Object.values(
                ctx.models.scrapDefinitions.getAll()
            ).filter(
                scrap => (this.selected_option || []).includes(scrap.scrap_type)
            );
            """,
        )
