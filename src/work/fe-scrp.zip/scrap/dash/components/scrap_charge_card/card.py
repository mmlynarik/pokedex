from typing import Self, Tuple

import dash_mantine_components as dmc
import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.dash.components.protocols.scrap_loading_station import ScrapLoadingStationConfig
from scrap.dash.components.scrap_charge_card.calculate_optim_bt import CalculateOptimizationBtnVM
from scrap.dash.components.scrap_charge_card.content.decision.close_scrap_charge import CloseScrapChargeVM
from scrap.dash.components.scrap_charge_card.content.inputs.component import ScrapChargeInputsVM
from scrap.dash.components.scrap_charge_card.content.inputs_validation_msg import InputsValidationMsgVM
from scrap.dash.components.scrap_charge_card.content.result.component import ResultVM
from scrap.dash.components.scrap_charge_card.content.risk_msg import RiskMsgVM


@frozen
class ScrapChargeCardVM:
    # Component id
    CARD_ID = "card"
    CARD_IDX_ID = f"{CARD_ID}-idx"
    CARD_HEADER_ID = f"{CARD_ID}-header"
    CARD_BODY_ID = f"{CARD_ID}-body"

    SCRAP_CHARGE_RESULT_DATA_ID = "optimization-result-wrapper"
    SCRAP_CHARGE_DECISION_DATA_ID = "decision-wrapper"
    HEADER_ID = "header-id"
    RESULT_AND_DECISION_WRAPPER_ID = "result-decision-wrapper"
    RESULT_AND_DECISION_OVERLAY_ID = "result-decision-overlay"

    card_index: int = sdc.binding(
        CARD_IDX_ID,
        "data",
        cs_read=False,
        cs_write=False,
        cs_state=True,
        ss_read=False,
        ss_write=True,
        ss_state=True,
        default=-1,
    )
    calculated_optimization_btn: CalculateOptimizationBtnVM = sdc.child_component(
        "", factory=CalculateOptimizationBtnVM
    )
    inputs: ScrapChargeInputsVM = sdc.child_component("inputs", factory=ScrapChargeInputsVM)
    correct_inputs_badge: InputsValidationMsgVM = sdc.child_component(
        "correct-inputs", factory=InputsValidationMsgVM
    )
    result: ResultVM = sdc.child_component("", factory=ResultVM)
    decision: CloseScrapChargeVM = sdc.child_component("decision", factory=CloseScrapChargeVM)
    risk_msg: RiskMsgVM = sdc.child_component("risk", factory=RiskMsgVM)

    @classmethod
    def create(cls, index: int) -> Self:
        return cls(
            card_index=index,
            result=ResultVM.create(index),
            inputs=ScrapChargeInputsVM.create(index),
            calculated_optimization_btn=CalculateOptimizationBtnVM.create(index),
            decision=CloseScrapChargeVM.create(index),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> dmc.Card:
        return dmc.Card(
            children=[
                dmc.CardSection(
                    children=[
                        dmc.Title("Optimalizácia šrotovej vsádzky", order=5),
                        sdc.get_child_layout(parent_id, cls.calculated_optimization_btn, config),
                    ],
                    id=sdc.create_id(parent_id, cls.CARD_HEADER_ID),
                    withBorder=True,
                    inheritPadding=True,
                ),
                dmc.CardSection(
                    children=[
                        html.Div(
                            children=[
                                dmc.Title("Vstupné dáta", order=6),
                                html.Div(className="secondary-data-separator"),
                                sdc.get_child_layout(parent_id, cls.correct_inputs_badge),
                            ],
                            className="section-title",
                        ),
                        sdc.get_child_layout(parent_id, cls.inputs, config),
                        html.Div(
                            children=[
                                html.Div(
                                    children=dmc.Text("Je potrebné prepočítať vsádzku"),
                                    className="unvisible",
                                    id=sdc.create_id(parent_id, cls.RESULT_AND_DECISION_OVERLAY_ID),
                                ),
                                html.Div(
                                    children=[
                                        html.Div(
                                            children=[
                                                dmc.Title("Výsledok optimalizácie a váženie", order=6),
                                                html.Div(className="secondary-data-separator"),
                                                sdc.get_child_layout(parent_id, cls.risk_msg),
                                            ],
                                            className="section-title",
                                        ),
                                        sdc.get_child_layout(parent_id, cls.result, config),
                                    ],
                                    id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_RESULT_DATA_ID),
                                ),
                            ],
                            id=sdc.create_id(parent_id, cls.RESULT_AND_DECISION_WRAPPER_ID),
                        ),
                        html.Div(
                            children=[
                                sdc.get_child_layout(parent_id, cls.decision, config),
                            ],
                            id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_DECISION_DATA_ID),
                        ),
                        dcc.Store(id=sdc.create_id(parent_id, cls.CARD_IDX_ID)),
                    ],
                    id=sdc.create_id(parent_id, cls.CARD_BODY_ID),
                    inheritPadding=True,
                ),
            ],
            id=sdc.create_id(parent_id, cls.CARD_ID),
            shadow="md",
            withBorder=True,
            className="invisible",
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputFieldClientSide(
                cls.SCRAP_CHARGE_RESULT_DATA_ID, "hidden", *cls.hide_scrap_charge_result()
            ),
            sdc.OutputFieldClientSide(
                cls.SCRAP_CHARGE_DECISION_DATA_ID, "hidden", *cls.hide_scrap_charge_result()
            ),
            sdc.OutputFieldClientSide(
                cls.RESULT_AND_DECISION_OVERLAY_ID, "className", *cls.hide_changed_inputs_overlay()
            ),
            sdc.OutputFieldClientSide(cls.CARD_ID, "className", *cls.hide_card()),
        )

    @classmethod
    def hide_scrap_charge_result(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideScrapChargeResultData",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            return ctx.hasValidOptimizationResult(scrapChargeId);
            """,
        )

    @classmethod
    def hide_changed_inputs_overlay(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideChangedInputsOverlay",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            return ctx.isInputsSameAsOptimSnapshot(scrapChargeId) ? 'unvisible' : '';
            """,
        )

    @classmethod
    def hide_card(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hideCard",
            ["viewModel", "ctx"],
            """
            const selectedScrapCharge = ctx.scrapChargeConfig?.selectedScrapCharge ?? [null, null];
            return selectedScrapCharge.at(viewModel.card_index) === null ? 'invisible' : '';
            """,
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.set_inputs_value()),)

    @classmethod
    def set_inputs_value(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setInputsValue",
            ["scrapChargeId", "selectorStates", "ctx"],
            """
            var updatedVm = {...this};
            const scrapCharge = ctx.getScrapChargeById(scrapChargeId);

            updatedVm.inputs = this.inputs.setInputsValue(scrapCharge, ctx);
            updatedVm.result = this.result.setInputsValue(
                (selectorStates[scrapChargeId]?.selectedScales || []),
                (selectorStates[scrapChargeId]?.selectedBaskets || []),
            );
            updatedVm.decision = this.decision.setInputsValue(scrapCharge, ctx);
            
            return updatedVm;
            """,
        )
