import json
import logging
import uuid
from string import Template
from typing import Any, Dict, List, Optional, Self, Tuple

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import dcc, html
from dash_websocket_component.DashWebsocketComponent import DashWebsocketComponent
from redis.exceptions import ConnectionError as RedisConnectionError
from scrap_core.optimization.datamodel import MultipleHeatsOptimizationOutput
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scrap.consumers.optimization_consumer import OPTIMIZATION_ID_FRONTEND_KEY, SCRAP_CHARGE_ID_FRONTEND_KEY
from scrap.dash.components.global_alert import Message
from scrap.dash.components.one_heat_optimizer_v2 import create_optimization_input, validate_charge_info
from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
    ScrapLoadingStationCTX,
)
from scrap.dash.components.scrap_charge_card.content.inputs.weighting_switched_basket.validation import (
    validate_loaded_switched_basket_minimum_limit,
)
from scrap.dash.components.scrap_charge_card.content.optimization_progress_bar import (
    OptimizationProgressBarVM,
)
from scrap.models import OptimizationDisplayDataV2, converter
from scrap.tasks import multiple_heats_scrap_optimization

log = logging.getLogger(__name__)


@attr.frozen
class CalculateOptimizationBtnVM:
    ID = "btn"
    BACKEND_TRIGGER_ID = "trigger"
    WS_CHANNEL_ID = "ws"
    CARD_INDEX_ID = "card-index"
    MESSAGE_CHANNEL_CS = "msg-channel-cs"
    MESSAGE_CHANNEL_SS = "msg-channel-ss"

    BTN_LABEL = "Vypočítať vsádzku"
    BTN_LABEL_LOADING = "Prebieha výpočet"

    card_index: int = sdc.one_way_binding(CARD_INDEX_ID, "data", default=-1)
    btn_loading: Optional[bool] = sdc.clientside_one_way_binding_with_state(ID, "loading", default=False)
    btn_label: str = sdc.clientside_one_way_binding_with_state(ID, "children", default=BTN_LABEL)
    ws_msg: str = sdc.one_way_binding(WS_CHANNEL_ID, "send", default="{}")
    backend_trigger: Any = sdc.clientside_one_way_binding_with_state(BACKEND_TRIGGER_ID, "data", default=None)
    messages: Optional[str] = sdc.binding(
        WS_CHANNEL_ID,
        "message",
        ss_read=False,
        ss_state=False,
        ss_write=False,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    progress_overlay: OptimizationProgressBarVM = sdc.child_component(
        "optimization", factory=OptimizationProgressBarVM
    )
    message_buffer_cs: List[str] = sdc.clientside_one_way_binding_with_state(
        MESSAGE_CHANNEL_CS,
        "data",
        default=[],
    )
    messages_channel_ss: Dict[str, str] = sdc.binding(
        MESSAGE_CHANNEL_SS,
        "data",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=False,
        cs_state=True,
        cs_write=False,
        default={},
        converter=converter.unstructure,
    )

    @classmethod
    def create(cls, card_index: int) -> Self:
        return cls(card_index=card_index)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            [
                sdc.get_child_layout(parent_id, cls.progress_overlay),
                dmc.Button(cls.BTN_LABEL, id=sdc.create_id(parent_id, cls.ID), disabled=config.read_only),
                DashWebsocketComponent(
                    id=sdc.create_id(parent_id, cls.WS_CHANNEL_ID),
                    url=f"ws://{config.host}:{config.port}/ws/optimization_progress",
                ),
                dcc.Store(id=sdc.create_id(parent_id, cls.BACKEND_TRIGGER_ID)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_CHANNEL_CS)),
                dcc.Store(id=sdc.create_id(parent_id, cls.MESSAGE_CHANNEL_SS)),
                dcc.Store(id=sdc.create_id(parent_id, cls.CARD_INDEX_ID)),
            ],
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputFieldClientSide(cls.ID, "className", *cls.set_focus_class_name()),)

    @classmethod
    def set_focus_class_name(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setFocusClassName",
            ["viewModel", "ctx"],
            """
            const scrapChargeId = ctx.getScrapChargeId(viewModel);
            return ctx.isInputsSameAsOptimSnapshot(scrapChargeId) ? '' : 'focus';
            """,
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return tuple()
        return (
            sdc.InputFieldClientSide(cls.ID, "n_clicks", *cls.start_optimization_clientside()),
            sdc.InputFieldClientSide(cls.WS_CHANNEL_ID, "message", *cls.read_status_msg()),
            sdc.InputFieldClientSide(cls.MESSAGE_CHANNEL_SS, "modified_timestamp", *cls.reset_optimization()),
            sdc.InputField(cls.BACKEND_TRIGGER_ID, "modified_timestamp", cls.start_optimization),
        )

    @classmethod
    def reset_optimization(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "resetOptimization",
            ["viewModel", "modifiedTimestamp", "ctx"],
            Template(
                """
            updatedVM = {...viewModel};
            if (viewModel.messages_channel_ss){
                updatedVM.btn_loading = false;
                updatedVM.btn_label = '${btn_label}';
                updatedVM.progress_overlay = updatedVM.progress_overlay.setHidden(true);
            }
            return updatedVM;
            """
            ).substitute(btn_label=cls.BTN_LABEL),
        )

    @classmethod
    def start_optimization_clientside(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "startOptimization",
            ["viewModel", "nClicks", "ctx"],
            Template(
                """
            updatedVM = {...viewModel};
            if (ctx.grade(viewModel) === null){
                updatedVM.message_buffer_cs = JSON.stringify(new ctx.messageDataClass("Je potrebne zadat grade id", "warning"));
                return updatedVM;
            }
            const scrapCharge = ctx.getScrapCharge(viewModel);
            if (scrapCharge?.optimization_start_clicked !== 1){
                const scrapChargeId = ctx.getScrapChargeId(viewModel);
                ctx.updateSelectedScrapCharge(scrapChargeId, {"optimization_start_clicked": 1});
            }
            ctx.syncClientSideChanges();

            updatedVM.btn_loading = true;
            updatedVM.btn_label = '${btn_label}';
            updatedVM.backend_trigger = Number(new Date());
            updatedVM.progress_overlay = updatedVM.progress_overlay.setHidden(false);
            return updatedVM;
            """
            ).substitute(btn_label=cls.BTN_LABEL_LOADING),
        )

    @classmethod
    def read_status_msg(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "readStatusMsg",
            ["viewModel", "message", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            if (message?.data != null){
                const realMsg = JSON.parse(message.data);
                updatedVM.progress_overlay = updatedVM.progress_overlay.setProgress(realMsg?.progress);
                if (realMsg?.progress === 100)
                    ctx.models.scrapCharges.syncData();
                    updatedVM.btn_loading = false;
                    updatedVM.btn_label = '${btn_label}';
                    updatedVM.progress_overlay = updatedVM.progress_overlay.setHidden(true);
            }
            return updatedVM;
            """
            ).substitute(btn_label=cls.BTN_LABEL),
        )

    def message_channel(self) -> Optional[Message]:
        return None if not self.messages_channel_ss else Message(**self.messages_channel_ss)

    def start_optimization(self, _: int, ctx: ScrapLoadingStationCTX) -> Self:
        charge = ctx.get_scrap_charge(self.card_index)

        if charge is None:
            return self

        charge.optimization_start_clicked = True

        unallocated_scrap = charge.get_unallocated_scrap()

        model_settings = attr.evolve(
            ctx.models.loading_station.model_settings,
            optimizer_settings=attr.evolve(
                ctx.models.loading_station.model_settings.optimizer_settings,
                scrap_mix_mapping=ctx.models.available_scraps.scrap_mix_mapping,
            ),
        )

        weighted_scraps = ctx.models.weighted_scrap(charge.pk).get_switched_baskets()
        switched_basket_errors = validate_loaded_switched_basket_minimum_limit(
            charge.scrap_limits, weighted_scraps
        )
        charge_errors, warnings = validate_charge_info(
            charge,
            ctx.models.loading_station.relaxable_lower_summing_limits_settings,
            ctx.models.loading_station.relaxable_upper_summing_limits_settings,
            unallocated_scrap,
            model_settings,
        )
        errors = (*charge_errors, *switched_basket_errors)
        if errors:
            return attr.evolve(self, messages_channel_ss=Message(uuid=str(uuid.uuid1()), errors=errors))

        opt_input = create_optimization_input(
            charge,
            unallocated_scrap,
            model_settings,
            ctx.transfer_capacity_or_zero,
            ctx.models.loading_station.loading_station_id,
        )

        opt_res_id = ctx.models.optimizations.create(opt_input, charge, warnings)

        try:
            multiple_heats_scrap_optimization.send(opt_res_id)

            return attr.evolve(
                self,
                ws_msg=json.dumps(
                    {
                        "get_optimization_status": {
                            OPTIMIZATION_ID_FRONTEND_KEY: opt_res_id,
                            SCRAP_CHARGE_ID_FRONTEND_KEY: charge.pk,
                        }
                    }
                ),
            )

        except RedisConnectionError:
            log.exception(f"Optimization for input data with id {opt_res_id} could not be started.")
