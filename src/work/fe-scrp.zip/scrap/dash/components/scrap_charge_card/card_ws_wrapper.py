from string import Template
from typing import Dict, Self, Tuple

import ussksdc as sdc
from attr import frozen
from dash import dcc, html
from dash_websocket_component import DashWebsocketComponent
from django.db import DatabaseError
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback

from scalecore.processor import (
    StartingWeightingState,
    StoppedWeightingState,
    StoppingWeightingState,
    UpdateAction,
    WeightingState,
)
from scrap.consumers.scale_controller import START_EVENT_KEY, STOP_EVENT_KEY
from scrap.dash.components.protocols.scrap_loading_station import (
    ScrapLoadingStationConfig,
)
from scrap.dash.components.scrap_charge_card.card import ScrapChargeCardVM
from scrap.models.various_models import ScaleCurrentState
from scrap.scales.weighting_backend import (
    MESSAGE_BY_ACTION,
    MESSAGE_BY_EXCEPTION,
    MESSAGE_KEYS,
)


def create_url(host: str, port: int, scale_id: str) -> str:
    return f"ws://{host}:{port}/{scale_id}/scale_control"


@frozen
class ScrapChargeCardWsWrapperVM:
    # Component id
    SCALE_CONTROL_1_WS = "weighted-scrap-1-ws"
    SCALE_CONTROL_2_WS = "weighted-scrap-2-ws"
    SCRAP_CHARGE_CARD_WRAPPER_ID = "scrap-charge-cards-wrapper"
    SELECTOR_STATES_IDS = "selector-states-store"

    ws_scale_control_1_url: str = sdc.one_way_binding(SCALE_CONTROL_1_WS, "url", default="")
    ws_scale_control_2_url: str = sdc.one_way_binding(SCALE_CONTROL_2_WS, "url", default="")
    selector_states: Dict[str, str] = sdc.clientside_only_state_binding(
        SELECTOR_STATES_IDS, "data", default={}
    )
    # Child components
    card: ScrapChargeCardVM = sdc.child_component("scrap-charge", factory=ScrapChargeCardVM)
    card_1: ScrapChargeCardVM = sdc.child_component("scrap-charge-1", factory=ScrapChargeCardVM)

    @classmethod
    def create(cls, host: str, port: int, scale_ids: Tuple[str, ...]) -> Self:
        return cls(
            ws_scale_control_1_url=create_url(host, port, scale_ids[0]),
            ws_scale_control_2_url=create_url(host, port, scale_ids[1]),
            card=ScrapChargeCardVM.create(0),
            card_1=ScrapChargeCardVM.create(1),
        )

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapLoadingStationConfig) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.card, config),
                sdc.get_child_layout(parent_id, cls.card_1, config),
                DashWebsocketComponent(id=sdc.create_id(parent_id, cls.SCALE_CONTROL_1_WS)),
                DashWebsocketComponent(id=sdc.create_id(parent_id, cls.SCALE_CONTROL_2_WS)),
                dcc.Store(id=sdc.create_id(parent_id, cls.SELECTOR_STATES_IDS)),
            ],
            id=sdc.create_id(parent_id, cls.SCRAP_CHARGE_CARD_WRAPPER_ID),
        )

    @classmethod
    def get_input_fields(cls, config: ScrapLoadingStationConfig) -> sdc.InputFields:
        if config.read_only:
            return ()
        return (
            sdc.InputFieldClientSide(cls.SCALE_CONTROL_1_WS, "message", *cls.update_scrap_weight_objects(0)),
            sdc.InputFieldClientSide(cls.SCALE_CONTROL_2_WS, "message", *cls.update_scrap_weight_objects(1)),
        )

    @classmethod
    def update_scrap_weight_objects(cls, scale_idx: int) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            f"scaleControllerHandler{scale_idx}",
            ["viewModel", "message", "ctx"],
            Template(
                """
            const updates = JSON.parse(message.data) || [];
            var [updatedVm, changes] = [viewModel, {}];
            for (let update of updates){
                if (update.length === 0)
                    return viewModel;
    
                if (Object.keys(update).includes('$starting')){
                    [updatedVm, ch, aId] = viewModel.processStartingState(update.$starting, updatedVm, ctx);
                }
                
                if (Object.keys(update).includes('$weighting')){
                    [updatedVm, ch, aId] = viewModel.processWeightingState(update.$weighting, updatedVm, ctx);
                }
                
                if (Object.keys(update).includes('$stopping')){
                    [updatedVm, ch, aId] = viewModel.processStoppingState(update.$stopping, updatedVm, ctx);
                }
                
                if (Object.keys(update).includes('$last_update')){
                    [updatedVm, ch, aId] = viewModel.processAfterStopMsg(update.$last_update, updatedVm, ctx);
                }
                
                if (Object.keys(update).includes('error')){
                    [updatedVm, ch, aId] = viewModel.processErrorState(update.error, updatedVm, ctx);
                }
                
                if (aId !== null){
                    changes[aId] = [...(changes[aId] || []), ...ch];
                }
            }
            
            
            for (let affectedId of Object.keys(changes)){
                console.log("Apply changes for scrap charge id: " + affectedId);
                ctx.models.weightedScrap.getFilteredData(affectedId).apply(changes[affectedId], true);
            }
            
            return updatedVm;
            """
            ).substitute(
                starting=MESSAGE_KEYS[StartingWeightingState],
                weighting=MESSAGE_KEYS[WeightingState],
                stopping=MESSAGE_KEYS[StoppingWeightingState],
                last_update=MESSAGE_KEYS[StoppedWeightingState],
            ),
        )

    @classmethod
    def get_output_fields(cls, config: ScrapLoadingStationConfig) -> sdc.OutputFields:
        if config.read_only:
            return ()

        return (
            sdc.OutputFieldClientSide(cls.SELECTOR_STATES_IDS, "data", *cls.store_selector_states()),
            sdc.OutputFieldClientSide(cls.SCALE_CONTROL_1_WS, "send", *cls.send_trigger_for_sending_data(0)),
            sdc.OutputFieldClientSide(cls.SCALE_CONTROL_2_WS, "send", *cls.send_trigger_for_sending_data(1)),
        )

    @classmethod
    def store_selector_states(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "setSelectorStates",
            ["viewModel", "ctx"],
            """
            var states = {...(viewModel.selector_states || {})};

            const ids = [ctx.getScrapChargeId(viewModel.card), ctx.getScrapChargeId(viewModel.card_1)];
            const scaleStates = [
                viewModel.card.result.scale_selector.active_scales,
                viewModel.card_1.result.scale_selector.active_scales,
            ];
            const basketSelectors = [
                [
                    viewModel.card.result.scale_weightning.basket.basket,
                    viewModel.card.result.scale_weightning_2.basket.basket,
                ],
                [
                    viewModel.card_1.result.scale_weightning.basket.basket,
                    viewModel.card_1.result.scale_weightning_2.basket.basket,
                ]
            ];
            
            for (let idx in ids){
                const scrapChargeId = ids[idx];
                if (scrapChargeId === null)
                    continue
                
                states[scrapChargeId] = {
                    ...(states[scrapChargeId] || {}),
                    selectedScales: (scaleStates[idx] || []),
                    selectedBaskets: (basketSelectors[idx] || []),
                };
            }
            
            return states;
            """,
        )

    @classmethod
    def send_trigger_for_sending_data(cls, scale_idx: int) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            f"sendCmdToScale{scale_idx}",
            ["viewModel", "ctx"],
            Template(
                """
            const weightingComponents = [
                $scale_idx === 0 ? viewModel.card.result.scale_weightning: viewModel.card.result.scale_weightning_2,
                $scale_idx === 0 ? viewModel.card_1.result.scale_weightning: viewModel.card_1.result.scale_weightning_2
            ];
            
            const wsMsg = [];
            for (let cardIndex in weightingComponents){
                let weightingComponent = weightingComponents[cardIndex];
                const scrapSelector = weightingComponent.proposed_scraps.selectedRow;
                if (scrapSelector === undefined) {
                    continue;
                }

                let scaleId = ctx.scaleId($scale_idx);
                let scaleState = Object.values(ctx.models.scaleState.getAll()).find(obj => obj.scale_id == scaleId);

                const isWeightingChangeRequested = weightingComponent.proposed_scraps.isWeightingRequested();
                const isSelectedScrapAndIsStoppedState = (scaleState.state === 0 && scrapSelector.length !== 0);
                const isSelectedAnotherScrap = (
                    scaleState.state === 2 
                    && scrapSelector.length !== 0
                    && scrapSelector[0].id !== scaleState.scrap
                );

                if (isWeightingChangeRequested && (isSelectedScrapAndIsStoppedState || isSelectedAnotherScrap)){
                    wsMsg.push(JSON.stringify({
                        '$start_event': {
                            scrap_charge_id: ctx.getScrapChargeIdByCardIdx(cardIndex),
                            scale_id: scaleId,
                            scrap: scrapSelector[0].id,
                            weighting_id: scaleState.weighted_scrap,
                        }
                    }));
                }
                if (weightingComponent.isStopRequested()){
                    wsMsg.push(JSON.stringify({
                        '$stop_event': {
                            scale_id: scaleId,
                            weighting_id: scaleState.weighted_scrap
                        }
                    }));
                }
            }
            if (wsMsg.length === 0){
                return null;
            }
            return wsMsg;
            """
            ).substitute(
                scale_idx=scale_idx,
                start_event=START_EVENT_KEY,
                stop_event=STOP_EVENT_KEY,
            ),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (
            sdc.JsCodeField(*cls.process_starting_state()),
            sdc.JsCodeField(*cls.process_weighting_state()),
            sdc.JsCodeField(*cls.process_stopping_state()),
            sdc.JsCodeField(*cls.process_after_stop_state()),
            sdc.JsCodeField(*cls.process_error_state()),
        )

    @classmethod
    def process_starting_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "processStartingState",
            ["update", "viewModel", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            const scaleId = update.scale_id; 
            const WeightedScrapsModel = ctx.models.weightedScrap.getFilteredData(update.scrap_charge_id);
            
            ctx.models.scaleState.applyStateForScaleId(
                update.scale_id,
                {
                    state: $starting_state,
                    scrap: update.scrap_type,
                    time: update.start_time,
                    weighted_scrap: WeightedScrapsModel.nextId,
                    scrap_charge: update.scrap_charge_id,
                }
            );
            WeightedScrapsModel.add({
                    end: null,
                    id: WeightedScrapsModel.nextId,
                    scale_id: update.scale_id,
                    scrap: update.scrap_type,
                    start: update.start_time,
                    weight: 0,
                    invalid_record: false,
                }
            );

            return [updatedVM, [], null];
            """
            ).substitute(starting_state=ScaleCurrentState.ScaleState.STARTING_WEIGHTING),
        )

    @classmethod
    def process_weighting_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "processWeightingState",
            ["update", "viewModel", "ctx"],
            Template(
                """
            var [updatedVM, changes, affectedScrapChargeId] = [{...viewModel}, [], null];
            const currentScaleState = (
                Object.values(ctx.models.scaleState.getAll())
                .find(obj => obj.scale_id == update.scale_id)
            );
            affectedScrapChargeId = currentScaleState.scrap_charge;

            if (update.weight === null){
                if (currentScaleState.state === $starting_weighting){
                    const oldId = currentScaleState.weighted_scrap;
                    
                    changes.push([oldId, null, {'id': update.weighting_id}]);
                    changes.push([oldId, update.weighting_id, null]);
                    
                    ctx.models.scaleState.applyStateForScaleId(
                        update.scale_id, {state: $weighting_state, weighted_scrap: update.weighting_id}
                    );   
                }
            } else {
                changes.push([update.weighting_id, null, {"weight": update.weight}]);
                affectedScrapChargeId = ctx.models.weightedScrap.findScrapChargeId(update.weighting_id);
            }
            return [updatedVM, changes, affectedScrapChargeId];
            """
            ).substitute(
                weighting_state=ScaleCurrentState.ScaleState.WEIGHTING,
                starting_weighting=ScaleCurrentState.ScaleState.STARTING_WEIGHTING,
            ),
        )

    @classmethod
    def process_after_stop_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "processAfterStopMsg",
            ["update", "viewModel", "ctx"],
            Template(
                """
            var [updatedVM, changes] = [{...viewModel}, []];
            const affectedScrapChargeId = ctx.models.weightedScrap.findScrapChargeId(update.weighting_id);
            
            changes.push([update.weighting_id, null, {"weight": update.last_measured_weight}]);
            ctx.models.scaleState.applyStateForScaleId(
                update.scale_id,
                {state: $stopped_state, scrap: null, time: null, scrap_charge: null}
            );
            return [updatedVM, changes, affectedScrapChargeId];
            """
            ).substitute(stopped_state=ScaleCurrentState.ScaleState.STOPPED_WEIGHTING),
        )

    @classmethod
    def process_error_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "processErrorState",
            ["update", "viewModel", "ctx"],
            Template(
                """
            var updatedVM = {...viewModel};
            const errorReason = update.reason;
            const action = update.action;
            if (errorReason == '$lock' && action == '$update_action'){
                console.warn("Scale " + update.scale_id + " current state has locked row in DB.");
            } else {
                const scaleIdx = ctx.scaleIds.indexOf(update.scale_id);
                const scaleState = Object.values(ctx.models.scaleState.getAll()).find(
                    obj => obj.scale_id === update.scale_id
                );
                if (scaleIdx === 0){
                    if (scaleState.state === 0){
                        updatedVM.scale_weightning.proposed_scraps = (
                            updatedVM.scale_weightning.proposed_scraps.deselectSelectedScrap()
                        );
                    } else {
                        updatedVM.scale_weightning.proposed_scraps = (
                            updatedVM.scale_weightning.proposed_scraps.selectRow(scaleState.scrap)
                        );
                    }
                }else {
                    if (scaleState.state === 0){
                        updatedVM.scale_weightning_2.proposed_scraps = (
                            updatedVM.scale_weightning_2.proposed_scraps.deselectSelectedScrap()
                        );
                    } else {
                        updatedVM.scale_weightning.proposed_scraps = (
                            updatedVM.scale_weightning.proposed_scraps.selectRow(scaleState.scrap)
                        );
                    }
                }
                updatedVM.message_buffer_cs = ctx.createClientSideMsg(
                    "Nepodarilo sa vykonat požadovanú akciu, skúste to znova.",
                    "error"
                );
            }
            return [updatedVM, [], null];
            """
            ).substitute(
                lock=MESSAGE_BY_EXCEPTION[DatabaseError], update_action=MESSAGE_BY_ACTION[UpdateAction]
            ),
        )

    @classmethod
    def process_stopping_state(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "processStoppingState",
            ["update", "viewModel", "ctx"],
            Template(
                """
            var [updatedVM, changes] = [{...viewModel}, []];
            const affectedScrapChargeId = ctx.models.weightedScrap.findScrapChargeId(update.weighting_id);
            changes.push([update.weighting_id, null, {"end": update.stop_time}]);
            ctx.models.scaleState.applyStateForScaleId(
                update.scale_id, {state: $stopping_state, time: update.stop_time}
            );
            return [updatedVM, changes, affectedScrapChargeId];
            """
            ).substitute(stopping_state=ScaleCurrentState.ScaleState.STOPPING_WEIGHTING),
        )
