from typing import List, Mapping, Optional, Tuple, TypedDict

from common.dash import CELL_STYLE, TABLE_HEADER_STYLE
from dash import dash_table
from dash.dash_table import FormatTemplate
from dash.dash_table.Format import Format, Scheme
from scrap_core.correctiontechnologiesmodel.correction_technologies import CorrectionTechnologyType
from scrap_core.correctiontechnologiesmodel.datamodel import CorrectionTechnologiesModelOutput
from scrap_core.yieldmodel import ScrapYieldModelOutput


class PriceFunctionTableRow(TypedDict):
    price_component: str
    unit_price: Optional[float]
    probability: Optional[float]
    weight: Optional[float]
    final_price: float
    real_price: Optional[float]


PriceFunctionTableData = List[PriceFunctionTableRow]
CorrectionTechnologyPrices = Mapping[Tuple[CorrectionTechnologyType, float], float]


def create_price_function_table(element_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=element_id,
        style_cell_conditional=[
            {"if": {"column_id": "price_component"}, "width": "190px"},
            {"if": {"column_id": "unit_price"}, "width": "100px"},
            {"if": {"column_id": "probability"}, "width": "100px"},
            {"if": {"column_id": "weight"}, "width": "100px"},
            {"if": {"column_id": "final_price"}, "width": "100px"},
            {"if": {"column_id": "real_price"}, "width": "100px"},
        ],
        style_data_conditional=[
            {"if": {"column_id": "price_component"}, "textAlign": "left"},
            {"if": {"filter_query": '{price_component} = "Celková cena šrotu"'}, "fontWeight": "bold"},
            {"if": {"filter_query": '{price_component} = "Celková cena opráv"'}, "fontWeight": "bold"},
            {
                "if": {"filter_query": '{price_component} = "Celková cena na tonu ocele"'},
                "fontWeight": "bold",
            },
        ],
        style_table={"margin-bottom": "16px", "padding-left": "16px", "width": "1%"},
        style_header=TABLE_HEADER_STYLE,
        style_cell=CELL_STYLE,
        columns=[
            {"name": "Zložka ceny", "id": "price_component", "type": "text", "editable": False},
            {
                "name": "Jednotková cena na kg",
                "id": "unit_price",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=4, scheme=Scheme.fixed),
            },
            {
                "name": "Pravdepodobnosť uplatnenia zložky",
                "id": "probability",
                "type": "numeric",
                "editable": False,
                "format": FormatTemplate.percentage(1),
            },
            {
                "name": "Hmotnosť [kg] / počet jednotiek",
                "id": "weight",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=0, scheme=Scheme.fixed),
            },
            {
                "name": "Očakávaná finálna cena",
                "id": "final_price",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=1, scheme=Scheme.fixed),
            },
            {
                "name": "Reálna cena",
                "id": "real_price",
                "type": "numeric",
                "editable": False,
                "format": Format(precision=1, scheme=Scheme.fixed),
            },
        ],
        data=[],
        editable=False,
    )


def get_correction_technology_name(cor_type: CorrectionTechnologyType, reality: bool) -> str:
    suffix = " (realita)" if reality else " (model)"
    if cor_type == CorrectionTechnologyType.REBLOW:
        return "Dofuk" + suffix
    if cor_type == CorrectionTechnologyType.RECLASSIFICATION:
        return "Preplánovanie tavby" + suffix
    if cor_type == CorrectionTechnologyType.SYNT_SLAG:
        return "Synt. troska" + suffix
    raise Exception(f"Unprocessed correction type: {cor_type}")


def should_create_row_for_corr_tech(corr_tech: CorrectionTechnologyType, corr_tech_unit: float) -> bool:
    return (corr_tech != CorrectionTechnologyType.NO_CORRECTION) and (corr_tech_unit > 0)


def get_correction_technologies_table_data(
    model_output: CorrectionTechnologiesModelOutput, real_output: Optional[CorrectionTechnologiesModelOutput]
) -> PriceFunctionTableData:
    model_table_data: PriceFunctionTableData = [
        {
            "price_component": get_correction_technology_name(corr_tech_rank[0], False),
            "unit_price": None,
            "probability": corr_tech_proba,
            "weight": corr_tech_rank[1],
            "final_price": 0.0,
            "real_price": 0.0,
        }
        for corr_tech_rank, corr_tech_proba in model_output.correction_technologies_probas.items()
        if should_create_row_for_corr_tech(*corr_tech_rank)
    ]
    real_table_data: PriceFunctionTableData = []
    if real_output is not None:
        real_table_data = [
            {
                "price_component": get_correction_technology_name(corr_tech_rank[0], True),
                "unit_price": None,
                "probability": 0.0,
                "weight": corr_tech_rank[1],
                "final_price": 0.0,
                "real_price": 0.0,
            }
            for corr_tech_rank, corr_tech_proba in real_output.correction_technologies_probas.items()
            if should_create_row_for_corr_tech(*corr_tech_rank)
        ]

    return model_table_data + real_table_data


def get_steel_weight_row(
    yield_model_output: ScrapYieldModelOutput, real_output: Optional[ScrapYieldModelOutput]
) -> PriceFunctionTableData:
    calculated_weight = yield_model_output.final_steel_weight
    real_weight = 0.0 if real_output is None else real_output.final_steel_weight
    return [
        {
            "price_component": "Hmotnosť tekutej ocele",
            "unit_price": None,
            "probability": None,
            "weight": None,
            "final_price": calculated_weight,
            "real_price": None if real_output is None else real_weight,
        }
    ]


def create_price_function_table_data(
    corr_tech_model_output: CorrectionTechnologiesModelOutput,
    real_corr_tech: Optional[CorrectionTechnologiesModelOutput],
    yield_model_output: ScrapYieldModelOutput,
    real_yield: Optional[ScrapYieldModelOutput],
) -> PriceFunctionTableData:
    cor_tech_data = get_correction_technologies_table_data(corr_tech_model_output, real_corr_tech)
    steel_weight_data = get_steel_weight_row(yield_model_output, real_yield)

    return cor_tech_data + steel_weight_data
