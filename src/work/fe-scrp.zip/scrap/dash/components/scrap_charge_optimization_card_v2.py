from datetime import date
from typing import List, Optional, TypedDict

import dash_bootstrap_components as dbc
from dash import dash_table, html
from common.dash import CELL_STYLE, DATA_TEXT_STYLE, TABLE_HEADER_STYLE
from scrap.dash.components import get_scrap_type_label
from scrap.dash.components.blend_results_table import create_results_table
from scrap.dash.components.raw_fe_chem_table import create_raw_fe_chem_table
from scrap.dash.components.scrap_charge_limits_table import create_charge_limits_table_v2
from scrap.dash.components.selectors import create_grade_selector
from scrap.dash.database_api import steel_grades

BASKET_NUMBER_INPUT_ID = "basket-number-input"
SWITCHED_BASKET_NUMBER_INPUT_ID = "switched-basket-number-input"
WEIGHT_INPUT_ID = "weight-input"
PIG_IRON_WEIGHT_INPUT_ID = "pig-iron-weight-input"
COMMENT_INPUT_ID = "comment-input"
CHARGE_CARD_ID = "charge-card-id"
GRADE_SELECTOR_ID = "grade-selector"
CALCULATE_OUTPUT_BUTTON_ID = "calculate-output-button"
RECALCULATE_OUTPUT_BUTTON_ID = "recalculate-output-button"
CLEAR_SCRAP_LIMITS_BUTTON_ID = "clear-scrap-limits-button-id"
READ_SCRAP_LIMITS_FROM_RESULT_BUTTON_ID = "read-scrap-limits-from-result-button-id"
CHARGE_OPTIMIZATION_CARD_HEADER_ID = "charge-optimization-card-header"
CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID = "charge-optimization-card-footer"
OPTIMIZATION_RESULTS_TABLE_ID = "scrap-optimization-results-table"
OPTIMIZATION_INPUT_DIV_ID = "scrap-optimization-input-div"
CONFIRM_CHARGE_BUTTON_ID = "confirm-charge-button"
PROGRESS_BAR_ID = "progress-bar"
CLOSE_PROGRESS_BAR_ID = "ending-progress-bar"
CARD_BODY_DIV_ID = "card-body-div"
RAW_FE_CHEM_TABLE_ID = "raw-fe-chem-table"
CHARGE_LIMITS_TABLE_ID = "charges-limits-table"
COLLAPSE_BUTTON_ID = "collapse-button"
COLLAPSE_ADVANCE_SETTINGS_ID = "collapse"
CARD_HEADER_DELETE_CHARGE_BUTTON = "card-header-delete-button"
DETAIL_OPTIMIZATION_TABLE_RESULT_ID = "detail_optimization_table_result"
OPTIMIZATION_RESULT_PROBABILITY_INFO_MSG_ID = "optimization-result-probability-info-msg"
CONFIRM_CHARGE_BUTTON_MSG_ID = "confirm-charge-button-msg"


DETAIL_OPTIMIZATION_RESULT_TABLE_ID = "detail-optimization-table-result-div"
DETAIL_OPTIMIZATION_BUTTON_RESULT_ID = "detail-optimization-button-result"


class ScrapOptimizationResultTableRow(TypedDict):
    label: str
    scrap_type: str
    recommended_weight: Optional[float]


ScrapOptimizationResultTableData = List[ScrapOptimizationResultTableRow]


def create_optimization_input_table_row(
    scrap_type: str, recommended_weight: float
) -> ScrapOptimizationResultTableRow:
    return {
        "label": get_scrap_type_label(scrap_type),
        "scrap_type": scrap_type,
        "recommended_weight": recommended_weight,
    }


def create_scrap_optimization_input_table(table_id: str) -> dash_table.DataTable:
    return dash_table.DataTable(
        id=table_id,
        columns=[
            {"name": "Typ šrotu", "id": "label", "type": "text", "editable": False},
            {"name": "Odporúčanie [t]", "id": "recommended_weight", "type": "number", "editable": False},
        ],
        data=[],
        style_data_conditional=DATA_TEXT_STYLE,
        style_cell_conditional=[{"if": {"column_id": "label"}, "width": "120px"}],
        style_table={"padding-left": "16px", "padding-right": "16px", "margin-top": "10px"},
        style_cell={**CELL_STYLE, "textAlign": "left"},
        style_header=TABLE_HEADER_STYLE,
    )


### COMPONENTS


def get_visual_separator(label: str) -> html.Div:
    return html.Div(
        [html.Div(className="line line-left"), html.H5(label)],
        className="separator",
    )


### CARD HEADER COMPONENT


def get_card_header(read_only: bool) -> dbc.CardHeader:
    return dbc.CardHeader(
        dbc.Row(
            [
                html.Div(
                    "Tavba",
                    id=CHARGE_OPTIMIZATION_CARD_HEADER_ID,
                    style={"font-weight": "bold"},
                    className="mx-2",
                ),
                html.Div(
                    dbc.Button(
                        "Odstrániť tavbu",
                        id=CARD_HEADER_DELETE_CHARGE_BUTTON,
                        outline=True,
                        color="danger",
                        size="sm",
                        className="mx-2",
                    ),
                    id=CARD_HEADER_DELETE_CHARGE_BUTTON + "-div",
                    hidden=read_only,
                ),
            ],
            justify="between",
            className="align-items-center",
        )
    )


### COMPONENTS FOR CARD BODY


def get_basket_number_input(input_id: str, read_only: bool) -> html.Div:
    return html.Div(
        [
            dbc.Label("Čísla korýt"),
            dbc.Input(
                id=input_id,
                type="text",
                style={"width": "100%"},
                debounce=True,
                disabled=read_only,
            ),
            dbc.FormText("", id=input_id + "-msg"),
        ],
        id=input_id + "-group",
    )


def get_switched_basket_number_input(input_id: str, read_only: bool) -> html.Div:
    return html.Div(
        [
            dbc.Label("Točené korytá"),
            dbc.Input(
                id=input_id,
                type="text",
                style={"width": "100%"},
                debounce=True,
                disabled=read_only,
            ),
            dbc.FormText("", id=input_id + "-msg"),
        ],
        id=input_id + "-group",
    )


def get_grade_selector(input_id: str, read_only: bool) -> html.Div:
    today = date.today()
    available_grade_ids = steel_grades.get_available_grade_ids(today)
    return html.Div(
        [
            dbc.Label("Plánovaná akosť"),
            create_grade_selector(
                input_id=input_id,
                disabled=read_only,
            ),
            dbc.FormText("", id=input_id + "-msg"),
        ],
        id=input_id + "-group",
    )


def create_number_input_with_unit_label(
    input_id: str,
    label: str,
    read_only: bool,
) -> html.Div:
    return html.Div(
        [
            dbc.Label(label, style={"white-space": "nowrap"}),
            dbc.InputGroup(
                [
                    dbc.Input(
                        id=input_id,
                        type="number",
                        step=0.1,
                        value=0.0,
                        style={"width": "60%"},
                        debounce=True,
                        disabled=read_only,
                    ),
                    dbc.InputGroupText("t"),
                ],
            ),
            dbc.FormText("", id=input_id + "-msg"),
        ],
        id=input_id + "-group",
        style={"width": "100%"},
    )


def get_total_scrap_weight_input(input_id: str, read_only: bool) -> html.Div:
    return create_number_input_with_unit_label(
        input_id,
        "Hmotnosť šrotu",
        read_only,
    )


def get_pig_iron_weight_input(input_id: str, read_only: bool) -> html.Div:
    return create_number_input_with_unit_label(
        input_id,
        "Hmotnosť sur. železa",
        read_only,
    )


def get_advance_settings_collapse_btn(input_id: str) -> html.Div:
    return html.Div(
        dbc.Button(
            "Rozšírené nastavenia",
            id=input_id,
            n_clicks=0,
            color="info",
            outline=False,
            style={
                "margin-bottom": "16px",
                "width": "100%",
                "white-space": "nowrap",
                "text-overflow": "ellipsis",
                "overflow": "hidden",
            },
        ),
        id=input_id + "-div",
        style={
            "padding-top": "32px",
        },
    )


def get_input_fields_row(read_only: bool) -> dbc.Row:
    return dbc.Row(
        [
            dbc.Col(get_basket_number_input(BASKET_NUMBER_INPUT_ID, read_only), sm=6, md=6, lg=4, xl=2),
            dbc.Col(
                get_switched_basket_number_input(SWITCHED_BASKET_NUMBER_INPUT_ID, read_only),
                sm=6,
                md=6,
                lg=4,
                xl=2,
            ),
            dbc.Col(get_grade_selector(GRADE_SELECTOR_ID, read_only), sm=6, md=6, lg=4, xl=2),
            dbc.Col(get_total_scrap_weight_input(WEIGHT_INPUT_ID, read_only), sm=6, md=6, lg=4, xl=2),
            dbc.Col(get_pig_iron_weight_input(PIG_IRON_WEIGHT_INPUT_ID, read_only), sm=6, md=6, lg=4, xl=2),
            dbc.Col(
                get_advance_settings_collapse_btn(COLLAPSE_BUTTON_ID),
                sm=6,
                md=6,
                lg=4,
                xl=2,
            ),
        ]
    )


def get_advance_settings_collapse_row(read_only: bool) -> dbc.Row:
    return dbc.Row(
        dbc.Collapse(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            create_charge_limits_table_v2(CHARGE_LIMITS_TABLE_ID, read_only),
                            xs=12,
                            sm=8,
                            md=7,
                            lg=8,
                            xl=6,
                        ),
                        dbc.Col(
                            html.Div(
                                children=create_raw_fe_chem_table(RAW_FE_CHEM_TABLE_ID, read_only),
                                id=RAW_FE_CHEM_TABLE_ID + "-div",
                            ),
                            xs=12,
                            sm=4,
                            md=5,
                            lg=4,
                            xl=6,
                        ),
                    ],
                    style={"padding": "0 15px"},
                ),
                dbc.Row(
                    dbc.Col(
                        html.Div(
                            [
                                dbc.Button(
                                    "Načítať limity šrotov z poslednej optimalizácie",
                                    id=READ_SCRAP_LIMITS_FROM_RESULT_BUTTON_ID,
                                    outline=False,
                                    n_clicks=0,
                                    style={"width": "24%"},
                                    color="secondary",
                                    size="sm",
                                ),
                                dbc.Button(
                                    "Vymazať limity šrotov",
                                    id=CLEAR_SCRAP_LIMITS_BUTTON_ID,
                                    outline=False,
                                    n_clicks=0,
                                    color="danger",
                                    style={"width": "24%", "margin-left": "10px"},
                                    size="sm",
                                ),
                            ],
                            style={"padding": "0 16px"},
                            hidden=read_only,
                        ),
                    ),
                ),
            ],
            className="mt-2 w-100",
            id=COLLAPSE_ADVANCE_SETTINGS_ID,
        ),
    )


def get_calculate_button_row() -> dbc.Row:
    return dbc.Row(
        [
            dbc.Col(
                html.Div(
                    dbc.Button(
                        "Vypočítať vsádzku",
                        id=CALCULATE_OUTPUT_BUTTON_ID,
                        color="primary",
                        n_clicks=0,
                        style={
                            "margin-top": "10px",
                            "width": "100%",
                            "font-weight": "700",
                            "letter-spacing": "2px",
                        },
                    ),
                    style={"width": "100%"},
                    id=CALCULATE_OUTPUT_BUTTON_ID + "-div",
                ),
                width=12,
            )
        ],
    )


def get_optimization_results_table_row() -> dbc.Row:
    return dbc.Row(
        dbc.Col(create_scrap_optimization_input_table(OPTIMIZATION_RESULTS_TABLE_ID), width=12),
    )


def get_optimization_results_detail_table_row() -> dbc.Row:
    return dbc.Row(
        [
            dbc.Col(
                dbc.Row(
                    [
                        dbc.Col(
                            html.Div(
                                id=OPTIMIZATION_RESULT_PROBABILITY_INFO_MSG_ID,
                            ),
                        ),
                        dbc.Col(
                            html.Div(
                                dbc.Button(
                                    " Zobraziť detailné výsledky ",
                                    color="link",
                                    n_clicks=0,
                                    className="m-0 p-0 font-weight-bold",
                                    style={"float": "right"},
                                    id=DETAIL_OPTIMIZATION_BUTTON_RESULT_ID,
                                ),
                                id=DETAIL_OPTIMIZATION_BUTTON_RESULT_ID + "-div",
                                hidden=True,
                                style={"padding": "2px 10px"},
                            ),
                        ),
                    ]
                ),
            ),
            dbc.Col(
                html.Div(
                    create_results_table(DETAIL_OPTIMIZATION_TABLE_RESULT_ID, False),
                    className="mt-2",
                    style={"overflow": "auto"},
                    hidden=True,
                    id=DETAIL_OPTIMIZATION_RESULT_TABLE_ID,
                ),
                width=12,
            ),
        ]
    )


def get_operator_comment_input_row() -> html.Div:
    return html.Div(
        dbc.Row(
            dbc.Col(
                html.Div(
                    dbc.InputGroup(
                        [
                            dbc.InputGroupText("Komentár operátora"),
                            dbc.Input(
                                id=COMMENT_INPUT_ID,
                                type="text",
                                debounce=True,
                                placeholder="Zmenu limitov pre šroty alebo optimalizáciu spustenú"
                                + " napriek varovaniam je nutné zdôvodniť.",
                            ),
                        ],
                        className="my-2",
                    ),
                ),
                width=12,
            ),
        ),
    )


def get_operator_decission_buttons_row() -> dbc.Row:
    return dbc.Row(
        [
            dbc.Col(
                dbc.Button(
                    "Uzavrieť tavbu", color="success", id=CONFIRM_CHARGE_BUTTON_ID, className="btn-block"
                ),
                width=6,
                className="pl-0",
            ),
            dbc.Col(
                dbc.Button(
                    "Prepočítať vsádzku",
                    color="primary",
                    id=RECALCULATE_OUTPUT_BUTTON_ID,
                    className="btn-block",
                ),
                width=6,
                className="pr-0",
            ),
            dbc.Col(
                html.Div(id=CONFIRM_CHARGE_BUTTON_MSG_ID, hidden=True, style={"color": "#BB2124"}),
                className="pl-0 mt-1",
                width=12,
            ),
        ],
        className="mt-2 mx-1",
    )


def get_optimization_result_with_options(read_only: bool) -> html.Div:
    all_children = [
        get_visual_separator("2. Výsledok"),
        get_optimization_results_table_row(),
        get_optimization_results_detail_table_row(),
    ]
    if not read_only:
        all_children.append(get_visual_separator("3. Rozhodnutie"))
        all_children.append(get_operator_comment_input_row())
        all_children.append(get_operator_decission_buttons_row())
    return html.Div(all_children, hidden=True, id=OPTIMIZATION_INPUT_DIV_ID)


def get_card_body(read_only: bool) -> dbc.CardBody:
    rows = [
        get_visual_separator("1. Vstupy"),
        get_input_fields_row(read_only),
        get_advance_settings_collapse_row(read_only),
    ]
    if not read_only:
        rows.append(get_calculate_button_row())
    rows.append(get_optimization_result_with_options(read_only))
    return dbc.CardBody(html.Div(rows), id=CARD_BODY_DIV_ID)


### COMPONENTS FOR CARD FOOTER


def get_footer_error_msg() -> html.Div:
    # #BB2124 is the same color as danger color but css doesnt have boostrap color label
    return html.Div(
        dbc.Col(
            "Nastala chyba pri optimalizácií. Prosím skúste to znova.",
            style={"color": "#BB2124", "font-weight": "bold", "text-align": "center"},
            id=CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID,
        ),
        hidden=True,
        id=CHARGE_OPTIMIZATION_CARD_FOOTER_ERROR_ID + "-div",
    )


def get_optimization_progress_bar(read_only: bool) -> html.Div:
    return html.Div(
        [
            dbc.Col(
                "Prebieha optimalizácia nákladky.",
                width=12,
                style={"text-align": "center"},
            ),
            dbc.Col(
                [
                    html.Div(
                        dbc.Progress("0%", value=0.0, animated=True, id=PROGRESS_BAR_ID),
                        hidden=read_only,
                    ),
                    html.Div(
                        dbc.Progress(
                            value=100.0,
                            animated=True,
                            id="read-only-" + PROGRESS_BAR_ID,
                        ),
                        hidden=not read_only,
                    ),
                ],
                width=12,
                style={"margin-top": "10px"},
            ),
        ],
        hidden=True,
        id=PROGRESS_BAR_ID + "-div",
    )


def get_close_progress_bar() -> html.Div:
    return html.Div(
        [
            dbc.Col("Uzatváram nákladku.", width=12, style={"text-align": "center"}),
            dbc.Col(
                dbc.Progress(value=100.0, animated=True, id=CLOSE_PROGRESS_BAR_ID),
                width=12,
                style={"margin-top": "10px"},
            ),
        ],
        hidden=True,
        id=CLOSE_PROGRESS_BAR_ID + "-div",
    )


def get_card_footer(read_only: bool) -> dbc.CardFooter:
    return dbc.CardFooter(
        [
            get_footer_error_msg(),
            get_optimization_progress_bar(read_only),
            get_close_progress_bar(),
        ],
        style={"background-color": "#fff", "border": "none"},
    )


### CARD COMPONENT


def create_scrap_charge_optimization_card_v2(read_only: bool) -> html.Div:
    return html.Div(
        dbc.Card(
            [get_card_header(read_only), get_card_body(read_only), get_card_footer(read_only)],
            style={"margin-right": "16px", "margin-left": "16px"},
            id=CHARGE_CARD_ID,
        ),
        id=CHARGE_CARD_ID + "-div",
        hidden=True,
    )
