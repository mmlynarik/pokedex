import time
from typing import Any, Dict, List, Sequence, Union

import attr
from dash import html
from dash.dash_table import DataTable
from scrap.dash.components.table_common import table_wrapper_with_header
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.grade_group import GradeGroupTableRowViewModel
from scrap.dash.components.grade_group.datasource import GradeGroupTableDataSource, get_data_source
from scrap.dash.components.grade_group.modal import GradeGroupModalViewModel
from scrap.dash.components.modals.delete_confirm import DeleteGradeGroupConfirmModalViewModel
from scrap.models import GradeGroup

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class GradeGroupTableViewModel:
    # Initial setup
    TOOLTIP_CHARACTER_THRESHOLD = 18
    HIDDEN_ON_LOAD = False
    # Components ID
    COMPONENT_ID = "table"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    TABLE_WRAPPER_ID = "dash-table-wrapper"
    ADD_NEW_GROUP_ID = "add-new-group"
    HEADER_MSG_ID = "message"
    DELETE_COLUMN_ID = "delete"
    EDIT_COLUMN_ID = "edit"
    # User friendly msg
    NAME = "Skupina akosti"
    ADD = "Pridať skupinu"
    DELETE = "Odstrániť skupinu"

    data_load_time: int = attr.ib(factory=time.time_ns, converter=int)
    delete_confirm_modal: DeleteGradeGroupConfirmModalViewModel = sdc.child_component(
        "confirm-delete", default=DeleteGradeGroupConfirmModalViewModel()
    )
    modal: GradeGroupModalViewModel = sdc.child_component(
        "grade-group-modal", factory=GradeGroupModalViewModel
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.ADD_NEW_GROUP_ID, "n_clicks", GradeGroupTableViewModel.open_modal),
            sdc.InputField(cls.COMPONENT_ID, "active_cell", GradeGroupTableViewModel.control_active_cell),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", GradeGroupTableViewModel.to_table_data),
            sdc.OutputField(cls.COMPONENT_ID, "tooltip_data", GradeGroupTableViewModel.to_tooltip_data),
            sdc.OutputField(
                GradeGroupTableViewModel.COMPONENT_ID, "active_cell", lambda _: None
            ),  # Reset active cell makes it possible to click on cell more then once
        )

    @classmethod
    def get_grade_group_table(cls, table_id: str, dash_table_wrapper_id: str) -> html.Div:
        return html.Div(
            DataTable(
                columns=[
                    {"name": "", "id": cls.EDIT_COLUMN_ID, "type": "text"},
                    {"name": "Názov skupiny", "id": "name", "type": "text"},
                    {"name": "Skupiny akosti", "id": "grade_ids_str", "type": "text"},
                    {"name": "Komentár", "id": "comment", "type": "text"},
                    {"name": "", "id": cls.DELETE_COLUMN_ID, "type": "text"},
                ],
                data=[],
                editable=False,
                fill_width=True,
                id=table_id,
                tooltip_delay=0,
                tooltip_duration=None,
            ),
            id=dash_table_wrapper_id,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return table_wrapper_with_header(
            cls.get_grade_group_table(
                sdc.create_id(parent_id, cls.COMPONENT_ID), sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID)
            ),
            cls.NAME,
            cls.ADD,
            sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
            sdc.create_id(parent_id, cls.HEADER_MSG_ID),
            sdc.create_id(parent_id, cls.ADD_NEW_GROUP_ID),
            cls.HIDDEN_ON_LOAD,
            [
                sdc.get_child_layout(parent_id, cls.modal),
                sdc.get_child_layout(parent_id, cls.delete_confirm_modal),
            ],
        )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time, self.modal.last_change.data, self.delete_confirm_modal.last_change.data
        )

    @property
    def data_source(self) -> GradeGroupTableDataSource:
        return get_data_source(self.last_change)

    @property
    def rows(self) -> Sequence[GradeGroupTableRowViewModel]:
        return self.data_source.get_grade_groups()

    def open_modal(self, _: int, ctx: SettingsAppFiltersSource) -> "GradeGroupTableViewModel":
        return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx))

    def to_table_data(self) -> List[Dict[str, Union[str, float]]]:
        return [row.dash_table_row for row in self.rows]

    def to_tooltip_data(self) -> List[Dict[str, str]]:
        return [
            {
                "grade_ids_str": (
                    row.grade_ids_str if len(row.grade_ids) > self.TOOLTIP_CHARACTER_THRESHOLD else ""
                )
            }
            for row in self.rows
        ]

    def open_delete_confirm_modal(
        self, row_view_model: GradeGroupTableRowViewModel
    ) -> "GradeGroupTableViewModel":
        grade_group = GradeGroup.objects.get(id=row_view_model.group_id)
        foreign_key_list = grade_group.all_uses
        if not foreign_key_list:
            is_action_impossible = False
            msg = f"Pozor snažíte sa vymazať skupinu akostí s názvom {row_view_model.name}! Naozaj chcete túto skupinu odstrániť?"
        else:
            is_action_impossible = True
            foreign_key_str = ", ".join([limit.name for limit in foreign_key_list])  # type: ignore
            msg = f"Skupinu akostí {row_view_model.name} nie je možné odstrániť z dôvodu využitia v limite {foreign_key_str}"
        return attr.evolve(
            self,
            delete_confirm_modal=DeleteGradeGroupConfirmModalViewModel(
                is_open=True,
                message=msg,
                is_action_impossible=is_action_impossible,
                affected_id=DataStoreViewModel(row_view_model.group_id),  # type: ignore
            ),
        )

    def control_active_cell(
        self,
        active_cell: Dict[str, Any],
        ctx: SettingsAppFiltersSource,
    ) -> "GradeGroupTableViewModel":
        if active_cell is None:
            return self
        row_view_model = self.rows[active_cell["row"]]
        active_cell_id = active_cell["column_id"]
        if active_cell_id == self.DELETE_COLUMN_ID:
            return self.open_delete_confirm_modal(row_view_model)
        if active_cell_id == self.EDIT_COLUMN_ID:
            return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx, row_view_model))
        return self
