from typing import Collection, Dict, Union

import attr


@attr.s(frozen=True, auto_attribs=True, slots=True)
class GradeGroupTableRowViewModel:
    group_id: int
    name: str
    comment: str = ""
    grade_ids: Collection[int] = ()
    grade_ids_str: str = ""
    edit: str = "📝"
    delete: str = "❌"

    @property
    def dash_table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)  # type: ignore
        # TODO remove type ignore with new mypy version
