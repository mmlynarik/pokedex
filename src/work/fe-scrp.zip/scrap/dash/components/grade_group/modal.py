import time
from typing import Optional

import attr
import dash_bootstrap_components as dbc
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.grade_group import GradeGroupTableRowViewModel
from scrap.dash.components.modals import create_input_wrapper, create_modal_footer, create_modal_header
from scrap.dash.components.selectors import GradeMultipleSelectorViewModel
from scrap.models import GradeDefinition, GradeGroup

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreStrViewModel, DataStoreViewModel


@attr.s(frozen=True, slots=True)
class GradeGroupModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    COMPONENT_ID = "modal"
    NAME_ID = "name"
    CLOSE_BUTTON_ID = "close"
    COMMENT_ID = "comment"
    CONFIRM_BUTTON_ID = "update"
    NAME_VALIDATION_MSG_ID = "name-validation"
    # User friendly msg
    NEW_GRADE_GROUP = "Nova skupina akosti"
    CREATE_GRADE_GROUP = "Vytvoriť skupinu akosti"
    UPDATE_GRADE_GROUP = "Aktualizovať skupinu akosti"
    NAME_MUST_BE_FILLED = "Názov skupiny musí byť vyplnený"
    GRADE_GROUP_NAME_ALREADY_EXISTS = "Skupina akostí s názvom {} už existuje."
    COMMENT = "Komentár"
    CHOOSE_GRADES = "Vyber akosti"

    affected_grade_group_id: DataStoreViewModel = sdc.child_component(
        "affected-grade-group-data-store", default=DataStoreViewModel()
    )
    origin_name: DataStoreStrViewModel = sdc.child_component(
        "origin-scrap-name-data-store", default=DataStoreStrViewModel()
    )
    last_change: DataStoreViewModel = sdc.child_component(
        "last-change-data-store", default=DataStoreViewModel(0)  # type: ignore #[SDC MYPY BUG]
    )
    grades: GradeMultipleSelectorViewModel = sdc.child_component(
        "grades", default=GradeMultipleSelectorViewModel()
    )
    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    confirm_button_label: str = sdc.one_way_binding(
        CONFIRM_BUTTON_ID, "children", default="Vytvoriť novu skupinu akosti"
    )
    name: str = sdc.two_way_binding(NAME_ID, "value", default=NEW_GRADE_GROUP)
    comment: str = sdc.two_way_binding(COMMENT_ID, "value", default="")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", GradeGroupModalViewModel.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", GradeGroupModalViewModel.confirm_event),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.CONFIRM_BUTTON_ID, "disabled", GradeGroupModalViewModel.are_inputs_invalid),
            sdc.OutputField(cls.NAME_VALIDATION_MSG_ID, "children", GradeGroupModalViewModel.name_validation),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            backdrop="static",
            children=[
                create_modal_header(
                    sdc.create_id(parent_id, cls.NAME_ID),
                    sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID),
                    sdc.create_id(parent_id, cls.NAME_VALIDATION_MSG_ID),
                ),
                dbc.ModalBody(
                    children=[
                        create_input_wrapper(
                            cls.CHOOSE_GRADES,
                            [sdc.get_child_layout(parent_id, cls.grades)],
                        ),
                        create_input_wrapper(
                            cls.COMMENT,
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.COMMENT_ID), debounce=True),
                            ],
                        ),
                    ]
                ),
                create_modal_footer(sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), ""),
                sdc.get_child_layout(parent_id, cls.affected_grade_group_id),
                sdc.get_child_layout(parent_id, cls.origin_name),
                sdc.get_child_layout(parent_id, cls.last_change),
            ],
            centered=True,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            keyboard=False,
        )

    @property
    def update(self) -> bool:
        return self.affected_grade_group_id.data != -1

    def set_input_values_and_open(
        self, ctx: SettingsAppFiltersSource, row_view_model: Optional[GradeGroupTableRowViewModel] = None
    ) -> "GradeGroupModalViewModel":
        if row_view_model is None:
            selected_grade = () if ctx.selected_grade_id is None else (ctx.selected_grade_id,)
            return attr.evolve(
                self,
                is_open=True,
                grades=self.grades.set_selected_options(selected_grade),
                confirm_button_label=self.CREATE_GRADE_GROUP,
            )
        return attr.evolve(
            self,
            is_open=True,
            affected_grade_group_id=DataStoreViewModel(row_view_model.group_id),  # type: ignore #[SDC MYPY BUG]
            name=row_view_model.name,
            origin_name=DataStoreStrViewModel(row_view_model.name),  # type: ignore #[SDC MYPY BUG]
            comment=row_view_model.comment,
            grades=self.grades.set_selected_options(row_view_model.grade_ids),
            confirm_button_label=self.UPDATE_GRADE_GROUP,
        )

    def close_modal(self, _: int) -> "GradeGroupModalViewModel":
        return self.reset_to_initial_state(False)

    def get_grade_group_or_raise(self) -> GradeGroup:
        if self.affected_grade_group_id.data == -1:
            raise Exception("Invalid state - no setup scrap group id.")
        return GradeGroup.objects.get(id=self.affected_grade_group_id.data)

    def update_group(self) -> None:
        grade_group = self.get_grade_group_or_raise()
        grade_group.group_name = self.name
        grade_group.comment = self.comment
        grade_group.grade_ids.set(
            GradeDefinition.objects.get_or_create(grade_id=gid)[0]
            for gid in self.grades.selected_values_or_raise
        )
        grade_group.save()

    def create_group(self) -> None:
        grade_group = GradeGroup(group_name=self.name, comment=self.comment)
        grade_group.save()
        grade_group.grade_ids.set(
            GradeDefinition.objects.get_or_create(grade_id=gid)[0]
            for gid in self.grades.selected_values_or_raise
        )

    def confirm_event(self, _: int) -> "GradeGroupModalViewModel":
        if self.update:
            self.update_group()
        else:
            self.create_group()
        return self.reset_to_initial_state(True)

    def reset_to_initial_state(self, data_changed: bool) -> "GradeGroupModalViewModel":
        last_change = time.time_ns() if data_changed else self.last_change.data
        return GradeGroupModalViewModel(last_change=DataStoreViewModel(last_change))  # type: ignore

    def are_inputs_invalid(self, ctx: SettingsAppFiltersSource) -> bool:
        return not (self.grades.has_selected_options and not self.name_validation(ctx))

    def name_validation(self, ctx: SettingsAppFiltersSource) -> str:
        all_existing_names = ctx.grade_groups_source.all_existing_names
        if self.update:
            all_existing_names = tuple(name for name in all_existing_names if name != self.origin_name.data)
        if not self.name:
            return self.NAME_MUST_BE_FILLED
        if self.name in all_existing_names:
            return self.GRADE_GROUP_NAME_ALREADY_EXISTS.format(self.name)
        return ""
