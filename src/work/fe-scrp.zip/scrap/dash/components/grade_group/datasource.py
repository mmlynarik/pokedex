from functools import lru_cache
from typing import Protocol, Sequence

from scrap.dash.components import get_grade_groups_str
from scrap.dash.components.grade_group import GradeGroupTableRowViewModel
from scrap.models import GradeGroup


@lru_cache(maxsize=32)
def get_all_grade_groups(
    timestamp: int,  # pylint: disable=unused-argument
) -> Sequence[GradeGroupTableRowViewModel]:
    grade_groups = GradeGroup.objects.all()
    return [
        GradeGroupTableRowViewModel(
            group_id=grade_group.id,
            name=grade_group.group_name,
            comment=grade_group.comment,
            grade_ids=grade_group.to_tuple(),
            grade_ids_str=get_grade_groups_str(grade_group.to_tuple()),
        )
        for grade_group in grade_groups
    ]


class GradeGroupTableDataSource(Protocol):
    def get_grade_groups(self) -> Sequence[GradeGroupTableRowViewModel]: ...

    @property
    def all_existing_names(self) -> Sequence[str]: ...


class CachedDbGradeGroupTableDataSource:
    def __init__(self, timestamp: int) -> None:
        self.timestamp = timestamp

    def get_grade_groups(self) -> Sequence[GradeGroupTableRowViewModel]:
        return get_all_grade_groups(self.timestamp)

    @property
    def all_existing_names(self) -> Sequence[str]:
        return tuple(group.name for group in self.get_grade_groups())


@lru_cache(maxsize=32)
def get_data_source(timestamp: int) -> GradeGroupTableDataSource:
    return CachedDbGradeGroupTableDataSource(timestamp)
