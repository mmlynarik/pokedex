import attr
from dash import dcc, html
import ussksdc as sdc
from scrap.dash.components.common import ScrapPurchaseAppSource
from django.urls import reverse

from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig


@attr.s(frozen=True, slots=True)
class PurchaseInputDataButtonViewModel:
    COMPONENT_ID = "button"

    BUTTON = "Vstupné dáta"

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputField(cls.COMPONENT_ID, "href", cls.update_input_data_link),)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig) -> html.Div:
        return html.Div(
            children=dcc.Link(
                cls.BUTTON,
                id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                href="#",
                target="_blank",
                className="btn btn-outline-info btn-sm",
            ),
            hidden=config.read_only,
            className="text-center",
        )

    def update_input_data_link(self, ctx: ScrapPurchaseAppSource) -> str:
        return reverse(
            "scrap:update_scrap_purchase",
            kwargs={"scrap_purchase_record_id": ctx.scrap_purchase_id},
        )
