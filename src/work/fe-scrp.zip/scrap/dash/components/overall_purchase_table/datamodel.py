import attr
from scrap_core import ScrapType


@attr.s(frozen=True, auto_attribs=True)
class OverallPurchaseTableDataViewModel:
    scrap_type: ScrapType
    quantity: float
    price: float
