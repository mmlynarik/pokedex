from typing import Dict, Tuple
import numpy

from scrap.dash.components.overall_purchase_table.datamodel import OverallPurchaseTableDataViewModel
from scrap.models import RealizedScrapOfferData


def compute_overall_purchase_table(
    realized_scrap_offer_data: RealizedScrapOfferData,
) -> Tuple[OverallPurchaseTableDataViewModel]:
    if not realized_scrap_offer_data:
        return ()

    price_key = "price"
    weight_key = "weight"

    computation_data: Dict = dict()
    for realized_scrap_offer in realized_scrap_offer_data:
        scrap_type = realized_scrap_offer.scrap_type
        if scrap_type not in computation_data:
            computation_data[scrap_type] = {
                price_key: list(),
                weight_key: list(),
            }
        computation_data[scrap_type][price_key].append(realized_scrap_offer.price)
        computation_data[scrap_type][weight_key].append(realized_scrap_offer.weight)

    result_data = []
    overall_weight = list()
    overall_price = list()
    for key, value in computation_data.items():
        overall_weight.extend(value[weight_key])
        overall_price.extend(value[price_key])

        result_data.append(
            OverallPurchaseTableDataViewModel(
                scrap_type=key,
                quantity=sum(value[weight_key]),
                price=numpy.average(value[price_key], weights=value[weight_key]),
            )
        )

    result_data.append(
        OverallPurchaseTableDataViewModel(
            scrap_type="Celkovo",
            quantity=sum(overall_weight),
            price=numpy.average(overall_price, weights=overall_weight),
        )
    )

    return tuple(result_data)
