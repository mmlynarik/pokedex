from typing import Dict, Tuple
import attr
from dash import html, dash_table
from dash.dash_table.Format import Format, Scheme
import ussksdc as sdc
from scrap.dash.components.overall_purchase_table.computations import compute_overall_purchase_table
from scrap.dash.components.common import ScrapPurchaseAppSource


@attr.s(frozen=True, slots=True)
class OveralScrapPurchaseTableViewModel:
    COMPONENT_ID = "table"

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (sdc.OutputField(cls.COMPONENT_ID, "data", cls.get_table_data),)

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                html.H4("Celkovo nakúpené"),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    data=[],
                    columns=[
                        {"name": "Typ šrotu", "id": "scrap_type", "type": "text", "editable": False},
                        {
                            "name": "Celkovo",
                            "id": "quantity",
                            "type": "numeric",
                            "editable": False,
                            "format": Format(
                                scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"
                            ),
                        },
                        {
                            "name": "Cena - vážený priemer",
                            "id": "price",
                            "type": "numeric",
                            "editable": False,
                            "format": Format(
                                scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"
                            ),
                        },
                    ],
                ),
            ],
            className="purchased-wrapper",
        )

    def get_table_data(self, ctx: ScrapPurchaseAppSource) -> Tuple[Dict, ...]:
        return tuple(
            attr.asdict(row)
            for row in compute_overall_purchase_table(
                ctx.db_purchase_data_source.get_realized_scrap_offer_data()
            )
        )
