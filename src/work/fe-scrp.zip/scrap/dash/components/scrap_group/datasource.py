from functools import lru_cache
from typing import Protocol, Sequence

from scrap.dash.components import get_scrap_groups_str
from scrap.dash.components.scrap_group import ScrapGroupTableRowViewModel
from scrap.models import ScrapGroup


@lru_cache(maxsize=32)
def get_all_scrap_groups(
    timestamp: int,  # pylint: disable=unused-argument
) -> Sequence[ScrapGroupTableRowViewModel]:
    scrap_groups = ScrapGroup.objects.all()
    return [
        ScrapGroupTableRowViewModel(
            group_id=scrap_group.id,
            name=scrap_group.group_name,
            comment=scrap_group.comment,
            scrap_types=get_scrap_groups_str(scrap_group),
        )
        for scrap_group in scrap_groups
    ]


class ScrapGroupTableDataSource(Protocol):
    def get_scrap_groups(self) -> Sequence[ScrapGroupTableRowViewModel]: ...

    @property
    def all_existing_names(self) -> Sequence[str]: ...


class CachedDbScrapGroupTableDataSource:
    def __init__(self, timestamp: int) -> None:
        self.timestamp = timestamp

    def get_scrap_groups(self) -> Sequence[ScrapGroupTableRowViewModel]:
        return get_all_scrap_groups(self.timestamp)

    @property
    def all_existing_names(self) -> Sequence[str]:
        return tuple(group.name for group in self.get_scrap_groups())


@lru_cache(maxsize=32)
def get_data_source(timestamp: int) -> ScrapGroupTableDataSource:
    return CachedDbScrapGroupTableDataSource(timestamp)
