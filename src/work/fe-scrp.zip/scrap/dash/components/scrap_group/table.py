import time
from typing import Any, Dict, List, Sequence, Union

import attr
import ussksdc as sdc
from dash import html
from dash.dash_table import DataTable
from scrap.dash.components.modals.delete_confirm import DeleteScrapGroupConfirmModalViewModel
from scrap.dash.components.scrap_group import ScrapGroupTableRowViewModel
from scrap.dash.components.scrap_group.datasource import ScrapGroupTableDataSource, get_data_source
from scrap.dash.components.scrap_group.modal import ScrapGroupModalViewModel
from scrap.dash.components.table_common import table_wrapper_with_header
from scrap.models import ScrapGroup
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class ScrapGroupTableViewModel:
    # Initial setup
    TOOLTIP_CHARACTER_THRESHOLD = 18
    HIDDEN_ON_LOAD = False
    # Components ID
    COMPONENT_ID = "table"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    TABLE_WRAPPER_ID = "dash-table-wrapper"
    ADD_NEW_GROUP_ID = "add-new-group"
    HEADER_MSG_ID = "message"
    DELETE_COLUMN_ID = "delete"
    EDIT_COLUMN_ID = "edit"
    SCRAP_TYPES_COLUMN_ID = "scrap_types"
    # User friendly msg
    NAME = "Skupina šrotov"
    ADD = "Pridať skupinu"
    DELETE = "Odstrániť skupinu"

    data_load_time: int = attr.ib(factory=time.time_ns, converter=int)
    modal: ScrapGroupModalViewModel = sdc.child_component(
        "scrap-group-modal", factory=ScrapGroupModalViewModel
    )
    delete_confirm_modal: DeleteScrapGroupConfirmModalViewModel = sdc.child_component(
        "confirm-delete", default=DeleteScrapGroupConfirmModalViewModel()
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.ADD_NEW_GROUP_ID, "n_clicks", ScrapGroupTableViewModel.open_modal),
            sdc.InputField(
                cls.COMPONENT_ID, "active_cell", ScrapGroupTableViewModel.control_active_table_cell
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", ScrapGroupTableViewModel.to_table_data),
            sdc.OutputField(cls.COMPONENT_ID, "tooltip_data", ScrapGroupTableViewModel.to_tooltip_data),
            sdc.OutputField(
                cls.COMPONENT_ID, "active_cell", lambda _: None
            ),  # Reset active cell makes it possible to click on cell more then once
        )

    @classmethod
    def get_scrap_group_table(cls, table_id: str, dash_table_wrapper_id: str) -> html.Div:
        return html.Div(
            DataTable(
                columns=[
                    {"name": "", "id": cls.EDIT_COLUMN_ID, "type": "text"},
                    {"name": "Názov skupiny", "id": "name", "type": "text"},
                    {"name": "Typy šrotov", "id": cls.SCRAP_TYPES_COLUMN_ID, "type": "text"},
                    {"name": "Komentár", "id": "comment", "type": "text"},
                    {"name": "", "id": cls.DELETE_COLUMN_ID, "type": "text"},
                ],
                data=[],
                editable=False,
                fill_width=True,
                id=table_id,
                tooltip_delay=0,
                tooltip_duration=None,
            ),
            id=dash_table_wrapper_id,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return table_wrapper_with_header(
            cls.get_scrap_group_table(
                sdc.create_id(parent_id, cls.COMPONENT_ID), sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID)
            ),
            cls.NAME,
            cls.ADD,
            sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
            sdc.create_id(parent_id, cls.HEADER_MSG_ID),
            sdc.create_id(parent_id, cls.ADD_NEW_GROUP_ID),
            cls.HIDDEN_ON_LOAD,
            [
                sdc.get_child_layout(parent_id, cls.modal),
                sdc.get_child_layout(parent_id, cls.delete_confirm_modal),
            ],
        )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time,
            self.modal.last_change.data,
            self.delete_confirm_modal.last_change.data,
        )

    @property
    def data_source(self) -> ScrapGroupTableDataSource:
        return get_data_source(self.last_change)

    @property
    def rows(self) -> Sequence[ScrapGroupTableRowViewModel]:
        return self.data_source.get_scrap_groups()

    def open_modal(self, _: int) -> "ScrapGroupTableViewModel":
        return attr.evolve(self, modal=self.modal.set_input_values_and_open())

    def to_table_data(self) -> List[Dict[str, Union[str, float]]]:
        return [row.dash_table_row for row in self.rows]

    def to_tooltip_data(self) -> List[Dict[str, str]]:
        return [
            {
                self.SCRAP_TYPES_COLUMN_ID: (
                    row.scrap_types if len(row.scrap_types) > self.TOOLTIP_CHARACTER_THRESHOLD else ""
                )
            }
            for row in self.rows
        ]

    def __open_delete_confirm_modal(
        self, row_view_model: ScrapGroupTableRowViewModel
    ) -> "ScrapGroupTableViewModel":
        scrap_group = ScrapGroup.objects.get(id=row_view_model.group_id)
        foreign_key_list = scrap_group.all_uses
        if not foreign_key_list:
            is_action_impossible = False
            msg = f"Pozor snažíte sa vymazať skupinu šrotov s názvom {row_view_model.name}! Naozaj chcete túto skupinu odstrániť?"
        else:
            is_action_impossible = True
            foreign_key_str = ", ".join([limit.name for limit in foreign_key_list])  # type: ignore
            msg = f"Skupinu šrotov {row_view_model.name} nie je možné zmazať z dôvodu využitia v limite {foreign_key_str}"
        return attr.evolve(
            self,
            delete_confirm_modal=DeleteScrapGroupConfirmModalViewModel(  # type: ignore #[SDC MYPY BUG]
                affected_id=DataStoreViewModel(row_view_model.group_id),  # type: ignore #[SDC MYPY BUG]
                is_action_impossible=is_action_impossible,
                message=msg,
                is_open=True,
            ),
        )

    def control_active_table_cell(self, active_cell: Dict[str, Any]) -> "ScrapGroupTableViewModel":
        if active_cell is None:
            return self
        row_view_model = self.rows[active_cell["row"]]
        active_cell_id = active_cell["column_id"]
        if active_cell_id == self.DELETE_COLUMN_ID:
            return self.__open_delete_confirm_modal(row_view_model)
        if active_cell_id == self.EDIT_COLUMN_ID:
            return attr.evolve(self, modal=self.modal.set_input_values_and_open(row_view_model))
        return self
