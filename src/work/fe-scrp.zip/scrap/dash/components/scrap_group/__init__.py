from typing import Collection, Dict, Union

import attr


@attr.s(frozen=True, auto_attribs=True, slots=True)
class ScrapGroupTableRowViewModel:
    group_id: int
    name: str
    comment: str = ""
    scrap_types: str = ""
    edit: str = "📝"
    delete: str = "❌"

    @property
    def dash_table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)  # type: ignore
        # TODO remove type ignore with new mypy version

    @property
    def scrap_types_collection(self) -> Collection[str]:
        return self.scrap_types.split(", ")
