import time
from typing import Optional

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.modals import create_input_wrapper, create_modal_footer, create_modal_header
from scrap.dash.components.scrap_group import ScrapGroupTableRowViewModel
from scrap.dash.components.selectors import ScrapMultipleSelectorViewModel
from scrap.models import ScrapGroup
from ussksdc.components.data_store import DataStoreStrViewModel, DataStoreViewModel


@attr.s(frozen=True, slots=True)
class ScrapGroupModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    COMPONENT_ID = "modal"
    NAME_ID = "name"
    CLOSE_BUTTON_ID = "close"
    COMMENT_ID = "comment"
    CONFIRM_BUTTON_ID = "update"
    NAME_VALIDATION_MSG_ID = "name-validation"
    # User friendly msg
    NEW_SCRAP_GROUP = "Nová skupina šrotov"
    CREATE_SCRAP_GROUP = "Vytvoriť skupinu šrotov"
    UPDATE_SCRAP_GROUP = "Aktualizovať skupinu šrotov"
    NAME_MUST_BE_FILLED = "Názov skupiny musí byť vyplnený"
    SCRAP_GROUP_NAME_ALREADY_EXISTS = "Skupina šrotov s názvom {} už existuje."
    COMMENT = "Komentár"
    CHOOSE_SCRAPS = "Vyber akosti"

    affected_scrap_group_id: DataStoreViewModel = sdc.child_component(
        "affected-scrap-group-data-store", default=DataStoreViewModel()
    )
    last_change: DataStoreViewModel = sdc.child_component(
        "last-change-data-store", default=DataStoreViewModel(0)  # type: ignore #[SDC MYPY BUG]
    )
    origin_name: DataStoreStrViewModel = sdc.child_component(
        "origin-scrap-name-data-store", default=DataStoreStrViewModel()
    )
    scraps: ScrapMultipleSelectorViewModel = sdc.child_component(
        "scraps", default=ScrapMultipleSelectorViewModel()
    )
    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    confirm_button_label: str = sdc.one_way_binding(
        CONFIRM_BUTTON_ID, "children", default="Vytvoriť novu skupinu šrotov"
    )
    name: str = sdc.two_way_binding(NAME_ID, "value", default=NEW_SCRAP_GROUP)
    comment: str = sdc.two_way_binding(COMMENT_ID, "value", default="")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", ScrapGroupModalViewModel.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", ScrapGroupModalViewModel.confirm_event),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.CONFIRM_BUTTON_ID, "disabled", ScrapGroupModalViewModel.are_inputs_invalid),
            sdc.OutputField(cls.NAME_VALIDATION_MSG_ID, "children", ScrapGroupModalViewModel.name_validation),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            backdrop="static",
            children=[
                create_modal_header(
                    sdc.create_id(parent_id, cls.NAME_ID),
                    sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID),
                    sdc.create_id(parent_id, cls.NAME_VALIDATION_MSG_ID),
                ),
                dbc.ModalBody(
                    children=[
                        create_input_wrapper(
                            cls.CHOOSE_SCRAPS,
                            [
                                sdc.get_child_layout(parent_id, cls.scraps),
                            ],
                        ),
                        create_input_wrapper(
                            cls.COMMENT,
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.COMMENT_ID), debounce=True),
                            ],
                        ),
                        sdc.get_child_layout(parent_id, cls.affected_scrap_group_id),
                        sdc.get_child_layout(parent_id, cls.origin_name),
                        sdc.get_child_layout(parent_id, cls.last_change),
                    ]
                ),
                create_modal_footer(sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), ""),
            ],
            centered=True,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            keyboard=False,
        )

    @property
    def update(self) -> bool:
        return self.affected_scrap_group_id.data != -1

    def set_input_values_and_open(
        self, row_view_model: Optional[ScrapGroupTableRowViewModel] = None
    ) -> "ScrapGroupModalViewModel":
        if row_view_model is None:
            return ScrapGroupModalViewModel(is_open=True, confirm_button_label=self.CREATE_SCRAP_GROUP)  # type: ignore #[SDC MYPY BUG]
        return ScrapGroupModalViewModel(
            is_open=True,
            affected_scrap_group_id=DataStoreViewModel(row_view_model.group_id),  # type: ignore #[SDC MYPY BUG]
            name=row_view_model.name,
            origin_name=DataStoreStrViewModel(row_view_model.name),  # type: ignore #[SDC MYPY BUG]
            comment=row_view_model.comment,
            scraps=self.scraps.set_selected_options(row_view_model.scrap_types_collection),
            confirm_button_label=self.UPDATE_SCRAP_GROUP,
        )

    def close_modal(self, _: int) -> "ScrapGroupModalViewModel":
        return self.reset_to_initial_state(False)

    def get_scrap_group_or_raise(self) -> ScrapGroup:
        if self.affected_scrap_group_id.data == -1:
            raise Exception("Invalid state - no setup scrap group id.")
        return ScrapGroup.objects.get(id=self.affected_scrap_group_id.data)

    def update_group(self) -> None:
        scrap_group = self.get_scrap_group_or_raise()
        scrap_group.group_name = self.name
        scrap_group.comment = self.comment
        scrap_group.scrap_ids.set(self.scraps.selected_values_or_raise)
        scrap_group.save()

    def create_group(self) -> None:
        scrap_group = ScrapGroup(group_name=self.name, comment=self.comment)
        scrap_group.save()
        scrap_group.scrap_ids.set(self.scraps.selected_values)

    def confirm_event(self, _: int) -> "ScrapGroupModalViewModel":
        if self.update:
            self.update_group()
        else:
            self.create_group()
        return self.reset_to_initial_state(True)

    def reset_to_initial_state(self, data_changed: bool) -> "ScrapGroupModalViewModel":
        last_change = time.time_ns() if data_changed else self.last_change.data
        # TODO [SDC MYPY BUG]
        return ScrapGroupModalViewModel(last_change=DataStoreViewModel(last_change))  # type: ignore

    def are_inputs_invalid(self, ctx: SettingsAppFiltersSource) -> bool:
        return not (self.scraps.has_selected_options and not self.name_validation(ctx))

    def name_validation(self, ctx: SettingsAppFiltersSource) -> str:
        all_existing_names = ctx.scrap_groups_source.all_existing_names
        if self.update:
            all_existing_names = tuple(name for name in all_existing_names if name != self.origin_name.data)
        if not self.name:
            return self.NAME_MUST_BE_FILLED
        if self.name in all_existing_names:
            return self.SCRAP_GROUP_NAME_ALREADY_EXISTS.format(self.name)
        return ""
