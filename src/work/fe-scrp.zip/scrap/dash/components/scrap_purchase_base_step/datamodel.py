from typing import Dict
from django.contrib.auth.models import User
import attr


@attr.frozen
class TransferListData:
    label: str = attr.ib(default="", converter=str)
    value: str = attr.ib(default="", converter=str)

    @classmethod
    def create(cls, user: User) -> "TransferListData":
        return cls(label=user.username, value=user.id)

    @property
    def user_id(self) -> int:
        return int(self.value)

    @property
    def as_dict(self) -> Dict[str, str]:
        return attr.asdict(self)
