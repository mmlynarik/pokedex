from typing import Tuple, List, Dict, Collection

import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from django.contrib.auth.models import User
from dash import html

from scrap.dash.components.scrap_purchase_base_step.datamodel import TransferListData

from ussksdc.core.helper import generate_clientside_callback
from ussksdc.core.datamodel import JsCode
from scrap.models import converter


@attr.frozen
class AuthorizedUsersVM:
    # Components ids
    TRANSFER_LIST_ID = "transfer-list"
    TRANSFER_LIST_WRAPPER_ID = "transfer-list-wrapper"
    # User friendly msg
    TITLE = "Autorizovaný používatelia"
    SEARCH_PLACEHOLDER = "Vyhľadajte používateľa"
    NOTHING_FOUND = "Pre zadané meno sa nenašiel žiaden používateľ"
    PLACEHOLDERS = [
        "Všetci používatelia sú autorizovaní",
        "Žiaden používateľ nie je autorizovaný",
    ]
    # Props
    DEFAULT_TRANSFER_LIST = [[], []]

    list_items: List[List[Dict[str, str]]] = sdc.binding(
        TRANSFER_LIST_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=DEFAULT_TRANSFER_LIST,
    )

    @classmethod
    def create(cls, all_users: Tuple[User, ...], authorized_users: Collection[User]) -> "AuthorizedUsersVM":
        authorized = [TransferListData.create(user).as_dict for user in authorized_users]
        unauthorized = [
            TransferListData.create(user).as_dict for user in set(all_users) - set(authorized_users)
        ]
        return cls(list_items=[unauthorized, authorized])

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                dmc.Text(cls.TITLE),
                dmc.TransferList(
                    id=sdc.create_id(parent_id, cls.TRANSFER_LIST_ID),
                    value=cls.DEFAULT_TRANSFER_LIST,
                    transferAllMatchingFilter=True,
                    searchPlaceholder=cls.SEARCH_PLACEHOLDER,
                    nothingFound=cls.NOTHING_FOUND,
                    placeholder=cls.PLACEHOLDERS,
                ),
            ],
            id=sdc.create_id(parent_id, cls.TRANSFER_LIST_WRAPPER_ID),
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.has_authorized_users()),)

    @classmethod
    def has_authorized_users(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "hasAuthorizedUsers",
            [],
            "return (this.list_items[1].length != 0);",
        )

    @property
    def authorized_user_ids(self) -> Tuple[int, ...]:
        structured_list_items = tuple(converter.structure(li, TransferListData) for li in self.list_items[1])
        return tuple(li.user_id for li in structured_list_items)
