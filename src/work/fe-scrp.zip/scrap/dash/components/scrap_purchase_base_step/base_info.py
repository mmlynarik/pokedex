from datetime import date, datetime
from typing import Optional, Tuple, Collection

from string import Template
import attr
import dash_mantine_components as dmc
import ussksdc as sdc
from dash import html
from ussksdc.core.datamodel import JsCode
from ussksdc.core.helper import generate_clientside_callback
from django.contrib.auth.models import User

from scrap.dash.components.scrap_purchase_base_step.authorized_users import AuthorizedUsersVM


@attr.frozen
class PurchaseNameAndDateVM:
    COMPONENT_ID = "base-info"
    NAME_INPUT_ID = "name"
    DATE_INPUT_ID = "date"
    TRANSFER_LIST_ID = "transfer-list"

    DATE_FORMAT = "MMMM DD, YYYY"

    DATE_LABEL = "Dátum nákupu"
    DATE_DESC = "Dátum, reprezentujúci deň vytvorenia nákupu"
    NAME_LABEL = "Názov"
    NAME_DESC = "Názov, reprezentujúci vstupné data"

    COMPONENT_DATETIME_FORMAT = "%Y-%m-%d"
    NAME_DATETIME_TEMPLATE = "%B %Y"

    name: str = sdc.binding(
        NAME_INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default="",
    )
    purchase_date_str: Optional[str] = sdc.binding(
        DATE_INPUT_ID,
        "value",
        ss_read=False,
        ss_state=True,
        ss_write=True,
        cs_read=True,
        cs_state=True,
        cs_write=False,
        default=None,
    )
    auth_users: AuthorizedUsersVM = sdc.child_component("auth-users", factory=AuthorizedUsersVM)

    @classmethod
    def create(
        cls,
        all_users: Tuple[User, ...],
        authorized_users: Collection[User],
        for_date: date,
        name: Optional[str] = None,
    ) -> "PurchaseNameAndDateVM":
        return cls(
            name=name if name is not None else for_date.strftime(cls.NAME_DATETIME_TEMPLATE),
            purchase_date_str=for_date.strftime(cls.COMPONENT_DATETIME_FORMAT),
            auth_users=AuthorizedUsersVM.create(all_users, authorized_users),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dmc.Group:
        return html.Div(
            [
                dmc.Group(
                    children=[
                        dmc.TextInput(
                            value="",
                            id=sdc.create_id(parent_id, cls.NAME_INPUT_ID),
                            label=cls.NAME_LABEL,
                            description=cls.NAME_DESC,
                            debounce=700,
                        ),
                        dmc.DatePicker(
                            id=sdc.create_id(parent_id, cls.DATE_INPUT_ID),
                            label=cls.DATE_LABEL,
                            description=cls.DATE_DESC,
                            inputFormat=cls.DATE_FORMAT,
                        ),
                    ],
                    grow=True,
                    position="center",
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                ),
                sdc.get_child_layout(parent_id, cls.auth_users),
            ]
        )

    @classmethod
    def get_js_code_fields(cls) -> sdc.JsCodeFields:
        return (sdc.JsCodeField(*cls.mising_fields()),)

    @classmethod
    def mising_fields(cls) -> Tuple[JsCode, str]:
        return generate_clientside_callback(
            "getMissingFields",
            [],
            Template(
                """
            var missingFields = [];
            if (!this.name)
                missingFields.push('${name}');
            if (!this.purchase_date_str)
                missingFields.push('${purchase_date}');
            if (!this.auth_users.hasAuthorizedUsers())
                missingFields.push('${auth_user}');
            return missingFields;
            """
            ).substitute(
                name=cls.NAME_LABEL, purchase_date=cls.DATE_LABEL, auth_user=AuthorizedUsersVM.TITLE
            ),
        )

    @property
    def purchase_date(self) -> date:
        return datetime.strptime(self.purchase_date_str, self.COMPONENT_DATETIME_FORMAT).date()
