from functools import lru_cache
from typing import Optional, Protocol, Sequence

from django.db.models import Q
from scrap.dash.components.risk_limit import RiskLimitsSettingsTableRowViewModel
from scrap.models import RelaxableRiskLimitSetting
from scrap.dash.components.one_heat_optimizer_v2 import get_relaxable_risk_limit_for_grade


class RiskLimitsTableDataSource(Protocol):
    def get_risk_limits(
        self, loading_station_id: Optional[int], grade_id: Optional[int], grade_group_id: Optional[int]
    ) -> Sequence[RiskLimitsSettingsTableRowViewModel]: ...


@lru_cache(maxsize=128)
def get_risk_limits(
    loading_station_id: Optional[int],
    grade_id: Optional[int],
    grade_group_id: Optional[int],
    timestamp: int,  # pylint: disable=unused-argument
) -> Sequence[RiskLimitsSettingsTableRowViewModel]:
    if grade_id is not None and loading_station_id is not None:
        filter_condition = Q(grade_ids__grade_ids__grade_id__exact=grade_id) | Q(grade_ids__grade_ids=None)
    elif grade_group_id is not None and loading_station_id is not None:
        filter_condition = Q(grade_ids__id=grade_group_id) | Q(grade_ids__grade_ids=None)
    else:
        return []

    risk_limits = set(
        RelaxableRiskLimitSetting.objects.select_related("grade_ids")
        .prefetch_related("loadingstation_set", "grade_ids__grade_ids")
        .filter(loadingstation__pk=loading_station_id)
        .filter(filter_condition)
    )

    limit_setting_rows = [
        RiskLimitsSettingsTableRowViewModel(
            affected_loading_stations_ids=limit.affected_loading_stations_ids,
            limit_id=limit.pk,
            name=limit.name,
            comment=limit.comment,
            grade_group_name=limit.grade_ids.group_name,
            grade_group_id=limit.grade_ids.id,
            grade_ids=limit.grade_ids.to_tuple(),
            cr_aim=limit.Cr_aim,
            cr_allowed=limit.Cr_allowed,
            cu_aim=limit.Cu_aim,
            cu_allowed=limit.Cu_allowed,
            mo_aim=limit.Mo_aim,
            mo_allowed=limit.Mo_allowed,
            ni_aim=limit.Ni_aim,
            ni_allowed=limit.Ni_allowed,
            s_aim=limit.S_aim,
            s_allowed=limit.S_allowed,
            sn_aim=limit.Sn_aim,
            sn_allowed=limit.Sn_allowed,
            is_limit_relevant=int(
                grade_id is None
            ),  # if grade id is not set, we can't tell which limit to use
        )
        for limit in risk_limits
    ]

    if grade_id is not None:
        resolved_limit = get_relaxable_risk_limit_for_grade(grade_id, risk_limits)
        # TODO this is a temporary solution that may not be fully compatible with settings screen
        #   see https://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/482
        resolved_row = RiskLimitsSettingsTableRowViewModel(
            affected_loading_stations_ids=(),
            grade_ids=(),
            limit_id=-1,
            name="[C] Odvodené nastavenie rizika",
            grade_group_id=-1,
            grade_group_name=str(grade_id),
            comment="Odvodené nastavenie",
            cr_aim=resolved_limit.Cr.aim,
            cr_allowed=resolved_limit.Cr.allowed,
            cu_aim=resolved_limit.Cu.aim,
            cu_allowed=resolved_limit.Cu.allowed,
            mo_aim=resolved_limit.Mo.aim,
            mo_allowed=resolved_limit.Mo.allowed,
            ni_aim=resolved_limit.Ni.aim,
            ni_allowed=resolved_limit.Ni.allowed,
            s_aim=resolved_limit.S.aim,
            s_allowed=resolved_limit.S.allowed,
            sn_aim=resolved_limit.Sn.aim,
            sn_allowed=resolved_limit.Sn.allowed,
            is_limit_relevant=1,
        )

        limit_setting_rows.append(resolved_row)

    return limit_setting_rows


class CachedDbRiskLimitsTableDataSource:
    def __init__(self, timestamp: int):
        self.timestamp = timestamp

    def get_risk_limits(
        self, loading_station_id: Optional[int], grade_id: Optional[int], grade_group_id: Optional[int]
    ) -> Sequence[RiskLimitsSettingsTableRowViewModel]:
        return get_risk_limits(loading_station_id, grade_id, grade_group_id, self.timestamp)


@lru_cache(maxsize=16)
def get_data_source(timestamp: int) -> RiskLimitsTableDataSource:
    return CachedDbRiskLimitsTableDataSource(timestamp)
