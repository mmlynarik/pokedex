import time
from typing import Any, Dict, List, Sequence, Union

import attr
from dash import html
from dash.dash_table import DataTable
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.modals.delete_confirm import DeleteRiskLimitConfirmModalViewModel
from scrap.dash.components.risk_limit import RiskLimitsSettingsTableRowViewModel
from scrap.dash.components.risk_limit.datasource import get_data_source
from scrap.dash.components.risk_limit.modal import RiskLimitModalViewModel
from scrap.dash.components.table_common import table_wrapper_with_header

import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class RiskLimitsSettingsTableViewModel:
    # Initial property
    HIDDEN_ON_LOAD = True
    # Component ids
    COMPONENT_ID = "table"
    COMPONENT_WRAPPER_ID = "table-wrapper"
    TABLE_WRAPPER_ID = "dash-table-wrapper"
    EDIT_COLUMN_ID = "edit"
    DELETE_COLUMN_ID = "delete"
    ADD_NEW_LIMIT_ID = "add-limit"
    GRADE_GROUP_COLUMN_ID = "grade_group_name"
    RELEVANT_LIMIT_COLUMN_ID = "is_limit_relevant"
    HEADER_MSG_ID = "message"
    # User friendly msg
    NAME = "Riziko nežiadúcej opravnej technológie"
    ADD = "Pridať limit"
    DELETE = "Odstrániť limnit"
    UPDATE = "Upraviť limnit"
    MISSING_DATA = "V databáze neboli nájdené žiadné dáta."

    data_load_time: int = attr.ib(factory=time.time_ns, converter=int)

    modal: RiskLimitModalViewModel = sdc.child_component(
        "risk-limit-modal", default=RiskLimitModalViewModel()
    )
    delete_confirm_modal: DeleteRiskLimitConfirmModalViewModel = sdc.child_component(
        "confirm-delete", default=DeleteRiskLimitConfirmModalViewModel()
    )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(
                cls.COMPONENT_ID, "active_cell", RiskLimitsSettingsTableViewModel.control_active_cell
            ),
            sdc.InputField(cls.ADD_NEW_LIMIT_ID, "n_clicks", RiskLimitsSettingsTableViewModel.open_modal),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", RiskLimitsSettingsTableViewModel.to_table_data),
            sdc.OutputField(
                cls.COMPONENT_ID, "tooltip_data", RiskLimitsSettingsTableViewModel.to_tooltip_data
            ),
            sdc.OutputField(cls.COMPONENT_WRAPPER_ID, "hidden", RiskLimitsSettingsTableViewModel.is_hidden),
            sdc.OutputField(cls.HEADER_MSG_ID, "children", RiskLimitsSettingsTableViewModel.get_table_msg),
            sdc.OutputField(cls.TABLE_WRAPPER_ID, "hidden", RiskLimitsSettingsTableViewModel.is_table_empty),
            sdc.OutputField(
                cls.COMPONENT_ID, "active_cell", lambda _: None
            ),  # Reset active cell makes it possible to click on cell more then once
        )

    @classmethod
    def get_risk_limit_table(cls, table_id: str, dash_table_wrapper_id: str) -> html.Div:
        return html.Div(
            DataTable(
                columns=[
                    {"name": ["Názov", ""], "id": cls.EDIT_COLUMN_ID, "type": "text"},
                    {"name": ["Názov", ""], "id": "name", "type": "text"},
                    {"name": ["Skupina akostí", ""], "id": cls.GRADE_GROUP_COLUMN_ID, "type": "text"},
                    {"name": ["Cr", "Cieľ"], "id": "cr_aim", "type": "numeric"},
                    {"name": ["Cr", "Max"], "id": "cr_allowed", "type": "numeric"},
                    {"name": ["Cu", "Cieľ"], "id": "cu_aim", "type": "numeric"},
                    {"name": ["Cu", "Max"], "id": "cu_allowed", "type": "numeric"},
                    {"name": ["Mo", "Cieľ"], "id": "mo_aim", "type": "numeric"},
                    {"name": ["Mo", "Max"], "id": "mo_allowed", "type": "numeric"},
                    {"name": ["Ni", "Cieľ"], "id": "ni_aim", "type": "numeric"},
                    {"name": ["Ni", "Max"], "id": "ni_allowed", "type": "numeric"},
                    {"name": ["S", "Cieľ"], "id": "s_aim", "type": "numeric"},
                    {"name": ["S", "Max"], "id": "s_allowed", "type": "numeric"},
                    {"name": ["Sn", "Cieľ"], "id": "sn_aim", "type": "numeric"},
                    {"name": ["Sn", "Max"], "id": "sn_allowed", "type": "numeric"},
                    {"name": ["Komentár", ""], "id": "comment", "type": "text"},
                    {"name": ["", ""], "id": cls.DELETE_COLUMN_ID, "type": "text"},
                    {
                        "name": ["Relevantný limit", "Relevantný limit"],
                        "id": cls.RELEVANT_LIMIT_COLUMN_ID,
                        "type": "numeric",
                    },
                ],
                data=[],
                fill_width=True,
                id=table_id,
                merge_duplicate_headers=True,
                # TODO http://vdevops/Esten/UssAi/_workitems/edit/388/
                style_data_conditional=[
                    {
                        "if": {"filter_query": "{is_limit_relevant} = 0"},
                        "backgroundColor": "rgb(190,190,190)",
                        "color": "rgb(160, 160, 160)",
                    },
                ],
                tooltip_delay=500,
                tooltip_duration=3000,
            ),
            id=dash_table_wrapper_id,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return table_wrapper_with_header(
            cls.get_risk_limit_table(
                sdc.create_id(parent_id, cls.COMPONENT_ID), sdc.create_id(parent_id, cls.TABLE_WRAPPER_ID)
            ),
            cls.NAME,
            cls.ADD,
            sdc.create_id(parent_id, cls.COMPONENT_WRAPPER_ID),
            sdc.create_id(parent_id, cls.HEADER_MSG_ID),
            sdc.create_id(parent_id, cls.ADD_NEW_LIMIT_ID),
            cls.HIDDEN_ON_LOAD,
            [
                sdc.get_child_layout(parent_id, cls.modal),
                sdc.get_child_layout(parent_id, cls.delete_confirm_modal),
            ],
        )

    @property
    def last_change(self) -> int:
        return max(
            self.data_load_time, self.modal.last_change.data, self.delete_confirm_modal.last_change.data
        )

    def rows(self, ctx: SettingsAppFiltersSource) -> Sequence[RiskLimitsSettingsTableRowViewModel]:
        data = get_data_source(self.last_change).get_risk_limits(
            ctx.selected_loading_station_id, ctx.selected_grade_id, ctx.selected_grade_group_id
        )
        return sorted(data, key=lambda row: (row.grade_ids, row.name))

    def is_hidden(self, ctx: SettingsAppFiltersSource) -> bool:
        return (
            (ctx.selected_loading_station_id is None and ctx.selected_grade_id is None)
            or (ctx.selected_loading_station_id is None and ctx.selected_grade_group_id is None)
            or (ctx.selected_grade_id is None and ctx.selected_grade_group_id is None)
        )

    def to_table_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, Union[str, float]]]:
        return [row.dash_table_row for row in self.rows(ctx)]

    def to_tooltip_data(self, ctx: SettingsAppFiltersSource) -> List[Dict[str, str]]:
        return [
            {
                self.EDIT_COLUMN_ID: self.UPDATE,
                self.DELETE_COLUMN_ID: self.DELETE,
                self.GRADE_GROUP_COLUMN_ID: row.grade_ids_str,
            }
            for row in self.rows(ctx)
        ]

    def control_active_cell(
        self, active_cell: Dict[str, Any], ctx: SettingsAppFiltersSource
    ) -> "RiskLimitsSettingsTableViewModel":
        if active_cell is None:
            return self
        row_view_model = self.rows(ctx)[active_cell["row"]]
        active_cell_id = active_cell["column_id"]
        if active_cell_id == self.EDIT_COLUMN_ID:
            return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx, row_view_model))
        if active_cell_id == self.DELETE_COLUMN_ID:
            return attr.evolve(
                self,
                delete_confirm_modal=DeleteRiskLimitConfirmModalViewModel(
                    is_open=True,
                    is_action_impossible=False,
                    affected_id=DataStoreViewModel(row_view_model.limit_id),  # type: ignore
                    message=f"Pozor snažíte sa vymazať risk limit s názvom {row_view_model.name}! "
                    + "Naozaj chcete tento limit odstrániť?",
                ),
            )
        return self

    def open_modal(self, _: int, ctx: SettingsAppFiltersSource) -> "RiskLimitsSettingsTableViewModel":
        return attr.evolve(self, modal=self.modal.set_input_values_and_open(ctx))

    def get_table_msg(self, ctx: SettingsAppFiltersSource) -> str:
        if not self.rows(ctx):
            return self.MISSING_DATA
        return ""

    def is_table_empty(self, ctx: SettingsAppFiltersSource) -> bool:
        return not self.rows(ctx)
