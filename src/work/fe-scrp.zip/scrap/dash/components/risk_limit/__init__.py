from typing import Collection, Dict, Union

import attr
from scrap.dash.components import get_grade_groups_str


@attr.s(frozen=True, auto_attribs=True, slots=True)
class RiskLimitsSettingsTableRowViewModel:
    limit_id: int
    name: str
    grade_group_id: int
    grade_group_name: str
    # Value of is_limit_relevant is bool type but for table we need int
    is_limit_relevant: int = 1
    affected_loading_stations_ids: Collection[int] = ()
    grade_ids: Collection[int] = ()
    cr_aim: float = 0.01
    cr_allowed: float = 0.01
    cu_aim: float = 0.01
    cu_allowed: float = 0.01
    mo_aim: float = 0.01
    mo_allowed: float = 0.01
    ni_aim: float = 0.01
    ni_allowed: float = 0.01
    s_aim: float = 0.015
    s_allowed: float = 0.015
    sn_aim: float = 0.01
    sn_allowed: float = 0.01
    created_at: str = ""
    created_by: str = ""
    comment: str = ""
    edit: str = "📝"
    delete: str = "❌"

    @property
    def dash_table_row(self) -> Dict[str, Union[str, float]]:
        return attr.asdict(self)  # type: ignore
        # TODO remove type ignore with new mypy version

    @property
    def grade_ids_str(self) -> str:
        return get_grade_groups_str(self.grade_ids)
