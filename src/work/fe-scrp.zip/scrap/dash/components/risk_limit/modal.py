import time
from typing import Optional

import attr
import dash_bootstrap_components as dbc
import ussksdc as sdc
from dash import html
from scrap.dash.components.common import SettingsAppFiltersSource
from scrap.dash.components.grade_group.modal import GradeGroupModalViewModel
from scrap.dash.components.modals import create_input_wrapper, create_modal_footer, create_modal_header
from scrap.dash.components.pair_inputs import ChemInputsViewModel, get_pair_inputs_wrapper
from scrap.dash.components.risk_limit import RiskLimitsSettingsTableRowViewModel
from scrap.dash.components.selectors import (
    GradeGroupSelectorViewModel,
    LoadingStationMultipleSelectorViewModel,
)
from scrap.models import LoadingStation, RelaxableRiskLimitSetting
from ussksdc.components.data_store import DataStoreViewModel


@attr.s(frozen=True, slots=True)
class RiskLimitModalViewModel:
    # Initial setup
    OPEN_ON_LOAD = False
    # Component ids
    COMPONENT_ID = "modal"
    NAME_ID = "name"
    CLOSE_BUTTON_ID = "close"
    COMMENT_ID = "comment"
    CONFIRM_BUTTON_ID = "confirm"
    CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID = "grade-group-modal-open"
    NAME_VALIDATION_MSG_ID = "name-validation"
    # User friendly msg
    NEW_LIMIT = "Nový limit"
    COMMENT = "Komentár"
    CHOOSE_GRADE_GROUP = "Vyber skupinu akostí"
    CHOOSE_LOADING_STATIONS = "Vyber nakladacie stanice"
    NAME_MUST_BE_FILLED = "Názov skupiny musí byť vyplnený"
    CREATE_LIMIT = "Vytvoriť limit"
    UPDATE_LIMIT = "Aktualizovať limit"
    AIM = "Cieľ"
    ALLOWED = "Max-Povolené"

    affected_limit_id: DataStoreViewModel = sdc.child_component(
        "affected-id-data-store", default=DataStoreViewModel()
    )
    last_change: DataStoreViewModel = sdc.child_component(
        "last-change-data-store", default=DataStoreViewModel(0)  # type: ignore #[SDC MYPY BUG]
    )
    grade_groups: GradeGroupSelectorViewModel = sdc.child_component(
        "grade-groups", default=GradeGroupSelectorViewModel()
    )
    loading_stations: LoadingStationMultipleSelectorViewModel = sdc.child_component(
        "loading-stations", default=LoadingStationMultipleSelectorViewModel()
    )
    cr_inputs: ChemInputsViewModel = sdc.child_component("cr", default=ChemInputsViewModel())
    cu_inputs: ChemInputsViewModel = sdc.child_component("cu", default=ChemInputsViewModel())
    mo_inputs: ChemInputsViewModel = sdc.child_component("mo", default=ChemInputsViewModel())
    ni_inputs: ChemInputsViewModel = sdc.child_component("ni", default=ChemInputsViewModel())
    s_inputs: ChemInputsViewModel = sdc.child_component("s", default=ChemInputsViewModel())
    sn_inputs: ChemInputsViewModel = sdc.child_component("sn", default=ChemInputsViewModel())
    modal: GradeGroupModalViewModel = sdc.child_component(
        "create-grade-group-modal", default=GradeGroupModalViewModel()
    )
    confirm_button_label: str = sdc.one_way_binding(CONFIRM_BUTTON_ID, "children", default=CREATE_LIMIT)
    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    name: str = sdc.two_way_binding(NAME_ID, "value", default=NEW_LIMIT)
    comment: str = sdc.two_way_binding(COMMENT_ID, "value", default="")

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", RiskLimitModalViewModel.close_modal),
            sdc.InputField(cls.CONFIRM_BUTTON_ID, "n_clicks", RiskLimitModalViewModel.confirm_event),
            sdc.InputField(
                cls.CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID, "n_clicks", RiskLimitModalViewModel.open_modal
            ),
        )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.CONFIRM_BUTTON_ID, "disabled", RiskLimitModalViewModel.are_inputs_invalid),
            sdc.OutputField(cls.NAME_VALIDATION_MSG_ID, "children", RiskLimitModalViewModel.name_validation),
        )

    @classmethod
    def create_chem_inputs(cls, parent_id: str) -> html.Div:
        return get_pair_inputs_wrapper(
            pair_inputs=[
                sdc.get_child_layout(parent_id, cls.cr_inputs, pair_name="Cr"),
                sdc.get_child_layout(parent_id, cls.cu_inputs, pair_name="Cu"),
                sdc.get_child_layout(parent_id, cls.mo_inputs, pair_name="Mo"),
                sdc.get_child_layout(parent_id, cls.ni_inputs, pair_name="Ni"),
                sdc.get_child_layout(parent_id, cls.s_inputs, pair_name="S"),
                sdc.get_child_layout(parent_id, cls.sn_inputs, pair_name="Sn"),
            ],
            first_column_label=cls.AIM,
            second_column_label=cls.ALLOWED,
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> dbc.Modal:
        return dbc.Modal(
            backdrop="static",
            children=[
                create_modal_header(
                    sdc.create_id(parent_id, cls.NAME_ID),
                    sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID),
                    sdc.create_id(parent_id, cls.NAME_VALIDATION_MSG_ID),
                ),
                dbc.ModalBody(
                    children=[
                        cls.create_chem_inputs(parent_id),
                        create_input_wrapper(
                            cls.CHOOSE_GRADE_GROUP,
                            [
                                html.Div(
                                    children=[
                                        sdc.get_child_layout(parent_id, cls.grade_groups),
                                        dbc.Button(
                                            children="+",
                                            color="light",
                                            id=sdc.create_id(
                                                parent_id, cls.CREATE_GROUP_GRADE_MODAL_OPEN_BUTTON_ID
                                            ),
                                        ),
                                    ],
                                    className="inputs-group",
                                ),
                            ],
                        ),
                        create_input_wrapper(
                            cls.CHOOSE_LOADING_STATIONS,
                            [
                                sdc.get_child_layout(parent_id, cls.loading_stations),
                            ],
                        ),
                        create_input_wrapper(
                            cls.COMMENT,
                            [
                                dbc.Input(id=sdc.create_id(parent_id, cls.COMMENT_ID), debounce=True),
                            ],
                        ),
                        sdc.get_child_layout(parent_id, cls.affected_limit_id),
                        sdc.get_child_layout(parent_id, cls.modal),
                        sdc.get_child_layout(parent_id, cls.last_change),
                    ]
                ),
                create_modal_footer(sdc.create_id(parent_id, cls.CONFIRM_BUTTON_ID), ""),
            ],
            centered=True,
            id=sdc.create_id(parent_id, cls.COMPONENT_ID),
            keyboard=False,
        )

    @property
    def update(self) -> bool:
        return self.affected_limit_id.data != -1

    def get_relaxable_risk_limit_or_raise(self) -> RelaxableRiskLimitSetting:
        if self.affected_limit_id is None:
            raise ValueError("Missing id of relaxable risk limit")
        return RelaxableRiskLimitSetting.objects.get(id=self.affected_limit_id.data)

    def update_group(self) -> None:
        grade_group = self.grade_groups.selected_value_or_raise
        relaxable_risk_limit = self.get_relaxable_risk_limit_or_raise()
        affected_loading_stations_ids = self.loading_stations.selected_options
        all_affected_loading_stations_ids = set(
            (*affected_loading_stations_ids, *relaxable_risk_limit.affected_loading_stations_ids)
        )

        relaxable_risk_limit.name = self.name
        relaxable_risk_limit.comment = self.comment
        relaxable_risk_limit.grade_ids = grade_group
        relaxable_risk_limit.Cr_aim = self.cr_inputs.aim_or_raise
        relaxable_risk_limit.Cr_allowed = self.cr_inputs.allowed_or_raise
        relaxable_risk_limit.Cu_aim = self.cu_inputs.aim_or_raise
        relaxable_risk_limit.Cu_allowed = self.cu_inputs.allowed_or_raise
        relaxable_risk_limit.Mo_aim = self.mo_inputs.aim_or_raise
        relaxable_risk_limit.Mo_allowed = self.mo_inputs.allowed_or_raise
        relaxable_risk_limit.Ni_aim = self.ni_inputs.aim_or_raise
        relaxable_risk_limit.Ni_allowed = self.ni_inputs.allowed_or_raise
        relaxable_risk_limit.S_aim = self.s_inputs.aim_or_raise
        relaxable_risk_limit.S_allowed = self.s_inputs.allowed_or_raise
        relaxable_risk_limit.Sn_aim = self.sn_inputs.aim_or_raise
        relaxable_risk_limit.Sn_allowed = self.sn_inputs.allowed_or_raise

        relaxable_risk_limit.save()
        for loading_station in LoadingStation.objects.filter(id__in=all_affected_loading_stations_ids):
            if loading_station.id in affected_loading_stations_ids:
                loading_station.relaxable_risk_limit_settings.add(relaxable_risk_limit)
            else:
                loading_station.relaxable_risk_limit_settings.remove(relaxable_risk_limit)

    def create_group(self) -> None:
        grade_group = self.grade_groups.selected_value_or_raise
        relaxable_risk_limit = RelaxableRiskLimitSetting(
            name=self.name,
            comment=self.comment,
            grade_ids=grade_group,
            Cr_aim=self.cr_inputs.aim,
            Cr_allowed=self.cr_inputs.allowed,
            Cu_aim=self.cu_inputs.aim,
            Cu_allowed=self.cu_inputs.allowed,
            Mo_aim=self.mo_inputs.aim,
            Mo_allowed=self.mo_inputs.allowed,
            Ni_aim=self.ni_inputs.aim,
            Ni_allowed=self.ni_inputs.allowed,
            S_aim=self.s_inputs.aim,
            S_allowed=self.s_inputs.allowed,
            Sn_aim=self.sn_inputs.aim,
            Sn_allowed=self.sn_inputs.allowed,
        )
        relaxable_risk_limit.save()
        for loading_station in LoadingStation.objects.filter(id__in=self.loading_stations.selected_options):
            loading_station.relaxable_risk_limit_settings.add(relaxable_risk_limit)

    def confirm_event(self, _: int) -> "RiskLimitModalViewModel":
        if self.update:
            self.update_group()
        else:
            self.create_group()
        return self.reset_to_initial_state(True)

    def reset_to_initial_state(self, data_changed: bool) -> "RiskLimitModalViewModel":
        last_change = time.time_ns() if data_changed else self.last_change.data
        return RiskLimitModalViewModel(last_change=DataStoreViewModel(last_change))  # type: ignore

    def close_modal(self, _: int) -> "RiskLimitModalViewModel":
        return self.reset_to_initial_state(False)

    def are_inputs_invalid(self) -> bool:
        return not (
            self.grade_groups.has_selected_option
            and self.loading_stations.has_selected_options
            and self.cr_inputs.valid_inputs
            and self.cu_inputs.valid_inputs
            and self.mo_inputs.valid_inputs
            and self.ni_inputs.valid_inputs
            and self.s_inputs.valid_inputs
            and self.sn_inputs.valid_inputs
        )

    def open_modal(self, _: int, ctx: SettingsAppFiltersSource) -> "RiskLimitModalViewModel":
        return attr.evolve(
            self,
            modal=self.modal.set_input_values_and_open(ctx),
        )

    def name_validation(self) -> str:
        if not self.name:
            return self.NAME_MUST_BE_FILLED
        return ""

    def set_input_values_and_open(
        self,
        ctx: SettingsAppFiltersSource,
        row_view_model: Optional[RiskLimitsSettingsTableRowViewModel] = None,
    ) -> "RiskLimitModalViewModel":
        if row_view_model is None:
            return RiskLimitModalViewModel(
                is_open=True,
                loading_stations=self.loading_stations.set_selected_option(ctx.selected_loading_station_id),
                grade_groups=self.grade_groups.set_filter_grade_id(ctx.selected_grade_id).set_selected_option(
                    None
                ),
                # TODO [SDC MYPY BUG] remove type ignore after fix Mypy issue:
                # https://mypy.readthedocs.io/en/stable/additional_features.html#id1
                cr_inputs=ChemInputsViewModel(aim=0.01, allowed=0.02),  # type: ignore
                cu_inputs=ChemInputsViewModel(aim=0.01, allowed=0.02),  # type: ignore
                mo_inputs=ChemInputsViewModel(aim=0.01, allowed=0.025),  # type: ignore
                ni_inputs=ChemInputsViewModel(aim=0.01, allowed=0.02),  # type: ignore
                s_inputs=ChemInputsViewModel(aim=0.15, allowed=0.387),  # type: ignore
                sn_inputs=ChemInputsViewModel(aim=0.01, allowed=0.02),  # type: ignore
            )
        return RiskLimitModalViewModel(  # type: ignore #[SDC MYPY BUG]
            is_open=True,
            confirm_button_label=self.UPDATE_LIMIT,
            affected_limit_id=DataStoreViewModel(row_view_model.limit_id),  # type: ignore #[SDC MYPY BUG]
            name=row_view_model.name,
            comment=row_view_model.comment,
            loading_stations=self.loading_stations.set_selected_options(
                row_view_model.affected_loading_stations_ids
            ),
            grade_groups=self.grade_groups.set_filter_grade_id(ctx.selected_grade_id).set_selected_option(
                row_view_model.grade_group_id
            ),
            cr_inputs=attr.evolve(
                self.cr_inputs, aim=row_view_model.cr_aim, allowed=row_view_model.cr_allowed
            ),
            cu_inputs=attr.evolve(
                self.cu_inputs, aim=row_view_model.cu_aim, allowed=row_view_model.cu_allowed
            ),
            mo_inputs=attr.evolve(
                self.mo_inputs, aim=row_view_model.mo_aim, allowed=row_view_model.mo_allowed
            ),
            ni_inputs=attr.evolve(
                self.ni_inputs, aim=row_view_model.ni_aim, allowed=row_view_model.ni_allowed
            ),
            s_inputs=attr.evolve(self.s_inputs, aim=row_view_model.s_aim, allowed=row_view_model.s_allowed),
            sn_inputs=attr.evolve(
                self.sn_inputs, aim=row_view_model.sn_aim, allowed=row_view_model.sn_allowed
            ),
        )
