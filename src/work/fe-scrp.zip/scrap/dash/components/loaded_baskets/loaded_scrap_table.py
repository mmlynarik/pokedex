from typing import Dict, List, Sequence, Union

import attr
from dash import dash_table, html
import ussksdc as sdc
from scrap.dash.components.common import LoadedBasketCompatibilitySource


def scrap_type_to_id(scrap_name: str) -> str:
    return scrap_name.replace(" ", "_").lower()


@attr.s(frozen=True, slots=True)
class LoadedScrapsTableViewModel:
    # COMPONENT IDS
    TABLE_ID = "loaded-scraps"
    SUM_COLUMN_ID = "sum"
    # COMPONENT CLASS NAMES
    TABLE_WRAPPER = "table-wrapper"
    # User friendly msg
    LOADED_SCRAPS = "Vsádzka [t]"
    SUM = "Spolu"

    order: int = attr.ib()

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.TABLE_ID, "columns", LoadedScrapsTableViewModel.get_table_columns),
            sdc.OutputField(cls.TABLE_ID, "data", LoadedScrapsTableViewModel.get_table_rows),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=dash_table.DataTable(
                id=sdc.create_id(parent_id, cls.TABLE_ID), merge_duplicate_headers=True
            ),
            className=cls.TABLE_WRAPPER,
        )

    def get_table_columns(
        self, ctx: LoadedBasketCompatibilitySource
    ) -> List[Dict[str, Union[str, Sequence[str]]]]:
        columns = [
            {"name": [self.LOADED_SCRAPS, scrap_type], "id": scrap_type_to_id(scrap_type), "type": "numeric"}
            for scrap_type in ctx.datasource.get_loaded_baskets(self.order).loaded_scraps
        ]
        columns.append({"name": [self.LOADED_SCRAPS, self.SUM], "id": self.SUM_COLUMN_ID, "type": "numeric"})
        return columns

    def get_table_rows(self, ctx: LoadedBasketCompatibilitySource) -> List[Dict[str, float]]:
        loaded_scraps = ctx.datasource.get_loaded_baskets(self.order).loaded_scraps
        data = [{scrap_type_to_id(scrap_type): value for scrap_type, value in loaded_scraps.items()}]
        data[0][self.SUM_COLUMN_ID] = sum(loaded_scraps.values())
        return data
