import logging
from datetime import datetime
from functools import lru_cache
from typing import Collection, Optional, Protocol, Tuple, Union, List
import pytz

import attr
import numpy as np
from immutables import Map
from scrap.dash.database_api import steel_grades
from scrap.models import (
    LoadingStation,
    all_prefetched_loading_station_query_set,
    get_relevant_relaxable_summing_limits_settings,
    MultipleHeatsOptimizationResult,
    ScrapCharge,
    get_input_data,
)
from scrap_core import SUPPORTED_SCRAP_TYPES, ScrapCharge as ScrapCoreScrapCharge, ScrapMixMapping
from scrap_core.compatible_grades import (
    check_grade_compatibility,
    is_scrap_charge_compatible_with_summing_limits,
)
from scrap_core.optimization.relaxable_limits import RelaxableUpperSummingLimit, RelaxableLowerSummingLimit
from scrap.dash.components.one_heat_optimizer_v2 import get_relaxable_risk_limit_for_grade

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


@attr.s(frozen=True, auto_attribs=True, slots=True)
class LoadedBaskets:
    id_: int
    basket_ids: Tuple[int, ...]
    loaded_timestamp: float
    loaded_scraps: ScrapCoreScrapCharge
    is_risk_limit_met: Optional[bool] = attr.ib(default=None)
    is_lower_summing_limit_met: Optional[bool] = attr.ib(default=None)
    is_upper_summing_limit_met: Optional[bool] = attr.ib(default=None)
    selected_grade: Optional[int] = attr.ib(default=None)

    @property
    def time_str(self) -> str:
        return (
            datetime.fromtimestamp(self.loaded_timestamp, tz=pytz.UTC)
            .astimezone(pytz.timezone("Europe/Bratislava"))
            .strftime("%d.%m %X")
        )

    @property
    def basket_ids_str(self) -> str:
        return ", ".join(map(str, self.basket_ids))

    @property
    def is_compatible(self) -> Optional[bool]:
        return self.is_risk_limit_met and self.is_lower_summing_limit_met and self.is_upper_summing_limit_met


LoadedBasketsForHeats = Collection[LoadedBaskets]


class LoadedBasketsDataSource(Protocol):
    def get_loaded_baskets(self, order: int) -> LoadedBaskets: ...

    def get_data_for_compatibility_card(self, order: int, grade_id: Optional[int]) -> LoadedBaskets: ...


def generate_loaded_scraps(min_loaded_scraps: int, max_loaded_scraps: int) -> ScrapCoreScrapCharge:
    scrap_count = np.random.randint(min_loaded_scraps, max_loaded_scraps)
    random_scrap_types = np.random.choice(SUPPORTED_SCRAP_TYPES, scrap_count, replace=False)
    random_weights = map(int, np.random.randint(100, 10000, scrap_count))
    return Map(dict(zip(random_scrap_types, random_weights)))


def generate_loaded_timestamp() -> float:
    return datetime.now().timestamp() - (np.random.randint(1, 100) * 1000)


def generate_basket_ids(min_basket_count: int, max_basket_count: int) -> Tuple[int, ...]:
    basket_count = np.random.randint(min_basket_count, max_basket_count)
    return tuple(map(int, np.random.randint(1, 100, basket_count)))


def generate_loaded_basket(
    id_: int,
    min_loaded_scraps: int,
    max_loaded_scraps: int,
    min_basket_count: int,
    max_basket_count: int,
) -> LoadedBaskets:
    return LoadedBaskets(
        id_=id_,
        basket_ids=generate_basket_ids(min_basket_count, max_basket_count),
        loaded_timestamp=generate_loaded_timestamp(),
        loaded_scraps=generate_loaded_scraps(min_loaded_scraps, max_loaded_scraps),
        is_risk_limit_met=None,
        is_lower_summing_limit_met=None,
        is_upper_summing_limit_met=None,
        selected_grade=None,
    )


class DummyLoadedBasketsDataSource:
    def __init__(self, loaded_baskets_count: int) -> None:
        self.dummy_data = {
            id_: generate_loaded_basket(id_, 1, 8, 1, 4) for id_ in range(0, loaded_baskets_count)
        }

    def get_loaded_baskets(self, order: int) -> LoadedBaskets:
        return self.dummy_data[order]

    def get_data_for_compatibility_card(self, order: int, grade_id: Optional[int]) -> LoadedBaskets:
        data = self.dummy_data[order]
        is_risk_limit_met = np.random.choice([True, False]) if grade_id is not None else None
        is_lower_summing_limit_met = np.random.choice([True, False]) if grade_id is not None else None
        is_upper_summing_limit_met = np.random.choice([True, False]) if grade_id is not None else None
        return attr.evolve(
            data,
            selected_grade=grade_id,
            is_risk_limit_met=is_risk_limit_met,
            is_lower_summing_limit_met=is_lower_summing_limit_met,
            is_upper_summing_limit_met=is_upper_summing_limit_met,
        )


@lru_cache(maxsize=1024)
def get_cached_loaded_basket_by_id(loaded_basket_id: int) -> ScrapCharge:
    return ScrapCharge.objects.get(pk=loaded_basket_id)


@lru_cache(maxsize=1024)
def get_cached_loading_station_by_id(loading_station_id: int) -> LoadingStation:
    return all_prefetched_loading_station_query_set().get(pk=loading_station_id)


def get_relevat_relaxable_summing_limits(
    loading_station_id: int, grade_id: int, check_for_upper_limit: bool
) -> Union[Collection[RelaxableLowerSummingLimit], Collection[RelaxableUpperSummingLimit]]:
    loading_station = get_cached_loading_station_by_id(loading_station_id)
    all_summing_limits = (
        loading_station.relaxable_upper_summing_limit_settings.all()
        if check_for_upper_limit
        else loading_station.relaxable_lower_summing_limit_settings.all()
    )
    # TODO type ignore due to mypy says that django related manager is not Iterable type
    summing_limits = get_relevant_relaxable_summing_limits_settings(all_summing_limits, grade_id)  # type: ignore
    return tuple(map(lambda limit: limit.to_relaxable_limit(), summing_limits))


@lru_cache(maxsize=1024)
def check_compatibility_loaded_basket_with_summing_limits(
    grade_id: int, loaded_basket_id: int, loading_station_id, check_for_upper_limit: bool
) -> Optional[bool]:
    loaded_basket = get_cached_loaded_basket_by_id(loaded_basket_id)

    optimization = loaded_basket.last_optimization_result
    if optimization is None:
        return None

    mix_mapping = optimization.optimization_input.model_settings.optimizer_settings.scrap_mix_mapping
    if mix_mapping is None:
        return None

    return is_scrap_charge_compatible_with_summing_limits(
        scrap_charge=optimization.result.scrap_weights_per_heat[0],
        summing_limits=get_relevat_relaxable_summing_limits(
            loading_station_id, grade_id, check_for_upper_limit
        ),
        mix_mapping=mix_mapping,
    )


@lru_cache(maxsize=1024)
def check_compatibility_loaded_basket_with_risk_limits(grade_id: int, loaded_basket_id: int) -> bool:
    loaded_basket = get_cached_loaded_basket_by_id(loaded_basket_id=loaded_basket_id)
    model_settings = loaded_basket.loading_station.model_settings
    relaxable_risk_limits_settings = tuple(loaded_basket.loading_station.relaxable_risk_limit_settings.all())
    relaxable_risk_limit = get_relaxable_risk_limit_for_grade(grade_id, relaxable_risk_limits_settings)
    return check_grade_compatibility(
        scrap_charge=loaded_basket.recommended_scrap_charge,
        pig_iron_weight=loaded_basket.pig_iron_weight_or_constant,
        pig_iron_chem=loaded_basket.raw_fe_chem,
        model_settings=model_settings,
        steel_grades=steel_grades,
        grade_id=grade_id,
        relaxable_risk_limit=relaxable_risk_limit,
    )


class DBLoadedBasketsDataSource:
    FALLBACK_ID = -1

    def __init__(
        self, loading_station_id: int, loaded_basket_to_load_count: int, reversed_order: bool = True
    ) -> None:
        self.loading_station_id = loading_station_id
        self.loaded_basket_to_load_count = loaded_basket_to_load_count
        self.reversed_order = reversed_order

    @property
    def fallback_loaded_baskets(self) -> LoadedBaskets:
        return LoadedBaskets(
            id_=self.FALLBACK_ID,
            basket_ids=(),
            loaded_timestamp=0,
            loaded_scraps=Map({}),
        )

    def get_loaded_baskets(self, order: int) -> LoadedBaskets:
        charges: List[ScrapCharge] = list(
            ScrapCharge.objects.filter(
                loading_station=self.loading_station_id, closed_at__isnull=False
            ).order_by("-closed_at")[: self.loaded_basket_to_load_count]
        )
        if self.reversed_order:
            charges.reverse()
        if len(charges) <= order:
            return self.fallback_loaded_baskets
        loaded_basket = charges[order]
        return LoadedBaskets(
            id_=loaded_basket.pk,
            basket_ids=loaded_basket.basket_ids,
            loaded_timestamp=loaded_basket.closed_at.timestamp(),
            loaded_scraps=loaded_basket.recommended_scrap_charge,
        )

    def get_data_for_compatibility_card(self, order: int, grade_id: Optional[int]) -> LoadedBaskets:
        loaded_baskets = self.get_loaded_baskets(order)
        if grade_id is None or loaded_baskets.id_ == self.FALLBACK_ID:
            is_risk_limit_met = None
            is_upper_summing_limit_met = None
            is_lower_summing_limit_met = None
        else:
            is_risk_limit_met = check_compatibility_loaded_basket_with_risk_limits(
                grade_id, loaded_baskets.id_
            )
            is_upper_summing_limit_met = check_compatibility_loaded_basket_with_summing_limits(
                grade_id, loaded_baskets.id_, self.loading_station_id, check_for_upper_limit=True
            )
            is_lower_summing_limit_met = check_compatibility_loaded_basket_with_summing_limits(
                grade_id, loaded_baskets.id_, self.loading_station_id, check_for_upper_limit=False
            )
        return attr.evolve(
            loaded_baskets,
            selected_grade=grade_id,
            is_risk_limit_met=is_risk_limit_met,
            is_upper_summing_limit_met=is_upper_summing_limit_met,
            is_lower_summing_limit_met=is_lower_summing_limit_met,
        )


def get_datasource(
    loading_station_id: Optional[int], compatibility_card_count: int
) -> LoadedBasketsDataSource:
    if loading_station_id is None:
        return DummyLoadedBasketsDataSource(compatibility_card_count)
    return DBLoadedBasketsDataSource(loading_station_id, compatibility_card_count)
