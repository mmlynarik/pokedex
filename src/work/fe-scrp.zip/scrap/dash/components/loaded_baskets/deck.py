from typing import Collection, Self

import attr
import ussksdc as sdc
from dash import html
from scrap.dash.components.auto_reload import AutoReloadViewModel
from scrap.dash.components.loaded_baskets.compatibility_card import LoadedBasketCompatibilityCardViewModel

LoadedBasketsComponents = Collection[html.Div]


@attr.frozen
class LoadedBasketsDeckViewModel:
    # COMPONENT INITIAL STATE
    COMPATIBILITY_CARD_COUNT = 12
    # COMPONENT IDS
    LOADED_BASKETS_DECK_ID = "deck"
    # COMPONENT CLASSNAMES
    DECK_WRAPPER_CLASSNAME = "deck-wrapper"
    DECK_CLASSNAME = "deck"

    @classmethod
    def create(cls, update_interval: int) -> Self:
        return cls(auto_reload=AutoReloadViewModel.create(update_interval))

    # TODO remove type ignore after fix Mypy issue:
    # https://mypy.readthedocs.io/en/stable/additional_features.html#id1
    auto_reload: AutoReloadViewModel = sdc.child_component(
        "auto-reload", factory=AutoReloadViewModel  # type: ignore
    )
    # TODO http://vdevops/Esten/UssAi/_workitems/edit/409/ add pattern matching callbacks
    compatibility_card_0: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-0", default=LoadedBasketCompatibilityCardViewModel(order=0)
    )
    compatibility_card_1: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-1", default=LoadedBasketCompatibilityCardViewModel(order=1)
    )
    compatibility_card_2: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-2", default=LoadedBasketCompatibilityCardViewModel(order=2)
    )
    compatibility_card_3: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-3", default=LoadedBasketCompatibilityCardViewModel(order=3)
    )
    compatibility_card_4: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-4", default=LoadedBasketCompatibilityCardViewModel(order=4)
    )
    compatibility_card_5: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-5", default=LoadedBasketCompatibilityCardViewModel(order=5)
    )
    compatibility_card_6: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-6", default=LoadedBasketCompatibilityCardViewModel(order=6)
    )
    compatibility_card_7: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-7", default=LoadedBasketCompatibilityCardViewModel(order=7)
    )
    compatibility_card_8: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-8", default=LoadedBasketCompatibilityCardViewModel(order=8)
    )
    compatibility_card_9: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-9", default=LoadedBasketCompatibilityCardViewModel(order=9)
    )
    compatibility_card_10: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-10", default=LoadedBasketCompatibilityCardViewModel(order=10)
    )
    compatibility_card_11: LoadedBasketCompatibilityCardViewModel = sdc.child_component(
        "compatibility-card-11", default=LoadedBasketCompatibilityCardViewModel(order=11)
    )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                sdc.get_child_layout(parent_id, cls.auto_reload),
                html.Div(
                    children=[
                        sdc.get_child_layout(parent_id, cls.compatibility_card_0),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_1),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_2),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_3),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_4),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_5),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_6),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_7),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_8),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_9),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_10),
                        sdc.get_child_layout(parent_id, cls.compatibility_card_11),
                    ],
                    className=cls.DECK_CLASSNAME,
                    id=sdc.create_id(parent_id, cls.LOADED_BASKETS_DECK_ID),
                ),
            ],
            className=cls.DECK_WRAPPER_CLASSNAME,
        )

    def interval(self, _: int) -> Self:
        return self
