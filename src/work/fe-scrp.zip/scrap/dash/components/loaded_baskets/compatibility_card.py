from typing import Optional
import attr
import ussksdc as sdc
from dash import html
from scrap.dash.components.common import LoadedBasketCompatibilitySource
from scrap.dash.components.loaded_baskets.loaded_scrap_table import LoadedScrapsTableViewModel


@attr.s(frozen=True, slots=True)
class LoadedBasketCompatibilityCardViewModel:
    # COMPONENT IDS
    LOADED_BASKET_COMPONENT_ID = "loaded-basket"
    CHECKED_GRADE_ID_INPUT_ID = "checked-grade-id"
    BASKETS_IDS_ID = "basket-ids"
    GRADE_FOR_CHECKING_INPUT_ID = "grade-for-compatibility-check"
    CHECK_COMPATIBILITY_BUTTON_ID = "check-compatibility"
    COMPATIBILITY_RESULT_ID = "compatibility-result"
    IS_RISK_LIMIT_MET_ID = "is-risk-limit-met"
    IS_UPPER_SUMMING_LIMIT_MET_ID = "is-upper-summing-limit-met"
    IS_LOWER_SUMMING_LIMIT_MET_ID = "is-lower-summing-limit-met"
    LOADED_SCRAP_TABLE_ID = "loaded-scrap-table"
    LOADED_SCRAP_TIME_ID = "loaded-scrap-time"
    LIMITS_COMPATIBILITY_WRAPPER_ID = "limits-compatibility-wrapper"
    # COMPONENT CLASSNAMES
    BASKET_CARD_CLASSNAME = "basket-card"
    BASKET_CARD_HEADER_CLASSNAME = f"{BASKET_CARD_CLASSNAME}-header"
    BASKET_CARD_CONTENT_CLASSNAME = f"{BASKET_CARD_CLASSNAME}-content"
    BASKET_CARD_FOOTER_CLASSNAME = f"{BASKET_CARD_CLASSNAME}-footer"
    LABEL_CLASSNAME = "label"
    VALUE_CLASSNAME = "value"
    COMPATIBLE_CLASSNAME = "compatible"
    INCOMPATIBLE_CLASSNAME = "incompatible"
    VISIBLE_HIDDEN_CLASSNAME = "hidden"
    # USER FRIENDLY MSG
    COMPATIBLE = "Kompatibilné"
    INCOMPATIBLE = "Nekompatibilné"

    order: int = attr.ib()
    loaded_scraps_table: LoadedScrapsTableViewModel = sdc.child_component(
        "loaded-scraps-table",
        default=attr.Factory(lambda self: LoadedScrapsTableViewModel(self.order), takes_self=True),
    )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(
                cls.BASKETS_IDS_ID, "children", LoadedBasketCompatibilityCardViewModel.get_basket_ids
            ),
            sdc.OutputField(
                cls.LOADED_SCRAP_TIME_ID,
                "children",
                LoadedBasketCompatibilityCardViewModel.get_scraps_load_time,
            ),
            sdc.OutputField(
                cls.COMPATIBILITY_RESULT_ID,
                "children",
                LoadedBasketCompatibilityCardViewModel.compatibility_loaded_baskets,
            ),
            sdc.OutputField(
                cls.COMPATIBILITY_RESULT_ID,
                "className",
                LoadedBasketCompatibilityCardViewModel.get_compatibility_loaded_baskets_class_name,
            ),
            sdc.OutputField(
                cls.IS_RISK_LIMIT_MET_ID,
                "className",
                LoadedBasketCompatibilityCardViewModel.get_compatibility_risk_limit_class_name,
            ),
            sdc.OutputField(
                cls.IS_UPPER_SUMMING_LIMIT_MET_ID,
                "className",
                LoadedBasketCompatibilityCardViewModel.get_compatibility_upper_summing_limit_class_name,
            ),
            sdc.OutputField(
                cls.IS_LOWER_SUMMING_LIMIT_MET_ID,
                "className",
                LoadedBasketCompatibilityCardViewModel.get_compatibility_lower_summing_limit_class_name,
            ),
            sdc.OutputField(
                cls.LIMITS_COMPATIBILITY_WRAPPER_ID,
                "className",
                LoadedBasketCompatibilityCardViewModel.grade_is_not_selected,
            ),
        )

    @classmethod
    def get_layout(cls, parent_id: str) -> html.Div:
        return html.Div(
            children=[
                html.Div(
                    children=[
                        html.Div(
                            f"Koryto", className=f"{cls.BASKET_CARD_HEADER_CLASSNAME}-{cls.LABEL_CLASSNAME}"
                        ),
                        html.Div(
                            className=f"{cls.BASKET_CARD_HEADER_CLASSNAME}-{cls.VALUE_CLASSNAME}",
                            id=sdc.create_id(parent_id, cls.BASKETS_IDS_ID),
                        ),
                    ],
                    className=cls.BASKET_CARD_HEADER_CLASSNAME,
                ),
                html.Div(
                    children=[
                        html.Div(
                            children=[
                                html.Div(id=sdc.create_id(parent_id, cls.COMPATIBILITY_RESULT_ID)),
                                html.Div(
                                    children="Riziko nežiadúcej opravnej technológie",
                                    id=sdc.create_id(parent_id, cls.IS_RISK_LIMIT_MET_ID),
                                ),
                                html.Div(
                                    children="Maximálne povolené množstvo šrotu",
                                    id=sdc.create_id(parent_id, cls.IS_UPPER_SUMMING_LIMIT_MET_ID),
                                ),
                                html.Div(
                                    children="Minimálne povolené množstvo šrotu",
                                    id=sdc.create_id(parent_id, cls.IS_LOWER_SUMMING_LIMIT_MET_ID),
                                ),
                            ],
                            id=sdc.create_id(parent_id, cls.LIMITS_COMPATIBILITY_WRAPPER_ID),
                        ),
                        sdc.get_child_layout(parent_id, cls.loaded_scraps_table),
                    ],
                    className=cls.BASKET_CARD_CONTENT_CLASSNAME,
                ),
                html.Div(
                    children=[
                        html.Div(
                            "Naložené", className=f"{cls.BASKET_CARD_FOOTER_CLASSNAME}-{cls.LABEL_CLASSNAME}"
                        ),
                        html.Div(
                            className=f"{cls.BASKET_CARD_FOOTER_CLASSNAME}-{cls.VALUE_CLASSNAME}",
                            id=sdc.create_id(parent_id, cls.LOADED_SCRAP_TIME_ID),
                        ),
                    ],
                    className=cls.BASKET_CARD_FOOTER_CLASSNAME,
                ),
            ],
            className=cls.BASKET_CARD_CLASSNAME,
        )

    def get_basket_ids(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return ctx.datasource.get_loaded_baskets(self.order).basket_ids_str

    def get_scraps_load_time(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return ctx.datasource.get_loaded_baskets(self.order).time_str

    def is_risk_limit_met(self, ctx: LoadedBasketCompatibilitySource) -> Optional[bool]:
        return ctx.datasource.get_data_for_compatibility_card(
            self.order, ctx.selected_grade_id
        ).is_risk_limit_met

    def is_upper_summing_limit_met(self, ctx: LoadedBasketCompatibilitySource) -> Optional[bool]:
        return ctx.datasource.get_data_for_compatibility_card(
            self.order, ctx.selected_grade_id
        ).is_upper_summing_limit_met

    def is_lower_summing_limit_met(self, ctx: LoadedBasketCompatibilitySource) -> Optional[bool]:
        return ctx.datasource.get_data_for_compatibility_card(
            self.order, ctx.selected_grade_id
        ).is_lower_summing_limit_met

    def is_loaded_basket_compatible(self, ctx: LoadedBasketCompatibilitySource) -> Optional[bool]:
        return ctx.datasource.get_data_for_compatibility_card(self.order, ctx.selected_grade_id).is_compatible

    def get_class_name_for_limit(self, is_limit_met: Optional[bool], selected_grade_id: Optional[int]) -> str:
        if selected_grade_id is None or is_limit_met is None:
            return ""
        if is_limit_met:
            return self.COMPATIBLE_CLASSNAME
        return self.INCOMPATIBLE_CLASSNAME

    def compatibility_loaded_baskets(self, ctx: LoadedBasketCompatibilitySource) -> str:
        if self.is_loaded_basket_compatible(ctx):
            return self.COMPATIBLE
        return self.INCOMPATIBLE

    def get_compatibility_loaded_baskets_class_name(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return self.get_class_name_for_limit(self.is_loaded_basket_compatible(ctx), ctx.selected_grade_id)

    def get_compatibility_risk_limit_class_name(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return self.get_class_name_for_limit(self.is_risk_limit_met(ctx), ctx.selected_grade_id)

    def get_compatibility_upper_summing_limit_class_name(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return self.get_class_name_for_limit(self.is_upper_summing_limit_met(ctx), ctx.selected_grade_id)

    def get_compatibility_lower_summing_limit_class_name(self, ctx: LoadedBasketCompatibilitySource) -> str:
        return self.get_class_name_for_limit(self.is_lower_summing_limit_met(ctx), ctx.selected_grade_id)

    def grade_is_not_selected(self, ctx: LoadedBasketCompatibilitySource) -> str:
        if ctx.selected_grade_id is None:
            return self.VISIBLE_HIDDEN_CLASSNAME
        return ""
