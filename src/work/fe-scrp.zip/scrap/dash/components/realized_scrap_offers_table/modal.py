from typing import Optional
import attr
from dash import html
import dash_bootstrap_components as dbc
import ussksdc as sdc
from ussksdc.components.data_store import DataStoreViewModel

from scrap.dash.components.modals import create_modal_label_header
from scrap.dash.components.common import ScrapPurchaseAppSource


@attr.s(frozen=True, slots=True)
class DeleteRealizedScrapOfferModalViewModel:
    OPEN_ON_LOAD = False

    COMPONENT_ID = "remove-modal"
    CLOSE_BUTTON_ID = "close"
    INFO_REALIZED_OFFER_ID = "realized-info"
    INFO_OFFERS_TO_UNLOCK_ID = "unlock-info"
    INFO_OFFERS_TO_DELETE_ID = "delete-info"
    DELETE_BUTTON_ID = "delete"

    NAME = "Zmazanie realizovanej ponuky"
    REALIZED_OFFER_TO_DELETE = "Realizovaná ponuka, ktorá bude zmazaná:\n"
    SCRAP_OFFERS_TO_UNLOCK = "Ponuky, ktoré budú odomknuté:\n"
    SCRAP_OFFERS_TO_DELETE = "Ponuky, ktoré budú zmazané:\n"
    DELETE_BUTTON = "Zmazať"

    is_open: bool = sdc.one_way_binding(COMPONENT_ID, "is_open", converter=bool, default=OPEN_ON_LOAD)
    realized_offer_idx: DataStoreViewModel = sdc.child_component(
        "realized-offer-idx", default=DataStoreViewModel()
    )
    info_realized_offer: str = sdc.one_way_binding(INFO_REALIZED_OFFER_ID, "children", default="")
    info_scrap_offers_to_unlock: str = sdc.one_way_binding(INFO_OFFERS_TO_UNLOCK_ID, "children", default="")
    info_scrap_offers_to_delete: str = sdc.one_way_binding(INFO_OFFERS_TO_DELETE_ID, "children", default="")

    @property
    def offer_idx(self) -> int:
        return self.realized_offer_idx.data

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (
            sdc.InputField(cls.CLOSE_BUTTON_ID, "n_clicks", cls.close_modal),
            sdc.InputField(cls.DELETE_BUTTON_ID, "n_clicks", cls.delete_realized_offer),
        )

    @classmethod
    def get_layout(cls, parent_id: str):
        return html.Div(
            children=[
                dbc.Modal(
                    backdrop="static",
                    children=[
                        create_modal_label_header(cls.NAME, sdc.create_id(parent_id, cls.CLOSE_BUTTON_ID)),
                        dbc.ModalBody(
                            children=[
                                html.Div(
                                    children=[
                                        dbc.Label(cls.REALIZED_OFFER_TO_DELETE),
                                        html.P(id=sdc.create_id(parent_id, cls.INFO_REALIZED_OFFER_ID)),
                                    ]
                                ),
                                html.Div(
                                    children=[
                                        dbc.Label(cls.SCRAP_OFFERS_TO_UNLOCK),
                                        html.P(id=sdc.create_id(parent_id, cls.INFO_OFFERS_TO_UNLOCK_ID)),
                                    ]
                                ),
                                html.Div(
                                    children=[
                                        dbc.Label(cls.SCRAP_OFFERS_TO_DELETE),
                                        html.P(id=sdc.create_id(parent_id, cls.INFO_OFFERS_TO_DELETE_ID)),
                                    ]
                                ),
                            ]
                        ),
                        dbc.ModalFooter(
                            children=[
                                dbc.Button(
                                    cls.DELETE_BUTTON,
                                    color="danger",
                                    id=sdc.create_id(parent_id, cls.DELETE_BUTTON_ID),
                                    n_clicks=0,
                                ),
                            ],
                        ),
                    ],
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                ),
                sdc.get_child_layout(parent_id, cls.realized_offer_idx),
            ]
        )

    def close_modal(self, _: Optional[int] = None) -> "DeleteRealizedScrapOfferModalViewModel":
        return attr.evolve(self, is_open=False)

    def set_input_values_and_open(
        self,
        offer_idx: int,
        info_realized_offer: str,
        info_scrap_offers_to_unlock: str,
        info_scrap_offers_to_delete: str,
    ) -> "DeleteRealizedScrapOfferModalViewModel":
        return attr.evolve(
            self,
            is_open=True,
            realized_offer_idx=DataStoreViewModel(offer_idx),
            info_realized_offer=info_realized_offer,
            info_scrap_offers_to_unlock=info_scrap_offers_to_unlock,
            info_scrap_offers_to_delete=info_scrap_offers_to_delete,
        )

    def delete_realized_offer(
        self, _: int, ctx: ScrapPurchaseAppSource
    ) -> "DeleteRealizedScrapOfferModalViewModel":
        ctx.db_purchase_data_source.remove_realized_offer(self.offer_idx)
        return self.close_modal()
