from typing import Tuple

from scrap.models import RealizedScrapOffer, ScrapOfferData, ScrapOffer


def get_delete_offer_info(
    realized_offer_to_delete: RealizedScrapOffer, scrap_offer_data: ScrapOfferData
) -> Tuple[str, str]:
    def generate_scrap_offer_info(scrap_offer: ScrapOffer) -> str:
        return " ".join(
            str(val or "")
            for val in (
                scrap_offer.scrap_type,
                scrap_offer.supplier,
                scrap_offer.weight,
                scrap_offer.supplier_price,
                scrap_offer.override_price,
                scrap_offer.note,
            )
        )

    scrap_offer_uuid_list = realized_offer_to_delete.scrap_offer_uuid_list
    connected_scrap_offers = [
        scrap_offer for scrap_offer in scrap_offer_data if scrap_offer.uuid in scrap_offer_uuid_list
    ]
    scrap_offers_to_unlock = list()
    scrap_offers_to_delete = list()
    for scrap_offer in connected_scrap_offers:
        if scrap_offer.generated_from:
            scrap_offers_to_delete.append(scrap_offer)
        else:
            scrap_offers_to_unlock.append(scrap_offer)

    return (
        "\n".join([generate_scrap_offer_info(scrap_offer) for scrap_offer in scrap_offers_to_unlock]),
        "\n".join([generate_scrap_offer_info(scrap_offer) for scrap_offer in scrap_offers_to_delete]),
    )
