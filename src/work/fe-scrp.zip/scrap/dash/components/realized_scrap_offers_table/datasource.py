from typing import List, Optional, Tuple
import attr
from scrap_core import ScrapType

from scrap.models import RealizedScrapOfferData


@attr.s(frozen=True, auto_attribs=True)
class RealizedScrapOfferTableRowViewModel:
    scrap_type: Optional[ScrapType]
    zone: Optional[str]
    weight: Optional[float]
    supplier: Optional[str]
    price: Optional[float]
    note: Optional[str]
    scrap_offer_uuid_list: List[str]

    @property
    def table_data(self):
        return {**attr.asdict(self), "delete": ""}


def get_realized_scrap_offer_table_data(
    realized_scrap_offer_data: RealizedScrapOfferData,
) -> Tuple[RealizedScrapOfferTableRowViewModel, ...]:
    return tuple(
        RealizedScrapOfferTableRowViewModel(
            scrap_type=realized_scrap_offer.scrap_type,
            zone=realized_scrap_offer.zone,
            weight=realized_scrap_offer.weight,
            supplier=realized_scrap_offer.supplier,
            price=realized_scrap_offer.price,
            note=realized_scrap_offer.note,
            scrap_offer_uuid_list=realized_scrap_offer.scrap_offer_uuid_list,
        )
        for realized_scrap_offer in realized_scrap_offer_data
    )
