from typing import Any, Dict, Tuple
import attr
from dash import html, dash_table, dcc
from dash.dash_table.Format import Format, Scheme
import ussksdc as sdc
from scrap.dash.scrap_purchase_app.config import ScrapPurchaseAppConfig
from scrap.dash.components.realized_scrap_offers_table.calculations import get_delete_offer_info
from scrap.dash.components.realized_scrap_offers_table.modal import DeleteRealizedScrapOfferModalViewModel
from scrap.dash.components.realized_scrap_offers_table.datasource import get_realized_scrap_offer_table_data
from scrap.dash.components.common import ScrapPurchaseAppSource
from django.urls import reverse


@attr.s(frozen=True, slots=True)
class RealizedScrapOfferTableViewModel:
    COMPONENT_ID = "table"
    DELETE_OFFER_MODAL_ID = "delete-modal"
    DELETE_BUTTON_ID = "delete"
    EXPORT_ID = "export"

    EXPORT = "Export"

    delete_offer_modal: DeleteRealizedScrapOfferModalViewModel = sdc.child_component(
        DELETE_OFFER_MODAL_ID, default=DeleteRealizedScrapOfferModalViewModel()
    )

    @classmethod
    def get_output_fields(cls) -> sdc.OutputFields:
        return (
            sdc.OutputField(cls.COMPONENT_ID, "data", cls.get_table_data),
            sdc.OutputField(cls.EXPORT_ID, "href", cls.update_export_realized_scrap_offers_button),
        )

    @classmethod
    def get_input_fields(cls) -> sdc.InputFields:
        return (sdc.InputField(cls.COMPONENT_ID, "active_cell", cls.click_on_realized_offer_table),)

    @classmethod
    def get_layout(cls, parent_id: str, config: ScrapPurchaseAppConfig) -> html.Div:
        return html.Div(
            children=[
                html.H4("Realizované ponuky"),
                dash_table.DataTable(
                    id=sdc.create_id(parent_id, cls.COMPONENT_ID),
                    columns=cls.get_realized_scrap_offers_columns(),
                    data=[],
                    hidden_columns=["delete"] if config.read_only else [],
                ),
                html.Div(
                    hidden=config.read_only,
                    children=dcc.Link(
                        cls.EXPORT,
                        id=sdc.create_id(parent_id, cls.EXPORT_ID),
                        href="#",
                        target="_blank",
                        className="btn btn-outline-info btn-sm",
                    ),
                    className="text-center",
                ),
                sdc.get_child_layout(parent_id, cls.delete_offer_modal),
            ],
            className="realized-wrapper",
        )

    @classmethod
    def get_realized_scrap_offers_columns(cls, read_only: bool = False, debug_mode: bool = False):
        realized_scrap_offers_columns = list()
        if not read_only:
            realized_scrap_offers_columns.extend(
                [
                    {"name": "", "id": "delete", "type": "text", "editable": False},
                ]
            )
        if debug_mode:
            realized_scrap_offers_columns.extend(
                [
                    {"name": "SO-id-list", "id": "scrap_offer_uuid_list", "type": "text", "editable": False},
                ]
            )
        realized_scrap_offers_columns.extend(
            [
                {
                    "name": "Typ šrotu",
                    "id": "scrap_type",
                    "type": "text",
                    "editable": False,
                },
                {
                    "name": "Zóna",
                    "id": "zone",
                    "type": "text",
                    "editable": False,
                },
                {
                    "name": "Objem",
                    "id": "weight",
                    "type": "numeric",
                    "format": Format(scheme=Scheme.fixed, precision=3, symbol="$", symbol_suffix=" t"),
                    "editable": False,
                },
                {
                    "name": "Dodávateľ",
                    "id": "supplier",
                    "type": "text",
                    "editable": False,
                },
                {
                    "name": "Realizovaná cena",
                    "id": "price",
                    "type": "numeric",
                    "editable": False,
                    "format": Format(scheme=Scheme.fixed, precision=2, symbol="$", symbol_suffix=" €"),
                },
                {
                    "name": "Poznámka",
                    "id": "note",
                    "type": "text",
                    "editable": False,
                },
            ]
        )
        return realized_scrap_offers_columns

    def get_table_data(self, ctx: ScrapPurchaseAppSource) -> Tuple[Dict[str, Any], ...]:
        return tuple(
            realized_offer.table_data
            for realized_offer in get_realized_scrap_offer_table_data(
                ctx.db_purchase_data_source.get_realized_scrap_offer_data()
            )
        )

    def click_on_realized_offer_table(
        self, active_cell: Dict, ctx: ScrapPurchaseAppSource
    ) -> "RealizedScrapOfferTableViewModel":
        realized_offer_idx = active_cell["row"]
        data = ctx.db_purchase_data_source.get_realized_scrap_offer_data()
        realized_offer = data[realized_offer_idx]
        info_to_unlock, info_to_delete = get_delete_offer_info(
            realized_offer, ctx.db_purchase_data_source.get_scrap_offer_data()
        )
        if active_cell["column_id"] == self.DELETE_BUTTON_ID:
            return attr.evolve(
                self,
                delete_offer_modal=self.delete_offer_modal.set_input_values_and_open(
                    realized_offer_idx,
                    " ".join(
                        str(val or "")
                        for val in (
                            realized_offer.scrap_type,
                            realized_offer.supplier,
                            realized_offer.weight,
                            realized_offer.price,
                            realized_offer.note,
                        )
                    ),
                    info_to_unlock,
                    info_to_delete,
                ),
            )
        return self

    def update_export_realized_scrap_offers_button(self, ctx: ScrapPurchaseAppSource) -> str:
        return reverse(
            "scrap:export_realized_offers_to_excel",
            kwargs={"scrap_purchase_record_id": ctx.scrap_purchase_id},
        )
