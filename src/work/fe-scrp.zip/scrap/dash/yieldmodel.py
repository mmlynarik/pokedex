import datetime
import functools
import json
from ast import literal_eval
from typing import Any, Dict
from dateutil.relativedelta import relativedelta

import dash
from dash.dependencies import Input, Output
import attr
import cattr
from dash import dcc, html
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from django_plotly_dash import DjangoDash

from common.dash import create_main_div
from scrap_core import SUPPORTED_SCRAP_TYPES
from scrap_core.yieldmodel.yield_model_precise import YieldEstimate


converter = cattr.Converter()
converter.register_unstructure_hook(pd.DataFrame, lambda data_frame: data_frame.to_json(date_format="iso"))
converter.register_structure_hook(pd.DataFrame, lambda serialized, _: pd.read_json(serialized))


yield_model_app = DjangoDash("YieldModel", serve_locally=True, add_bootstrap_links=True)

INITIAL_DATA_STORE_ID = "initial-data"


def clip_and_normalize(data: pd.Series) -> pd.Series:
    return data.clip(0.0, 1.0) * 100.0


STD_MULTIPLIER = 2.0


def get_yield_estimates_from_raw_data(data: pd.DataFrame) -> Dict[Any, YieldEstimate]:
    return {key: YieldEstimate(row.Yields, row.Stds) for key, row in data.iterrows()}


def preprocess_yield_estimates(estimates: Dict[Any, YieldEstimate], counts: Dict[Any, int]) -> pd.DataFrame:
    data = pd.DataFrame(
        {
            "Yields": clip_and_normalize(
                pd.Series({key: estimate.yield_mean for key, estimate in estimates.items()})
            ),
            "Lower": clip_and_normalize(
                pd.Series(
                    {key: estimate.get_lower_bound(STD_MULTIPLIER) for key, estimate in estimates.items()}
                )
            ),
            "Upper": clip_and_normalize(
                pd.Series(
                    {key: estimate.get_upper_bound(STD_MULTIPLIER) for key, estimate in estimates.items()}
                )
            ),
            "plusminus": clip_and_normalize(
                pd.Series({key: estimate.yield_std * STD_MULTIPLIER for key, estimate in estimates.items()})
            ),
            "Counts": pd.Series({key: counts[key] for key, _ in estimates.items()}),
        }
    )

    data[data["Counts"] == 0] = (50, 0, 100, 50, 0)
    data["ErrorU"] = data["Upper"] - data["Yields"]
    data["ErrorL"] = data["Yields"] - data["Lower"]
    return data


def preprocess_data_for_comparison_graph(data: pd.DataFrame) -> pd.DataFrame:
    yield_estimates = get_yield_estimates_from_raw_data(data)
    data = preprocess_yield_estimates(yield_estimates, data.Counts.to_dict())
    data["Texts"] = [f"{x} {values.Yields:.1f}% +/− {values.plusminus:.1f}%" for x, values in data.iterrows()]
    data = data.set_index("Texts")
    data = data.sort_values("Texts")
    return data


def preprocess_data_for_weighted_avg_graph(data: pd.DataFrame, window_size: int) -> pd.DataFrame:
    data["date"] = pd.Series(get_dates(data, window_size), index=data.index)
    data.columns = ["mean", "std", "mean_oc1", "std_oc1", "mean_oc2", "std_oc2", "date"]
    return data


def draw_yield_model_weighted_avg_graph(data: pd.DataFrame, window_size: int):
    reordered = data.set_index(
        pd.MultiIndex.from_tuples([literal_eval(x) for x in data.index], names=["month", "year"])
    )
    data = preprocess_data_for_weighted_avg_graph(reordered, window_size)
    fig = go.Figure(
        data=[
            go.Bar(
                name="OC1 & OC2",
                x=data["date"],
                y=data["mean"],
                error_y=dict(type="data", array=list(2 * data["std"])),
            ),
            go.Bar(
                name="OC1",
                x=data["date"],
                y=data["mean_oc1"],
                error_y=dict(type="data", array=list(2 * data["std_oc1"])),
            ),
            go.Bar(
                name="OC2",
                x=data["date"],
                y=data["mean_oc2"],
                error_y=dict(type="data", array=list(2 * data["std_oc2"])),
            ),
        ]
    )
    fig.update_layout(
        width=1500,
        height=500,
        title="Vážený priemer výťažkov šrotov pri zvolenej veľkosti okna",
        xaxis_tickangle=45,
        barmode="group",
    )
    fig.update_yaxes(visible=True, title="", range=(0.8, 1))
    fig.update_xaxes(visible=True, title="")
    return fig


def draw_yield_model_comparison_graph(comparison_plot_data: pd.DataFrame):
    fig = px.scatter(
        preprocess_data_for_comparison_graph(comparison_plot_data),
        y="Yields",
        error_y="ErrorU",
        error_y_minus="ErrorL",
    )
    fig.update_layout(
        showlegend=False,
        width=1500,
        height=500,
        xaxis_tickangle=45,
        title="Porovnanie modelu výťažkov šrotov pre dané časové obdobie",
    )
    fig.update_yaxes(visible=True, title="", range=(-5, 105))
    fig.update_xaxes(visible=True, title="")
    return fig


def get_dates(data: pd.DataFrame, window_size: int) -> pd.Series:
    dates_list = [datetime.date(year, month, 1) for month, year in data.index]
    if window_size == 1:
        return [x.strftime("%b %Y") for x in dates_list]
    return [
        x.strftime("%b %Y") + " - " + (x + relativedelta(months=window_size - 1)).strftime("%b %Y")
        for x in dates_list
    ]


def create_warnings_ul(data: pd.DataFrame) -> html.Ul:
    list_of_warnings = data.values.tolist()
    return html.Ul([html.Li(warning) for warning in list_of_warnings])


def draw_yield_model_graph_for_window(graph_data: pd.DataFrame, window_size: int):
    reordered = graph_data.set_index(
        pd.MultiIndex.from_tuples(
            [literal_eval(x) for x in graph_data.index], names=["month", "year", "scrap_type"]
        )
    ).reorder_levels([2, 0, 1])
    fig = go.Figure()
    for scrap_type in SUPPORTED_SCRAP_TYPES:
        data_for_type = reordered.loc[scrap_type]
        yield_estimates = get_yield_estimates_from_raw_data(data_for_type)
        preprocessed_for_type = preprocess_yield_estimates(yield_estimates, data_for_type.Counts.to_dict())
        fig.add_trace(
            go.Scatter(
                x=get_dates(preprocessed_for_type, window_size),
                y=preprocessed_for_type.Yields,
                visible="legendonly",
                error_y={
                    "type": "data",
                    "array": preprocessed_for_type.ErrorU,
                    "arrayminus": preprocessed_for_type.ErrorL,
                    "symmetric": False,
                },
                name=scrap_type,
            )
        )
    fig.update_layout(
        width=1500,
        height=500,
        title="Výťažky šrotov pre dané časové obdobie pri zvolenej veľkosti okna",
        xaxis_tickangle=45,
    )
    fig.update_yaxes(range=(-5, 105))
    return fig


@attr.s(auto_attribs=True, slots=True, frozen=True, cache_hash=True)
class YieldModelData:
    comparison_graph_data: pd.DataFrame
    graph_data: pd.DataFrame
    window_size: int
    average_graph_data: pd.DataFrame
    frontend_warnings: pd.DataFrame

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self))

    def to_context_data(self) -> dict:
        # Better will be to assign data directly to components
        # Unfortunatelly it does not work for dash tables now :( so we need to use this hack
        return {INITIAL_DATA_STORE_ID: {"children": self.serialize()}}

    @classmethod
    @functools.lru_cache()
    def deserialize(cls, serialized: str) -> "YieldModelData":
        return converter.structure(json.loads(serialized), YieldModelData)


MAIN_DIV_ID = "yield-model"

yield_model_app.layout = create_main_div(
    MAIN_DIV_ID,
    [
        html.Div(id=INITIAL_DATA_STORE_ID, children="", style={"display": "none"}),
        dcc.Loading(
            [
                html.Div([dcc.Graph(id="comparison_plot", figure=go.Figure())]),
                html.Div(
                    [dcc.Graph(id="window_plot", figure=go.Figure())],
                ),
                html.Div(
                    [dcc.Graph(id="weighted_avg_plot", figure=go.Figure())],
                ),
                html.Details(
                    [
                        html.Summary(style={"color": "red", "fontSize": "25px"}, id="summary"),
                        html.Div(id="warnings"),
                    ]
                ),
            ]
        ),
    ],
)


# Callback functions
@yield_model_app.callback(
    [
        Output("comparison_plot", "figure"),
        Output("window_plot", "figure"),
        Output("weighted_avg_plot", "figure"),
        Output("summary", "children"),
        Output("warnings", "children"),
    ],
    [Input(INITIAL_DATA_STORE_ID, "children")],
)
def update_page(serialized_data):
    if (serialized_data is None) or (serialized_data == ""):
        return dash.no_update, dash.no_update

    data = YieldModelData.deserialize(serialized_data)
    return (
        draw_yield_model_comparison_graph(data.comparison_graph_data),
        draw_yield_model_graph_for_window(data.graph_data, data.window_size),
        draw_yield_model_weighted_avg_graph(data.average_graph_data, data.window_size),
        f"Warnings({len(data.frontend_warnings)})",
        create_warnings_ul(data.frontend_warnings),
    )
