from math import isfinite

from rest_framework import serializers

from scrap_core.optimization.datamodel import SCRAP_LOCATION


def positive_finite(value):
    if not isfinite(value) or value <= 0:
        raise serializers.ValidationError("A valid positive integer is required.")


def non_negative_finite(value):
    if not isfinite(value) or value < 0:
        raise serializers.ValidationError("A valid non-negative integer is required.")


def outdoor_indoor(value):
    if value not in SCRAP_LOCATION:
        raise serializers.ValidationError(f"Scrap location must be one of {SCRAP_LOCATION}.")


class HeatInputsSerializer(serializers.Serializer):
    grade_planned = serializers.IntegerField(validators=[positive_finite])
    total_scrap_weight = serializers.IntegerField(validators=[positive_finite])
    pig_iron_weight = serializers.IntegerField(validators=[positive_finite])
    pig_iron_chem = serializers.DictField(child=serializers.FloatField(validators=[positive_finite]))
    lower_bounds = serializers.DictField(child=serializers.IntegerField(validators=[non_negative_finite]))
    upper_bounds = serializers.DictField(child=serializers.IntegerField(validators=[non_negative_finite]))


class AvailableScrapsSerializer(serializers.Serializer):
    weight = serializers.IntegerField(validators=[positive_finite])
    location = serializers.CharField(validators=[outdoor_indoor])


class MultipleHeatsOptimizationInputSerializer(serializers.Serializer):
    loading_station_id = serializers.IntegerField(allow_null=False, validators=[positive_finite])
    available_scraps = serializers.DictField(child=AvailableScrapsSerializer(), allow_empty=False)
    heats = serializers.ListField(child=HeatInputsSerializer(), allow_empty=False)
