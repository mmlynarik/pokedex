import logging
from typing import Protocol, Tuple, Union, Iterable, Callable, Hashable, Set, TypeVar, Optional

from django.contrib.auth.models import User
from django.db import models
from simple_history.models import HistoricalRecords

from scrap_core.optimization.datamodel import ScrapExclusiveGroup
from scrap_core.optimization.relaxable_limits import (
    RelaxableRiskLimit,
    RelaxableValue,
    RelaxableLowerSummingLimit,
    RelaxableUpperSummingLimit,
)

from scrap.models.groups_models import GradeGroup, ScrapGroup, grade_group_to_tuple, scrap_group_to_tuple
from scrap_core.utils import group_by

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


class HasLoadingStationReference(Protocol):
    @property
    def loadingstation_set(self) -> models.manager.Manager: ...


class LoadingStationMixin:
    @property
    def affected_loading_stations(self: HasLoadingStationReference) -> list:
        return sorted(station.name for station in self.loadingstation_set.all())

    @property
    def affected_loading_stations_ids(self: HasLoadingStationReference) -> Tuple[int, ...]:
        return tuple(sorted(station.id for station in self.loadingstation_set.all()))


class ScrapExclusiveGroupSetting(models.Model, LoadingStationMixin):
    name = models.CharField(blank=False, null=False, max_length=64)
    scrap_types = models.ForeignKey(ScrapGroup, on_delete=models.PROTECT)
    comment = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        User, related_name="scrap_exclusive_group_created_by", on_delete=models.PROTECT
    )
    history = HistoricalRecords()

    def __str__(self) -> str:
        return f"{self.name}"

    def to_scrap_exclusive_group(self) -> ScrapExclusiveGroup:
        scrap_definitions = self.scrap_types.scrap_ids.all()
        return ScrapExclusiveGroup(
            name=self.name,
            scrap_types=tuple(scrap.scrap_type for scrap in scrap_definitions),  # type: ignore
        )


class RelaxableRiskLimitSetting(models.Model, LoadingStationMixin):
    name = models.CharField(blank=False, null=False, max_length=64)
    grade_ids = models.ForeignKey(GradeGroup, on_delete=models.PROTECT)
    comment = models.TextField(blank=True, default="")
    Cr_aim = models.FloatField(default=0.01)
    Cr_allowed = models.FloatField(default=0.01)
    Cu_aim = models.FloatField(default=0.01)
    Cu_allowed = models.FloatField(default=0.01)
    Mo_aim = models.FloatField(default=0.01)
    Mo_allowed = models.FloatField(default=0.01)
    Ni_aim = models.FloatField(default=0.01)
    Ni_allowed = models.FloatField(default=0.01)
    S_aim = models.FloatField(default=0.15)
    S_allowed = models.FloatField(default=0.15)
    Si_aim = models.FloatField(default=0.01)
    Si_allowed = models.FloatField(default=0.01)
    Sn_aim = models.FloatField(default=0.01)
    Sn_allowed = models.FloatField(default=0.01)
    history = HistoricalRecords()

    def __str__(self):
        return self.name

    def to_relaxable_limit(self) -> RelaxableRiskLimit:
        # see comment above definition of the function
        # `scrap_relaxable_risk_limit_setting_to_relaxable_risk_limit`
        return risk_setting_to_risk_limit(self)

    @classmethod
    def from_relaxable_limit(
        cls, limit: RelaxableRiskLimit, name: str, grade_ids: GradeGroup, comment: str = ""
    ) -> "RelaxableRiskLimitSetting":
        return cls(
            name=name,
            grade_ids=grade_ids,
            comment=comment,
            Cr_aim=limit.Cr.aim,
            Cr_allowed=limit.Cr.allowed,
            Cu_aim=limit.Cu.aim,
            Cu_allowed=limit.Cu.allowed,
            Mo_aim=limit.Mo.aim,
            Mo_allowed=limit.Mo.allowed,
            Ni_aim=limit.Ni.aim,
            Ni_allowed=limit.Ni.allowed,
            S_aim=limit.S.aim,
            S_allowed=limit.S.allowed,
            Si_aim=limit.Si.aim,
            Si_allowed=limit.Si.allowed,
            Sn_aim=limit.Sn.aim,
            Sn_allowed=limit.Sn.allowed,
        )


class RelaxableSummingLimitSetting(models.Model, LoadingStationMixin):
    class Meta:
        abstract = True

    name = models.CharField(blank=False, null=False, max_length=64)
    grade_ids = models.ForeignKey(GradeGroup, on_delete=models.PROTECT)
    scrap_types = models.ForeignKey(ScrapGroup, on_delete=models.PROTECT)
    comment = models.TextField(blank=True, default="")


class RelaxableUpperSummingLimitSetting(RelaxableSummingLimitSetting):
    weight_aim = models.IntegerField(default=10**6)
    weight_allowed = models.IntegerField(default=10**6)
    ratio_aim = models.FloatField(default=1)
    ratio_allowed = models.FloatField(default=1)
    history = HistoricalRecords()

    def __str__(self) -> str:
        return f"{self.name} upper"

    def to_relaxable_limit(self) -> RelaxableUpperSummingLimit:
        return upper_setting_to_upper_limit(self)


class RelaxableLowerSummingLimitSetting(RelaxableSummingLimitSetting):
    weight_aim = models.IntegerField(default=0)
    weight_allowed = models.IntegerField(default=0)
    ratio_aim = models.FloatField(default=0)
    ratio_allowed = models.FloatField(default=0)
    history = HistoricalRecords()

    def __str__(self) -> str:
        return f"{self.name} lower"

    def to_relaxable_limit(self) -> RelaxableLowerSummingLimit:
        return lower_setting_to_lower_limit(self)


# in migrations, django uses so-called historical models instead of models defined above,
# consequently methods of these models are not available. Therefore, it is necessary to
# have the following conversions defined outside model classes. See
# https://docs.djangoproject.com/en/4.1/topics/migrations/#historical-models
def risk_setting_to_risk_limit(
    limit_setting: RelaxableRiskLimitSetting,
) -> RelaxableRiskLimit:
    return RelaxableRiskLimit(
        name=limit_setting.name,
        Cr=RelaxableValue(limit_setting.Cr_aim, limit_setting.Cr_allowed),
        Cu=RelaxableValue(limit_setting.Cu_aim, limit_setting.Cu_allowed),
        Mo=RelaxableValue(limit_setting.Mo_aim, limit_setting.Mo_allowed),
        Ni=RelaxableValue(limit_setting.Ni_aim, limit_setting.Ni_allowed),
        S=RelaxableValue(limit_setting.S_aim, limit_setting.S_allowed),
        Si=RelaxableValue(limit_setting.Si_aim, limit_setting.Si_allowed),
        Sn=RelaxableValue(limit_setting.Sn_aim, limit_setting.Sn_allowed),
    )


def lower_setting_to_lower_limit(setting: RelaxableLowerSummingLimitSetting) -> RelaxableLowerSummingLimit:
    return RelaxableLowerSummingLimit(
        name=setting.name,
        scrap_types=scrap_group_to_tuple(setting.scrap_types),
        weight_limit=RelaxableValue(setting.weight_aim, setting.weight_allowed),
        ratio=RelaxableValue(setting.ratio_aim, setting.ratio_allowed),
    )


def upper_setting_to_upper_limit(setting: RelaxableUpperSummingLimitSetting) -> RelaxableUpperSummingLimit:
    return RelaxableUpperSummingLimit(
        name=setting.name,
        scrap_types=scrap_group_to_tuple(setting.scrap_types),
        weight_limit=RelaxableValue(setting.weight_aim, setting.weight_allowed),
        ratio=RelaxableValue(setting.ratio_aim, setting.ratio_allowed),
    )


L = TypeVar(
    "L",
    bound=Union[
        RelaxableRiskLimitSetting, RelaxableLowerSummingLimitSetting, RelaxableUpperSummingLimitSetting
    ],
)


S = TypeVar(
    "S",
    bound=Union[RelaxableLowerSummingLimitSetting, RelaxableUpperSummingLimitSetting],
)


def get_relevant_limit_settings(
    limits: Iterable[L], grade_id: Optional[int], key_getter: Callable[[L], Hashable]
) -> Tuple[L, ...]:
    groups = group_by(limits, key_getter)

    relevant: Set[L] = set()

    for group in groups.values():

        if grade_id is not None:
            # grade id is specified, look for applicable limits only
            specific = tuple(lim for lim in group if grade_id in grade_group_to_tuple(lim.grade_ids))
        else:
            # if grade id is not specified, look for any non-default limit
            specific = tuple(lim for lim in group if grade_group_to_tuple(lim.grade_ids))

        # If there is at least one specific limit, use specific limits and ignore defaults
        if specific:
            relevant.update(specific)
        else:
            relevant.update(lim for lim in group if not grade_group_to_tuple(lim.grade_ids))

    return tuple(relevant)


def get_relevant_relaxable_risk_limits_settings(
    limits: Iterable[RelaxableRiskLimitSetting], grade_id: int
) -> Tuple[RelaxableRiskLimitSetting, ...]:
    return tuple(
        lim
        for lim in limits
        if grade_id in grade_group_to_tuple(lim.grade_ids) or not grade_group_to_tuple(lim.grade_ids)
    )


def resolve_risk_limit_settings(limits: Iterable[RelaxableRiskLimitSetting]) -> RelaxableRiskLimit:
    def resolve_values_to_minimum(values: Iterable[RelaxableValue]) -> RelaxableValue:
        values_list = list(values)

        return RelaxableValue(
            aim=min(val.aim for val in values_list),
            allowed=min(val.allowed for val in values_list),
        )

    def resolve_values_to_first_active(values: Iterable[RelaxableValue]) -> RelaxableValue:
        values_list = list(values)

        return RelaxableValue(
            aim=min((val for val in values_list if val.aim < 1), key=values_list.index).aim,
            allowed=min((val for val in values_list if val.allowed < 1), key=values_list.index).allowed,
        )

    def resolve_to_minimum(limits_: Iterable[RelaxableRiskLimitSetting]) -> RelaxableRiskLimit:

        risk_limits = [risk_setting_to_risk_limit(lim) for lim in limits_]

        return RelaxableRiskLimit(
            name=f'minimum({", ".join(limit.name for limit in risk_limits)})',
            Cr=resolve_values_to_minimum(lim.Cr for lim in risk_limits),
            Cu=resolve_values_to_minimum(lim.Cu for lim in risk_limits),
            Mo=resolve_values_to_minimum(lim.Mo for lim in risk_limits),
            Ni=resolve_values_to_minimum(lim.Ni for lim in risk_limits),
            S=resolve_values_to_minimum(lim.S for lim in risk_limits),
            Sn=resolve_values_to_minimum(lim.Sn for lim in risk_limits),
            Si=resolve_values_to_minimum(lim.Si for lim in risk_limits),
        )

    def resolve_to_first_active(limits_: Iterable[RelaxableRiskLimit]) -> RelaxableRiskLimit:
        limits_list = list(limits_)

        return RelaxableRiskLimit(
            name=", ".join(limit.name for limit in limits_list),
            Cr=resolve_values_to_first_active(lim.Cr for lim in limits_list),
            Cu=resolve_values_to_first_active(lim.Cu for lim in limits_list),
            Mo=resolve_values_to_first_active(lim.Mo for lim in limits_list),
            Ni=resolve_values_to_first_active(lim.Ni for lim in limits_list),
            S=resolve_values_to_first_active(lim.S for lim in limits_list),
            Sn=resolve_values_to_first_active(lim.Sn for lim in limits_list),
            Si=resolve_values_to_first_active(lim.Si for lim in limits_list),
        )

    # 0 - default limits, 1 - one-grade limits, 2 - multi-grade limits
    limit_groups = group_by(
        items=limits,
        key_getter=lambda lim: (
            len(grade_group_to_tuple(lim.grade_ids)) if len(grade_group_to_tuple(lim.grade_ids)) < 2 else 2
        ),
    )

    # one-grade limits have higher priority than multi-grade limits
    specific_limits = [
        resolve_to_minimum(group) for group in (limit_groups.get(1), limit_groups.get(2)) if group is not None
    ]
    try:
        default_limit = resolve_to_minimum(limit_groups[0])
    except KeyError:
        log.exception("Default risk limit not found")
        raise

    # more specific limit has higher priority than default
    return resolve_to_first_active(specific_limits + [default_limit])


def get_relevant_relaxable_summing_limits_settings(
    limits: Iterable[S], grade_id: Optional[int]
) -> Tuple[S, ...]:
    # summing limits are grouped per affected scrap types
    return get_relevant_limit_settings(
        limits, grade_id, lambda limit: frozenset(scrap_group_to_tuple(limit.scrap_types))
    )
