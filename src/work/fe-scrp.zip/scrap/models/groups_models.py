from typing import cast, Tuple


from immutables import Map
from django.db import models

from scrap_core import ScrapType, ScrapMix, ScrapMixMapping


class GradeDefinition(models.Model):
    grade_id = models.IntegerField(primary_key=True)

    def __str__(self):
        return str(self.grade_id)


class GradeGroup(models.Model):
    group_name = models.CharField(max_length=32, unique=True)
    grade_ids = models.ManyToManyField(GradeDefinition, blank=True)
    comment = models.CharField(max_length=255, blank=True)

    @property
    def all_uses(self):
        return [
            *self.relaxableuppersumminglimitsetting_set.all(),
            *self.relaxablelowersumminglimitsetting_set.all(),
            *self.relaxablerisklimitsetting_set.all(),
        ]

    def __str__(self):
        return self.group_name

    def to_tuple(self) -> Tuple[int, ...]:
        return grade_group_to_tuple(self)


# kept outside of model so this function (and related code) can be used in migrations
def grade_group_to_tuple(group: GradeGroup) -> Tuple[int, ...]:
    return tuple(item.grade_id for item in group.grade_ids.all())


class ScrapDefinition(models.Model):
    tms_id = models.IntegerField(null=True)  # XXX scrap does not have tms id
    scrap_type = models.CharField(primary_key=True, max_length=16)
    description = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.scrap_type


class ScrapGroup(models.Model):
    group_name = models.CharField(max_length=32, unique=True)
    scrap_ids = models.ManyToManyField(ScrapDefinition, blank=True)
    comment = models.CharField(max_length=255, blank=True)

    @property
    def all_uses(self):
        return [
            *self.relaxableuppersumminglimitsetting_set.all(),
            *self.relaxablelowersumminglimitsetting_set.all(),
            *self.scrapexclusivegroupsetting_set.all(),
        ]

    def __str__(self):
        return self.group_name

    def to_tuple(self) -> Tuple[ScrapType, ...]:
        return scrap_group_to_tuple(self)


# kept outside of model so this function (and related code) can be used in migrations
def scrap_group_to_tuple(group: ScrapGroup) -> Tuple[ScrapType, ...]:
    return tuple(cast(ScrapType, item.scrap_type) for item in group.scrap_ids.all())


class ScrapFacility(models.Model):
    name = models.CharField(max_length=32, unique=True)
    facility_id = models.IntegerField(unique=True)
    outdoor = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Scrap facilities"

    def __str__(self):
        return f"{self.name}"


class ScrapMixDefinition(models.Model):
    name = models.CharField(max_length=64, unique=True)
    display_name = models.CharField(max_length=64)
    exhausted = models.BooleanField(default=False)

    def __str__(self):
        return self.name

    def get_scrap_type_mapping(self) -> Map[ScrapType, float]:
        return Map(
            {
                scrap_mix_ratio.scrap_type.scrap_type: scrap_mix_ratio.ratio
                for scrap_mix_ratio in self.scrapmixratio_set.all()
            }
        )

    @classmethod
    def get_identifiers(cls, exclude_exhausted: bool = False) -> Tuple[Tuple[ScrapMix, str], ...]:
        if exclude_exhausted:
            definitions = cls.objects.filter(exhausted=False)
        else:
            definitions = cls.objects.all()
        return tuple((ScrapMix(mix.name), mix.display_name) for mix in definitions)

    @classmethod
    def get_scrap_mix_mapping(cls) -> ScrapMixMapping:
        return Map(
            {
                ScrapMix(definition.name): definition.get_scrap_type_mapping()
                for definition in cls.objects.filter(exhausted=False)
            }
        )


class ScrapMixRatio(models.Model):
    scrap_mix_definition = models.ForeignKey(ScrapMixDefinition, on_delete=models.PROTECT)
    scrap_type = models.ForeignKey(ScrapDefinition, on_delete=models.PROTECT)
    ratio = models.FloatField()

    def __str__(self):
        return self.scrap_mix_definition.name + "-" + f"{self.ratio:.2f}" + "-" + self.scrap_type.scrap_type
