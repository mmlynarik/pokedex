# TODO model_settings django model
#   or add loading_station fk to OptimizationInput and use model_settings from loading station, however
#   refactor exclusive scrap groups outside of model settings (similar to risk/summing limits)
import collections
import copy
import functools
import itertools
import json
import logging
import re
from datetime import date, datetime
from functools import lru_cache
from typing import Collection, List, Optional, Sequence, Tuple

import attr
import cachetools as ct
import django.utils.timezone
from common.models import CustomSerializationField
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.core.validators import MinValueValidator
from django.db import models, transaction
from django.db.models import QuerySet, UniqueConstraint
from immutables import Map
from returns.maybe import Maybe, Nothing
from returns.result import Failure, Result, Success

from scrap.dash.database_api import steel_grades
from scrap.models.groups_models import GradeDefinition, GradeGroup, ScrapFacility
from scrap.models.model_settings import (
    RelaxableLowerSummingLimitSetting,
    RelaxableRiskLimitSetting,
    RelaxableUpperSummingLimitSetting,
    ScrapExclusiveGroupSetting,
    lower_setting_to_lower_limit,
    resolve_risk_limit_settings,
    upper_setting_to_upper_limit,
)
from scrap.models.printer_models import FtpConnection, Printer
from scrap.models.user_models import Operator
from scrap_core import Chem, ScrapBounds
from scrap_core import ScrapCharge as ScrapCoreScrapCharge
from scrap_core.blendmodel import ScrapBlendModelOutput
from scrap_core.correctiontechnologiesmodel import (
    CorrectionTechnologiesModelOutput,
    CorrectionTechnologyType,
)
from scrap_core.datamodel import RawFeChem
from scrap_core.optimization.datamodel import (
    AvailableScrap as AvailableScrapCore,
    AvailableScraps,
    ChemRiskLevels,
    HeatInputs,
    HeatPlan,
    ModelSettings,
    MultipleHeatsOptimizationInput,
    MultipleHeatsOptimizationOutput,
    ScrapMixLimit,
    ScrapMixLimits,
    converter,
    OUTDOOR_SCRAP_NAME,
    INDOOR_SCRAP_NAME,
)
from scrap_core.utils import elementwise_sum


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())

# copied from json.decoder
FLAGS = re.VERBOSE | re.MULTILINE | re.DOTALL
WHITESPACE = re.compile(r"[ \t\n\r]*", FLAGS)

DEFAULT_SCRAP_WEIGHT = 36000
DEFAULT_PIG_IRON_WEIGHT = 150000
SCRAP_CHARGE_LOWER_BOUND = 75.0  # in %

CHANGE_LIMITS_OPERATOR_DECISION = "Change limits"
CANCEL_CHARGE_OPERATOR_DECISION = "Dismiss"
LOADED_CHARGE_OPERATOR_DECISION = "Loaded"


converter = copy.deepcopy(converter)

converter.register_unstructure_hook(CorrectionTechnologyType, lambda ctt: ctt.value)
converter.register_structure_hook(CorrectionTechnologyType, lambda value, _: CorrectionTechnologyType(value))

converter.register_unstructure_hook(bool, int)
converter.register_structure_hook(bool, lambda data, _: bool(data))

converter.register_unstructure_hook(datetime, lambda datetime_: datetime_.timestamp())
converter.register_structure_hook(datetime, lambda timestamp, _: datetime.fromtimestamp(timestamp))

converter.register_unstructure_hook(date, lambda date_: date_.strftime("%Y-%m-%d"))
converter.register_structure_hook(date, lambda date_str, _: date(*map(int, date_str.split("-"))))


def unstructure_corrtechmodeloutput(data: CorrectionTechnologiesModelOutput) -> list:
    return converter.unstructure(list(data.correction_technologies_probas.items()))


def structure_corrtechmodeloutput(unstructured: list, _) -> CorrectionTechnologiesModelOutput:
    return CorrectionTechnologiesModelOutput(
        Map(converter.structure(unstructured, List[Tuple[Tuple[CorrectionTechnologyType, float], float]])),
    )


converter.register_unstructure_hook(CorrectionTechnologiesModelOutput, unstructure_corrtechmodeloutput)
converter.register_structure_hook(CorrectionTechnologiesModelOutput, structure_corrtechmodeloutput)

converter.register_unstructure_hook(Map, lambda data: converter.unstructure(dict(data)))
converter.register_structure_hook(Map, lambda data, _: Map(data))


@attr.frozen
class ScrapChargeInputsSnapshot:
    grade_id: Optional[int] = attr.ib(default=None)
    basket_ids: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    switched_basket_ids: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    total_scrap_weight: Optional[int] = attr.ib(default=None)
    pig_iron_weight: Optional[int] = attr.ib(default=None)
    raw_fe_chem: RawFeChem = attr.ib(default=RawFeChem())
    scrap_limits: ScrapMixLimits = attr.ib(default=())


@attr.frozen
class OptimizationDisplayDataV2:
    optimization_id: int
    percentage_done: float = 0.0
    result: Optional[MultipleHeatsOptimizationOutput] = None
    comment: Optional[str] = None  # -> ScrapCharge
    operator_decision: Optional[str] = None  # -> ScrapCharge
    corr_tech_model_output: Optional[CorrectionTechnologiesModelOutput] = None  # -> OptResult
    blend_model_output: Optional[ScrapBlendModelOutput] = None  # -> OptResult
    used_predicted_chems: Tuple[Chem, ...] = ()  # -> OptRes
    warnings: Tuple[str, ...] = ()  # -> OptResult
    inputs_snapshot: Optional[ScrapChargeInputsSnapshot] = attr.ib(default=None)  # -> ScrapCharge

    def is_running(self):
        return self.result is None

    def is_done(self):
        return (self.result is not None) and (self.result.error is None)

    def is_error(self):
        return (self.result is not None) and (self.result.error is not None)

    def has_operator_decision(self):
        return self.operator_decision is not None

    def has_result_error(self):
        if self.result is None:
            return False
        return self.result.error is not None

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    def from_optimization_result(cls, result) -> "OptimizationDisplayDataV2":
        return cls(
            optimization_id=result.pk,
            percentage_done=result.progress,
            result=result.result,
            corr_tech_model_output=result.corr_tech_model_output,
            blend_model_output=result.blend_model_output,
            used_predicted_chems=result.corr_tech_chems,
            warnings=result.warnings,
        )


# TODO remove when not needed anymore
@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapChargeDisplayDataV2:
    heat_id: Optional[int] = attr.ib(default=None)
    grade_id: Optional[int] = attr.ib(default=None)
    basket_ids: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    switched_basket_ids: Tuple[int, ...] = attr.ib(default=(), converter=tuple)
    total_scrap_weight: Optional[int] = attr.ib(default=None)
    pig_iron_weight: Optional[int] = attr.ib(default=None)
    raw_fe_chem: RawFeChem = attr.ib(default=RawFeChem())
    scrap_limits: ScrapMixLimits = attr.ib(default=())
    optimizations: Tuple[OptimizationDisplayDataV2, ...] = attr.ib(default=(), converter=tuple)
    optimization_start_clicked: bool = attr.ib(default=False)
    heat_plan: Optional[HeatPlan] = attr.ib(default=None)
    loaded_scrap_id: int = attr.ib(default=-1)

    @property
    def inputs_snapshot(self) -> ScrapChargeInputsSnapshot:
        return ScrapChargeInputsSnapshot(
            self.grade_id,
            self.basket_ids,
            self.switched_basket_ids,
            self.total_scrap_weight,
            self.pig_iron_weight,
            self.raw_fe_chem,
            self.scrap_limits,
        )

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    # HACK HACK HACK
    # This needs to be here so that field with this class is well shown in django admin
    # TODO solve better on django side
    def __str__(self) -> str:
        return self.serialize()

    def total_scrap_weight_or_raise(self) -> int:
        if self.total_scrap_weight is None:
            raise ValueError("Call this method only if you are sure total scrap weight is set")
        return self.total_scrap_weight

    @property
    def total_scrap_weight_or_constant(self) -> int:
        if self.total_scrap_weight is None:
            return DEFAULT_SCRAP_WEIGHT
        return self.total_scrap_weight

    def grade_id_or_raise(self) -> int:
        if self.grade_id is None:
            raise ValueError("Call this method only if you are sure grade id is set")
        return self.grade_id

    def pig_iron_weight_or_raise(self) -> int:
        if self.pig_iron_weight is None:
            raise ValueError("Call this method only if you are sure pig iron weight is set")
        return self.pig_iron_weight

    @property
    def pig_iron_weight_or_constant(self) -> int:
        if self.pig_iron_weight is None:
            return DEFAULT_PIG_IRON_WEIGHT
        return self.pig_iron_weight

    @property
    def user_set_lower_bounds(self) -> ScrapBounds:
        return Map(
            {
                limit_row.scrap_type: limit_row.minimum
                for limit_row in self.scrap_limits
                if (limit_row.minimum is not None) and (limit_row.minimum > 0)
            }
        )

    @property
    def user_set_upper_bounds(self) -> ScrapBounds:
        return Map(
            {
                limit_row.scrap_type: limit_row.maximum
                for limit_row in self.scrap_limits
                if limit_row.maximum is not None
            }
        )

    @property
    def recalculation_count(self) -> int:
        return len(self.optimizations)

    @property
    def last_optimization_id(self) -> Optional[int]:
        if not self.optimizations:
            return None
        return self.optimizations[-1].optimization_id

    @property
    def recommended_scrap_charge(self) -> Optional[ScrapCoreScrapCharge]:
        try:
            return self.optimizations[-1].result.scrap_weights_per_heat[0]
        except (AttributeError, IndexError):
            return None


@lru_cache()
def deserialize_scrap_charge_data_v2(serialized: str) -> ScrapChargeDisplayDataV2:
    return converter.structure(json.loads(serialized), ScrapChargeDisplayDataV2)


class ScrapChargeDataV2(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(ScrapChargeDataV2, self).__init__(
            ScrapChargeDisplayDataV2,
            lambda x: x.serialize(),
            deserialize_scrap_charge_data_v2,
            *args,
            **kwargs,
        )


@attr.s(auto_attribs=True, slots=True, frozen=True)
class LoadingStationDisplayDataV2:
    # TODO: Remove available_scraps when current version of loading station app is turned off
    available_scraps: AvailableScraps = ()
    scrap_charges: Tuple[ScrapChargeDisplayDataV2, ...] = ()

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @classmethod
    @lru_cache()
    def deserialize(cls, serialized: str) -> "LoadingStationDisplayDataV2":
        return converter.structure(json.loads(serialized), cls)


# Code W0108(unnecessary-lambda)
# pylint: disable=W0108
class CurrentDataFieldV2(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(CurrentDataFieldV2, self).__init__(
            LoadingStationDisplayDataV2,
            lambda x: x.serialize(),
            lambda s: LoadingStationDisplayDataV2.deserialize(s),
            *args,
            **kwargs,
        )


class HeatPlanField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(HeatPlanField, self).__init__(
            HeatPlan,
            lambda x: x.serialize(),
            lambda x: converter.structure(json.loads(x), HeatPlan),
            *args,
            **kwargs,
        )


class ModelSettingsField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(ModelSettingsField, self).__init__(
            ModelSettings, lambda x: x.serialize(), ModelSettings.deserialize, *args, **kwargs
        )


class RawFeChemField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(RawFeChemField, self).__init__(
            RawFeChem,
            lambda x: x.serialize(),
            lambda x: converter.structure(json.loads(x), RawFeChem),
            *args,
            **kwargs,
        )


# TODO obsolete, squash migrations and remove
class MultipleHeatsOptimizationInputField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(MultipleHeatsOptimizationInputField, self).__init__(
            MultipleHeatsOptimizationInput,
            lambda x: x.serialize(),
            MultipleHeatsOptimizationInput.deserialize,
            *args,
            **kwargs,
        )


class MultipleHeatsOptimizationOutputField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(MultipleHeatsOptimizationOutputField, self).__init__(
            MultipleHeatsOptimizationOutput,
            lambda x: x.serialize(),
            MultipleHeatsOptimizationOutput.deserialize,
            *args,
            **kwargs,
        )


class GenericCattrEncoder(json.JSONEncoder):
    def default(self, obj):
        return converter.unstructure(obj)


class ScrapLimitsDecoder(json.JSONDecoder):
    def decode(self, s, _w=WHITESPACE.match):
        return tuple(converter.structure(x, ScrapMixLimit) for x in json.loads(s))


class OptimizationsDecoder(json.JSONDecoder):
    def decode(self, s, _w=WHITESPACE.match):
        return tuple(converter.structure(x, OptimizationDisplayDataV2) for x in json.loads(s))


class LoadingStation(models.Model):
    name = models.CharField(max_length=32)
    current_data_v2 = CurrentDataFieldV2(default=LoadingStationDisplayDataV2().serialize(), editable=False)
    debug = models.BooleanField(default=False)
    level_2 = models.BooleanField(default=False)
    steelshop = models.IntegerField(default=None, blank=True, null=True, choices=[(1, "OC1"), (2, "OC2")])
    base_model_settings = ModelSettingsField(default=ModelSettings().serialize())
    user_in_control = models.ForeignKey(
        User, null=True, on_delete=models.DO_NOTHING, related_name="loading_station_user_in_control"
    )
    scale_control = models.BooleanField(default=False)
    authorized_users = models.ManyToManyField(User, related_name="loading_station_authorized_user")
    scrap_exclusive_group_settings = models.ManyToManyField(ScrapExclusiveGroupSetting, blank=True)
    relaxable_risk_limit_settings = models.ManyToManyField(RelaxableRiskLimitSetting, blank=True)
    relaxable_upper_summing_limit_settings = models.ManyToManyField(
        RelaxableUpperSummingLimitSetting, blank=True
    )
    relaxable_lower_summing_limit_settings = models.ManyToManyField(
        RelaxableLowerSummingLimitSetting, blank=True
    )
    scrap_facilities = models.ManyToManyField(ScrapFacility, blank=True)
    scrap_yard_api = models.BooleanField(verbose_name="Use scrap yard api", default=False)
    printer = models.OneToOneField(Printer, null=True, on_delete=models.SET_NULL)

    def __str__(self):
        return self.name

    # Warning using this property you can trigger hundreds of queries to DB
    # In order to minimize number of queries made to db please use all_prefetched_loading_station_query_set
    @property
    def model_settings(self) -> ModelSettings:
        optimizer_settings = attr.evolve(
            self.base_model_settings.optimizer_settings,
            scrap_exclusive_groups=tuple(
                setting.to_scrap_exclusive_group() for setting in self.scrap_exclusive_group_settings.all()
            ),
        )
        return attr.evolve(self.base_model_settings, optimizer_settings=optimizer_settings)

    @property
    def printer_connection(self) -> FtpConnection:
        return FtpConnection() if self.printer is None else self.printer.printer_connection


def all_prefetched_loading_station_query_set() -> QuerySet:
    return LoadingStation.objects.select_related("user_in_control").prefetch_related(
        "authorized_users",
        "scrap_exclusive_group_settings__scrap_types__scrap_ids",
        "relaxable_risk_limit_settings__grade_ids__grade_ids",
        "relaxable_upper_summing_limit_settings__scrap_types__scrap_ids",
        "relaxable_upper_summing_limit_settings__grade_ids__grade_ids",
        "relaxable_lower_summing_limit_settings__scrap_types__scrap_ids",
        "relaxable_lower_summing_limit_settings__grade_ids__grade_ids",
    )


class Basket(models.Model):
    basket_id = models.IntegerField(validators=[MinValueValidator(0)])
    weight = models.IntegerField(validators=[MinValueValidator(0)])


class BasketWaggonWeight(models.Model):
    scale_id = models.CharField(max_length=4, primary_key=True)
    weight = models.IntegerField(validators=[MinValueValidator(0)])


class ScrapCharge(models.Model):
    loading_station = models.ForeignKey(LoadingStation, on_delete=models.PROTECT)
    closed_at = models.DateTimeField(null=True)
    grade_id = models.IntegerField(null=True)
    order_num = models.IntegerField(null=True)
    baskets = models.ManyToManyField(Basket, related_name="scrap_charge_baskets")
    switched_baskets = models.ManyToManyField(Basket, related_name="scrap_charge_switched_baskets")
    total_scrap_weight = models.IntegerField(null=True)
    pig_iron_weight = models.IntegerField(null=True)
    optimization_start_clicked = models.BooleanField(default=False)
    heat_plan = HeatPlanField(null=True)
    raw_fe_chem = RawFeChemField(null=True, default=RawFeChem)
    # TODO this attribute is very likely obsolete
    scrap_limits = models.JSONField(default=list, encoder=GenericCattrEncoder, decoder=ScrapLimitsDecoder)
    # TODO remove when not needed anymore, obsolete
    optimizations = models.JSONField(default=list, encoder=GenericCattrEncoder, decoder=OptimizationsDecoder)
    is_wet = models.BooleanField(null=True)
    is_reserve = models.BooleanField(null=True)
    operator = models.ForeignKey(Operator, null=True, on_delete=models.PROTECT)
    operator_comment = models.CharField(max_length=512, null=True, blank=True)
    operator_decision = models.CharField(
        max_length=64, null=True, blank=True
    )  # TODO ??? DO WE REALLY NEED/USE `operator_decision` field?
    # SHA1 hash of the latest input data (calculated and used by front-end client)
    input_data_snapshot = models.CharField(max_length=64, null=True)

    # temporary method, remove when `optimizations` field is removed
    @staticmethod
    def __extract_comment(optimizations: Sequence[OptimizationDisplayDataV2]) -> Optional[str]:
        return None if not optimizations else optimizations[-1].comment

    @classmethod
    def from_scrap_charge_display_data(
        cls,
        data: ScrapChargeDisplayDataV2,
        loading_station: LoadingStation,
        operator_decision: str,
        closed_at: Optional[datetime] = None,
    ) -> "ScrapCharge":

        with transaction.atomic():
            scrap_charge = cls(
                loading_station=loading_station,
                closed_at=closed_at,
                grade_id=data.grade_id,
                total_scrap_weight=data.total_scrap_weight,
                pig_iron_weight=data.pig_iron_weight,
                optimization_start_clicked=data.optimization_start_clicked,
                heat_plan=data.heat_plan,
                raw_fe_chem=data.raw_fe_chem,
                scrap_limits=data.scrap_limits,
                optimizations=data.optimizations,
                operator_comment=cls.__extract_comment(data.optimizations),
                operator_decision=operator_decision,
            )
            scrap_charge.save()

            scrap_charge.optimization_results.set(
                MultipleHeatsOptimizationResult.objects.filter(
                    pk__in={item.optimization_id for item in data.optimizations}
                )
            )

            for basked_id in data.basket_ids:
                try:
                    basket = Basket.objects.get(basket_id=basked_id)
                except ObjectDoesNotExist:
                    basket = Basket.objects.create(basket_id=basked_id, weight=0)
                    log.error(f"Invalid basket ID: {basked_id}")

                scrap_charge.baskets.add(basket)

            for basked_id in data.switched_basket_ids:
                try:
                    basket = Basket.objects.get(basket_id=basked_id)
                except ObjectDoesNotExist:
                    basket = Basket.objects.create(basket_id=basked_id, weight=0)
                    log.error(f"Invalid basket ID: {basked_id}")

                scrap_charge.switched_baskets.add(basket)

            scrap_charge.save()

        return scrap_charge

    @property
    def is_active(self) -> bool:
        return self.closed_at is None

    @property
    def basket_ids(self) -> Tuple[int, ...]:
        # Represent the list of primary keys of the db record with basket.
        return tuple(self.baskets.all().values_list("id", flat=True))

    @property
    def basket_basket_ids(self) -> Tuple[int, ...]:
        # Represent the list of real ids of baskets
        return tuple(self.baskets.all().values_list("basket_id", flat=True))

    @property
    def switched_basket_ids(self) -> Tuple[int, ...]:
        return tuple(self.switched_baskets.all().values_list("basket_id", flat=True))

    @property
    def total_scrap_weight_or_constant(self) -> int:
        if self.total_scrap_weight is None:
            return DEFAULT_SCRAP_WEIGHT
        return self.total_scrap_weight

    @property
    def pig_iron_weight_or_constant(self) -> int:
        if self.pig_iron_weight is None:
            return DEFAULT_PIG_IRON_WEIGHT
        return self.pig_iron_weight

    # TODO deprecated, remove when OptimizationDisplayDataV2 are removed
    @property
    def inputs_snapshot(self) -> ScrapChargeInputsSnapshot:
        return ScrapChargeInputsSnapshot(
            self.grade_id,
            self.basket_basket_ids,
            self.switched_basket_ids,
            self.total_scrap_weight,
            self.pig_iron_weight,
            self.raw_fe_chem,
            self.scrap_limits,
        )

    @property
    def last_optimization_result(self):
        try:
            return self.optimization_results.latest("created_at")
        except MultipleHeatsOptimizationResult.DoesNotExist:
            return None

    def grade_id_or_raise(self) -> int:
        if self.grade_id is None:
            raise ValueError("Call this method only if you are sure grade id is set")
        return self.grade_id

    def update_basket_ids(self, new_ids: Collection[int]) -> "ScrapCharge":
        old_ids = self.basket_ids
        to_delete_ids = [x for x in old_ids if x not in set(new_ids)]
        to_add_ids = [x for x in new_ids if x not in set(old_ids)]

        with transaction.atomic():
            if to_delete_ids:
                for id_to_del in Basket.objects.filter(basket_id__in=to_delete_ids).values_list(
                    "id", flat=True
                ):
                    self.baskets.remove(id_to_del)

            if to_add_ids:
                for id_to_add in Basket.objects.filter(basket_id__in=to_add_ids).values_list("id", flat=True):
                    self.baskets.add(id_to_add)
        return self

    def update_switched_basket_ids(self, new_ids: Collection[int]) -> "ScrapCharge":
        old_ids = self.switched_basket_ids
        to_delete_ids = [x for x in old_ids if x not in set(new_ids)]
        to_add_ids = [x for x in new_ids if x not in set(old_ids)]

        with transaction.atomic():
            if to_delete_ids:
                for id_to_del in Basket.objects.filter(basket_id__in=to_delete_ids).values_list(
                    "id", flat=True
                ):
                    self.switched_baskets.remove(id_to_del)

            if to_add_ids:
                for id_to_add in Basket.objects.filter(basket_id__in=to_add_ids).values_list("id", flat=True):
                    self.switched_baskets.add(id_to_add)
        return self

    @property
    def recalculation_count(self) -> int:
        return self.optimization_results.count()

    @property
    def expected_risk(self) -> Maybe[ChemRiskLevels]:
        opt_res = self.last_optimization_result

        if opt_res is None:
            return Nothing

        maybe_opt_res = Maybe.from_optional(opt_res.result)

        return maybe_opt_res.bind_optional(lambda res: res.first_heat_expected_risk)

    @property
    def recommended_scrap_charge(self) -> Optional[ScrapCoreScrapCharge]:

        recommended = None
        res = self.last_optimization_result

        if res is not None:

            try:
                recommended = res.result.scrap_weights_per_heat[0]
            except (AttributeError, IndexError):
                log.warning(f"Recommendation for scrap charge {self.pk} is not available")

        return recommended

    def get_weighted_scrap_lower_bounds(self) -> ScrapBounds:
        """Lower bounds induced by scrap already in baskets (important for recalculation)"""
        lower_bounds = collections.defaultdict(float)
        for ws in self.weightedscrap_set.filter(invalid_record=False):
            lower_bounds[ws.scrap] += ws.weight
        return Map(lower_bounds)

    def get_unallocated_scrap(self) -> AvailableScraps:
        available_scrap = self.loading_station.availablescrap_set.all()

        other_charges = self.loading_station.scrapcharge_set.filter(closed_at=None).exclude(pk=self.pk)

        allocated_scrap = elementwise_sum(
            *(
                charge.recommended_scrap_charge
                for charge in other_charges
                if charge.recommended_scrap_charge is not None
            )
        )

        # each scrap type belongs to at most 1 item in available scrap queryset
        return tuple(
            AvailableScrapCore(
                scrap_type=item.scrap_type,
                weight=item.weight - allocated_scrap.get(item.scrap_type, 0),
                location=OUTDOOR_SCRAP_NAME if item.located_outdoor else INDOOR_SCRAP_NAME,
            )
            for item in available_scrap
        )


# TODO think about adding serializable decorator to
#   CorrectionTechnologiesModelOutput
#   ScrapBlendModelOutput
class CorrTechModelOutputDecoder(json.JSONDecoder):
    def decode(self, s, _w=WHITESPACE.match):
        return converter.structure(json.loads(s), CorrectionTechnologiesModelOutput)


class BlendModelOutputDecoder(json.JSONDecoder):
    def decode(self, s, _w=WHITESPACE.match):
        return converter.structure(json.loads(s), ScrapBlendModelOutput)


# TODO update code to use ScrapCharge.optimization_results instead of optimizations
# TODO migrate correct data to scrap_charge field
class MultipleHeatsOptimizationResult(models.Model):
    class ResultStatus(models.IntegerChoices):
        CREATED = 1
        RUNNING = 2
        FINISHED = 3
        ERROR = 4

    created_at = models.DateTimeField(default=django.utils.timezone.now)
    last_updated = models.DateTimeField(auto_now=True)
    progress = models.FloatField(default=0.0)
    status = models.IntegerField(default=ResultStatus.CREATED, choices=ResultStatus.choices)
    result = MultipleHeatsOptimizationOutputField(null=True)
    scrap_charge = models.ForeignKey(
        ScrapCharge, on_delete=models.CASCADE, related_name="optimization_results", null=True
    )
    # following fields are `null` when their values are not available yet, or optimization failed
    corr_tech_chems = models.JSONField(null=True)  # previously called "used_predicted_chems"
    corr_tech_model_output = models.JSONField(
        encoder=GenericCattrEncoder, decoder=CorrTechModelOutputDecoder, null=True
    )
    blend_model_output = models.JSONField(
        encoder=GenericCattrEncoder, decoder=BlendModelOutputDecoder, null=True
    )
    warnings = models.JSONField(default=list)

    @functools.cached_property
    def input_data(self) -> MultipleHeatsOptimizationInput:
        return get_input_data(self.optimization_input, self.created_at.date())

    @property
    def model_output(self) -> Result[MultipleHeatsOptimizationOutput, str]:
        if self.status == MultipleHeatsOptimizationResult.ResultStatus.CREATED:
            return Failure("Multiple heat optimization was not started yet")
        if self.status == MultipleHeatsOptimizationResult.ResultStatus.RUNNING:
            return Failure("Multiple heat optimization is currently running")
        if self.status == MultipleHeatsOptimizationResult.ResultStatus.FINISHED:
            if self.result is not None:
                return Success(self.result)
            raise ValueError("Multiple heat optimization status is finished but result is not available")
        if self.status == MultipleHeatsOptimizationResult.ResultStatus.ERROR:
            return Failure("Multiple heat optimization failed to run")
        raise ValueError("Invalid multiple heat optimization result status code")

    # TODO replace usage of input_data with corresponding optimization_input/charge_input
    @property
    def first_heat_lower_bounds(self) -> ScrapBounds:
        return self.input_data.heats[0].lower_bounds

    @property
    def first_heat_upper_bounds(self) -> ScrapBounds:
        return self.input_data.heats[0].upper_bounds

    @property
    def first_heat_total_weight(self) -> int:
        return self.input_data.heats[0].total_scrap_weight

    @property
    def first_heat_lower_bounds_and_model_result(
        self,
    ) -> Result[Tuple[ScrapBounds, ScrapCoreScrapCharge], str]:
        lower_bounds = self.first_heat_lower_bounds
        model_result = self.model_output.bind(lambda mo: mo.first_heat_scrap_weights_result)
        return model_result.bind(lambda mo: Success((lower_bounds, mo)))

    @property
    def first_heat_upper_bounds_and_model_result(
        self,
    ) -> Result[Tuple[ScrapBounds, ScrapCoreScrapCharge], str]:
        lower_bounds = self.first_heat_upper_bounds
        model_result = self.model_output.bind(lambda mo: mo.first_heat_scrap_weights_result)
        return model_result.bind(lambda mo: Success((lower_bounds, mo)))


# TODO read model settings from loading station
class OptimizationInput(models.Model):
    model_settings = ModelSettingsField()

    # not used, due to compatibility with MultipleHeatsOptimizationInput dataclass
    lower_bounds = models.JSONField()
    # in fact, available scrap
    upper_bounds = models.JSONField()

    loading_station = models.ForeignKey(
        LoadingStation, on_delete=models.PROTECT, related_name="optimization_inputs", null=True
    )

    optimization_result = models.OneToOneField(
        to=MultipleHeatsOptimizationResult,
        on_delete=models.CASCADE,
        related_name="optimization_input",
        null=True,
    )


def get_input_data(optimization_input: OptimizationInput, when: date) -> MultipleHeatsOptimizationInput:

    heats = [
        HeatInputs(
            grade_planned=steel_grades.get_grade_from_id(charge_input.grade_def.grade_id, when),
            total_scrap_weight=charge_input.total_scrap_weight,
            pig_iron_weight=charge_input.pig_iron_weight,
            pig_iron_chem=charge_input.pig_iron_chem,
            lower_bounds=Map(charge_input.lower_bounds),
            upper_bounds=Map(charge_input.upper_bounds),
            relaxable_risk_limit=resolve_risk_limit_settings(get_risk_settings(charge_input.grade_def)),
            relaxable_lower_summing_limits=tuple(
                lower_setting_to_lower_limit(setting)
                for setting in get_lower_summing_settings(charge_input.grade_def)
            ),
            relaxable_upper_summing_limits=tuple(
                upper_setting_to_upper_limit(setting)
                for setting in get_upper_summing_settings(charge_input.grade_def)
            ),
        )
        for charge_input in sorted(
            optimization_input.charge_inputs.prefetch_related("grade_def").all(),
            key=lambda item: item.order_index,
        )
    ]

    return MultipleHeatsOptimizationInput(
        model_settings=optimization_input.model_settings,
        lower_bounds=Map(optimization_input.lower_bounds),
        upper_bounds=Map(optimization_input.upper_bounds),
        heats=tuple(heats),
    )


class ChargeInput(models.Model):
    grade_def = models.ForeignKey(GradeDefinition, on_delete=models.PROTECT)
    total_scrap_weight = models.IntegerField()
    pig_iron_weight = models.IntegerField()

    pig_iron_chem = RawFeChemField()

    lower_bounds = models.JSONField()
    upper_bounds = models.JSONField()

    optimization_input = models.ForeignKey(
        OptimizationInput, related_name="charge_inputs", on_delete=models.CASCADE
    )

    order_index = models.IntegerField()

    @property
    def risk_settings(self) -> Tuple[RelaxableRiskLimitSetting, ...]:
        return get_risk_settings(self.grade_def)

    @property
    def lower_summing_settings(self) -> Tuple[RelaxableLowerSummingLimitSetting, ...]:
        return get_lower_summing_settings(self.grade_def)

    @property
    def upper_summing_settings(self) -> Tuple[RelaxableUpperSummingLimitSetting, ...]:
        return get_upper_summing_settings(self.grade_def)


# TODO add loading station parameter to all "get settings" functions below
# TODO add when: date parameter to all "get settings" functions below
@ct.cached(cache=ct.TTLCache(maxsize=64, ttl=60 * 15))
def get_risk_settings(grade_def: GradeDefinition) -> Tuple[RelaxableRiskLimitSetting, ...]:
    relevant_groups = grade_def.gradegroup_set.prefetch_related("relaxablerisklimitsetting_set").all()
    universal_groups = GradeGroup.objects.prefetch_related("relaxablerisklimitsetting_set").filter(
        grade_ids=None
    )
    return tuple(
        setting
        for group in itertools.chain(relevant_groups, universal_groups)
        for setting in group.relaxablerisklimitsetting_set.all()
    )


@ct.cached(cache=ct.TTLCache(maxsize=64, ttl=60 * 15))
def get_lower_summing_settings(grade_def: GradeDefinition) -> Tuple[RelaxableLowerSummingLimitSetting, ...]:
    relevant_groups = grade_def.gradegroup_set.prefetch_related("relaxablelowersumminglimitsetting_set").all()
    universal_groups = GradeGroup.objects.prefetch_related("relaxablelowersumminglimitsetting_set").filter(
        grade_ids=None
    )
    return tuple(
        setting
        for group in itertools.chain(relevant_groups, universal_groups)
        for setting in group.relaxablelowersumminglimitsetting_set.select_related("scrap_types", "grade_ids")
        .prefetch_related("scrap_types__scrap_ids", "grade_ids__grade_ids")
        .all()
    )


@ct.cached(cache=ct.TTLCache(maxsize=64, ttl=60 * 15))
def get_upper_summing_settings(grade_def: GradeDefinition) -> Tuple[RelaxableUpperSummingLimitSetting, ...]:
    relevant_groups = grade_def.gradegroup_set.prefetch_related("relaxableuppersumminglimitsetting_set").all()
    universal_groups = GradeGroup.objects.prefetch_related("relaxableuppersumminglimitsetting_set").filter(
        grade_ids=None
    )
    return tuple(
        setting
        for group in itertools.chain(relevant_groups, universal_groups)
        for setting in group.relaxableuppersumminglimitsetting_set.select_related("scrap_types", "grade_ids")
        .prefetch_related("scrap_types__scrap_ids", "grade_ids__grade_ids")
        .all()
    )


class AvailableScrap(models.Model):
    loading_station = models.ForeignKey(LoadingStation, on_delete=models.CASCADE)
    scrap_type = models.CharField(max_length=16)
    weight = models.IntegerField(default=0)
    located_outdoor = models.BooleanField(default=False)

    class Meta:
        constraints = [
            UniqueConstraint(
                name="unique_scrap_type_on_single_loading_station",
                fields=["loading_station_id", "scrap_type"],
            ),
        ]
