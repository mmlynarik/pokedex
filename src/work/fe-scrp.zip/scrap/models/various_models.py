import json
import logging
from datetime import datetime
from typing import List, Optional, Sequence, Tuple, TypeVar

import attr
import pandas as pd
from common.models import CustomSerializationField
from django.core.exceptions import ObjectDoesNotExist
from django.core.validators import MinValueValidator, RegexValidator
from django.db import models
from django.db.models import UniqueConstraint
from django_plotly_dash.models import StatelessApp
from returns.maybe import Maybe

from scrap.models.steelshop_models import (
    SCRAP_CHARGE_LOWER_BOUND,
    Basket,
    ScrapCharge,
    converter,
)
from scrap.utils import TableRowMixin, is_zone_domestic, to_milliseconds
from scrap_core import (
    ScrapBounds,
    ScrapType,
    filter_out_nones,
    scrap_weights_to_scrap_string,
)
from scrap_core import ScrapCharge as ScrapCoreScrapCharge
from scrap_core.evaluation import and_optional
from scrap_core.evaluation.datamodel import (
    average_loading_error,
    get_used_scraps_count,
    max_loading_error,
    total_loading_error,
)
from scrap_core.heat_matching.common import BASKET_TYPO_TOLERANCE
from scrap_core.heat_matching.strategies import baskets_are_similar
from scrap_core.optimization.datamodel import ChemRiskLevels

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


HIGH_PRIORITY = 1.0
NORMAL_PRIORITY = 0.0

SCRAP_PURCHASE_APP = [
    {"app_name": "scrappurchase", "slug": "scrap-purchase"},
    {"app_name": "scrappurchaseinputdata", "slug": "scrap-purchase-input-data"},
    {"app_name": "scrappurchasereadonly", "slug": "scrap-purchase-readonly"},
]


class DataFrameField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(DataFrameField, self).__init__(
            pd.DataFrame,
            lambda df: df.to_json(date_format="iso"),
            pd.read_json,
            *args,
            **kwargs,
        )


class YieldCalculationModelResult(models.Model):
    class ResultStatus(models.IntegerChoices):
        CREATED = 1
        RUNNING = 2
        FINISHED = 3
        ERROR = 4

    created_at = models.DateTimeField(default=datetime.now)  # TODO change to utcnow
    last_updated = models.DateTimeField(auto_now=True)
    progress = models.FloatField()
    status = models.IntegerField(choices=ResultStatus.choices)
    window_size = models.PositiveSmallIntegerField()
    data_from = models.DateTimeField()
    data_to = models.DateTimeField()
    comparison_graph_data = DataFrameField(null=True, editable=False)
    graph_data = DataFrameField(null=True, editable=False)
    average_graph_data = DataFrameField(null=True, editable=False)
    frontend_warnings = DataFrameField(null=True, editable=False)


class PigIronAnalysisResult(models.Model):
    chem = models.CharField(max_length=2)
    value = models.FloatField()
    timestamp = models.DateTimeField(default=datetime.utcnow)


class WeightedScrap(models.Model):
    start = models.DateTimeField()
    end = models.DateTimeField(null=True)
    scale_id = models.CharField(max_length=8, validators=[RegexValidator(r"v\d+", "Invalid scale id")])
    # scrap attribute below contains heap attribute from Scrap Registry API, see `ScrapMixDefinition`
    # in frontend/scrap/dash/components/available_scraps/model/available_scraps/api.py
    scrap = models.CharField(max_length=16)
    weight = models.IntegerField(default=0)
    scrap_charge = models.ForeignKey(ScrapCharge, on_delete=models.CASCADE, null=True)
    baskets = models.ManyToManyField(Basket)
    invalid_record = models.BooleanField(default=False)

    class Meta:
        constraints = [
            UniqueConstraint(
                name="unique_weighting_on_single_scale",
                fields=["scale_id", "start"],
            ),
        ]

    @property
    def start_timestamp(self) -> int:
        return to_milliseconds(self.start)

    @property
    def end_timestamp_or_none(self) -> Optional[int]:
        return None if self.end is None else to_milliseconds(self.end)


T = TypeVar("T")


AVG_ERROR_LIMIT = 1500.0
MAX_ERROR_LIMIT = 2000.0


class ClosedHeatEvaluationV2(models.Model):
    version = models.PositiveSmallIntegerField(null=False, default=2)
    scrap_charge = models.OneToOneField(
        to=ScrapCharge, on_delete=models.CASCADE, related_name="closedheatevaluationv2", primary_key=True
    )
    total_loading_error = models.FloatField(null=True)
    max_loading_error = models.FloatField(null=True)
    used_scraps_recommendation = models.PositiveSmallIntegerField(null=True)
    used_scraps_reality = models.PositiveSmallIntegerField(null=True)
    forced_scrap_weight_percentage = models.FloatField(null=True)
    average_error = models.FloatField(null=True)
    reality = models.TextField(null=True)
    model_recommendation = models.TextField(null=True)
    comment = models.TextField(null=True)
    verdict = models.TextField(null=True)
    verdict_user = models.TextField(null=True)
    used_scraps_same = models.BooleanField(null=True)
    max_error_under_limit = models.BooleanField(null=True)
    avg_error_under_limit = models.BooleanField(null=True)
    lower_limits_under_limit = models.BooleanField(null=True)
    heat_ok = models.BooleanField(null=True)
    data_errors = models.TextField(null=True)
    last_update = models.DateTimeField(auto_now=True)
    auto_calculate_attempts = models.PositiveSmallIntegerField(default=0)
    s_over = models.FloatField(null=True)
    s_max = models.FloatField(null=True)
    extra_o2 = models.FloatField(null=True)
    extra_synt_slag = models.FloatField(null=True)
    reclass = models.BooleanField(null=True)
    operator_id = models.PositiveSmallIntegerField(null=True)
    # grade ID loaded from (Scada) database
    planned_grade_id = models.PositiveSmallIntegerField(null=True)
    final_grade_id = models.PositiveSmallIntegerField(null=True)
    # basket IDs loaded from (Scada) database
    basket_1 = models.PositiveSmallIntegerField(null=True)
    basket_2 = models.PositiveSmallIntegerField(null=True)
    basket_3 = models.PositiveSmallIntegerField(null=True)
    basket_4 = models.PositiveSmallIntegerField(null=True)
    heat_yield = models.FloatField(null=True)
    lower_bounds = models.TextField(null=True)
    upper_bounds = models.TextField(null=True)
    available_scrap = models.TextField(null=True)
    heat_date = models.DateTimeField(null=True)
    heat_no = models.PositiveSmallIntegerField(null=True)
    # TODO not used, may be removed
    heat_no_app = models.PositiveSmallIntegerField(null=True)
    heat_year = models.PositiveSmallIntegerField(null=True)
    grade_id_app = models.PositiveSmallIntegerField(null=True)
    basket_1_app = models.PositiveSmallIntegerField(null=True)
    basket_2_app = models.PositiveSmallIntegerField(null=True)
    basket_3_app = models.PositiveSmallIntegerField(null=True)
    basket_4_app = models.PositiveSmallIntegerField(null=True)
    switched_basket_1_app = models.PositiveSmallIntegerField(null=True)
    switched_basket_2_app = models.PositiveSmallIntegerField(null=True)
    recalculation_count = models.PositiveSmallIntegerField(null=True)
    selectivity_app = models.PositiveSmallIntegerField(null=True)
    selectivity_planned = models.PositiveSmallIntegerField(null=True)
    selectivity_final = models.PositiveSmallIntegerField(null=True)
    selectivity_app_planned = models.TextField(null=True)
    # TODO add in separate PR to be able to add warning color to report
    #  undesirable correction technology probabilities
    # corr_tech_risk_reality = models.FloatField(null=True)
    # corr_tech_risk_recommendation = models.FloatField(null=True)

    @property
    def expected_risk(self) -> Maybe[ChemRiskLevels]:
        return self.scrap_charge.expected_risk

    @property
    def basket_ids_app(self) -> Tuple[int, ...]:
        return tuple(
            sorted(
                filter_out_nones([self.basket_1_app, self.basket_2_app, self.basket_3_app, self.basket_4_app])
            )
        )

    @property
    def switched_basket_ids_app(self) -> Tuple[int, ...]:
        return tuple(
            sorted(
                filter_out_nones(
                    [
                        self.switched_basket_1_app,
                        self.switched_basket_2_app,
                    ]
                )
            )
        )

    @property
    def basket_ids_db(self) -> Tuple[int, ...]:
        return tuple(sorted(filter_out_nones([self.basket_1, self.basket_2, self.basket_3, self.basket_4])))

    def add_data_error(self, new_error: str):
        if self.data_errors is None:
            self.data_errors = new_error
        else:
            errors = self.data_errors.split("\n")
            if new_error not in errors:
                self.data_errors = self.data_errors + "\n" + new_error

        # This is here just to make sure we do not log empty errors
        if self.data_errors is not None:
            self.data_errors = self.data_errors.strip()
            if not self.data_errors:
                self.data_errors = None

    def add_real_charge_data(self, real_charge: ScrapCoreScrapCharge):
        self.reality = scrap_weights_to_scrap_string(real_charge)
        self.used_scraps_reality = get_used_scraps_count(real_charge)

    def add_model_recommendation_data(self, model_recommendation: ScrapCoreScrapCharge):
        self.model_recommendation = scrap_weights_to_scrap_string(model_recommendation)
        self.used_scraps_recommendation = get_used_scraps_count(model_recommendation)

    def add_recommendation_adherence_data(
        self, real_charge: ScrapCoreScrapCharge, model_recommendation: ScrapCoreScrapCharge
    ):
        self.total_loading_error = total_loading_error(real_charge, model_recommendation)
        self.max_loading_error = max_loading_error(real_charge, model_recommendation)
        self.max_error_under_limit = self.max_loading_error <= MAX_ERROR_LIMIT
        self.average_error = average_loading_error(real_charge, model_recommendation)
        self.avg_error_under_limit = self.average_error <= AVG_ERROR_LIMIT
        self.used_scraps_same = get_used_scraps_count(real_charge) == get_used_scraps_count(
            model_recommendation
        )

    def add_lower_bounds_data(self, lower_bounds: ScrapBounds):
        self.lower_bounds = scrap_weights_to_scrap_string(lower_bounds)

    def add_upper_bounds_data(self, upper_bounds: ScrapBounds):
        self.upper_bounds = scrap_weights_to_scrap_string(upper_bounds)

    def add_lower_bounds_percentage_data(self, lower_bounds: ScrapBounds, total_scrap_weight: float):
        self.forced_scrap_weight_percentage = (sum(lower_bounds.values()) / total_scrap_weight) * 100
        self.lower_limits_under_limit = self.forced_scrap_weight_percentage <= SCRAP_CHARGE_LOWER_BOUND

    def add_s_over(self, real_s: float, s_max: float):
        self.s_over = real_s - s_max

    def add_extra_synt_slag(self, synt_slag: float, min_synt_slag: float):
        self.extra_synt_slag = synt_slag - min_synt_slag

    def add_reclassification(self, grade_id_planned: int, grade_id_final: int):
        self.reclass = grade_id_planned != grade_id_final

    def add_available_scrap(self, available_scrap: ScrapBounds):
        self.available_scrap = scrap_weights_to_scrap_string(available_scrap)

    def add_basket_ids(self, basket_ids: Tuple[int, ...]):
        basket_count = len(basket_ids)
        if basket_count >= 1:
            self.basket_1 = basket_ids[0]
        if basket_count >= 2:
            self.basket_2 = basket_ids[1]
        if basket_count >= 3:
            self.basket_3 = basket_ids[2]
        if basket_count >= 4:
            self.basket_4 = basket_ids[3]
        if basket_count >= 5:
            self.add_data_error(
                f"Only 4 baskets are displayed but there were {basket_count} baskets in db - {basket_ids}"
            )

    def add_basket_ids_app(self, baskets: Sequence[Basket]) -> None:
        basket_ids = [b.basket_id for b in baskets]

        basket_count = len(basket_ids)
        if basket_count >= 1:
            self.basket_1_app = basket_ids[0]
        if basket_count >= 2:
            self.basket_2_app = basket_ids[1]
        if basket_count >= 3:
            self.basket_3_app = basket_ids[2]
        if basket_count >= 4:
            self.basket_4_app = basket_ids[3]
        if basket_count >= 5:
            self.add_data_error(
                f"Only 4 baskets are displayed but there were {basket_count} baskets in app - {basket_ids}"
            )

    def add_switched_basket_ids_app(self, switched_baskets: Sequence[Basket]) -> None:
        switched_basket_ids = [b.basket_id for b in switched_baskets]

        switched_basket_count = len(switched_basket_ids)
        if switched_basket_count >= 1:
            self.switched_basket_1_app = switched_basket_ids[0]
        if switched_basket_count >= 2:
            self.switched_basket_2_app = switched_basket_ids[1]
        if switched_basket_count > 2:
            self.add_data_error(
                f"Only 2 baskets are displayed but there were {switched_basket_count} baskets in app"
                f" - {switched_basket_count}"
            )

    def set_heat_ok(self):
        if not baskets_are_similar(self.basket_ids_app, self.basket_ids_db, BASKET_TYPO_TOLERANCE):
            self.heat_ok = None
        else:
            self.heat_ok = and_optional(
                self.max_error_under_limit, self.avg_error_under_limit, self.lower_limits_under_limit
            )

    def set_heat_year(self):
        if self.heat_date is not None:
            self.heat_year = self.heat_date.year
        else:
            log.error(f"Closed heat evaluation {self.pk} has empty 'heat_date' attribute")


class SupportedScrapTypeMapping(models.Model):
    scrap_type = models.CharField(max_length=100)
    input_scrap_type = models.CharField(max_length=100)

    class Meta:
        unique_together = ("scrap_type", "input_scrap_type")


class ScrapSupplier(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name


class ScrapSupplierMapping(models.Model):
    scrap_supplier = models.ForeignKey(ScrapSupplier, on_delete=models.PROTECT)
    input_scrap_supplier = models.CharField(max_length=100)

    class Meta:
        unique_together = ("scrap_supplier", "input_scrap_supplier")


class ScrapPurchase(models.Model):
    supplier = models.ForeignKey(ScrapSupplier, on_delete=models.PROTECT)
    scrap_type = models.CharField(max_length=100)
    zone = models.CharField(max_length=10)
    date = models.DateField(auto_now=False, auto_now_add=False)
    quantity = models.FloatField(validators=[MinValueValidator(0.0)])
    price = models.FloatField(validators=[MinValueValidator(0.0)])
    note = models.CharField(max_length=255, null=True)
    entered_manually = models.BooleanField(default=False)

    @property
    def total_value(self) -> float:
        return self.quantity * self.price

    @property
    def is_zone_domestic(self) -> bool:
        return is_zone_domestic(self.zone)

    def __str__(self):
        return (
            f"Supplier: {self.supplier}\t"
            f"Scrap type: {self.scrap_type}\t"
            f"Zone: {self.zone}\t"
            f"Purchased date: {self.date}\t"
            f"Quantity: {self.quantity}\t"
            f"Price: {self.price}\t"
            f"Total value: {self.total_value}"
        )

    def __eq__(self, other):
        return (
            self.supplier.id == other.supplier.id
            and self.scrap_type == other.scrap_type
            and self.zone == other.zone
            and self.date == other.date
            and self.quantity == other.quantity
            and self.price == other.price
        )

    # bugfix -> if __eq__ is overridden -> __hash__ has to be as well
    # see: https://stackoverflow.com/questions/61212514/django-model-objects-became-not-hashable-after-upgrading-to-django-2-2 # pylint: disable=line-too-long
    def __hash__(self):  # pylint: disable=useless-super-delegation
        return super().__hash__()


@attr.s(auto_attribs=True, slots=True, frozen=True)
class BaseDeltaRule:
    # not ScrapType because Prime and Cut and their comparing during evaluation
    scrap_type: Optional[str]
    zone: Optional[str]
    supplier: Optional[str]
    base_delta: Optional[float]


BaseDeltaRuleData = Tuple[BaseDeltaRule, ...]


@attr.frozen
class ScrapParsedData(TableRowMixin):
    input_scrap_type: str = attr.ib()
    # can't be used ScrapType because values are filled from DB (str)
    scrap_type: Optional[str] = attr.ib()
    weight: float = attr.ib(converter=float)

    def update_field(self, **kwargs) -> "ScrapParsedData":
        return attr.evolve(self, **kwargs)


ParsedScrapStateData = Tuple[ScrapParsedData, ...]
ParsedScrapOnTheWayData = Tuple[ScrapParsedData, ...]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapOfferParsedRecord:
    input_supplier: Optional[str]
    supplier: Optional[str]
    input_scrap_type: Optional[str]
    scrap_type: Optional[ScrapType]
    quantity: Optional[float]
    price: Optional[float]
    zone: Optional[str]
    station: Optional[str]
    country: Optional[str]
    note: Optional[str]
    entered_manually: bool = False

    def update_field(self, **kwargs) -> "ScrapOfferParsedRecord":
        return attr.evolve(self, **kwargs)


ScrapOfferParsedData = Tuple[ScrapOfferParsedRecord, ...]


@attr.frozen
class ScrapOffer:
    uuid: str = attr.ib()
    scrap_type: Optional[ScrapType] = attr.ib(default=None)
    zone: Optional[str] = attr.ib(default=None)
    weight: Optional[float] = attr.ib(default=None)
    supplier: Optional[str] = attr.ib(default=None)
    # supplier price is for reference only
    supplier_price: Optional[float] = attr.ib(default=None)
    price_with_delta: Optional[float] = attr.ib(default=None)
    recommendation: Optional[float] = attr.ib(default=None)
    scrap_purchased: bool = attr.ib(default=False)
    base_delta_rules: List[int] = attr.ib(default=[])
    added_by_user: bool = attr.ib(default=False)
    note: Optional[str] = attr.ib(default=None)
    override_price: Optional[float] = attr.ib(default=None)
    generated_from: Optional[str] = attr.ib(default=None)
    station: Optional[str] = attr.ib(default=None)
    frozen: bool = attr.ib(default=False)
    last_month_price: Optional[float] = attr.ib(default=None)
    last_month_price_added_manually: bool = attr.ib(default=False)
    scrap_purchase_pk: int = attr.ib(default=-1)

    @classmethod
    def deserialize(cls, serialized: str) -> "ScrapOffer":
        return converter.structure(json.loads(serialized), cls)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def update_field(self, **kwargs) -> "ScrapOffer":
        return attr.evolve(self, **kwargs)

    @property
    def has_valid_price(self) -> bool:
        return self.price_with_delta is not None or self.override_price is not None

    @property
    def purchase_price(self) -> float:
        if self.override_price is not None:
            return self.override_price

        if self.price_with_delta is not None:
            return self.price_with_delta

        raise ValueError(f"Offer {self.uuid} has no price defined")


ScrapOfferData = Tuple[ScrapOffer, ...]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class RealizedScrapOffer(TableRowMixin):
    scrap_type: Optional[ScrapType]
    zone: Optional[str]
    weight: Optional[float]
    supplier: Optional[str]
    price: Optional[float]
    note: Optional[str]
    scrap_offer_uuid_list: List[str]

    @classmethod
    def deserialize(cls, serialized: str) -> "RealizedScrapOffer":
        return converter.structure(json.loads(serialized), cls)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    def to_dict(self):
        return converter.unstructure(self)


RealizedScrapOfferData = Tuple[RealizedScrapOffer, ...]


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapState:
    scrap_type: ScrapType
    state_weight: float
    on_the_way_weight: float

    @classmethod
    def deserialize(cls, serialized: str) -> "ScrapState":
        return converter.structure(json.loads(serialized), cls)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self))

    def update_field(self, **kwargs) -> "ScrapState":
        return attr.evolve(self, **kwargs)


ScrapStateData = Tuple[ScrapState, ...]


# FIXME application UI -> production plan are numbers in kgs not tons
# FIXME change scrap_amount to steel_amount or something similar, e.g. steel_weight
# TODO replace scrap_grade_name with grade_id, or even better - with grade object
@attr.s(auto_attribs=True, slots=True, frozen=True)
class ProductionPlan:
    scrap_grade_name: str
    scrap_amount: float

    @classmethod
    def deserialize(cls, serialized: str) -> "ProductionPlan":
        return converter.structure(json.loads(serialized), cls)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)

    @property
    def grade_id(self):
        return int(self.scrap_grade_name.split("/")[1])


ProductionPlanData = Tuple[ProductionPlan, ...]


def get_scrap_purchase_stateless_app(app_data: dict) -> Optional[StatelessApp]:
    app_name = app_data["app_name"]
    try:
        stateless_app = StatelessApp.objects.get(app_name=app_name)
    except ObjectDoesNotExist:
        stateless_app = None
    return stateless_app


class ScaleCurrentState(models.Model):
    class ScaleState(models.IntegerChoices):
        STOPPED_WEIGHTING = 0
        STARTING_WEIGHTING = 1
        WEIGHTING = 2
        STOPPING_WEIGHTING = 3
        ERROR = 4

    scale_id = models.CharField(max_length=8, validators=[RegexValidator(r"v\d+", "Invalid scale id")])
    state = models.IntegerField(choices=ScaleState.choices)
    state_sequence = models.IntegerField(default=0)
    scrap = models.CharField(max_length=16, null=True, blank=True)
    time = models.DateTimeField(null=True, blank=True)
    weighted_scrap = models.ForeignKey(WeightedScrap, on_delete=models.SET_NULL, null=True, blank=True)
    scrap_charge = models.ForeignKey(ScrapCharge, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return (
            "ScaleCurrentState -> "
            f"scale_id: {self.scale_id}, state: {self.state},"
            f"state_seq: {self.state_sequence}, scrap: {self.scrap},"
            f"time: {self.time},"
            f"weighted_scrap: {self.weighted_scrap.id if self.weighted_scrap is not None else None},"
            f"scrap_charge: {self.scrap_charge.id if self.scrap_charge is not None else None}"
        )
