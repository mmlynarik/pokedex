import json
import logging
from datetime import date, datetime
from functools import lru_cache
from typing import List, Mapping, Optional, Tuple

import attr
import pandas as pd
from common.models import CustomSerializationField
from django.contrib.auth.models import User
from django.db import models, transaction
from django.db.utils import IntegrityError
from django_plotly_dash.models import DashApp

from scrap_core import positive_finite
from scrap_core.home_scrap_estimation import estimate_weekly_home_scrap_production
from scrap_core.optimization.datamodel import ModelSettings, OptimizerSettings
from scrap_core.serialization import serializable
from scrap_core.utils import MEAN_HEAT_WEIGHT, MEAN_SCRAP_WEIGHT, convert_tons_to_kilograms, scrap_to_steel
from scrap_core.yieldmodel import PIG_IRON_YIELD_V2

from ..dash.database_api import db_scada
from .various_models import (
    SCRAP_PURCHASE_APP,
    BaseDeltaRuleData,
    ParsedScrapOnTheWayData,
    ParsedScrapStateData,
    ProductionPlan,
    ProductionPlanData,
    RealizedScrapOfferData,
    ScrapOfferData,
    ScrapOfferParsedData,
    ScrapStateData,
    converter,
    get_scrap_purchase_stateless_app,
)

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


MEAN_DAILY_PRODUCTION_PER_STEELSHOP = {"OC1": 6336000, "OC2": 7226000}  # in kg

# Weighted average of data between 2021-01-01 and 2022-07-01
# provided by http://viu.sk.uss.com/scrap/results/detail/161
MEAN_SCRAP_YIELD = 0.931789112


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapPurchaseOptimizationSettings:
    model_settings: ModelSettings = attr.ib(
        default=ModelSettings(
            optimizer_settings=OptimizerSettings(
                # max ratios copied from production settings for OC2 loading station
                h_min_ratio=0,
                h_max_ratio=0.4,
                l_min_ratio=0,
                l_max_ratio=0.5,
            )
        )
    )
    # TODO obsolete
    # 0 - no production, 1 - average production, 2 - 200% production, etc.
    expected_production_ratio: float = attr.ib(default=1.0, validator=[positive_finite])

    def __str__(self) -> str:
        return self.serialize()

    @classmethod
    def deserialize(cls, serialized: str) -> "ScrapPurchaseOptimizationSettings":
        return converter.structure(json.loads(serialized), cls)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), sort_keys=True)


class ScrapPurchaseOptimizationSettingsField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(ScrapPurchaseOptimizationSettingsField, self).__init__(
            ScrapPurchaseOptimizationSettings,
            lambda obj: obj.serialize(),
            # patching in `0061_summing_scrap_limits_to_tuple` migration does not work,
            # if `lambda` is not used here. I have no idea why it so.
            lambda serialized: ScrapPurchaseOptimizationSettings.deserialize(serialized),
            *args,
            **kwargs,
        )


def calc_scrap_stock_objective_correction(
    expected_steel_production, scrap_stock_objective_in_kgs, mean_scrap_ratio
):
    return (
        1
        + scrap_to_steel(scrap_stock_objective_in_kgs, PIG_IRON_YIELD_V2, MEAN_SCRAP_YIELD, mean_scrap_ratio)
        / expected_steel_production
    )


@serializable(converter)
@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapPurchaseOptimizationInput:
    optimization_settings: ScrapPurchaseOptimizationSettings
    # TODO separate scrap_piles and scrap_on_the_way
    scrap_supplies: ScrapStateData
    scrap_offers: ScrapOfferData
    realized_offers: RealizedScrapOfferData
    # TODO rename to production plan data, so it won't confuse anyone (hopefully)
    production_plan: ProductionPlanData  # in kgs (will be fixed)
    production_plan_date: date
    production_plan_nr_of_weeks: int
    expected_steel_production: int  # in kgs
    # FIXME all internal weight units must be kgs
    #   https://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/547
    scrap_stock_objective: int  # in tons
    export_slabs_weight: int = attr.ib(default=0)  # in tons
    mean_scrap_weight: int = attr.ib(default=MEAN_SCRAP_WEIGHT)  # in kgs

    @property
    def scrap_stock_objective_in_kgs(self):
        return convert_tons_to_kilograms(self.scrap_stock_objective)

    @property
    def available_offers(self) -> ScrapOfferData:
        return tuple(offer for offer in self.scrap_offers if not offer.scrap_purchased)

    @property
    def expected_production_plan(self) -> ProductionPlanData:
        planned_steel_production = sum(item.scrap_amount for item in self.production_plan)
        expected_steel_production_correction = self.expected_steel_production / planned_steel_production

        return tuple(
            [
                ProductionPlan(
                    scrap_grade_name=item.scrap_grade_name,
                    scrap_amount=item.scrap_amount * expected_steel_production_correction,
                )
                for item in self.production_plan
            ]
        )

    @property
    def corrected_production_plan(self) -> ProductionPlanData:
        scrap_stock_objective_in_kgs = convert_tons_to_kilograms(self.scrap_stock_objective)
        log.info(f"scrap stock objective: {scrap_stock_objective_in_kgs} kg")

        scrap_stock_objective_correction = calc_scrap_stock_objective_correction(
            self.expected_steel_production, self.scrap_stock_objective_in_kgs, self.mean_scrap_ratio
        )

        return tuple(
            [
                ProductionPlan(
                    scrap_grade_name=item.scrap_grade_name,
                    scrap_amount=item.scrap_amount * scrap_stock_objective_correction,
                )
                for item in self.expected_production_plan
            ]
        )

    @property
    def expected_home_scrap(self) -> List[dict]:
        """Use production plan to estimate home scrap."""
        export_slabs_weight_in_kgs = convert_tons_to_kilograms(self.export_slabs_weight)
        log.info(f"export slabs weight: {export_slabs_weight_in_kgs} kg")
        log.info(f"expected steel production weight: {self.expected_steel_production} kg")

        home_scrap_estimation = estimate_weekly_home_scrap_production(
            db_scada,
            self.production_plan_date,
            (self.expected_steel_production - export_slabs_weight_in_kgs) / self.production_plan_nr_of_weeks,
        )

        return [
            {
                "scrap_type": scrap_type,
                "weight": home_scrap_estimation[scrap_type] * self.production_plan_nr_of_weeks,
                "record_type": "expected_home_scrap",
            }
            for scrap_type in home_scrap_estimation
        ]

    @property
    def mean_scrap_ratio(self) -> float:
        return self.mean_scrap_weight / MEAN_HEAT_WEIGHT

    # FIXME this type: ignore(s) in the following method are due to optional weight and price attributes
    #  of ScrapOffer-like objects. I do not understand why these attributes are optional,
    #  so if by any chance we make them required, what is not straightforward, remove these type: ignore hacks
    def to_dataframe(self) -> pd.DataFrame:
        """
        Return dataframe with columns
            - scrap_type
            - weight (in kg)
            - price (per kg)
            - record_type - scrap_pile, on_the_way, expected_home_scrap, realized_offer, available_offer
        """

        df_scrap_piles = pd.DataFrame(
            [
                {
                    "scrap_type": item.scrap_type,
                    "weight": convert_tons_to_kilograms(item.state_weight),  # type: ignore
                    "price": 0.0,
                    "record_type": "scrap_pile",
                }
                for item in self.scrap_supplies
            ]
        )

        df_scrap_on_the_way = pd.DataFrame(
            [
                {
                    "scrap_type": item.scrap_type,
                    "weight": convert_tons_to_kilograms(item.on_the_way_weight),  # type: ignore
                    "price": 0.0,
                    "record_type": "on_the_way",
                }
                for item in self.scrap_supplies
            ]
        )

        df_realized_offers = pd.DataFrame(
            [
                {
                    "scrap_type": offer.scrap_type,
                    "weight": convert_tons_to_kilograms(offer.weight),  # type: ignore
                    "price": offer.price / 1000,  # type: ignore
                    "record_type": "realized_offer",
                }
                for offer in self.realized_offers
            ]
        )

        df_expected_home_scrap = pd.DataFrame({**item, "price": 0.0} for item in self.expected_home_scrap)

        df_available_offers = pd.DataFrame(
            [
                {
                    "scrap_type": offer.scrap_type,
                    "weight": convert_tons_to_kilograms(offer.weight),  # type: ignore
                    "price": offer.purchase_price / 1000,  # type: ignore
                    "record_type": "available_offer",
                }
                for offer in self.available_offers
            ]
        )

        return pd.concat(
            [
                df_scrap_piles,
                df_scrap_on_the_way,
                df_realized_offers,
                df_expected_home_scrap,
                df_available_offers,
            ]
        )

    def to_dataframe_grouped(self):
        """
        Group records with respect to "scrap_type" and "price"
        in order to reduce dimensionality of optimization space
        """
        df_scrap = self.to_dataframe()

        # set prices of already owned scrap records to 0
        df_scrap.loc[df_scrap["record_type"] != "available_offer", "price"] = 0

        # notice that summed are weights only, prices are kept intact
        df_grouped = (
            df_scrap[["scrap_type", "weight", "price"]].groupby(["scrap_type", "price"]).sum().reset_index()
        )

        return df_grouped


@serializable(converter)
@attr.s(slots=True, frozen=True)
class ScrapPurchaseOptimizationOutput:
    error: Optional[str] = attr.ib(default=None)
    warning: Optional[str] = attr.ib(default=None)
    recommendations: Optional[Mapping[str, float]] = attr.ib(default=None)


# pylint: disable=unnecessary-lambda
class ScrapPurchaseOptimizationInputField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(ScrapPurchaseOptimizationInputField, self).__init__(
            ScrapPurchaseOptimizationInput,
            lambda obj: obj.serialize(),
            # patching in `0051_production_plan_date` migration does not work,
            # if `lambda` is not used here. I have no idea why it so.
            lambda serialized: ScrapPurchaseOptimizationInput.deserialize(serialized),
            *args,
            **kwargs,
        )


class ScrapPurchaseOptimizationOutputField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(ScrapPurchaseOptimizationOutputField, self).__init__(
            ScrapPurchaseOptimizationOutput,
            lambda obj: obj.serialize(),
            ScrapPurchaseOptimizationOutput.deserialize,
            *args,
            **kwargs,
        )


class ScrapPurchaseOptimizationResult(models.Model):
    class ResultStatus(models.IntegerChoices):
        CREATED = 1
        RUNNING = 2
        FINISHED = 3
        ERROR = 4

    created_at = models.DateTimeField(default=datetime.utcnow)
    # TODO last_updated = models.DateTimeField(auto_now=True)
    status = models.IntegerField(default=ResultStatus.CREATED, choices=ResultStatus.choices)
    progress = models.FloatField(default=0.0)
    input_data = ScrapPurchaseOptimizationInputField(null=False)
    output_data = ScrapPurchaseOptimizationOutputField(null=True)


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapPurchaseOptimizationDisplayData:
    optimization_id: int
    progress: float = 0.0

    def update(self) -> "ScrapPurchaseOptimizationDisplayData":
        optimization_result = ScrapPurchaseOptimizationResult.objects.get(pk=self.optimization_id)
        new_instance = attr.evolve(self, progress=optimization_result.progress)
        return new_instance

    @property
    def output_data(self) -> Optional[ScrapPurchaseOptimizationOutput]:
        optimization_result = ScrapPurchaseOptimizationResult.objects.get(pk=self.optimization_id)
        return optimization_result.output_data

    def is_finished(self):
        return self.output_data is not None


@attr.s(auto_attribs=True, slots=True, frozen=True)
class ScrapPurchaseRecordDisplayData:
    scrap_state_filename: str = ""
    scrap_on_the_way_filename: str = ""
    production_plan_date: Optional[datetime] = None
    scrap_stock_objective: Optional[int] = None
    mean_scrap_weight: int = MEAN_SCRAP_WEIGHT
    scrap_offer_data: ScrapOfferData = tuple()
    realized_scrap_offer_data: RealizedScrapOfferData = tuple()
    parsed_scrap_offers_data: ScrapOfferParsedData = tuple()
    scrap_offers_filename: str = ""
    base_delta_rule_data: BaseDeltaRuleData = tuple()
    parsed_scrap_state_data: ParsedScrapStateData = tuple()
    parsed_scrap_on_the_way_data: ParsedScrapOnTheWayData = tuple()
    scrap_state_data: ScrapStateData = tuple()
    production_plan_data: ProductionPlanData = tuple()
    production_plan_nr_of_weeks: int = 4
    computations: Tuple[ScrapPurchaseOptimizationDisplayData, ...] = ()
    user_defined_expected_steel_production: Optional[int] = attr.ib(default=None)
    export_slabs_weight: int = attr.ib(default=0)

    def serialize(self) -> str:
        return json.dumps(converter.unstructure(self), indent=4, sort_keys=True)


@lru_cache()
def deserialize_scrap_purchase_record_data(serialized: str) -> ScrapPurchaseRecordDisplayData:
    return converter.structure(json.loads(serialized), ScrapPurchaseRecordDisplayData)


class CurrentScrapPurchaseDataField(CustomSerializationField):
    def __init__(self, *args, **kwargs):
        super(CurrentScrapPurchaseDataField, self).__init__(
            ScrapPurchaseRecordDisplayData,
            lambda x: x.serialize(),
            deserialize_scrap_purchase_record_data,
            *args,
            **kwargs,
        )


class ScrapPurchaseRecord(models.Model):
    name = models.CharField(max_length=32, null=True)
    current_data = CurrentScrapPurchaseDataField(
        default=ScrapPurchaseRecordDisplayData().serialize(), editable=False
    )
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    updated_at = models.DateTimeField(auto_now=True, editable=False)
    purchase_date = models.DateField(
        null=True,
    )
    user_in_control = models.ForeignKey(
        User, null=True, on_delete=models.DO_NOTHING, related_name="scrap_purchase_record_user_in_control"
    )
    authorized_users = models.ManyToManyField(User, related_name="scrap_purchase_record_authorized_user")
    debug = models.BooleanField(default=False)
    finished = models.BooleanField(default=False)
    optimization_settings = ScrapPurchaseOptimizationSettingsField(
        default=ScrapPurchaseOptimizationSettings().serialize()
    )

    def __str__(self):
        return f"ScrapPurchaseRecord {self.pk} ({self.name} @ {self.purchase_date})"

    def save(self, force_insert=False, force_update=False, using=None, update_fields=None):
        super(ScrapPurchaseRecord, self).save(
            force_insert=force_insert, force_update=force_update, using=using, update_fields=update_fields
        )
        if self.pk:
            for app in SCRAP_PURCHASE_APP:
                with transaction.atomic():
                    stateless_app = get_scrap_purchase_stateless_app(app_data=app)
                    if stateless_app:
                        slug = f"{app['slug']}-{self.pk}"
                        base_state = '{"scrap-purchase-record-id": {"children": ' + str(self.pk) + "}}"
                        try:
                            DashApp(
                                stateless_app=stateless_app,
                                instance_name=slug,
                                slug=slug,
                                base_state=base_state,
                            ).save()
                        except IntegrityError:
                            pass
