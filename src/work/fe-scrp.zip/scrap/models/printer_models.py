import attr
from django.db import models
from ftplib import FTP


@attr.frozen
class FtpConnection:
    host: str = ""
    username: str = ""
    password: str = ""

    @property
    def is_valid(self) -> bool:
        return self.host != "" and self.username != "" and self.password != ""

    @property
    def get_ftp_conn(self) -> FTP:
        return FTP(self.host, user=self.username, passwd=self.password)


class Printer(models.Model):
    ip = models.GenericIPAddressField()
    ftp_username = models.CharField(max_length=32)
    ftp_password = models.CharField(max_length=32)
    location = models.CharField(max_length=32, blank=True)

    @property
    def printer_connection(self) -> FtpConnection:
        return FtpConnection(host=self.ip, username=self.ftp_username, password=self.ftp_password)

    def __str__(self) -> str:
        location = self.location or "unknown position"
        return f"The printer is located at {location} with ip: {self.ip}"
