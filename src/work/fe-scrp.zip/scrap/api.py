from typing import List, Any, Mapping, Dict, Optional, Tuple

from scrap_core import ScrapMix
from scrap_core.optimization.datamodel import (
    AvailableScrap,
    AvailableScraps,
    ModelSettings,
    MultipleHeatsOptimizationOutput,
    RawFeChem,
    ScrapMixLimit,
)
from scrap_core.optimization.validations import ChargeInfoValidationResult
from scrap.dash.components.one_heat_optimizer_v2 import validate_charge_info
from scrap.models import (
    ScrapChargeDisplayDataV2,
    MultipleHeatsOptimizationResult,
    RelaxableLowerSummingLimitSetting,
    RelaxableUpperSummingLimitSetting,
    OptimizationInput,
    ChargeInput,
    GradeDefinition,
    LoadingStation,
)
from scrap.tasks import multiple_heats_scrap_optimization


def has_valid_charges(results: List[ChargeInfoValidationResult]) -> bool:
    return all(not result[0] for result in results)  # without errors only


def get_available_scraps_from_req_dict(req_dict: Dict[ScrapMix, Dict]) -> AvailableScraps:
    return tuple(
        AvailableScrap(scrap_type=scrap, weight=values["weight"], location=values["location"])
        for scrap, values in req_dict.items()
    )


def one_map_within_other_map(first: Mapping, other: Mapping) -> bool:
    return set(first).issubset(set(other))


def validate_user_bounds(req_heat: Dict, req_available_scraps: Dict) -> bool:
    return one_map_within_other_map(
        req_heat["lower_bounds"], req_available_scraps
    ) and one_map_within_other_map(req_heat["upper_bounds"], req_available_scraps)


def exclude_warning_from_validation_result(result: ChargeInfoValidationResult) -> ChargeInfoValidationResult:
    to_exclude = ["Plán tavieb nenačítaný - optimalizácia prebehne pre jednu tavbu"]
    errors, warnings = result
    return (errors, tuple(warning for warning in warnings if warning not in to_exclude))


def add_error_to_validation_result(result: ChargeInfoValidationResult) -> ChargeInfoValidationResult:
    errors, warnings = result
    return (errors + ("Šroty v ohraničeniach na tavbe nie sú podmnožinou dostupných šrotov.",), warnings)


def validate_all_charges_info(
    req: Any,
    model_settings: ModelSettings,
    relaxable_lower_summing_limits_settings: Tuple[RelaxableLowerSummingLimitSetting, ...],
    relaxable_upper_summing_limits_settings: Tuple[RelaxableUpperSummingLimitSetting, ...],
) -> List[ChargeInfoValidationResult]:
    validation_results = []
    available_scraps = get_available_scraps_from_req_dict(req["available_scraps"])
    for heat in req["heats"]:
        charge_info = ScrapChargeDisplayDataV2(
            grade_id=heat["grade_planned"],
            total_scrap_weight=heat["total_scrap_weight"],
            pig_iron_weight=heat["pig_iron_weight"],
            raw_fe_chem=RawFeChem(**heat["pig_iron_chem"]),
            scrap_limits=tuple(
                ScrapMixLimit(
                    scrap_type=scrap,
                    minimum=heat["lower_bounds"].get(scrap, 0),
                    maximum=heat["upper_bounds"].get(scrap, req["available_scraps"][scrap]["weight"]),
                )
                for scrap in req["available_scraps"]
            ),
        )
        validation_result = exclude_warning_from_validation_result(
            validate_charge_info(
                charge_info,
                relaxable_lower_summing_limits_settings,
                relaxable_upper_summing_limits_settings,
                available_scraps,
                model_settings,
            )
        )
        if not validate_user_bounds(req_heat=heat, req_available_scraps=req["available_scraps"]):
            validation_result = add_error_to_validation_result(validation_result)
        validation_results.append(validation_result)
    return validation_results


def get_errors_from_validation_results(
    results: List[ChargeInfoValidationResult],
) -> Dict[int, Tuple[str, ...]]:
    errors = [result[0] for result in results]
    return {idx: error for idx, error in enumerate(errors)}


def get_warnings_from_validation_results(
    results: List[ChargeInfoValidationResult],
) -> Dict[int, Tuple[str, ...]]:
    warnings = [result[1] for result in results]
    return {idx: warning for idx, warning in enumerate(warnings)}


def get_multiple_heats_optimization_input_from_req(
    req: Any, model_settings: ModelSettings
) -> OptimizationInput:

    opt_input = OptimizationInput(
        model_settings=model_settings,
        lower_bounds={scrap: 0 for scrap in req["available_scraps"]},
        upper_bounds={scrap: values["weight"] for scrap, values in req["available_scraps"].items()},
        loading_station=LoadingStation.objects.get(pk=req["loading_station_id"]),
    )
    opt_input.save()

    ChargeInput.objects.bulk_create(
        [
            ChargeInput(
                grade_def=GradeDefinition.objects.get_or_create(grade_id=heat["grade_planned"])[0],
                total_scrap_weight=heat["total_scrap_weight"],
                pig_iron_weight=heat["pig_iron_weight"],
                pig_iron_chem=RawFeChem(**heat["pig_iron_chem"]),
                lower_bounds=heat["lower_bounds"],
                upper_bounds=heat["upper_bounds"],
                optimization_input=opt_input,
                order_index=idx,
            )
            for idx, heat in enumerate(req["heats"])
        ]
    )

    return opt_input


def optimize_multiple_heats_api(opt_input: OptimizationInput) -> int:
    db_result = MultipleHeatsOptimizationResult()
    db_result.save()

    opt_input.optimization_result = db_result
    opt_input.save()

    multiple_heats_scrap_optimization.send(db_result.pk)
    return db_result.pk


def get_expected_risk_summary(result: MultipleHeatsOptimizationOutput) -> Optional[str]:
    expected_risk = None
    if result.first_heat_expected_risk is not None:
        expected_risk = (
            "high"
            if result.first_heat_expected_risk.high
            else ("medium" if result.first_heat_expected_risk.medium else "low")
        )
    return expected_risk
