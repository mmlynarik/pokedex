import logging
from datetime import datetime
from typing import Any, Dict, Tuple, Optional

import attr
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db import transaction
from django.db.utils import DatabaseError

from scalecore.processor import (
    AnyAction,
    AnyState,
    AnyStates,
    MessageProcessor,
    StartAction,
    StartingWeightingState,
    StopAction,
    StoppedWeightingState,
    StoppingWeightingState,
    StopStartAction,
    TareAction,
    UnappliableActionError,
    UpdateAction,
    WeightingBackend,
    WeightingState,
    get_processor,
)
from scalesingest.error import ScaleAPIError
from scrap.models import ScaleCurrentState, WeightedScrap
from scrap.scales import scale_processors
from scrap.utils import from_milliseconds, to_milliseconds

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class InvalidStateError(Exception):
    pass


def get_actual_datetime(scale_id: str) -> datetime:
    scale_processor = scale_processors[scale_id]
    return from_milliseconds(scale_processor.get_redis_time())


def update_to_stopped_weighting_state(
    current_state: ScaleCurrentState, _: StoppedWeightingState
) -> ScaleCurrentState:
    current_state.state = ScaleCurrentState.ScaleState.STOPPED_WEIGHTING
    current_state.scrap = None
    current_state.time = None
    current_state.weighted_scrap = None
    current_state.scrap_charge = None
    return current_state


def update_to_starting_weighting_state(
    current_state: ScaleCurrentState, new_state: StartingWeightingState
) -> ScaleCurrentState:
    current_state.state = ScaleCurrentState.ScaleState.STARTING_WEIGHTING
    current_state.scrap = new_state.scrap_type
    current_state.time = new_state.start_time
    current_state.weighted_scrap = None
    current_state.scrap_charge_id = new_state.scrap_charge_id
    return current_state


def update_to_weighting_state(
    current_state: ScaleCurrentState, new_state: WeightingState
) -> ScaleCurrentState:
    current_state.state = ScaleCurrentState.ScaleState.WEIGHTING
    current_state.weighted_scrap_id = new_state.weighting_id
    return current_state


def update_to_stopping_weighting_state(
    current_state: ScaleCurrentState, new_state: StoppingWeightingState
) -> ScaleCurrentState:
    current_state.state = ScaleCurrentState.ScaleState.STOPPING_WEIGHTING
    current_state.time = new_state.stop_time
    return current_state


class DjangoWeightingBackend:
    def __init__(self, scale_id: str) -> None:
        self.scale_id = scale_id

    def get_current_datetime(self) -> datetime:
        scale_processor = scale_processors[self.scale_id]
        return from_milliseconds(scale_processor.get_redis_time())

    def request_weighting_start(
        self, start_action: StartAction, start_at: datetime
    ) -> StartingWeightingState:
        return StartingWeightingState(
            scrap_charge_id=start_action.scrap_charge_id,
            scrap_type=start_action.scrap_type,
            start_time=start_at,
        )

    def start_weighting(self, current_state: StartingWeightingState) -> WeightingState:
        weighted_scrap = WeightedScrap.objects.create(
            scrap_charge_id=current_state.scrap_charge_id,
            scale_id=self.scale_id,
            scrap=current_state.scrap_type,
            start=current_state.start_time,
        )
        return WeightingState(weighted_scrap.pk)

    def weight_update(self, current_state: WeightingState) -> WeightingState:
        weighted_scrap = WeightedScrap.objects.get(pk=current_state.weighting_id)
        if weighted_scrap.end is not None:
            return current_state

        new_weight = scale_processors[self.scale_id].get_current_relative_weight(
            to_milliseconds(weighted_scrap.start)
        )

        weighted_scrap.weight = new_weight
        weighted_scrap.save()

        return attr.evolve(current_state, weight=new_weight)

    def request_weighting_stop(self, stop_action: StopAction, stop_at: datetime) -> StoppingWeightingState:
        return StoppingWeightingState(stop_action.weighting_id, stop_at)

    def stop_weighting(self, current_state: StoppingWeightingState) -> StoppedWeightingState:
        weighted_scrap = WeightedScrap.objects.get(pk=current_state.weighting_id)

        # TODO very likely we don't need current_state.stop_time,
        #  we may use scale_api.get_current_relative_weight instead
        new_weight = scale_processors[self.scale_id].get_weight_between(
            to_milliseconds(weighted_scrap.start), to_milliseconds(current_state.stop_time)
        )

        weighted_scrap.weight = new_weight
        weighted_scrap.end = current_state.stop_time
        weighted_scrap.save()

        return StoppedWeightingState(weighting_id=weighted_scrap.pk, last_measured_weight=new_weight)

    def tare(self, current_state: StoppedWeightingState) -> StoppedWeightingState:
        scale_processor = scale_processors[self.scale_id]
        scale_processor.tare()
        return current_state


MESSAGE_KEYS = {
    StartingWeightingState: "starting",
    WeightingState: "weighting",
    StoppingWeightingState: "weighting_stopped",
    StoppedWeightingState: "weight_update_after_stopping",
}
UNKNOWN_MSG_KEY = "unknown"
ERROR_MSG_KEY = "error"

MESSAGE_BY_EXCEPTION = {
    DatabaseError: "lock",
    InvalidStateError: "state",
    UnappliableActionError: "action",
    ScaleAPIError: "scale_data",
}

MESSAGE_BY_ACTION = {
    TareAction: "user-action",
    StartAction: "user-action",
    StopStartAction: "user-action",
    StopAction: "user-action",
    UpdateAction: "server-action",
}


class DashMessagingProcessor:
    def __init__(self, group_name: str) -> None:
        self.group_name = group_name

    async def send_raw_msgs(self, messages: Tuple[Dict[str, Any], ...]) -> None:
        await get_channel_layer().group_send(
            self.group_name,
            {"type": "forward_message", "content": messages},
        )
        logger.info(f"Messages {messages} sent to group '{self.group_name}'")

    def send_updated_state(self, states: AnyStates, scale_id: str) -> None:
        messages = []
        for state in states:
            msg_key = MESSAGE_KEYS.get(type(state), UNKNOWN_MSG_KEY)
            msg_data = {**state.to_message(), "scale_id": scale_id}

            messages.append({msg_key: msg_data})

        async_to_sync(self.send_raw_msgs)(tuple(messages))

    def send_error_state(self, exception: Exception, action: AnyAction, scale_id: str) -> None:
        reason = MESSAGE_BY_EXCEPTION.get(type(exception), UNKNOWN_MSG_KEY)
        action = MESSAGE_BY_ACTION.get(type(action), UNKNOWN_MSG_KEY)

        # If an error is raised due to a lock db on server interaction, it is not necessary to send
        # this event to the client. Also prevents the overcrowding of clients with unnecessary messages
        # which can do race conditions on client.
        if isinstance(exception, DatabaseError) and isinstance(action, UpdateAction):
            logger.warning(
                f"An error lock state, reason - {reason}, exception - {exception}. No message will be sent."
            )
            return

        message = {
            ERROR_MSG_KEY: {
                "reason": reason,
                "action": action,
                "scale_id": scale_id,
                "exception": str(exception),
            }
        }

        async_to_sync(self.send_raw_msgs)((message,))


def get_state_from_db_data(state: ScaleCurrentState) -> AnyState:
    state_type = state.state

    if state_type == ScaleCurrentState.ScaleState.STOPPED_WEIGHTING:
        return StoppedWeightingState()

    if state_type == ScaleCurrentState.ScaleState.STARTING_WEIGHTING:
        return StartingWeightingState(
            scrap_type=state.scrap, start_time=state.time, scrap_charge_id=state.scrap_charge.id
        )

    if state_type == ScaleCurrentState.ScaleState.WEIGHTING:
        return WeightingState(weighting_id=state.weighted_scrap.pk, weight=state.weighted_scrap.weight)

    if state_type == ScaleCurrentState.ScaleState.STOPPING_WEIGHTING:
        return StoppingWeightingState(stop_time=state.time, weighting_id=state.weighted_scrap.pk)

    raise InvalidStateError(f"Inconsistent database state {state_type}")


def update_locked_state(state: ScaleCurrentState, new_state: AnyState):
    # TODO there is no need to convert this state to AnyState type,
    #   because tests below may be conducted against ScaleCurrentState.state attribute
    current_state = get_state_from_db_data(state)

    if current_state == new_state:
        return

    if isinstance(new_state, StoppedWeightingState):
        updated_state = update_to_stopped_weighting_state(state, new_state)
    elif isinstance(new_state, StartingWeightingState):
        updated_state = update_to_starting_weighting_state(state, new_state)
    elif isinstance(new_state, WeightingState):
        updated_state = update_to_weighting_state(state, new_state)
    elif isinstance(new_state, StoppingWeightingState):
        updated_state = update_to_stopping_weighting_state(state, new_state)
    else:
        raise InvalidStateError(f"Trying to update the current state to the invalid state {new_state}")

    updated_state.state_sequence += 1
    updated_state.save()


def apply_action_with_db_lock(
    backend: WeightingBackend, action: AnyAction, message_processor: MessageProcessor
) -> Optional[Exception]:
    state_to_update = None
    raised_exception = None

    logger.info(f"Applying action {action} ... ")

    with transaction.atomic() as t:
        try:
            # try to acquire lock with `select_for_update`
            # (see `select_for_update` here https://docs.djangoproject.com/en/5.0/ref/models/querysets/)
            locked_state_db = (
                ScaleCurrentState.objects.select_related("weighted_scrap")
                .select_for_update(nowait=True)
                .get(scale_id=backend.scale_id)
            )
            logger.info(f"Initial db state is {locked_state_db}")

            locked_state = get_state_from_db_data(locked_state_db)

            logger.info(f"Transaction {t} - lock acquired with state {locked_state}")

            state_processor = get_processor(locked_state, action)

            # All states will be sent to the client due to the update client side
            # Only the last state will be saved to the db, because all states are executed under one lock.
            states = state_processor(backend, locked_state, action)
            logger.info(f"New states are {states}")

            new_state = states[-1]

            if locked_state != new_state:
                logger.info(
                    f"New state {new_state} is different than current state {locked_state}, updating state ..."
                )
                update_locked_state(locked_state_db, new_state)
                state_to_update = states
            else:
                logger.info(
                    f"New state {new_state} is equal to current state {locked_state}, no need to update state"
                )

            logger.info(f"Final db state is {locked_state_db}")

            # release lock by exiting transaction
            logger.debug("Lock released")

        except DatabaseError as e:
            logger.error(f"Database error, in particular: {e}")
            raised_exception = e

        except InvalidStateError as e:
            logger.exception("State machine encountered an invalid state")
            raised_exception = e

        except UnappliableActionError as e:
            logger.exception(f"State machine encountered a non-applicable action {action}")
            raised_exception = e

        except ScaleAPIError as e:
            logger.exception(f"Invalid data from scale {backend.scale_id}")
            raised_exception = e

    if raised_exception is not None:
        message_processor.send_error_state(raised_exception, action, backend.scale_id)
        logger.error(f"Action {action} failed due to {raised_exception} error")
    else:
        logger.info(f"Action {action} applied successfully")

    if state_to_update is not None:
        message_processor.send_updated_state(state_to_update, backend.scale_id)

    return raised_exception
