from scalecore.processor import TareAction
from scrap.weighting import MESSAGING_PROCESSORS, WEIGHTING_BACKENDS
from scrap.scales.weighting_backend import apply_action_with_db_lock


def tare_scale(scale_id: str) -> None:
    backend = WEIGHTING_BACKENDS[scale_id]
    messaging_processor = MESSAGING_PROCESSORS[scale_id]

    apply_action_with_db_lock(backend, TareAction(), messaging_processor)
