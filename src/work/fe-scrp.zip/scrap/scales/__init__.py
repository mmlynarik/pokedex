from typing import Dict

from redis import Redis

from vsadzka.settings import (
    SCALES_REDIS_HOST,
    SCALES_REDIS_PORT,
)

from scalesingest.redis_resources.heartbeat import RedisHeartbeat
from scalesingest.redis_resources.queue import RedisQueue
from scalesingest.redis_resources.stream import ReadonlyRedisStream
from scalesingest.scale_api import get_standard_redis_names, Ind310API, We2110API, ScaleAPI

redis_client = Redis(SCALES_REDIS_HOST, SCALES_REDIS_PORT)


scale_processors: Dict[str, ScaleAPI] = {}


# TODO load these ids from db, for example ScaleCurrentState.scale_id field
#   https://vdevops.sk.uss.com/Esten/UssAi/_workitems/edit/666
for scale_id, api_class in [("v1", Ind310API), ("v2", Ind310API), ("v8", We2110API), ("v9", We2110API)]:
    stream_name, command_queue_name, heartbeat_name = get_standard_redis_names(scale_id)

    stream = ReadonlyRedisStream(redis_client, stream_name, 1024)
    command_queue = RedisQueue(redis_client, command_queue_name)
    heartbeat = RedisHeartbeat(redis_client, heartbeat_name, 5000)

    scale_processors[scale_id] = api_class(stream, command_queue, heartbeat, lookbehind=1024)
