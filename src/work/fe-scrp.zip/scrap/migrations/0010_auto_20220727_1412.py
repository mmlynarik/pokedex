from datetime import datetime

import django.db.models.deletion
from django.db import migrations, models


def create_scrap_group_by_scrap_types(
    apps, scrap_types_str: str, rules_name: str, priority: int
) -> "ScrapGroup":
    ScrapGroup = apps.get_model("scrap", "ScrapGroup")
    ScrapDefinition = apps.get_model("scrap", "ScrapDefinition")
    scrap_types = [item.strip() for item in scrap_types_str.split(",")]
    new_scrap_group = ScrapGroup(
        group_name=f"Group_{datetime.now().timestamp()}", comment=f"Created from: {rules_name} {priority}"
    )
    new_scrap_group.save()
    scrap_types_definitions = ScrapDefinition.objects.filter(scrap_type__in=scrap_types)
    new_scrap_group.scrap_ids.set(scrap_types_definitions)
    new_scrap_group.save()
    return new_scrap_group


def convert_scrap_type_to_scrap_groups(apps, _):
    ScrapSummingLimitSetting = apps.get_model("scrap", "ScrapSummingLimitSetting")
    summing_limits = ScrapSummingLimitSetting.objects.all()
    for summing_limit in summing_limits:
        scrap_group = create_scrap_group_by_scrap_types(
            apps, summing_limit.scrap_types, summing_limit.name, summing_limit.priority
        )
        summing_limit.scrap_types_new = scrap_group
        summing_limit.save()


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0009_auto_20220725_1356"),
    ]

    operations = [
        migrations.AddField(
            model_name="scrapsumminglimitsetting",
            name="scrap_types_new",
            field=models.ForeignKey(
                null=True, on_delete=django.db.models.deletion.PROTECT, to="scrap.ScrapGroup"
            ),
        ),
        migrations.RunPython(convert_scrap_type_to_scrap_groups, reverse_code=migrations.RunPython.noop),
        migrations.RemoveField(model_name="scrapsumminglimitsetting", name="scrap_types"),
        migrations.RenameField(
            model_name="scrapsumminglimitsetting",
            old_name="scrap_types_new",
            new_name="scrap_types",
        ),
        migrations.AlterField(
            model_name="scrapsumminglimitsetting",
            name="scrap_types",
            field=models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="scrap.ScrapGroup"),
        ),
    ]
