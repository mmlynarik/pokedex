from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0078_remove_scrapcharge_active"),
    ]

    operations = [
        migrations.AlterField(
            model_name="scrapcharge",
            name="operator_comment",
            field=models.CharField(blank=True, max_length=512, null=True),
        ),
    ]
