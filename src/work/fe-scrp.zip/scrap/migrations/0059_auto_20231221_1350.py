"""
see https://docs.djangoproject.com/en/5.0/releases/4.0/ (section Table and column naming scheme changes on Oracle)
and https://code.djangoproject.com/ticket/33789#comment:15 for more information

Script to generate `DJANGO3_TO_DJANGO4_SQL` can be found here
https://code.djangoproject.com/attachment/ticket/33789/generate_rename_table_colums_new_trunc.py

You can run this script in django4 environment and `python manage.py shell` as follows:

```
f = open(generate_rename_table_colums_new_trunc.py)
exec(f.open())
f.close()
```

If you need to execute `djangoX_to_djangoY_sql` manually, you can use `python manage.py dbshell`.
"""

import logging
import os

from django.db import connection, migrations


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


DJANGO3_TO_DJANGO4_SQL = """
ALTER TABLE "SCRAP_LOADINGSTATION_RELAXE6E5" RENAME COLUMN "RELAXABLEUPPERSUMMINGLIMIT54D7" to "RELAXABLEUPPERSUMMINGLIMIT130B";
ALTER TABLE "SCRAP_LOADINGSTATION_RELAXE086" RENAME COLUMN "RELAXABLELOWERSUMMINGLIMITEF7C" to "RELAXABLELOWERSUMMINGLIMIT6A28";
"""


DJANGO4_TO_DJANGO3_SQL = """
ALTER TABLE "SCRAP_LOADINGSTATION_RELAXE6E5" RENAME COLUMN "RELAXABLEUPPERSUMMINGLIMIT130B" to "RELAXABLEUPPERSUMMINGLIMIT54D7";
ALTER TABLE "SCRAP_LOADINGSTATION_RELAXE086" RENAME COLUMN "RELAXABLELOWERSUMMINGLIMIT6A28" to "RELAXABLELOWERSUMMINGLIMITEF7C";
"""


def get_sql_rename_script(sql):
    max_name_length = connection.ops.max_name_length()

    # skip migration for non-oracle db (e.g. sqlite)
    if max_name_length is None:
        log.warning(
            f"Migration {os.path.basename(__file__)} skipped because `max_name_length` is not defined "
            f"(the migration is applicable to Oracle db only)"
        )
        return ""

    return sql


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0058_scrapcharge_operator"),
    ]

    # at the moment, when both databases are migrated and django 4 is used in test and production,
    # this migration is no longer needed (however, db backups prior to migration 0059 are not compatible anymore)
    operations = []
