import attr

from django.db import migrations
from django.db.models import Q
from tqdm import tqdm

from scrap.models import MultipleHeatsOptimizationResult


NUM_SLICES = 6


def get_removal_script(start_idx: int, end_idx: int):
    def remove_old_limits(apps, __):
        User = apps.get_model("auth", "User")
        admin = User.objects.filter(is_superuser=True).first()
        if admin is None:
            # This is a one-off migration for existing prod/test databases. In case of
            # creating a new empty db for local development, no data should be loaded -
            # they will be loaded from the db dump file.
            return

        last_id = MultipleHeatsOptimizationResult.objects.latest("id").id
        start_id = last_id / NUM_SLICES * start_idx
        end_id = last_id / NUM_SLICES * end_idx
        query = Q(pk__gte=start_id) & Q(pk__lte=end_id)

        for result in tqdm(
            MultipleHeatsOptimizationResult.objects.filter(query).iterator(10),
            total=MultipleHeatsOptimizationResult.objects.filter(query).count(),
        ):
            result.save()

    return remove_old_limits


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0028_migrate_limits_to_relaxable_limits"),
    ]

    operations = [
        migrations.RunPython(get_removal_script(i, i + 1), migrations.RunPython.noop)
        for i in range(NUM_SLICES)
    ]
