from django.db import migrations
from django_plotly_dash.models import DashApp, StatelessApp
from scrap.dash.settings_app import NAME_APP, SLUG_APP


def create_dash_dependencies(apps, _):
    settings_stateless_app, _ = StatelessApp.objects.get_or_create(app_name=NAME_APP, slug=SLUG_APP)
    DashApp.objects.get_or_create(
        stateless_app=settings_stateless_app,
        instance_name=SLUG_APP,
        slug=SLUG_APP,
        base_state={},
    )


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0011_auto_20220728_0848"),
    ]

    operations = [migrations.RunPython(create_dash_dependencies, reverse_code=migrations.RunPython.noop)]
