import logging

import attr
from django.core.exceptions import ObjectDoesNotExist
from django.db import migrations
from tqdm.auto import tqdm

from scrap.models import ScrapChargeDisplayDataV2, OptimizationDisplayDataV2

log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def display_data_to_scrap_charge(apps, data: ScrapChargeDisplayDataV2, loading_station, closed_at):
    ScrapCharge = apps.get_model("scrap", "ScrapCharge")
    LoadedScrap = apps.get_model("scrap", "LoadedScrap")
    Basket = apps.get_model("scrap", "Basket")

    scrap_charge = ScrapCharge(
        loading_station=loading_station,
        closed_at=closed_at,
        grade_id=data.grade_id,
        total_scrap_weight=data.total_scrap_weight,
        pig_iron_weight=data.pig_iron_weight,
        optimization_start_clicked=data.optimization_start_clicked,
        heat_plan=data.heat_plan,
        raw_fe_chem=data.raw_fe_chem,
        scrap_limits=data.scrap_limits,
        optimizations=data.optimizations,
    )
    scrap_charge.save()

    if data.loaded_scrap_id > -1:
        try:
            loaded_scrap = LoadedScrap.objects.get(pk=data.loaded_scrap_id)

            scrap_charge.active = loaded_scrap.active
            scrap_charge.is_wet = loaded_scrap.is_wet

            for ws in loaded_scrap.weightedscrap_set.all():
                ws.scrap_charge = scrap_charge
                ws.save()

        except ObjectDoesNotExist:
            log.exception(f"LoadedScrap {data.loaded_scrap_id} not found")

    for basked_id in data.basket_ids:
        try:
            basket = Basket.objects.get(basket_id=basked_id)
        except ObjectDoesNotExist:
            basket = Basket.objects.create(basket_id=basked_id, weight=0)
            log.error(f"Invalid basket ID: {basked_id}")

        scrap_charge.baskets.add(basket)

    for basked_id in data.switched_basket_ids:
        try:
            basket = Basket.objects.get(basket_id=basked_id)
        except ObjectDoesNotExist:
            basket = Basket.objects.create(basket_id=basked_id, weight=0)
            log.error(f"Invalid basket ID: {basked_id}")

        scrap_charge.switched_baskets.add(basket)

    scrap_charge.save()

    return scrap_charge


def get_optimizations(scrap_charge):
    return tuple(
        attr.evolve(
            OptimizationDisplayDataV2.from_optimization_result(res),
            comment=scrap_charge.operator_comment,
            operator_decision=scrap_charge.operator_decision,
            inputs_snapshot=scrap_charge.inputs_snapshot,
        )
        for res in scrap_charge.optimization_results.order_by("created_at")
    )


def scrap_charge_to_display_data(scrap_charge):
    return ScrapChargeDisplayDataV2(
        grade_id=scrap_charge.grade_id,
        basket_ids=tuple(basket.basket_id for basket in scrap_charge.baskets.all()),
        switched_basket_ids=tuple(basket.basket_id for basket in scrap_charge.switched_baskets.all()),
        total_scrap_weight=scrap_charge.total_scrap_weight,
        pig_iron_weight=scrap_charge.pig_iron_weight,
        raw_fe_chem=scrap_charge.raw_fe_chem,
        scrap_limits=scrap_charge.scrap_limits,
        optimizations=get_optimizations(scrap_charge),
        optimization_start_clicked=scrap_charge.optimization_start_clicked,
        heat_plan=scrap_charge.heat_plan,
        loaded_scrap_id=-1,
    )


def convert_closed_heat_to_scrap_charge(apps, _) -> None:
    ClosedHeatV2 = apps.get_model("scrap", "ClosedHeatV2")
    ClosedHeatEvaluationV2 = apps.get_model("scrap", "ClosedHeatEvaluationV2")

    for closed_heat in tqdm(ClosedHeatV2.objects.all()):
        display_data_to_scrap_charge(
            apps,
            data=closed_heat.data,
            loading_station=closed_heat.loading_station,
            closed_at=closed_heat.created_at,
        )

    # remove evaluations to be able to remove closed heats,
    # as they are used as keys in evaluations
    # (we will be able to recreate evaluations from scrap charges later)
    ClosedHeatEvaluationV2.objects.all().delete()

    # remove closed heats, so we do not create duplicates,
    # when migration is reverted
    ClosedHeatV2.objects.all().delete()


def convert_scrap_charge_to_closed_heat(apps, _) -> None:
    ScrapCharge = apps.get_model("scrap", "ScrapCharge")
    ClosedHeatV2 = apps.get_model("scrap", "ClosedHeatV2")
    WeightedScrap = apps.get_model("scrap", "WeightedScrap")

    ClosedHeatV2.objects.bulk_create(
        ClosedHeatV2(
            loading_station=scrap_charge.loading_station,
            created_at=scrap_charge.closed_at,
            data=scrap_charge_to_display_data(scrap_charge),
        )
        for scrap_charge in tqdm(ScrapCharge.objects.all())
    )

    # dereference all weighted srap objects
    for ws in WeightedScrap.objects.all():
        ws.scrap_charge = None
        ws.save()

    ScrapCharge.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0056_auto_20231205_0956"),
    ]

    operations = [
        migrations.RunPython(convert_closed_heat_to_scrap_charge, convert_scrap_charge_to_closed_heat)
    ]
