import logging

from django.core.exceptions import ObjectDoesNotExist
from django.db import migrations
from django.db.models import ProtectedError

from scrap.utils_migrations import get_or_create_grade_group_v2

from scrap_core import SUPPORTED_CHEMS


log = logging.getLogger(__name__)
log.addHandler(logging.NullHandler())


def split_specific_limits_into_single_grade_limits(apps, __):
    RelaxableRiskLimitSetting = apps.get_model("scrap", "RelaxableRiskLimitSetting")

    log.info("Splitting of limits started ...")

    # loop over all low-chem limits
    for limit in RelaxableRiskLimitSetting.objects.filter(name__startswith="MIG0021_low"):
        grade_group = limit.grade_ids

        log.info(f"Processing limit {limit.name}, {grade_group.group_name} ...")

        grade_ids = tuple(item.grade_id for item in grade_group.grade_ids.all())

        # split multi-grade limits only
        if len(grade_ids) == 1:
            log.info(f"Limit {limit.name}, {grade_group.group_name} - skipped")
            continue

        for grade_id in grade_ids:

            # create a single-grade group
            single_grade_group = get_or_create_grade_group_v2(
                apps, grade_ids=[grade_id], create_name=f"Group_{grade_id}"
            )
            log.info(f"Group {single_grade_group.group_name} - created")

            # clone original limit and change its grade group
            RelaxableRiskLimitSetting(
                name=f"{limit.name}",
                grade_ids=single_grade_group,
                comment="Calculated single grade limit",
                Cr_aim=limit.Cr_aim,
                Cr_allowed=limit.Cr_allowed,
                Cu_aim=limit.Cu_aim,
                Cu_allowed=limit.Cu_allowed,
                Mo_aim=limit.Mo_aim,
                Mo_allowed=limit.Mo_allowed,
                Ni_aim=limit.Ni_aim,
                Ni_allowed=limit.Ni_allowed,
                S_aim=limit.S_aim,
                S_allowed=limit.S_allowed,
                Si_aim=limit.Si_aim,
                Si_allowed=limit.Si_allowed,
                Sn_aim=limit.Sn_aim,
                Sn_allowed=limit.Sn_allowed,
            ).save()
            log.info(f"Limit {limit.name}, {single_grade_group.group_name} - created")

        # remove original limit
        limit.delete()
        log.info(f"Limit {limit.name}, {grade_group.group_name} - removed")

        # remove original group, if it is not needed anymore
        try:
            grade_group.delete()
            log.info(f"Group {grade_group.group_name} - removed")
        except ProtectedError:
            log.warning(f"Group {grade_group.group_name} - can't be removed")

        log.info(f"Limit {limit.name}, {grade_group.group_name} - processed")

    log.info("Splitting of limits done")


def replace_with_1(limit, default_limit, chem):

    aim = f"{chem}_aim"
    allowed = f"{chem}_allowed"

    # specific limits are usually used to weaken default limit setting
    if getattr(limit, aim) <= getattr(default_limit, aim) and getattr(limit, allowed) <= getattr(
        default_limit, allowed
    ):
        setattr(limit, aim, 1)
        setattr(limit, allowed, 1)


def replace_default_value_with_1(apps, __):

    RelaxableRiskLimitSetting = apps.get_model("scrap", "RelaxableRiskLimitSetting")

    log.info(f"Replacing defaults with 1s started ...")

    try:
        default_limit = RelaxableRiskLimitSetting.objects.get(grade_ids__group_name="All grades")
    except ObjectDoesNotExist:
        log.warning("Default risk limit not found, can't replace anything")
        return

    # loop over all low-chem limits
    for limit in RelaxableRiskLimitSetting.objects.filter(name__startswith="MIG0021_low"):

        for chem in SUPPORTED_CHEMS:
            replace_with_1(limit, default_limit, chem)

        limit.save()

        log.info(f"Limit {limit.name}, {limit.grade_ids.group_name} - updated")

    log.info(f"Replacing defaults with 1s done")


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0034_loadingstation_level_2"),
    ]

    operations = [
        migrations.RunPython(replace_default_value_with_1, migrations.RunPython.noop),
        migrations.RunPython(split_specific_limits_into_single_grade_limits, migrations.RunPython.noop),
    ]
