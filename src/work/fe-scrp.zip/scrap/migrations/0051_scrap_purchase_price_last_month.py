from django.db import migrations

from datetime import date
from typing import Optional
import attr

from dateutil.relativedelta import relativedelta
from scrap_core import ScrapType

from scrap.utils import is_zone_domestic


def get_scrap_price_for_last_month(
    purchase_date: date,
    scrap_type: Optional[ScrapType],
    scrap_zone: Optional[str],
    scrap_supplier: Optional[str],
    scrap_purchase_model,
) -> Optional[float]:
    def month_diff(dta: date, dtb: date) -> int:
        diff = relativedelta(dta.replace(day=1), dtb.replace(day=1))
        return 12 * diff.years + diff.months

    if scrap_type is None or scrap_zone is None:
        return None

    filter_kwargs = {"scrap_type": scrap_type, "zone": scrap_zone, "date__lt": purchase_date}
    if not is_zone_domestic(scrap_zone):
        if scrap_supplier is None:
            return None
        filter_kwargs["supplier__name"] = scrap_supplier

    try:
        scrap_purchase = scrap_purchase_model.objects.filter(**filter_kwargs).latest("date")
        previous_price_age = month_diff(purchase_date, scrap_purchase.date)
        if scrap_purchase.price is None or previous_price_age > 1:
            return None
        return scrap_purchase.price
    except scrap_purchase_model.DoesNotExist:
        return None


def add_last_month_price_data(apps, _) -> None:
    ScrapPurchaseRecord = apps.get_model("scrap", "ScrapPurchaseRecord")
    ScrapPurchase = apps.get_model("scrap", "ScrapPurchase")

    scrap_purchases = ScrapPurchaseRecord.objects.all()
    for scrap_purchase in scrap_purchases:
        current_data = scrap_purchase.current_data
        scrap_offers = current_data.scrap_offer_data
        if not scrap_offers:
            continue

        updated_scrap_offers = [
            attr.evolve(
                scrap_offer,
                last_month_price=get_scrap_price_for_last_month(
                    purchase_date=scrap_purchase.purchase_date,
                    scrap_type=scrap_offer.scrap_type,
                    scrap_zone=scrap_offer.zone,
                    scrap_supplier=scrap_offer.supplier,
                    scrap_purchase_model=ScrapPurchase,
                ),
            )
            for scrap_offer in scrap_offers
        ]
        updated_current_data = attr.evolve(current_data, scrap_offer_data=updated_scrap_offers)
        scrap_purchase.current_data = updated_current_data
        scrap_purchase.save()


class Migration(migrations.Migration):

    dependencies = [
        ("scrap", "0050_alter_operator_operator_id"),
    ]

    operations = [
        migrations.RunPython(add_last_month_price_data, migrations.RunPython.noop),
    ]
